# Frozen producer receipts for counter mana substitutions

Dependent scratch transport for `abilities_final_counter_cost_producers` (core ManaCost producer model, acquisition and source designations). Base files were captured from live source; the patch does not replace owner core/acquisition files. No production files changed and no builds, tests, probes or materialization were executed by this worker.

Each counter allocation stores its exact frozen producer index. Resource `source` is the creature receiving a counter; event source/controller/designations come from the indexed producer, not the creature's or spell's current keywords. Metadata-bearing costs reject unlabelled allocations and out-of-range/wrong-rule indices. Metadata-free legacy costs retain the existing unlabelled operation. Producer receipts participate in request hashing.

The planner's replacement-aware counter preview, generic payment commit and spell payment commit all use the same frozen cause builder. CostContext owns a checkpointed explicit cause override. Its execution binding transports that receipt explicitly through ManaExecutionContext; prepared payment scopes consume and restore it, and ordinary cost-shaped causes alone never authorize preservation. Existing enclosing transactions retain rollback and pending decision ownership.

Both wasm command paths preserve producer indices. The protocol adds an optional producer descriptor to resource choices, keeping old payload defaults. Labels read only frozen designations or occurrence plus exact source ID. The direct client retains separate indexed choices while allowing a counter resource to supply mana independently. Root TypeScript bindings carry the additive optional descriptor; the root may regenerate protocol bindings with its normal generator when verifying the union.

Root-only verification targets authored here:

- Engine unit filter `counter_producer_allocation`: real two-counter commit from the same resource using two distinct producer occurrences; frozen cause identity after current abilities disappear; speculative neutrality; forged/unlabelled metadata rejection; distinct receipt hashes; legacy compatibility.
- Engine unit filter `bound_counter_cost_producer`: CostContext/ExecutionContext checkpoint transport, prepared scope success/error/pending restoration, ordinary absent-override negative.
- Wasm unit filter `indexed_counter_resource_commands`: exact indexed command roundtrip and legacy command compatibility.
- `web/ui/tests/counter-payment-producers.test.js`: independent labelled selections and mana activation, both class choices exposed on card actions.
- Owner Dewshaper actual cause-sensitive replacement scenarios are a separate required source-level integration proof. These transport tests do not substitute for that gameplay evidence.

No Cargo registrations are required: Rust regressions are inside existing unit targets. This packet does not change producer acquisition, mana-cost algebra, current keyword inference, counter replacement policy, or the original raw source records.
