import test from "node:test";
import assert from "node:assert/strict";
import { paymentPreferences, paymentSourceOptions, selectPaymentSource, sourceChoiceKey } from "../src/lib/payment-draft.js";
import { manaPaymentActionMap } from "../src/lib/mana-payment-actions.js";

const payment = { available_sources: [{ source_id: "10", source_name: "Resource",
  payment_kinds: ["put_minus_one_counter_by:0", "put_minus_one_counter_by:1"],
  payment_labels: { "put_minus_one_counter_by:0": "Put a -1/-1 counter · first (source #20)",
    "put_minus_one_counter_by:1": "Put a -1/-1 counter · second (source #21)" } }],
  activation_options: [{ source_id: "10", ability_index: 0 }] };

test("counter producers retain distinct labels, selections and independent mana activations", () => {
  const options = paymentSourceOptions(payment);
  assert.equal(options.length, 3);
  assert.match(options[1].label, /first/);
  assert.match(options[2].label, /second/);
  assert.notEqual(sourceChoiceKey(options[1]), sourceChoiceKey(options[2]));
  let draft = selectPaymentSource(paymentPreferences(), options[1]);
  draft = selectPaymentSource(draft, options[2]);
  draft = selectPaymentSource(draft, options[0]);
  assert.equal(draft.required_alternatives.length, 2);
  assert.equal(draft.required_activations.length, 1);
  assert.deepEqual(draft.required_alternatives.map(value => value.payment_kind),
    ["put_minus_one_counter_by:0", "put_minus_one_counter_by:1"]);
});

test("card actions expose both frozen producer labels even when the resource makes mana", () => {
  const actions = manaPaymentActionMap({ decision: { kind: "mana_payment", player: 0 }, perspective: 0, mana_payment: payment }).get(10);
  assert.equal(actions.length, 3);
  assert.ok(actions.some(action => /first/.test(action.label)));
  assert.ok(actions.some(action => /second/.test(action.label)));
});
