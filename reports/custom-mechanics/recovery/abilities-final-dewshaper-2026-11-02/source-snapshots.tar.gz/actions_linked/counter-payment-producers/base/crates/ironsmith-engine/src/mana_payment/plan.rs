use crate::color::Color;
use crate::costs::PaymentReason;
use crate::ids::{ObjectId, PlayerId};
use crate::mana::{ManaCost, ManaSymbol};
use crate::player::{ManaPool, ManaSpendPolicy};

/// Stable, transaction-local identity for an expanded mana pip.
#[cfg_attr(
    feature = "serialization",
    derive(serde::Serialize, serde::Deserialize)
)]
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, PartialOrd, Ord)]
pub struct ManaPipId(pub u32);

/// Whether declining a payment is itself a legal choice.
#[cfg_attr(
    feature = "serialization",
    derive(serde::Serialize, serde::Deserialize)
)]
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub enum PaymentObligation {
    #[default]
    Required,
    Optional,
}

/// One exact mana-ability choice the player has selected while incrementally
/// constructing a payment.  Unlike `required_sources`, this preserves which
/// ability and mana-output branch was chosen for a multi-ability source. The
/// containing vector is a multiset: repeated entries require repeated legal
/// activations of the same ability.
#[cfg_attr(
    feature = "serialization",
    derive(serde::Serialize, serde::Deserialize)
)]
#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub struct RequiredManaActivation {
    pub source: ObjectId,
    pub ability_index: usize,
    pub color_restriction: Option<Vec<Color>>,
}

/// One exact keyword-payment resource selected during incremental planning.
#[cfg_attr(
    feature = "serialization",
    derive(serde::Serialize, serde::Deserialize)
)]
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, PartialOrd, Ord)]
pub struct RequiredAlternativePayment {
    pub source: ObjectId,
    pub kind: ManaPaymentSourceKind,
}

/// User choices that constrain replanning.  These are deliberately expressed
/// as constraints rather than client-authored executable steps.
#[cfg_attr(
    feature = "serialization",
    derive(serde::Serialize, serde::Deserialize)
)]
#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct ManaPaymentPreferences {
    pub required_sources: Vec<ObjectId>,
    pub required_activations: Vec<RequiredManaActivation>,
    pub required_alternatives: Vec<RequiredAlternativePayment>,
    pub excluded_sources: Vec<ObjectId>,
    pub preserve_sources: Vec<ObjectId>,
    pub prefer_life: bool,
    /// Expanded pips the player explicitly chose to pay with life.
    pub required_life_pips: Vec<ManaPipId>,
    /// Actual W/U/B/R/G mana to allocate to X. This is a constraint on a
    /// server-proved assignment, not a client-authored payment receipt.
    #[cfg_attr(
        feature = "serialization",
        serde(default, skip_serializing_if = "Option::is_none")
    )]
    pub x_allocation: Option<ironsmith_core::mana::XManaAllocation>,
}

impl ManaPaymentPreferences {
    pub fn normalize(&mut self) {
        self.required_life_pips.sort_unstable();
        self.required_life_pips.dedup();
        self.required_sources.sort_unstable();
        self.required_sources.dedup();
        for activation in &mut self.required_activations {
            if let Some(colors) = &mut activation.color_restriction {
                colors.sort_by_key(|color| color_sort_key(*color));
                colors.dedup();
            }
        }
        self.required_activations.sort_by_key(|activation| {
            (
                activation.source,
                activation.ability_index,
                activation
                    .color_restriction
                    .as_deref()
                    .map(color_restriction_sort_key),
            )
        });
        self.required_alternatives.sort_unstable();
        self.required_alternatives.dedup();
        self.excluded_sources.sort_unstable();
        self.excluded_sources.dedup();
        self.preserve_sources.sort_unstable();
        self.preserve_sources.dedup();
    }
}

fn color_sort_key(color: Color) -> u8 {
    match color {
        Color::White => 0,
        Color::Blue => 1,
        Color::Black => 2,
        Color::Red => 3,
        Color::Green => 4,
    }
}

fn color_restriction_sort_key(colors: &[Color]) -> u8 {
    colors.iter().fold(0, |bits, color| {
        bits | match color {
            Color::White => 1 << 0,
            Color::Blue => 1 << 1,
            Color::Black => 1 << 2,
            Color::Red => 1 << 3,
            Color::Green => 1 << 4,
        }
    })
}

/// Everything needed to plan one payment transaction.
#[cfg_attr(
    feature = "serialization",
    derive(serde::Serialize, serde::Deserialize)
)]
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ManaPaymentRequest {
    pub payer: PlayerId,
    pub source: ObjectId,
    pub reason: PaymentReason,
    pub cost: ManaCost,
    pub x_value: u32,
    pub spend_policy: ManaSpendPolicy,
    /// Resources already committed to a separate tap cost, such as Harmonize.
    pub reserved_tap_sources: Vec<ObjectId>,
    /// Graveyard cards reserved for payment after mana abilities finish.
    pub reserved_graveyard_sources: Vec<ObjectId>,
    /// Permanents announced for later sacrifice; tapping for mana is allowed.
    pub reserved_permanent_sources: Vec<ObjectId>,
    pub allow_mana_abilities: bool,
    pub allow_life_payment: bool,
    pub allow_black_life: bool,
    pub obligation: PaymentObligation,
    pub preferences: ManaPaymentPreferences,
    /// Assist's actual payment must leave this independently priced caster
    /// obligation payable. A continuation cannot itself contain Assist.
    #[cfg_attr(
        feature = "serialization",
        serde(default, skip_serializing_if = "Option::is_none")
    )]
    pub assist_completion: Option<Box<ManaPaymentRequest>>,
    /// Explicit source-wide payment restrictions (for example, a cast
    /// permission that allows activating only certain lands). CR 605.3c
    /// ability-occurrence guards are retained separately in native game state.
    #[cfg_attr(feature = "serialization", serde(default))]
    pub activation_excluded_sources: Vec<ObjectId>,
}

impl ManaPaymentRequest {
    pub fn new(payer: PlayerId, source: ObjectId, reason: PaymentReason, cost: ManaCost) -> Self {
        Self {
            payer,
            source,
            reason,
            cost,
            x_value: 0,
            spend_policy: ManaSpendPolicy::default(),
            reserved_tap_sources: Vec::new(),
            reserved_graveyard_sources: Vec::new(),
            reserved_permanent_sources: Vec::new(),
            allow_mana_abilities: true,
            allow_life_payment: true,
            allow_black_life: false,
            obligation: PaymentObligation::Required,
            preferences: ManaPaymentPreferences::default(),
            assist_completion: None,
            activation_excluded_sources: Vec::new(),
        }
    }

    pub(crate) fn reserving_alternatives(&self, allocations: &[PlannedPipAllocation]) -> Self {
        let mut request = self.clone();
        for allocation in allocations {
            match allocation.payment {
                PlannedPipPayment::Convoke(id)
                | PlannedPipPayment::Improvise(id)
                | PlannedPipPayment::Waterbend(id) => {
                    if !request.reserved_tap_sources.contains(&id) {
                        request.reserved_tap_sources.push(id);
                    }
                }
                PlannedPipPayment::Delve(id) => {
                    if !request.reserved_graveyard_sources.contains(&id) {
                        request.reserved_graveyard_sources.push(id);
                    }
                }
                _ => {}
            }
        }
        request
    }

    pub fn with_x(mut self, x_value: u32) -> Self {
        self.x_value = x_value;
        self
    }

    pub fn with_spend_policy(mut self, spend_policy: ManaSpendPolicy) -> Self {
        self.spend_policy = spend_policy;
        self
    }
}

/// A single mana ability activation selected by a plan.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct PlannedManaActivation {
    /// Exact production decisions captured by the planner, including fallback simulation.
    pub production_witnesses: Option<Vec<super::ManaProductionWitness>>,
    /// Exact server-selected production outputs and replacement decisions,
    /// grouped by the original nonempty mana event for authoritative replay.
    pub replacement_witnesses: Option<Vec<super::ManaReplacementWitness>>,

    pub source: ObjectId,
    pub ability_index: usize,
    /// Restriction supplied to existing mana-choice effects during execution.
    pub color_restriction: Option<Vec<Color>>,
    pub expected_mana: ManaPool,
    /// Exact payer pool after this step in the selected plan order.
    pub expected_pool_after: ManaPool,
    /// Number of distinct colored outputs inferred for source-preservation scoring.
    pub flexibility: usize,
    pub undo_safe: bool,
}

#[cfg_attr(
    feature = "serialization",
    derive(serde::Serialize, serde::Deserialize)
)]
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, PartialOrd, Ord)]
pub enum ManaPaymentSourceKind {
    ManaAbility,
    Convoke,
    Improvise,
    Delve,
    Waterbend,
    PutMinusOneCounter,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ManaPaymentSourceOption {
    pub source: ObjectId,
    pub kinds: Vec<ManaPaymentSourceKind>,
}

/// One exact mana-ability action that an incremental payment client may offer.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ManaPaymentActivationOption {
    pub source: ObjectId,
    pub ability_index: usize,
    pub color_restriction: Option<Vec<Color>>,
    pub expected_mana: ManaPool,
    pub repeatable: bool,
    /// Sequential activations proven legal on a scratch branch, capped at
    /// the number useful for this payment. This is not an unlimited-use flag.
    pub max_activations: usize,
}

/// How a displayed pip is expected to be paid.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum PlannedPipPayment {
    Mana(ManaSymbol),
    Life(u32),
    Convoke(ObjectId),
    Improvise(ObjectId),
    Delve(ObjectId),
    Waterbend(ObjectId),
    PutMinusOneCounter(ObjectId),
    Assist {
        player: PlayerId,
        symbol: ManaSymbol,
    },
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct PlannedPipAllocation {
    pub pip: ManaPipId,
    pub printed_index: usize,
    pub alternatives: Vec<ManaSymbol>,
    pub payment: PlannedPipPayment,
}

/// Reasons that confirmation deserves an explicit warning.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum ManaPaymentWarning {
    PaysLife(u32),
    UsesNonUndoSafeSource(ObjectId),
    UsesPreservedSource(ObjectId),
    ProducesExcessMana(u32),
    RequiresManualChoices,
}

/// Lexicographic score. Lower values are preferred in every field.
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq, PartialOrd, Ord)]
pub struct ManaPaymentScore {
    pub irreversible_cost: u32,
    pub life_paid: u32,
    pub preserved_sources_used: u32,
    pub excess_mana: u32,
    pub flexible_sources_used: u32,
    pub source_count: u32,
}

impl ManaPaymentScore {
    /// No ranked alternative can beat this score, so ranking may stop here.
    pub fn reaches_search_floor(self) -> bool {
        self.irreversible_cost == 0
            && self.life_paid == 0
            && self.preserved_sources_used == 0
            && self.excess_mana == 0
            && self.flexible_sources_used == 0
    }
}

/// An engine-produced proposal for paying a mana cost, or an unfunded payment window.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ManaPaymentPlan {
    /// False for a payment window that needs more resources before confirmation.
    pub payable: bool,
    pub id: u64,
    pub request_hash: u64,
    pub mana_ability_steps: Vec<PlannedManaActivation>,
    pub allocations: Vec<PlannedPipAllocation>,
    /// The portion still paid from mana/life after keyword alternatives.
    pub mana_cost_after_alternatives: ManaCost,
    pub pool_before: ManaPool,
    pub expected_pool_after_activations: ManaPool,
    pub expected_pool_after_payment: ManaPool,
    pub life_to_pay: u32,
    pub score: ManaPaymentScore,
    pub warnings: Vec<ManaPaymentWarning>,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum ManaPaymentFailure {
    MissingPlayer,
    NoLegalPlan,
    SearchLimitReached,
    ConflictingPreferences,
    StalePlan,
    ExecutionFailed,
    /// An otherwise legal payment's effect/program could not be completed.
    EffectExecutionFailed(crate::effects::ExecutionError),
}

impl ManaPaymentFailure {
    pub(crate) fn from_execution(error: crate::game_loop::GameLoopError) -> Self {
        match error {
            crate::game_loop::GameLoopError::ExecutionFailed(error)
            | crate::game_loop::GameLoopError::ActionError(
                crate::special_actions::ActionError::ExecutionFailure { error, .. },
            ) => Self::EffectExecutionFailed(error),
            _ => Self::ExecutionFailed,
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ManaPaymentExecution {
    Paid,
    PendingDecision,
}

/// A client response to an authoritative payment proposal.
///
/// The client never sends executable activation or spending steps. It may
/// accept the selected server plan, ask the server to replan with constraints,
/// activate a currently legal mana source, or cancel the enclosing transaction.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum ManaPaymentResponse {
    Confirm {
        plan_id: u64,
        request_hash: u64,
    },
    Replan {
        preferences: ManaPaymentPreferences,
    },
    /// Activate one currently legal source, then return to this payment.
    Activate {
        source: ObjectId,
        ability_index: usize,
    },
    Cancel,
}

/// Resumable engine-side state for one proposed payment.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct PendingManaPayment {
    pub request: ManaPaymentRequest,
    pub plan: ManaPaymentPlan,
    pub next_activation: usize,
    /// Actual completed activation prefix; native checkpoint clones retain
    /// the same producer identities through prompts and plan refinement.
    pub(crate) completed_outputs: crate::effects::CompletedActionPrefix,
    /// Exact activation acquisition retained only by this pending payment.
    pub(crate) activation_declaration: Option<crate::events::spells::ActivationDeclaration>,
    /// False while the UI is showing the first legal plan and a better
    /// bounded-search result is still being computed.
    pub planning_complete: bool,
}

impl PendingManaPayment {
    /// Refine a native proposal without losing actions already completed while
    /// funding its predecessor. Only producer handles transfer; the newly
    /// constructed request, plan, cursor and planning policy remain authoritative.
    pub(crate) fn with_completed_prefix_from(mut self, previous: Option<&Self>) -> Self {
        if let Some(previous) = previous {
            self.completed_outputs = previous.completed_outputs.clone();
            self.activation_declaration = previous.activation_declaration.clone();
        }
        self
    }

    pub fn new(request: ManaPaymentRequest, plan: ManaPaymentPlan) -> Self {
        Self {
            request,
            plan,
            next_activation: 0,
            completed_outputs: Default::default(),
            activation_declaration: None,
            planning_complete: true,
        }
    }

    pub fn provisional(request: ManaPaymentRequest, plan: ManaPaymentPlan) -> Self {
        // A funded first plan at the ranking floor is already the best answer.
        let planning_complete = plan.payable && plan.score.reaches_search_floor();
        Self {
            request,
            plan,
            next_activation: 0,
            completed_outputs: Default::default(),
            activation_declaration: None,
            planning_complete,
        }
    }
}

#[cfg(all(test, feature = "serialization"))]
mod consumer_constraint_wire_tests {
    use super::*;
    #[test]
    fn serialized_requests_retain_cost_owned_spending_constraints_and_root_identity() {
        use ironsmith_core::mana::{ManaProducerFilter, ManaSpendingRestriction};
        let request = ManaPaymentRequest::new(
            PlayerId(0),
            ObjectId::from_raw(19),
            PaymentReason::CastSpell,
            ManaCost::new().add_generic(2).with_spending_restriction(
                ManaSpendingRestriction::ProducedBy(ManaProducerFilter::Subtype(
                    crate::types::Subtype::Treasure,
                )),
            ),
        );
        let json = serde_json::to_value(&request).unwrap();
        let restored: ManaPaymentRequest = serde_json::from_value(json.clone()).unwrap();
        assert_eq!(restored, request);
        assert_eq!(
            crate::mana_payment::mana_payment_transaction_id(&restored),
            crate::mana_payment::mana_payment_transaction_id(&request)
        );
        let mut legacy = json;
        legacy["cost"]
            .as_object_mut()
            .unwrap()
            .remove("spending_restrictions");
        let plain: ManaPaymentRequest = serde_json::from_value(legacy).unwrap();
        assert!(plain.cost.spending_restrictions().is_empty());
        assert_ne!(
            crate::mana_payment::mana_payment_transaction_id(&plain),
            crate::mana_payment::mana_payment_transaction_id(&request)
        );
    }
}
