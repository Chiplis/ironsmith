use super::*;

/// "Double all damage that sources you control of the chosen type would deal."
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct DoubleDamageFromSourcesYouControlOfChosenType {
    pub display: String,
}

impl DoubleDamageFromSourcesYouControlOfChosenType {
    pub fn new(display: String) -> Self {
        Self { display }
    }
}

#[derive(Debug, Clone)]
struct ChosenTypeDamageSourceMatcher {
    ability_source: ObjectId,
}

impl ReplacementMatcher for ChosenTypeDamageSourceMatcher {

    fn matches_prepared_event(
        &self,
        event: &dyn crate::events::traits::GameEventType,
        ctx: &crate::events::context::PreparedEventContext,
    ) -> bool {
        if event.event_kind() != EventKind::Damage {
            return false;
        }

        let Some(damage) = downcast_event::<DamageEvent>(event) else {
            return false;
        };
        let Some(chosen_type) = ctx.game.chosen_creature_type(self.ability_source) else {
            return false;
        };
        let Some(source_obj) = ctx.game.object(damage.source) else {
            return false;
        };

        ctx.game.current_controller(source_obj.id) == Some(ctx.controller)
            && ctx.game.current_has_subtype(source_obj.id, chosen_type)
    }

    fn priority(&self) -> ReplacementPriority {
        ReplacementPriority::Other
    }

    fn display(&self) -> String {
        "If a source you control of the chosen type would deal damage".to_string()
    }
}

impl StaticAbilityKind for DoubleDamageFromSourcesYouControlOfChosenType {
    fn id(&self) -> StaticAbilityId {
        StaticAbilityId::DoubleDamageFromSourcesYouControlOfChosenType
    }

    fn display(&self) -> String {
        ironsmith_core::semantic_audit::retained("DoubleDamageFromSourcesYouControlOfChosenType", &self.display, self)
    }

    fn generate_replacement_effect(
        &self,
        source: ObjectId,
        controller: PlayerId,
    ) -> Option<ReplacementEffect> {
        Some(ReplacementEffect::with_matcher(
            source,
            controller,
            ChosenTypeDamageSourceMatcher {
                ability_source: source,
            },
            ReplacementAction::Double,
        ))
    }
}

#[derive(Debug, Clone, PartialEq)]
pub struct RedirectDamageToSourceController {
    pub source_filter: ObjectFilter,
    pub target_player_filter: PlayerFilter,
    pub display: String,
}

impl RedirectDamageToSourceController {
    pub fn new(
        source_filter: ObjectFilter,
        target_player_filter: PlayerFilter,
        display: impl Into<String>,
    ) -> Self {
        Self {
            source_filter,
            target_player_filter,
            display: display.into(),
        }
    }
}

impl StaticAbilityKind for RedirectDamageToSourceController {
    fn id(&self) -> StaticAbilityId {
        StaticAbilityId::RedirectDamageToSourceController
    }

    fn display(&self) -> String {
        ironsmith_core::semantic_audit::retained("RedirectDamageToSourceController", &self.display, self)
    }

    fn generate_replacement_effect(
        &self,
        source: ObjectId,
        controller: PlayerId,
    ) -> Option<ReplacementEffect> {
        Some(ReplacementEffect::with_matcher(
            source,
            controller,
            DamageAmountReplacementMatcher {
                source_filter: self.source_filter.clone(),
                target_player_filter: Some(self.target_player_filter.clone()),
                target_object_filter: None,
                condition: None,
                combat_only: false,
                noncombat_only: false,
                amount_less_than: None,
                maximum_damage: None,
            },
            ReplacementAction::Redirect {
                target: RedirectTarget::ToSourceController,
                which: RedirectWhich::First,
            },
        ))
    }
}

#[derive(Debug, Clone, PartialEq)]
pub struct ModifyDamageAmountReplacement {
    pub source_filter: ObjectFilter,
    pub target_player_filter: Option<PlayerFilter>,
    pub target_object_filter: Option<ObjectFilter>,
    pub delta: i32,
    pub dynamic_delta: Option<Value>,
    pub noncombat_only: bool,
    pub display: String,
    pub condition: Option<crate::ConditionExpr>,
}

impl ModifyDamageAmountReplacement {
    pub fn new(
        source_filter: ObjectFilter,
        target_player_filter: Option<PlayerFilter>,
        target_object_filter: Option<ObjectFilter>,
        delta: i32,
        display: impl Into<String>,
    ) -> Self {
        Self {
            source_filter,
            target_player_filter,
            target_object_filter,
            delta,
            dynamic_delta: None,
            noncombat_only: false,
            display: display.into(),
            condition: None,
        }
    }

    pub fn with_dynamic_delta(mut self, value: Value) -> Self {
        self.dynamic_delta = Some(value);
        self
    }

    pub fn with_noncombat_only(mut self, noncombat_only: bool) -> Self {
        self.noncombat_only = noncombat_only;
        self
    }

    pub fn with_condition(mut self, condition: crate::ConditionExpr) -> Self {
        self.condition = Some(match self.condition.take() {
            Some(existing) => crate::ConditionExpr::And(Box::new(existing), Box::new(condition)),
            None => condition,
        });
        self
    }
}

#[derive(Debug, Clone, PartialEq)]
pub struct MinimumDamageAmountReplacement {
    pub source_filter: ObjectFilter,
    pub target_player_filter: Option<PlayerFilter>,
    pub target_object_filter: Option<ObjectFilter>,
    pub floor: Value,
    pub noncombat_only: bool,
    pub display: String,
}

impl MinimumDamageAmountReplacement {
    pub fn new(
        source_filter: ObjectFilter,
        target_player_filter: Option<PlayerFilter>,
        target_object_filter: Option<ObjectFilter>,
        floor: Value,
        noncombat_only: bool,
        display: impl Into<String>,
    ) -> Self {
        Self {
            source_filter,
            target_player_filter,
            target_object_filter,
            floor,
            noncombat_only,
            display: display.into(),
        }
    }
}

/// The recipient-side relation "shares a color with the damage's source",
/// carried as a tagged constraint on the damage source reference.
fn split_damage_source_color_relation(filter: &ObjectFilter) -> (std::borrow::Cow<'_, ObjectFilter>, bool) {
    let is_pair_relation = |constraint: &crate::filter::TaggedObjectConstraint| {
        constraint.tag.as_str() == "triggering_source"
            && constraint.relation == TaggedOpbjectRelation::SharesColorWithTagged
    };
    if !filter.tagged_constraints.iter().any(is_pair_relation) {
        return (std::borrow::Cow::Borrowed(filter), false);
    }
    let mut stripped = filter.clone();
    stripped.tagged_constraints.retain(|constraint| !is_pair_relation(constraint));
    (std::borrow::Cow::Owned(stripped), true)
}

/// Whether a damage source other than the recipient shares a color with it,
/// both as they are when the damage would be dealt (the source's last-known
/// information when it has left).
fn damage_source_shares_color_with_recipient(
    damage: &DamageEvent,
    recipient: &crate::object::Object,
    ctx: &crate::events::context::EventContext<'_>,
) -> bool {
    if damage.source == recipient.id {
        return false;
    }
    let recipient_colors =
        crate::snapshot::ObjectSnapshot::from_object_with_calculated_characteristics(
            recipient, ctx.game,
        )
        .colors;
    let source_colors = if ctx
        .game
        .damage_source_is_colorless(damage.source, ctx.event_source_snapshot)
    {
        // A colorless source of damage (Ghostly Flame) shares no color.
        crate::color::ColorSet::COLORLESS
    } else if let Some(source) = ctx
        .game
        .object(damage.source)
        .filter(|_| !ctx.game.is_phased_out(damage.source))
    {
        crate::snapshot::ObjectSnapshot::from_object_with_calculated_characteristics(
            source, ctx.game,
        )
        .colors
    } else if let Some(snapshot) = ctx
        .event_source_snapshot
        .filter(|snapshot| snapshot.object_id == damage.source)
    {
        snapshot.colors
    } else {
        return false;
    };
    !recipient_colors.intersection(source_colors).is_empty()
}

#[derive(Debug, Clone, PartialEq)]
pub(crate) struct DamageAmountReplacementMatcher {
    pub(crate) source_filter: ObjectFilter,
    pub(crate) target_player_filter: Option<PlayerFilter>,
    pub(crate) target_object_filter: Option<ObjectFilter>,
    pub(crate) condition: Option<crate::ConditionExpr>,
    pub(crate) combat_only: bool,
    pub(crate) noncombat_only: bool,
    pub(crate) amount_less_than: Option<Value>,
    pub(crate) maximum_damage: Option<u32>,
}

impl DamageAmountReplacementMatcher {
    fn source_matches(
        &self,
        damage: &DamageEvent,
        ctx: &crate::events::context::PreparedEventContext<'_>,
    ) -> bool {
        // "Enchanted creature" is the object currently attached to this
        // replacement's source. An old damage snapshot may remember an Aura
        // which has since moved; it cannot restore that obsolete relationship
        // or substitute a new incarnation of the same creature.
        // Singular source phrases compile to an identity tag, whereas some
        // other attachment filters use the explicit inverse relation. Neither
        // form may fall through to historical or intrinsic attachment evidence.
        let requires_current_attachment = self.source_filter.tagged_constraints.iter().any(|constraint| {
            matches!(constraint.tag.as_str(), "enchanted" | "equipped" | "fortified")
                && constraint.relation == TaggedOpbjectRelation::IsTaggedObject
        }) || self.source_filter.with_attached_object.as_deref().is_some_and(|filter| filter.source);
        if requires_current_attachment {
            let attached = ctx.source.and_then(|source| ctx.game.object(source))
                .filter(|source| source.zone == Zone::Battlefield && !ctx.game.is_phased_out(source.id))
                .and_then(|source| source.attached_to)
                .and_then(|target| target.object_id());
            if attached != Some(damage.source) {
                return false;
            }
        }
        // A resolved source target retains its exact identity rather than
        // requiring that object to remain in its old zone or combat role.
        if self.source_filter == ObjectFilter::specific(damage.source) { return true; }
        // Unblocked is current combat status, not a characteristic whose
        // absent snapshot predicate may be silently ignored.
        if self.source_filter.unblocked && !ctx.game.combat.as_ref().is_some_and(|combat|
            crate::combat_state::is_unblocked(combat, damage.source)) { return false; }
        // An unconstrained source predicate requires no characteristics or LKI.
        // The source of damage may already have left its former zone.
        if self.source_filter == ObjectFilter::default() {
            return true;
        }
        // Use LKI only when the source no longer exists. A still-live source
        // may have changed controller or types since its ability was put on
        // the stack; an older snapshot cannot make it match again.
        // Shared damage-source color hook (Ghostly Flame): a colorless source
        // of damage is matched with no colors.
        if let Some(colorless) = ctx
            .game
            .damage_source_color_snapshot(damage.source, ctx.event_source_snapshot)
        {
            let filter_ctx = if colorless.zone == Zone::Stack {
                ctx.filter_ctx.clone().with_caster(Some(colorless.controller))
            } else {
                ctx.filter_ctx.clone()
            };
            return self.source_filter.matches_snapshot(&colorless, &filter_ctx, ctx.game);
        }
        if let Some(source) = ctx.game.object(damage.source).filter(|_| !ctx.game.is_phased_out(damage.source)) {
            let filter_ctx = if source.zone == Zone::Stack {
                ctx.filter_ctx
                    .clone()
                    .with_caster(ctx.game.current_controller(damage.source))
            } else {
                ctx.filter_ctx.clone()
            };
            return self.source_filter.matches(source, &filter_ctx, ctx.game);
        }
        let Some(snapshot) = ctx.event_source_snapshot
            .filter(|snapshot| snapshot.object_id == damage.source)
        else {
            // Matching must fail even when called without an execution root
            // and therefore without a shared resource-error latch.
            ctx.record_match_failure(
                crate::static_ability_processor::StaticEffectDiscoveryError::UnavailableCharacteristics {
                    object: damage.source,
                },
            );
            return false;
        };
        let filter_ctx = if snapshot.zone == Zone::Stack {
            ctx.filter_ctx.clone().with_caster(Some(snapshot.controller))
        } else {
            ctx.filter_ctx.clone()
        };
        self.source_filter.matches_snapshot(snapshot, &filter_ctx, ctx.game)
    }

    fn target_matches(
        &self,
        damage: &DamageEvent,
        ctx: &crate::events::context::EventContext<'_>,
    ) -> bool {
        match damage.target {
            crate::events::DamageTarget::Player(player) => self
                .target_player_filter
                .as_ref()
                .is_some_and(|filter| filter.matches_player(player, &ctx.filter_ctx)),
            crate::events::DamageTarget::Object(object_id) => {
                let Some(filter) = &self.target_object_filter else {
                    return false;
                };
                let Some(object) = ctx.game.object(object_id) else {
                    return false;
                };
                // "... by another creature if they share a color" (Well-Laid
                // Plans): a relation between this damage's source and its
                // recipient, not a property of either alone.
                let (filter, pair_shares_color) = split_damage_source_color_relation(filter);
                if pair_shares_color
                    && !damage_source_shares_color_with_recipient(damage, object, ctx)
                {
                    return false;
                }
                filter.matches(object, &ctx.filter_ctx, ctx.game)
            }
        }
    }

    fn condition_matches(&self, ctx: &crate::events::context::EventContext<'_>) -> bool {
        let Some(condition) = &self.condition else {
            return true;
        };
        let Some(source) = ctx.source else {
            return false;
        };
        let eval_ctx = crate::condition_eval::ExternalEvaluationContext {
            controller: ctx.controller,
            source,
            defending_player: None,
            attacking_player: None,
            filter_source: Some(source),
            iterated_player: None,
            triggering_event: None,
            trigger_identity: None,
            ability_index: None,
            options: Default::default(),
        };
        crate::condition_eval::evaluate_condition_external(ctx.game, condition, &eval_ctx)
    }

    fn amount_matches(
        &self,
        damage: &DamageEvent,
        ctx: &crate::events::context::EventContext<'_>,
    ) -> bool {
        if self.combat_only && !damage.is_combat {
            return false;
        }
        if self.noncombat_only && damage.is_combat {
            return false;
        }
        if self.maximum_damage.is_some_and(|maximum| damage.amount > maximum) {
            return false;
        }
        let Some(value) = &self.amount_less_than else {
            return true;
        };
        let Some(source) = ctx.source else {
            return false;
        };
        let mut dm = crate::decision::SelectFirstDecisionMaker;
        let mut eval_ctx = crate::effects::ExecutionContext::new(source, ctx.controller, &mut dm);
        if let Some(source_obj) = ctx.game.object(source) {
            eval_ctx.optional_costs_paid = source_obj.optional_costs_paid.clone();
            if !source_obj.cast_tagged_objects.is_empty() {
                eval_ctx = eval_ctx.with_tagged_objects(source_obj.cast_tagged_objects.clone());
            }
        }
        let Ok(floor) = crate::effects::helpers::resolve_value(ctx.game, value, &eval_ctx) else {
            return false;
        };
        (damage.amount as i32) < floor
    }
}

impl ReplacementMatcher for DamageAmountReplacementMatcher {

    fn matches_prepared_event(
        &self,
        event: &dyn crate::events::traits::GameEventType,
        ctx: &crate::events::context::PreparedEventContext<'_>,
    ) -> bool {
        if event.event_kind() != EventKind::Damage {
            return false;
        }

        let Some(damage) = downcast_event::<DamageEvent>(event) else {
            return false;
        };

        self.condition_matches(ctx)
            && self.target_matches(damage, ctx)
            && self.amount_matches(damage, ctx)
            && self.source_matches(damage, ctx)
    }

    fn priority(&self) -> ReplacementPriority {
        ReplacementPriority::Other
    }

    fn display(&self) -> String {
        "If matching damage would be dealt".to_string()
    }
}

impl StaticAbilityKind for ModifyDamageAmountReplacement {
    fn id(&self) -> StaticAbilityId {
        StaticAbilityId::ModifyDamageAmountReplacement
    }

    fn display(&self) -> String {
        // The modeled reading lives in the payload reader; an audit that
        // reaches this display reports the fields instead of the prose.
        let display = ironsmith_core::semantic_audit::retained(
            "ModifyDamageAmountReplacement",
            &self.display,
            self,
        );
        let Some(condition) = &self.condition else {
            return display;
        };
        let condition = super::super::describe_static_condition(condition);
        if let Some(rest) = condition.strip_prefix("as long as ")
            && let Some(if_tail) = display
                .strip_prefix("If ")
                .or_else(|| display.strip_prefix("if "))
        {
            return format!("As long as {rest}, if {if_tail}");
        }
        format!("{display} {condition}")
    }

    fn with_static_condition(
        &self,
        condition: crate::ConditionExpr,
    ) -> Option<super::StaticAbility> {
        Some(super::StaticAbility::new(
            self.clone().with_condition(condition),
        ))
    }

    fn generate_replacement_effect(
        &self,
        source: ObjectId,
        controller: PlayerId,
    ) -> Option<ReplacementEffect> {
        if self.dynamic_delta.is_none() && self.delta == 0 {
            return None;
        }
        Some(ReplacementEffect::with_matcher(
            source,
            controller,
            DamageAmountReplacementMatcher {
                source_filter: self.source_filter.clone(),
                target_player_filter: self.target_player_filter.clone(),
                target_object_filter: self.target_object_filter.clone(),
                condition: self.condition.clone(),
                combat_only: false,
                noncombat_only: self.noncombat_only,
                amount_less_than: None,
                maximum_damage: None,
            },
            ReplacementAction::Modify(match &self.dynamic_delta {
                Some(value) => EventModification::AddDynamic(value.clone()),
                None => EventModification::Add(self.delta),
            }),
        ))
    }
}

impl StaticAbilityKind for MinimumDamageAmountReplacement {
    fn id(&self) -> StaticAbilityId {
        StaticAbilityId::ModifyDamageAmountReplacement
    }

    fn display(&self) -> String {
        ironsmith_core::semantic_audit::retained("MinimumDamageAmountReplacement", &self.display, self)
    }

    fn generate_replacement_effect(
        &self,
        source: ObjectId,
        controller: PlayerId,
    ) -> Option<ReplacementEffect> {
        Some(ReplacementEffect::with_matcher(
            source,
            controller,
            DamageAmountReplacementMatcher {
                source_filter: self.source_filter.clone(),
                target_player_filter: self.target_player_filter.clone(),
                target_object_filter: self.target_object_filter.clone(),
                condition: None,
                combat_only: false,
                noncombat_only: self.noncombat_only,
                amount_less_than: Some(self.floor.clone()),
                maximum_damage: None,
            },
            ReplacementAction::Modify(EventModification::SetToAtLeast(self.floor.clone())),
        ))
    }
}

#[derive(Debug, Clone, PartialEq)]
pub struct DoubleDamageAmountReplacement {
    pub source_filter: ObjectFilter,
    pub target_player_filter: Option<PlayerFilter>,
    pub target_object_filter: Option<ObjectFilter>,
    pub factor: u32,
    pub combat_only: bool,
    pub noncombat_only: bool,
    pub display: String,
    pub condition: Option<crate::ConditionExpr>,
}

impl DoubleDamageAmountReplacement {
    pub fn new(
        source_filter: ObjectFilter,
        target_player_filter: Option<PlayerFilter>,
        target_object_filter: Option<ObjectFilter>,
        factor: u32,
        combat_only: bool,
        display: impl Into<String>,
    ) -> Self {
        Self {
            source_filter,
            target_player_filter,
            target_object_filter,
            factor,
            combat_only,
            noncombat_only: false,
            display: display.into(),
            condition: None,
        }
    }

    pub fn noncombat_only(mut self) -> Self {
        self.noncombat_only = true;
        self
    }
}

impl StaticAbilityKind for DoubleDamageAmountReplacement {
    fn id(&self) -> StaticAbilityId {
        StaticAbilityId::ModifyDamageAmountReplacement
    }

    fn display(&self) -> String {
        ironsmith_core::semantic_audit::retained("DoubleDamageAmountReplacement", &self.display, self)
    }

    fn with_static_condition(
        &self,
        condition: crate::ConditionExpr,
    ) -> Option<super::StaticAbility> {
        let mut ability = self.clone();
        ability.condition = Some(match ability.condition.take() {
            Some(existing) => crate::ConditionExpr::And(Box::new(existing), Box::new(condition)),
            None => condition,
        });
        Some(super::StaticAbility::new(ability))
    }

    fn generate_replacement_effect(
        &self,
        source: ObjectId,
        controller: PlayerId,
    ) -> Option<ReplacementEffect> {
        Some(ReplacementEffect::with_matcher(
            source,
            controller,
            DamageAmountReplacementMatcher {
                source_filter: self.source_filter.clone(),
                target_player_filter: self.target_player_filter.clone(),
                target_object_filter: self.target_object_filter.clone(),
                condition: self.condition.clone(),
                combat_only: self.combat_only,
                noncombat_only: self.noncombat_only,
                amount_less_than: None,
                maximum_damage: None,
            },
            ReplacementAction::Modify(EventModification::Multiply(self.factor)),
        ))
    }
}

/// "If a source would deal damage to you or a permanent you control, prevent
/// half that damage, rounded up." (Gisela, Blade of Goldnight)
#[derive(Debug, Clone, PartialEq)]
pub struct PreventHalfDamageReplacement {
    pub source_filter: ObjectFilter,
    pub target_player_filter: Option<PlayerFilter>,
    pub target_object_filter: Option<ObjectFilter>,
    pub round_up: bool,
    pub display: String,
}

impl PreventHalfDamageReplacement {
    pub fn new(
        source_filter: ObjectFilter,
        target_player_filter: Option<PlayerFilter>,
        target_object_filter: Option<ObjectFilter>,
        round_up: bool,
        display: impl Into<String>,
    ) -> Self {
        Self {
            source_filter,
            target_player_filter,
            target_object_filter,
            round_up,
            display: display.into(),
        }
    }
}

impl StaticAbilityKind for PreventHalfDamageReplacement {
    fn id(&self) -> StaticAbilityId {
        StaticAbilityId::PreventHalfDamageReplacement
    }

    fn display(&self) -> String {
        ironsmith_core::semantic_audit::retained("PreventHalfDamageReplacement", &self.display, self)
    }

    fn generate_replacement_effect(
        &self,
        source: ObjectId,
        controller: PlayerId,
    ) -> Option<ReplacementEffect> {
        Some(ReplacementEffect::with_matcher(
            source,
            controller,
            DamageAmountReplacementMatcher {
                source_filter: self.source_filter.clone(),
                target_player_filter: self.target_player_filter.clone(),
                target_object_filter: self.target_object_filter.clone(),
                condition: None,
                combat_only: false,
                noncombat_only: false,
                amount_less_than: None,
                maximum_damage: None,
            },
            ReplacementAction::PreventHalfDamage {
                round_up: self.round_up,
            },
        ))
    }
}

#[derive(Debug, Clone, PartialEq)]
pub struct DoubleCountersReplacement {
    pub filter: ObjectFilter,
    pub player_filter: Option<PlayerFilter>,
    pub counter_type: Option<CounterType>,
    /// Who must be putting the counters; `None` matches any actor.
    pub actor: Option<PlayerFilter>,
    /// With `player_filter` set, also match permanents matching `filter`.
    pub includes_permanents: bool,
    /// Halve (rounded down) instead of doubling.
    pub halve: bool,
    /// "If an effect would put ..." (Doubling Season): only counters put on
    /// by an effect (or entering with counters) are doubled; cost and
    /// game-rule placements such as +N loyalty costs are not.
    pub effect_only: bool,
    pub display: String,
}

impl DoubleCountersReplacement {
    pub fn new(filter: ObjectFilter, counter_type: Option<CounterType>, display: String) -> Self {
        Self {
            filter,
            player_filter: None,
            counter_type,
            actor: None,
            includes_permanents: false,
            halve: false,
            effect_only: false,
            display,
        }
    }

    pub fn new_for_player(
        player_filter: PlayerFilter,
        counter_type: Option<CounterType>,
        display: String,
    ) -> Self {
        Self {
            filter: ObjectFilter::default(),
            player_filter: Some(player_filter),
            counter_type,
            actor: None,
            includes_permanents: false,
            halve: false,
            effect_only: false,
            display,
        }
    }

    /// "If <actor> would put one or more counters on a permanent or player,
    /// ... twice/half that many ... instead."
    pub fn new_for_actor(actor: PlayerFilter, halve: bool, display: String) -> Self {
        Self {
            filter: ObjectFilter::permanent(),
            player_filter: Some(PlayerFilter::Any),
            counter_type: None,
            actor: Some(actor),
            includes_permanents: true,
            halve,
            effect_only: false,
            display,
        }
    }

    pub fn effect_caused_only(mut self) -> Self {
        self.effect_only = true;
        self
    }
}

#[derive(Debug, Clone)]
struct WouldPutCountersOrEnterWithCountersMatcher {
    ability_source: ObjectId,
    controller: PlayerId,
    filter: ObjectFilter,
    player_filter: Option<PlayerFilter>,
    counter_type: Option<CounterType>,
    actor: Option<PlayerFilter>,
    includes_permanents: bool,
    effect_only: bool,
    /// The cause a placement must come from; entry counters never match.
    cause_filter: Option<crate::events::cause::CauseFilter>,
}

impl WouldPutCountersOrEnterWithCountersMatcher {
    fn actor_matches(&self, actor: Option<PlayerId>, game: &crate::game_state::GameState) -> bool {
        let Some(required) = &self.actor else {
            return true;
        };
        let Some(actor) = actor else {
            return false;
        };
        player_ids_for_filter(game, required.clone(), self.controller).contains(&actor)
    }
}

impl ReplacementMatcher for WouldPutCountersOrEnterWithCountersMatcher {

    fn matches_prepared_event(
        &self,
        event: &dyn crate::events::traits::GameEventType,
        ctx: &crate::events::context::PreparedEventContext,
    ) -> bool {
        match event.event_kind() {
            EventKind::PutCounters => {
                let Some(put_counters) = downcast_event::<crate::events::PutCountersEvent>(event)
                else {
                    return false;
                };
                if self
                    .counter_type
                    .is_some_and(|counter_type| counter_type != put_counters.counter_type)
                {
                    return false;
                }
                if !self.actor_matches(put_counters.cause.source_controller, ctx.game) {
                    return false;
                }
                // Doubling Season ruling: loyalty (and other) counters put on
                // as a cost, by combat damage (wither) or by a game rule
                // aren't put on "by an effect".
                if self.effect_only && !put_counters.cause.cause_type.is_effect_like() {
                    return false;
                }
                if let Some(cause_filter) = &self.cause_filter {
                    use crate::events::cause::CauseFilterRuntimeExt as _;
                    if !cause_filter.matches(&put_counters.cause, ctx.game, self.controller) {
                        return false;
                    }
                }
                match put_counters.target {
                    crate::game_state::Target::Object(object) => {
                        (self.player_filter.is_none() || self.includes_permanents)
                            && ctx.game.object(object).is_some_and(|obj| {
                                self.filter.matches(obj, &ctx.filter_ctx, ctx.game)
                            })
                    }
                    crate::game_state::Target::Player(player) => {
                        self.player_filter.as_ref().is_some_and(|filter| {
                            player_ids_for_filter(ctx.game, filter.clone(), self.controller)
                                .contains(&player)
                        })
                    }
                }
            }
            EventKind::EnterBattlefield => {
                if self.player_filter.is_some() && !self.includes_permanents {
                    return false;
                }
                if self.cause_filter.is_some() {
                    return false;
                }
                let Some(etb) = downcast_event::<EnterBattlefieldEvent>(event) else {
                    return false;
                };
                if etb.object == self.ability_source {
                    return false;
                }
                // CR 122.6: the player who will control the permanent as it
                // enters puts its entry counters, not its pre-entry controller.
                let entering_controller = ctx
                    .prospective_entry_world(etb.object)
                    .and_then(|world| world.controller_of_id(etb.object))
                    .or(etb.controller_override)
                    .or_else(|| ctx.game.controller_of_id(etb.object));
                if self.actor.is_some() && !self.actor_matches(entering_controller, ctx.game) {
                    return false;
                }
                if !etb
                    .enters_with_counters
                    .iter()
                    .any(|(counter_type, count)| {
                        *count > 0
                            && self
                                .counter_type
                                .is_none_or(|required| required == *counter_type)
                    })
                {
                    return false;
                }
                // Match the characteristics and controller the object will have
                // on the battlefield, including other entry replacements.
                crate::events::zones::matchers::WouldEnterBattlefieldMatcher::new(
                    self.filter.clone(),
                )
                .matches_prepared_event(event, ctx)
            }
            _ => false,
        }
    }

    fn display(&self) -> String {
        "When counters would be put on a matching permanent".to_string()
    }
}

impl StaticAbilityKind for DoubleCountersReplacement {
    fn id(&self) -> StaticAbilityId {
        StaticAbilityId::DoubleCountersReplacement
    }

    fn display(&self) -> String {
        ironsmith_core::semantic_audit::retained("DoubleCountersReplacement", &self.display, self)
    }

    fn generate_replacement_effect(
        &self,
        source: ObjectId,
        controller: PlayerId,
    ) -> Option<ReplacementEffect> {
        Some(ReplacementEffect::with_matcher(
            source,
            controller,
            WouldPutCountersOrEnterWithCountersMatcher {
                ability_source: source,
                controller,
                filter: self.filter.clone(),
                player_filter: self.player_filter.clone(),
                counter_type: self.counter_type,
                actor: self.actor.clone(),
                includes_permanents: self.includes_permanents,
                effect_only: self.effect_only,
                cause_filter: None,
            },
            if self.halve {
                ReplacementAction::HalveCounters {
                    counter_type: self.counter_type,
                }
            } else {
                ReplacementAction::DoubleCounters {
                    counter_type: self.counter_type,
                }
            },
        ))
    }
}

/// "If one or more [type] counters would be put on a [filter], that many plus
/// N (or minus N) are put on it instead.
#[derive(Debug, Clone, PartialEq)]
pub struct AddCountersPlacementReplacement {
    pub filter: ObjectFilter,
    pub player_filter: Option<PlayerFilter>,
    pub counter_type: Option<CounterType>,
    pub additional: i64,
    pub actor: Option<PlayerFilter>,
    pub includes_permanents: bool,
    /// The cause the placement must come from, when restricted.
    pub cause: Option<crate::events::cause::CauseFilter>,
    pub display: String,
}

impl AddCountersPlacementReplacement {
    pub fn new(
        filter: ObjectFilter,
        counter_type: Option<CounterType>,
        additional: impl Into<i64>,
        display: String,
    ) -> Self {
        Self {
            filter,
            player_filter: None,
            counter_type,
            additional: additional.into(),
            actor: None,
            includes_permanents: false,
            cause: None,
            display,
        }
    }

    /// Only placements from a matching cause are increased.
    pub fn with_cause(mut self, cause: crate::events::cause::CauseFilter) -> Self {
        self.cause = Some(cause);
        self
    }

    /// Counters a matching player would get instead of counters on permanents.
    pub fn for_player(mut self, player_filter: PlayerFilter) -> Self {
        self.player_filter = Some(player_filter);
        self
    }
}

impl StaticAbilityKind for AddCountersPlacementReplacement {
    fn id(&self) -> StaticAbilityId {
        StaticAbilityId::AddCountersPlacementReplacement
    }

    fn display(&self) -> String {
        if ironsmith_core::semantic_audit::semantic_audit_active() {
            use ironsmith_core::semantic_audit::humanize_variant;
            let mut recipients = Vec::new();
            if self.includes_permanents {
                recipients.push(self.filter.description());
            }
            if let Some(player) = &self.player_filter {
                recipients.push(humanize_variant(player));
            }
            return format!(
                "If {}{} counters would be put on {}{}, that many plus {} are put instead",
                self.actor
                    .as_ref()
                    .map_or(String::new(), |actor| format!("{} would cause ", humanize_variant(actor))),
                self.counter_type
                    .map_or("one or more".to_string(), |counter| counter.description().to_string()),
                recipients.join(" or "),
                self.cause
                    .as_ref()
                    .map_or(String::new(), |cause| format!(" by {}", humanize_variant(cause))),
                self.additional
            );
        }
        self.display.clone()
    }

    fn generate_replacement_effect(
        &self,
        source: ObjectId,
        controller: PlayerId,
    ) -> Option<ReplacementEffect> {
        Some(ReplacementEffect::with_matcher(
            source,
            controller,
            WouldPutCountersOrEnterWithCountersMatcher {
                ability_source: source,
                controller,
                filter: self.filter.clone(),
                player_filter: self.player_filter.clone(),
                counter_type: self.counter_type,
                actor: self.actor.clone(),
                includes_permanents: self.includes_permanents,
                effect_only: false,
                cause_filter: self.cause.clone(),
            },
            ReplacementAction::AddCountersToPlacement {
                counter_type: self.counter_type,
                additional: self.additional,
            },
        ))
    }
}

/// The counter-placement addition ("if you would put ..., put that many
/// plus N ... instead") as a replacement effect a resolving ability
/// registers for a duration. An optional actor limits who places the counters;
/// passive wording leaves that scope unrestricted.
pub(crate) fn counter_placement_addition_replacement(
    source: ObjectId,
    controller: PlayerId,
    filter: ObjectFilter,
    actor: Option<PlayerFilter>,
    counter_type: Option<CounterType>,
    additional: i64,
) -> ReplacementEffect {
    ReplacementEffect::with_matcher(
        source,
        controller,
        WouldPutCountersOrEnterWithCountersMatcher {
            ability_source: source,
            controller,
            filter,
            player_filter: None,
            counter_type,
            actor,
            includes_permanents: false,
            effect_only: false,
            cause_filter: None,
        },
        ReplacementAction::AddCountersToPlacement {
            counter_type,
            additional,
        },
    )
}

/// Replacement for "if you would get one or more [kind] counters ... you
/// can't get additional [kind] counters this turn." The allowance is scoped
/// to the affected player and resets with turn history.
#[derive(Debug, Clone, PartialEq)]
pub struct PlayerCounterPerTurnLimitReplacement {
    pub player_filter: PlayerFilter,
    pub counter_type: CounterType,
    pub maximum: u32,
    pub display: String,
}

impl PlayerCounterPerTurnLimitReplacement {
    pub fn new(
        player_filter: PlayerFilter,
        counter_type: CounterType,
        maximum: u32,
        display: impl Into<String>,
    ) -> Self {
        Self {
            player_filter,
            counter_type,
            maximum,
            display: display.into(),
        }
    }
}

impl StaticAbilityKind for PlayerCounterPerTurnLimitReplacement {
    fn id(&self) -> StaticAbilityId {
        StaticAbilityId::PlayerCounterPerTurnLimitReplacement
    }

    fn display(&self) -> String {
        ironsmith_core::semantic_audit::retained("PlayerCounterPerTurnLimitReplacement", &self.display, self)
    }

    fn generate_replacement_effect(
        &self,
        source: ObjectId,
        controller: PlayerId,
    ) -> Option<ReplacementEffect> {
        Some(ReplacementEffect::with_matcher(
            source,
            controller,
            WouldPutCountersOrEnterWithCountersMatcher {
                ability_source: source,
                controller,
                filter: ObjectFilter::default(),
                player_filter: Some(self.player_filter.clone()),
                counter_type: Some(self.counter_type),
                actor: None,
                includes_permanents: false,
                effect_only: false,
                cause_filter: None,
            },
            ReplacementAction::SetPlayerCountersAndLockForTurn {
                counter_type: self.counter_type,
                amount: self.maximum,
            },
        ))
    }
}

#[derive(Debug, Clone, PartialEq)]
pub struct DoubleTokenCreationReplacement {
    pub controller: PlayerFilter,
    pub display: String,
}

impl DoubleTokenCreationReplacement {
    pub fn new(controller: PlayerFilter, display: impl Into<String>) -> Self {
        Self {
            controller,
            display: display.into(),
        }
    }
}

impl StaticAbilityKind for DoubleTokenCreationReplacement {
    fn id(&self) -> StaticAbilityId {
        StaticAbilityId::DoubleTokenCreationReplacement
    }

    fn display(&self) -> String {
        ironsmith_core::semantic_audit::retained("DoubleTokenCreationReplacement", &self.display, self)
    }

    fn generate_replacement_effect(
        &self,
        source: ObjectId,
        controller: PlayerId,
    ) -> Option<ReplacementEffect> {
        Some(ReplacementEffect::with_matcher(
            source,
            controller,
            crate::events::tokens::matchers::WouldCreateTokensUnderControlMatcher::new(
                self.controller.clone(),
            ),
            ReplacementAction::Double,
        ))
    }
}

/// "If one or more tokens would be created under your control, three times
/// that many of those tokens are created instead." (Ojer Taq)
#[derive(Debug, Clone, PartialEq)]
pub struct MultiplyTokenCreationReplacement {
    pub controller: PlayerFilter,
    pub token_filter: Option<ObjectFilter>,
    pub factor: u32,
    pub display: String,
}

impl MultiplyTokenCreationReplacement {
    pub fn new(
        controller: PlayerFilter,
        token_filter: Option<ObjectFilter>,
        factor: u32,
        display: impl Into<String>,
    ) -> Self {
        Self {
            controller,
            token_filter,
            factor,
            display: display.into(),
        }
    }
}

impl StaticAbilityKind for MultiplyTokenCreationReplacement {
    fn id(&self) -> StaticAbilityId {
        StaticAbilityId::MultiplyTokenCreationReplacement
    }

    fn display(&self) -> String {
        ironsmith_core::semantic_audit::retained("MultiplyTokenCreationReplacement", &self.display, self)
    }

    fn generate_replacement_effect(
        &self,
        source: ObjectId,
        controller: PlayerId,
    ) -> Option<ReplacementEffect> {
        let mut matcher =
            crate::events::tokens::matchers::WouldCreateTokensUnderControlMatcher::new(
                self.controller.clone(),
            );
        if let Some(token_filter) = &self.token_filter {
            matcher = matcher.with_token_filter(token_filter.clone());
        }
        Some(ReplacementEffect::with_matcher(
            source,
            controller,
            matcher,
            ReplacementAction::Modify(EventModification::Multiply(self.factor)),
        ))
    }
}

#[derive(Debug, Clone, PartialEq)]
pub struct AddTokenCreationReplacement {
    pub controller: PlayerFilter,
    pub token_filter: ObjectFilter,
    pub additional_token: ironsmith_core::AdditionalTokenKind,
    pub additional: i32,
    /// One additional token per token being created ("that many").
    pub per_created: bool,
    pub display: String,
}

impl AddTokenCreationReplacement {
    pub fn new(
        controller: PlayerFilter,
        token_filter: ObjectFilter,
        additional_token: ironsmith_core::AdditionalTokenKind,
        additional: i32,
        display: impl Into<String>,
    ) -> Self {
        Self {
            controller,
            token_filter,
            additional_token,
            additional,
            per_created: false,
            display: display.into(),
        }
    }

    pub fn per_created(mut self) -> Self {
        self.per_created = true;
        self
    }
}

impl StaticAbilityKind for AddTokenCreationReplacement {
    fn id(&self) -> StaticAbilityId {
        StaticAbilityId::AddTokenCreationReplacement
    }

    fn display(&self) -> String {
        ironsmith_core::semantic_audit::retained("AddTokenCreationReplacement", &self.display, self)
    }

    fn generate_replacement_effect(
        &self,
        source: ObjectId,
        controller: PlayerId,
    ) -> Option<ReplacementEffect> {
        Some(ReplacementEffect::with_matcher(
            source,
            controller,
            crate::events::tokens::matchers::WouldCreateTokensUnderControlMatcher::new(
                self.controller.clone(),
            )
            .with_token_filter(self.token_filter.clone()),
            if self.per_created {
                ReplacementAction::AddTokensPerCreated {
                    token: self.additional_token,
                }
            } else {
                ReplacementAction::AddTokens {
                    token: self.additional_token,
                    count: self.additional.max(0) as u32,
                }
            },
        ))
    }
}

/// Can be your commander.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub struct CanBeCommander;

impl StaticAbilityKind for CanBeCommander {
    fn id(&self) -> StaticAbilityId {
        StaticAbilityId::CanBeCommander
    }

    fn display(&self) -> String {
        "Can be your commander".to_string()
    }
}

// =============================================================================
// Unified Grant System
// =============================================================================

/// Unified grant ability that grants abilities or alternative casting methods
/// to cards matching a filter in a specific zone.
///
/// This is the generic version that replaces bespoke types like `GrantEscape`
/// and `GrantFlashToNoncreatureSpells`. It provides a uniform way to express
/// "cards matching X in zone Y have Z".
///
/// # Examples
///
/// ```ignore
/// // Valley Floodcaller: "You may cast noncreature spells as though they had flash."
/// StaticAbility::grants(GrantSpec::flash_to_noncreature_spells())
///
/// // Underworld Breach: "Each nonland card in your graveyard has escape."
/// StaticAbility::grants(GrantSpec::escape_to_nonland(3))
/// ```
#[derive(Debug, Clone, PartialEq)]
pub struct Grants {
    pub spec: GrantSpec,
    pub condition: Option<crate::ConditionExpr>,
}

impl Grants {
    /// Create a new Grants ability from a grant specification.
    pub fn new(spec: GrantSpec) -> Self {
        Self {
            spec,
            condition: None,
        }
    }

    pub fn with_condition(mut self, condition: crate::ConditionExpr) -> Self {
        self.condition = Some(match self.condition.take() {
            Some(existing) => crate::ConditionExpr::And(Box::new(existing), Box::new(condition)),
            None => condition,
        });
        self
    }
}

impl StaticAbilityKind for Grants {
    fn id(&self) -> StaticAbilityId {
        StaticAbilityId::Grants
    }

    fn display(&self) -> String {
        let mut text = self.spec.display();
        if let Some(condition) = &self.condition {
            let condition_text = super::super::describe_static_condition(condition);
            if static_condition_is_during_your_turn(condition) {
                return format!("During your turn, {text}");
            }
            // "As long as ... and this card is in your graveyard, it has
            // flashback {2}{G}": the pronoun's antecedent is in the condition.
            if text.starts_with("it has ")
                && let Some(rest) = condition_text.strip_prefix("as long as ")
            {
                return format!("As long as {rest}, {text}");
            }
            text.push(' ');
            text.push_str(&condition_text);
        }
        text
    }

    fn with_static_condition(
        &self,
        condition: crate::ConditionExpr,
    ) -> Option<super::StaticAbility> {
        Some(super::StaticAbility::new(
            self.clone().with_condition(condition),
        ))
    }

    fn is_active(&self, game: &GameState, source: ObjectId) -> bool {
        let Some(condition) = &self.condition else {
            return true;
        };
        let Some(source_obj) = game.object(source) else {
            return false;
        };
        super::super::static_condition_is_active(
            condition,
            game,
            source,
            game.controller_of(source_obj),
        )
    }

    fn grant_spec(&self) -> Option<GrantSpec> {
        Some(self.spec.clone())
    }
}

fn static_condition_is_during_your_turn(condition: &crate::ConditionExpr) -> bool {
    matches!(
        condition,
        crate::ConditionExpr::ActivationTiming(crate::ability::ActivationTiming::DuringYourTurn)
    )
}

/// Level abilities for level-up creatures.
#[derive(Debug, Clone, PartialEq)]
pub struct LevelAbilities {
    pub levels: Vec<LevelAbility>,
}

impl LevelAbilities {
    pub fn new(levels: Vec<LevelAbility>) -> Self {
        Self { levels }
    }
}

impl StaticAbilityKind for LevelAbilities {
    fn id(&self) -> StaticAbilityId {
        StaticAbilityId::LevelAbilities
    }

    fn display(&self) -> String {
        if self.levels.is_empty() {
            return "Level up abilities".to_string();
        }

        let rendered_levels = self
            .levels
            .iter()
            .map(|level| {
                let range = match level.max_level {
                    Some(max) if max == level.min_level => format!("Level {}", level.min_level),
                    Some(max) => format!("Level {}-{}", level.min_level, max),
                    None => format!("Level {}+", level.min_level),
                };
                let mut details = Vec::new();
                if let Some((power, toughness)) = level.power_toughness {
                    details.push(format!("{power}/{toughness}"));
                }
                details.extend(level.abilities.iter().map(|ability| ability.display()));
                if details.is_empty() {
                    range
                } else {
                    format!("{range}: {}", details.join(", "))
                }
            })
            .collect::<Vec<_>>()
            .join("; ");

        format!("Level up abilities ({rendered_levels})")
    }

    fn level_abilities(&self) -> Option<&[LevelAbility]> {
        Some(&self.levels)
    }
}

/// "You have no maximum hand size"
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub struct NoMaximumHandSize;

impl StaticAbilityKind for NoMaximumHandSize {
    // These rule outputs are rebuilt by update_cant_effects, not by the
    // continuous-effect generator.
    fn may_generate_continuous_effects(&self) -> bool { false }

    fn id(&self) -> StaticAbilityId {
        StaticAbilityId::NoMaximumHandSize
    }

    fn display(&self) -> String {
        "You have no maximum hand size".to_string()
    }

    fn apply_restrictions(&self, game: &mut GameState, _source: ObjectId, controller: PlayerId) {
        if let Some(player) = game.players.get_mut_for_derived_update().get_mut(controller.index()) {
            player.max_hand_size = i32::MAX;
        }
    }
}

/// Player scope belongs to the rule source, including its chosen player.
fn hand_size_players(game: &GameState, player: &PlayerFilter, source: ObjectId, controller: PlayerId) -> Vec<PlayerId> {
    let context = game.filter_context_for(controller, Some(source));
    game.players.iter().filter(|p| p.is_in_game() && crate::filter::player_filter_matches_game(player, p.id, game, &context)).map(|p| p.id).collect()
}
fn hand_size_possessive(player: &PlayerFilter) -> String {
    match player {
        PlayerFilter::You => "Your".into(),
        PlayerFilter::Opponent => "Each opponent's".into(),
        PlayerFilter::Any => "Each player's".into(),
        PlayerFilter::ChosenPlayer => "The chosen player's".into(),
        _ => format!("{}'s", capitalize_first(&player.description())),
    }
}
#[derive(Debug, Clone, PartialEq)]
pub struct ScopedNoMaximumHandSize { pub player: PlayerFilter }
impl StaticAbilityKind for ScopedNoMaximumHandSize {
    fn may_generate_continuous_effects(&self) -> bool { false }
    fn id(&self) -> StaticAbilityId { StaticAbilityId::NoMaximumHandSize }
    fn display(&self) -> String {
        match &self.player {
            PlayerFilter::You => "You have no maximum hand size.".into(),
            PlayerFilter::Any => "Players have no maximum hand size.".into(),
            PlayerFilter::Opponent => "Your opponents have no maximum hand size.".into(),
            player => format!("{} has no maximum hand size.", capitalize_first(&player.description())),
        }
    }
    fn apply_restrictions(&self, game: &mut GameState, source: ObjectId, controller: PlayerId) {
        for id in hand_size_players(game, &self.player, source, controller) {
            if let Some(player)=game.players.get_mut_for_derived_update().get_mut(id.index()) { player.max_hand_size=i32::MAX; }
        }
    }
}
#[derive(Debug, Clone, PartialEq)]
pub struct MaximumHandSizeFromSourceCounters { pub player: PlayerFilter, pub counter_type: CounterType }
impl StaticAbilityKind for MaximumHandSizeFromSourceCounters {
    fn may_generate_continuous_effects(&self) -> bool { false }
    fn id(&self) -> StaticAbilityId { StaticAbilityId::SetMaximumHandSize }
    fn display(&self) -> String {
        format!("{} maximum hand size is equal to the number of {} counters on this permanent.", hand_size_possessive(&self.player), self.counter_type.description())
    }
    fn apply_restrictions(&self, game: &mut GameState, source: ObjectId, controller: PlayerId) {
        // Finite source counters are queried in the current rule-source frame.
        let amount=game.counter_count(source,self.counter_type).min(i32::MAX as u32) as i32;
        for id in hand_size_players(game,&self.player,source,controller) {
            if let Some(player)=game.players.get_mut_for_derived_update().get_mut(id.index()) { player.max_hand_size=amount; }
        }
    }
}

/// "Your/Each opponent's maximum hand size is N."
#[derive(Debug, Clone, PartialEq)]
pub struct SetMaximumHandSize {
    pub player: PlayerFilter,
    pub amount: u32,
}

impl SetMaximumHandSize {
    pub fn new(player: PlayerFilter, amount: u32) -> Self {
        Self { player, amount }
    }
}

impl StaticAbilityKind for SetMaximumHandSize {
    // These rule outputs are rebuilt by update_cant_effects, not by the
    // continuous-effect generator.
    fn may_generate_continuous_effects(&self) -> bool { false }

    fn id(&self) -> StaticAbilityId {
        StaticAbilityId::SetMaximumHandSize
    }

    fn display(&self) -> String {
        let amount = number_word_u32(self.amount).unwrap_or_else(|| self.amount.to_string());
        match self.player {
            PlayerFilter::You => format!("Your maximum hand size is {amount}."),
            PlayerFilter::Opponent => {
                format!("Each opponent's maximum hand size is {amount}.")
            }
            PlayerFilter::Any => format!("Each player's maximum hand size is {amount}."),
            _ => format!("{} maximum hand size is {amount}.",hand_size_possessive(&self.player)),
        }
    }

    fn apply_restrictions(&self, game: &mut GameState, source: ObjectId, controller: PlayerId) {
        for player_id in hand_size_players(game, &self.player, source, controller) {
            if let Some(player) = game.players.get_mut_for_derived_update().get_mut(player_id.index()) {
                player.max_hand_size = self.amount.min(i32::MAX as u32) as i32;
            }
        }
    }
}

/// "Your/Each opponent's maximum hand size is reduced by N."
#[derive(Debug, Clone, PartialEq)]
pub struct ReduceMaximumHandSize {
    pub player: PlayerFilter,
    pub amount: u32,
}

impl ReduceMaximumHandSize {
    pub fn new(player: PlayerFilter, amount: u32) -> Self {
        Self { player, amount }
    }
}

impl StaticAbilityKind for ReduceMaximumHandSize {
    // These rule outputs are rebuilt by update_cant_effects, not by the
    // continuous-effect generator.
    fn may_generate_continuous_effects(&self) -> bool { false }

    fn id(&self) -> StaticAbilityId {
        StaticAbilityId::ReduceMaximumHandSize
    }

    fn display(&self) -> String {
        match self.player {
            PlayerFilter::You => {
                format!("Your maximum hand size is reduced by {}.", self.amount)
            }
            PlayerFilter::Opponent => {
                format!(
                    "Each opponent's maximum hand size is reduced by {}.",
                    self.amount
                )
            }
            PlayerFilter::Any => {
                format!(
                    "Each player's maximum hand size is reduced by {}.",
                    self.amount
                )
            }
            _ => format!("Maximum hand size is reduced by {}.", self.amount),
        }
    }

    fn apply_restrictions(&self, game: &mut GameState, source: ObjectId, controller: PlayerId) {
        let affected = hand_size_players(game, &self.player, source, controller);

        let reduction = self.amount.min(i32::MAX as u32) as i32;
        for player_id in affected {
            if let Some(player) = game.players.get_mut_for_derived_update().get_mut(player_id.index()) {
                if player.max_hand_size != i32::MAX { player.max_hand_size = player.max_hand_size.saturating_sub(reduction); }
            }
        }
    }
}

/// "Your/Each opponent's maximum hand size is increased by N."
#[derive(Debug, Clone, PartialEq)]
pub struct IncreaseMaximumHandSize {
    pub player: PlayerFilter,
    pub amount: u32,
}

impl IncreaseMaximumHandSize {
    pub fn new(player: PlayerFilter, amount: u32) -> Self {
        Self { player, amount }
    }
}

impl StaticAbilityKind for IncreaseMaximumHandSize {
    // These rule outputs are rebuilt by update_cant_effects, not by the
    // continuous-effect generator.
    fn may_generate_continuous_effects(&self) -> bool { false }

    fn id(&self) -> StaticAbilityId {
        StaticAbilityId::IncreaseMaximumHandSize
    }

    fn display(&self) -> String {
        let amount = number_word_u32(self.amount).unwrap_or_else(|| self.amount.to_string());
        match self.player {
            PlayerFilter::You => format!("Your maximum hand size is increased by {amount}."),
            PlayerFilter::Opponent => {
                format!("Each opponent's maximum hand size is increased by {amount}.")
            }
            PlayerFilter::Any => {
                format!("Each player's maximum hand size is increased by {amount}.")
            }
            _ => format!("Maximum hand size is increased by {amount}."),
        }
    }

    fn apply_restrictions(&self, game: &mut GameState, source: ObjectId, controller: PlayerId) {
        let affected = hand_size_players(game, &self.player, source, controller);

        let increase = self.amount.min(i32::MAX as u32) as i32;
        for player_id in affected {
            if let Some(player) = game.players.get_mut_for_derived_update().get_mut(player_id.index()) {
                if player.max_hand_size != i32::MAX { player.max_hand_size = player.max_hand_size.saturating_add(increase); }
            }
        }
    }
}

fn player_ids_for_filter(
    game: &GameState,
    player_filter: PlayerFilter,
    controller: PlayerId,
) -> Vec<PlayerId> {
    use crate::game_loop::player_matches_filter_with_combat;

    let combat = game.combat.as_ref();
    game.players
        .iter()
        .filter(|player| {
            player.is_in_game()
                && player_matches_filter_with_combat(
                    player.id,
                    &player_filter,
                    game,
                    controller,
                    combat,
                )
        })
        .map(|player| player.id)
        .collect()
}

fn count_distinct_card_types_in_graveyard(game: &GameState, player_id: PlayerId) -> i32 {
    use crate::types::CardType;

    let mut types: Vec<CardType> = Vec::new();
    let Some(player) = game.player(player_id) else {
        return 0;
    };
    for &card_id in &player.graveyard {
        let Some(obj) = game.object(card_id) else {
            continue;
        };
        // CR 613.1d / 709.4: include current type-changing effects and the
        // combined types of a split card outside the stack and battlefield.
        for card_type in game.current_card_types(card_id)
            .unwrap_or_else(|| obj.zone_card_types().to_vec())
        {
            if !types.contains(&card_type) {
                types.push(card_type);
            }
        }
    }
    types.len() as i32
}

fn count_distinct_mana_values_in_graveyard(game: &GameState, player_id: PlayerId) -> i32 {
    let Some(player) = game.player(player_id) else {
        return 0;
    };

    let mut values: Vec<u32> = Vec::new();
    for &card_id in &player.graveyard {
        let Some(obj) = game.object(card_id) else {
            continue;
        };
        let mana_value = obj.mana_cost.as_ref().map_or(0, |cost| cost.mana_value());
        if !values.contains(&mana_value) {
            values.push(mana_value);
        }
    }
    values.len() as i32
}

pub(crate) fn conditional_spell_keyword_active(
    spec: ConditionalSpellKeywordSpec,
    game: &GameState,
    controller: PlayerId,
) -> bool {
    let count = match spec.metric {
        GraveyardCountMetric::CardTypes => count_distinct_card_types_in_graveyard(game, controller),
        GraveyardCountMetric::ManaValues => {
            count_distinct_mana_values_in_graveyard(game, controller)
        }
    };
    count >= spec.threshold as i32
}

/// "This spell has flash/cascade as long as there are N or more ... in your graveyard."
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct ConditionalSpellKeyword {
    pub spec: ConditionalSpellKeywordSpec,
}

impl ConditionalSpellKeyword {
    pub const fn new(spec: ConditionalSpellKeywordSpec) -> Self {
        Self { spec }
    }
}

impl StaticAbilityKind for ConditionalSpellKeyword {
    fn id(&self) -> StaticAbilityId {
        StaticAbilityId::ConditionalSpellKeyword
    }

    fn display(&self) -> String {
        let keyword = match self.spec.keyword {
            ConditionalSpellKeywordKind::Flash => "flash",
            ConditionalSpellKeywordKind::Cascade => "cascade",
        };
        let metric = match self.spec.metric {
            GraveyardCountMetric::CardTypes => "card types",
            GraveyardCountMetric::ManaValues => "mana values",
        };
        let threshold =
            number_word_u32(self.spec.threshold).unwrap_or_else(|| self.spec.threshold.to_string());
        format!(
            "This spell has {keyword} as long as there are {threshold} or more {metric} among cards in your graveyard."
        )
    }

    fn conditional_spell_keyword_spec(&self) -> Option<ConditionalSpellKeywordSpec> {
        Some(self.spec)
    }
}

/// "Cast this spell only ..." cast-time restriction.
#[derive(Debug, Clone, PartialEq)]
pub struct ThisSpellCastRestriction {
    pub kind: ThisSpellCastRestrictionKind,
    pub display: String,
}

impl ThisSpellCastRestriction {
    pub fn new(kind: ThisSpellCastRestrictionKind, display: impl Into<String>) -> Self {
        Self {
            kind,
            display: display.into(),
        }
    }
}

impl StaticAbilityKind for ThisSpellCastRestriction {
    fn id(&self) -> StaticAbilityId {
        StaticAbilityId::ThisSpellCastRestriction
    }

    fn display(&self) -> String {
        if ironsmith_core::semantic_audit::semantic_audit_active() {
            // The restriction's typed timing and condition, never its prose.
            use ironsmith_core::semantic_audit::{audited_condition, humanize_variant};
            use crate::static_abilities::{ThisSpellCastCondition as C, ThisSpellCastTiming as T};
            let mut parts = Vec::new();
            if let Some(T::NotDuringYourFirstTurns(count)) = &self.kind.timing
                && self.kind.condition.is_none()
            {
                let turns = (1..=*count)
                    .map(|n| ironsmith_core::ordinal_word(n).unwrap_or_else(|| n.to_string()))
                    .collect::<Vec<_>>();
                let turns = match turns.len() {
                    0 | 1 => turns.join(""),
                    2 => turns.join(" or "),
                    n => format!("{}, or {}", turns[..n - 1].join(", "), turns[n - 1]),
                };
                return format!(
                    "You can't cast this spell during your {turns} turn{} of the game",
                    if *count == 1 { "" } else { "s" }
                );
            }
            if let Some(timing) = &self.kind.timing {
                parts.push(match timing {
                    T::DuringDeclareAttackersStep => "during the declare attackers step".to_string(),
                    T::DuringDeclareBlockersStep => "during the declare blockers step".to_string(),
                    T::DuringOpponentsUpkeep => "during an opponent's upkeep".to_string(),
                    T::DuringOpponentsTurn => "during an opponent's turn".to_string(),
                    T::DuringYourTurn => "during your turn".to_string(),
                    T::DuringYourEndStep => "during your end step".to_string(),
                    T::DuringCombat => "during combat".to_string(),
                    T::AfterCombat => "after combat".to_string(),
                    T::BeforeAttackersAreDeclared => "before attackers are declared".to_string(),
                    T::BeforeCombatDamageStep => "before the combat damage step".to_string(),
                    T::DuringCombatOnOpponentsTurn => "during combat on an opponent's turn".to_string(),
                    T::DuringYourDeclareAttackersStep => "during your declare attackers step".to_string(),
                    T::DuringDeclareBlockersStepOnOpponentsTurn => {
                        "during the declare blockers step on an opponent's turn".to_string()
                    }
                    T::DuringOpponentsTurnBeforeAttackersAreDeclared => {
                        "during an opponent's turn, before attackers are declared".to_string()
                    }
                    T::DuringOpponentsTurnAfterUpkeep => {
                        "during an opponent's turn after their upkeep step".to_string()
                    }
                    other => humanize_variant(other),
                });
            }
            match &self.kind.condition {
                Some(C::Condition(condition)) => {
                    parts.push(format!("if {}", audited_condition("ThisSpellCastRestriction", condition)))
                }
                Some(C::YouWereAttackedThisStep) => {
                    parts.push("if you've been attacked this step".to_string())
                }
                Some(C::NoPermanentsNamedOnBattlefield(name)) => {
                    parts.push(format!("if no permanents named {name} are on the battlefield"))
                }
                // "only if you've cast another green spell this turn": the
                // count is taken while this spell is being cast, so every
                // counted spell is another one.
                Some(C::PlayerCastSpellThisTurnOrMore {
                    player,
                    spell_filter,
                    count,
                }) => {
                    let spells = crate::static_abilities::cost_modifiers::describe_spell_filter(spell_filter);
                    let quantity = if *count == 1 {
                        format!("another {}", spells.replacen("spells", "spell", 1))
                    } else {
                        let amount = ironsmith_core::cardinal_word(*count)
                            .unwrap_or_else(|| count.to_string());
                        format!("{amount} or more other {spells}")
                    };
                    let subject = match player {
                        crate::target::PlayerFilter::You => "you've".to_string(),
                        crate::target::PlayerFilter::Opponent => "an opponent has".to_string(),
                        crate::target::PlayerFilter::Any => "a player has".to_string(),
                        other => format!("{} has", other.description()),
                    };
                    let quantity = if matches!(player, crate::target::PlayerFilter::You) {
                        quantity
                    } else {
                        quantity.replacen("another ", "a ", 1).replacen(" other ", " ", 1)
                    };
                    let quantity = match quantity.strip_prefix("a ") {
                        Some(rest) if rest.starts_with(['a', 'e', 'i', 'o', 'u']) => format!("an {rest}"),
                        _ => quantity,
                    };
                    parts.push(format!("if {subject} cast {quantity} this turn"))
                }
                // "only if you control two or more Vampires".
                Some(C::YouControlAtLeast { filter, count }) => {
                    let quantity = if *count == 1 {
                        let described = filter.description();
                        if described.starts_with("a ") || described.starts_with("an ") {
                            described
                        } else if described.starts_with(['a', 'e', 'i', 'o', 'u']) {
                            format!("an {described}")
                        } else {
                            format!("a {described}")
                        }
                    } else {
                        let amount = ironsmith_core::cardinal_word(*count)
                            .unwrap_or_else(|| count.to_string());
                        format!(
                            "{amount} or more {}",
                            crate::static_abilities::pluralized_subject_text(filter)
                        )
                    };
                    parts.push(format!("if you control {quantity}"))
                }
                Some(C::CreatureIsAttackingYou) => {
                    parts.push("if a creature is attacking you".to_string())
                }
                Some(C::CreatureDiedThisTurn) => {
                    parts.push("if a creature died this turn".to_string())
                }
                Some(C::YouControlFewerCreaturesThanEachOpponent) => {
                    parts.push("if you control fewer creatures than each opponent".to_string())
                }
                Some(condition) => parts.push(format!("if {}", humanize_variant(condition))),
                None => {}
            }
            return format!("Cast this spell only {}", parts.join(" and only "));
        }
        self.display.clone()
    }

    fn this_spell_cast_restriction_kind(&self) -> Option<ThisSpellCastRestrictionKind> {
        Some(self.kind.clone())
    }
}

/// "X can't be greater than ..." spell-casting X restriction.
#[derive(Debug, Clone, PartialEq)]
pub struct ThisSpellXMaximum {
    pub maximum: crate::effect::Value,
    pub display: String,
}

impl ThisSpellXMaximum {
    pub fn new(maximum: crate::effect::Value, display: impl Into<String>) -> Self {
        Self {
            maximum,
            display: display.into(),
        }
    }
}

impl StaticAbilityKind for ThisSpellXMaximum {
    fn id(&self) -> StaticAbilityId {
        StaticAbilityId::ThisSpellXMaximum
    }

    fn display(&self) -> String {
        ironsmith_core::semantic_audit::retained("ThisSpellXMaximum", &self.display, self)
    }

    fn this_spell_x_maximum_value(&self) -> Option<crate::effect::Value> {
        Some(self.maximum.clone())
    }
}

/// "X can't be less than ..." spell-casting X restriction.
#[derive(Debug, Clone, PartialEq)]
pub struct ThisSpellXMinimum {
    pub minimum: crate::effect::Value,
    pub display: String,
}

impl ThisSpellXMinimum {
    pub fn new(minimum: crate::effect::Value, display: impl Into<String>) -> Self {
        Self {
            minimum,
            display: display.into(),
        }
    }
}

impl StaticAbilityKind for ThisSpellXMinimum {
    fn id(&self) -> StaticAbilityId {
        StaticAbilityId::ThisSpellXMinimum
    }

    fn display(&self) -> String {
        ironsmith_core::semantic_audit::retained("ThisSpellXMinimum", &self.display, self)
    }

    fn this_spell_x_minimum_value(&self) -> Option<crate::effect::Value> {
        Some(self.minimum.clone())
    }
}

/// "Each opponent's maximum hand size is equal to seven minus the number of card types in your graveyard."
#[derive(Debug, Clone, PartialEq)]
pub struct MaximumHandSizeSevenMinusYourGraveyardCardTypes {
    pub player: PlayerFilter,
    pub minimum_types: u32,
}

impl MaximumHandSizeSevenMinusYourGraveyardCardTypes {
    pub const fn new(player: PlayerFilter, minimum_types: u32) -> Self {
        Self {
            player,
            minimum_types,
        }
    }
}

impl StaticAbilityKind for MaximumHandSizeSevenMinusYourGraveyardCardTypes {
    fn may_generate_continuous_effects(&self) -> bool { false }

    fn id(&self) -> StaticAbilityId {
        StaticAbilityId::MaximumHandSizeSevenMinusYourGraveyardCardTypes
    }

    fn display(&self) -> String {
        let who = match self.player {
            PlayerFilter::You => "Your",
            PlayerFilter::Opponent => "Each opponent's",
            PlayerFilter::Any => "Each player's",
            _ => "Affected players'",
        };
        format!(
            "As long as there are {} or more card types among cards in your graveyard, {who} maximum hand size is equal to seven minus the number of those card types.",
            self.minimum_types
        )
    }

    fn apply_restrictions(&self, game: &mut GameState, _source: ObjectId, controller: PlayerId) {
        let card_types = count_distinct_card_types_in_graveyard(game, controller);
        if card_types < self.minimum_types as i32 {
            return;
        }

        let max_hand_size = (7 - card_types).max(0);
        let affected = player_ids_for_filter(game, self.player.clone(), controller);
        for player_id in affected {
            if let Some(player) = game.players.get_mut_for_derived_update().get_mut(player_id.index()) {
                player.max_hand_size = max_hand_size;
            }
        }
    }
}

/// Replacement for effect-caused discards moving to the top of the library.
///
/// "If an effect causes you to discard a card, you may put it on top of
/// your library instead of into your graveyard."
///
/// Key rules:
/// - Only applies to discards from effects (not costs)
/// - Uses the composable EventCause system to filter on cause type
/// - Offers an interactive choice between graveyard and library
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub struct EffectDiscardToLibraryReplacement;

impl StaticAbilityKind for EffectDiscardToLibraryReplacement {
    fn id(&self) -> StaticAbilityId {
        StaticAbilityId::EffectDiscardToLibraryReplacement
    }

    fn display(&self) -> String {
        "If an effect causes you to discard a card, you may put it on top of your library instead"
            .to_string()
    }

    fn generate_replacement_effect(
        &self,
        source: ObjectId,
        controller: PlayerId,
    ) -> Option<ReplacementEffect> {
        Some(ReplacementEffect::with_matcher(
            source,
            controller,
            // Use the composable matcher that filters on cause type
            WouldDiscardMatcher::you_from_effect().with_destination(Zone::Graveyard),
            ReplacementAction::InteractiveChooseDestination {
                destinations: vec![Zone::Graveyard, Zone::Library],
                description: "Put discarded card on top of library instead of graveyard?"
                    .to_string(),
            },
        ))
    }
}

/// Dredge N — while this card is in its owner's graveyard, its owner may
/// replace one draw by milling exactly N cards and returning this card to hand.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct DredgeAbility {
    pub amount: u32,
}

impl DredgeAbility {
    pub fn new(amount: u32) -> Self {
        Self { amount }
    }
}

#[derive(Debug, Clone, Copy)]
struct DredgeDrawMatcher {
    amount: u32,
}

impl ReplacementMatcher for DredgeDrawMatcher {

    fn matches_prepared_event(
        &self,
        event: &dyn crate::events::traits::GameEventType,
        ctx: &crate::events::context::PreparedEventContext,
    ) -> bool {
        if event.event_kind() != EventKind::Draw {
            return false;
        }
        let Some(draw) = downcast_event::<crate::events::cards::DrawEvent>(event) else {
            return false;
        };
        let Some(source) = ctx.source.and_then(|source| ctx.game.object(source)) else {
            return false;
        };

        draw.count == 1
            && source.zone == Zone::Graveyard
            && source.owner == draw.player
            && ctx
                .game
                .player(draw.player)
                .is_some_and(|player| player.library.len() >= self.amount as usize)
    }

    fn display(&self) -> String {
        format!("Dredge {}", self.amount)
    }
}

impl StaticAbilityKind for DredgeAbility {
    fn id(&self) -> StaticAbilityId {
        StaticAbilityId::Dredge
    }

    fn display(&self) -> String {
        format!("Dredge {}", self.amount)
    }

    fn generate_replacement_effect(
        &self,
        source: ObjectId,
        controller: PlayerId,
    ) -> Option<ReplacementEffect> {
        Some(
            ReplacementEffect::with_matcher(
                source,
                controller,
                DredgeDrawMatcher {
                    amount: self.amount,
                },
                ReplacementAction::Instead(vec![
                    Effect::mill(self.amount),
                    Effect::move_to_zone(ChooseSpec::Source, Zone::Hand, false),
                ]),
            )
            .optional(),
        )
    }
}

/// Replacement for opponent-controlled effects causing this card to be discarded.
///
/// "If a spell or ability an opponent controls causes you to discard this card,
/// put it onto the battlefield instead of putting it into your graveyard."
#[derive(Debug, Clone, PartialEq, Eq, Default)]
pub struct OpponentEffectDiscardThisToBattlefieldReplacement {
    /// "... put it onto the battlefield with two +1/+1 counters on it
    /// instead ..." (Dodecapod): counters the card enters with.
    pub entry_counters: Vec<(crate::object::CounterType, u32)>,
}

impl StaticAbilityKind for OpponentEffectDiscardThisToBattlefieldReplacement {
    fn id(&self) -> StaticAbilityId {
        StaticAbilityId::OpponentEffectDiscardThisToBattlefieldReplacement
    }

    fn display(&self) -> String {
        let counters = self
            .entry_counters
            .iter()
            .map(|(counter_type, count)| {
                let noun = if *count == 1 { "counter" } else { "counters" };
                format!("{count} {} {noun}", counter_type.description())
            })
            .collect::<Vec<_>>();
        let with = if counters.is_empty() {
            String::new()
        } else {
            format!(" with {} on it", counters.join(" and "))
        };
        format!(
            "If a spell or ability an opponent controls causes you to discard this card, put it onto \
             the battlefield{with} instead of putting it into your graveyard"
        )
    }

    fn generate_replacement_effect(
        &self,
        source: ObjectId,
        controller: PlayerId,
    ) -> Option<ReplacementEffect> {
        let action = if self.entry_counters.is_empty() {
            ReplacementAction::ChangeDestination(Zone::Battlefield)
        } else {
            ReplacementAction::MoveToZoneWithCounters {
                zone: Zone::Battlefield,
                counters: self.entry_counters.clone(),
            }
        };
        Some(ReplacementEffect::with_matcher(
            source,
            controller,
            WouldDiscardMatcher::source_from_opponent_effect(),
            action,
        ))
    }
}

/// "If a spell or ability an opponent controls causes you to discard a card,
/// you may reveal that card and put it on top of your library instead of
/// putting it anywhere else." (Nephalia Academy, CR 614.6)
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub struct OpponentEffectDiscardToLibraryReplacement;

impl StaticAbilityKind for OpponentEffectDiscardToLibraryReplacement {
    fn id(&self) -> StaticAbilityId {
        StaticAbilityId::OpponentEffectDiscardToLibraryReplacement
    }

    fn display(&self) -> String {
        "If a spell or ability an opponent controls causes you to discard a card, you may reveal \
         that card and put it on top of your library instead of putting it anywhere else"
            .to_string()
    }

    fn generate_replacement_effect(
        &self,
        source: ObjectId,
        controller: PlayerId,
    ) -> Option<ReplacementEffect> {
        Some(ReplacementEffect::with_matcher(
            source,
            controller,
            WouldDiscardMatcher::you_from_opponent_effect().with_destination(Zone::Graveyard),
            ReplacementAction::InteractiveChooseDestination {
                destinations: vec![Zone::Graveyard, Zone::Library],
                description: "Reveal the discarded card and put it on top of your library instead?"
                    .to_string(),
            },
        ))
    }
}

/// "If you would draw a card, exile the top card of your library face down instead."
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub struct DrawReplacementExileTopFaceDown;

impl StaticAbilityKind for DrawReplacementExileTopFaceDown {
    fn id(&self) -> StaticAbilityId {
        StaticAbilityId::DrawReplacementExileTopFaceDown
    }

    fn display(&self) -> String {
        "If you would draw a card, exile the top card of your library face down instead."
            .to_string()
    }

    fn generate_replacement_effect(
        &self,
        source: ObjectId,
        controller: PlayerId,
    ) -> Option<ReplacementEffect> {
        const TOP_CARD_TAG: &str = "draw_replacement_top_card";

        Some(ReplacementEffect::with_matcher(
            source,
            controller,
            WouldDrawCardMatcher::you(),
            ReplacementAction::Instead(vec![
                Effect::new(
                    crate::effects::ChooseObjectsEffect::new(
                        ObjectFilter::default()
                            .in_zone(Zone::Library)
                            .owned_by(PlayerFilter::You),
                        1,
                        PlayerFilter::You,
                        TOP_CARD_TAG,
                    )
                    .top_only(),
                ),
                Effect::new(
                    crate::effects::ExileEffect::with_spec(ChooseSpec::tagged(TOP_CARD_TAG))
                        .with_face_down(true),
                ),
            ]),
        ))
    }
}

/// "If you would draw a card, draw two cards instead."
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub struct DrawReplacementDouble;

impl StaticAbilityKind for DrawReplacementDouble {
    fn id(&self) -> StaticAbilityId {
        StaticAbilityId::DrawReplacementDouble
    }

    fn display(&self) -> String {
        "If you would draw a card, draw two cards instead.".to_string()
    }

    fn generate_replacement_effect(
        &self,
        source: ObjectId,
        controller: PlayerId,
    ) -> Option<ReplacementEffect> {
        Some(ReplacementEffect::with_matcher(
            source,
            controller,
            WouldDrawCardMatcher::you(),
            ReplacementAction::Instead(vec![Effect::new(crate::effects::DrawCardsEffect::you(2))]),
        ))
    }
}

/// "If you would draw a card while your library has no cards in it, skip that draw instead."
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub struct DrawReplacementSkipEmptyLibrary;

impl StaticAbilityKind for DrawReplacementSkipEmptyLibrary {
    fn id(&self) -> StaticAbilityId {
        StaticAbilityId::DrawReplacementSkipEmptyLibrary
    }

    fn display(&self) -> String {
        "If you would draw a card while your library has no cards in it, skip that draw instead."
            .to_string()
    }

    fn generate_replacement_effect(
        &self,
        source: ObjectId,
        controller: PlayerId,
    ) -> Option<ReplacementEffect> {
        Some(ReplacementEffect::with_matcher(
            source,
            controller,
            WouldDrawCardWhileLibraryEmptyMatcher::you(),
            ReplacementAction::Skip,
        ))
    }
}

/// "If you would draw a card while [condition], [effects] instead."
#[derive(Debug, Clone, PartialEq)]
pub struct ConditionalDrawReplacement {
    pub condition: Condition,
    pub replacement_effects: Vec<Effect>,
    pub optional: bool,
    pub display: String,
    /// Never replace the first card drawn during a draw step (CR 504.1).
    pub except_first_of_draw_step: bool,
}

impl ConditionalDrawReplacement {
    pub fn new(
        condition: Condition,
        replacement_effects: Vec<Effect>,
        optional: bool,
        display: impl Into<String>,
    ) -> Self {
        Self {
            condition,
            replacement_effects,
            optional,
            display: display.into(),
            except_first_of_draw_step: false,
        }
    }
}

impl StaticAbilityKind for ConditionalDrawReplacement {
    fn id(&self) -> StaticAbilityId {
        StaticAbilityId::ConditionalDrawReplacement
    }

    fn display(&self) -> String {
        ironsmith_core::semantic_audit::retained("ConditionalDrawReplacement", &self.display, self)
    }

    fn with_static_condition(&self, condition: crate::ConditionExpr) -> Option<StaticAbility> {
        let mut combined = self.clone();
        combined.condition = Condition::And(Box::new(condition), Box::new(combined.condition));
        // Some authored optional draw replacements already carry the complete
        // leading static condition in their typed display (for example
        // "As long as this enchantment has six or more ...").  Re-wrapping
        // those must strengthen executable matching without appending a
        // second debug-style condition sentence.
        if !combined
            .display
            .trim_start()
            .to_ascii_lowercase()
            .starts_with("as long as ")
        {
            combined.display = format!(
                "{} {}",
                combined.display,
                super::super::describe_static_condition(&combined.condition)
            );
        }
        Some(StaticAbility::new(combined))
    }

    fn generate_replacement_effect(
        &self,
        source: ObjectId,
        controller: PlayerId,
    ) -> Option<ReplacementEffect> {
        let replacement = ReplacementEffect::with_matcher(
            source,
            controller,
            ConditionalWouldDrawCardMatcher {
                condition: self.condition.clone(),
                display: self.display.clone(),
                except_first_of_draw_step: self.except_first_of_draw_step,
            },
            ReplacementAction::Instead(self.replacement_effects.clone()),
        );
        Some(if self.optional {
            replacement.optional()
        } else {
            replacement
        })
    }
}

/// "If you would lose the game, instead [effects]."
#[derive(Debug, Clone, PartialEq)]
pub struct LoseGameReplacement {
    pub replacement_effects: Vec<Effect>,
    pub optional: bool,
    pub display: String,
}

impl LoseGameReplacement {
    pub fn new(
        replacement_effects: Vec<Effect>,
        optional: bool,
        display: impl Into<String>,
    ) -> Self {
        Self {
            replacement_effects,
            optional,
            display: display.into(),
        }
    }
}

impl StaticAbilityKind for LoseGameReplacement {
    fn id(&self) -> StaticAbilityId {
        StaticAbilityId::LoseGameReplacement
    }

    fn display(&self) -> String {
        ironsmith_core::semantic_audit::retained("LoseGameReplacement", &self.display, self)
    }

    fn generate_replacement_effect(
        &self,
        source: ObjectId,
        controller: PlayerId,
    ) -> Option<ReplacementEffect> {
        let replacement = ReplacementEffect::with_matcher(
            source,
            controller,
            crate::events::other::WouldLoseGameMatcher,
            ReplacementAction::Instead(self.replacement_effects.clone()),
        );
        Some(if self.optional {
            replacement.optional()
        } else {
            replacement
        })
    }
}

#[derive(Debug, Clone, PartialEq)]
struct ConditionalWouldDrawCardMatcher {
    condition: Condition,
    display: String,
    except_first_of_draw_step: bool,
}

impl ReplacementMatcher for ConditionalWouldDrawCardMatcher {

    fn matches_prepared_event(&self, event: &dyn GameEventType, ctx: &crate::events::context::PreparedEventContext) -> bool {
        if !WouldDrawCardMatcher::you().matches_prepared_event(event, ctx) {
            return false;
        }
        if self.except_first_of_draw_step
            && crate::events::downcast_event::<crate::events::DrawEvent>(event)
                .is_some_and(|draw| draw.first_of_draw_step)
        {
            return false;
        }

        let Some(source) = ctx.source else {
            return false;
        };
        let eval_ctx = crate::condition_eval::ExternalEvaluationContext {
            controller: ctx.controller,
            source,
            defending_player: None,
            attacking_player: None,
            filter_source: None,
            iterated_player: None,
            triggering_event: None,
            trigger_identity: None,
            ability_index: None,
            options: Default::default(),
        };

        crate::condition_eval::evaluate_condition_external(ctx.game, &self.condition, &eval_ctx)
    }

    fn display(&self) -> String {
        ironsmith_core::semantic_audit::retained("LoseGameReplacement", &self.display, self)
    }
}

/// "If you would draw one or more cards, you draw that many cards plus one
/// instead." (Quantum Riddler). Modify the enclosing draw instruction before
/// its individual draws; a leading "as long as" condition gates it.
#[derive(Debug, Clone, PartialEq)]
pub struct DrawExtraCardsReplacement {
    pub condition: Option<Condition>,
    pub extra: u32,
    /// Skip the first card drawn in each of the player's own draw steps.
    pub except_first_of_draw_step: bool,
    /// Apply once per draw instruction rather than to every card drawn.
    pub per_instruction: bool,
    pub display: String,
}

impl DrawExtraCardsReplacement {
    pub fn new(extra: u32, display: impl Into<String>) -> Self {
        Self {
            condition: None,
            extra,
            except_first_of_draw_step: false,
            per_instruction: true,
            display: display.into(),
        }
    }

    pub fn except_first_of_draw_step(mut self) -> Self {
        self.except_first_of_draw_step = true;
        self
    }

    pub fn per_card(mut self) -> Self {
        self.per_instruction = false;
        self
    }
}

impl StaticAbilityKind for DrawExtraCardsReplacement {
    fn may_generate_continuous_effects(&self) -> bool {
        false
    }

    fn id(&self) -> StaticAbilityId {
        StaticAbilityId::DrawExtraCardsReplacement
    }

    fn display(&self) -> String {
        ironsmith_core::semantic_audit::retained("DrawExtraCardsReplacement", &self.display, self)
    }

    fn with_static_condition(&self, condition: crate::ConditionExpr) -> Option<StaticAbility> {
        let mut combined = self.clone();
        combined.condition = Some(match combined.condition.take() {
            Some(existing) => Condition::And(Box::new(condition), Box::new(existing)),
            None => condition,
        });
        Some(StaticAbility::new(combined))
    }

    fn generate_replacement_effect(
        &self,
        source: ObjectId,
        controller: PlayerId,
    ) -> Option<ReplacementEffect> {
        Some(ReplacementEffect::with_matcher(
            source,
            controller,
            WouldDrawInstructionMatcher {
                condition: self.condition.clone(),
                except_first_of_draw_step: self.except_first_of_draw_step,
                per_instruction: self.per_instruction,
                display: self.display.clone(),
            },
            // CR 121.2 / 616.2: "draw N cards instead" replaces the draw with
            // N separate draws. Each is a new event that every other
            // replacement or restriction can apply to (Dredge, Jace, Narset,
            // a second doubler), while CR 614.5 keeps this one from
            // reapplying to them (the Replaced arm suppresses it).
            if self.per_instruction {
                // CR 121.2a: change the enclosing instruction before any
                // individual draw can be replaced.
                ReplacementAction::Modify(crate::replacement::EventModification::Add(
                    i32::try_from(self.extra).unwrap_or(i32::MAX),
                ))
            } else {
                ReplacementAction::Instead(vec![crate::effect::Effect::draw(
                    self.extra.saturating_add(1),
                )])
            },
        ))
    }
}

/// The first card of one of your draw instructions, optionally gated by a
/// static condition.
#[derive(Debug, Clone)]
struct WouldDrawInstructionMatcher {
    condition: Option<Condition>,
    except_first_of_draw_step: bool,
    per_instruction: bool,
    display: String,
}

impl ReplacementMatcher for WouldDrawInstructionMatcher {

    fn may_match_event_kind(&self, kind: EventKind) -> bool {
        kind == if self.per_instruction { EventKind::KeywordAction } else { EventKind::Draw }
    }

    fn matches_prepared_event(&self, event: &dyn GameEventType, ctx: &crate::events::context::PreparedEventContext) -> bool {
        if self.per_instruction {
            let Some(instruction) = crate::events::downcast_event::<crate::events::KeywordActionEvent>(event) else {
                return false;
            };
            if instruction.action != crate::events::KeywordActionKind::DrawCards
                || instruction.player != ctx.controller || instruction.amount == 0
            {
                return false;
            }
            let (during_draw_step, drawn_this_step) = ctx.game.current_draw_step_context_for_player(instruction.player);
            if self.except_first_of_draw_step && during_draw_step && drawn_this_step == 0 {
                return false;
            }
        } else {
            if !WouldDrawCardMatcher::you().matches_prepared_event(event, ctx) {
                return false;
            }
            let Some(draw) = crate::events::downcast_event::<crate::events::DrawEvent>(event) else {
                return false;
            };
            if self.except_first_of_draw_step && draw.first_of_draw_step {
                return false;
            }
        }
        let Some(condition) = &self.condition else {
            return true;
        };
        let Some(source) = ctx.source else {
            return false;
        };
        let eval_ctx = crate::condition_eval::ExternalEvaluationContext {
            controller: ctx.controller,
            source,
            defending_player: None,
            attacking_player: None,
            filter_source: None,
            iterated_player: None,
            triggering_event: None,
            trigger_identity: None,
            ability_index: None,
            options: Default::default(),
        };
        crate::condition_eval::evaluate_condition_external(ctx.game, condition, &eval_ctx)
    }

    fn display(&self) -> String {
        ironsmith_core::semantic_audit::retained("DrawExtraCardsReplacement", &self.display, self)
    }
}

/// "If you would create a Clue, Food, or Treasure token, instead create one of
/// each." (Academy Manufactor)
#[derive(Debug, Clone, PartialEq)]
pub struct CreateOneOfEachTokenReplacement {
    pub kinds: Vec<ironsmith_core::AdditionalTokenKind>,
    pub display: String,
}

impl CreateOneOfEachTokenReplacement {
    pub fn new(
        kinds: Vec<ironsmith_core::AdditionalTokenKind>,
        display: impl Into<String>,
    ) -> Self {
        Self {
            kinds,
            display: display.into(),
        }
    }
}

impl StaticAbilityKind for CreateOneOfEachTokenReplacement {
    fn id(&self) -> StaticAbilityId {
        StaticAbilityId::CreateOneOfEachTokenReplacement
    }

    fn display(&self) -> String {
        ironsmith_core::semantic_audit::retained("CreateOneOfEachTokenReplacement", &self.display, self)
    }

    fn generate_replacement_effect(
        &self,
        source: ObjectId,
        controller: PlayerId,
    ) -> Option<ReplacementEffect> {
        let mut token_filter = ObjectFilter::default();
        token_filter.any_of = self
            .kinds
            .iter()
            .map(|kind| {
                let mut branch = ObjectFilter::default();
                branch.subtypes.push(match kind {
                    ironsmith_core::AdditionalTokenKind::Treasure => {
                        crate::types::Subtype::Treasure
                    }
                    ironsmith_core::AdditionalTokenKind::Food => crate::types::Subtype::Food,
                    ironsmith_core::AdditionalTokenKind::Squirrel => {
                        crate::types::Subtype::Squirrel
                    }
                    ironsmith_core::AdditionalTokenKind::Clue => crate::types::Subtype::Clue,
                });
                branch
            })
            .collect();
        Some(ReplacementEffect::with_matcher(
            source,
            controller,
            crate::events::tokens::matchers::WouldCreateTokensUnderControlMatcher::new(
                PlayerFilter::You,
            )
            .with_token_filter(token_filter),
            ReplacementAction::AddTokensOfOtherKinds {
                kinds: self.kinds.clone(),
            },
        ))
    }
}

/// "If an opponent would draw a card except the first one they draw in each
/// of their draw steps, instead that player skips that draw and you draw a
/// card." (Notion Thief)
#[derive(Debug, Clone, PartialEq)]
pub struct RedirectDrawReplacement {
    pub drawer: PlayerFilter,
    pub except_first_of_draw_step: bool,
    pub display: String,
}

impl RedirectDrawReplacement {
    pub fn new(
        drawer: PlayerFilter,
        except_first_of_draw_step: bool,
        display: impl Into<String>,
    ) -> Self {
        Self {
            drawer,
            except_first_of_draw_step,
            display: display.into(),
        }
    }
}

/// "If you would draw a card, instead <effects>." (Underrealm Lich), optionally
/// sparing the first draw of each draw step (Hullbreacher).
#[derive(Debug, Clone, PartialEq)]
pub struct DrawReplacementWithEffects {
    pub drawer: PlayerFilter,
    pub except_first_of_draw_step: bool,
    pub replacement_effects: Vec<Effect>,
    pub display: String,
    /// "If a cycling ability of <filter> would cause you to draw a card":
    /// only draws a resolving cycling ability of a matching source proposes.
    pub cycling_source: Option<ObjectFilter>,
}

impl DrawReplacementWithEffects {
    pub fn new(
        drawer: PlayerFilter,
        except_first_of_draw_step: bool,
        replacement_effects: Vec<Effect>,
        display: impl Into<String>,
    ) -> Self {
        Self {
            drawer,
            except_first_of_draw_step,
            replacement_effects,
            display: display.into(),
            cycling_source: None,
        }
    }
}

impl StaticAbilityKind for DrawReplacementWithEffects {
    fn id(&self) -> StaticAbilityId {
        StaticAbilityId::DrawReplacementWithEffects
    }

    fn display(&self) -> String {
        ironsmith_core::semantic_audit::retained("DrawReplacementWithEffects", &self.display, self)
    }

    fn generate_replacement_effect(
        &self,
        source: ObjectId,
        controller: PlayerId,
    ) -> Option<ReplacementEffect> {
        Some(ReplacementEffect::with_matcher(
            source,
            controller,
            WouldDrawByPlayerMatcher {
                drawer: self.drawer.clone(),
                except_first_of_draw_step: self.except_first_of_draw_step,
                display: self.display.clone(),
                cycling_source: self.cycling_source.clone(),
            },
            ReplacementAction::Instead(self.replacement_effects.clone()),
        ))
    }
}

impl StaticAbilityKind for RedirectDrawReplacement {
    fn id(&self) -> StaticAbilityId {
        StaticAbilityId::RedirectDrawReplacement
    }

    fn display(&self) -> String {
        ironsmith_core::semantic_audit::retained("RedirectDrawReplacement", &self.display, self)
    }

    fn generate_replacement_effect(
        &self,
        source: ObjectId,
        controller: PlayerId,
    ) -> Option<ReplacementEffect> {
        Some(ReplacementEffect::with_matcher(
            source,
            controller,
            WouldDrawByPlayerMatcher {
                drawer: self.drawer.clone(),
                except_first_of_draw_step: self.except_first_of_draw_step,
                display: self.display.clone(),
                cycling_source: None,
            },
            ReplacementAction::RedirectDrawToController,
        ))
    }
}

#[derive(Debug, Clone, PartialEq)]
struct WouldDrawByPlayerMatcher {
    drawer: PlayerFilter,
    except_first_of_draw_step: bool,
    display: String,
    cycling_source: Option<ObjectFilter>,
}

impl ReplacementMatcher for WouldDrawByPlayerMatcher {

    fn matches_prepared_event(&self, event: &dyn GameEventType, ctx: &crate::events::context::PreparedEventContext) -> bool {
        if !WouldDrawCardMatcher::new(self.drawer.clone()).matches_prepared_event(event, ctx) {
            return false;
        }
        let Some(draw) = crate::events::downcast_event::<crate::events::DrawEvent>(event) else {
            return false;
        };
        if self.except_first_of_draw_step && draw.first_of_draw_step {
            return false;
        }
        let Some(cycling_source) = self.cycling_source.as_ref() else {
            return true;
        };
        // "If a cycling ability of another nonland card would cause you to
        // draw a card": the draw must come from a resolving cycling ability
        // whose source (as last known) matches.
        let Some(cause) = draw.cause_ability.as_ref() else {
            return false;
        };
        if cause.keyword != Some(ironsmith_core::ActivatedAbilityKeyword::Cycling) {
            return false;
        }
        match cause.source_snapshot.as_ref() {
            Some(snapshot) => cycling_source.matches_snapshot(snapshot, &ctx.filter_ctx, ctx.game),
            None => ctx
                .game
                .object(cause.source)
                .is_some_and(|object| cycling_source.matches(object, &ctx.filter_ctx, ctx.game)),
        }
    }

    fn display(&self) -> String {
        ironsmith_core::semantic_audit::retained("RedirectDrawReplacement", &self.display, self)
    }
}

/// "If you would draw a card, exile the top N cards of your library instead. You may play those
/// cards this turn."
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct DrawReplacementExileTopAndPlay {
    pub count: u32,
}

impl DrawReplacementExileTopAndPlay {
    pub fn new(count: u32) -> Self {
        Self { count }
    }
}

impl StaticAbilityKind for DrawReplacementExileTopAndPlay {
    fn id(&self) -> StaticAbilityId {
        StaticAbilityId::DrawReplacementExileTopAndPlay
    }

    fn display(&self) -> String {
        let cards = if self.count == 1 { "card" } else { "cards" };
        format!(
            "If you would draw a card, exile the top {} {} of your library instead. You may play those cards this turn.",
            self.count, cards
        )
    }

    fn generate_replacement_effect(
        &self,
        source: ObjectId,
        controller: PlayerId,
    ) -> Option<ReplacementEffect> {
        const TOP_CARDS_TAG: &str = "draw_replacement_top_cards";

        Some(ReplacementEffect::with_matcher(
            source,
            controller,
            WouldDrawCardMatcher::you(),
            ReplacementAction::Instead(vec![
                Effect::new(
                    crate::effects::ChooseObjectsEffect::new(
                        ObjectFilter::default()
                            .in_zone(Zone::Library)
                            .owned_by(PlayerFilter::You),
                        self.count as usize,
                        PlayerFilter::You,
                        TOP_CARDS_TAG,
                    )
                    .top_only(),
                ),
                Effect::new(crate::effects::ExileEffect::with_spec(ChooseSpec::tagged(
                    TOP_CARDS_TAG,
                ))),
                Effect::new(crate::effects::GrantPlayTaggedEffect::new(
                    TOP_CARDS_TAG,
                    PlayerFilter::You,
                    crate::effects::GrantPlayTaggedDuration::UntilEndOfTurn,
                    true,
                    false,
                )),
            ]),
        ))
    }
}

/// "If you would draw a card, instead reveal the top N cards of your library. Put all matching
/// cards revealed this way into your hand and the rest on the bottom of your library."
#[derive(Debug, Clone, PartialEq)]
pub struct DrawReplacementRevealTopMatchingToHandRestBottom {
    pub count: u32,
    pub filter: ObjectFilter,
    pub order: crate::effects::consult_helpers::LibraryBottomOrder,
    pub display: String,
}

impl DrawReplacementRevealTopMatchingToHandRestBottom {
    pub fn new(
        count: u32,
        filter: ObjectFilter,
        order: crate::effects::consult_helpers::LibraryBottomOrder,
        display: impl Into<String>,
    ) -> Self {
        Self {
            count,
            filter,
            order,
            display: display.into(),
        }
    }
}

impl StaticAbilityKind for DrawReplacementRevealTopMatchingToHandRestBottom {
    fn id(&self) -> StaticAbilityId {
        StaticAbilityId::DrawReplacementRevealTopMatchingToHandRestBottom
    }

    fn display(&self) -> String {
        ironsmith_core::semantic_audit::retained("DrawReplacementRevealTopMatchingToHandRestBottom", &self.display, self)
    }

    fn generate_replacement_effect(
        &self,
        source: ObjectId,
        controller: PlayerId,
    ) -> Option<ReplacementEffect> {
        const REVEALED_TAG: &str = "draw_replacement_revealed";
        const MATCHED_TAG: &str = "draw_replacement_matched";

        let mut matching_filter = self.filter.clone();
        matching_filter.zone = None;
        matching_filter
            .tagged_constraints
            .push(TaggedObjectConstraint {
                tag: TagKey::from(REVEALED_TAG),
                relation: TaggedOpbjectRelation::IsTaggedObject,
            });

        Some(ReplacementEffect::with_matcher(
            source,
            controller,
            WouldDrawCardMatcher::you(),
            ReplacementAction::Instead(vec![
                Effect::reveal_top_cards(
                    PlayerFilter::You,
                    Value::Fixed(self.count as i32),
                    TagKey::from(REVEALED_TAG),
                ),
                Effect::new(
                    crate::effects::TagMatchingObjectsEffect::new(matching_filter, MATCHED_TAG)
                        .in_zones(vec![Zone::Library]),
                ),
                Effect::for_each_tagged(
                    MATCHED_TAG,
                    vec![Effect::move_to_zone(
                        ChooseSpec::Iterated,
                        Zone::Hand,
                        false,
                    )],
                ),
                Effect::put_tagged_remainder_on_library_bottom(
                    TagKey::from(REVEALED_TAG),
                    Some(TagKey::from(MATCHED_TAG)),
                    self.order,
                    PlayerFilter::You,
                ),
            ]),
        ))
    }
}

/// "If [object] would [keyword action], instead [effects]."
#[derive(Debug, Clone, PartialEq)]
pub struct KeywordActionReplacement {
    pub action: crate::events::KeywordActionKind,
    pub source_filter: ObjectFilter,
    pub performer_filter: Option<PlayerFilter>,
    pub replacement_effects: Vec<Effect>,
    pub optional: bool,
    pub display: String,
}

impl KeywordActionReplacement {
    pub fn new(
        action: crate::events::KeywordActionKind,
        source_filter: ObjectFilter,
        performer_filter: Option<PlayerFilter>,
        replacement_effects: Vec<Effect>,
        optional: bool,
        display: impl Into<String>,
    ) -> Self {
        Self {
            action,
            source_filter,
            performer_filter,
            replacement_effects,
            optional,
            display: display.into(),
        }
    }
}

impl StaticAbilityKind for KeywordActionReplacement {
    fn id(&self) -> StaticAbilityId {
        StaticAbilityId::KeywordActionReplacement
    }

    fn display(&self) -> String {
        ironsmith_core::semantic_audit::retained("KeywordActionReplacement", &self.display, self)
    }

    fn generate_replacement_effect(
        &self,
        source: ObjectId,
        controller: PlayerId,
    ) -> Option<ReplacementEffect> {
        let replacement = ReplacementEffect::with_matcher(
            source,
            controller,
            crate::events::other::WouldKeywordActionMatcher::new(
                self.action,
                self.source_filter.clone(),
            )
            .with_performer_filter(self.performer_filter.clone()),
            ReplacementAction::Instead(self.replacement_effects.clone()),
        );
        Some(if self.optional {
            replacement.optional()
        } else {
            replacement
        })
    }
}

/// "If a card would be put into an opponent's graveyard from anywhere, instead exile it with a
/// void counter on it."
#[derive(Debug, Clone, PartialEq)]
pub struct ExileToCounteredExileInsteadOfGraveyard {
    pub player: PlayerFilter,
    pub counter_type: CounterType,
}

impl ExileToCounteredExileInsteadOfGraveyard {
    pub fn new(player: PlayerFilter, counter_type: CounterType) -> Self {
        Self {
            player,
            counter_type,
        }
    }

    fn graveyard_owner_phrase(&self) -> &'static str {
        match self.player {
            PlayerFilter::You => "your",
            PlayerFilter::Opponent => "an opponent's",
            _ => "a player's",
        }
    }
}

impl StaticAbilityKind for ExileToCounteredExileInsteadOfGraveyard {
    fn id(&self) -> StaticAbilityId {
        StaticAbilityId::ExileToCounteredExileInsteadOfGraveyard
    }

    fn display(&self) -> String {
        let counter = self.counter_type.description().into_owned();
        format!(
            "If a card would be put into {} graveyard from anywhere, instead exile it with a {} counter on it.",
            self.graveyard_owner_phrase(),
            counter
        )
    }

    fn generate_replacement_effect(
        &self,
        source: ObjectId,
        controller: PlayerId,
    ) -> Option<ReplacementEffect> {
        Some(ReplacementEffect::with_matcher(
            source,
            controller,
            // "If a card would be put into ...": tokens aren't cards
            // (CR 108.2, 111.1), so they still go to the graveyard (and die).
            WouldGoToGraveyardFromAnywhereMatcher::new(
                ObjectFilter::default()
                    .owned_by(self.player.clone())
                    .nontoken(),
                false,
            ),
            ReplacementAction::ExileWithSourceLinkCountersThen {
                counters: vec![(self.counter_type, 1)],
                effects: Vec::new(),
            },
        ))
    }
}

/// "If [objects] would be put into a graveyard from anywhere, exile them instead."
#[derive(Debug, Clone, PartialEq)]
pub struct ExileToExileInsteadOfGraveyard {
    pub filter: ObjectFilter,
    pub graveyard_owner: PlayerFilter,
    pub exclude_cycled: bool,
    /// Record the exiled card as exiled with the source (CR 607.2a), for a
    /// card whose other ability uses "cards exiled with" it.
    pub link_to_source: bool,
}

impl ExileToExileInsteadOfGraveyard {
    pub fn new(filter: ObjectFilter, graveyard_owner: PlayerFilter) -> Self {
        Self {
            filter,
            graveyard_owner,
            exclude_cycled: false,
            link_to_source: false,
        }
    }

    pub fn unless_cycled(filter: ObjectFilter, graveyard_owner: PlayerFilter) -> Self {
        Self {
            filter,
            graveyard_owner,
            exclude_cycled: true,
            link_to_source: false,
        }
    }

    fn graveyard_owner_phrase(&self) -> &'static str {
        match self.graveyard_owner {
            PlayerFilter::You => "your",
            PlayerFilter::Opponent => "an opponent's",
            _ => "a",
        }
    }

    fn replacement_subject_phrase(&self) -> String {
        // A bare "card" noun without the matching nontoken restriction is
        // oracle's "a card or token" (Rest in Peace, Necrodominance).
        if self.filter.has_explicit_card_noun() && !self.filter.nontoken {
            let mut bare_card = ObjectFilter::default();
            bare_card.set_explicit_card_noun(true);
            if self.filter == bare_card {
                return "a card or token".to_string();
            }
        }
        // The "card" noun already excludes tokens (CR 108.2), so a nontoken
        // restriction carried for matching isn't spelled out.
        let mut filter = self.filter.clone();
        if filter.has_explicit_card_noun() {
            filter.nontoken = false;
        }
        let filter = &filter;
        if filter.has_explicit_card_noun()
            && filter.controller == Some(PlayerFilter::NotYou)
        {
            let mut normalized = filter.clone();
            normalized.controller = None;
            let mut bare_card = ObjectFilter::default();
            bare_card.set_explicit_card_noun(true);
            if normalized == bare_card {
                return "a card you didn't control".to_string();
            }
        }
        if filter.has_explicit_card_noun()
            && let [marker] = filter.ability_markers.as_slice()
        {
            let mut normalized = filter.clone();
            normalized.ability_markers.clear();
            if normalized == ObjectFilter::default() {
                let marker = marker.to_ascii_lowercase();
                let article = match marker.chars().next() {
                    Some('a' | 'e' | 'i' | 'o' | 'u') => "an",
                    _ => "a",
                };
                return format!("a card that has {article} {marker} ability");
            }
        }
        let description = filter.description();
        let first_word = description
            .split_whitespace()
            .next()
            .unwrap_or_default()
            .to_ascii_lowercase();
        if description.is_empty()
            || matches!(
                first_word.as_str(),
                "a" | "an" | "the" | "this" | "that" | "each" | "another" | "one" | "any"
            )
        {
            return description;
        }
        let article = match first_word.chars().next() {
            Some('a' | 'e' | 'i' | 'o' | 'u') => "an",
            _ => "a",
        };
        format!("{article} {description}")
    }
}

impl StaticAbilityKind for ExileToExileInsteadOfGraveyard {
    fn is_source_only_graveyard_replacement(&self) -> bool {
        self.filter.source
    }

    fn id(&self) -> StaticAbilityId {
        StaticAbilityId::ExileToExileInsteadOfGraveyard
    }

    fn display(&self) -> String {
        let cycled_clause = if self.exclude_cycled {
            " and it wasn't cycled"
        } else {
            ""
        };
        format!(
            "If {} would be put into {} graveyard from anywhere{}, exile it instead.",
            self.replacement_subject_phrase(),
            self.graveyard_owner_phrase(),
            cycled_clause
        )
    }

    fn generate_replacement_effect(
        &self,
        source: ObjectId,
        controller: PlayerId,
    ) -> Option<ReplacementEffect> {
        let mut filter = self.filter.clone();
        if filter.owner.is_none() {
            filter.owner = Some(self.graveyard_owner.clone());
        }
        // With a linked "cards exiled with" ability, the card is exiled by
        // this source so that ability can find it (CR 607.2a).
        Some(ReplacementEffect::with_matcher(
            source,
            controller,
            WouldGoToGraveyardFromAnywhereMatcher::new(filter, self.exclude_cycled),
            if self.link_to_source {
                ReplacementAction::ExileWithSourceLink
            } else {
                ReplacementAction::ChangeDestination(Zone::Exile)
            },
        ))
    }
}

#[derive(Debug, Clone)]
struct WouldGoToGraveyardFromAnywhereMatcher {
    filter: ObjectFilter,
    exclude_cycled: bool,
}

impl WouldGoToGraveyardFromAnywhereMatcher {
    fn new(filter: ObjectFilter, exclude_cycled: bool) -> Self {
        Self {
            filter,
            exclude_cycled,
        }
    }

    fn is_excluded_cycled_discard(
        &self,
        card: ObjectId,
        cause: &crate::events::cause::EventCause,
        ctx: &EventContext,
    ) -> bool {
        if !self.exclude_cycled {
            return false;
        }
        if cause.cause_type != CauseType::Cost || cause.source != Some(card) {
            return false;
        }
        let cycling_filter = ObjectFilter::default().with_ability_marker("cycling");
        if let Some(snapshot) = ctx
            .event_source_snapshot
            .filter(|snapshot| snapshot.object_id == card)
        {
            return cycling_filter.matches_snapshot(snapshot, &ctx.filter_ctx, ctx.game);
        }
        ctx.game
            .object(card)
            .is_some_and(|obj| cycling_filter.matches(obj, &ctx.filter_ctx, ctx.game))
    }
}

impl ReplacementMatcher for WouldGoToGraveyardFromAnywhereMatcher {

    fn matches_prepared_event(&self, event: &dyn GameEventType, ctx: &crate::events::context::PreparedEventContext) -> bool {
        match event.event_kind() {
            EventKind::Discard => {
                let Some(discard) = downcast_event::<DiscardEvent>(event) else {
                    return false;
                };
                if discard.destination != Zone::Graveyard {
                    return false;
                }
                if self.is_excluded_cycled_discard(discard.card, &discard.cause, ctx) {
                    return false;
                }
                ctx.game
                    .object(discard.card)
                    .is_some_and(|obj| self.filter.matches(obj, &ctx.filter_ctx, ctx.game))
            }
            EventKind::ZoneChange => {
                let Some(zone_change) = downcast_event::<ZoneChangeEvent>(event) else {
                    return false;
                };
                if zone_change.to != Zone::Graveyard {
                    return false;
                }
                if zone_change.objects.first().is_some_and(|card| {
                    self.is_excluded_cycled_discard(*card, &zone_change.cause, ctx)
                }) {
                    return false;
                }
                if let Some(snapshot) = zone_change.snapshot.as_ref().or(ctx.event_source_snapshot)
                {
                    let mut filter_ctx = ctx.filter_ctx.clone();
                    filter_ctx.caster.get_or_insert(snapshot.controller);
                    return self
                        .filter
                        .matches_snapshot(snapshot, &filter_ctx, ctx.game);
                }
                zone_change
                    .objects
                    .first()
                    .and_then(|id| ctx.game.object(*id))
                    .is_some_and(|obj| self.filter.matches(obj, &ctx.filter_ctx, ctx.game))
            }
            _ => false,
        }
    }

    fn display(&self) -> String {
        "If an object would be put into a graveyard from anywhere".to_string()
    }
}

/// "If [objects] would die, exile them instead."
#[derive(Debug, Clone, PartialEq)]
pub struct ExileWouldDieInstead {
    pub filter: ObjectFilter,
    pub damaged_by: Option<DamagedBySource>,
    pub damager_filter: Option<ObjectFilter>,
    pub damager_filter_surface: Option<String>,
    pub exile_with_counters: Vec<(CounterType, u32)>,
    pub follow_up_effects: Vec<Effect>,
}

impl ExileWouldDieInstead {
    pub fn new(filter: ObjectFilter) -> Self {
        Self {
            filter,
            damaged_by: None,
            damager_filter: None,
            damager_filter_surface: None,
            exile_with_counters: Vec::new(),
            follow_up_effects: Vec::new(),
        }
    }

    pub fn damaged_by(filter: ObjectFilter, damaged_by: DamagedBySource) -> Self {
        Self {
            filter,
            damaged_by: Some(damaged_by),
            damager_filter: None,
            damager_filter_surface: None,
            exile_with_counters: Vec::new(),
            follow_up_effects: Vec::new(),
        }
    }

    pub fn with_follow_up(
        filter: ObjectFilter,
        damaged_by: Option<DamagedBySource>,
        follow_up_effects: Vec<Effect>,
    ) -> Self {
        Self::with_counters_and_follow_up(filter, damaged_by, Vec::new(), follow_up_effects)
    }

    pub fn damaged_by_filter(filter: ObjectFilter, damager_filter: ObjectFilter) -> Self {
        Self::damaged_by_filter_with_surface(filter, damager_filter, None)
    }

    pub fn damaged_by_filter_with_surface(
        filter: ObjectFilter,
        damager_filter: ObjectFilter,
        damager_filter_surface: Option<String>,
    ) -> Self {
        Self {
            filter,
            damaged_by: None,
            damager_filter: Some(damager_filter),
            damager_filter_surface,
            exile_with_counters: Vec::new(),
            follow_up_effects: Vec::new(),
        }
    }

    pub fn with_counters_and_follow_up(
        filter: ObjectFilter,
        damaged_by: Option<DamagedBySource>,
        exile_with_counters: Vec<(CounterType, u32)>,
        follow_up_effects: Vec<Effect>,
    ) -> Self {
        Self {
            filter,
            damaged_by,
            damager_filter: None,
            damager_filter_surface: None,
            exile_with_counters,
            follow_up_effects,
        }
    }
}

fn is_simple_source_would_die_filter(filter: &ObjectFilter) -> bool {
    if !filter.source || filter.card_types.len() > 1 {
        return false;
    }

    let mut filter_without_type = filter.clone();
    filter_without_type.card_types.clear();
    filter_without_type == ObjectFilter::source()
}

fn with_indefinite_article(text: String) -> String {
    let lower = text.to_ascii_lowercase();
    if lower.starts_with("a ")
        || lower.starts_with("an ")
        || lower.starts_with("the ")
        || lower.starts_with("another ")
    {
        return text;
    }
    let article = if lower
        .chars()
        .next()
        .is_some_and(|first| matches!(first, 'a' | 'e' | 'i' | 'o' | 'u'))
    {
        "an"
    } else {
        "a"
    };
    format!("{article} {text}")
}

impl StaticAbilityKind for ExileWouldDieInstead {
    fn id(&self) -> StaticAbilityId {
        StaticAbilityId::ExileWouldDieInstead
    }

    fn exile_would_die_instead_spec(
        &self,
    ) -> Option<(
        &ObjectFilter,
        Option<DamagedBySource>,
        Option<&ObjectFilter>,
        &[(CounterType, u32)],
        &[Effect],
    )> {
        Some((
            &self.filter,
            self.damaged_by,
            self.damager_filter.as_ref(),
            &self.exile_with_counters,
            &self.follow_up_effects,
        ))
    }

    fn display(&self) -> String {
        let counter_suffix = if self.exile_with_counters.is_empty() {
            String::new()
        } else {
            let counter_phrases: Vec<String> = self
                .exile_with_counters
                .iter()
                .map(|(counter_type, count)| describe_counter_phrase(counter_type, *count))
                .collect();
            format!(" with {} on it", join_english(&counter_phrases))
        };
        if let Some(damager_filter) = &self.damager_filter {
            let source_text = self.damager_filter_surface.clone().unwrap_or_else(|| {
                let mut source_filter = damager_filter.clone();
                source_filter.zone = None;
                source_filter
                    .description()
                    .replace(" you control", " you controlled")
                    .replace(" an opponent controls", " an opponent controlled")
            });
            format!(
                "If {} dealt damage this turn by {} would die, exile it{} instead.",
                with_indefinite_article(self.filter.description()),
                source_text,
                counter_suffix
            )
        } else if let Some(damaged_by) = self.damaged_by {
            let source_text = match damaged_by {
                DamagedBySource::ThisCreature => "this creature",
                DamagedBySource::EquippedCreature => "equipped creature",
                DamagedBySource::EnchantedCreature => "enchanted creature",
            };
            format!(
                "If {} dealt damage by {} this turn would die, exile it{} instead.",
                self.filter.description(),
                source_text,
                counter_suffix
            )
        } else {
            format!(
                "If {} would die, exile it{} instead.",
                self.filter.description(),
                counter_suffix
            )
        }
    }

    fn generate_replacement_effect(
        &self,
        source: ObjectId,
        controller: PlayerId,
    ) -> Option<ReplacementEffect> {
        if let Some(damager_filter) = &self.damager_filter {
            return Some(ReplacementEffect::with_matcher(
                source,
                controller,
                WouldDieDamagedByFilteredSourceThisTurnMatcher::new(
                    self.filter.clone(),
                    damager_filter.clone(),
                ),
                ReplacementAction::ExileWithSourceLinkCountersThen {
                    counters: self.exile_with_counters.clone(),
                    effects: self.follow_up_effects.clone(),
                },
            ));
        }
        if let Some(damaged_by) = self.damaged_by {
            return Some(ReplacementEffect::with_matcher(
                source,
                controller,
                WouldDieDamagedBySourceThisTurnMatcher::new(self.filter.clone(), damaged_by),
                ReplacementAction::ExileWithSourceLinkCountersThen {
                    counters: self.exile_with_counters.clone(),
                    effects: self.follow_up_effects.clone(),
                },
            ));
        }

        if is_simple_source_would_die_filter(&self.filter)
            && self.exile_with_counters.is_empty()
            && self.follow_up_effects.is_empty()
        {
            return Some(ReplacementEffect::exile_instead_of_dying(
                source, controller,
            ));
        }

        Some(ReplacementEffect::with_matcher(
            source,
            controller,
            crate::events::zones::matchers::WouldChangeZoneMatcher::new(
                self.filter.clone(),
                Some(Zone::Battlefield),
                Some(Zone::Graveyard),
            ),
            ReplacementAction::ExileWithSourceLinkCountersThen {
                counters: self.exile_with_counters.clone(),
                effects: self.follow_up_effects.clone(),
            },
        ))
    }
}

// =============================================================================
// Interactive ETB Replacement Abilities (Unified System)
// =============================================================================

/// "You may discard a card matching [filter]. If you don't, put this into [zone]."
///
/// Used by: Mox Diamond (discard land or goes to graveyard)
///
/// This is an interactive replacement effect that uses the unified replacement
/// system rather than the deprecated EtbReplacementHandler trait.
#[derive(Debug, Clone, PartialEq)]
pub struct DiscardOrRedirectReplacement {
    /// Filter for cards that can be discarded to satisfy the replacement.
    pub filter: ObjectFilter,
    /// Where the permanent goes if no card is discarded.
    pub redirect_zone: Zone,
}

impl DiscardOrRedirectReplacement {
    /// Create a new discard-or-redirect replacement ability.
    pub fn new(filter: ObjectFilter, redirect_zone: Zone) -> Self {
        Self {
            filter,
            redirect_zone,
        }
    }
}

impl StaticAbilityKind for DiscardOrRedirectReplacement {
    fn id(&self) -> StaticAbilityId {
        StaticAbilityId::DiscardOrRedirectReplacement
    }

    fn display(&self) -> String {
        let discard_phrase = describe_discard_filter_card_phrase(&self.filter);
        let redirect_phrase = describe_redirect_zone_phrase(self.redirect_zone);
        format!(
            "If this would enter the battlefield, you may discard {} instead. If you do, put it onto the battlefield. If you don't, put it into {}.",
            discard_phrase, redirect_phrase
        )
    }

    fn generate_replacement_effect(
        &self,
        source: ObjectId,
        controller: PlayerId,
    ) -> Option<ReplacementEffect> {
        Some(ReplacementEffect::with_matcher(
            source,
            controller,
            ThisWouldEnterBattlefieldMatcher,
            ReplacementAction::InteractiveDiscardOrRedirect {
                filter: self.filter.clone(),
                redirect_zone: self.redirect_zone,
            },
        ))
    }
}

/// "Sacrifice [count] permanents matching [filter], or put this into [zone]."
///
/// Used by the family of lands whose entry is replaced by sacrificing
/// untapped lands (Scorched Ruins, Lotus Vale, and related cards).
#[derive(Debug, Clone, PartialEq)]
pub struct SacrificeOrRedirectReplacement {
    pub filter: ObjectFilter,
    pub count: u32,
    pub redirect_zone: Zone,
}

impl SacrificeOrRedirectReplacement {
    pub fn new(filter: ObjectFilter, count: u32, redirect_zone: Zone) -> Self {
        Self {
            filter,
            count,
            redirect_zone,
        }
    }
}

impl StaticAbilityKind for SacrificeOrRedirectReplacement {
    fn id(&self) -> StaticAbilityId {
        StaticAbilityId::SacrificeOrRedirectReplacement
    }

    fn display(&self) -> String {
        let count =
            ironsmith_core::cardinal_word(self.count).unwrap_or_else(|| self.count.to_string());
        let sacrifice_subject = if self.count == 1 {
            self.filter.description()
        } else {
            pluralize_filter_description(&self.filter.description())
        };
        let redirect_phrase = describe_redirect_zone_phrase(self.redirect_zone);
        format!(
            "If this land would enter, sacrifice {} {} instead. If you do, put this land onto the battlefield. If you don't, put it into {}.",
            count, sacrifice_subject, redirect_phrase
        )
    }

    fn generate_replacement_effect(
        &self,
        source: ObjectId,
        controller: PlayerId,
    ) -> Option<ReplacementEffect> {
        Some(ReplacementEffect::with_matcher(
            source,
            controller,
            ThisWouldEnterBattlefieldMatcher,
            ReplacementAction::InteractiveSacrificeOrRedirect {
                filter: self.filter.clone(),
                count: self.count,
                redirect_zone: self.redirect_zone,
            },
        ))
    }
}

/// "As this enters the battlefield, you may pay N life. If you don't, it enters tapped."
///
/// Used by: Shock lands (Godless Shrine, etc.), slow fetches (Vault of Champions, etc.)
///
/// This is an interactive replacement effect that uses the unified replacement
/// system rather than the deprecated EtbReplacementHandler trait.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct PayLifeOrEnterTappedReplacement {
    /// The amount of life to pay to enter untapped.
    pub life_cost: u32,
}

impl PayLifeOrEnterTappedReplacement {
    /// Create a new pay-life-or-enter-tapped replacement ability.
    pub fn new(life_cost: u32) -> Self {
        Self { life_cost }
    }
}

impl StaticAbilityKind for PayLifeOrEnterTappedReplacement {
    fn may_generate_continuous_effects(&self) -> bool {
        false
    }

    fn id(&self) -> StaticAbilityId {
        StaticAbilityId::PayLifeOrEnterTappedReplacement
    }

    fn display(&self) -> String {
        format!(
            "As this enters the battlefield, you may pay {} life. If you don't, it enters tapped.",
            self.life_cost
        )
    }

    fn generate_replacement_effect(
        &self,
        source: ObjectId,
        controller: PlayerId,
    ) -> Option<ReplacementEffect> {
        Some(ReplacementEffect::with_matcher(
            source,
            controller,
            ThisWouldEnterBattlefieldMatcher,
            ReplacementAction::InteractivePayLifeOrEnterTapped {
                life_cost: self.life_cost,
            },
        ))
    }

    fn enters_tapped(&self) -> bool {
        // This is conditionally enters tapped, so we return false here
        // The actual tapped state is determined by the replacement effect
        false
    }
}

/// "As this land enters, you may reveal a <type> card from your hand. If you
/// don't, this land enters tapped." (Port Town, Frostboil Snarl, ...)
///
/// Interactive replacement effect on the unified replacement system, parallel
/// to [`PayLifeOrEnterTappedReplacement`].
#[derive(Debug, Clone, PartialEq)]
pub struct RevealCardOrEnterTappedReplacement {
    /// The hand card that may be revealed to enter untapped.
    pub filter: ObjectFilter,
    /// Authored subject phrase ("this land").
    pub subject: String,
    /// Authored tail subject phrase ("this land" or "it").
    pub tail_subject: String,
}

impl RevealCardOrEnterTappedReplacement {
    pub fn new(
        filter: ObjectFilter,
        subject: impl Into<String>,
        tail_subject: impl Into<String>,
    ) -> Self {
        Self {
            filter,
            subject: subject.into(),
            tail_subject: tail_subject.into(),
        }
    }
}

impl StaticAbilityKind for RevealCardOrEnterTappedReplacement {
    fn id(&self) -> StaticAbilityId {
        StaticAbilityId::RevealCardOrEnterTappedReplacement
    }

    fn display(&self) -> String {
        format!(
            "As {} enters, you may reveal {} from your hand. If you don't, {} enters tapped.",
            self.subject,
            with_indefinite_article(self.filter.description()),
            self.tail_subject
        )
    }

    fn generate_replacement_effect(
        &self,
        source: ObjectId,
        controller: PlayerId,
    ) -> Option<ReplacementEffect> {
        Some(ReplacementEffect::with_matcher(
            source,
            controller,
            ThisWouldEnterBattlefieldMatcher,
            ReplacementAction::InteractiveRevealCardOrEnterTapped {
                filter: self.filter.clone(),
            },
        ))
    }

    fn enters_tapped(&self) -> bool {
        // Conditionally enters tapped; the replacement effect decides.
        false
    }
}

/// "If a nontoken creature would enter and it wasn't cast, exile it instead."
/// (Containment Priest). Matching objects that would enter the battlefield
/// move to `destination` instead.
#[derive(Debug, Clone, PartialEq)]
pub struct RedirectWouldEnterReplacement {
    pub filter: ObjectFilter,
    /// Only objects that are not entering from the stack (i.e. weren't cast).
    pub not_cast: bool,
    pub destination: Zone,
    pub display: String,
    /// With `not_cast`: a cast object for which no mana was spent also
    /// qualifies (Primeval Spawn).
    pub or_no_mana_spent: bool,
}

impl RedirectWouldEnterReplacement {
    pub fn new(
        filter: ObjectFilter,
        not_cast: bool,
        destination: Zone,
        display: impl Into<String>,
    ) -> Self {
        Self {
            filter,
            not_cast,
            destination,
            display: display.into(),
            or_no_mana_spent: false,
        }
    }

    pub fn with_or_no_mana_spent(mut self, or_no_mana_spent: bool) -> Self {
        self.or_no_mana_spent = or_no_mana_spent;
        self
    }
}

impl StaticAbilityKind for RedirectWouldEnterReplacement {
    fn id(&self) -> StaticAbilityId {
        StaticAbilityId::RedirectWouldEnterReplacement
    }

    fn display(&self) -> String {
        ironsmith_core::semantic_audit::retained("RedirectWouldEnterReplacement", &self.display, self)
    }

    fn generate_replacement_effect(
        &self,
        source: ObjectId,
        controller: PlayerId,
    ) -> Option<ReplacementEffect> {
        Some(ReplacementEffect::with_matcher(
            source,
            controller,
            WouldEnterFromZoneMatcher {
                enter_matcher: crate::events::zones::matchers::WouldEnterBattlefieldMatcher::new(
                    self.filter.clone(),
                ),
                not_cast: self.not_cast,
                or_no_mana_spent: self.or_no_mana_spent,
            },
            ReplacementAction::ChangeDestination(self.destination),
        ))
    }
}

/// A would-enter matcher that can additionally require the object not to be
/// entering from the stack ("and it wasn't cast").
#[derive(Debug, Clone)]
struct WouldEnterFromZoneMatcher {
    enter_matcher: crate::events::zones::matchers::WouldEnterBattlefieldMatcher,
    not_cast: bool,
    or_no_mana_spent: bool,
}

impl WouldEnterFromZoneMatcher {
    fn origin_allowed(
        &self,
        event: &dyn GameEventType,
        game: &crate::game_state::GameState,
    ) -> bool {
        if !self.not_cast {
            return true;
        }
        let entering = match event.event_kind() {
            EventKind::ZoneChange => {
                crate::events::downcast_event::<crate::events::ZoneChangeEvent>(event)
                    .map(|zone_change| (zone_change.from, zone_change.objects.first().copied()))
            }
            EventKind::EnterBattlefield => {
                crate::events::downcast_event::<crate::events::EnterBattlefieldEvent>(event)
                    .map(|etb| (etb.from, Some(etb.object)))
            }
            _ => None,
        };
        let Some((from, object)) = entering else {
            return false;
        };
        if from != Zone::Stack {
            return true;
        }
        // "or no mana was spent to cast it" (Primeval Spawn).
        self.or_no_mana_spent
            && object
                .and_then(|object| game.object(object))
                .is_some_and(|object| object.mana_spent_to_cast.total() == 0)
    }
}

impl ReplacementMatcher for WouldEnterFromZoneMatcher {

    fn matches_prepared_event(&self, event: &dyn GameEventType, ctx: &crate::events::context::PreparedEventContext) -> bool {
        self.enter_matcher.matches_prepared_event(event, ctx) && self.origin_allowed(event, ctx.game)
    }

    fn applies_from_entering_source(&self) -> bool {
        self.enter_matcher.applies_from_entering_source()
    }

    fn priority(&self) -> ReplacementPriority {
        self.enter_matcher.priority()
    }

    fn display(&self) -> String {
        self.enter_matcher.display()
    }
}

/// "If a land is tapped for two or more mana, it produces {C} instead of any
/// other type and amount." (Damping Sphere)
#[derive(Debug, Clone, PartialEq)]
pub struct ManaProductionReplacement {
    pub source_filter: ObjectFilter,
    pub minimum_amount: u32,
    pub replacement_mana: Vec<crate::mana::ManaSymbol>,
    pub display: String,
}

impl ManaProductionReplacement {
    pub fn new(
        source_filter: ObjectFilter,
        minimum_amount: u32,
        replacement_mana: Vec<crate::mana::ManaSymbol>,
        display: impl Into<String>,
    ) -> Self {
        Self {
            source_filter,
            minimum_amount,
            replacement_mana,
            display: display.into(),
        }
    }
}

impl StaticAbilityKind for ManaProductionReplacement {
    fn id(&self) -> StaticAbilityId {
        StaticAbilityId::ManaProductionReplacement
    }

    fn display(&self) -> String {
        ironsmith_core::semantic_audit::retained("ManaProductionReplacement", &self.display, self)
    }

    fn generate_replacement_effect(
        &self,
        source: ObjectId,
        controller: PlayerId,
    ) -> Option<ReplacementEffect> {
        Some(ReplacementEffect::with_matcher(
            source,
            controller,
            TappedForMinimumManaMatcher {
                inner: crate::events::mana::matchers::ManaProducedBySourceMatcher::tapped_source_for_mana(
                    self.source_filter.clone(),
                ),
                minimum_amount: self.minimum_amount,
            },
            ReplacementAction::ReplaceManaExact(self.replacement_mana.clone()),
        ))
    }
}

/// "If you tap a permanent for mana, it produces three times as much of that
/// mana instead." (Nyxbloom Ancient, Mana Reflection)
#[derive(Debug, Clone, PartialEq)]
pub struct ManaProductionMultiplierReplacement {
    pub source_filter: ObjectFilter,
    pub factor: u32,
    pub display: String,
}

impl ManaProductionMultiplierReplacement {
    pub fn new(source_filter: ObjectFilter, factor: u32, display: impl Into<String>) -> Self {
        Self {
            source_filter,
            factor,
            display: display.into(),
        }
    }
}

impl StaticAbilityKind for ManaProductionMultiplierReplacement {
    fn id(&self) -> StaticAbilityId {
        StaticAbilityId::ManaProductionMultiplierReplacement
    }

    fn display(&self) -> String {
        ironsmith_core::semantic_audit::retained("ManaProductionMultiplierReplacement", &self.display, self)
    }

    fn generate_replacement_effect(
        &self,
        source: ObjectId,
        controller: PlayerId,
    ) -> Option<ReplacementEffect> {
        Some(ReplacementEffect::with_matcher(
            source,
            controller,
            TappedForMinimumManaMatcher {
                inner: crate::events::mana::matchers::ManaProducedBySourceMatcher::tapped_source_for_mana(
                    self.source_filter.clone(),
                ),
                minimum_amount: 1,
            },
            ReplacementAction::Modify(EventModification::Multiply(self.factor)),
        ))
    }
}

/// Mana a matching source is tapped for, when the event adds at least
/// `minimum_amount` mana.
#[derive(Debug, Clone)]
struct TappedForMinimumManaMatcher {
    inner: crate::events::mana::matchers::ManaProducedBySourceMatcher,
    minimum_amount: u32,
}

impl ReplacementMatcher for TappedForMinimumManaMatcher {

    fn may_match_event_kind(&self, kind: crate::events::EventKind) -> bool {
        kind == crate::events::EventKind::ManaAdded
    }

    fn mana_predicate(&self) -> Option<crate::events::mana::ManaEventPredicate<'_>> {
        let mut predicate = self.inner.mana_predicate()?;
        predicate.minimum_amount = predicate.minimum_amount.max(self.minimum_amount as usize);
        Some(predicate)
    }

    fn matches_prepared_event(&self, event: &dyn GameEventType, ctx: &crate::events::context::PreparedEventContext) -> bool {
        self.inner.matches_prepared_event(event, ctx)
            && crate::events::downcast_event::<crate::events::ManaAddedEvent>(event)
                .is_some_and(|added| added.mana.len() >= self.minimum_amount as usize)
    }

    fn priority(&self) -> ReplacementPriority {
        self.inner.priority()
    }

    fn display(&self) -> String {
        self.inner.display()
    }
}

/// "If you would gain life, you gain twice that much life instead." (Boon
/// Reflection); `loss` selects the life-loss form (Bloodletter of Aclazotz).
/// A leading "as long as" / "during your turn" condition gates it.
#[derive(Debug, Clone, PartialEq)]
pub struct DoubleLifeChangeReplacement {
    pub player: PlayerFilter,
    pub loss: bool,
    pub condition: Option<Condition>,
    pub display: String,
}

impl DoubleLifeChangeReplacement {
    pub fn new(player: PlayerFilter, loss: bool, display: impl Into<String>) -> Self {
        Self {
            player,
            loss,
            condition: None,
            display: display.into(),
        }
    }
}

impl StaticAbilityKind for DoubleLifeChangeReplacement {
    fn id(&self) -> StaticAbilityId {
        StaticAbilityId::DoubleLifeChangeReplacement
    }

    fn display(&self) -> String {
        ironsmith_core::semantic_audit::retained("DoubleLifeChangeReplacement", &self.display, self)
    }

    fn with_static_condition(&self, condition: crate::ConditionExpr) -> Option<StaticAbility> {
        let mut combined = self.clone();
        combined.condition = Some(match combined.condition.take() {
            Some(existing) => Condition::And(Box::new(condition), Box::new(existing)),
            None => condition,
        });
        Some(StaticAbility::new(combined))
    }

    fn generate_replacement_effect(
        &self,
        source: ObjectId,
        controller: PlayerId,
    ) -> Option<ReplacementEffect> {
        Some(ReplacementEffect::with_matcher(
            source,
            controller,
            ConditionalWouldChangeLifeMatcher {
                player: self.player.clone(),
                loss: self.loss,
                condition: self.condition.clone(),
                display: self.display.clone(),
            },
            ReplacementAction::Double,
        ))
    }
}

/// A life-gain or life-loss event for the matching player, optionally gated
/// by a static condition evaluated for the replacement's source.
#[derive(Debug, Clone)]
struct ConditionalWouldChangeLifeMatcher {
    player: PlayerFilter,
    loss: bool,
    condition: Option<Condition>,
    display: String,
}

impl ReplacementMatcher for ConditionalWouldChangeLifeMatcher {

    fn matches_prepared_event(&self, event: &dyn GameEventType, ctx: &crate::events::context::PreparedEventContext) -> bool {
        let matches_change = if self.loss {
            crate::events::life::matchers::WouldLoseLifeMatcher::new(self.player.clone())
                .matches_prepared_event(event, ctx)
        } else {
            crate::events::life::matchers::WouldGainLifeMatcher::new(self.player.clone())
                .matches_prepared_event(event, ctx)
        };
        if !matches_change {
            return false;
        }
        let Some(condition) = &self.condition else {
            return true;
        };
        let Some(source) = ctx.source else {
            return false;
        };
        let eval_ctx = crate::condition_eval::ExternalEvaluationContext {
            controller: ctx.controller,
            source,
            defending_player: None,
            attacking_player: None,
            filter_source: None,
            iterated_player: None,
            triggering_event: None,
            trigger_identity: None,
            ability_index: None,
            options: Default::default(),
        };
        crate::condition_eval::evaluate_condition_external(ctx.game, condition, &eval_ctx)
    }

    fn display(&self) -> String {
        ironsmith_core::semantic_audit::retained("DoubleLifeChangeReplacement", &self.display, self)
    }
}

/// Parser-backed pregame action from opening hand.
#[derive(Debug, Clone, PartialEq)]
pub struct PregameAction {
    pub kind: crate::static_abilities::PregameActionKind,
    pub text: String,
    pub effects: Vec<crate::effect::Effect>,
}

impl PregameAction {
    pub fn new(kind: crate::static_abilities::PregameActionKind, text: impl Into<String>) -> Self {
        Self {
            kind,
            text: text.into(),
            effects: Vec::new(),
        }
    }

    pub fn with_effects(
        kind: crate::static_abilities::PregameActionKind,
        text: impl Into<String>,
        effects: Vec<crate::effect::Effect>,
    ) -> Self {
        Self {
            kind,
            text: text.into(),
            effects,
        }
    }
}

impl StaticAbilityKind for PregameAction {
    fn id(&self) -> StaticAbilityId {
        StaticAbilityId::PregameAction
    }

    fn display(&self) -> String {
        match &self.kind {
            crate::static_abilities::PregameActionKind::ChosenOutsideGame(spec) => {
                let condition = match &spec.deck_condition {
                    ironsmith_core::PregameDeckCondition::Unrestricted => String::new(),
                    ironsmith_core::PregameDeckCondition::EveryCardPrintedTextContainsAny { exempt_types, phrases } => format!("; starting-deck cards except {:?} must contain one of {:?} in their printed rules text", exempt_types, phrases),
                };
                format!("You may choose this outside-game card as your {}{}. You may exchange it with a card in your opening hand", spec.designation, condition)
            }
            crate::static_abilities::PregameActionKind::BeginOnBattlefield(spec) => {
                render_begin_on_battlefield_pregame(spec)
            }
            // The kind alone fixes this action's meaning (Serum Powder).
            crate::static_abilities::PregameActionKind::MulliganExileHandDrawSameCount
                if ironsmith_core::semantic_audit::semantic_audit_active() =>
            {
                "Any time you could mulligan and this card is in your hand, you may exile all the cards from your hand, then draw that many cards".to_string()
            }
            crate::static_abilities::PregameActionKind::MulliganExileHandDrawSameCount => {
                self.text.clone()
            }
            // No structural reading: an audit reports the typed kind.
            crate::static_abilities::PregameActionKind::SourceSetup { .. }
            | crate::static_abilities::PregameActionKind::ChooseColor
            | crate::static_abilities::PregameActionKind::ExileDraftedCardsBeforeShuffle(_) => {
                ironsmith_core::semantic_audit::retained("PregameAction", &self.text, &self.kind)
            }
            crate::static_abilities::PregameActionKind::RevealFromOpeningHand(spec) => {
                render_reveal_from_opening_hand_pregame(*spec, &self.effects)
            }
        }
    }

    fn pregame_action_kind(&self) -> Option<crate::static_abilities::PregameActionKind> {
        Some(self.kind.clone())
    }

    fn pregame_action_effects(&self) -> Option<&[crate::effect::Effect]> {
        Some(&self.effects)
    }
}

fn lowercase_first(text: &str) -> String {
    let mut chars = text.chars();
    let Some(first) = chars.next() else {
        return String::new();
    };
    first.to_lowercase().collect::<String>() + chars.as_str()
}

fn contextualize_delayed_spell_consequence(text: &str) -> String {
    for prefix in [
        "Counter it unless that object's controller pays",
        "Counter it unless that player pays",
        "Counter it unless they pay",
    ] {
        if let Some(rest) = text.strip_prefix(prefix) {
            return format!("Counter that spell unless that player pays{rest}");
        }
    }
    text.to_string()
}

fn render_reveal_from_opening_hand_pregame(
    spec: crate::static_abilities::PregameRevealFromOpeningHandSpec,
    effects: &[crate::effect::Effect],
) -> String {
    let prefix = "You may reveal this card from your opening hand. If you do";
    let Some(schedule) = effects
        .iter()
        .find_map(|effect| effect.downcast_ref::<crate::effects::ScheduleDelayedTriggerEffect>())
    else {
        return format!("{prefix}.");
    };

    let first_opponent_spell = schedule
        .trigger
        .downcast_ref::<crate::triggers::SpellCastTrigger>()
        .is_some_and(|trigger| {
            trigger.first_spell_of_game && trigger.caster == crate::target::PlayerFilter::Opponent
        });
    let timing = if let Some(upkeep) = schedule
        .trigger
        .downcast_ref::<crate::triggers::BeginningOfUpkeepTrigger>()
    {
        match &upkeep.player {
            crate::target::PlayerFilter::You => "at the beginning of your first upkeep".to_string(),
            crate::target::PlayerFilter::Any => "at the beginning of the first upkeep".to_string(),
            _ => lowercase_first(&schedule.trigger.display()),
        }
    } else if let Some(main) = schedule
        .trigger
        .downcast_ref::<crate::triggers::BeginningOfMainPhaseTrigger>()
    {
        match (main.player.clone(), main.phase_type) {
            (
                crate::target::PlayerFilter::You,
                crate::triggers::phase_step::MainPhaseType::Precombat,
            ) => "at the beginning of your first main phase of the game".to_string(),
            _ => lowercase_first(&schedule.trigger.display()),
        }
    } else if first_opponent_spell {
        "when each opponent casts their first spell of the game".to_string()
    } else {
        lowercase_first(&schedule.trigger.display())
    };

    let delayed_effects = schedule.effects.flattened_default_effects();
    // An audit reads the delayed program through the full effect renderer
    // (installed above this crate), not the terse runtime summary.
    let audited = if ironsmith_core::semantic_audit::semantic_audit_active() {
        ironsmith_core::semantic_audit::described_value(&delayed_effects.to_vec())
    } else {
        None
    };
    let mut consequence = audited
        .unwrap_or_else(|| crate::runtime_display::compile_effect_list(delayed_effects));
    if first_opponent_spell {
        consequence = contextualize_delayed_spell_consequence(&consequence);
    }
    let consequence = consequence.trim().trim_end_matches('.');
    if spec.effect_before_timing {
        format!("{prefix}, {} {timing}.", lowercase_first(consequence))
    } else {
        format!("{prefix}, {timing}, {}.", lowercase_first(consequence))
    }
}

fn render_begin_on_battlefield_pregame(
    spec: &crate::static_abilities::PregameBeginOnBattlefieldSpec,
) -> String {
    let mut clause = String::from("If this card is in your opening hand");
    if spec.require_not_starting_player {
        clause.push_str(" and you're not the starting player");
    }
    let simple_begin_on_battlefield = !spec.require_not_starting_player
        && spec.counters.is_empty()
        && spec.exile_cards_from_hand == 0;
    if simple_begin_on_battlefield {
        clause.push_str(", you may begin the game with it on the battlefield");
    } else {
        clause.push_str(", you may begin the game with this on the battlefield");
    }
    if !spec.counters.is_empty() {
        clause.push_str(" with ");
        let counter_phrases: Vec<String> = spec
            .counters
            .iter()
            .map(|(counter_type, count)| describe_counter_phrase(counter_type, *count))
            .collect();
        clause.push_str(&join_english(&counter_phrases));
        clause.push_str(" on it");
    }
    clause.push('.');
    if spec.exile_cards_from_hand > 0 {
        let count = spec.exile_cards_from_hand;
        let card_word = if count == 1 { "card" } else { "cards" };
        let count_word = if count == 1 {
            "a".to_string()
        } else {
            count.to_string()
        };
        clause.push_str(&format!(
            " If you do, exile {count_word} {card_word} from your hand."
        ));
    }
    clause
}

fn describe_counter_phrase(counter_type: &crate::object::CounterType, count: u32) -> String {
    let counter_name = counter_type.description();
    if count == 1 {
        format!("a {counter_name} counter")
    } else {
        format!("{count} {counter_name} counters")
    }
}

fn join_english(items: &[String]) -> String {
    match items {
        [] => String::new(),
        [one] => one.clone(),
        [first, second] => format!("{first} and {second}"),
        _ => {
            let (last, rest) = items.split_last().expect("nonempty");
            format!("{}, and {}", rest.join(", "), last)
        }
    }
}

/// Supported keyword-like text that should compile cleanly even before it has
/// dedicated runtime hooks.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct KeywordText {
    pub text: String,
}

impl KeywordText {
    pub fn new(text: impl Into<String>) -> Self {
        Self { text: text.into() }
    }
}

impl StaticAbilityKind for KeywordText {
    fn id(&self) -> StaticAbilityId {
        StaticAbilityId::KeywordText
    }

    fn display(&self) -> String {
        // Nothing but retained prose backs this ability: an audit reports it.
        ironsmith_core::semantic_audit::retained("KeywordText", &self.text, self)
    }
}

/// Draft-only rule text from Conspiracy-style cards.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct DraftRuleText {
    pub text: String,
    pub rule: ironsmith_core::DraftRule,
}

impl DraftRuleText {
    pub fn new(text: impl Into<String>) -> Self {
        let text = text.into();
        let rule = ironsmith_core::draft_rule(&text);
        Self::typed(text, rule)
    }

    pub fn typed(text: impl Into<String>, rule: ironsmith_core::DraftRule) -> Self {
        Self { text: text.into(), rule }
    }
}

impl StaticAbilityKind for DraftRuleText {
    fn id(&self) -> StaticAbilityId {
        StaticAbilityId::DraftRuleText
    }

    fn draft_rule(&self) -> Option<ironsmith_core::DraftRule> {
        Some(self.rule)
    }

    fn display(&self) -> String {
        // Nothing but retained prose backs this ability: an audit reports it.
        ironsmith_core::semantic_audit::retained("DraftRuleText", &self.text, self)
    }
}

/// "If this enchantment leaves the battlefield, this effect continues until
/// end of turn" (Titania's Song). Inert while its permanent is on the
/// battlefield; as the permanent leaves, the game registers the continuous
/// effects of its other static abilities for the rest of the turn.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct StaticEffectsContinueUntilEndOfTurnAfterLeaving {
    pub text: String,
}

impl StaticEffectsContinueUntilEndOfTurnAfterLeaving {
    pub fn new(text: impl Into<String>) -> Self {
        Self { text: text.into() }
    }
}

impl StaticAbilityKind for StaticEffectsContinueUntilEndOfTurnAfterLeaving {
    fn id(&self) -> StaticAbilityId {
        StaticAbilityId::StaticEffectsContinueUntilEndOfTurnAfterLeaving
    }

    fn display(&self) -> String {
        // The ability's identity fixes its meaning.
        if ironsmith_core::semantic_audit::semantic_audit_active() {
            return "If this permanent leaves the battlefield, its static effects continue until end of turn".to_string();
        }
        self.text.clone()
    }
}

/// Marker for CR 702.106 hidden agenda setup and reveal semantics.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct HiddenAgenda;

impl StaticAbilityKind for HiddenAgenda {
    fn id(&self) -> StaticAbilityId {
        StaticAbilityId::HiddenAgenda
    }

    fn display(&self) -> String {
        "Hidden agenda".to_string()
    }
}

/// Marker for the two-name hidden-agenda variant.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct DoubleAgenda;

impl StaticAbilityKind for DoubleAgenda {
    fn id(&self) -> StaticAbilityId {
        StaticAbilityId::DoubleAgenda
    }

    fn display(&self) -> String {
        "Double agenda".to_string()
    }
}

/// "You are the starting player. If multiple players would be the starting
/// player, one of those players is chosen at random." (Power Play, CR 315.5a).
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct StartingPlayer;

impl StaticAbilityKind for StartingPlayer {
    fn id(&self) -> StaticAbilityId {
        StaticAbilityId::StartingPlayer
    }

    fn display(&self) -> String {
        "You are the starting player. If multiple players would be the starting player, one of those players is chosen at random.".to_string()
    }
}

/// Deck-construction rule text. It has no in-game rules impact, but deck
/// validation enforces its typed copy limit.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct DeckConstructionRuleText {
    pub text: String,
    /// `Some(None)`: any number of copies; `Some(Some(n))`: up to `n`.
    pub copy_limit: Option<Option<u32>>,
    /// Colors its owner circles as they create their deck (Cryptic Spires).
    pub color_choices: Option<u32>,
}

impl DeckConstructionRuleText {
    pub fn new(text: impl Into<String>) -> Self {
        let text = text.into();
        let color_choices = ironsmith_core::deck_construction_color_choice_count(&text);
        Self { text, copy_limit: None, color_choices }
    }

    pub fn with_copy_limit(text: impl Into<String>, maximum: Option<u32>) -> Self {
        Self { text: text.into(), copy_limit: Some(maximum), color_choices: None }
    }

    pub fn with_color_choices(text: impl Into<String>, count: u32) -> Self {
        Self { text: text.into(), copy_limit: None, color_choices: Some(count) }
    }
}

impl StaticAbilityKind for DeckConstructionRuleText {
    fn id(&self) -> StaticAbilityId {
        StaticAbilityId::DeckConstructionRuleText
    }

    fn deck_copy_limit(&self) -> Option<Option<u32>> {
        self.copy_limit
    }

    fn deck_color_choice_count(&self) -> Option<u32> {
        self.color_choices
    }

    fn display(&self) -> String {
        if ironsmith_core::semantic_audit::semantic_audit_active() {
            if let Some(count) = self.color_choices {
                return format!(
                    "As its owner creates their deck, they choose {count} different colors for this card"
                );
            }
            return match self.copy_limit {
                Some(None) => "A deck can have any number of copies of this card".to_string(),
                Some(Some(limit)) => format!("A deck can have up to {limit} copies of this card"),
                // The instruction ("circle two colors") has no typed effect.
                None => "A deck-construction instruction with no modeled game effect".to_string(),
            };
        }
        fn title_case_name_fragment(name: &str) -> String {
            name.split_whitespace()
                .map(|part| {
                    let mut chars = part.chars();
                    let Some(first) = chars.next() else {
                        return String::new();
                    };
                    format!(
                        "{}{}",
                        first.to_ascii_uppercase(),
                        chars.as_str().to_ascii_lowercase()
                    )
                })
                .collect::<Vec<_>>()
                .join(" ")
        }

        if let Some((prefix, name)) = self.text.rsplit_once("cards named ") {
            let name = name.trim_end_matches('.');
            return format!("{prefix}cards named {}.", title_case_name_fragment(name));
        }
        self.text.clone()
    }
}

/// A dungeon's entry restriction: "You can't enter this dungeon unless you
/// 'venture into [quality].'" (CR 701.49d). It functions outside the game:
/// the venture action reads it when choosing a dungeon to bring in.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct DungeonEntryRestriction {
    pub quality: String,
}

impl DungeonEntryRestriction {
    pub fn new(quality: impl Into<String>) -> Self {
        Self {
            quality: quality.into(),
        }
    }
}

impl StaticAbilityKind for DungeonEntryRestriction {
    fn id(&self) -> StaticAbilityId {
        StaticAbilityId::DungeonEntryRestriction
    }

    fn display(&self) -> String {
        format!(
            "You can't enter this dungeon unless you \"venture into {}.\"",
            self.quality
        )
    }

    fn dungeon_entry_quality(&self) -> Option<&str> {
        Some(&self.quality)
    }
}

// =============================================================================
// Placeholder / Marker Abilities
// =============================================================================

/// CR 702.47 splice ability that functions from its card's owner's hand.
#[derive(Debug, Clone, PartialEq)]
pub struct SpliceAbility {
    pub spec: crate::static_abilities::SpliceSpec<crate::costs::Cost>,
}

impl SpliceAbility {
    pub fn new(spec: crate::static_abilities::SpliceSpec<crate::costs::Cost>) -> Self {
        Self { spec }
    }
}

impl StaticAbilityKind for SpliceAbility {
    fn id(&self) -> StaticAbilityId {
        if self.spec.descriptive { StaticAbilityId::KeywordMarker } else { StaticAbilityId::Splice }
    }

    fn display(&self) -> String {
        let separator = if self.spec.cost.has_non_mana_costs() {
            "—"
        } else {
            " "
        };
        let rendered_cost = self
            .spec
            .cost_surface
            .clone()
            .unwrap_or_else(|| self.spec.cost.display());
        if self.spec.descriptive {
            let zone = self.spec.source_zone.unwrap_or(crate::zone::Zone::Hand);
            let movement = match self.spec.source_destination {
                None => format!("reveal this card from your {zone}"),
                Some(crate::zone::Zone::Exile) => format!("exile this card from your {zone}"),
                Some(destination) => format!("put this card from your {zone} into {destination}"),
            };
            let mut text = format!("As you cast an {} spell, you may {movement} and pay {rendered_cost}. If you do, add this card's effects to that spell.", self.spec.quality.oracle_surface());
            if let Some(max) = self.spec.max_per_spell {
                if self.spec.source_destination == Some(crate::zone::Zone::Exile) && max == 1 {
                    text.push_str(" You may exile only one card this way per spell.");
                } else {
                    text.push_str(&format!(" You may move only {max} cards this way per spell."));
                }
            }
            if let Some(keyword)=&self.spec.custom_keyword {
                text.push_str(&format!(" This text-adding cost is named {keyword}."));
            }
            text
        } else { format!("Splice onto {}{separator}{rendered_cost}", self.spec.quality.oracle_surface()) }
    }

    fn splice_spec(&self) -> Option<&crate::static_abilities::SpliceSpec<crate::costs::Cost>> {
        Some(&self.spec)
    }
}

/// CR 702.120 escalate ability that adds its typed cost per mode beyond the first.
#[derive(Debug, Clone, PartialEq)]
pub struct EscalateAbility {
    pub spec: crate::static_abilities::EscalateSpec<crate::costs::Cost>,
}

impl EscalateAbility {
    pub fn new(spec: crate::static_abilities::EscalateSpec<crate::costs::Cost>) -> Self {
        Self { spec }
    }
}

impl StaticAbilityKind for EscalateAbility {
    fn id(&self) -> StaticAbilityId {
        if self.spec.descriptive { StaticAbilityId::KeywordMarker } else { StaticAbilityId::Escalate }
    }

    fn display(&self) -> String {
        let separator = if self.spec.cost.has_non_mana_costs() {
            "—"
        } else {
            " "
        };
        let rendered_cost = self
            .spec
            .cost_surface
            .clone()
            .unwrap_or_else(|| self.spec.cost.display());
        if self.spec.descriptive { format!("Pay {rendered_cost} for each mode chosen beyond the first.") }
        else { format!("Escalate{separator}{rendered_cost}") }
    }

    fn escalate_spec(&self) -> Option<&crate::static_abilities::EscalateSpec<crate::costs::Cost>> {
        Some(&self.spec)
    }
}

/// Semantic keyword label for a keyword whose runtime semantics are implemented elsewhere.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct KeywordMarker {
    pub marker: String,
    pub mechanic: Option<ironsmith_core::KeywordMarkerMechanic>,
}

impl KeywordMarker {
    pub fn new(marker: impl Into<String>) -> Self {
        let marker = marker.into();
        let mechanic = ironsmith_core::keyword_marker_mechanic(&marker);
        Self::typed(marker, mechanic)
    }

    pub fn typed(
        marker: impl Into<String>,
        mechanic: Option<ironsmith_core::KeywordMarkerMechanic>,
    ) -> Self {
        Self { marker: marker.into(), mechanic }
    }
}

impl StaticAbilityKind for KeywordMarker {
    fn generate_replacement_effect(
        &self, source: ObjectId, controller: PlayerId,
    ) -> Option<ReplacementEffect> {
        if self.mechanic != Some(ironsmith_core::KeywordMarkerMechanic::DestroyAttachmentInstead) {
            return None;
        }
        // Share the transaction and matcher, not the native keyword identity.
        UmbraArmor.generate_replacement_effect(source, controller)
    }

    fn has_delve(&self) -> bool {
        self.mechanic == Some(ironsmith_core::KeywordMarkerMechanic::ExileGraveyardCardsForGenericMana)
    }
    fn has_convoke(&self) -> bool {
        self.mechanic == Some(ironsmith_core::KeywordMarkerMechanic::TapCreaturesForMana)
    }
    fn has_improvise(&self) -> bool {
        self.mechanic == Some(ironsmith_core::KeywordMarkerMechanic::TapArtifactsForGenericMana)
    }

    fn id(&self) -> StaticAbilityId {
        StaticAbilityId::KeywordMarker
    }

    fn keyword_marker_mechanic(&self) -> Option<ironsmith_core::KeywordMarkerMechanic> {
        self.mechanic.clone()
    }

    fn display(&self) -> String {
        const MORE_THAN_MEETS_THE_EYE: &str = "more than meets the eye";
        let trimmed = self.marker.trim();
        if let Some(prefix) = trimmed.get(..MORE_THAN_MEETS_THE_EYE.len())
            && prefix.eq_ignore_ascii_case(MORE_THAN_MEETS_THE_EYE)
            && trimmed[MORE_THAN_MEETS_THE_EYE.len()..]
                .chars()
                .next()
                .is_none_or(char::is_whitespace)
        {
            return format!(
                "More Than Meets the Eye{}",
                &trimmed[MORE_THAN_MEETS_THE_EYE.len()..]
            );
        }
        self.marker.clone()
    }
}

/// Inert compiled-text provenance for keywords authored on one source line.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct SourceLineKeywordGroup {
    pub keyword_count: usize,
}

impl SourceLineKeywordGroup {
    pub const fn new(keyword_count: usize) -> Self {
        Self { keyword_count }
    }
}

impl StaticAbilityKind for SourceLineKeywordGroup {
    fn id(&self) -> StaticAbilityId {
        StaticAbilityId::SourceLineKeywordGroup
    }

    fn display(&self) -> String {
        String::new()
    }
}

/// Inert compiled-text provenance for static models from one source line.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct SourceLineStaticGroup {
    pub member_count: usize,
}

impl SourceLineStaticGroup {
    pub const fn new(member_count: usize) -> Self {
        Self { member_count }
    }
}

impl StaticAbilityKind for SourceLineStaticGroup {
    fn may_generate_continuous_effects(&self) -> bool {
        false
    }

    fn id(&self) -> StaticAbilityId {
        StaticAbilityId::SourceLineStaticGroup
    }

    fn source_line_static_group_member_count(&self) -> Option<usize> {
        Some(self.member_count)
    }

    fn display(&self) -> String {
        String::new()
    }
}

/// Allows a player to continuously see the top card of their library.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct LookAtTopCardOfLibrary;

impl StaticAbilityKind for LookAtTopCardOfLibrary {
    fn id(&self) -> StaticAbilityId {
        StaticAbilityId::LookAtTopCardOfLibrary
    }

    fn display(&self) -> String {
        "You may look at the top card of your library any time.".to_string()
    }
}

/// Allows a player to continuously see face-down creatures they do not control.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct LookAtFaceDownCreaturesYouDontControl;

impl StaticAbilityKind for LookAtFaceDownCreaturesYouDontControl {
    fn id(&self) -> StaticAbilityId {
        StaticAbilityId::LookAtFaceDownCreaturesYouDontControl
    }

    fn display(&self) -> String {
        "You may look at face-down creatures you don't control any time.".to_string()
    }
}

/// Allows every player to continuously see the top card of every library.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct AllPlayersLookAtTopCardsOfLibraries;

impl StaticAbilityKind for AllPlayersLookAtTopCardsOfLibraries {
    fn id(&self) -> StaticAbilityId {
        StaticAbilityId::AllPlayersLookAtTopCardsOfLibraries
    }

    fn display(&self) -> String {
        "Players play with the top card of their libraries revealed.".to_string()
    }
}

/// Allows every player to continuously see the controller's top library card.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct AllPlayersLookAtYourTopLibraryCard;

impl StaticAbilityKind for AllPlayersLookAtYourTopLibraryCard {
    fn id(&self) -> StaticAbilityId {
        StaticAbilityId::AllPlayersLookAtYourTopLibraryCard
    }

    fn display(&self) -> String {
        "Play with the top card of your library revealed.".to_string()
    }
}

/// Public hand visibility is enforced by both the live sync view and cached
/// UI snapshot. These scopes do not reveal an unrelated player's library.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ControllerPlaysWithHandRevealed;
impl StaticAbilityKind for ControllerPlaysWithHandRevealed {
    fn id(&self) -> StaticAbilityId { StaticAbilityId::ControllerPlaysWithHandRevealed }
    fn display(&self) -> String { "Play with your hand revealed.".into() }
}
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct PlayersPlayWithHandsRevealed;
impl StaticAbilityKind for PlayersPlayWithHandsRevealed {
    fn id(&self) -> StaticAbilityId { StaticAbilityId::PlayersPlayWithHandsRevealed }
    fn display(&self) -> String { "Players play with their hands revealed.".into() }
}

/// Makes the controller's opponents play with revealed hands.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct OpponentsPlayWithHandsRevealed;

impl StaticAbilityKind for OpponentsPlayWithHandsRevealed {
    fn id(&self) -> StaticAbilityId {
        StaticAbilityId::OpponentsPlayWithHandsRevealed
    }

    fn display(&self) -> String {
        "Your opponents play with their hands revealed.".to_string()
    }
}

/// Controls opponents during their library searches.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ControlOpponentsWhileSearchingLibraries;

impl StaticAbilityKind for ControlOpponentsWhileSearchingLibraries {
    fn id(&self) -> StaticAbilityId {
        StaticAbilityId::ControlOpponentsWhileSearchingLibraries
    }

    fn display(&self) -> String {
        "You control your opponents while they're searching their libraries.".to_string()
    }
}

/// Replaces opponents' found search cards with exile and grants play permission.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct OpponentSearchExileFoundCards;

impl StaticAbilityKind for OpponentSearchExileFoundCards {
    fn id(&self) -> StaticAbilityId {
        StaticAbilityId::OpponentSearchExileFoundCards
    }

    fn display(&self) -> String {
        "While an opponent is searching their library, they exile each card they find. You may play those cards for as long as they remain exiled, and you may spend mana as though it were mana of any color to cast them.".to_string()
    }
}

/// Allows this card to be cast from the library while its owner is searching it.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct CastThisCardFromLibraryWhileSearching;

impl StaticAbilityKind for CastThisCardFromLibraryWhileSearching {
    fn id(&self) -> StaticAbilityId {
        StaticAbilityId::CastThisCardFromLibraryWhileSearching
    }

    fn display(&self) -> String {
        "While you're searching your library, you may cast this card from your library.".to_string()
    }
}

/// Typed fallback keyword text preserved from parser/builder.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct KeywordFallbackText {
    pub text: String,
}

impl KeywordFallbackText {
    pub fn new(text: impl Into<String>) -> Self {
        Self { text: text.into() }
    }
}

impl StaticAbilityKind for KeywordFallbackText {
    fn id(&self) -> StaticAbilityId {
        StaticAbilityId::KeywordFallbackText
    }

    fn display(&self) -> String {
        // Nothing but retained prose backs this ability: an audit reports it.
        ironsmith_core::semantic_audit::retained("KeywordFallbackText", &self.text, self)
    }
}

/// Typed fallback static rule text preserved from parser/builder.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct RuleFallbackText {
    pub text: String,
}

impl RuleFallbackText {
    pub fn new(text: impl Into<String>) -> Self {
        Self { text: text.into() }
    }
}

impl StaticAbilityKind for RuleFallbackText {
    fn id(&self) -> StaticAbilityId {
        StaticAbilityId::RuleFallbackText
    }

    fn display(&self) -> String {
        // Nothing but retained prose backs this ability: an audit reports it.
        ironsmith_core::semantic_audit::retained("RuleFallbackText", &self.text, self)
    }
}

/// Parser fallback marker used in allow-unsupported mode.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct UnsupportedParserLine {
    pub raw_line: String,
    pub reason: String,
}

impl UnsupportedParserLine {
    pub fn new(raw_line: impl Into<String>, reason: impl Into<String>) -> Self {
        Self {
            raw_line: raw_line.into(),
            reason: reason.into(),
        }
    }
}

impl StaticAbilityKind for UnsupportedParserLine {
    fn id(&self) -> StaticAbilityId {
        StaticAbilityId::UnsupportedParserLine
    }

    fn display(&self) -> String {
        format!(
            "Unsupported parser line fallback: {} ({})",
            self.raw_line.trim(),
            self.reason
        )
    }
}

/// One typed prevention family, preserving live source/recipient filters.
#[derive(Debug, Clone, PartialEq)]
pub struct PreventMatchingDamage {
    pub spec: ironsmith_core::PreventMatchingDamageSpec,
    pub condition: Option<crate::ConditionExpr>,
}

impl StaticAbilityKind for PreventMatchingDamage {
    fn id(&self) -> StaticAbilityId {
        StaticAbilityId::PreventMatchingDamage
    }

    fn display(&self) -> String {
        // The static gate ("As long as this artifact is untapped") leads the
        // printed prevention rule.
        let Some(condition) = &self.condition else { return self.spec.display.clone() };
        let condition = crate::static_abilities::continuous::describe_static_condition(condition);
        let Some(gate) = condition.strip_prefix("as long as ") else {
            return self.spec.display.clone();
        };
        format!("As long as {gate}, {}", self.spec.display)
    }

    fn with_static_condition(&self, condition: crate::ConditionExpr) -> Option<StaticAbility> {
        let mut next = self.clone();
        next.condition = Some(match next.condition.take() {
            Some(old) => crate::ConditionExpr::And(Box::new(old), Box::new(condition)),
            None => condition,
        });
        Some(StaticAbility::new(next))
    }

    fn generate_replacement_effect(
        &self,
        source: ObjectId,
        controller: PlayerId,
    ) -> Option<ReplacementEffect> {
        Some(ReplacementEffect::with_matcher(
            source,
            controller,
            DamageAmountReplacementMatcher {
                source_filter: self.spec.source_filter.clone(),
                target_player_filter: self.spec.target_player_filter.clone(),
                target_object_filter: self.spec.target_object_filter.clone(),
                condition: self.condition.clone(),
                combat_only: self.spec.combat_only,
                noncombat_only: self.spec.noncombat_only,
                amount_less_than: None,
                maximum_damage: self.spec.maximum_damage,
            },
            ReplacementAction::PreventDamageByRule(self.spec.amount.clone()),
        ).with_controller_option(self.spec.optional_by_controller))
    }
}


#[derive(Debug, Clone, PartialEq)]
pub struct PreventMatchingDamageWithFollowUp {
    pub spec: ironsmith_core::StaticDamagePreventionFollowUp<Effect>,
}

impl StaticAbilityKind for PreventMatchingDamageWithFollowUp {
    fn id(&self) -> StaticAbilityId { StaticAbilityId::PreventMatchingDamage }
    fn display(&self) -> String { self.spec.display.clone() }

    fn generate_replacement_effect(&self, source: ObjectId, controller: PlayerId) -> Option<ReplacementEffect> {
        let mut effects = Vec::new();
        if let Some(tag) = &self.spec.damage_source_tag {
            effects.push(Effect::tag_triggering_source(tag.clone()));
        }
        effects.extend(self.spec.effects.iter().cloned());
        Some(ReplacementEffect::with_matcher(
            source, controller,
            DamageAmountReplacementMatcher {
                source_filter: self.spec.source_filter.clone(),
                target_player_filter: self.spec.target_player_filter.clone(),
                target_object_filter: self.spec.target_object_filter.clone(),
                condition: None,
                combat_only: self.spec.combat_only,
                noncombat_only: self.spec.noncombat_only,
                amount_less_than: None,
                maximum_damage: None,
            },
            match self.spec.amount_basis {
                ironsmith_core::PreventionFollowUpAmount::Prevented =>
                    ReplacementAction::PreventDamageThen(effects),
                ironsmith_core::PreventionFollowUpAmount::Proposed =>
                    ReplacementAction::PreventDamageThenFromProposedAmount(effects),
            },
        ))
    }
}


/// One additive life-gain replacement, participating in the ordinary CR 616
/// ordering and replacement-application identity machinery.
#[derive(Debug, Clone, PartialEq)]
pub struct AddLifeGainReplacement {
    pub player: PlayerFilter,
    pub additional: i32,
    pub condition: Option<Condition>,
    pub display: String,
}

impl StaticAbilityKind for AddLifeGainReplacement {
    fn id(&self) -> StaticAbilityId { StaticAbilityId::AddLifeGainReplacement }
    fn display(&self) -> String { ironsmith_core::semantic_audit::retained("AddLifeGainReplacement", &self.display, self) }
    fn with_static_condition(&self, condition: crate::ConditionExpr) -> Option<StaticAbility> {
        let mut combined = self.clone();
        combined.condition = Some(match combined.condition.take() {
            Some(existing) => Condition::And(Box::new(condition), Box::new(existing)),
            None => condition,
        });
        Some(StaticAbility::new(combined))
    }
    fn generate_replacement_effect(&self, source: ObjectId, controller: PlayerId) -> Option<ReplacementEffect> {
        Some(ReplacementEffect::with_matcher(source, controller,
            ConditionalWouldChangeLifeMatcher {
                player: self.player.clone(), loss: false,
                condition: self.condition.clone(), display: self.display.clone(),
            },
            ReplacementAction::Modify(EventModification::Add(self.additional)),
        ))
    }
}

/// Fixed token additions/substitutions retain complete lowered definitions.
#[derive(Debug, Clone, PartialEq)]
pub struct TokenCreationTemplates {
    pub controller: PlayerFilter,
    pub token_filter: ObjectFilter,
    pub templates: Vec<crate::effect::Effect>,
    pub mode: ironsmith_core::TokenCreationTemplateMode,
    pub optional: bool,
    pub choose_one: bool,
    pub display: String,
    pub condition: Option<crate::ConditionExpr>,
}
impl StaticAbilityKind for TokenCreationTemplates {
    fn id(&self) -> StaticAbilityId { StaticAbilityId::TokenCreationTemplates }
    fn display(&self) -> String { ironsmith_core::semantic_audit::retained("TokenCreationTemplates", &self.display, self) }
    fn with_static_condition(&self, condition: crate::ConditionExpr) -> Option<StaticAbility> {
        let mut next = self.clone();
        next.condition = Some(match next.condition { Some(old) => crate::ConditionExpr::And(Box::new(old), Box::new(condition)), None => condition });
        Some(StaticAbility::new(next))
    }
    fn generate_replacement_effect(&self, source: ObjectId, controller: PlayerId) -> Option<ReplacementEffect> {
        let effect = ReplacementEffect::with_matcher(source, controller,
            crate::events::tokens::matchers::WouldCreateTokensUnderControlMatcher::new(self.controller.clone())
                .with_token_filter(self.token_filter.clone()).with_condition(self.condition.clone()),
            ReplacementAction::TokenCreationTemplates { templates: self.templates.clone(), mode: self.mode, choose_one: self.choose_one, choice_parent: None });
        Some(if self.optional { effect.optional() } else { effect })
    }
}


#[derive(Debug, Clone, PartialEq)]
pub struct RedirectMatchingDamage {
    pub spec: ironsmith_core::StaticDamageRedirectionSpec,
    pub condition: Option<crate::ConditionExpr>,
}
impl StaticAbilityKind for RedirectMatchingDamage {
    fn id(&self) -> StaticAbilityId { StaticAbilityId::RedirectMatchingDamage }
    fn display(&self) -> String {
        // The static gate ("As long as this creature is untapped") is part of
        // the printed ability, ahead of the redirection itself.
        let Some(condition) = &self.condition else { return self.spec.display.clone() };
        let condition = crate::static_abilities::continuous::describe_static_condition(condition);
        let Some(gate) = condition.strip_prefix("as long as ") else {
            return self.spec.display.clone();
        };
        format!("As long as {gate}, {}", self.spec.display)
    }
    fn with_static_condition(&self, condition: crate::ConditionExpr) -> Option<StaticAbility> {
        let mut next = self.clone();
        next.condition = Some(match next.condition.take() {
            Some(old) => crate::ConditionExpr::And(Box::new(old), Box::new(condition)),
            None => condition,
        });
        Some(StaticAbility::new(next))
    }
    fn generate_replacement_effect(&self, source: ObjectId, controller: PlayerId) -> Option<ReplacementEffect> {
        let mut condition = self.condition.clone();
        if self.spec.source_must_be_untapped {
            condition = Some(match condition {
                Some(old) => crate::ConditionExpr::And(Box::new(old), Box::new(crate::ConditionExpr::SourceIsUntapped)),
                None => crate::ConditionExpr::SourceIsUntapped,
            });
        }
        let target = match self.spec.destination {
            ironsmith_core::StaticDamageRedirectDestination::Source => RedirectTarget::ToObject(source),
            ironsmith_core::StaticDamageRedirectDestination::AttachedPermanent => RedirectTarget::ToAttachedPermanent(source),
            ironsmith_core::StaticDamageRedirectDestination::DamagedPermanentController => RedirectTarget::ToRecipientController,
        };
        Some(ReplacementEffect::with_matcher(source, controller,
            DamageAmountReplacementMatcher {
                source_filter: self.spec.source_filter.clone(),
                target_player_filter: self.spec.target_player_filter.clone(),
                target_object_filter: self.spec.target_object_filter.clone(),
                condition, combat_only: self.spec.combat_only, noncombat_only: self.spec.noncombat_only,
                amount_less_than: None, maximum_damage: None,
            },
            if self.spec.excess_only {
                ReplacementAction::RedirectExcessDamage { target, which: RedirectWhich::First }
            } else {
                ReplacementAction::Redirect { target, which: RedirectWhich::First }
            },
        ))
    }
}

/// Typed mana-production rewriting. Live static occurrence discovery owns the
/// supplying host's zones, controller and phase-out; this matcher owns the
/// distinct production source/controller and its recorded provenance.
#[derive(Debug, Clone, PartialEq)]
pub struct ManaProductionRewrite {
    pub rule: ironsmith_core::ManaOutputRewrite,
    pub display: String,
}
impl StaticAbilityKind for ManaProductionRewrite {
    fn id(&self) -> StaticAbilityId { StaticAbilityId::ManaProductionRewrite }
    fn display(&self) -> String { ironsmith_core::semantic_audit::retained("ManaProductionRewrite", &self.display, self) }
    fn generate_replacement_effect(&self, source: ObjectId, controller: PlayerId) -> Option<ReplacementEffect> {
        Some(ReplacementEffect::with_matcher(source, controller,
            crate::events::mana::matchers::ManaRewriteMatcher {rule: self.rule.clone()},
            ReplacementAction::RewriteMana {input: self.rule.input, output: self.rule.output,
                quantity: self.rule.quantity}))
    }
}

/// CR 106.4 / 106.6: conversion changes the existing mana's type. It does not produce
/// new mana and does not discard source restrictions or producer snapshots.
#[derive(Debug, Clone, PartialEq)]
pub struct ConvertUnspentMana { pub player: crate::target::PlayerFilter, pub symbol: crate::mana::ManaSymbol }
impl StaticAbilityKind for ConvertUnspentMana {
    fn id(&self) -> StaticAbilityId { StaticAbilityId::ConvertUnspentMana }
    fn display(&self) -> String { format!("If {} would lose unspent mana, that mana becomes {} instead", self.player.description(), format!("{:?}", self.symbol).to_ascii_lowercase()) }
    fn generate_replacement_effect(&self, source: ObjectId, controller: PlayerId) -> Option<ReplacementEffect> {
        Some(ReplacementEffect::with_matcher(source, controller,
            crate::events::mana::matchers::ManaLossMatcher { player: self.player.clone() },
            ReplacementAction::ConvertUnspentMana(self.symbol)))
    }
}

/// Event-time correlation between two different members of a chosen-player set.
#[derive(Debug, Clone)]
pub(crate) struct ChosenPlayersDamageMatcher { pub ability_source: ObjectId }
impl ReplacementMatcher for ChosenPlayersDamageMatcher {
    fn matches_prepared_event(&self, event: &dyn crate::events::traits::GameEventType,
        ctx: &crate::events::context::PreparedEventContext) -> bool {
        let Some(damage) = downcast_event::<DamageEvent>(event) else { return false; };
        let chosen = ctx.game.chosen_players(self.ability_source);
        let source_controller = ctx.game.current_controller(damage.source).or_else(||
            ctx.event_source_snapshot.filter(|snapshot| snapshot.object_id == damage.source).map(|snapshot| snapshot.controller));
        let recipient = match damage.target {
            crate::events::DamageTarget::Player(player) => Some(player),
            crate::events::DamageTarget::Object(id) => ctx.game.object(id)
                .filter(|object| object.zone == Zone::Battlefield && !ctx.game.is_phased_out(id))
                .and_then(|_| ctx.game.current_controller(id)),
        };
        match (source_controller, recipient) {
            (Some(from), Some(to)) => from != to && chosen.contains(&from) && chosen.contains(&to),
            _ => false,
        }
    }
    fn priority(&self) -> ReplacementPriority { ReplacementPriority::Other }
    fn display(&self) -> String { "damage between different chosen players".into() }
}

#[derive(Debug,Clone)]
pub struct CounterKindReplacement {
    pub filter:ObjectFilter,
    pub cause:crate::events::cause::CauseFilter,
    pub kinds:Vec<CounterType>,
    pub display:String,
}
impl StaticAbilityKind for CounterKindReplacement {
    fn id(&self)->StaticAbilityId{StaticAbilityId::CounterKindReplacement}
    fn display(&self)->String{self.display.clone()}
    fn generate_replacement_effect(&self,source:ObjectId,controller:PlayerId)->Option<ReplacementEffect>{
        Some(ReplacementEffect::with_matcher(source,controller,CounterKindProducerMatcher{
            source,controller,filter:self.filter.clone(),cause:self.cause.clone(),
        },ReplacementAction::RewriteCounterKinds{kinds:self.kinds.clone(),cause:self.cause.clone(),selected:None}))
    }
}

#[derive(Debug,Clone)]
struct CounterKindProducerMatcher{source:ObjectId,controller:PlayerId,filter:ObjectFilter,cause:crate::events::cause::CauseFilter}
impl ReplacementMatcher for CounterKindProducerMatcher {
 fn applies_from_entering_source(&self)->bool{self.filter.source}
 fn matches_prepared_event(&self,event:&dyn crate::events::traits::GameEventType,ctx:&crate::events::context::PreparedEventContext)->bool{
  use crate::events::cause::CauseFilterRuntimeExt as _;
  if let Some(placement)=downcast_event::<crate::events::PutCountersEvent>(event){
   if placement.count==0{return false;}
   // Missing effect producer facts are a possible match, not a false one;
   // the fallible admission boundary reports incomplete after recipient scope.
   let unknown=placement.cause.cause_type.is_effect_like()&&(placement.cause.source.is_none()||placement.cause.source_controller.is_none());
   return WouldPutCountersOrEnterWithCountersMatcher{ability_source:self.source,controller:self.controller,filter:self.filter.clone(),player_filter:None,counter_type:None,actor:None,includes_permanents:false,effect_only:false,cause_filter:if unknown{None}else{Some(self.cause.clone())}}.matches_prepared_event(event,ctx);
  }
  let Some(entry)=downcast_event::<EnterBattlefieldEvent>(event)else{return false};
  if (entry.object==self.source&&!self.filter.source)||entry.prepared_choices.is_none(){return false;}
  let Some(world)=ctx.prospective_entry_world(entry.object)else{return false};
  // CR614.17c: an ordinary replacement cannot rescue a prohibited placement.
  if !entry.enters_with_counters.iter().any(|(kind,count)|*count>0&&world.can_have_counter_type_placed(entry.object,*kind)){return false;}
  (entry.validate_counter_producer_receipts().is_err()||entry.counter_producer_receipts.iter().any(|receipt|receipt.count>0&&world.can_have_counter_type_placed(entry.object,receipt.kind)&&self.cause.matches(&receipt.cause,ctx.game,self.controller)))
   &&crate::events::zones::matchers::WouldEnterBattlefieldMatcher::new(self.filter.clone()).matches_prepared_event(event,ctx)
 }
 fn priority(&self)->ReplacementPriority{ReplacementPriority::Other}
 fn display(&self)->String{"cause-scoped counter-kind replacement".into()}
}
