//! Apply replacement effect implementation.

use crate::effect::EffectOutcome;
use crate::effects::{EffectExecutionCategory, EffectExecutor};
use crate::effects::{ExecutionContext, ExecutionError};
use crate::game_state::GameState;
use crate::replacement::ReplacementEffect;
pub use ironsmith_core::ReplacementApplyMode;

/// Effect that registers a replacement effect with the game state.
#[derive(Debug, Clone)]
pub struct ApplyReplacementEffect {
    /// The replacement effect to register.
    pub effect: ReplacementEffect,
    /// How to register it.
    pub mode: ReplacementApplyMode,
}

impl ApplyReplacementEffect {
    pub fn one_shot(effect: ReplacementEffect) -> Self {
        Self {
            effect,
            mode: ReplacementApplyMode::OneShot,
        }
    }

    pub fn resolution(effect: ReplacementEffect) -> Self {
        Self {
            effect,
            mode: ReplacementApplyMode::Resolution,
        }
    }

    pub fn until_end_of_turn(effect: ReplacementEffect) -> Self {
        Self {
            effect,
            mode: ReplacementApplyMode::UntilEndOfTurn,
        }
    }
}

impl EffectExecutor for ApplyReplacementEffect {
    fn execute(
        &self,
        game: &mut GameState,
        _ctx: &mut ExecutionContext,
    ) -> Result<EffectOutcome, ExecutionError> {
        let effect=self.effect.clone().with_producer_cause(_ctx.cause.clone());
        match self.mode {
            ReplacementApplyMode::OneShot => {
                game.effect_store
                    .replacement_effects
                    .add_one_shot_effect(effect.clone());
            }
            ReplacementApplyMode::UntilEndOfTurn => {
                game.effect_store
                    .replacement_effects
                    .add_until_end_of_turn_effect(effect.clone());
            }
            ReplacementApplyMode::UntilYourNextTurn => {
                game.effect_store
                    .replacement_effects
                    .add_until_next_turn_effect(
                        effect.clone(),
                        _ctx.controller,
                        game.turn.turn_number,
                    );
            }
            ReplacementApplyMode::Resolution => {
                game.effect_store
                    .replacement_effects
                    .add_resolution_effect(effect.clone());
            }
        }

        Ok(EffectOutcome::resolved())
    }

    fn primary_execution_category(&self) -> EffectExecutionCategory {
        EffectExecutionCategory::ReplacementRegistration
    }
}
