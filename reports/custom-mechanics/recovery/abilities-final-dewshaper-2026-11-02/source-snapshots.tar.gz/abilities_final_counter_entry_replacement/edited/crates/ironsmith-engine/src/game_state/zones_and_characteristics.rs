use super::*;

#[derive(Debug, Clone, Default)]
pub(crate) struct PreparedEtbChoices {
    /// An entry program put the entering object into this zone instead of
    /// onto the battlefield (Frankenstein's Monster).
    pub(crate) entry_redirect: Option<Zone>,
    /// An entry program tapped the entering object ("You may have this land
    /// enter tapped"), so it enters tapped.
    pub(crate) as_enters_tapped: bool,
    pub(crate) as_enters_designations: Vec<ironsmith_core::PermanentDesignation>,
    pub(crate) as_enters_named_actions: Vec<(String,crate::player::ManaPool)>,
    pub(crate) chosen_color: Option<crate::color::Color>,
    /// "choose two colors": the chosen colors, recorded together.
    pub(crate) chosen_color_set: Option<crate::color::ColorSet>,
    pub(crate) chosen_basic_land_type: Option<crate::types::Subtype>,
    /// "choose two basic land types": every chosen type, in choice order.
    pub(crate) chosen_basic_land_type_sequence: Option<Vec<crate::types::Subtype>>,
    pub(crate) chosen_land_type: Option<crate::types::Subtype>,
    pub(crate) chosen_creature_type: Option<crate::types::Subtype>,
    pub(crate) chosen_card_type: Option<crate::types::CardType>,
    pub(crate) chosen_player: Option<PlayerId>,
    /// "choose two players": the chosen players, in choice order.
    pub(crate) chosen_player_set: Option<Vec<PlayerId>>,
    pub(crate) chosen_named_option: Option<String>,
    /// "each player chooses <A> or <B>": every player's option.
    pub(crate) player_named_options: Vec<(PlayerId, String)>,
    pub(crate) noted_life_total: Option<i32>,
    pub(crate) power_toughness_choices:
        Vec<crate::static_abilities::PowerToughnessChoiceOption>,
    pub(crate) battle_protector: Option<PlayerId>,
    pub(crate) discard_hand: bool,
    pub(crate) as_enters_counters: Vec<(crate::object::CounterType, u32)>,
    pub(crate) as_enters_counter_receipts: Vec<crate::events::zones::EntryCounterProducerReceipt>,
    pub(crate) as_enters_tagged_objects:
        std::collections::HashMap<crate::tag::TagKey, Vec<crate::snapshot::ObjectSnapshot>>,
    pub(crate) transfer_as_enters_source_links: bool,
    pub(crate) as_enters_linked_exile: Vec<EntryLinkedExileTransfer>,
    pub(crate) as_enters_continuous_effects: Vec<crate::continuous::ContinuousEffectId>,
    /// Actual programme packets; metadata clones share their producer handles.
    pub(crate) as_enters_outputs: Vec<crate::effects::PublishedEffectOutputs>,
    /// Exact native acquisition shared by prospective and committed duration copies.
    pub(crate) entry_copy_registration: Option<crate::continuous::ContinuousEffectId>,
}

/// Only relationships actually created by an as-enters program cross entry.
#[derive(Debug, Clone)]
pub(crate) struct EntryLinkedExileTransfer {
    pub(crate) owner: crate::linked_exile::LinkedExileOwner,
    pub(crate) members: Vec<ObjectId>,
    pub(crate) aliases: Vec<crate::linked_exile::LinkedExileOwner>,
}

/// Real source cards represented by one prospective entering permanent.
#[derive(Debug, Clone)]
pub(crate) struct PreparedEntryComponent {
    pub(crate) snapshot: crate::snapshot::ObjectSnapshot,
    pub(crate) original_definition: crate::cards::CardDefinition,
}

#[derive(Debug, Clone)]
pub(crate) struct PreparedEtbEntry {
    pub(crate) result: crate::events::processing::EtbEventResult,
    pub(crate) choices: PreparedEtbChoices,
    /// Frozen by an owning zone operation before replacement programs run.
    pub(crate) zone_entry_lookback: Option<Vec<crate::snapshot::ObjectSnapshot>>,
    /// Authored entry face; movement establishes it before resolved copy and
    /// characteristic replacements are applied, never afterward.
    pub(crate) entry_definition: Option<crate::cards::CardDefinition>,
    pub(crate) physical_components: Vec<PreparedEntryComponent>,
    pub(crate) linked_face_mana_cost: Option<crate::mana::ManaCost>,
    /// Attachment specified by the authoring effect, validated during this commit.
    pub(crate) entry_attachment: Option<AttachmentTarget>,
    pub(crate) entry_attachment_requires_aura: bool,
    pub(crate) entry_attachment_specified: bool,
    /// Further restricts what an Aura entering without a fixed attachment may
    /// choose to enchant ("Only creatures can be enchanted this way"). With
    /// it, an Aura that would enchant a player has no legal choice.
    pub(crate) entry_attachment_filter: Option<crate::filter::ObjectFilter>,
}

fn named_color_creature_type_option(
    game: &GameState,
    option: &str,
) -> Option<(crate::color::Color, crate::types::Subtype)> {
    let mut words = option.split_whitespace();
    let color = crate::color::Color::from_name(&words.next()?.to_ascii_lowercase())?;
    let subtype_name = words.collect::<Vec<_>>().join(" ");
    if subtype_name.is_empty() {
        return None;
    }
    let subtype = game.subtypes_in_family(crate::types::SubtypeFamily::Creature)
        .iter()
        .copied()
        .find(|subtype| subtype.to_string().eq_ignore_ascii_case(&subtype_name))?;
    Some((color, subtype))
}

/// A named as-enters option that is exactly one creature or land subtype.
fn named_subtype_option(game: &GameState, option: &str) -> Option<crate::types::Subtype> {
    let name = option.trim();
    if name.is_empty() {
        return None;
    }
    [
        crate::types::SubtypeFamily::Creature,
        crate::types::SubtypeFamily::Land,
    ]
    .into_iter()
    .flat_map(|family| game.subtypes_in_family(family))
    .find(|subtype| subtype.to_string().eq_ignore_ascii_case(name))
}

fn as_enters_effect_program_from_ability(
    ability: &crate::ability::Ability,
) -> Option<(crate::resolution::ResolutionProgram, bool, bool)> {
    let crate::ability::AbilityKind::Static(static_ability) = &ability.kind else {
        return None;
    };
    let ironsmith_core::StaticAbilityPayload::AsEntersEffectProgram {
        program,
        also_turns_face_up,
        turns_face_up_only,
        transforms_into,
        ..
    } = &static_ability.compiled_model()?.payload
    else {
        return None;
    };
    if transforms_into.is_some() {
        return None;
    }
    Some((program.clone(), *also_turns_face_up, *turns_face_up_only))
}

fn as_transforms_effect_program_from_ability(
    ability: &crate::ability::Ability,
) -> Option<crate::resolution::ResolutionProgram> {
    let crate::ability::AbilityKind::Static(static_ability) = &ability.kind else {
        return None;
    };
    let ironsmith_core::StaticAbilityPayload::AsEntersEffectProgram {
        program,
        transforms_into: Some(_),
        ..
    } = &static_ability.compiled_model()?.payload
    else {
        return None;
    };
    Some(program.clone())
}

fn ability_retains_counters_moving_to(
    ability: &crate::ability::Ability,
    destination: Zone,
) -> bool {
    let crate::ability::AbilityKind::Static(static_ability) = &ability.kind else {
        return false;
    };
    let Some(model) = static_ability.compiled_model() else {
        return false;
    };
    matches!(
        &model.payload,
        ironsmith_core::StaticAbilityPayload::CountersRemainAcrossZoneChanges {
            excluded_destinations,
            ..
        } if !excluded_destinations.contains(&destination)
    )
}

/// Already acquired post-transform programs and the exact actor/source facts.
/// Later programs cannot replace these with another face or incarnation.
pub(crate) struct CapturedTransformPrograms {
    source: ObjectId,
    controller: PlayerId,
    programs: Vec<crate::resolution::ResolutionProgram>,
    snapshot: crate::snapshot::ObjectSnapshot,
}

#[derive(Default)]
struct AsEntersProgramExecution {
    linked_exile: Vec<EntryLinkedExileTransfer>,
    outputs: Vec<crate::effects::CompletedEffectOutputs>,
    ran: bool,
    /// "put this into its owner's graveyard instead of onto the battlefield".
    entry_redirect: Option<Zone>,
    /// An entry program tapped the entering source.
    entry_tapped: bool,
    entry_designations: Vec<ironsmith_core::PermanentDesignation>,
    entry_named_actions: Vec<(String,crate::player::ManaPool)>,
    entry_counter_receipts: Vec<crate::events::zones::EntryCounterProducerReceipt>,
    continuous_effects: Vec<crate::continuous::ContinuousEffectId>,
    tagged_objects:
        std::collections::HashMap<crate::tag::TagKey, Vec<crate::snapshot::ObjectSnapshot>>,
}

impl std::fmt::Debug for AsEntersProgramExecution {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("AsEntersProgramExecution")
            .field("ran", &self.ran)
            .field("continuous_effects", &self.continuous_effects)
            .field("tagged_objects", &self.tagged_objects)
            .field("output_count", &self.outputs.len())
            .finish()
    }
}

fn merge_retained_tagged_objects(
    destination: &mut std::collections::HashMap<
        crate::tag::TagKey,
        Vec<crate::snapshot::ObjectSnapshot>,
    >,
    source: &std::collections::HashMap<crate::tag::TagKey, Vec<crate::snapshot::ObjectSnapshot>>,
) {
    for (tag, snapshots) in source {
        let retained = destination.entry(tag.clone()).or_default();
        for snapshot in snapshots {
            if retained
                .iter()
                .all(|existing| existing.stable_id != snapshot.stable_id)
            {
                retained.push(snapshot.clone());
            }
        }
    }
}

impl GameState {
    /// Frozen layer-1 rules, including casting abilities and copiable other halves.
    pub fn calculated_copiable_values(&self, id: ObjectId) -> Option<crate::snapshot::CopiableValues> {
        crate::continuous::copiable_values_with_effects(id, self.objects_map(),
            &self.all_continuous_effects(), &self.battlefield, self.commander_objects(), self)
    }

    /// A spell reads its current layer-derived program. Captured activated and
    /// triggered abilities are owned by their StackEntry instead (CR 113.7a).
    pub fn current_spell_program(
        &self,
        id: ObjectId,
    ) -> Result<
        crate::resolution::ResolutionProgram,
        crate::static_ability_processor::StaticEffectDiscoveryError,
    > {
        let chars = self.calculated_characteristics(id).ok_or(
            crate::static_ability_processor::StaticEffectDiscoveryError::UnavailableCharacteristics { object: id })?;
        chars.validate_numeric_range()?;
        if !chars.spell_effect.has_complete_definition() {
            return Err(
                crate::static_ability_processor::StaticEffectDiscoveryError::TextChangeDomain(
                    crate::continuous::text_changes::TextChangeDomainError::SpellProgram,
                ),
            );
        }
        match Arc::unwrap_or_clone(chars.spell_effect) {
            crate::snapshot::SpellProgramState::Present(program) => Ok(program),
            crate::snapshot::SpellProgramState::Absent => Ok(Default::default()),
            crate::snapshot::SpellProgramState::Unavailable => Err(
                crate::static_ability_processor::StaticEffectDiscoveryError::TextChangeDomain(
                    crate::continuous::text_changes::TextChangeDomainError::SpellProgram,
                ),
            ),
        }
    }

    /// The rest of an enter-as-copy choice once the copy entered: "If you do,
    /// it gains haste until end of turn" applies as part of the replacement;
    /// "When you do, exile that card" is a reflexive triggered ability
    /// (CR 603.12) whose "that card" is the copied object as it was.
    fn apply_enter_as_copy_followups(
        &mut self,
        new_id: ObjectId,
        copy_source_id: ObjectId,
        followups: &[ironsmith_core::EnterAsCopyFollowup],
    ) {
        let Some(controller) = self.controller_of_id(new_id) else {
            return;
        };
        for followup in followups {
            match followup {
                ironsmith_core::EnterAsCopyFollowup::GainsHasteUntilEndOfTurn => {
                    let effect = crate::continuous::ContinuousEffect::new(
                        new_id,
                        controller,
                        crate::continuous::EffectTarget::Specific(new_id),
                        crate::continuous::Modification::AddAbility(
                            crate::static_abilities::StaticAbility::haste(),
                        ),
                    )
                    .until(crate::effect::Until::EndOfTurn)
                    .with_expires_end_of_turn(self.turn.turn_number)
                    .with_source_type(
                        crate::continuous::EffectSourceType::Resolution {
                            locked_targets: vec![new_id],
                        },
                    );
                    self.effect_store.continuous_effects.add_effect(effect);
                    self.mark_continuous_state_dirty();
                }
                ironsmith_core::EnterAsCopyFollowup::ExileCopiedObject => {
                    let Some(copied) = self.object(copy_source_id) else {
                        continue;
                    };
                    let copied_tag = crate::tag::TagKey::from("copied_object");
                    let Some(snapshot) =
                        crate::snapshot::ObjectSnapshot::capture_for_execution(copied, self)
                    else {
                        return;
                    };
                    let mut tagged_objects = std::collections::HashMap::new();
                    tagged_objects.insert(copied_tag.clone(), vec![snapshot]);
                    crate::effects::composition::queue_reflexive_trigger(
                        self,
                        new_id,
                        controller,
                        vec![crate::effect::Effect::exile(
                            crate::target::ChooseSpec::Tagged(copied_tag),
                        )],
                        tagged_objects,
                    );
                }
                // Applied with the copiable values as the object entered.
                ironsmith_core::EnterAsCopyFollowup::RetainOwnColors | ironsmith_core::EnterAsCopyFollowup::RetainEmbalmCharacteristics
                | ironsmith_core::EnterAsCopyFollowup::CountersFromCopiedPermanent => {}
                ironsmith_core::EnterAsCopyFollowup::TapCopiedObjectFrozenWhileYouControlSource => {
                    // "When you do, tap the copied creature and it doesn't
                    // untap during its controller's untap step for as long as
                    // you control this creature" (CR 603.12): the reflexive
                    // ability refers to the copied object as it was.
                    let Some(copied) = self.object(copy_source_id) else {
                        continue;
                    };
                    let copied_tag = crate::tag::TagKey::from("copied_object");
                    let Some(snapshot) =
                        crate::snapshot::ObjectSnapshot::capture_for_execution(copied, self)
                    else {
                        return;
                    };
                    let mut tagged_objects = std::collections::HashMap::new();
                    tagged_objects.insert(copied_tag.clone(), vec![snapshot]);
                    let frozen = crate::target::ObjectFilter::default().match_tagged(
                        copied_tag.clone(),
                        crate::filter::TaggedOpbjectRelation::IsTaggedObject,
                    );
                    crate::effects::composition::queue_reflexive_trigger(
                        self,
                        new_id,
                        controller,
                        vec![
                            crate::effect::Effect::tap(crate::target::ChooseSpec::Tagged(
                                copied_tag,
                            )),
                            crate::effect::Effect::cant_until(
                                crate::effect::Restriction::untap(frozen),
                                crate::effect::Until::YouStopControllingThis,
                            ),
                        ],
                        tagged_objects,
                    );
                }
            }
        }
    }

    /// CR 400.4a: an instant or sorcery card cannot enter the battlefield.
    ///
    /// This is a zone-change rule, not a replacement effect, so callers must
    /// check it before proposing ETB replacements or collecting entry choices.
    pub(crate) fn card_cannot_enter_battlefield(&self, object_id: ObjectId) -> bool {
        self.token_cannot_change_zones(object_id, Zone::Battlefield)
            || self.object(object_id).is_some_and(|object| {
                if object.spell_copy_entry_forbidden { return true; }
                (object.kind == crate::object::ObjectKind::Card
                    && object.card_types.iter().any(|card_type| {
                        matches!(card_type, CardType::Instant | CardType::Sorcery)
                    }))
                    || self.entry_prohibited_by_cant_effect(object)
            })
    }

    /// CR 111.8: a token that has left the battlefield can't move to another
    /// zone or come back onto the battlefield; it stays where it is until
    /// state-based actions remove it (CR 704.5d).
    ///
    /// Tokens are staged in the command zone while being created, and a copy
    /// of a card (CR 707.12) is created as a token in the card's zone and then
    /// cast, so those two moves are not departures from the battlefield.
    pub(crate) fn token_cannot_change_zones(&self, object_id: ObjectId, new_zone: Zone) -> bool {
        self.object(object_id).is_some_and(|object| {
            if object.kind != crate::object::ObjectKind::Token || new_zone == Zone::Stack {
                return false;
            }
            match object.zone {
                Zone::Battlefield | Zone::Stack => false,
                // A token staged in the command zone during creation may still
                // enter; one that got there by leaving the battlefield may not.
                Zone::Command => self
                    .auxiliary_tracking
                    .departed_command_zone_tokens
                    .contains(&object_id),
                _ => true,
            }
        })
    }

    /// CR 614.17-style prohibitions such as Grafdigger's Cage: the filter is
    /// matched against the card where it currently is, so zone-bearing
    /// filters only stop entries from the named zones.
    fn entry_prohibited_by_cant_effect(&self, object: &crate::object::Object) -> bool {
        if object.zone == Zone::Battlefield {
            return false;
        }
        self.effect_store
            .cant_effects
            .cant_enter_battlefield
            .iter()
            .any(|restriction| {
                let mut ctx = crate::target::FilterContext::default();
                if let Some(source) = restriction.source {
                    ctx = ctx.with_source(source);
                }
                restriction.filter.matches(object, &ctx, self)
            })
    }

    /// [`Self::entry_prohibited_by_cant_effect`] for a prospective entering
    /// object whose characteristics differ from the live object's (applied
    /// entry replacements, CR 614.17d). The prohibition filter is matched
    /// against a snapshot so the live object's layered characteristics don't
    /// mask the prospective ones.
    fn prospective_entry_prohibited_by_cant_effect(&self, object: &crate::object::Object) -> bool {
        if object.zone == Zone::Battlefield {
            return false;
        }
        let mut snapshot = crate::snapshot::ObjectSnapshot::from_object(object, self);
        snapshot.card_types = object.card_types.to_vec().into();
        snapshot.subtypes = object.subtypes.to_vec().into();
        self.effect_store
            .cant_effects
            .cant_enter_battlefield
            .iter()
            .any(|restriction| {
                let mut ctx = crate::target::FilterContext::default();
                if let Some(source) = restriction.source {
                    ctx = ctx.with_source(source);
                }
                restriction.filter.matches_snapshot(&snapshot, &ctx, self)
            })
    }

    fn execute_immediate_effect_programs(
        &mut self,
        source: ObjectId,
        controller: PlayerId,
        programs: Vec<crate::resolution::ResolutionProgram>,
        linked_owner: Option<crate::linked_exile::LinkedExileOwner>,
        preparing_entry: bool,
        entry_event: Option<&crate::events::EnterBattlefieldEvent>,
        entry_reserved_objects: &std::collections::HashSet<ObjectId>,
        decision_maker: &mut dyn crate::decision::DecisionMaker,
    ) -> Result<AsEntersProgramExecution, crate::effects::ExecutionError> {
        self.execute_immediate_effect_programs_with_snapshot(source, controller, programs,
            linked_owner, preparing_entry, entry_event, entry_reserved_objects, None, decision_maker)
    }

    fn execute_immediate_effect_programs_with_snapshot(
        &mut self,
        source: ObjectId,
        controller: PlayerId,
        programs: Vec<crate::resolution::ResolutionProgram>,
        linked_owner: Option<crate::linked_exile::LinkedExileOwner>,
        preparing_entry: bool,
        entry_event: Option<&crate::events::EnterBattlefieldEvent>,
        entry_reserved_objects: &std::collections::HashSet<ObjectId>,
        source_snapshot: Option<crate::snapshot::ObjectSnapshot>,
        decision_maker: &mut dyn crate::decision::DecisionMaker,
    ) -> Result<AsEntersProgramExecution, crate::effects::ExecutionError> {
        if programs.is_empty() {
            return Ok(AsEntersProgramExecution::default());
        }
        // Replay begins with the entire list. Per-program checkpoints cannot
        // undo a preceding program's payments or one-shot consumption.
        let checkpoint = self.clone();
        let result = self.execute_immediate_effect_programs_inner(
            source,
            controller,
            programs,
            linked_owner,
            preparing_entry,
            entry_event,
            entry_reserved_objects,
            source_snapshot.as_ref(),
            decision_maker,
        );
        if result.is_err() || decision_maker.awaiting_choice() {
            self.restore_execution_checkpoint(
                checkpoint,
                result.is_ok() && decision_maker.awaiting_choice(),
            );
            return result.map(|_| AsEntersProgramExecution::default());
        }
        result
    }

    fn execute_immediate_effect_programs_inner(
        &mut self,
        source: ObjectId,
        controller: PlayerId,
        programs: Vec<crate::resolution::ResolutionProgram>,
        linked_owner: Option<crate::linked_exile::LinkedExileOwner>,
        preparing_entry: bool,
        entry_event: Option<&crate::events::EnterBattlefieldEvent>,
        entry_reserved_objects: &std::collections::HashSet<ObjectId>,
        source_snapshot: Option<&crate::snapshot::ObjectSnapshot>,
        decision_maker: &mut dyn crate::decision::DecisionMaker,
    ) -> Result<AsEntersProgramExecution, crate::effects::ExecutionError> {
        let initial_effect_ids: std::collections::HashSet<_> = self
            .effect_store
            .continuous_effects
            .effects()
            .iter()
            .map(|effect| effect.id)
            .collect();
        let mut execution = AsEntersProgramExecution {
            ran: true,
            ..AsEntersProgramExecution::default()
        };
        let optional_costs_paid = source_snapshot.map(|snapshot| snapshot.optional_costs_paid.clone())
            .or_else(|| self.object(source).map(|object| object.optional_costs_paid.clone()))
            .unwrap_or_default();
        for program in programs {
            let linked_before = if preparing_entry {
                linked_owner.as_ref().map(|owner| self.linked_exile_pair_members(owner)
                    .map(<[ObjectId]>::to_vec)).transpose()?
            } else { None };
            let alias_readers_before = self.exile_tracking.linked_exile_pair_aliases.keys()
                .cloned().collect::<std::collections::HashSet<_>>();
            let provenance = self.provenance_graph_mut().alloc_root(
                crate::provenance::ProvenanceNodeKind::EffectExecution { source, controller },
            );
            let mut context =
                crate::effects::ExecutionContext::new(source, controller, decision_maker)
                    .with_linked_exile_owner(linked_owner.clone())
                    .with_optional_costs_paid(optional_costs_paid.clone())
                    .with_cause(crate::events::cause::EventCause::from_effect(
                        source, controller,
                    ))
                    .with_provenance(provenance);
            context.source_snapshot = source_snapshot.cloned();
            if program.source_number_pair.is_some() {
                context.source_number_owner = Some(if preparing_entry {
                    let from = self
                        .object(source)
                        .ok_or(crate::effects::ExecutionError::ObjectNotFound(source))?
                        .zone;
                    let default_event = crate::events::EnterBattlefieldEvent::new(source, from);
                    let prospective = entry_event
                        .unwrap_or(&default_event)
                        .try_prospective_game_state(self)
                        .map_err(crate::effects::ExecutionError::ContinuousDiscovery)?
                        .ok_or(crate::effects::ExecutionError::ObjectNotFound(source))?;
                    crate::source_numbers::resolve_owner(
                        &prospective,
                        source,
                        program.source_number_pair,
                        None,
                        None,
                    )?
                } else {
                    crate::source_numbers::resolve_owner(
                        self,
                        source,
                        program.source_number_pair,
                        None,
                        source_snapshot,
                    )?
                });
            }
            if let Some(event) = entry_event {
                for (tag, snapshots) in &event.program_choices.as_enters_tagged_objects {
                    context.set_tagged_objects(tag.clone(), snapshots.clone());
                }
            }
            context.replacement.entry_counter_source = preparing_entry.then_some(source);
            context.replacement.entry_event = entry_event.cloned().map(Box::new);
            context.replacement.entry_reserved_objects = entry_reserved_objects.clone();
            let completed = crate::game_loop::execute_resolution_program_with_outputs_typed(
                self,
                &mut context,
                controller,
                source,
                &program,
                None,
                &[],
            )?;
            if let (Some(owner), Some(before)) = (linked_owner.as_ref(), linked_before) {
                execution.linked_exile.push(EntryLinkedExileTransfer {
                    owner: owner.clone(),
                    members: self.linked_exile_pair_members(owner)?.iter().copied()
                        .filter(|member| !before.contains(member)).collect(),
                    aliases: self.exile_tracking.linked_exile_pair_aliases.iter()
                        .filter(|(reader, creator)| *creator == owner && !alias_readers_before.contains(*reader))
                        .map(|(reader, _)| reader.clone()).collect(),
                });
            }
            if preparing_entry {
                // Retain only successful authored exile receipts from this
                // entry program. Auxiliary replacement actions are excluded
                // by action_objects' instruction-result boundary.
                let tag=crate::tag::TagKey::from("__entry_action_exiled__");
                let snapshots=completed.outputs.iter().flat_map(|output|
                    output.outcome.action_objects(crate::effect::PriorEffectAction::Exiled,None).into_iter().cloned()
                ).collect::<Vec<_>>();
                if !snapshots.is_empty(){
                    let retained=execution.tagged_objects.entry(tag).or_default();
                    for snapshot in snapshots {if !retained.iter().any(|prior|prior.object_id==snapshot.object_id){retained.push(snapshot);}}
                }
            }
            for event in completed.events {
                self.queue_trigger_event(provenance, event);
            }
            execution.outputs.extend(completed.outputs);
            execution.continuous_effects = self
                .effect_store
                .continuous_effects
                .effects()
                .iter()
                .filter(|effect| !initial_effect_ids.contains(&effect.id))
                .map(|effect| effect.id)
                .collect();
            let awaiting_choice = context.decision_maker.awaiting_choice();
            merge_retained_tagged_objects(&mut execution.tagged_objects, &context.tagged_objects);
            if let Some(destination) = context.replacement.entry_redirect.take() {
                execution.entry_redirect = Some(destination);
            }
            execution.entry_tapped |= std::mem::take(&mut context.replacement.entry_tapped);
            execution.entry_designations.append(&mut context.replacement.entry_designations);
            execution.entry_named_actions.append(&mut context.replacement.entry_named_actions);
            execution.entry_counter_receipts.append(&mut context.replacement.entry_counter_receipts);
            if awaiting_choice {
                return Ok(execution);
            }
            if execution.entry_redirect.is_some() {
                // The object no longer enters; later entry programs don't run.
                return Ok(execution);
            }
        }
        Ok(execution)
    }

    pub(crate) fn execute_entry_programs(
        &mut self,
        source: ObjectId,
        controller: PlayerId,
        programs: Vec<crate::resolution::ResolutionProgram>,
        entry_event: Option<&crate::events::EnterBattlefieldEvent>,
        dm: &mut dyn crate::decision::DecisionMaker,
    ) -> Result<Option<PreparedEtbChoices>, crate::effects::ExecutionError> {
        self.execute_entry_programs_with_reservations(
            source,
            controller,
            programs,
            None,
            entry_event,
            &std::collections::HashSet::from([source]),
            dm,
        )
    }

    pub(crate) fn execute_entry_programs_with_reservations(
        &mut self,
        source: ObjectId,
        controller: PlayerId,
        programs: Vec<crate::resolution::ResolutionProgram>,
        linked_owner: Option<crate::linked_exile::LinkedExileOwner>,
        entry_event: Option<&crate::events::EnterBattlefieldEvent>,
        entry_reserved_objects: &std::collections::HashSet<ObjectId>,
        dm: &mut dyn crate::decision::DecisionMaker,
    ) -> Result<Option<PreparedEtbChoices>, crate::effects::ExecutionError> {
        let checkpoint = self.clone();
        let result = self.execute_entry_programs_inner(
            source,
            controller,
            programs,
            linked_owner,
            entry_event,
            entry_reserved_objects,
            dm,
        );
        if result.is_err() || dm.awaiting_choice() {
            *self = checkpoint;
            return result.map(|_| None);
        }
        result
    }

    fn execute_entry_programs_inner(
        &mut self,
        source: ObjectId,
        controller: PlayerId,
        programs: Vec<crate::resolution::ResolutionProgram>,
        linked_owner: Option<crate::linked_exile::LinkedExileOwner>,
        entry_event: Option<&crate::events::EnterBattlefieldEvent>,
        entry_reserved_objects: &std::collections::HashSet<ObjectId>,
        dm: &mut dyn crate::decision::DecisionMaker,
    ) -> Result<Option<PreparedEtbChoices>, crate::effects::ExecutionError> {
        let before = self
            .object(source)
            .ok_or(crate::effects::ExecutionError::InvalidTarget)?
            .counters
            .clone();
        let execution = self.execute_immediate_effect_programs(
            source,
            controller,
            programs,
            linked_owner,
            true,
            entry_event,
            entry_reserved_objects,
            dm,
        )?;
        if dm.awaiting_choice() {
            return Ok(None);
        }
        let after = self
            .object(source)
            .ok_or(crate::effects::ExecutionError::InvalidTarget)?
            .counters
            .clone();
        let counters = after
            .iter()
            .filter_map(|(kind, count)| {
                let previous = before.get(kind).copied().unwrap_or(0);
                (*count > previous).then(|| (*kind, *count - previous))
            })
            .collect();
        self.object_mut(source)
            .ok_or(crate::effects::ExecutionError::InvalidTarget)?
            .counters = before;
        Ok(Some(PreparedEtbChoices {
            entry_redirect: execution.entry_redirect,
            as_enters_tapped: execution.entry_tapped,
            as_enters_designations: execution.entry_designations,
            as_enters_named_actions: execution.entry_named_actions,
            as_enters_counters: counters,
            // Do not derive provenance from the net count: later removals can
            // make it differ from the successful original producer packets.
            as_enters_counter_receipts: execution.entry_counter_receipts,
            as_enters_tagged_objects: execution.tagged_objects,
            transfer_as_enters_source_links: execution.ran,
            as_enters_linked_exile: execution.linked_exile,
            as_enters_continuous_effects: execution.continuous_effects,
            as_enters_outputs: execution
                .outputs
                .into_iter()
                .map(crate::effects::PublishedEffectOutputs::retain)
                .collect(),
            entry_copy_registration: entry_event
                .and_then(|event| event.program_choices.entry_copy_registration),
            ..Default::default()
        }))
    }

    fn entry_text_abilities(&self, source: ObjectId) -> Option<Vec<crate::ability::Ability>> {
        let from = self.object(source)?.zone;
        let preview =
            crate::events::EnterBattlefieldEvent::new(source, from).prospective_game_state(self)?;
        let effects = preview.all_continuous_effects();
        let chars = crate::continuous::text_box_characteristics_with_effects(
            source,
            preview.objects_map(),
            &effects,
            &preview.battlefield,
            preview.commander_objects(),
            &preview,
        )?;
        Some(chars.abilities.iter().cloned().collect())
    }

    fn execute_as_enters_effect_programs_from_abilities(
        &mut self,
        source: ObjectId,
        controller: PlayerId,
        abilities: &[crate::ability::Ability],
        for_turn_face_up: bool,
        decision_maker: &mut dyn crate::decision::DecisionMaker,
    ) -> Result<AsEntersProgramExecution, crate::effects::ExecutionError> {
        let checkpoint = self.clone();
        let result = (|| {
            let mut current_abilities = abilities.to_vec();
            let mut applied = std::collections::HashSet::new();
            let mut combined = AsEntersProgramExecution::default();
            loop {
                let next = current_abilities.iter().find_map(|ability| {
                    let crate::ability::AbilityKind::Static(static_ability) = &ability.kind else {
                        return None;
                    };
                    if applied.contains(&static_ability.instance_id()) {
                        return None;
                    }
                    let (program, also_face_up, only_face_up) =
                        as_enters_effect_program_from_ability(ability)?;
                    let applies = if for_turn_face_up {
                        also_face_up
                    } else {
                        !only_face_up
                    };
                    applies.then_some((static_ability.instance_id(), program))
                });
                let Some((identity, program)) = next else {
                    break;
                };
                applied.insert(identity);
                let execution = self.execute_immediate_effect_programs(
                    source,
                    controller,
                    vec![program],
                    None,
                    !for_turn_face_up,
                    None,
                    &std::collections::HashSet::new(),
                    decision_maker,
                )?;
                combined.ran |= execution.ran;
                combined.entry_redirect = combined.entry_redirect.or(execution.entry_redirect);
                combined.entry_designations.extend(execution.entry_designations.iter().cloned());
                combined.entry_named_actions.extend(execution.entry_named_actions.iter().cloned());
                combined.entry_counter_receipts.extend(execution.entry_counter_receipts.iter().cloned());
                combined
                    .continuous_effects
                    .extend(execution.continuous_effects.iter().copied());
                merge_retained_tagged_objects(
                    &mut combined.tagged_objects,
                    &execution.tagged_objects,
                );
                combined.linked_exile.extend(execution.linked_exile);
                combined.outputs.extend(execution.outputs);
                if decision_maker.awaiting_choice() {
                    return Ok(combined);
                }
                // A text exchange can remove a not-yet-applied program and supply
                // another one. Each ability instance applies at most once to this
                // event, even if a later exchange brings its text back.
                let changed_text =
                    self.effect_store
                        .continuous_effects
                        .effects()
                        .iter()
                        .any(|effect| {
                            execution.continuous_effects.contains(&effect.id)
                                && matches!(
                                    effect.modification,
                                    crate::continuous::Modification::SetTextBox(_)
                                )
                                && matches!(&effect.source_type,
                            crate::continuous::EffectSourceType::Resolution { locked_targets }
                            if locked_targets.contains(&source))
                        });
                if changed_text {
                    if let Some(abilities) = self.entry_text_abilities(source) {
                        current_abilities = abilities;
                    }
                }
            }
            Ok(combined)
        })();
        if result.is_err() || decision_maker.awaiting_choice() {
            self.restore_execution_checkpoint(
                checkpoint,
                result.is_ok() && decision_maker.awaiting_choice(),
            );
            return result.map(|_| AsEntersProgramExecution::default());
        }
        result
    }

    /// Apply characteristic rewrites before observers can see the completed
    /// transform. Counter identity changes are not counter placement/removal.
    pub(crate) fn apply_atomic_transform_characteristics(
        &mut self,
        source: ObjectId,
        cause: Option<&crate::events::cause::EventCause>,
        payment: Option<&crate::player::ManaPool>,
    ) -> Result<(), crate::effects::ExecutionError> {
        use ironsmith_core::static_ability_model::TransformCharacteristicAdjustment as Adjustment;
        let Some(characteristics) = self.try_current_characteristics(source)
            .map_err(crate::effects::ExecutionError::ContinuousDiscovery)? else { return Ok(()) };
        let controller = characteristics.controller;
        let abilities = characteristics.abilities;
        let adjustments = abilities.iter().filter_map(|ability| {
            let crate::ability::AbilityKind::Static(ability) = &ability.kind else { return None };
            let ironsmith_core::StaticAbilityPayload::AsEntersEffectProgram {
                transforms_into: Some(_), transform_characteristics: Some(adjustment), ..
            } = &ability.compiled_model()?.payload else { return None };
            Some(adjustment.clone())
        }).collect::<Vec<_>>();
        for adjustment in adjustments {
            match adjustment {
                Adjustment::CounterKind(kind) => {
                    let object = self.object_mut(source)
                        .ok_or(crate::effects::ExecutionError::ObjectNotFound(source))?;
                    let total = object.counters.values().try_fold(0u32, |total, count| total.checked_add(*count))
                        .ok_or_else(|| crate::effects::ExecutionError::Impossible("counter count overflow".into()))?;
                    object.counters.clear();
                    if total != 0 { object.counters.insert(kind, total); }
                }
                Adjustment::ColorsFromNamedActivationPayment(label) => {
                    let Some(cause) = cause else { continue };
                    if cause.source != Some(source)
                        || cause.resolving_ability != Some(ironsmith_core::CauseAbilityKind::Activated)
                        || cause.activation_definition.is_none()
                        || !cause.activation_label.as_ref().is_some_and(|name| name.eq_ignore_ascii_case(&label)) {
                        continue;
                    }
                    let Some(payment) = payment else { continue };
                    let colors = [crate::color::Color::White, crate::color::Color::Blue,
                        crate::color::Color::Black, crate::color::Color::Red, crate::color::Color::Green]
                        .into_iter().filter(|color| payment.amount(crate::mana::ManaSymbol::from_color(*color)) != 0)
                        .collect::<crate::color::ColorSet>();
                    // No paid colors means the quantified instruction does
                    // nothing; it does not make an already colored face colorless.
                    if colors.is_empty() { continue; }
                    self.effect_store.continuous_effects.add_effect(crate::continuous::ContinuousEffect::new(
                        source, controller, crate::continuous::EffectTarget::Specific(source),
                        crate::continuous::Modification::SetColors(colors),
                    ).until(crate::effect::Until::Forever)
                        .with_source_type(crate::continuous::EffectSourceType::Resolution { locked_targets: vec![source] }));
                }
            }
        }
        self.refresh_continuous_state().map_err(crate::effects::ExecutionError::ContinuousDiscovery)?;
        Ok(())
    }

    pub(crate) fn capture_transform_programs(
        &self, source: ObjectId, controller: PlayerId,
    ) -> Result<CapturedTransformPrograms, crate::effects::ExecutionError> {
        let object = self.object(source).ok_or(crate::effects::ExecutionError::ObjectNotFound(source))?;
        let programs = object.abilities_vec().iter().filter_map(as_transforms_effect_program_from_ability).collect();
        let snapshot = crate::snapshot::ObjectSnapshot::from_object_with_calculated_characteristics(object, self);
        Ok(CapturedTransformPrograms { source, controller, programs, snapshot })
    }

    pub(crate) fn execute_captured_transform_programs_with_outputs(
        &mut self, captured: &CapturedTransformPrograms,
        decision_maker: &mut dyn crate::decision::DecisionMaker,
    ) -> Result<Vec<crate::effects::CompletedEffectOutputs>, crate::effects::ExecutionError> {
        let execution = self.execute_immediate_effect_programs_with_snapshot(
            captured.source, captured.controller, captured.programs.clone(), None, false, None,
            &std::collections::HashSet::new(), Some(captured.snapshot.clone()), decision_maker,
        )?;
        if let Some(object) = self.object_mut(captured.source) {
            merge_retained_tagged_objects(&mut object.cast_tagged_objects, &execution.tagged_objects);
        }
        Ok(execution.outputs)
    }

    pub(crate) fn execute_as_transforms_effect_programs(
        &mut self,
        source: ObjectId,
        controller: PlayerId,
        decision_maker: &mut dyn crate::decision::DecisionMaker,
    ) -> Result<(), crate::effects::ExecutionError> {
        self.execute_as_transforms_effect_programs_with_outputs(source, controller, decision_maker)
            .map(|_| ())
    }

    pub(crate) fn execute_as_transforms_effect_programs_with_outputs(
        &mut self,
        source: ObjectId,
        controller: PlayerId,
        decision_maker: &mut dyn crate::decision::DecisionMaker,
    ) -> Result<Vec<crate::effects::CompletedEffectOutputs>, crate::effects::ExecutionError> {
        self.apply_atomic_transform_characteristics(source, None, None)?;
        let abilities = self
            .object(source)
            .map(|object| object.abilities_vec())
            .unwrap_or_default();
        let programs = abilities
            .iter()
            .filter_map(as_transforms_effect_program_from_ability)
            .collect::<Vec<_>>();
        let execution = self.execute_immediate_effect_programs(
            source,
            controller,
            programs,
            None,
            false,
            None,
            &std::collections::HashSet::new(),
            decision_maker,
        )?;
        if let Some(object) = self.object_mut(source) {
            merge_retained_tagged_objects(
                &mut object.cast_tagged_objects,
                &execution.tagged_objects,
            );
        }
        Ok(execution.outputs)
    }

    pub(crate) fn execute_as_enters_effect_programs_for_turn_face_up(
        &mut self,
        source: ObjectId,
        controller: PlayerId,
        decision_maker: &mut dyn crate::decision::DecisionMaker,
    ) -> Result<(), crate::effects::ExecutionError> {
        self.execute_as_enters_effect_programs_for_turn_face_up_with_outputs(
            source,
            controller,
            decision_maker,
        )
        .map(|_| ())
    }

    pub(crate) fn execute_as_enters_effect_programs_for_turn_face_up_with_outputs(
        &mut self,
        source: ObjectId,
        controller: PlayerId,
        decision_maker: &mut dyn crate::decision::DecisionMaker,
    ) -> Result<Vec<crate::effects::CompletedEffectOutputs>, crate::effects::ExecutionError> {
        let abilities = self
            .object(source)
            .map(|object| object.abilities_vec())
            .unwrap_or_default();
        let execution = self.execute_as_enters_effect_programs_from_abilities(
            source,
            controller,
            &abilities,
            true,
            decision_maker,
        )?;
        if let Some(object) = self.object_mut(source) {
            merge_retained_tagged_objects(
                &mut object.cast_tagged_objects,
                &execution.tagged_objects,
            );
        }
        Ok(execution.outputs)
    }

    /// "If this enchantment leaves the battlefield, this effect continues
    /// until end of turn" (Titania's Song): as the permanent leaves, the
    /// continuous effects its other static abilities generate are registered
    /// until end of turn, keeping their timestamp and applying to whatever
    /// their filters match, as they did while the source was on the
    /// battlefield. They form one effect for CR 613.6.
    fn register_lingering_static_effects_on_leave(
        &mut self,
        source: ObjectId,
        snapshot: &crate::snapshot::ObjectSnapshot,
    ) {
        use crate::static_abilities::StaticAbilityId;
        // Simultaneous departures retain the abilities and controller from
        // before the whole batch. Earlier commits may remove their grantor.
        let abilities = &snapshot.abilities;
        let controller = snapshot.controller;
        let zone = snapshot.zone;
        if !abilities.iter().any(|ability| {
            ability.functions_in(&zone)
                && matches!(&ability.kind, crate::ability::AbilityKind::Static(payload)
                    if payload.id() == StaticAbilityId::StaticEffectsContinueUntilEndOfTurnAfterLeaving)
        }) {
            return;
        }
        let mut effects = Vec::new();
        for ability in abilities.iter() {
            let crate::ability::AbilityKind::Static(static_ability) = &ability.kind else {
                continue;
            };
            if !ability.functions_in(&zone)
                || static_ability.id()
                    == StaticAbilityId::StaticEffectsContinueUntilEndOfTurnAfterLeaving
            {
                continue;
            }
            effects.extend(static_ability.generate_effects(source, controller, self));
        }
        if effects.is_empty() {
            return;
        }
        let timestamp = self
            .effect_store
            .continuous_effects
            .get_object_timestamp(source)
            .unwrap_or(0);
        let group = self.effect_store.continuous_effects.next_effect_group_id();
        for mut effect in effects {
            effect.duration = crate::effect::Until::EndOfTurn;
            effect.timestamp = timestamp;
            effect.group = Some(group);
            effect.source_type = crate::continuous::EffectSourceType::StaticAbility;
            effect.originating_static_ability = None;
            effect.originating_ability = None;
            self.effect_store.continuous_effects.add_effect(effect);
        }
        self.mark_continuous_state_dirty();
    }

    pub fn move_object(
        &mut self,
        old_id: ObjectId,
        new_zone: Zone,
        cause: crate::events::cause::EventCause,
    ) -> Option<ObjectId> {
        self.move_object_with_snapshot(old_id, new_zone, cause, None)
    }

    pub(crate) fn move_object_with_snapshot(
        &mut self,
        old_id: ObjectId,
        new_zone: Zone,
        cause: crate::events::cause::EventCause,
        lki_snapshot: Option<crate::snapshot::ObjectSnapshot>,
    ) -> Option<ObjectId> {
        self.move_object_with_snapshot_and_entry_prevalidation(
            old_id,
            new_zone,
            cause,
            lki_snapshot,
            false,
        )
    }

    fn move_object_with_snapshot_and_entry_prevalidation(
        &mut self,
        old_id: ObjectId,
        new_zone: Zone,
        cause: crate::events::cause::EventCause,
        lki_snapshot: Option<crate::snapshot::ObjectSnapshot>,
        entry_prevalidated: bool,
    ) -> Option<ObjectId> {
        let pre_event_lookback_source_snapshots = if self
            .may_have_triggered_abilities_for_event_kind(crate::events::EventKind::ZoneChange)
        {
            match self.try_trigger_source_lookback_snapshots() {
                Ok(snapshots) => snapshots,
                Err(error) => {
                    self.record_token_resource_failure(&error);
                    return None;
                }
            }
        } else {
            Vec::new()
        };
        self.move_object_with_snapshot_and_pre_event_lookback_internal(
            old_id,
            new_zone,
            cause,
            lki_snapshot,
            &pre_event_lookback_source_snapshots,
            entry_prevalidated,
            None,
            &[],
            None,
            false,
        )
    }

    fn move_prepared_zone_entry_with_lookback(
        &mut self,
        old_id: ObjectId,
        zone: Zone,
        cause: crate::events::cause::EventCause,
        snapshot: Option<crate::snapshot::ObjectSnapshot>,
        lookback: Option<&[crate::snapshot::ObjectSnapshot]>,
        entry_prevalidated: bool,
        entry_definition: Option<&crate::cards::CardDefinition>,
        physical_components: &[PreparedEntryComponent],
        entry_linked_face_mana_cost: Option<&crate::mana::ManaCost>,
        entry_face_down: bool,
    ) -> Option<ObjectId> {
        let owned_lookback;
        let lookback = match lookback {
            Some(lookback) => lookback,
            None => {
                owned_lookback = if self.may_have_triggered_abilities_for_event_kind(
                    crate::events::EventKind::ZoneChange,
                ) {
                    self.trigger_source_lookback_snapshots()
                } else {
                    Vec::new()
                };
                &owned_lookback
            }
        };
        if !physical_components.is_empty() && zone != Zone::Battlefield {
            let opened = self.open_simultaneous_action();
            let mut results = Vec::new();
            for component in physical_components {
                let id = component.snapshot.object_id;
                if let Some(object) = self.object_mut(id) {
                    object.apply_definition_face(&component.original_definition);
                }
                if let Some(new_id) = self
                    .move_object_with_snapshot_and_pre_event_lookback_internal(
                        id,
                        zone,
                        cause.clone(),
                        Some(component.snapshot.clone()),
                        lookback,
                        entry_prevalidated,
                        None,
                        &[],
                        None,
                        entry_face_down,
                    )
                {
                    results.push(new_id);
                }
            }
            self.close_simultaneous_action(opened);
            self.record_zone_change_results(old_id, results.clone());
            return results.first().copied();
        }
        self.move_object_with_snapshot_and_pre_event_lookback_internal(
            old_id,
            zone,
            cause,
            snapshot,
            lookback,
            entry_prevalidated,
            entry_definition,
            physical_components,
            entry_linked_face_mana_cost,
            entry_face_down,
        )
    }

    pub(crate) fn move_object_with_snapshot_and_pre_event_lookback(
        &mut self,
        old_id: ObjectId,
        new_zone: Zone,
        cause: crate::events::cause::EventCause,
        lki_snapshot: Option<crate::snapshot::ObjectSnapshot>,
        pre_event_lookback_source_snapshots: &[crate::snapshot::ObjectSnapshot],
    ) -> Option<ObjectId> {
        self.move_object_with_snapshot_and_pre_event_lookback_internal(
            old_id,
            new_zone,
            cause,
            lki_snapshot,
            pre_event_lookback_source_snapshots,
            false,
            None,
            &[],
            None,
            false,
        )
    }

    fn move_object_with_snapshot_and_pre_event_lookback_internal(
        &mut self,
        old_id: ObjectId,
        new_zone: Zone,
        cause: crate::events::cause::EventCause,
        lki_snapshot: Option<crate::snapshot::ObjectSnapshot>,
        pre_event_lookback_source_snapshots: &[crate::snapshot::ObjectSnapshot],
        entry_prevalidated: bool,
        entry_definition: Option<&crate::cards::CardDefinition>,
        physical_components: &[PreparedEntryComponent],
        entry_linked_face_mana_cost: Option<&crate::mana::ManaCost>,
        entry_face_down: bool,
    ) -> Option<ObjectId> {
        // CR 311.2/312.2: planar cards remain in the command zone even if an
        // effect attempts to move them. Turning them face down is handled by
        // the Planechase procedure because it creates a new command-zone object.
        if self.is_planar_card(old_id) && new_zone != Zone::Command {
            return Some(old_id);
        }
        if self.is_vanguard_card(old_id) && new_zone != Zone::Command {
            return Some(old_id);
        }
        // CR 314.2: scheme cards remain in the command zone. Setting one in
        // motion or turning it face down changes its status, not its zone.
        if self.is_scheme_card(old_id) && new_zone != Zone::Command {
            return Some(old_id);
        }
        // CR 315.3: conspiracy cards remain in command. Turning an agenda
        // conspiracy face up changes only its status.
        if self.is_conspiracy_card(old_id) && new_zone != Zone::Command {
            return Some(old_id);
        }
        // CR 108.5: an effect can't bring a nontraditional card (other than a
        // dungeon) into the game from outside the game; it stays outside.
        if new_zone != Zone::Command
            && new_zone != Zone::OutsideGame
            && self.objects.get(&old_id).is_some_and(|object| {
                object.zone == Zone::OutsideGame
                    && object.card_types.iter().any(|card_type| {
                        matches!(
                            card_type,
                            crate::types::CardType::Plane
                                | crate::types::CardType::Phenomenon
                                | crate::types::CardType::Vanguard
                                | crate::types::CardType::Scheme
                        )
                    })
            })
        {
            return None;
        }
        // CR 717.6: an Attraction card goes to its owner's junkyard in the
        // command zone instead of a graveyard, hand or library.
        let new_zone = self.attraction_card_destination(old_id, new_zone);
        // One already in the command zone (its Attraction deck or junkyard)
        // stays where it is.
        if new_zone == Zone::Command
            && self.is_attraction_card(old_id)
            && self
                .objects
                .get(&old_id)
                .is_some_and(|object| object.zone == Zone::Command)
        {
            return Some(old_id);
        }
        if self
            .objects
            .get(&old_id)
            .is_some_and(|object| object.zone == new_zone)
            && !matches!(new_zone, Zone::Exile | Zone::Command)
        {
            // Preserve identity and all object state. Library positioning is
            // an explicit instruction handled by the caller, not a zone change.
            return Some(old_id);
        }
        // A simultaneous exchange checks entry legality before either member
        // leaves its original zone. Its prepared commit must preserve that
        // answer instead of evaluating dynamic filters against a partial move.
        if new_zone == Zone::Battlefield
            && !entry_prevalidated
            && self.card_cannot_enter_battlefield(old_id)
        {
            return None;
        }
        if self.token_cannot_change_zones(old_id, new_zone) {
            return None;
        }
        // A hidden identity can leave and re-enter the same zone with the same
        // commitment. Bind that new object to a distinct public generation.
        // Exhaustion rejects this move before any state, queue or ID mutation;
        // unknown historical generations stay unknown, never restart at zero.
        let next_hidden_incarnation = match self
            .hidden_card_info(old_id)
            .and_then(|info| info.incarnation)
        {
            Some(current) => Some(current.checked_add(1)?),
            None => None,
        };
        // Use the object's current typed abilities while it is still in the
        // origin zone. This honors ability-loss effects on the battlefield and
        // still lets an all-zone retention ability operate from other zones.
        let retain_counters = lki_snapshot.as_ref().map_or_else(
            || {
                self.current_abilities(old_id).is_some_and(|abilities| {
                    abilities
                        .iter()
                        .any(|ability| ability_retains_counters_moving_to(ability, new_zone))
                })
            },
            |snapshot| {
                snapshot
                    .abilities
                    .iter()
                    .any(|ability| ability_retains_counters_moving_to(ability, new_zone))
            },
        );
        // Capture before the first mutation. Legacy Option movement reports
        // incompleteness to the surrounding event/effect root and moves nothing.
        let pre_move_snapshot = match lki_snapshot {
            Some(snapshot) => Some(snapshot),
            None => match self
                .objects
                .get(&old_id)
                .map(|object| {
                    self.try_cached_object_snapshot_with_calculated_characteristics(object)
                })
                .transpose()
            {
                Ok(snapshot) => snapshot,
                Err(error) => {
                    self.record_token_resource_failure(&error);
                    return None;
                }
            },
        };
        let turn_face_up_before_action = self.object_annotations.turn_face_up_before_action.contains(&old_id);
        let was_face_down = self.is_face_down(old_id);
        let was_foretold = self.is_prepared_face_down(old_id);
        let preserved_exile_viewers = if self
            .objects
            .get(&old_id)
            .is_some_and(|obj| obj.zone == Zone::Exile)
        {
            self.exile_tracking_mut()
                .face_down_exile_viewers
                .remove(&old_id)
        } else {
            None
        };
        // Direct rule moves also need event-time hand permissions. Prepared
        // actions already retained their complete pre-proposal frame; keep it.
        if !self.action_observations_suppressed()
            && self.object(old_id).is_some_and(|object|object.zone==Zone::Battlefield)
            && new_zone!=Zone::Battlefield
            && !self.effect_store.departure_hand_reveal_frames.contains_key(&old_id)
        {
            let event=crate::triggers::TriggerEvent::new_with_provenance(
                crate::events::ZoneChangeEvent::with_cause(old_id,Zone::Battlefield,new_zone,cause.clone(),pre_move_snapshot.clone()),Default::default());
            match crate::effects::freeze_hand_reveal_frame(self,&event) {
                Ok(frame)=>{self.effect_store.departure_hand_reveal_frames.insert(old_id,frame);}
                Err(error)=>{self.record_token_resource_failure(&error);return None;}
            }
        }
        // Source cleanup retires its hold records. Capture their exact
        // participants first, but phase them in only after this physical move.
        let phase_duration_returns = if self.objects.get(&old_id).is_some_and(|object| object.zone == Zone::Battlefield)
            && new_zone != Zone::Battlefield {
            self.take_phase_out_holds_for_source(old_id)
        } else { std::collections::BTreeMap::new() };
        if self
            .objects
            .get(&old_id)
            .is_some_and(|object| object.zone == Zone::Battlefield)
            && new_zone != Zone::Battlefield
        {
            if let Some(snapshot) = pre_move_snapshot.as_ref() {
                self.register_lingering_static_effects_on_leave(old_id, snapshot);
            }
            self.note_attraction_left_battlefield(old_id);
            // CR 506.4: a planeswalker or battle that leaves the battlefield
            // stops being attacked.
            self.remove_attacked_permanent_from_combat(old_id, None);
            // CR 506.4: an attacking or blocking creature that leaves the
            // battlefield is removed from combat. The new object in the
            // destination zone is unrelated to the departed combatant (CR
            // 400.7), so its old ID must not linger as a combatant; creatures
            // that blocked it remain blocking creatures (CR 509.1g).
            self.remove_departed_object_from_combat(old_id);
        }
        if let Some(snapshot) = pre_move_snapshot.as_ref() {
            for entry in &mut self.stack {
                if entry.is_ability
                    && entry
                        .triggering_event
                        .as_ref()
                        .and_then(|event| event.object_id())
                        .is_some_and(|object_id| object_id == old_id)
                {
                    entry.tagged_objects.insert(
                        crate::tag::TagKey::from("triggering"),
                        vec![snapshot.clone()],
                    );
                    entry
                        .tagged_objects
                        .entry(crate::tag::TagKey::from("__it__"))
                        .or_insert_with(|| vec![snapshot.clone()]);
                }
                for tagged_snapshots in entry.tagged_objects.values_mut() {
                    for tagged_snapshot in tagged_snapshots {
                        // The ability watches this incarnation. An explicit
                        // movement link may already have updated its object id;
                        // card identity alone cannot authorize a later blink.
                        if tagged_snapshot.object_id == old_id
                            && tagged_snapshot.zone == snapshot.zone
                        {
                            *tagged_snapshot = snapshot.clone();
                        }
                    }
                }
            }
            self.refresh_pending_ability_source_lki(snapshot);
        }

        if self
            .object(old_id)
            .is_some_and(|object| object.zone == Zone::Battlefield)
            && new_zone != Zone::Battlefield
        {
            self.detach_relations_for_leaving_object(old_id);
        }
        if self
            .object(old_id)
            .is_some_and(|object| object.zone == Zone::Stack)
        {
            if let (Some(snapshot), Some(previous)) = (
                pre_move_snapshot.as_ref(),
                self.turn_store.cast_spell_lki.get(&old_id).cloned(),
            ) {
                let (mut object, entry) = (*previous).clone();
                object.copy_spell_values_from_values(&snapshot.copiable_values);
                self.turn_store
                    .cast_spell_lki
                    .insert(old_id, Arc::new((object, entry)));
            }
        }
        self.object_store.changes.record(old_id);
        self.object_store.render_changes.record(old_id);
        let old_object = ObjectStore::into_owned_object(self.objects.remove(&old_id)?);
        self.auxiliary_tracking_mut().acquired_spell_keywords.remove(&old_id);
        self.auxiliary_tracking_mut().duration_windows.remove(&crate::game_state::LibraryTopAnnouncement::Cast(old_id));
        self.effect_store.continuous_effects.remove_source_bound_static_effects(old_id);
        self.turn_store.forecast_revealed_hand_cards.remove(&old_id);
        self.turn_store
            .hand_cards_revealed_until_owners_next_turn
            .remove(&old_id);
        let hidden_card_info = self.auxiliary_tracking_mut().hidden_cards.remove(&old_id);
        if hidden_card_info.is_some()
            && old_object.zone.is_public()
            && !was_face_down
            && !was_foretold
        {
            // Every peer had to open this card while it sat face up in a
            // public zone, checking its claims then: settle them now,
            // identically on every peer.
            self.settle_public_hidden_identity_obligations(old_object.stable_id);
        }
        self.auxiliary_tracking_mut()
            .sector_designations
            .remove(&old_id);
        // A publicly revealed hidden card becomes a new object (CR 400.7).
        self.forget_public_hidden_card_reveal(old_id);
        self.clear_hidden_face_down_cast_claim(old_id);
        self.stable_id_index.remove(&old_object.stable_id);
        self.commander_tracking_mut()
            .declined_command_zone_moves
            .remove(&old_id);
        let old_zone = old_object.zone;
        let owner = old_object.owner;

        let preserves_exile_grants_for_adventure_stack_cast = old_zone == Zone::Exile
            && new_zone == Zone::Stack
            && crate::decision::spell_has_adventure_half(self, &old_object);
        if old_zone != new_zone && !preserves_exile_grants_for_adventure_stack_cast {
            self.effect_store
                .grant_registry
                .remove_stable_card_grants_for_zone(old_object.stable_id, old_zone);
        }
        if old_zone == Zone::Stack && new_zone != Zone::Exile {
            self.effect_store
                .grant_registry
                .remove_stable_card_grants_for_zone(old_object.stable_id, Zone::Exile);
        }

        if let Some(target) = old_object.attached_to {
            match target {
                AttachmentTarget::Object(id) => {
                    if let Some(parent) = self.object_mut(id) {
                        parent.attachments.retain(|existing| *existing != old_id);
                    }
                }
                AttachmentTarget::Player(id) => {
                    if let Some(player) = self.player_mut(id) {
                        player.attachments.retain(|existing| *existing != old_id);
                    }
                }
            }
        }

        // Remove from old zone index
        self.remove_from_zone_index(old_id, old_zone, owner);
        self.object_annotations_mut().turn_face_up_before_action.remove(&old_id);

        self.clear_incarnation_custom_statuses(old_id);

        // Clear state from old zone's extension maps
        if old_zone == Zone::Battlefield {
            self.clear_battlefield_state(old_id);
            self.clear_player_control_from_source(old_object.stable_id);
        }
        if old_zone == Zone::Exile {
            self.clear_exile_state(old_id);
        }
        if old_zone == Zone::Stack {
            self.exile_tracking_mut()
                .cast_origin_snapshots
                .remove(&old_id);
        }

        if old_zone == Zone::Battlefield
            && new_zone != Zone::Battlefield
            && let Some(merged) = self.merged_permanent(old_object.stable_id).cloned()
        {
            let component_destinations = self
                .commander_tracking_mut()
                .pending_merged_component_destinations
                .remove(&old_object.stable_id);
            let mut result_object_ids = Vec::with_capacity(merged.components.len());
            for (index, component) in merged.components.iter().enumerate() {
                let component_zone = component_destinations
                    .as_ref()
                    .and_then(|destinations| destinations.get(index))
                    .copied()
                    .unwrap_or(new_zone);
                let new_component_id =
                    self.create_merged_component_object(component, component_zone)?;
                result_object_ids.push(new_component_id);
            }
            self.commander_tracking_mut()
                .merged_permanents
                .remove(&old_object.stable_id);
            self.distribute_merged_stickers(old_object.stable_id, &result_object_ids);

            use crate::events::zones::ZoneChangeEvent;
            use crate::triggers::TriggerEvent;

            let event = ZoneChangeEvent::with_results(
                old_id,
                result_object_ids.clone(),
                old_zone,
                new_zone,
                cause,
                pre_move_snapshot,
            );
            let event_provenance = self
                .provenance_graph_mut()
                .alloc_root_event(crate::events::EventKind::ZoneChange);
            self.queue_trigger_event(
                event_provenance,
                TriggerEvent::new_with_provenance(event, event_provenance)
                    .with_lookback_source_snapshots(pre_event_lookback_source_snapshots.to_vec()),
            );
            self.record_zone_change_results(old_id, result_object_ids.clone());
            if old_zone != new_zone {
                for result_object_id in &result_object_ids {
                    self.record_ui_zone_transition(old_id, *result_object_id, old_zone, new_zone);
                }
            }

            self.complete_source_phase_duration_returns(phase_duration_returns);
        self.reconcile_library_top_identity();
            #[cfg(debug_assertions)]
            self.debug_assert_zone_consistency();
            self.reconcile_ring_bearers();
            return result_object_ids.first().copied();
        }

        if old_zone == Zone::Battlefield
            && new_zone != Zone::Battlefield
            && let Some(melded) = self.melded_permanent(old_object.stable_id).cloned()
        {
            // CR 903.9c: per-component commander destinations, if any.
            let component_destinations = self
                .commander_tracking_mut()
                .pending_merged_component_destinations
                .remove(&old_object.stable_id);
            let mut result_object_ids = Vec::with_capacity(melded.components.len());
            for (index, component) in melded.components.iter().enumerate() {
                let component_zone = component_destinations
                    .as_ref()
                    .and_then(|destinations| destinations.get(index))
                    .copied()
                    .unwrap_or(new_zone);
                let new_component_id =
                    self.create_meld_component_object(component, component_zone)?;
                result_object_ids.push(new_component_id);
            }
            self.commander_tracking_mut()
                .melded_permanents
                .remove(&old_object.stable_id);
            self.distribute_merged_stickers(old_object.stable_id, &result_object_ids);

            use crate::events::zones::ZoneChangeEvent;
            use crate::triggers::TriggerEvent;

            let event = ZoneChangeEvent::with_results(
                old_id,
                result_object_ids.clone(),
                old_zone,
                new_zone,
                cause,
                pre_move_snapshot,
            );
            let event_provenance = self
                .provenance_graph_mut()
                .alloc_root_event(crate::events::EventKind::ZoneChange);
            self.queue_trigger_event(
                event_provenance,
                TriggerEvent::new_with_provenance(event, event_provenance)
                    .with_lookback_source_snapshots(pre_event_lookback_source_snapshots.to_vec()),
            );
            self.record_zone_change_results(old_id, result_object_ids.clone());
            if old_zone != new_zone {
                for result_object_id in &result_object_ids {
                    self.record_ui_zone_transition(old_id, *result_object_id, old_zone, new_zone);
                }
            }

            self.complete_source_phase_duration_returns(phase_duration_returns);
        self.reconcile_library_top_identity();
            #[cfg(debug_assertions)]
            self.debug_assert_zone_consistency();

            self.reconcile_ring_bearers();

            return result_object_ids.first().copied();
        }

        // Create new object with new ID (zone change = new object per rule 400.7)
        let new_id = self.new_object_id();
        // A replacement waiting for this card follows it onto the stack and
        // ends on any other zone change (CR 400.7).
        self.effect_store
            .replacement_effects
            .rebind_followed_object(old_id, new_id, new_zone);
        let mut new_object = old_object;
        new_object.id = new_id;
        new_object.zone = new_zone;
        if !(old_zone == Zone::Stack && new_zone == Zone::Battlefield) {
            new_object.initial_controller = owner;
        }
        if old_zone == Zone::Command {
            self.auxiliary_tracking_mut()
                .departed_command_zone_tokens
                .remove(&old_id);
        }
        if new_object.kind == crate::object::ObjectKind::Token
            && old_zone == Zone::Battlefield
            && new_zone == Zone::Command
        {
            self.auxiliary_tracking_mut()
                .departed_command_zone_tokens
                .insert(new_id);
        }
        if old_zone == Zone::Stack && new_zone != Zone::Stack {
            new_object.end_stack_program_overlay();
        }
        if old_zone == Zone::Stack
            && new_zone == Zone::Battlefield
            && matches!(new_object.kind, crate::object::ObjectKind::SpellCopy)
        {
            new_object.kind = crate::object::ObjectKind::Token;
        }
        // Counters are tied to the object instance, not to the physical card.
        // `move_object` always creates the new object for the destination.
        if !retain_counters {
            new_object.counters.clear();
        }

        // Reset zone-specific state on the object
        if let Some(authored)=new_object.optional_costs_before_payment_alternatives.take(){new_object.optional_costs=authored;}
        new_object.attached_to = None;
        new_object.attachments.clear();
        // Casting-contribution state should not persist across arbitrary zone changes.
        // Preserve it only for Stack -> Battlefield (a spell resolving into a permanent).
        let preserve_face_down_overlay =
            new_zone == Zone::Battlefield && new_object.face_down_cast_state.is_some();
        let preserve_bestow_overlay =
            new_zone == Zone::Battlefield && new_object.bestow_cast_state.is_some();
        let preserve_prototype_overlay = matches!(new_zone, Zone::Stack | Zone::Battlefield)
            && new_object.prototype_cast_state.is_some();
        let preserve_temporary_static_ability_grants =
            old_zone == Zone::Stack && new_zone == Zone::Battlefield;
        if !(old_zone == Zone::Command && new_zone == Zone::Battlefield) {
            new_object.token_creation_method = None;
        }
        let preserve_cast_tags = new_zone == Zone::Stack
            || (old_zone == Zone::Stack && new_zone == Zone::Battlefield)
            || (old_zone == Zone::Command && new_zone == Zone::Battlefield
                && matches!(new_object.kind, crate::object::ObjectKind::Token));
        let preserve_optional_costs_paid = old_zone == Zone::Stack && new_zone == Zone::Battlefield;
        let preserve_x_value = old_zone == Zone::Stack && new_zone == Zone::Battlefield;
        // Restore enters-as characteristics first, so the printed values saved
        // by the face-down, bestow and prototype overlays below always win.
        if matches!(old_zone, Zone::Battlefield | Zone::Stack) && new_zone != Zone::Battlefield {
            new_object.end_enters_as_copy_overlay();
        }
        // CR 702.51c: "creatures that convoked it" stays linked to the
        // permanent the resolving spell becomes.
        if !preserve_optional_costs_paid {
            new_object.keyword_payment_contributions_to_cast.clear();
        }
        if !preserve_face_down_overlay && !preserve_bestow_overlay {
            // The face-down and bestow overlays overwrote the object's
            // copiable fields; restore the printed card as it leaves (CR 708.9,
            // 400.7, 702.103). Merely dropping the saved state would leave the
            // card in its new zone as a "Face-down creature" / Aura.
            new_object.end_bestow_cast_overlay();
            new_object.end_face_down_cast_overlay();
        }
        // CR 718.4: end the prototype overlay after the face-down overlay,
        // whose saved values are the prototype characteristics when a
        // prototyped permanent was turned face down.
        // A token (e.g. a resolved copy of a prototyped spell) has no other
        // characteristics to return to; only a card does (CR 718.3c, 718.4).
        if !preserve_prototype_overlay && new_object.kind == crate::object::ObjectKind::Card {
            new_object.end_prototype_cast_overlay();
        }
        if !preserve_x_value {
            new_object.x_value = None;
        }
        if !(old_zone == Zone::Stack && new_zone == Zone::Battlefield) {
            new_object.snow_mana_spent_to_cast = crate::player::ManaPool::default();
            new_object.mana_spent_on_x = Some(crate::mana::XManaAllocation::default());
        }
        if !preserve_cast_tags {
            new_object.cast_tagged_objects.clear();
        }
        if !(old_zone==Zone::Stack && new_zone==Zone::Battlefield) {
            new_object.named_payment_outcomes.clear();
        }
        if !preserve_temporary_static_ability_grants {
            new_object.temporary_static_ability_grants.clear();
        }
        // A selected land permission attaches its rider to the original
        // entering object before entry counters or any added programs run.
        // Redirected / independent replacement moves cannot lend this grant
        // to another permanent or a later incarnation.
        if let Some(abilities) = self
            .runtime_cache
            .pending_land_permission_grants
            .remove(&old_id)
        {
            if new_zone == Zone::Battlefield
                && cause.cause_type == crate::events::cause::CauseType::SpecialAction
                && cause.source == Some(old_id)
            {
                for ability in abilities {
                    new_object.temporary_static_ability_grants.push(
                        crate::object::TemporaryStaticAbilityGrant {
                            ability: ability.id(),
                            ability_payload: Some(ability),
                            expires_end_of_turn: None,
                        },
                    );
                }
            }
        }
        if !preserve_optional_costs_paid {
            new_object.optional_costs_paid = crate::cost::OptionalCostsPaid::default();
        }
        new_object.cast_alternative_method = None;
        new_object.cast_play_from_constraints = None;
        new_object.cast_price = None;
        new_object.cast_play_permission = None;
        // A card cast through a granted "it gains suspend" trigger carries a
        // synthetic "Suspend 0—{0}" permission only for that cast; it isn't a
        // printed ability and must not follow the card (CR 400.7, 702.62a).
        if old_zone == Zone::Stack
            && new_zone != Zone::Stack
            && new_object
                .alternative_casts
                .iter()
                .any(is_synthetic_granted_suspend)
        {
            new_object.alternative_casts = new_object
                .alternative_casts
                .iter()
                .filter(|method| !is_synthetic_granted_suspend(method))
                .cloned()
                .collect::<Vec<_>>()
                .into();
        }

        // CR 715.3c / 720.3c / 704.5e: a copied Adventure or Omen spell has
        // no physical normal face; it keeps the inset until it ceases.
        if old_zone == Zone::Stack
            && new_zone != Zone::Stack
            && new_object.kind != crate::object::ObjectKind::SpellCopy
            && (new_object.subtypes.contains(&Subtype::Adventure)
                || new_object.subtypes.contains(&Subtype::Omen))
            && let Some(front_def) = self.linked_face_definition_by_name_or_id(
                new_object.other_face_name.as_deref(),
                new_object.other_face,
            )
        {
            let handles = self.object_store.shared_handles_for_definition(&front_def);
            new_object.apply_definition_face_with_shared(&front_def, &handles);
        }
        // CR 712.8a / 712.14: outside the battlefield and the stack a
        // transforming double-faced card has only its front face, and it
        // enters the battlefield front face up unless an effect says otherwise.
        // A flipped flip card likewise leaves as the unflipped card (CR 710.2,
        // 710.4).
        let leaves_battlefield_or_stack = matches!(old_zone, Zone::Battlefield | Zone::Stack)
            && !matches!(new_zone, Zone::Battlefield | Zone::Stack);
        if (leaves_battlefield_or_stack
            || (entry_definition.is_some() && !matches!(new_zone, Zone::Battlefield | Zone::Stack))
            || (old_zone == Zone::Exile && new_zone == Zone::Battlefield))
            && matches!(
                new_object.linked_face_layout,
                LinkedFaceLayout::TransformLike | LinkedFaceLayout::Flip
            )
            && new_object.kind != crate::object::ObjectKind::SpellCopy
            && let Some(front_def) =
                self.default_face_definition_for_transform_like_return(&new_object)
        {
            let handles = self.object_store.shared_handles_for_definition(&front_def);
            new_object.apply_definition_face_with_shared(&front_def, &handles);
        }

        if new_zone == Zone::Battlefield
            && let Some(definition) = entry_definition
        {
            let handles = self.object_store.shared_handles_for_definition(definition);
            new_object.apply_definition_face_with_shared(definition, &handles);
        }

        // Set battlefield state for new permanents
        if new_zone == Zone::Battlefield {
            self.set_summoning_sick(new_id);
        }

        if !physical_components.is_empty() {
            // A combined permanent is one new representation of all sources,
            // rather than an extra physical card with a fabricated origin.
            new_object.stable_id = crate::ids::StableId::from(new_id);
            if let Some(definition) = entry_definition {
                new_object.card = Some(definition.card.id);
            }
        }
        if new_zone == Zone::Battlefield {
            new_object.linked_face_mana_cost = entry_linked_face_mana_cost
                .cloned()
                .map(Into::into)
                .or(new_object.linked_face_mana_cost);
        }
        // Assemble the entering representation before publishing it. Never
        // alter the origin object's face or its last-known-information packet.
        if entry_face_down && new_zone == Zone::Battlefield {
            new_object.apply_face_down_cast_overlay();
            self.set_face_down(new_id);
        }
        let sticker_identity = new_object.stable_id;
        self.add_object(new_object);
        // The designation belongs to an exact origin and only its immediate
        // spell successor. A different departure consumes the continuation;
        // copies, later recasts, and resolving permanents cannot inherit it.
        if let Some(statuses)=self.exile_tracking_mut().cast_continuation_statuses.remove(&old_id) {
            for name in statuses {
                if let Some(old_statuses)=self.battlefield_flags_mut().custom_statuses.get_mut(&old_id) { old_statuses.remove(&name); }
                if new_zone==Zone::Stack { self.set_custom_status_in_zone(new_id,&name,Zone::Stack,true); }
            }
        }
        // The component objects cease to exist as representations, but their
        // physical stickers belong to the combined entrant (CR 123.5a).
        self.absorb_component_stickers_batch(
            physical_components.iter().map(|component| component.snapshot.stable_id), new_id,
        );
        for component in physical_components {
            if component.snapshot.object_id != old_id { self.remove_object(component.snapshot.object_id); }
        }
        if turn_face_up_before_action && old_zone == Zone::Stack && new_zone == Zone::Battlefield {
            self.register_turn_face_up_before_action(new_id);
        }
        if old_zone == Zone::Stack && new_zone == Zone::Battlefield {
            self.transfer_cast_linked_exile_pairs(old_id, new_id);
            self.transfer_exiled_with_source_links(old_id, new_id);
            self.effect_store
                .continuous_effects
                .retarget_resolved_permanent_spell(old_id, new_id);
            self.effect_store
                .prevention_effects
                .link_resolved_permanent_spell(old_id, new_id);
        }
        self.move_stickers_to_new_object(sticker_identity, new_id, new_zone);
        if new_zone == Zone::Battlefield {
            self.note_attraction_entered_battlefield(new_id);
        }
        if let Some(mut info) = hidden_card_info {
            let audit_info = info.clone();
            let entering_library = (new_zone == Zone::Library && old_zone != Zone::Library)
                .then(|| audit_info.clone());
            info.zone = new_zone;
            info.incarnation = next_hidden_incarnation;
            self.observe_hidden_incarnation(info.incarnation);
            self.auxiliary_tracking_mut()
                .hidden_cards
                .insert(new_id, info);
            self.hydrate_verified_library_replay_zone(new_id, new_zone);
            self.push_hidden_info_operation(HiddenInfoOperation::HiddenMove {
                owner: audit_info.owner,
                old_object_id: old_id,
                new_object_id: new_id,
                from: old_zone,
                to: new_zone,
                slot: audit_info.slot,
                commitment: audit_info.commitment,
            });
            if let Some(entering) = entering_library {
                // A claim subject entering a library is anchored to its
                // durable ziffle ciphertext (checked at the end-of-match
                // disclosure), since reshuffles break the object link.
                self.anchor_hidden_card_entering_library(new_id, &entering);
            } else if new_zone == Zone::Graveyard {
                // A card put into a graveyard is face up and opened on every
                // peer, which checks its claims then; it needs no anchor.
                self.forget_hidden_claim_subject(sticker_identity);
            }
        }

        // CR 406.3 / 400.7: a face-down exiled card that leaves exile is a new
        // object that enters face up (a Hideaway land played from exile, a
        // Praetor's Grasp card put onto the battlefield) unless the effect
        // itself says face down, which uses the face-down cast overlay. Only a
        // face-down permanent or spell carries its status onto the battlefield.
        if new_zone == Zone::Battlefield
            && ((was_face_down && matches!(old_zone, Zone::Battlefield | Zone::Stack))
                || self
                    .object(new_id)
                    .is_some_and(|obj| obj.face_down_cast_state.is_some()))
        {
            self.set_face_down(new_id);
        }
        if old_zone == Zone::Exile && new_zone == Zone::Exile && was_face_down {
            self.set_face_down(new_id);
            if let Some(viewers) = preserved_exile_viewers {
                for viewer in viewers {
                    self.grant_face_down_exile_view(new_id, viewer);
                }
            }
        }

        if old_zone != new_zone {
            self.record_ui_zone_transition(old_id, new_id, old_zone, new_zone);
        }
        // CR 708.9: a face-down permanent or spell that moves to another zone
        // is revealed by its owner (it isn't when it stays face down, e.g. a
        // face-down spell resolving). An identity this peer can't open yet is
        // disclosed by the hidden-card protocol instead.
        if was_face_down
            && matches!(old_zone, Zone::Battlefield | Zone::Stack)
            && old_zone != new_zone
            && !self.is_face_down(new_id)
            && !self.is_hidden_card_placeholder(new_id)
        {
            self.record_face_down_reveal(new_id, owner);
        }

        // CR 613.7d: an object receives a timestamp whenever it enters a zone.
        self.effect_store.continuous_effects.record_entry(new_id);
        self.restamp_object_stickers(new_id);
        if new_zone == Zone::Battlefield {
            self.handle_day_night_object_entered(new_id);
        }

        // Queue zone change event for triggers.
        if old_zone != new_zone {
            use crate::events::zones::ZoneChangeEvent;
            use crate::triggers::TriggerEvent;

            // For LTB-style moves we keep the pre-move object ID; for all others use
            // the destination object ID so ETB/"this enters" matching remains stable.
            let event_object_id = if old_zone == Zone::Battlefield {
                old_id
            } else {
                new_id
            };
            let event = if physical_components.is_empty() {
                ZoneChangeEvent::with_cause(
                    event_object_id,
                    old_zone,
                    new_zone,
                    cause,
                    pre_move_snapshot.clone(),
                )
            } else {
                let mut event = ZoneChangeEvent::batch_with_snapshots(
                    vec![new_id],
                    old_zone,
                    new_zone,
                    cause,
                    physical_components
                        .iter()
                        .map(|component| component.snapshot.clone())
                        .collect(),
                );
                event.result_objects = vec![new_id];
                event
            };
            let mut event = event;
            // Every committed move has an exact destination incarnation.
            // Entry predicates retain this identity after that object leaves;
            // the origin snapshot cannot establish it on its own.
            event.result_objects = vec![new_id];
            if old_zone == Zone::Battlefield {
                if let Some(snapshot) = pre_move_snapshot.as_ref() {
                    for attachment_id in &snapshot.attachments {
                        if let Some(attachment) = self.object(*attachment_id) {
                            event = event.with_object_tag(
                                crate::tag::TagKey::from("attached_source"),
                                crate::snapshot::ObjectSnapshot::from_object(attachment, self),
                            );
                        }
                    }
                }
            }
            let event_provenance = self
                .provenance_graph_mut()
                .alloc_root_event(crate::events::EventKind::ZoneChange);
            self.queue_trigger_event(
                event_provenance,
                TriggerEvent::new_with_provenance(event, event_provenance)
                    .with_lookback_source_snapshots(pre_event_lookback_source_snapshots.to_vec()),
            );
        }
        self.record_zone_change_results(old_id, vec![new_id]);
        for component in physical_components {
            self.record_zone_change_results(component.snapshot.object_id, vec![new_id]);
        }

        self.complete_source_phase_duration_returns(phase_duration_returns);
        self.reconcile_library_top_identity();
        // Validate zone consistency in debug builds
        #[cfg(debug_assertions)]
        self.debug_assert_zone_consistency();

        self.reconcile_ring_bearers();

        Some(new_id)
    }

    pub(crate) fn default_face_definition_for_transform_like_return(
        &self,
        object: &Object,
    ) -> Option<crate::cards::CardDefinition> {
        let other_def = self.linked_face_definition_by_name_or_id(
            object.other_face_name.as_deref(),
            object.other_face,
        )?;
        let returns_to_default_face = |layout: LinkedFaceLayout| {
            matches!(
                layout,
                LinkedFaceLayout::TransformLike | LinkedFaceLayout::Flip
            )
        };
        if !returns_to_default_face(other_def.card.linked_face_layout) {
            return None;
        }
        let current_def = self.displayed_face_definition(object)?;
        if !returns_to_default_face(current_def.card.linked_face_layout) {
            return None;
        }

        // CR 715.4/719.4: an Adventurer or Omen card's normal face is its only
        // face outside the stack, whichever face definition was created first.
        let inset = |def: &crate::cards::CardDefinition| {
            def.card.subtypes.contains(&Subtype::Adventure)
                || def.card.subtypes.contains(&Subtype::Omen)
        };
        match (inset(&current_def), inset(&other_def)) {
            (true, false) => return Some(other_def),
            (false, true) => return None,
            _ => {}
        }
        self.linked_face_is_back(current_def.card.id, other_def.card.id).then_some(other_def)
    }

    pub fn move_object_by_effect(&mut self, old_id: ObjectId, new_zone: Zone) -> Option<ObjectId> {
        self.move_object(old_id, new_zone, crate::events::cause::EventCause::effect())
    }

    pub fn move_object_by_game_rule(
        &mut self,
        old_id: ObjectId,
        new_zone: Zone,
    ) -> Option<ObjectId> {
        self.move_object(
            old_id,
            new_zone,
            crate::events::cause::EventCause::from_game_rule(),
        )
    }

    /// Put an object its owner owns into the ante zone (CR 407.4).
    ///
    /// Ante-specific card effects should use this entrypoint so the
    /// owner-only restriction is enforced centrally.
    pub fn ante_owned_object(
        &mut self,
        owner: PlayerId,
        object_id: ObjectId,
    ) -> Result<ObjectId, String> {
        let Some(object) = self.object(object_id) else {
            return Err("cannot ante a missing object".to_string());
        };
        if object.owner != owner {
            return Err("a player can ante only an object they own".to_string());
        }
        if object.zone == Zone::Ante {
            return Ok(object_id);
        }
        self.move_object_by_game_rule(object_id, Zone::Ante)
            .ok_or_else(|| "the object could not be moved to ante".to_string())
    }

    /// Select a random card from a player's library and ante it (CR 407.2).
    pub fn ante_random_library_card(&mut self, owner: PlayerId) -> Result<ObjectId, String> {
        let mut candidates = self
            .player(owner)
            .ok_or_else(|| "cannot ante for a missing player".to_string())?
            .library
            .to_vec();
        if candidates.is_empty() {
            return Err("cannot ante from an empty library".to_string());
        }
        self.shuffle_slice(&mut candidates);
        self.ante_owned_object(owner, candidates[0])
    }

    /// Transfer ownership of every card in ante to the winning player at the
    /// end of the game (CR 407.2). Returns the number of changed owners and is
    /// deliberately idempotent so duplicate terminal-result observations are
    /// harmless.
    pub fn finalize_ante_ownership(&mut self, winner: PlayerId) -> usize {
        if self.player(winner).is_none() {
            return 0;
        }
        let ante_ids = self.ante.clone();
        let mut changed = 0;
        for id in ante_ids {
            if self.object(id).is_some_and(|object| object.owner != winner) {
                if let Some(object) = self.object_mut(id) {
                    object.owner = winner;
                }
                changed += 1;
            }
        }
        changed
    }

    pub fn move_object_by_sba(&mut self, old_id: ObjectId, new_zone: Zone) -> Option<ObjectId> {
        self.move_object(
            old_id,
            new_zone,
            crate::events::cause::EventCause::from_sba(),
        )
    }

    pub(crate) fn move_object_by_sba_with_snapshot(
        &mut self,
        old_id: ObjectId,
        new_zone: Zone,
        snapshot: Option<crate::snapshot::ObjectSnapshot>,
    ) -> Option<ObjectId> {
        self.move_object_with_snapshot(
            old_id,
            new_zone,
            crate::events::cause::EventCause::from_sba(),
            snapshot,
        )
    }

    /// Move an object to the battlefield with ETB replacement effect processing.
    ///
    /// This processes replacement effects that modify how a permanent enters the battlefield:
    /// - "Enters tapped" effects (from the permanent itself or other sources)
    /// - "Enters with N counters" effects
    /// - "If this would enter the battlefield, exile it instead"
    ///
    /// For moves TO the battlefield, this should be used instead of `move_object`
    /// to ensure replacement effects are properly applied.
    pub fn move_object_with_etb_processing(
        &mut self,
        old_id: ObjectId,
        new_zone: Zone,
    ) -> Result<super::EntryCommitResult, crate::effects::ExecutionError> {
        let mut dm = crate::decision::SelectFirstDecisionMaker;
        self.move_object_with_etb_processing_with_dm(old_id, new_zone, &mut dm)
    }

    /// Move an object to the battlefield with ETB replacement processing and decisions.
    pub fn move_object_with_etb_processing_with_dm(
        &mut self,
        old_id: ObjectId,
        new_zone: Zone,
        decision_maker: &mut dyn crate::decision::DecisionMaker,
    ) -> Result<super::EntryCommitResult, crate::effects::ExecutionError> {
        self.move_object_with_etb_processing_with_dm_and_cause(
            old_id,
            new_zone,
            crate::events::cause::EventCause::effect(),
            decision_maker,
        )
    }

    /// Move an object with an authored tapped instruction in the original entry
    /// event, before replacement effects modify it.
    pub(crate) fn move_object_with_etb_processing_with_entry_options(
        &mut self,
        old_id: ObjectId,
        new_zone: Zone,
        decision_maker: &mut dyn crate::decision::DecisionMaker,
        initial_enters_tapped: bool,
        choose_aura_attachment: bool,
    ) -> Result<super::EntryCommitResult, crate::effects::ExecutionError> {
        self.move_object_with_etb_processing_with_cause_and_entry_options(
            old_id,
            new_zone,
            crate::events::cause::EventCause::effect(),
            decision_maker,
            initial_enters_tapped,
            choose_aura_attachment,
        )
    }

    pub(crate) fn move_object_with_etb_processing_with_cause_and_entry_options(
        &mut self,
        old_id: ObjectId,
        new_zone: Zone,
        cause: crate::events::cause::EventCause,
        decision_maker: &mut dyn crate::decision::DecisionMaker,
        initial_enters_tapped: bool,
        choose_aura_attachment: bool,
    ) -> Result<super::EntryCommitResult, crate::effects::ExecutionError> {
        self.move_object_with_etb_processing_with_dm_and_cause_internal(
            old_id,
            new_zone,
            cause,
            decision_maker,
            choose_aura_attachment,
            Vec::new(),
            None,
            initial_enters_tapped,
            None,
            None,
        )
    }

    /// Reuse the native prospective-entry projection after every replacement
    /// and as-enters choice, without committing an entry or publishing events.
    pub(crate) fn prepared_entry_attachment_game_state(
        &self, object: ObjectId, prepared: &PreparedEtbEntry,
        controller: Option<PlayerId>,
    ) -> Result<Option<GameState>, crate::effects::ExecutionError> {
        let result = &prepared.result;
        let mut event = crate::events::EnterBattlefieldEvent::new(object, self.object(object).ok_or(crate::effects::ExecutionError::ObjectNotFound(object))?.zone);
        event.enters_as_copy_of = result.enters_as_copy_of;
        event.copy_followups = result.copy_followups.clone();
        event.copy_duration = result.copy_duration.clone();
        event.copy_name_override = result.copy_name_override.clone();
        event.added_colors = result.added_colors;
        event.added_card_types = result.added_card_types.clone();
        event.removes_other_card_types = result.removes_other_card_types;
        event.added_supertypes = result.added_supertypes.clone();
        event.removed_supertypes = result.removed_supertypes.clone();
        event.added_subtypes = result.added_subtypes.clone();
        event.added_abilities = result.added_abilities.clone();
        event.set_base_power_toughness = result.set_base_power_toughness;
        event.controller_override = result.controller_override.or(controller);
        event.enters_with_counters = result.enters_with_counters.clone();
        event.program_choices = prepared.choices.clone();
        event.try_prospective_game_state(self)
            .map_err(crate::effects::ExecutionError::ContinuousDiscovery)
    }

    /// Original creation instructions belong to every replacement-added token.
    pub(crate) fn move_created_token_with_entry_instructions(
        &mut self,
        old_id: ObjectId,
        cause: crate::events::cause::EventCause,
        decision_maker: &mut dyn crate::decision::DecisionMaker,
        enters_tapped: bool,
        choose_aura_attachment: bool,
        counters: Vec<(crate::object::CounterType, u32)>,
        attachment: Option<AttachmentTarget>,
        attachment_specified: bool,
    ) -> Result<super::EntryCommitResult, crate::effects::ExecutionError> {
        if attachment_specified {
            // Prepare replacement/entry choices inside the same transaction as
            // the fixed attachment; pending choices publish no partial world.
            let mut working=self.clone();
            let old_zone = working.object(old_id).map(|object|object.zone).unwrap_or(Zone::Command);
            let result = crate::events::processing::process_etb_with_event_and_dm_with_initial_counters_and_controller(
                &mut working,old_id,old_zone,decision_maker,counters.clone(),None,enters_tapped,cause.clone())?;
            let Some(mut prepared)=working.prepare_etb_entry_with_controller_and_dm(old_id,result,None,decision_maker)? else {
                return Ok(super::EntryCommitResult { original:crate::events::processing::EventOutcome::NotApplicable, programs:Vec::new(), pending:decision_maker.awaiting_choice(), published_outputs:Vec::new() });
            };
            prepared.entry_attachment=attachment;
            prepared.entry_attachment_requires_aura=true;
            prepared.entry_attachment_specified=true;
            let result=working.move_object_with_etb_processing_with_dm_and_cause_internal(
                old_id,Zone::Battlefield,cause,decision_maker,false,Vec::new(),None,enters_tapped,Some(prepared),None)?;
            if decision_maker.awaiting_choice(){return Ok(super::EntryCommitResult::pending())}
            *self=working;
            return Ok(result);
        }
        self.move_object_with_etb_processing_with_dm_and_cause_internal(
            old_id,
            Zone::Battlefield,
            cause,
            decision_maker,
            choose_aura_attachment,
            counters,
            None,
            enters_tapped,
            None,
            None,
        )
    }

    pub(crate) fn move_object_with_etb_processing_with_cause_and_entry_options_and_controller(
        &mut self,
        old_id: ObjectId,
        new_zone: Zone,
        cause: crate::events::cause::EventCause,
        decision_maker: &mut dyn crate::decision::DecisionMaker,
        entering_controller: Option<PlayerId>,
        initial_enters_tapped: bool,
        choose_aura_attachment: bool,
        authored_entry_definition: Option<crate::cards::CardDefinition>,
    ) -> Result<super::EntryCommitResult, crate::effects::ExecutionError> {
        self.move_object_with_etb_processing_with_dm_and_cause_internal(
            old_id,
            new_zone,
            cause,
            decision_maker,
            choose_aura_attachment,
            Vec::new(),
            entering_controller,
            initial_enters_tapped,
            None,
            authored_entry_definition,
        )
    }

    /// Move an object to the battlefield with ETB replacement processing and an explicit cause.
    pub fn move_object_with_etb_processing_with_dm_and_cause(
        &mut self,
        old_id: ObjectId,
        new_zone: Zone,
        cause: crate::events::cause::EventCause,
        decision_maker: &mut dyn crate::decision::DecisionMaker,
    ) -> Result<super::EntryCommitResult, crate::effects::ExecutionError> {
        self.move_object_with_etb_processing_with_dm_and_cause_internal(
            old_id,
            new_zone,
            cause,
            decision_maker,
            true,
            Vec::new(),
            None,
            false,
            None,
            None,
        )
    }

    pub fn move_object_with_etb_processing_with_initial_counters_with_dm(
        &mut self,
        old_id: ObjectId,
        new_zone: Zone,
        initial_enters_with_counters: Vec<(crate::object::CounterType, u32)>,
        decision_maker: &mut dyn crate::decision::DecisionMaker,
    ) -> Result<super::EntryCommitResult, crate::effects::ExecutionError> {
        self.move_object_with_etb_processing_with_dm_and_cause_internal(
            old_id,
            new_zone,
            crate::events::cause::EventCause::effect(),
            decision_maker,
            true,
            initial_enters_with_counters,
            None,
            false,
            None,
            None,
        )
    }

    pub(crate) fn move_object_with_etb_processing_with_initial_counters_and_controller_with_dm(
        &mut self,
        old_id: ObjectId,
        new_zone: Zone,
        initial_enters_with_counters: Vec<(crate::object::CounterType, u32)>,
        entering_controller: Option<PlayerId>,
        decision_maker: &mut dyn crate::decision::DecisionMaker,
    ) -> Result<super::EntryCommitResult, crate::effects::ExecutionError> {
        self.move_object_with_etb_processing_with_dm_and_cause_internal(
            old_id,
            new_zone,
            crate::events::cause::EventCause::effect(),
            decision_maker,
            true,
            initial_enters_with_counters,
            entering_controller,
            false,
            None,
            None,
        )
    }

    pub fn move_object_with_etb_processing_without_aura_attachment_choice(
        &mut self,
        old_id: ObjectId,
        new_zone: Zone,
        decision_maker: &mut dyn crate::decision::DecisionMaker,
    ) -> Result<super::EntryCommitResult, crate::effects::ExecutionError> {
        self.move_object_with_etb_processing_with_dm_and_cause_internal(
            old_id,
            new_zone,
            crate::events::cause::EventCause::effect(),
            decision_maker,
            false,
            Vec::new(),
            None,
            false,
            None,
            None,
        )
    }

    /// Resolve every choice and action that forms part of an object's entry
    /// before the destination object is created.
    ///
    /// The returned record is independent of the source-zone object ID and can
    /// therefore be collected for every member of a simultaneous-entry batch
    /// before any member is committed.
    pub(crate) fn prepare_etb_entry_with_controller_and_dm(
        &mut self,
        old_id: ObjectId,
        result: crate::events::processing::EtbEventResult,
        entering_controller: Option<PlayerId>,
        decision_maker: &mut dyn crate::decision::DecisionMaker,
    ) -> Result<Option<PreparedEtbEntry>, crate::effects::ExecutionError> {
        self.prepare_etb_entry_after_programs(
            old_id,
            result,
            entering_controller,
            decision_maker,
            None,
        )
    }

    pub(crate) fn prepare_etb_entry_after_programs(
        &mut self,
        old_id: ObjectId,
        result: crate::events::processing::EtbEventResult,
        entering_controller: Option<PlayerId>,
        decision_maker: &mut dyn crate::decision::DecisionMaker,
        completed_programs: Option<(PreparedEtbChoices, Vec<crate::ability::Ability>)>,
    ) -> Result<Option<PreparedEtbEntry>, crate::effects::ExecutionError> {
        let checkpoint = self.clone();
        let outcome = self.prepare_etb_entry_after_programs_inner(
            old_id,
            result,
            entering_controller,
            decision_maker,
            completed_programs,
        );
        if outcome.is_err() || decision_maker.awaiting_choice() {
            *self = checkpoint;
            return outcome.map(|_| None);
        }
        outcome
    }

    fn prepare_etb_entry_after_programs_inner(
        &mut self,
        old_id: ObjectId,
        mut result: crate::events::processing::EtbEventResult,
        entering_controller: Option<PlayerId>,
        decision_maker: &mut dyn crate::decision::DecisionMaker,
        completed_programs: Option<(PreparedEtbChoices, Vec<crate::ability::Ability>)>,
    ) -> Result<Option<PreparedEtbEntry>, crate::effects::ExecutionError> {
        if result.prevented {
            return Ok(Some(PreparedEtbEntry {
                result,
                choices: PreparedEtbChoices::default(),
                zone_entry_lookback: None,
                entry_definition: None,
                physical_components: Vec::new(),
                linked_face_mana_cost: None,
                entry_attachment: None,
                entry_attachment_requires_aura: false,
                entry_attachment_specified: false,
                entry_attachment_filter: None,
            }));
        }
        let prospective_source = result
            .enters_as_copy_of
            .and_then(|copy_source| self.object(copy_source))
            .or_else(|| self.object(old_id));
        // Entry choices must see the same layer-one copy values as replacement
        // matching and commit, including a source that is itself a temporary copy.
        let prospective_copiable_values = result.enters_as_copy_of
            .and_then(|source| crate::continuous::referenced_copiable_values(source, self));
        let prospective_controller = result
            .controller_override
            .or(entering_controller)
            .or_else(|| self.current_controller(old_id))
            .or_else(|| self.object(old_id).map(|object| object.owner))
            .ok_or(crate::effects::ExecutionError::InvalidTarget)?;
        // CR 110.2b/614.12a: a resolving permanent spell's default controller
        // is its caster, but the player currently controlling the spell makes
        // the permanent's own entry choices.
        let entering_default_controller = prospective_controller;
        // The proposal processor also stores the caller's default entry
        // controller here. That is not a replacement changing control and
        // must not hide a resolving spell's current controller (CR 110.2b).
        let resolving_entering_spell = result.replacement_context.as_ref()
            .and_then(|context| context.zone_change_context.as_ref())
            .is_some_and(|zone| zone.cause.source == Some(old_id));
        let prospective_controller = if (result.controller_override.is_none()
            || (result.controller_override == entering_controller && resolving_entering_spell))
            && self
                .object(old_id)
                .is_some_and(|object| object.zone == Zone::Stack)
        {
            self.current_controller(old_id)
                .unwrap_or(prospective_controller)
        } else {
            prospective_controller
        };
        let mut prospective_card_types = prospective_copiable_values
            .as_ref()
            .map(|values| values.card_types.clone().into())
            .or_else(|| prospective_source.map(|object| object.card_types.clone()))
            .unwrap_or_default();
        for card_type in &result.added_card_types {
            if !prospective_card_types.contains(card_type) {
                prospective_card_types.push(*card_type);
            }
        }
        let mut prospective_subtypes = prospective_copiable_values
            .as_ref()
            .map(|values| values.subtypes.clone().into())
            .or_else(|| prospective_source.map(|object| object.subtypes.clone()))
            .unwrap_or_default();
        if result.removes_other_card_types {
            crate::continuous::replace_card_types_and_prune_subtypes_in_game(
                &mut prospective_card_types,
                &mut prospective_subtypes,
                &result.added_card_types,
             self);
        }
        for subtype in &result.added_subtypes {
            if !prospective_subtypes.contains(subtype) {
                prospective_subtypes.push(*subtype);
            }
        }
        // CR 614.17d: an entry prohibition is checked against the permanent
        // as it would exist after the applied replacement effects, so a
        // replacement that adds a banned type can't sneak it in.
        if (!result.added_card_types.is_empty()
            || !result.added_subtypes.is_empty()
            || result.removes_other_card_types
            || result.enters_as_copy_of.is_some())
            && let Some(mut prospective) = self.object(old_id).cloned()
        {
            prospective.card_types = prospective_card_types.clone();
            prospective.subtypes = prospective_subtypes.clone();
            if self.prospective_entry_prohibited_by_cant_effect(&prospective) {
                result.prevented = true;
                result.new_destination = None;
                return Ok(Some(PreparedEtbEntry {
                    result,
                    choices: PreparedEtbChoices::default(),
                    zone_entry_lookback: None,
                    entry_definition: None,
                    physical_components: Vec::new(),
                    linked_face_mana_cost: None,
                    entry_attachment: None,
                    entry_attachment_requires_aura: false,
                    entry_attachment_specified: false,
                    entry_attachment_filter: None,
                }));
            }
        }
        if let Some(choices) = result.prepared_choices.clone() {
            return Ok(Some(PreparedEtbEntry {
                result,
                choices,
                zone_entry_lookback: None,
                entry_definition: None,
                physical_components: Vec::new(),
                linked_face_mana_cost: None,
                entry_attachment: None,
                entry_attachment_requires_aura: false,
                entry_attachment_specified: false,
                entry_attachment_filter: None,
            }));
        }
        let mut prospective_abilities = prospective_copiable_values
            .as_ref()
            .map(|values| values.abilities.iter().cloned().collect::<Vec<_>>())
            .or_else(|| prospective_source.map(|object| object.abilities_vec()))
            .unwrap_or_default();
        prospective_abilities.extend(result.added_abilities.iter().cloned());
        if result.enters_face_down { prospective_abilities.clear(); }

        let mut program_choices = if let Some((choices, abilities)) = completed_programs {
            prospective_abilities = abilities;
            choices
        } else {
            let programs = prospective_abilities
                .iter()
                .filter_map(|ability| {
                    let (program, _, face_up_only) =
                        as_enters_effect_program_from_ability(ability)?;
                    (!face_up_only).then_some(program)
                })
                .collect();
            let from = self
                .object(old_id)
                .ok_or(crate::effects::ExecutionError::ObjectNotFound(old_id))?
                .zone;
            let mut entry_event = crate::events::EnterBattlefieldEvent::new(old_id, from);
            entry_event.enters_as_copy_of = result.enters_as_copy_of;
            entry_event.enters_face_down = result.enters_face_down;
            entry_event.copy_duration = result.copy_duration.clone();
            entry_event.copy_name_override = result.copy_name_override.clone();
            entry_event.added_colors = result.added_colors;
            entry_event.added_card_types = result.added_card_types.clone();
            entry_event.removes_other_card_types = result.removes_other_card_types;
            entry_event.added_supertypes = result.added_supertypes.clone();
            entry_event.removed_supertypes = result.removed_supertypes.clone();
            entry_event.added_subtypes = result.added_subtypes.clone();
            entry_event.added_abilities = result.added_abilities.clone();
            entry_event.set_base_power_toughness = result.set_base_power_toughness;
            entry_event.controller_override = Some(entering_default_controller);
            if result.copy_duration.is_some() && result.enters_as_copy_of.is_some() {
                entry_event.program_choices.entry_copy_registration =
                    Some(self.effect_store.continuous_effects.reserve_entry_effect());
            }
            let Some(choices) = self.execute_entry_programs(
                old_id,
                prospective_controller,
                programs,
                Some(&entry_event),
                decision_maker,
            )?
            else {
                return Ok(None);
            };
            if !choices.as_enters_continuous_effects.is_empty() {
                if let Some(abilities) = self.entry_text_abilities(old_id) {
                    prospective_abilities = abilities;
                }
            }
            choices
        };
        // "put this creature into its owner's graveyard instead of onto the
        // battlefield" (Frankenstein's Monster): an entry program redirected
        // the entering object (CR 614.1c). Its completed actions stand.
        if let Some(destination) = program_choices.entry_redirect.take() {
            result.prevented = true;
            result.new_destination = Some(destination);
            return Ok(Some(PreparedEtbEntry {
                result,
                choices: program_choices,
                zone_entry_lookback: None,
                entry_definition: None,
                physical_components: Vec::new(),
                linked_face_mana_cost: None,
                entry_attachment: None,
                entry_attachment_requires_aura: false,
                entry_attachment_specified: false,
                entry_attachment_filter: None,
            }));
        }

        let battle_protector = if prospective_card_types.contains(&crate::types::CardType::Battle) {
            let legal = self.legal_battle_protectors_for(
                prospective_controller,
                prospective_subtypes.contains(&Subtype::Siege),
            );
            if legal.len() <= 1 {
                legal.first().copied()
            } else {
                let options = legal
                    .iter()
                    .enumerate()
                    .map(|(index, player)| {
                        crate::decisions::context::SelectableOption::new(
                            index,
                            self.player(*player)
                                .map(|player| player.name.clone())
                                .unwrap_or_else(|| format!("Player {}", player.0)),
                        )
                    })
                    .collect();
                let context = crate::decisions::context::SelectOptionsContext::new(
                    prospective_controller,
                    Some(old_id),
                    "Choose a player to protect this battle",
                    options,
                    1,
                    1,
                );
                let selected = decision_maker
                    .decide_options(self, &context)
                    .into_iter()
                    .find_map(|index| legal.get(index).copied());
                if decision_maker.awaiting_choice() {
                    return Ok(None);
                }
                selected.or_else(|| legal.first().copied())
            }
        } else {
            None
        };

        program_choices.battle_protector = battle_protector;
        let mut choices = program_choices;
        for ability in prospective_abilities {
            let crate::ability::AbilityKind::Static(static_ability) = &ability.kind else {
                continue;
            };
            if let Some(spec) = static_ability.color_choice_as_enters() {
                let mut options = vec![
                    crate::color::Color::White,
                    crate::color::Color::Blue,
                    crate::color::Color::Black,
                    crate::color::Color::Red,
                    crate::color::Color::Green,
                ];
                if let Some(excluded) = spec.excluded {
                    options.retain(|color| *color != excluded);
                }
                if spec.count > 1 && options.len() >= spec.count as usize {
                    // "choose two colors" (Seal of the Guildpact): that many
                    // different colors, recorded together.
                    let choice_spec =
                        crate::decisions::specs::ManaColorsSpec::restricted_different_colors(
                            old_id,
                            spec.count,
                            options.clone(),
                        )
                        .without_mana();
                    let chosen = crate::decisions::make_decision(
                        self,
                        decision_maker,
                        prospective_controller,
                        Some(old_id),
                        choice_spec,
                    );
                    if decision_maker.awaiting_choice() {
                        return Ok(None);
                    }
                    let mut set = crate::color::ColorSet::COLORLESS;
                    for color in chosen {
                        if options.contains(&color) && set.count() < spec.count {
                            set = set.with(color);
                        }
                    }
                    // A short answer is completed with the first unchosen
                    // options, keeping the choice at its required size.
                    for color in &options {
                        if set.count() >= spec.count {
                            break;
                        }
                        set = set.with(*color);
                    }
                    choices.chosen_color_set = Some(set);
                } else if !options.is_empty() {
                    let choice_spec = crate::decisions::specs::ManaColorsSpec::restricted(
                        old_id,
                        1,
                        true,
                        options.clone(),
                    )
                    .without_mana();
                    let mut chosen = crate::decisions::make_decision(
                        self,
                        decision_maker,
                        prospective_controller,
                        Some(old_id),
                        choice_spec,
                    );
                    if decision_maker.awaiting_choice() {
                        return Ok(None);
                    }
                    choices.chosen_color = chosen.pop().filter(|color| options.contains(color));
                }
            }
            if static_ability.basic_land_type_choice_as_enters().is_some() {
                // "choose two basic land types" (Illusionary Terrain) records
                // distinct types in choice order; a single choice keeps the
                // ordinary chosen-basic-land-type record.
                let choice_count = static_ability.basic_land_type_choice_count_as_enters().max(1);
                let mut options = vec![
                    crate::types::Subtype::Plains,
                    crate::types::Subtype::Island,
                    crate::types::Subtype::Swamp,
                    crate::types::Subtype::Mountain,
                    crate::types::Subtype::Forest,
                ];
                let mut sequence = Vec::new();
                for _ in 0..choice_count {
                    if options.is_empty() {
                        break;
                    }
                    let display_options = options
                        .iter()
                        .enumerate()
                        .map(|(idx, subtype)| {
                            crate::decisions::spec::DisplayOption::new(idx, subtype.to_string())
                        })
                        .collect::<Vec<_>>();
                    let choice_spec =
                        crate::decisions::specs::ChoiceSpec::single(old_id, display_options);
                    let mut chosen = crate::decisions::make_decision(
                        self,
                        decision_maker,
                        prospective_controller,
                        Some(old_id),
                        choice_spec,
                    );
                    if decision_maker.awaiting_choice() {
                        return Ok(None);
                    }
                    let Some(subtype) = chosen
                        .pop()
                        .filter(|idx| *idx < options.len())
                        .map(|idx| options.remove(idx))
                    else {
                        break;
                    };
                    sequence.push(subtype);
                }
                choices.chosen_basic_land_type = sequence.first().copied();
                if choice_count > 1 {
                    choices.chosen_basic_land_type_sequence = Some(sequence);
                }
            }
            if static_ability.land_type_choice_as_enters().is_some() {
                let options = self.subtypes_in_family(crate::types::SubtypeFamily::Land);
                let display_options = options
                    .iter()
                    .enumerate()
                    .map(|(idx, subtype)| {
                        crate::decisions::spec::DisplayOption::new(idx, subtype.to_string())
                    })
                    .collect::<Vec<_>>();
                let choice_spec =
                    crate::decisions::specs::ChoiceSpec::single(old_id, display_options);
                let mut chosen = crate::decisions::make_decision(
                    self,
                    decision_maker,
                    prospective_controller,
                    Some(old_id),
                    choice_spec,
                );
                if decision_maker.awaiting_choice() {
                    return Ok(None);
                }
                choices.chosen_land_type = chosen
                    .pop()
                    .filter(|idx| *idx < options.len())
                    .map(|idx| options[idx]);
            }
            if static_ability.creature_type_choice_as_enters().is_some() {
                let options = self.subtypes_in_family(crate::types::SubtypeFamily::Creature);
                let display_options = options
                    .iter()
                    .enumerate()
                    .map(|(idx, subtype)| {
                        crate::decisions::spec::DisplayOption::new(idx, subtype.to_string())
                    })
                    .collect::<Vec<_>>();
                let choice_spec =
                    crate::decisions::specs::ChoiceSpec::single(old_id, display_options);
                let mut chosen = crate::decisions::make_decision(
                    self,
                    decision_maker,
                    prospective_controller,
                    Some(old_id),
                    choice_spec,
                );
                if decision_maker.awaiting_choice() {
                    return Ok(None);
                }
                choices.chosen_creature_type = chosen
                    .pop()
                    .filter(|idx| *idx < options.len())
                    .map(|idx| options[idx]);
            }
            if let Some(spec) = static_ability.player_choice_as_enters() {
                let filter_ctx = self.filter_context_for(prospective_controller, Some(old_id));
                let options = self
                    .players
                    .iter()
                    .filter(|player| {
                        player.is_in_game() && spec.filter.matches_player(player.id, &filter_ctx)
                    })
                    .map(|player| player.id)
                    .collect::<Vec<_>>();
                if spec.count > 1 && options.len() >= spec.count as usize {
                    // "choose two players" (Sower of Discord): that many
                    // different players, one choice at a time.
                    let mut remaining = options.clone();
                    let mut picked = Vec::new();
                    while picked.len() < spec.count as usize && !remaining.is_empty() {
                        let display_options = remaining
                            .iter()
                            .enumerate()
                            .filter_map(|(idx, player_id)| {
                                self.player(*player_id).map(|player| {
                                    crate::decisions::spec::DisplayOption::new(
                                        idx,
                                        player.name.to_string(),
                                    )
                                })
                            })
                            .collect::<Vec<_>>();
                        let choice_spec =
                            crate::decisions::specs::ChoiceSpec::single(old_id, display_options);
                        let mut chosen = crate::decisions::make_decision(
                            self,
                            decision_maker,
                            prospective_controller,
                            Some(old_id),
                            choice_spec,
                        );
                        if decision_maker.awaiting_choice() {
                            return Ok(None);
                        }
                        let index = chosen
                            .pop()
                            .filter(|idx| *idx < remaining.len())
                            .unwrap_or(0);
                        picked.push(remaining.remove(index));
                    }
                    choices.chosen_player_set = Some(picked);
                } else if !options.is_empty() {
                    let display_options = options
                        .iter()
                        .enumerate()
                        .filter_map(|(idx, player_id)| {
                            self.player(*player_id).map(|player| {
                                crate::decisions::spec::DisplayOption::new(
                                    idx,
                                    player.name.to_string(),
                                )
                            })
                        })
                        .collect::<Vec<_>>();
                    let choice_spec =
                        crate::decisions::specs::ChoiceSpec::single(old_id, display_options);
                    let mut chosen = crate::decisions::make_decision(
                        self,
                        decision_maker,
                        prospective_controller,
                        Some(old_id),
                        choice_spec,
                    );
                    if decision_maker.awaiting_choice() {
                        return Ok(None);
                    }
                    choices.chosen_player = chosen
                        .pop()
                        .filter(|idx| *idx < options.len())
                        .map(|idx| options[idx]);
                }
            }
            if let Some(spec) = static_ability.reveal_from_hand_choice_as_enters() {
                choices.as_enters_tagged_objects.insert(
                    crate::tag::TagKey::from(crate::effects::PUBLIC_REVEALED_TAG),
                    Vec::new(),
                );
                let filter_ctx = self.filter_context_for(prospective_controller, Some(old_id));
                let hand: Vec<ObjectId> = self
                    .player(prospective_controller)
                    .map(|player| player.hand.to_vec())
                    .unwrap_or_default();
                // Only the owner knows which hidden hand cards match: peers
                // offer their placeholders too, every peer asks, and the
                // chosen cards are opened before the answer replays (see
                // `game_state::hidden_hand_choices`).
                let hidden_hand_choice =
                    self.hand_choice_depends_on_hidden_identity(&spec.filter, hand.iter().copied());
                let placeholders = if hidden_hand_choice {
                    self.hidden_hand_placeholder_candidates(
                        &spec.filter,
                        &filter_ctx,
                        hand.iter().copied(),
                    )
                } else {
                    Vec::new()
                };
                let candidates = hand
                    .into_iter()
                    .filter_map(|candidate_id| {
                        self.object(candidate_id)
                            .filter(|object| {
                                placeholders.contains(&candidate_id)
                                    || spec.filter.matches(object, &filter_ctx, self)
                            })
                            .map(|object| {
                                crate::decisions::context::SelectableObject::new(
                                    candidate_id,
                                    object.name.to_string(),
                                )
                            })
                    })
                    .collect::<Vec<_>>();
                if !candidates.is_empty() || hidden_hand_choice {
                    // A hidden choice may be answered short: the owner's real
                    // match count is unknown here.
                    let min = if spec.optional || hidden_hand_choice {
                        0
                    } else {
                        spec.count.min.min(candidates.len())
                    };
                    let max = spec
                        .count
                        .max
                        .unwrap_or(candidates.len())
                        .min(candidates.len());
                    let context = crate::decisions::context::SelectObjectsContext::new(
                        prospective_controller,
                        Some(old_id),
                        "Reveal cards from your hand",
                        candidates.clone(),
                        min,
                        Some(max),
                    );
                    let context = if hidden_hand_choice {
                        context.require_explicit_choice().with_reveal_policy(
                            crate::decisions::context::SelectionRevealPolicy::Public,
                        )
                    } else {
                        context
                    };
                    let candidate_ids = candidates
                        .iter()
                        .map(|candidate| candidate.id)
                        .collect::<Vec<_>>();
                    let selected = if !hidden_hand_choice
                        && min == candidates.len()
                        && max == candidates.len()
                    {
                        candidate_ids.clone()
                    } else {
                        decision_maker.decide_objects(self, &context)
                    };
                    if decision_maker.awaiting_choice() {
                        return Ok(None);
                    }
                    let revealed = selected
                        .into_iter()
                        .filter(|selected| candidate_ids.contains(selected))
                        .take(max)
                        .collect::<Vec<_>>();
                    if hidden_hand_choice {
                        self.record_hidden_identity_obligations(
                            &revealed,
                            &spec.filter,
                            &filter_ctx,
                            "reveal cards matching the filter",
                        );
                        self.mark_hidden_cards_publicly_revealed(&revealed);
                    }
                    if revealed.len() >= min {
                        let snapshots = revealed
                            .iter()
                            .filter_map(|id| self.object(*id))
                            .map(|object| {
                                crate::snapshot::ObjectSnapshot::from_object(object, self)
                            })
                            .collect();
                        choices.as_enters_tagged_objects.insert(
                            crate::tag::TagKey::from(crate::effects::PUBLIC_REVEALED_TAG),
                            snapshots,
                        );
                    }
                    if revealed.len() >= min && !revealed.is_empty() {
                        for viewer_idx in 0..self.players.len() {
                            let viewer = crate::ids::PlayerId::from_index(viewer_idx as u8);
                            let view_ctx = crate::decisions::context::ViewCardsContext::new(
                                viewer,
                                prospective_controller,
                                Some(old_id),
                                Zone::Hand,
                                "Reveal cards from hand",
                            )
                            .with_public(true);
                            decision_maker.view_cards(self, viewer, &revealed, &view_ctx);
                        }
                    }
                }
            }
            if let Some(spec) = static_ability.card_name_choice_as_enters() {
                if spec.reveal_opponents_hands {
                    let opponent_ids = self
                        .players
                        .iter()
                        .filter(|player| player.is_in_game() && player.id != prospective_controller)
                        .map(|player| player.id)
                        .collect::<Vec<_>>();
                    for opponent_id in opponent_ids {
                        let cards = self
                            .player(opponent_id)
                            .map(|player| player.hand.clone())
                            .unwrap_or_default();
                        for viewer_idx in 0..self.players.len() {
                            let viewer = crate::ids::PlayerId::from_index(viewer_idx as u8);
                            let mut view_ctx =
                                crate::decisions::context::ViewCardsContext::look_at_hand(
                                    viewer,
                                    opponent_id,
                                    Some(old_id),
                                );
                            view_ctx.description = "Reveal that player's hand".to_string();
                            view_ctx.public = true;
                            decision_maker.view_cards(self, viewer, &cards, &view_ctx);
                        }
                    }
                }
                let choice_ctx = crate::decisions::context::TextInputContext::new(
                    prospective_controller,
                    Some(old_id),
                    "Choose a card name",
                )
                .with_placeholder("Enter a card name")
                .require_known_value(true);
                let chosen_name = decision_maker.decide_text(self, &choice_ctx);
                if decision_maker.awaiting_choice() {
                    return Ok(None);
                }
                let chosen_name = chosen_name.trim();
                if !chosen_name.is_empty() {
                    let mut registry = CardRegistry::new();
                    registry.ensure_cards_loaded([chosen_name]);
                    let canonical_name = registry
                        .get(chosen_name)
                        .map(|definition| definition.name().to_string())
                        .unwrap_or_else(|| chosen_name.to_string());
                    let legal = !spec.require_nonland_from_revealed_opponents
                        || self
                            .players
                            .iter()
                            .filter(|player| {
                                player.is_in_game() && player.id != prospective_controller
                            })
                            .flat_map(|player| player.hand.iter().copied())
                            .filter_map(|object_id| self.object(object_id))
                            .any(|object| {
                                !object.is_land()
                                    && object.name.eq_ignore_ascii_case(&canonical_name)
                            });
                    let legal = legal
                        && !(spec.exclude_basic_land_names
                            && is_basic_land_card_name(&canonical_name));
                    if legal {
                        choices.chosen_named_option = Some(canonical_name);
                    }
                }
                // The controller chooses which opponent participates, before
                // that opponent names their card (CR 101.4, 608.2d).
                let naming_opponent = if spec.opponent_also_chooses {
                    let opponents = self.team_apnap_player_order().into_iter()
                        .filter(|player| self.are_opponents(prospective_controller, *player))
                        .collect::<Vec<_>>();
                    if opponents.len() <= 1 {
                        opponents.first().copied()
                    } else {
                        let options = opponents.iter().enumerate().map(|(index, player)| {
                            crate::decisions::context::SelectableOption::new(index,
                                self.player(*player).map(|p| p.name.clone())
                                    .unwrap_or_else(|| format!("Player {}", player.0)))
                        }).collect();
                        let context = crate::decisions::context::SelectOptionsContext::new(
                            prospective_controller, Some(old_id), "Choose an opponent to name a card",
                            options, 1, 1,
                        );
                        let selected = decision_maker.decide_options(self, &context).into_iter()
                            .find_map(|index| opponents.get(index).copied());
                        if decision_maker.awaiting_choice() { return Ok(None); }
                        selected
                    }
                } else { None };
                if let Some(opponent) = naming_opponent {
                    let choice_ctx = crate::decisions::context::TextInputContext::new(
                        opponent,
                        Some(old_id),
                        "Choose a card name",
                    )
                    .with_placeholder("Enter a card name")
                    .require_known_value(true);
                    let opponent_name = decision_maker.decide_text(self, &choice_ctx);
                    if decision_maker.awaiting_choice() {
                        return Ok(None);
                    }
                    let opponent_name = opponent_name.trim();
                    if !opponent_name.is_empty() {
                        let mut registry = CardRegistry::new();
                        registry.ensure_cards_loaded([opponent_name]);
                        let canonical = registry
                            .get(opponent_name)
                            .map(|definition| definition.name().to_string())
                            .unwrap_or_else(|| opponent_name.to_string());
                        if !(spec.exclude_basic_land_names && is_basic_land_card_name(&canonical)) {
                            choices.chosen_named_option = Some(match choices.chosen_named_option.take() {
                                Some(mine) if mine != canonical => format!("{mine}\n{canonical}"),
                                Some(mine) => mine,
                                None => canonical,
                            });
                        }
                    }
                }
            }
            if let Some(spec) = static_ability.named_option_choice_as_enters()
                && spec.at_random
                && !spec.options.is_empty()
            {
                // "As this enters, choose 2, 3, or 4 at random": no player
                // makes this choice; the game's deterministic RNG picks one
                // listed option uniformly.
                let mut indices = (0..spec.options.len()).collect::<Vec<_>>();
                self.shuffle_slice(&mut indices);
                if let Some(option) = indices.first().map(|idx| spec.options[*idx].clone()) {
                    choices.chosen_named_option = Some(option);
                }
            } else if let Some(spec) = static_ability.named_option_choice_as_enters()
                && spec.each_player
                && !spec.options.is_empty()
            {
                // "As this creature enters, each player chooses war or
                // peace": every player chooses in APNAP order (CR 101.4),
                // and each player's option is recorded on the permanent.
                let display_options = spec
                    .options
                    .iter()
                    .enumerate()
                    .map(|(idx, option)| {
                        crate::decisions::spec::DisplayOption::new(idx, option.clone())
                    })
                    .collect::<Vec<_>>();
                for player in self.team_apnap_player_order() {
                    let choice_spec = crate::decisions::specs::ChoiceSpec::single(
                        old_id,
                        display_options.clone(),
                    );
                    let mut chosen = crate::decisions::make_decision(
                        self,
                        decision_maker,
                        player,
                        Some(old_id),
                        choice_spec,
                    );
                    if decision_maker.awaiting_choice() {
                        return Ok(None);
                    }
                    if let Some(option) = chosen
                        .pop()
                        .filter(|idx| *idx < spec.options.len())
                        .map(|idx| spec.options[idx].clone())
                    {
                        choices.player_named_options.push((player, option));
                    }
                }
            } else if let Some(spec) = static_ability.named_option_choice_as_enters()
                && !spec.options.is_empty()
            {
                let display_options = spec
                    .options
                    .iter()
                    .enumerate()
                    .map(|(idx, option)| {
                        crate::decisions::spec::DisplayOption::new(idx, option.clone())
                    })
                    .collect::<Vec<_>>();
                let choice_spec =
                    crate::decisions::specs::ChoiceSpec::single(old_id, display_options);
                let mut chosen = crate::decisions::make_decision(
                    self,
                    decision_maker,
                    prospective_controller,
                    Some(old_id),
                    choice_spec,
                );
                if decision_maker.awaiting_choice() {
                    return Ok(None);
                }
                if let Some(option) = chosen
                    .pop()
                    .filter(|idx| *idx < spec.options.len())
                    .map(|idx| spec.options[idx].clone())
                {
                    choices.chosen_card_type = match option.as_str() {
                        "artifact" => Some(crate::types::CardType::Artifact),
                        "creature" => Some(crate::types::CardType::Creature),
                        "enchantment" => Some(crate::types::CardType::Enchantment),
                        "instant" => Some(crate::types::CardType::Instant),
                        "sorcery" => Some(crate::types::CardType::Sorcery),
                        "planeswalker" => Some(crate::types::CardType::Planeswalker),
                        "land" => Some(crate::types::CardType::Land),
                        _ => None,
                    };
                    if let Some((color, subtype)) = named_color_creature_type_option(self, &option) {
                        choices.chosen_color = Some(color);
                        choices.chosen_creature_type = Some(subtype);
                    } else if let Some(subtype) = named_subtype_option(self, &option) {
                        // "choose Elemental, Elf, ... or Treefolk" / "choose
                        // Island or Swamp": the option is itself the chosen
                        // type that "of the chosen type" filters read.
                        choices.chosen_creature_type = Some(subtype);
                    }
                    choices.chosen_named_option = Some(option);
                }
            }
            if static_ability.life_total_note_as_enters().is_some() {
                choices.noted_life_total = self
                    .player(prospective_controller)
                    .map(|player| player.life);
            }
            if static_ability.id() == crate::static_abilities::StaticAbilityId::DiscardHandAsEnters
            {
                choices.discard_hand = true;
            }
            if let Some(spec) = static_ability.power_toughness_choice_as_enters_or_turns_face_up()
                && spec.at_random
                && !spec.options.is_empty()
            {
                // "As this creature enters, flip a coin. If the coin comes up
                // heads, ..." (Molten Sentry): the deterministic game RNG
                // picks one listed characteristic option uniformly.
                let mut indices = (0..spec.options.len()).collect::<Vec<_>>();
                self.shuffle_slice(&mut indices);
                if let Some(option) = indices.first().map(|idx| spec.options[*idx].clone()) {
                    choices.power_toughness_choices.push(option);
                }
            } else if let Some(spec) = static_ability.power_toughness_choice_as_enters_or_turns_face_up()
                && !spec.options.is_empty()
            {
                let display_options = spec
                    .options
                    .iter()
                    .enumerate()
                    .map(|(idx, option)| {
                        crate::decisions::spec::DisplayOption::new(
                            idx,
                            format!("{}/{}", option.power, option.toughness),
                        )
                    })
                    .collect::<Vec<_>>();
                let choice_spec =
                    crate::decisions::specs::ChoiceSpec::single(old_id, display_options);
                let mut chosen = crate::decisions::make_decision(
                    self,
                    decision_maker,
                    prospective_controller,
                    Some(old_id),
                    choice_spec,
                );
                if decision_maker.awaiting_choice() {
                    return Ok(None);
                }
                if let Some(option) = chosen
                    .pop()
                    .filter(|idx| *idx < spec.options.len())
                    .map(|idx| spec.options[idx].clone())
                {
                    choices.power_toughness_choices.push(option);
                }
            }
        }

        result.prepared_choices = Some(choices.clone());
        Ok(Some(PreparedEtbEntry {
            result,
            choices,
            zone_entry_lookback: None,
            entry_definition: None,
            physical_components: Vec::new(),
            linked_face_mana_cost: None,
            entry_attachment: None,
            entry_attachment_requires_aura: false,
            entry_attachment_specified: false,
            entry_attachment_filter: None,
        }))
    }

    /// Commit an ETB proposal whose replacement choices were already resolved.
    ///
    /// Batch-entry callers use this after every entrant's immutable proposal has
    /// been collected, so no entrant can make another entrant's replacement
    /// effects visible before the simultaneous event is committed.
    pub(crate) fn commit_prepared_etb_with_controller_and_dm(
        &mut self,
        old_id: ObjectId,
        prepared_entry: PreparedEtbEntry,
        entering_controller: Option<PlayerId>,
        decision_maker: &mut dyn crate::decision::DecisionMaker,
    ) -> Result<super::EntryCommitResult, crate::effects::ExecutionError> {
        self.move_object_with_etb_processing_with_dm_and_cause_internal(
            old_id,
            Zone::Battlefield,
            crate::events::cause::EventCause::effect(),
            decision_maker,
            true,
            Vec::new(),
            entering_controller,
            false,
            Some(prepared_entry),
            None,
        )
    }

    pub(crate) fn commit_prepared_etb_with_cause_and_options_and_dm(
        &mut self,
        old_id: ObjectId,
        prepared_entry: PreparedEtbEntry,
        entering_controller: Option<PlayerId>,
        cause: crate::events::cause::EventCause,
        choose_aura_attachment: bool,
        decision_maker: &mut dyn crate::decision::DecisionMaker,
    ) -> Result<super::EntryCommitResult, crate::effects::ExecutionError> {
        self.move_object_with_etb_processing_with_dm_and_cause_internal(
            old_id,
            Zone::Battlefield,
            cause,
            decision_maker,
            choose_aura_attachment,
            Vec::new(),
            entering_controller,
            false,
            Some(prepared_entry),
            None,
        )
    }

    /// Commit a prepared entry whose attachment the effect fixes ("onto the
    /// battlefield attached to X"). The caller attaches it; an Aura must not
    /// choose something else to enchant (CR 303.4f).
    pub(crate) fn commit_prepared_etb_with_fixed_attachment_and_dm(
        &mut self,
        old_id: ObjectId,
        prepared_entry: PreparedEtbEntry,
        entering_controller: Option<PlayerId>,
        decision_maker: &mut dyn crate::decision::DecisionMaker,
    ) -> Result<super::EntryCommitResult, crate::effects::ExecutionError> {
        self.move_object_with_etb_processing_with_dm_and_cause_internal(
            old_id,
            Zone::Battlefield,
            crate::events::cause::EventCause::effect(),
            decision_maker,
            false,
            Vec::new(),
            entering_controller,
            false,
            Some(prepared_entry),
            None,
        )
    }

    /// Commit a prevalidated exchange entrant with a fixed attachment target.
    /// Its caller stages the entire exchange and supplies the attachment; do
    /// not choose a different target or recheck entry prohibitions after the
    /// other member of the simultaneous exchange has already departed.
    pub(crate) fn commit_prepared_exchange_etb_with_dm(
        &mut self,
        old_id: ObjectId,
        prepared_entry: PreparedEtbEntry,
        entering_controller: PlayerId,
        cause: crate::events::cause::EventCause,
        decision_maker: &mut dyn crate::decision::DecisionMaker,
    ) -> Result<super::EntryCommitResult, crate::effects::ExecutionError> {
        self.move_object_with_etb_processing_with_dm_and_cause_body(
            old_id,
            Zone::Battlefield,
            cause,
            decision_maker,
            false,
            Vec::new(),
            Some(entering_controller),
            false,
            Some(prepared_entry),
            true,
            None,
        )
    }

    fn move_object_with_etb_processing_with_dm_and_cause_internal(
        &mut self,
        old_id: ObjectId,
        new_zone: Zone,
        cause: crate::events::cause::EventCause,
        decision_maker: &mut dyn crate::decision::DecisionMaker,
        choose_aura_attachment: bool,
        initial_enters_with_counters: Vec<(crate::object::CounterType, u32)>,
        entering_controller: Option<PlayerId>,
        initial_enters_tapped: bool,
        prepared_entry: Option<PreparedEtbEntry>,
        authored_entry_definition: Option<crate::cards::CardDefinition>,
    ) -> Result<super::EntryCommitResult, crate::effects::ExecutionError> {
        if new_zone == Zone::Battlefield && self.card_cannot_enter_battlefield(old_id) {
            let mut published_outputs = Vec::new();
            let programs = prepared_entry
                .map(|mut entry| {
                    crate::effects::PublishedEffectOutputs::append_distinct(
                        &mut published_outputs,
                        entry.result.completed_program_outputs.iter().cloned(),
                    );
                    crate::effects::PublishedEffectOutputs::append_distinct(
                        &mut published_outputs,
                        entry.choices.as_enters_outputs.iter().cloned(),
                    );
                    std::mem::take(&mut entry.result.additional_programs)
                })
                .unwrap_or_default();
            return Ok(super::EntryCommitResult {
                original: crate::events::processing::EventOutcome::NotApplicable,
                programs,
                pending: false,
                published_outputs,
            });
        }
        if new_zone == Zone::Battlefield {
            let mut working = self.clone();
            let outcome = working.move_object_with_etb_processing_with_dm_and_cause_body(
                old_id,
                new_zone,
                cause,
                decision_maker,
                choose_aura_attachment,
                initial_enters_with_counters,
                entering_controller,
                initial_enters_tapped,
                prepared_entry,
                false,
                authored_entry_definition,
            );
            if outcome.is_err() {
                return outcome;
            }
            if decision_maker.awaiting_choice() {
                return Ok(super::EntryCommitResult::pending());
            }
            // Validate the completed entry before publishing it. Query
            // preparation performs no day/night, ascend or other game rules
            // procedures while this operation's working state is isolated.
            working = working
                .continuous_query_snapshot()
                .map_err(crate::effects::ExecutionError::ContinuousDiscovery)?;
            *self = working;
            return outcome;
        }

        self.move_object_with_etb_processing_with_dm_and_cause_body(
            old_id,
            new_zone,
            cause,
            decision_maker,
            choose_aura_attachment,
            initial_enters_with_counters,
            entering_controller,
            initial_enters_tapped,
            prepared_entry,
            false,
            authored_entry_definition,
        )
    }

    fn move_object_with_etb_processing_with_dm_and_cause_body(
        &mut self,
        old_id: ObjectId,
        new_zone: Zone,
        cause: crate::events::cause::EventCause,
        decision_maker: &mut dyn crate::decision::DecisionMaker,
        choose_aura_attachment: bool,
        initial_enters_with_counters: Vec<(crate::object::CounterType, u32)>,
        entering_controller: Option<PlayerId>,
        initial_enters_tapped: bool,
        prepared_entry: Option<PreparedEtbEntry>,
        entry_prevalidated: bool,
        authored_entry_definition: Option<crate::cards::CardDefinition>,
    ) -> Result<super::EntryCommitResult, crate::effects::ExecutionError> {
        use crate::events::processing::EventOutcome;
        let checkpoint = self.clone();
        let mut programs = Vec::new();
        let mut published_outputs = Vec::new();
        let mut original_verdict = EventOutcome::NotApplicable;
        let result = self.move_object_with_etb_processing_with_dm_and_cause_body_inner(
            old_id,
            new_zone,
            cause,
            decision_maker,
            choose_aura_attachment,
            initial_enters_with_counters,
            entering_controller,
            initial_enters_tapped,
            prepared_entry,
            entry_prevalidated,
            &mut programs,
            &mut original_verdict,
            &mut published_outputs,
            authored_entry_definition,
        );
        if result.is_err() || decision_maker.awaiting_choice() {
            *self = checkpoint;
        }
        let entered = result?;
        if decision_maker.awaiting_choice() {
            return Ok(super::EntryCommitResult::pending());
        }
        let original = match entered {
            Some(entered) => EventOutcome::Proceed(entered),
            None => match original_verdict {
                EventOutcome::Replaced => EventOutcome::Replaced,
                EventOutcome::NotApplicable => EventOutcome::NotApplicable,
                EventOutcome::Prevented | EventOutcome::Proceed(()) => EventOutcome::Prevented,
            },
        };
        Ok(super::EntryCommitResult {
            original,
            programs,
            pending: false,
            published_outputs,
        })
    }

    fn move_object_with_etb_processing_with_dm_and_cause_body_inner(
        &mut self,
        old_id: ObjectId,
        new_zone: Zone,
        cause: crate::events::cause::EventCause,
        decision_maker: &mut dyn crate::decision::DecisionMaker,
        choose_aura_attachment: bool,
        initial_enters_with_counters: Vec<(crate::object::CounterType, u32)>,
        entering_controller: Option<PlayerId>,
        initial_enters_tapped: bool,
        mut prepared_entry: Option<PreparedEtbEntry>,
        entry_prevalidated: bool,
        programs: &mut Vec<crate::events::processing::PreparedReplacementProgram>,
        original_verdict: &mut crate::events::processing::EventOutcome<()>,
        published_outputs: &mut Vec<crate::effects::PublishedEffectOutputs>,
        authored_entry_definition: Option<crate::cards::CardDefinition>,
    ) -> Result<Option<EntersResult>, crate::effects::ExecutionError> {
        use crate::events::processing::EventOutcome;
        if let Some(entry) = &mut prepared_entry {
            crate::effects::PublishedEffectOutputs::append_distinct(
                published_outputs,
                entry.result.completed_program_outputs.iter().cloned(),
            );
            crate::effects::PublishedEffectOutputs::append_distinct(
                published_outputs,
                entry.choices.as_enters_outputs.iter().cloned(),
            );
            programs.append(&mut entry.result.additional_programs);
            *original_verdict = if entry.result.replaced {
                EventOutcome::Replaced
            } else {
                EventOutcome::Prevented
            };
        }
        // Preparation may have completed an Instead program which moved the
        // original source. There is no source event left to validate or commit.
        if prepared_entry
            .as_ref()
            .is_some_and(|entry| entry.result.prevented && entry.result.new_destination.is_none())
        {
            return Ok(None);
        }
        let old_zone = self
            .object(old_id)
            .ok_or(crate::effects::ExecutionError::ObjectNotFound(old_id))?
            .zone;

        if old_zone == new_zone && !matches!(new_zone, Zone::Exile | Zone::Command) {
            return Ok(None);
        }
        *original_verdict = EventOutcome::Prevented;
        // Only process ETB replacement for moves TO the battlefield
        if new_zone != Zone::Battlefield {
            let Some(new_id) = self.move_object(old_id, new_zone, cause.clone()) else {
                return Ok(None);
            };
            return Ok(Some(EntersResult {
                new_id,
                enters_tapped: false,
                entry_attachment: None,
            }));
        }

        // Process through ETB replacement effects
        let prepared_entry = if let Some(prepared_entry) = prepared_entry {
            prepared_entry
        } else {
            let mut result = crate::events::processing::process_etb_with_event_and_dm_with_initial_counters_and_controller(
                self,
                old_id,
                old_zone,
                decision_maker,
                initial_enters_with_counters,
                entering_controller,
                initial_enters_tapped,
                cause.clone(),
            )?;
            crate::effects::PublishedEffectOutputs::append_distinct(
                published_outputs,
                result.completed_program_outputs.iter().cloned(),
            );
            programs.append(&mut result.additional_programs);
            if result.replaced {
                *original_verdict = EventOutcome::Replaced;
            }
            match self.prepare_etb_entry_with_controller_and_dm(
                old_id,
                result,
                entering_controller,
                decision_maker,
            )? {
                Some(prepared) => prepared,
                None => return Ok(None),
            }
        };
        let mut prepared_entry = prepared_entry;
        if let Some(definition) = authored_entry_definition {
            // Keep the face selected by the authoring action through the
            // physical zone move; ordinary returns still use the default face.
            prepared_entry.entry_definition = Some(definition);
        }
        let PreparedEtbEntry {
            result,
            choices,
            zone_entry_lookback,
            entry_definition,
            physical_components,
            linked_face_mana_cost,
            entry_attachment,
            entry_attachment_requires_aura,
            entry_attachment_specified,
            entry_attachment_filter,
        } = prepared_entry;
        crate::effects::PublishedEffectOutputs::append_distinct(
            published_outputs,
            result.completed_program_outputs.iter().cloned(),
        );
        crate::effects::PublishedEffectOutputs::append_distinct(
            published_outputs,
            choices.as_enters_outputs.iter().cloned(),
        );
        // A completed Instead payload leaves no entry proposal to commit.
        // Its legitimate movement can invalidate old source IDs without being
        // an execution error; validation remains mandatory for actual commits.
        if result.prevented && result.new_destination.is_none() {
            return Ok(None);
        }
        for component in &physical_components {
            if !self
                .object(component.snapshot.object_id)
                .is_some_and(|object| {
                    object.zone == component.snapshot.zone
                        && object.stable_id == component.snapshot.stable_id
                })
            {
                return Err(crate::effects::ExecutionError::InternalError(
                    "composite entry source changed before commit".into(),
                ));
            }
        }
        let original_zone_snapshot = result
            .replacement_context
            .as_ref()
            .and_then(|context| context.zone_change_context.as_ref())
            .and_then(|zone| zone.snapshot.clone());

        // If ETB was prevented or redirected to a different zone
        if result.prevented {
            if let Some(dest) = result.new_destination {
                // Move to the alternate destination
                let Some(new_id) = self.move_prepared_zone_entry_with_lookback(
                    old_id,
                    dest,
                    cause.clone(),
                    original_zone_snapshot.clone(),
                    zone_entry_lookback.as_deref(),
                    entry_prevalidated,
                    entry_definition.as_ref(),
                    &physical_components,
                    linked_face_mana_cost.as_ref(),
                    false,
                ) else {
                    return Ok(None);
                };
                return Ok(Some(EntersResult {
                    new_id,
                    enters_tapped: false,
                    entry_attachment: None,
                }));
            }
            return Ok(None);
        }

        // CR 303.4f: an Aura put onto the battlefield by an effect chooses
        // what to enchant even if it was on the stack; a resolving Aura spell
        // supplies its target as the entry attachment instead.
        let prospective_aura_entry = choose_aura_attachment
            && (self
                .object(old_id)
                .is_some_and(|object| object.subtypes.contains(&Subtype::Aura))
                || result.enters_as_copy_of.is_some_and(|copy_id| {
                    self.object(copy_id)
                        .is_some_and(|object| object.subtypes.contains(&Subtype::Aura))
                })
                || result.added_subtypes.contains(&Subtype::Aura));
        // CR 303.4g is not a second zone change. If attachment proves
        // impossible, restore this exact pre-entry state.
        let mut aura_entry_checkpoint =
            (prospective_aura_entry || entry_attachment_specified).then(|| self.clone());

        if choices.discard_hand {
            let controller = result
                .controller_override
                .or(entering_controller)
                .or_else(|| self.current_controller(old_id))
                .or_else(|| self.object(old_id).map(|object| object.owner))
                .ok_or(crate::effects::ExecutionError::ObjectNotFound(old_id))?;
            let hand = self
                .player(controller)
                .map(|player| player.hand.clone())
                .unwrap_or_default();
            // Hidden-information matches: the owner reveals the hand publicly
            // before any card moves, so every peer applies Madness (CR
            // 702.35a) and discard triggers to the same identities, as the
            // discard-hand effect does (see `hidden_hand_choices`). This body
            // runs on a working copy that is dropped while a decision is
            // awaited (the Madness choice below already relies on that), so
            // pausing here and re-running with the owner's answer is safe.
            // Never prompts outside hidden-information matches.
            let to_reveal: Vec<ObjectId> =
                hand.iter().copied().filter(|id| *id != old_id).collect();
            if to_reveal
                .iter()
                .any(|id| self.hidden_identity_is_private(*id))
                && self
                    .reveal_private_hidden_cards_publicly(
                        &mut *decision_maker,
                        controller,
                        old_id,
                        &to_reveal,
                        "Reveal the cards you discard",
                        false,
                    )
                    .is_none()
            {
                return Ok(None);
            }
            let cards = hand.into_iter().filter(|id| *id != old_id).collect();
            let provenance = self
                .provenance_graph_mut()
                .alloc_root_event(crate::events::EventKind::Discard);
            let snapshot = self.object(old_id).map(|object| {
                crate::snapshot::ObjectSnapshot::from_object_with_calculated_characteristics(
                    object, self,
                )
            });
            let mut ctx = crate::effects::ExecutionContext::new(old_id, controller, decision_maker)
                .with_cause(cause.clone())
                .with_provenance(provenance);
            ctx.source_snapshot = snapshot;
            if let Some(context) = &result.replacement_context {
                context.apply_to(&mut ctx);
                ctx.provenance = provenance;
            }
            let mut outcome =
                crate::effects::cards::discard_hand_cards(self, &mut ctx, controller, cards)?;
            if ctx.decision_maker.awaiting_choice() {
                return Ok(None);
            }
            crate::effects::retain_unmatched_outcome_events(self, &mut outcome.events);
            for event in outcome.events {
                self.queue_trigger_event(event.provenance(), event);
            }
        }

        // Preserve a simultaneous exchange's entry-legality result through
        // the final zone mutation, not just the outer ETB preparation layer.
        let Some(new_id) = self.move_prepared_zone_entry_with_lookback(
            old_id,
            Zone::Battlefield,
            cause.clone(),
            original_zone_snapshot,
            zone_entry_lookback.as_deref(),
            entry_prevalidated,
            entry_definition.as_ref(),
            &physical_components,
            linked_face_mana_cost.as_ref(),
            result.enters_face_down,
        ) else {
            return Ok(None);
        };
        if let Some(object) = self.object_mut(new_id) {
            merge_retained_tagged_objects(
                &mut object.cast_tagged_objects,
                &choices.as_enters_tagged_objects,
            );
        }
        self.effect_store.continuous_effects.retarget_entry_effects(
            &choices.as_enters_continuous_effects,
            old_id,
            new_id,
        );
        // As-enters effect programs execute against the pre-move object id;
        // migrate any choices they recorded to the battlefield id.
        if new_id != old_id {
            let choice_store = self.choice_store_mut();
            if let Some(memory) = choice_store.chosen_color_acquisitions.remove(&old_id) {
                choice_store.chosen_color_acquisitions.insert(new_id, memory);
            }
            if let Some(color) = choice_store.chosen_colors.remove(&old_id) {
                choice_store.chosen_colors.insert(new_id, color);
            }
            if let Some(colors) = choice_store.chosen_color_sets.remove(&old_id) {
                choice_store.chosen_color_sets.insert(new_id, colors);
            }
            if let Some(land_type) = choice_store.chosen_land_types.remove(&old_id) {
                choice_store.chosen_land_types.insert(new_id, land_type);
            }
            if let Some(land_types) = choice_store.chosen_basic_land_type_sequences.remove(&old_id) {
                choice_store
                    .chosen_basic_land_type_sequences
                    .insert(new_id, land_types);
            }
            if let Some(creature_type) = choice_store.chosen_creature_types.remove(&old_id) {
                choice_store
                    .chosen_creature_types
                    .insert(new_id, creature_type);
            }
            if let Some(creature_types) = choice_store.chosen_creature_type_sets.remove(&old_id) {
                choice_store
                    .chosen_creature_type_sets
                    .insert(new_id, creature_types);
            }
            if let Some(card_type) = choice_store.chosen_card_types.remove(&old_id) {
                choice_store.chosen_card_types.insert(new_id, card_type);
            }
            if let Some(player) = choice_store.chosen_players.remove(&old_id) {
                choice_store.chosen_players.insert(new_id, player);
            }
            // "As this creature enters, secretly choose an opponent."
            if let Some(secret) = choice_store.secret_chosen_players.remove(&old_id) {
                choice_store.secret_chosen_players.insert(new_id, secret);
            }
            if let Some(players) = choice_store.chosen_player_sets.remove(&old_id) {
                choice_store.chosen_player_sets.insert(new_id, players);
            }
            if let Some(object) = choice_store.chosen_objects.remove(&old_id) {
                choice_store.chosen_objects.insert(new_id, object);
            }
            if let Some(names) = choice_store.chosen_named_options.remove(&old_id) {
                choice_store.chosen_named_options.insert(new_id, names);
            }
            if let Some(choices) = choice_store.chosen_player_named_options.remove(&old_id) {
                choice_store
                    .chosen_player_named_options
                    .insert(new_id, choices);
            }
            let numeric = choice_store
                .numeric_acquisitions
                .iter()
                .filter(|(owner, _)| owner.host == old_id)
                .map(|(owner, number)| (owner.clone(), *number))
                .collect::<Vec<_>>();
            choice_store
                .numeric_acquisitions
                .retain(|owner, _| owner.host != old_id);
            for (mut owner, number) in numeric {
                owner.host = new_id;
                choice_store.numeric_acquisitions.insert(owner, number);
            }
            // Devour runs as the permanent enters (CR 702.82a) and records the
            // devoured count on the pre-move id.
            let devoured = self.devoured_count(old_id);
            if devoured > 0 {
                self.set_devoured_count(old_id, 0);
                self.set_devoured_count(new_id, devoured);
            }
            let devoured_objects = self.devoured_objects(old_id).to_vec();
            if !devoured_objects.is_empty() {
                self.set_devoured_objects(old_id, Vec::new());
                self.set_devoured_objects(new_id, devoured_objects);
            }
        }
        if choices.transfer_as_enters_source_links {
            self.transfer_entry_linked_exile_pairs(&choices.as_enters_linked_exile, new_id);
            self.transfer_exiled_with_source_links(old_id, new_id);
            let imprinted_cards = self.get_imprinted_cards(old_id).to_vec();
            self.clear_imprinted_cards(old_id);
            for imprinted_card in imprinted_cards {
                self.imprint_card(new_id, imprinted_card);
            }
        }
        if let Some(controller) = result.controller_override {
            self.stage_initial_controller_for_assembly(new_id, controller);
        }

        // Apply "enters as copy" before tapped/counter modifications. Ordinary
        // enter-as-copy effects replace the object's copiable values. A copy
        // with an explicit duration instead becomes a locked layer-1 effect,
        // preserving the underlying permanent so it can revert when it expires.
        let temporary_copy_duration = result.copy_duration.clone();
        // These entry modifications overwrite the permanent's own copiable
        // fields. They belong to this permanent only, so remember the printed
        // values and restore them when it leaves the battlefield (CR 707.2,
        // 400.7): a Clone that copied Grave Titan is just Clone again in its
        // new zone.
        if temporary_copy_duration.is_none()
            && (result.enters_as_copy_of.is_some()
                || !result.added_colors.is_empty()
                || !result.added_card_types.is_empty()
                || !result.added_supertypes.is_empty()
                || !result.removed_supertypes.is_empty()
                || !result.added_subtypes.is_empty()
                || !result.added_abilities.is_empty()
                || result.set_base_power_toughness.is_some()
                || !choices.power_toughness_choices.is_empty())
            && let Some(new_obj) = self.object_mut(new_id)
        {
            new_obj.capture_enters_as_copy_restore_state();
        }
        let retained_colors = result.copy_followups
            .contains(&ironsmith_core::EnterAsCopyFollowup::RetainOwnColors)
            .then(|| self.object(new_id).map(|object| object.colors()))
            .flatten();
        if let Some(copy_source_id) = result.enters_as_copy_of {
            if let Some(duration) = temporary_copy_duration.clone() {
                let copiable_values = crate::continuous::referenced_copiable_values(copy_source_id, self);
                if let Some(mut copiable_values) = copiable_values {
                    crate::static_abilities::exclude_cdas_from_copy(
                        &mut copiable_values.abilities, &mut copiable_values.ability_labels,
                        false, retained_colors.is_some(), result.removes_other_card_types,
                    );
                    if let Some(colors) = retained_colors {
                        copiable_values.colors = colors;
                    }
                    let controller = self
                        .current_controller(new_id)
                        .ok_or(crate::effects::ExecutionError::ObjectNotFound(new_id))?;
                    if let Some(name) = &result.copy_name_override {
                        copiable_values.name = name.clone();
                    }
                    copiable_values.colors = copiable_values.colors.union(result.added_colors);
                    for card_type in &result.added_card_types {
                        if !copiable_values.card_types.contains(card_type) {
                            copiable_values.card_types.push(*card_type);
                        }
                    }
                    if result.removes_other_card_types {
                        // Copy snapshots own vectors; use the same type/family
                        // operation as prospective and ordinary entry worlds.
                        let mut types = std::mem::take(&mut copiable_values.card_types).into();
                        let mut subtypes = std::mem::take(&mut copiable_values.subtypes).into();
                        crate::continuous::replace_card_types_and_prune_subtypes_in_game(
                            &mut types,
                            &mut subtypes,
                            &result.added_card_types,
                         self);
                        copiable_values.card_types = types.to_vec();
                        copiable_values.subtypes = subtypes.to_vec();
                    }
                    copiable_values
                        .supertypes
                        .retain(|supertype| !result.removed_supertypes.contains(supertype));
                    for supertype in &result.added_supertypes {
                        if !copiable_values.supertypes.contains(supertype) {
                            copiable_values.supertypes.push(*supertype);
                        }
                    }
                    for subtype in &result.added_subtypes {
                        if !copiable_values.subtypes.contains(subtype) {
                            copiable_values.subtypes.push(*subtype);
                        }
                    }
                    if result.set_base_power_toughness.is_some() {
                        crate::static_abilities::exclude_pt_cdas_from_copy(
                            &mut copiable_values.abilities,
                            &mut copiable_values.ability_labels,
                        );
                    }
                    for ability in &result.added_abilities {
                        crate::static_abilities::add_copy_exception_ability(
                            &mut copiable_values.abilities,
                            &mut copiable_values.ability_labels,
                            &mut copiable_values.compiled_card_text,
                            ability.clone(),
                            None,
                        );
                    }
                    if let Some((power, toughness)) = result.set_base_power_toughness {
                        copiable_values.power = Some(power);
                        copiable_values.toughness = Some(toughness);
                    }

                    let modification = crate::continuous::Modification::CopyOf {
retain_original_types: false, retain_original_name: false,
                        target_id: copy_source_id,
                        copiable_values: Box::new(copiable_values),
                        preserve_source_abilities: false,
                        name_override: None,
                        name_override_surface: None,
                        add_supertypes: Vec::new(),
                    };
                    let expires_end_of_turn = matches!(
                        &duration,
                        crate::effect::Until::EndOfTurn
                            | crate::effect::Until::YourNextTurn
                            | crate::effect::Until::YourNextUpkeep
                            | crate::effect::Until::ControllersNextUntapStep
                    )
                    .then_some(self.turn.turn_number)
                    .unwrap_or(u32::MAX);
                    let effect = crate::continuous::ContinuousEffect::new(
                        new_id,
                        controller,
                        crate::continuous::EffectTarget::Specific(new_id),
                        modification,
                    )
                    .until(duration)
                    .with_expires_end_of_turn(expires_end_of_turn)
                    .with_source_type(
                        crate::continuous::EffectSourceType::Resolution {
                            locked_targets: vec![new_id],
                        },
                    );
                    // Stage the copy with the remaining entry fields. Its
                    // counters and prepared choices are not assembled yet.
                    let registration = choices.entry_copy_registration.ok_or_else(|| {
                        crate::effects::ExecutionError::IncompleteEvidence(
                            "temporary entry copy omitted its prospective acquisition".into(),
                        )
                    })?;
                    self.effect_store
                        .continuous_effects
                        .add_reserved_entry_effect(registration, effect)?;
                }
            } else {
                // CR 707.9b: "it doesn't copy that creature's color" keeps the
                // entering object's own colors as its copiable color.
                let copiable_values = crate::continuous::referenced_copiable_values(copy_source_id, self);
                if let (Some(values), Some(new_obj)) = (copiable_values.as_ref(), self.object_mut(new_id)) {
                    new_obj.copy_copiable_values_from_values(values);
                    if result.set_base_power_toughness.is_some() {
                        crate::static_abilities::exclude_pt_cdas_from_copy(
                            &mut new_obj.abilities,
                            &mut new_obj.ability_labels,
                        );
                    }
                    crate::static_abilities::exclude_cdas_from_copy(
                        &mut new_obj.abilities, &mut new_obj.ability_labels,
                        false, retained_colors.is_some(), result.removes_other_card_types,
                    );
                    if let Some(colors) = retained_colors {
                        new_obj.color_override = Some(colors);
                    }
                    if let Some(name) = &result.copy_name_override {
                        new_obj.name = name.clone().into();
                    }
                }
            }
        }
        if temporary_copy_duration.is_none() {
            if !result.added_colors.is_empty()
                && let Some(new_obj) = self.object_mut(new_id)
            {
                new_obj.color_override = Some(new_obj.colors().union(result.added_colors));
            }
            let admitted_families=self.custom_subtypes.clone();
            if (!result.added_card_types.is_empty() || result.removes_other_card_types)
                && let Some(new_obj) = self.object_mut(new_id)
            {
                for card_type in &result.added_card_types {
                    if !new_obj.card_types.contains(card_type) {
                        new_obj.card_types.push(*card_type);
                    }
                }
                if result.removes_other_card_types {
                    for subtype in new_obj.subtypes.iter_mut() {
                        if let crate::types::Subtype::Custom(incoming)=*subtype {
                            if let Some(crate::types::Subtype::Custom(known))=admitted_families.iter().find(|known|**known==*subtype) {*subtype=crate::types::Subtype::Custom(incoming.union_associations(*known));}
                        }
                    }
                    crate::continuous::replace_card_types_and_prune_subtypes(
                        &mut new_obj.card_types,
                        &mut new_obj.subtypes,
                        &result.added_card_types,
                    );
                }
            }
            if !result.added_supertypes.is_empty()
                && let Some(new_obj) = self.object_mut(new_id)
            {
                for supertype in &result.added_supertypes {
                    if !new_obj.supertypes.contains(supertype) {
                        new_obj.supertypes.push(*supertype);
                    }
                }
            }
            if !result.removed_supertypes.is_empty()
                && let Some(new_obj) = self.object_mut(new_id)
            {
                new_obj
                    .supertypes
                    .retain(|supertype| !result.removed_supertypes.contains(supertype));
            }
            if !result.added_subtypes.is_empty()
                && let Some(new_obj) = self.object_mut(new_id)
            {
                for subtype in &result.added_subtypes {
                    if !new_obj.subtypes.contains(subtype) {
                        new_obj.subtypes.push(*subtype);
                    }
                }
            }
            if result.enters_as_copy_of.is_some() {
                // CR 707.9b: "enters as a copy ... except it has X" — the
                // granted ability is part of the copy's rules text too.
                if let Some(new_obj) = self.object_mut(new_id) {
                    let mut text = new_obj.compiled_card_text.to_string();
                    for ability in &result.added_abilities {
                        crate::static_abilities::add_copy_exception_ability(
                            &mut new_obj.abilities,
                            &mut new_obj.ability_labels,
                            &mut text,
                            ability.clone(),
                            None,
                        );
                    }
                    new_obj.compiled_card_text = text.into();
                }
            } else {
                for ability in &result.added_abilities {
                    self.install_authored_object_ability(
                        new_id,
                        ability.clone(),
                        AuthoredAbilityDuplicatePolicy::PreserveAll,
                    );
                }
            }
            if let Some((power, toughness)) = result.set_base_power_toughness
                && let Some(new_obj) = self.object_mut(new_id)
            {
                new_obj.base_power = Some(crate::card::PtValue::Fixed(power));
                new_obj.base_toughness = Some(crate::card::PtValue::Fixed(toughness));
            }
        }

        // Publish the choices collected against the prospective permanent only
        // after the destination object exists. No decision is made in this
        // section, so neither synchronous nor suspended callers can observe a
        // battlefield permanent whose mandatory entry choice is unresolved.
        if let Some(color) = choices.chosen_color {
            self.set_chosen_color(new_id, color);
        }
        if let Some(colors) = choices.chosen_color_set {
            self.set_chosen_colors(new_id, colors);
        }
        if let Some(subtype) = choices.chosen_basic_land_type {
            self.set_chosen_basic_land_type(new_id, subtype);
        }
        if let Some(subtypes) = choices.chosen_basic_land_type_sequence.clone() {
            self.set_chosen_basic_land_type_sequence(new_id, subtypes);
        }
        if let Some(subtype) = choices.chosen_land_type {
            self.set_chosen_land_type(new_id, subtype);
        }
        if let Some(subtype) = choices.chosen_creature_type {
            self.set_chosen_creature_type(new_id, subtype);
        }
        if let Some(card_type) = choices.chosen_card_type {
            self.set_chosen_card_type(new_id, card_type);
        }
        if let Some(player) = choices.chosen_player {
            self.set_chosen_player(new_id, player);
        }
        if let Some(players) = choices.chosen_player_set.clone() {
            self.set_chosen_players(new_id, players);
        }
        if let Some(option) = choices.chosen_named_option.clone() {
            self.set_chosen_named_option(new_id, option);
        }
        if !choices.player_named_options.is_empty() {
            self.set_player_named_option_choices(new_id, choices.player_named_options.clone());
        }
        if let Some(life_total) = choices.noted_life_total {
            self.set_noted_life_total_for_source(new_id, life_total);
        }
        if result.copy_followups.contains(&ironsmith_core::EnterAsCopyFollowup::RetainEmbalmCharacteristics)
            && let Some(object) = self.object_mut(new_id)
        {
            object.apply_embalm_copy_exception();
        }
        for option in &choices.power_toughness_choices {
            if let Some(object) = self.object_mut(new_id) {
                object.base_power = Some(crate::card::PtValue::Fixed(option.power));
                object.base_toughness = Some(crate::card::PtValue::Fixed(option.toughness));
                if let Some(types) = &option.card_types { object.card_types = types.clone().into(); }
                for subtype in &option.added_subtypes { if !object.subtypes.contains(subtype) { object.subtypes.push(*subtype); } }
                for granted in &option.abilities {
                    let ability = crate::ability::Ability::static_ability(granted.clone());
                    self.install_authored_object_ability(
                        new_id,
                        ability,
                        AuthoredAbilityDuplicatePolicy::PreserveAll,
                    );
                }
                self.mark_continuous_state_dirty();
            }
        }

        // Apply enters tapped
        if result.enters_tapped || choices.as_enters_tapped {
            self.tap(new_id);
        }

        // Apply enters with counters. Counters an object is given as it
        // enters are "put" on it (CR 122.6): each kind gets a counter
        // timestamp (613.7c) and a counters-put event, which "whenever
        // counters are put on" triggers and turn history see. The object's
        // controller puts them (122.6a).
        let mut entry_counters: Vec<(crate::object::CounterType, u32)> = Vec::new();
        for (counter_type, count) in result
            .enters_with_counters
            .iter()
            .chain(&choices.as_enters_counters)
        {
            if let Some(obj) = self.object_mut(new_id) {
                obj.add_counters(*counter_type, *count);
            }
            if *count == 0 {
                continue;
            }
            match entry_counters
                .iter_mut()
                .find(|(existing, _)| existing == counter_type)
            {
                Some((_, total)) => *total = total.saturating_add(*count),
                None => entry_counters.push((*counter_type, *count)),
            }
        }
        if !entry_counters.is_empty() {
            self.mark_continuous_state_dirty();
            let entering_controller = self.object(new_id).map(|object| self.controller_of(object));
            for (counter_type, count) in entry_counters {
                self.effect_store
                    .continuous_effects
                    .record_counter_change(new_id, counter_type);
                let count_after = self.counter_count(new_id, counter_type);
                let event_provenance = self
                    .provenance_graph_mut()
                    .alloc_root_event(crate::events::EventKind::MarkersChanged);
                let event = crate::triggers::TriggerEvent::new_with_provenance(
                    crate::events::MarkersChangedEvent::added(
                        counter_type,
                        new_id,
                        count,
                        Some(new_id),
                        entering_controller,
                    )
                    .with_count_after(count_after),
                    event_provenance,
                );
                self.queue_trigger_event(event_provenance, event);
            }
        }

        // Apply source-zone entry programs' permanent designations to this
        // new object before any enter-the-battlefield observer can inspect it.
        for (label,payment) in &choices.as_enters_named_actions {
            let controller=self.current_controller(new_id).ok_or(crate::effects::ExecutionError::InvalidTarget)?;
            let effect=crate::effect::Effect::new(ironsmith_core::PerformNamedActionEffect {label:label.clone(),performer:Some(crate::target::ChooseSpec::SpecificObject(new_id)),objects:None,prior_objects:None});
            let outcome=crate::effects::execute_effect(self,&effect,&mut crate::effects::EffectContext::new_default(new_id,controller).with_activation_mana_payment(payment.clone()))?;
            for event in outcome.events {self.queue_trigger_event(event.provenance(),event);}
        }
        for designation in &choices.as_enters_designations {
            let effect = crate::effect::Effect::new(ironsmith_core::SetPermanentDesignationEffect {
                target: crate::target::ChooseSpec::SpecificObject(new_id),
                designation: designation.clone(),
            });
            let controller = self.current_controller(new_id).ok_or(crate::effects::ExecutionError::InvalidTarget)?;
            let mut context = crate::effects::EffectContext::new_default(new_id, controller);
            let outcome = crate::effects::execute_effect(self, &effect, &mut context)?;
            for event in outcome.events { self.queue_trigger_event(event.provenance(), event); }
        }

        if let Some(protector) = choices.battle_protector {
            let _ = self.set_battle_protector(new_id, protector);
        }

        if !result.paid_labels.is_empty()
            && let Some(obj) = self.object_mut(new_id)
        {
            for label in &result.paid_labels {
                obj.optional_costs_paid.mark_label_paid(label);
            }
        }

        for linked_old_id in &result.linked_exile_with_entering {
            if self.object(*linked_old_id).is_none() {
                continue;
            }
            let Some(exiled_id) = self.move_object(*linked_old_id, Zone::Exile, cause.clone())
            else {
                continue;
            };
            self.add_exiled_with_source_link(new_id, exiled_id);
            self.record_zone_change_results(*linked_old_id, vec![exiled_id]);
        }

        if let Some(copy_source_id) = result.enters_as_copy_of
            && !result.copy_followups.is_empty()
        {
            self.apply_enter_as_copy_followups(new_id, copy_source_id, &result.copy_followups);
        }

        // If this is an Aura entering without a specified host, choose what to
        // attach to (CR 303.4f; a resolving Aura spell supplies its target as
        // the entry attachment instead).
        if choose_aura_attachment
            && let Some(obj) = self.object(new_id)
            && obj.subtypes.contains(&Subtype::Aura)
            // An entry effect that makes it a non-Aura ("as a non-Aura
            // enchantment") means it enters attached to nothing.
            && !self
                .current_subtypes(new_id)
                .is_some_and(|subtypes| !subtypes.contains(&Subtype::Aura))
            && obj.attached_to.is_none()
            && let Some(filter) = obj.aura_attach_filter_owned()
        {
            let chooser = self.current_controller(new_id).unwrap_or(obj.owner);
            let filter_ctx = self.filter_context_for(chooser, Some(new_id));
            let chosen_target = match filter {
                AuraAttachmentFilter::Object(filter) => {
                    // CR 303.4f: the object needn't be a permanent. An enchant
                    // ability naming another zone ("enchant creature card in a
                    // graveyard") picks from that zone (Animate Dead returned
                    // by Sun Titan or found by Zur).
                    let candidate_zone = filter.zone.unwrap_or(Zone::Battlefield);
                    let mut candidates = Vec::new();
                    for (id, candidate) in &self.objects {
                        // CR 702.26b: phased-out permanents are treated as
                        // though they don't exist.
                        if *id == new_id
                            || candidate.zone != candidate_zone
                            || self.is_phased_out(*id)
                        {
                            continue;
                        }
                        // CR 303.4f: the object must be legal to enchant under
                        // "any other applicable effects", which includes
                        // protection (702.16c) but not hexproof or shroud.
                        if filter.matches(candidate, &filter_ctx, self)
                            && entry_attachment_filter.as_ref().is_none_or(|restriction| {
                                restriction.matches(candidate, &filter_ctx, self)
                            })
                            && !crate::targeting::has_protection_from_source(self, *id, new_id)
                        {
                            candidates.push(crate::decisions::context::SelectableObject::new(
                                *id,
                                candidate.name.to_string(),
                            ));
                        }
                    }

                    // The object map's iteration order is hash-based; offer
                    // the choice (and its fallback) in a stable order.
                    candidates.sort_by_key(|candidate| candidate.id);
                    if candidates.is_empty() {
                        None
                    } else {
                        let fallback_target = candidates.first().map(|candidate| candidate.id);
                        let ctx = crate::decisions::context::SelectObjectsContext::new(
                            chooser,
                            Some(new_id),
                            "Attach Aura to",
                            candidates,
                            1,
                            Some(1),
                        );
                        decision_maker
                            .decide_objects(self, &ctx)
                            .first()
                            .copied()
                            .or(fallback_target)
                            .map(AttachmentTarget::Object)
                    }
                }
                AuraAttachmentFilter::Player(filter) => {
                    let candidates = self
                        .players
                        .iter()
                        .filter(|player| {
                            entry_attachment_filter.is_none()
                                && player.is_in_game()
                                && filter.matches_player(player.id, &filter_ctx)
                                && !match self.object(new_id) {
                                    Some(aura) => {
                                        crate::effects::permanents::player_has_protection_from_object(
                                            self, player.id, aura,
                                        )
                                    }
                                    None => crate::effects::permanents::player_has_protection_from_everything(
                                        self, player.id,
                                    ),
                                }
                        })
                        .map(|player| (player.id, player.name.to_string()))
                        .collect::<Vec<_>>();
                    if candidates.is_empty() {
                        None
                    } else if candidates.len() == 1 {
                        Some(AttachmentTarget::Player(candidates[0].0))
                    } else {
                        let choice_spec = crate::decisions::specs::ChoiceSpec::single(
                            new_id,
                            candidates
                                .iter()
                                .enumerate()
                                .map(|(idx, (_, name))| {
                                    crate::decisions::spec::DisplayOption::new(idx, name.clone())
                                })
                                .collect(),
                        );
                        let mut chosen = crate::decisions::make_decision(
                            self,
                            decision_maker,
                            chooser,
                            Some(new_id),
                            choice_spec,
                        );
                        chosen
                            .pop()
                            .and_then(|idx| candidates.get(idx).map(|(player_id, _)| *player_id))
                            .map(AttachmentTarget::Player)
                            .or_else(|| Some(AttachmentTarget::Player(candidates[0].0)))
                    }
                }
            };

            let attached = chosen_target.is_some_and(|target| {
                if !self.attach_object_to_target(new_id, target) {
                    return false;
                }
                true
            });
            if !attached && let Some(checkpoint) = aura_entry_checkpoint.take() {
                *self = checkpoint;
                if old_zone == Zone::Stack {
                    let Some(graveyard_id) = self.move_object(old_id, Zone::Graveyard, cause)
                    else {
                        return Ok(None);
                    };
                    return Ok(Some(EntersResult {
                        new_id: graveyard_id,
                        enters_tapped: false,
                        entry_attachment: None,
                    }));
                }
                return Ok(Some(EntersResult {
                    new_id: old_id,
                    enters_tapped: false,
                        entry_attachment: None,
                }));
            }
        }

        // "As this Equipment enters, choose a creature you control it could
        // be attached to. If you do, it enters attached to that creature."
        // (Grifter's Blade): a non-Aura's own entry choice of its host. With
        // no legal host it simply enters unattached.
        if entry_attachment.is_none()
            && !prospective_aura_entry
            && let Some(attach_filter) = self.object(new_id).and_then(|object| {
                object.abilities.iter().find_map(|ability| {
                    let crate::ability::AbilityKind::Static(ability) = &ability.kind else {
                        return None;
                    };
                    match &ability.compiled_model()?.payload {
                        ironsmith_core::StaticAbilityPayload::EntersAttachedToChosenObject {
                            filter,
                            ..
                        } => Some(filter.clone()),
                        _ => None,
                    }
                })
            })
            && self
                .object(new_id)
                .is_some_and(|object| object.attached_to.is_none())
        {
            let chooser = self
                .object(new_id)
                .map(|object| self.controller_of(object))
                .ok_or(crate::effects::ExecutionError::ObjectNotFound(new_id))?;
            let filter_ctx = self.filter_context_for(chooser, Some(new_id));
            let mut candidates = Vec::new();
            for id in self.battlefield.clone() {
                if id == new_id || self.is_phased_out(id) {
                    continue;
                }
                let Some(candidate) = self.object(id) else {
                    continue;
                };
                if attach_filter.matches(candidate, &filter_ctx, self)
                    && !crate::targeting::has_protection_from_source(self, id, new_id)
                {
                    candidates.push(crate::decisions::context::SelectableObject::new(
                        id,
                        candidate.name.to_string(),
                    ));
                }
            }
            candidates.sort_by_key(|candidate| candidate.id);
            if !candidates.is_empty() {
                let fallback_target = candidates.first().map(|candidate| candidate.id);
                let ctx = crate::decisions::context::SelectObjectsContext::new(
                    chooser,
                    Some(new_id),
                    "Choose a creature for it to enter attached to",
                    candidates,
                    1,
                    Some(1),
                );
                if let Some(host) = decision_maker
                    .decide_objects(self, &ctx)
                    .first()
                    .copied()
                    .or(fallback_target)
                {
                    crate::effects::permanents::attach_battlefield_object_to_target(
                        self,
                        new_id,
                        AttachmentTarget::Object(host),
                    );
                }
            }
        }

        let mut entry_attachment_verdict = entry_attachment_specified.then_some(
            crate::effect::EntryAttachmentChoice { target: entry_attachment, performed: false },
        );
        if entry_attachment_specified
            && (!entry_attachment_requires_aura
                || self.calculated_subtypes(new_id).contains(&Subtype::Aura))
        {
            // Inspect the resolved entrant: copy/type replacements can make the
            // authored object an Aura or make a requested Aura a non-Aura.
            let is_aura = self.calculated_subtypes(new_id).contains(&Subtype::Aura);
            let attached = entry_attachment.is_some_and(|target| {
                self.object(new_id).is_some_and(|object| object.attached_to == Some(target))
                    || crate::effects::permanents::attach_battlefield_object_to_target(self, new_id, target)
            });
            if let Some(verdict) = &mut entry_attachment_verdict {
                verdict.performed = attached;
            }
            if attached && let Some(target) = entry_attachment {
                // The entry owner performed the attachment. Its as-becomes-
                // attached choices precede entry observations and deferred
                // replacement programmes; the later receipt consumer does not
                // physically attach or repeat these choices.
                let controller = self.controller_of_id(new_id)
                    .ok_or(crate::effects::ExecutionError::ObjectNotFound(new_id))?;
                let mut choice_context = crate::effects::ExecutionContext::new(
                    new_id, controller, decision_maker,
                );
                choice_context.cause = cause.clone();
                crate::effects::permanents::choose_color_as_becomes_attached(
                    self, &mut choice_context, new_id, target,
                );
                if choice_context.decision_maker.awaiting_choice() { return Ok(None); }
            }
            if is_aura && !attached {
                let checkpoint = aura_entry_checkpoint.take().ok_or_else(|| {
                    crate::effects::ExecutionError::InternalError(
                        "fixed Aura attachment lost its precommit checkpoint".into(),
                    )
                })?;
                *self = checkpoint;
                if old_zone == Zone::Stack {
                    let Some(graveyard_id) = self.move_object(old_id, Zone::Graveyard, cause)
                    else {
                        return Ok(None);
                    };
                    return Ok(Some(EntersResult {
                        new_id: graveyard_id,
                        enters_tapped: false,
                        entry_attachment: None,
                    }));
                }
                *original_verdict = EventOutcome::Prevented;
                return Ok(None);
            }
        }

        // "This creature enters prepared." The permanent is on the battlefield
        // by now, which is what the prepare spell copy's existence is tied to.
        //
        // This reads the printed abilities rather than the calculated ones:
        // every battlefield entry runs through here, and asking for calculated
        // characteristics would force a per-entry recomputation instead of the
        // batched layer rebuild. Entering prepared is a printed property, and
        // CR keeps the designation even if the permanent later loses abilities.
        if self.object_printed_static_ability(
            new_id,
            crate::static_abilities::StaticAbilityId::EntersPrepared,
        ) {
            self.set_prepared(new_id);
        }

        // CR 714.3a / 702.155b: a Saga gets its lore counter(s) as it enters,
        // however it enters.
        crate::game_loop::add_entry_lore_counters(self, new_id, decision_maker)?;

        // CR 709.5d: a Room gets the unlocked designation for the half that was
        // cast; one entering any other way has neither door unlocked. CR
        // 709.5h: "when you unlock this door" also triggers for a door that
        // entered unlocked.
        if let Some(room_controller) = self
            .object(new_id)
            .filter(|object| {
                object.linked_face_layout == LinkedFaceLayout::Split
                    && object.subtypes.contains(&Subtype::Room)
            })
            .map(|object| self.controller_of(object))
        {
            // A permanent entering as a copy of a Room (Clone) wasn't cast as
            // either half, so it enters with neither door unlocked.
            let cast_as_spell = old_zone == Zone::Stack
                && result.enters_as_copy_of.is_none()
                && self
                    .object(new_id)
                    .is_some_and(|object| object.kind == crate::object::ObjectKind::Card);
            if cast_as_spell {
                let provenance = self
                    .provenance_graph_mut()
                    .alloc_root_event(crate::events::EventKind::KeywordAction);
                let event = crate::triggers::TriggerEvent::new_with_provenance(
                    crate::events::KeywordActionEvent::new(
                        crate::events::KeywordActionKind::UnlockDoor,
                        room_controller,
                        new_id,
                        1,
                    ),
                    provenance,
                );
                self.queue_trigger_event(provenance, event);
            } else {
                self.mark_room_entered_with_no_unlocked_door(new_id);
            }
        }

        Ok(Some(EntersResult {
            new_id,
            enters_tapped: result.enters_tapped,
            entry_attachment: entry_attachment_verdict,
        }))
    }

    /// Removes an object from the game completely (e.g., tokens ceasing to exist).
    /// This does NOT create a new object - the object is simply gone.
    pub fn remove_object(&mut self, id: ObjectId) {
        if !self.objects.contains_key(&id) {
            return;
        }
        self.auxiliary_tracking_mut().acquired_spell_keywords.remove(&id);
        self.auxiliary_tracking_mut().duration_windows.remove(&crate::game_state::LibraryTopAnnouncement::Cast(id));
        self.object_annotations_mut().noted_life_totals.remove(&id);
        self.object_annotations_mut().noted_creature_types.remove(&id);
        self.object_annotations_mut().stored_die_results.remove(&id);
        self.object_annotations_mut().turn_face_up_before_action.remove(&id);
        if self
            .object(id)
            .is_some_and(|object| object.zone == Zone::Battlefield)
        {
            self.detach_relations_for_leaving_object(id);
        }
        self.battlefield_flags_mut()
            .saga_entry_lore_processed
            .remove(&id);
        if let Some(stable_id) = self.object(id).map(|object| object.stable_id) {
            self.remove_stickers(stable_id);
        }
        self.mark_continuous_state_dirty();
        self.bump_mutation_revision();
        self.object_store.changes.record(id);
        self.object_store.render_changes.record(id);
        if let Some(obj) = self.objects.remove(&id).map(ObjectStore::into_owned_object) {
            self.effect_store.continuous_effects.remove_source_bound_static_effects(id);
            if let Some(target) = obj.attached_to {
                match target {
                    AttachmentTarget::Object(parent_id) => {
                        if let Some(parent) = self.object_mut(parent_id) {
                            parent.attachments.retain(|existing| *existing != id);
                        }
                    }
                    AttachmentTarget::Player(player_id) => {
                        if let Some(player) = self.player_mut(player_id) {
                            player.attachments.retain(|existing| *existing != id);
                        }
                    }
                }
            }
            self.stable_id_index.remove(&obj.stable_id);
            self.auxiliary_tracking_mut()
                .sector_designations
                .remove(&id);
            {
                let commander_tracking = self.commander_tracking_mut();
                commander_tracking.melded_permanents.remove(&obj.stable_id);
                commander_tracking.merged_permanents.remove(&obj.stable_id);
                commander_tracking
                    .pending_merged_component_destinations
                    .remove(&obj.stable_id);
                commander_tracking.declined_command_zone_moves.remove(&id);
            }
            self.remove_from_zone_index(id, obj.zone, obj.owner);
        }
    }

    /// Project a spell onto the stack in an isolated payment-analysis clone.
    /// Retain its identity without producing a physical zone-change event.
    pub(crate) fn project_spell_for_payment(&mut self, id: ObjectId) {
        let Some(object) = self.object(id) else {
            return;
        };
        let (zone, owner) = (object.zone, object.owner);
        if zone == Zone::Stack {
            return;
        }
        // This isolated world is an unfinished casting announcement, not a
        // completed library move. Keep its new top concealed during queries.
        self.begin_library_top_announcement(super::LibraryTopAnnouncement::Cast(id));
        self.remove_from_zone_index(id, zone, owner);
        // Casting face up from concealed exile is not a turn-face-up action.
        // The isolated declaration clears old concealment; its caller reapplies
        // the face-down flag only for a declared face-down cast.
        let concealed = {
            let flags = self.battlefield_flags_mut();
            flags.manifested.remove(&id);
            flags.cloaked.remove(&id);
            flags.described_face_down.remove(&id);
            flags.face_down.remove(&id)
        };
        self.object_mut(id).expect("proposal source exists").zone = Zone::Stack;
        if concealed {
            self.mark_face_down_state_changed(id);
        }
    }

    /// Removes an object ID from its zone index.
    fn remove_from_zone_index(&mut self, id: ObjectId, zone: Zone, owner: PlayerId) {
        let mut removed = false;
        match zone {
            Zone::Battlefield => {
                let before = self.battlefield.len();
                self.battlefield.remove_id(id);
                removed = self.battlefield.len() != before;
            }
            Zone::Command => {
                let before = self.command_zone.len();
                self.command_zone.remove_id(id);
                removed = self.command_zone.len() != before;
            }
            Zone::Exile => {
                let before = self.exile.len();
                self.exile.remove_id(id);
                removed = self.exile.len() != before;
            }
            Zone::Ante => {
                let before = self.ante.len();
                self.ante.remove_id(id);
                removed = self.ante.len() != before;
            }
            Zone::Library => {
                let was_top = self
                    .player(owner)
                    .and_then(|player| player.library.last().copied())
                    == Some(id);
                if let Some(player) = self.player_mut(owner) {
                    let before = player.library.len();
                    player.library.remove_id(id);
                    removed = player.library.len() != before;
                }
                if was_top {
                    self.bump_library_top_revision(owner);
                }
            }
            Zone::Hand => {
                if let Some(player) = self.player_mut(owner) {
                    let before = player.hand.len();
                    player.hand.remove_id(id);
                    removed = player.hand.len() != before;
                }
            }
            Zone::Graveyard => {
                if let Some(player) = self.player_mut(owner) {
                    let before = player.graveyard.len();
                    player.graveyard.remove_id(id);
                    removed = player.graveyard.len() != before;
                }
            }
            Zone::OutsideGame => {
                if let Some(player) = self.player_mut(owner) {
                    let before = player.sideboard.len();
                    player.sideboard.remove_id(id);
                    removed = player.sideboard.len() != before;
                }
            }
            Zone::Stack => {
                let before = self.stack.len();
                // A spell leaving the stack also leaves its zone index.
                // Triggered/activated abilities sharing its source ID remain
                // independent stack objects and must survive that move.
                self.stack
                    .retain(|entry| entry.object_id != id || entry.is_ability);
                removed = self.stack.len() != before;
            }
        }
        if removed {
            self.bump_zone_revision(zone);
        }
    }

    // =========================================================================
    // Zone Consistency Validation
    // =========================================================================

    /// Validate that zone indexes are consistent with the canonical objects HashMap.
    ///
    /// This checks that:
    /// - Every ID in denormalized zone indexes (battlefield, exile, etc.) exists in objects
    /// - Every object's zone field matches exactly one denormalized index
    /// - No ID appears in multiple zone indexes
    ///
    /// Available in all builds for explicit validation. Automatic invariant checks
    /// remain limited to debug builds or paranoid invariant builds.
    pub fn validate_zone_consistency(&self) -> Result<(), String> {
        use std::collections::HashSet;

        let mut seen_ids: HashSet<ObjectId> = HashSet::new();

        // Check battlefield
        for &id in &self.battlefield {
            if seen_ids.contains(&id) {
                return Err(format!("Object #{} appears in multiple zone indexes", id.0));
            }
            seen_ids.insert(id);

            match self.objects.get(&id) {
                Some(obj) if obj.zone == Zone::Battlefield => {}
                Some(obj) => {
                    return Err(format!(
                        "Object #{} in battlefield index has zone {}",
                        id.0, obj.zone
                    ));
                }
                None => {
                    return Err(format!(
                        "Object #{} in battlefield index doesn't exist in objects",
                        id.0
                    ));
                }
            }
        }

        // Check exile
        for &id in &self.exile {
            if seen_ids.contains(&id) {
                return Err(format!("Object #{} appears in multiple zone indexes", id.0));
            }
            seen_ids.insert(id);

            match self.objects.get(&id) {
                Some(obj) if obj.zone == Zone::Exile => {}
                Some(obj) => {
                    return Err(format!(
                        "Object #{} in exile index has zone {}",
                        id.0, obj.zone
                    ));
                }
                None => {
                    return Err(format!(
                        "Object #{} in exile index doesn't exist in objects",
                        id.0
                    ));
                }
            }
        }

        // Check command zone
        for &id in &self.command_zone {
            if seen_ids.contains(&id) {
                return Err(format!("Object #{} appears in multiple zone indexes", id.0));
            }
            seen_ids.insert(id);

            match self.objects.get(&id) {
                Some(obj) if obj.zone == Zone::Command => {}
                Some(obj) => {
                    return Err(format!(
                        "Object #{} in command zone index has zone {}",
                        id.0, obj.zone
                    ));
                }
                None => {
                    return Err(format!(
                        "Object #{} in command zone index doesn't exist in objects",
                        id.0
                    ));
                }
            }
        }

        // Check ante
        for &id in &self.ante {
            if seen_ids.contains(&id) {
                return Err(format!("Object #{} appears in multiple zone indexes", id.0));
            }
            seen_ids.insert(id);

            match self.objects.get(&id) {
                Some(obj) if obj.zone == Zone::Ante => {}
                Some(obj) => {
                    return Err(format!(
                        "Object #{} in ante index has zone {}",
                        id.0, obj.zone
                    ));
                }
                None => {
                    return Err(format!(
                        "Object #{} in ante index doesn't exist in objects",
                        id.0
                    ));
                }
            }
        }

        // Check player zones
        for player in &self.players {
            // Library
            for &id in &player.library {
                if seen_ids.contains(&id) {
                    return Err(format!("Object #{} appears in multiple zone indexes", id.0));
                }
                seen_ids.insert(id);

                match self.objects.get(&id) {
                    Some(obj) if obj.zone == Zone::Library => {}
                    Some(obj) => {
                        return Err(format!(
                            "Object #{} in {}'s library has zone {}",
                            id.0, player.name, obj.zone
                        ));
                    }
                    None => {
                        return Err(format!(
                            "Object #{} in {}'s library doesn't exist in objects",
                            id.0, player.name
                        ));
                    }
                }
            }

            // Hand
            for &id in &player.hand {
                if seen_ids.contains(&id) {
                    return Err(format!("Object #{} appears in multiple zone indexes", id.0));
                }
                seen_ids.insert(id);

                match self.objects.get(&id) {
                    Some(obj) if obj.zone == Zone::Hand => {}
                    Some(obj) => {
                        return Err(format!(
                            "Object #{} in {}'s hand has zone {}",
                            id.0, player.name, obj.zone
                        ));
                    }
                    None => {
                        return Err(format!(
                            "Object #{} in {}'s hand doesn't exist in objects",
                            id.0, player.name
                        ));
                    }
                }
            }

            // Graveyard
            for &id in &player.graveyard {
                if seen_ids.contains(&id) {
                    return Err(format!("Object #{} appears in multiple zone indexes", id.0));
                }
                seen_ids.insert(id);

                match self.objects.get(&id) {
                    Some(obj) if obj.zone == Zone::Graveyard => {}
                    Some(obj) => {
                        return Err(format!(
                            "Object #{} in {}'s graveyard has zone {}",
                            id.0, player.name, obj.zone
                        ));
                    }
                    None => {
                        return Err(format!(
                            "Object #{} in {}'s graveyard doesn't exist in objects",
                            id.0, player.name
                        ));
                    }
                }
            }

            // Sideboard / outside the game
            for &id in &player.sideboard {
                if seen_ids.contains(&id) {
                    return Err(format!("Object #{} appears in multiple zone indexes", id.0));
                }
                seen_ids.insert(id);

                match self.objects.get(&id) {
                    Some(obj) if obj.zone == Zone::OutsideGame => {}
                    Some(obj) => {
                        return Err(format!(
                            "Object #{} in {}'s sideboard has zone {}",
                            id.0, player.name, obj.zone
                        ));
                    }
                    None => {
                        return Err(format!(
                            "Object #{} in {}'s sideboard doesn't exist in objects",
                            id.0, player.name
                        ));
                    }
                }
            }
        }

        // Check that all objects with non-Stack zones are in exactly one index
        for (&id, obj) in &self.objects {
            if obj.zone == Zone::Stack {
                // Stack objects are managed via StackEntry, not indexed
                continue;
            }
            if !seen_ids.contains(&id) {
                return Err(format!(
                    "Object #{} with zone {} is not in any zone index",
                    id.0, obj.zone
                ));
            }
        }

        Ok(())
    }

    /// Debug assertion for zone consistency. Panics if zones are inconsistent.
    #[cfg(any(debug_assertions, feature = "paranoid-invariants"))]
    pub fn debug_assert_zone_consistency(&self) {
        if let Err(e) = self.validate_zone_consistency() {
            panic!("Zone consistency violation: {}", e);
        }
    }

    /// Gets a reference to an object by ID.
    pub fn object(&self, id: ObjectId) -> Option<&Object> {
        self.object_store.object(id)
    }

    /// Gets a mutable reference to an object by ID.
    pub fn object_mut(&mut self, id: ObjectId) -> Option<&mut Object> {
        if !self.objects.contains_key(&id) {
            return None;
        }
        let counter = &self.runtime_cache.work_counters.generic_object_mutations;
        counter.set(counter.get().saturating_add(1));
        self.mark_continuous_state_dirty();
        let revision = self.bump_mutation_revision();
        self.runtime_cache
            .characteristics_cache
            .bump_object_revision(id, revision);
        let object = self.object_store.object_mut(id)?;
        object.last_modified = revision;
        Some(object)
    }

    pub(crate) fn objects_map(&self) -> &ObjectMap {
        self.object_store.objects_map()
    }

    /// Whether an attachment destination still exists. Aura enchant filters
    /// determine its permitted zone; Equipment and Fortifications additionally
    /// require a battlefield destination in attachment legality checks.
    pub fn attachment_target_exists(&self, target: AttachmentTarget) -> bool {
        match target {
            AttachmentTarget::Object(id) => self.object(id).is_some(),
            AttachmentTarget::Player(id) => {
                self.player(id).is_some_and(|player| player.is_in_game())
            }
        }
    }

    pub fn attachment_target_exists_on_battlefield(&self, target: AttachmentTarget) -> bool {
        match target {
            AttachmentTarget::Object(id) => self
                .object(id)
                .is_some_and(|object| object.zone == Zone::Battlefield),
            AttachmentTarget::Player(id) => {
                self.player(id).is_some_and(|player| player.is_in_game())
            }
        }
    }

    // =========================================================================
    // Counter Management
    // =========================================================================

    /// Add counters to an object and return a CounterPlaced event for trigger checking.
    ///
    /// This method adds the counters and returns the event that should be used
    /// to check for triggers (like saga chapter abilities).
    ///
    /// Returns None for zero counters or an absent or phased-out object.
    pub fn add_counters(
        &mut self,
        id: ObjectId,
        counter_type: crate::object::CounterType,
        amount: u32,
    ) -> Option<crate::triggers::TriggerEvent> {
        // CR 702.26b: ordinary effects cannot change phased-out permanents.
        if amount == 0 || self.is_phased_out(id) {
            return None;
        }
        self.mark_continuous_state_dirty();
        let obj = self.object_mut(id)?;
        let previous_count = obj.counters.get(&counter_type).copied().unwrap_or(0);
        obj.add_counters(counter_type, amount);
        if amount > 0 {
            self.effect_store
                .continuous_effects
                .record_counter_change(id, counter_type);
        }
        self.record_counter_ui_effect_event("counters_added", id, counter_type, amount);

        let event_provenance = self
            .provenance_graph_mut()
            .alloc_root_event(crate::events::EventKind::CounterPlaced);
        Some(crate::triggers::TriggerEvent::new_with_provenance(
            crate::events::other::CounterPlacedEvent::new(id, counter_type, amount)
                .with_previous_count(previous_count),
            event_provenance,
        ))
    }

    /// Remove counters from an object.
    ///
    /// Returns the actual number of counters removed and a trigger event.
    /// The actual removed amount may be less than requested if there weren't enough.
    pub fn remove_counters(
        &mut self,
        id: ObjectId,
        counter_type: crate::object::CounterType,
        amount: u32,
        source: Option<ObjectId>,
        source_controller: Option<PlayerId>,
    ) -> Option<(u32, crate::triggers::TriggerEvent)> {
        // CR 702.26b: ordinary effects cannot change phased-out permanents.
        if self.is_phased_out(id) {
            return None;
        }
        // A "counters can't be removed" prohibition (CR 122.1) leaves them.
        if !self.can_have_counter_type_removed(id, counter_type) {
            return None;
        }
        self.mark_continuous_state_dirty();
        let location_snapshot = self.object(id).map(|object| {
            crate::snapshot::ObjectSnapshot::from_object_with_calculated_characteristics(
                object, self,
            )
        });
        let obj = self.object_mut(id)?;
        let removed = obj.remove_counters(counter_type, amount);
        let count_after = obj.counters.get(&counter_type).copied().unwrap_or(0);

        if removed == 0 {
            return None;
        }
        self.record_counter_ui_effect_event("counters_removed", id, counter_type, removed);

        let event_provenance = self
            .provenance_graph_mut()
            .alloc_root_event(crate::events::EventKind::MarkersChanged);
        let mut event = crate::triggers::TriggerEvent::new_with_provenance(
            crate::events::MarkersChangedEvent::removed(
                counter_type,
                id,
                removed,
                source,
                source_controller,
            )
            .with_count_after(count_after),
            event_provenance,
        );
        if let Some(snapshot) = location_snapshot {
            event = event.with_lookback_source_snapshots(vec![snapshot]);
        }

        Some((removed, event))
    }

    /// Add counters with full tracking (source, controller) for the unified marker system.
    ///
    /// Returns a MarkersChangedEvent for trigger checking.
    pub fn add_counters_with_source(
        &mut self,
        id: ObjectId,
        counter_type: crate::object::CounterType,
        amount: u32,
        source: Option<ObjectId>,
        source_controller: Option<PlayerId>,
    ) -> Option<crate::triggers::TriggerEvent> {
        self.add_counters_with_cause(id, counter_type, amount, crate::events::cause::EventCause {
            source, source_controller, ..crate::events::cause::EventCause::effect()
        })
    }

    pub fn add_counters_with_cause(
        &mut self, id: ObjectId, counter_type: crate::object::CounterType, amount: u32,
        cause: crate::events::cause::EventCause,
    ) -> Option<crate::triggers::TriggerEvent> {
        let source = cause.source;
        let source_controller = cause.source_controller;
        // CR 702.26b: ordinary effects cannot change phased-out permanents.
        if self.is_phased_out(id) {
            return None;
        }
        self.mark_continuous_state_dirty();
        if amount == 0 {
            return None;
        }

        let obj = self.object_mut(id)?;
        obj.add_counters(counter_type, amount);
        let count_after = obj.counters.get(&counter_type).copied().unwrap_or(0);
        self.effect_store
            .continuous_effects
            .record_counter_change(id, counter_type);
        self.record_counter_ui_effect_event("counters_added", id, counter_type, amount);

        let event_provenance = self
            .provenance_graph_mut()
            .alloc_root_event(crate::events::EventKind::MarkersChanged);
        // The event-time count lets chapter abilities (CR 714.2b) and
        // "Nth counter" triggers (122.7) compare the exact before/after pair.
        Some(crate::triggers::TriggerEvent::new_with_provenance(
            crate::events::MarkersChangedEvent::added(
                counter_type,
                id,
                amount,
                source,
                source_controller,
            )
            .with_count_after(count_after).with_cause(cause),
            event_provenance,
        ))
    }

    /// Record a UI-only counter change event for battlefield objects.
    fn record_counter_ui_effect_event(
        &mut self,
        kind: &str,
        id: ObjectId,
        counter_type: crate::object::CounterType,
        amount: u32,
    ) {
        if amount == 0 {
            return;
        }
        let Some(stable_id) = self
            .object(id)
            .filter(|obj| obj.zone == Zone::Battlefield)
            .map(|obj| obj.stable_id)
        else {
            return;
        };
        self.record_ui_effect_event(
            kind,
            None,
            None,
            vec![stable_id],
            Some(i64::from(amount)),
            Some(counter_type.description().into_owned()),
        );
    }

    /// Get the number of counters of a specific type on an object.
    pub fn counter_count(&self, id: ObjectId, counter_type: crate::object::CounterType) -> u32 {
        self.object(id)
            .and_then(|obj| obj.counters.get(&counter_type).copied())
            .unwrap_or(0)
    }

    /// Add player counters, returning every notification and replacement outcome.
    pub fn add_player_counters_with_source(
        &mut self,
        player_id: PlayerId,
        counter_type: crate::object::CounterType,
        amount: u32,
        source: Option<ObjectId>,
        source_controller: Option<PlayerId>,
    ) -> Result<crate::effect::EffectOutcome, crate::effects::ExecutionError> {
        let mut dm = crate::decision::SelectFirstDecisionMaker;
        self.add_player_counters_with_source_with_dm(
            player_id,
            counter_type,
            amount,
            source,
            source_controller,
            &mut dm,
        )
    }

    /// Resolve player-counter choices and commit only the resolved event.
    /// Pending/error operations restore their state and return no partial events.
    pub fn add_player_counters_with_source_with_dm(
        &mut self,
        player_id: PlayerId,
        counter_type: crate::object::CounterType,
        amount: u32,
        source: Option<ObjectId>,
        source_controller: Option<PlayerId>,
        dm: &mut dyn crate::decision::DecisionMaker,
    ) -> Result<crate::effect::EffectOutcome, crate::effects::ExecutionError> {
        let mut cause = crate::events::cause::EventCause::effect();
        cause.source = source;
        cause.source_controller = source_controller;
        let mut ctx = crate::effects::ExecutionContext::new(
            source.unwrap_or(ObjectId::from_raw(0)),
            source_controller.unwrap_or(player_id),
            dm,
        )
        .with_cause(cause.clone());
        let event =
            crate::events::Event::put_player_counters(player_id, counter_type, amount, cause);
        crate::effects::counters::execute_player_counter_placement(self, &mut ctx, event)
    }

    /// Remove counters from a player and emit a unified marker event when applicable.
    ///
    /// Returns the actual number removed and the corresponding event.
    pub fn remove_player_counters_with_source(
        &mut self,
        player_id: PlayerId,
        counter_type: crate::object::CounterType,
        amount: u32,
        source: Option<ObjectId>,
        source_controller: Option<PlayerId>,
    ) -> Option<(u32, crate::triggers::TriggerEvent)> {
        if amount == 0 {
            return None;
        }

        let removed = if matches!(counter_type, crate::object::CounterType::Poison) {
            let current = self.player(player_id)?.poison_counters;
            let removed = current.min(amount);
            self.write_shared_poison(player_id, current.saturating_sub(removed));
            removed
        } else {
            self.player_mut(player_id)?
                .remove_counters(counter_type, amount)
        };

        if removed == 0 {
            return None;
        }

        let count_after = self.player(player_id)?.counter_count(counter_type);
        let event_provenance = self
            .provenance_graph_mut()
            .alloc_root_event(crate::events::EventKind::MarkersChanged);
        Some((
            removed,
            crate::triggers::TriggerEvent::new_with_provenance(
                crate::events::MarkersChangedEvent::removed(
                    counter_type,
                    player_id,
                    removed,
                    source,
                    source_controller,
                )
                .with_count_after(count_after),
                event_provenance,
            ),
        ))
    }

    /// Check if an object has any counters of a specific type.
    pub fn has_counters(&self, id: ObjectId, counter_type: crate::object::CounterType) -> bool {
        self.counter_count(id, counter_type) > 0
    }

    // =========================================================================
    // Calculated Characteristics (with continuous effects applied)
    // =========================================================================

    /// Calculate all characteristics for an object, applying continuous effects.
    ///
    /// This includes effects from:
    /// - Registered continuous effects (from resolved spells/abilities)
    /// - Static abilities on permanents (generated dynamically)
    pub fn all_continuous_effects(&self) -> Vec<ContinuousEffect> {
        self.all_continuous_effects_arc().as_ref().clone()
    }

    /// Complete snapshot for fallible queries. A legacy clean cache is not
    /// sufficient evidence: only checked publication can establish trust.
    pub fn try_all_continuous_effects(
        &self,
    ) -> Result<Vec<ContinuousEffect>, crate::static_ability_processor::StaticEffectDiscoveryError>
    {
        self.try_all_continuous_effects_arc()
            .map(|effects| effects.as_ref().clone())
    }

    /// Fallible shared snapshot: the same checked revision/error contract as
    /// the owned query, without cloning every effect merely to validate it.
    pub(crate) fn try_all_continuous_effects_arc(
        &self,
    ) -> Result<
        Arc<Vec<ContinuousEffect>>,
        crate::static_ability_processor::StaticEffectDiscoveryError,
    > {
        crate::static_ability_processor::validate_mana_scalar_domain(self)?;
        let revision = self.effect_store.continuous_effects.revision();
        if self.continuous_state_is_clean()
            && self
                .runtime_cache
                .static_effects_cache
                .borrow()
                .has_checked_snapshot(revision)
        {
            return Ok(self.cached_continuous_effects_snapshot_arc());
        }
        crate::static_ability_processor::try_get_all_continuous_effects(self, self.static_effect_discovery_limits())
            .map(Arc::new)
    }

    /// Shared form of [`Self::all_continuous_effects`].
    pub(crate) fn all_continuous_effects_arc(&self) -> Arc<Vec<ContinuousEffect>> {
        if self.continuous_state_is_clean() {
            return self.cached_continuous_effects_snapshot_arc();
        }
        if let Some(context) = crate::continuous::nested_regeneration_context(self) {
            return crate::continuous::regenerate_in_context(context, || {
                crate::static_ability_processor::get_all_continuous_effects(self)
            });
        }
        Arc::new(crate::static_ability_processor::get_all_continuous_effects(
            self,
        ))
    }

    /// Combine registered and cached static-ability continuous effects.
    ///
    /// Unlike `all_continuous_effects`, this does not regenerate static-ability
    /// effects dynamically. Callers must only use this after
    /// `refresh_continuous_state` (or `update_static_ability_effects`) for the
    /// current state.
    pub(crate) fn cached_continuous_effects_snapshot(&self) -> Vec<ContinuousEffect> {
        self.cached_continuous_effects_snapshot_arc()
            .as_ref()
            .clone()
    }

    pub(crate) fn cached_continuous_effects_snapshot_arc(&self) -> Arc<Vec<ContinuousEffect>> {
        let revision = self.effect_store.continuous_effects.revision();
        if let Some((cached_revision, effects)) =
            self.runtime_cache.effects_snapshot.borrow().as_ref()
            && *cached_revision == revision
        {
            return Arc::clone(effects);
        }

        let mut effects: Vec<ContinuousEffect> = self
            .effect_store
            .continuous_effects
            .effects_sorted()
            .into_iter()
            .cloned()
            .collect();
        effects.reserve(
            self.effect_store
                .continuous_effects
                .static_ability_effects()
                .len(),
        );
        effects.extend(
            self.effect_store
                .continuous_effects
                .static_ability_effects()
                .iter()
                .cloned(),
        );
        let effects = Arc::new(effects);
        *self.runtime_cache.effects_snapshot.borrow_mut() = Some((revision, Arc::clone(&effects)));
        effects
    }

    pub(crate) fn characteristicless_face_down_characteristics(
        &self,
        object: ObjectId,
    ) -> Option<crate::continuous::CalculatedCharacteristics> {
        // CR 121.8, 406.3a and hidden-agenda rules: these face-down objects
        // have no characteristics. Their identities and zones remain available.
        if !self.drawn_card_waits_for_announcement(object)
            && !self.is_face_down_conspiracy(object)
            && !(self.is_face_down(object)
                && self
                    .object(object)
                    .is_some_and(|object| object.zone == Zone::Exile))
        {
            return None;
        }
        let owner = self.object(object)?.owner;
        Some(crate::continuous::CalculatedCharacteristics {
            copy_values: None,
            alternate_name: None,
            name: "".into(),
            mana_cost: None,
            linked_face_mana_value: None,
            compiled_card_text: std::sync::Arc::<str>::from(""),
            ability_labels: Default::default(),
            base_power: None,
            base_toughness: None,
            power: None,
            toughness: None,
            card_types: Vec::new().into(),
            subtypes: Vec::new().into(),
            supertypes: Vec::new().into(),
            world_supertype_since: None,
            colors: crate::color::ColorSet::COLORLESS,
            loyalty: None,
            defense: None,
            abilities: Vec::new().into(),
            static_abilities: Vec::new().into(),
            numeric_range_error: None,
            numeric_choice_error: None,
            text_change_error: None,
            spell_effect: Arc::new(crate::snapshot::SpellProgramState::Absent),
            text_changes: Vec::new(),
            ability_gain_prohibitions: Vec::new(),
            aura_attach_filter: None,
            controller: owner,
        })
    }

    /// Calculate all characteristics for an object using precomputed continuous effects.
    ///
    /// This avoids rebuilding/allocating the full effect list when multiple
    /// characteristic lookups happen in the same operation.
    pub fn calculated_characteristics_with_effects(
        &self,
        id: ObjectId,
        effects: &[ContinuousEffect],
    ) -> Option<crate::continuous::CalculatedCharacteristics> {
        if let Some(chars) = self.characteristicless_face_down_characteristics(id) {
            return Some(chars);
        }
        if let Some(chars) = crate::continuous::in_progress_characteristics(self, id) {
            return Some(chars);
        }
        crate::continuous::calculate_characteristics_with_effects(
            id,
            &self.objects,
            effects,
            &self.battlefield,
            self.commander_objects(),
            self,
        )
    }

    /// `calculated_characteristics_with_effects` for snapshot capture. When
    /// `effects` is the clean state's own effect snapshot (the same
    /// allocation), the characteristics cache holds exactly this result, so
    /// a board-wide capture does not rerun the layer system per object.
    pub(crate) fn calculated_characteristics_for_capture(
        &self,
        id: ObjectId,
        effects: &[ContinuousEffect],
    ) -> Option<crate::continuous::CalculatedCharacteristics> {
        if self.continuous_state_is_clean()
            && !self.is_phased_out(id)
            && self
                .runtime_cache
                .effects_snapshot
                .borrow()
                .as_ref()
                .is_some_and(|(revision, cached)| {
                    *revision == self.effect_store.continuous_effects.revision()
                        && std::ptr::eq(cached.as_slice(), effects)
                })
        {
            return self
                .calculated_characteristics_arc(id)
                .map(|chars| chars.as_ref().clone());
        }
        self.calculated_characteristics_with_effects(id, effects)
    }

    pub(crate) fn calculated_characteristics_batch_with_effects(
        &self,
        ids: &[ObjectId],
        effects: &[ContinuousEffect],
    ) -> HashMap<ObjectId, crate::continuous::CalculatedCharacteristics> {
        let mut calculated = crate::continuous::calculate_characteristics_batch_with_effects(
            ids,
            &self.objects,
            effects,
            &self.battlefield,
            self.commander_objects(),
            self,
        );
        for id in ids {
            if let Some(chars) = self.characteristicless_face_down_characteristics(*id) {
                calculated.insert(*id, chars);
            }
        }
        calculated
    }

    /// Precompute calculated characteristics for a set of objects in one batch.
    ///
    /// This is useful for external snapshot builders that are about to inspect
    /// many battlefield objects and want to avoid repeated one-object layer
    /// calculations. The cache is transient and automatically invalidated by
    /// continuous-effect revision changes.
    pub fn prewarm_calculated_characteristics(&self, ids: &[ObjectId]) {
        if !self.continuous_state_is_clean() {
            return;
        }

        let effects_revision = self.effect_store.continuous_effects.revision();
        let missing: Vec<_> = ids
            .iter()
            .copied()
            .filter(|id| {
                // A nested prewarm can include its enclosing partial source.
                !crate::continuous::characteristics_calculation_in_progress(self, *id)
                    && !self
                        .runtime_cache
                        .characteristics_cache
                        .contains_valid_entry(*id, effects_revision)
            })
            .collect();
        if missing.is_empty() {
            return;
        }

        let effects = self.cached_continuous_effects_snapshot();
        let marker = crate::continuous::provisional_condition_marker();
        let calculated = self.calculated_characteristics_batch_with_effects(&missing, &effects);
        if crate::continuous::computed_provisionally(marker) {
            return;
        }
        for id in missing {
            self.runtime_cache.characteristics_cache.insert(
                id,
                effects_revision,
                calculated.get(&id).cloned(),
            );
        }
    }

    pub fn calculated_characteristics_arc(
        &self,
        id: ObjectId,
    ) -> Option<Arc<crate::continuous::CalculatedCharacteristics>> {
        let _tap_reads = self.derived_tap_read_scope();
        if self
            .object(id)
            .is_some_and(|object| object.zone == Zone::Battlefield && self.is_phased_out(id))
        {
            return None;
        }
        if let Some(chars) = crate::continuous::in_progress_characteristics(self, id) {
            return Some(Arc::new(chars));
        }
        let effects_revision = self.effect_store.continuous_effects.revision();
        if self.continuous_state_is_clean()
            && let Some(cached) = self
                .runtime_cache
                .characteristics_cache
                .get(id, effects_revision)
        {
            self.runtime_cache
                .work_counters
                .bump_characteristics_cache_hits();
            #[cfg(feature = "paranoid-invariants")]
            self.assert_cached_characteristics_fresh(id, cached.as_deref());
            return cached;
        }

        if !self.continuous_state_is_clean()
            && let Some(context) = crate::continuous::nested_regeneration_context(self)
        {
            // A dirty read inside another calculation (a delirium count reading
            // each graveyard card) repeats in an identical layer context.
            if self.object(id).is_some_and(|object| object.zone == Zone::Battlefield)
                && self.battlefield.len() > 1
            {
                return crate::continuous::board_characteristics_in_context(context, id, || {
                    let all_effects = self.all_continuous_effects_arc();
                    self.runtime_cache
                        .work_counters
                        .bump_characteristics_full_recomputes();
                    self.runtime_cache
                        .work_counters
                        .add_effects_considered(all_effects.len() as u64);
                    let board: Vec<_> = self
                        .battlefield
                        .iter()
                        .copied()
                        .filter(|&candidate| {
                            candidate == id
                                || (!self.is_phased_out(candidate)
                                    && !crate::continuous::characteristics_calculation_in_progress(
                                        self, candidate,
                                    ))
                        })
                        .collect();
                    self.calculated_characteristics_batch_with_effects(&board, &all_effects)
                });
            }
            return crate::continuous::characteristics_in_context(context, id, || {
                let all_effects = self.all_continuous_effects_arc();
                self.runtime_cache
                    .work_counters
                    .bump_characteristics_full_recomputes();
                self.runtime_cache
                    .work_counters
                    .add_effects_considered(all_effects.len() as u64);
                self.calculated_characteristics_with_effects(id, &all_effects)
            });
        }
        let all_effects = self.all_continuous_effects_arc();
        self.runtime_cache
            .work_counters
            .bump_characteristics_full_recomputes();
        self.runtime_cache
            .work_counters
            .add_effects_considered(all_effects.len() as u64);
        if self.continuous_state_is_clean() {
            let mut scope = self.battlefield.clone();
            if !scope.contains(&id) {
                scope.push(id);
            }
            let missing: Vec<_> = scope
                .into_iter()
                .filter(|candidate| {
                    // A condition query can pull an enclosing source into
                    // this batch. Its current layer view is not a final result.
                    !crate::continuous::characteristics_calculation_in_progress(self, *candidate)
                        && !self
                            .runtime_cache
                            .characteristics_cache
                            .contains_valid_entry(*candidate, effects_revision)
                })
                .collect();
            if !missing.is_empty() {
                let marker = crate::continuous::provisional_condition_marker();
                let calculated_batch =
                    self.calculated_characteristics_batch_with_effects(&missing, &all_effects);
                // A self-dependent condition an enclosing evaluation treated
                // provisionally (CR 613.8) makes these results unfit to cache.
                if crate::continuous::computed_provisionally(marker) {
                    return calculated_batch.get(&id).cloned().map(Arc::new);
                }
                let mut calculated = None;
                for candidate in missing {
                    let cached = self.runtime_cache.characteristics_cache.insert(
                        candidate,
                        effects_revision,
                        calculated_batch.get(&candidate).cloned(),
                    );
                    if candidate == id {
                        calculated = cached;
                    }
                }
                return calculated;
            }
        }

        let marker = crate::continuous::provisional_condition_marker();
        let calculated = self.calculated_characteristics_with_effects(id, &all_effects);
        if self.continuous_state_is_clean() && !crate::continuous::computed_provisionally(marker) {
            return self.runtime_cache.characteristics_cache.insert(
                id,
                effects_revision,
                calculated,
            );
        }
        calculated.map(Arc::new)
    }

    pub fn calculated_characteristics(
        &self,
        id: ObjectId,
    ) -> Option<crate::continuous::CalculatedCharacteristics> {
        self.calculated_characteristics_arc(id)
            .map(|chars| chars.as_ref().clone())
    }

    #[cfg(feature = "paranoid-invariants")]
    fn assert_cached_characteristics_fresh(
        &self,
        id: ObjectId,
        cached: Option<&crate::continuous::CalculatedCharacteristics>,
    ) {
        if id.0 % 16 != 0 || !self.continuous_state_is_clean() {
            return;
        }
        let effects = self.cached_continuous_effects_snapshot();
        let recomputed = self.calculated_characteristics_with_effects(id, &effects);
        assert_eq!(
            format!("{cached:?}"),
            format!("{:?}", recomputed.as_ref()),
            "stale calculated-characteristics cache entry for object #{}",
            id.0
        );
    }

    /// Return the object's current characteristics in its zone.
    ///
    /// This view reflects continuous effects across all zones and expands
    /// semantic subtype implications like changeling.
    pub fn current_characteristics(&self, id: ObjectId) -> Option<CalculatedCharacteristics> {
        let object = self.object(id)?;
        if object.zone == Zone::Battlefield && self.is_phased_out(id) {
            return None;
        }
        let mut chars =
            self.calculated_characteristics(id)
                .unwrap_or_else(|| CalculatedCharacteristics {
                    copy_values: None,
                    alternate_name: object.split_other_half_name().map(str::to_string),
                    name: object.name.clone(),
                    mana_cost: object.mana_cost_owned(),
                    linked_face_mana_value: object.linked_face_mana_value(),
                    compiled_card_text: object.compiled_card_text.clone(),
                    ability_labels: object.ability_labels.clone(),
                    base_power: object.base_power.as_ref().map(|value| value.base_value()),
                    base_toughness: object
                        .base_toughness
                        .as_ref()
                        .map(|value| value.base_value()),
                    power: object.power(),
                    toughness: object.toughness(),
                    card_types: object.zone_card_types().to_vec().into(),
                    subtypes: object.zone_subtypes().to_vec().into(),
                    supertypes: object.zone_supertypes().to_vec().into(),
                    world_supertype_since: object
                        .supertypes
                        .contains(&crate::types::Supertype::World)
                        .then_some(0),
                    colors: object.colors(),
                    loyalty: object.base_loyalty,
                    defense: object.base_defense,
                    abilities: object.abilities.clone().into(),
                    static_abilities: object
                        .abilities
                        .iter()
                        .filter_map(|ability| match &ability.kind {
                            AbilityKind::Static(static_ability) => Some(static_ability.clone()),
                            _ => None,
                        })
                        .chain(object.level_granted_abilities().iter().cloned())
                        .chain(
                            object
                                .temporary_static_ability_grants
                                .iter()
                                .filter(|grant| !grant.is_expired(self.turn.turn_number))
                                .filter_map(|grant| grant.materialize()),
                        )
                        .collect::<Vec<_>>()
                        .into(),
                    numeric_range_error: None,
                    numeric_choice_error: None,
                    text_change_error: None,
                    spell_effect: Arc::new(crate::snapshot::SpellProgramState::from_option(
                        object.spell_effect_owned(),
                    )),
                    text_changes: Vec::new(),
                    ability_gain_prohibitions: Vec::new(),
                    aura_attach_filter: object.aura_attach_filter_owned(),
                    controller: self.controller_of(object),
                });

        if chars.validate_numeric_range().is_err() {
            return None;
        }
        self.normalize_current_characteristic_subtypes(object, &mut chars);

        Some(chars)
    }

    fn normalize_current_characteristic_subtypes(
        &self,
        object: &Object,
        chars: &mut CalculatedCharacteristics,
    ) {
        let has_changeling = chars
            .static_abilities
            .iter()
            .any(|ability| ability.id() == crate::static_abilities::StaticAbilityId::Changeling);
        let can_have_creature_subtypes = chars.card_types.iter().any(|card_type| {
            matches!(
                card_type,
                crate::types::CardType::Creature | crate::types::CardType::Kindred
            )
        });
        if object.zone != crate::zone::Zone::Battlefield
            && has_changeling
            && can_have_creature_subtypes
        {
            for subtype in &self.subtypes_in_family(crate::types::SubtypeFamily::Creature) {
                if !chars.subtypes.contains(subtype) {
                    chars.subtypes.push(*subtype);
                }
            }
        }
    }

    /// Missing/phased objects remain absence; unresolved computation is an
    /// error and cannot reintroduce printed abilities through a fallback.
    pub fn try_current_characteristics(
        &self,
        id: ObjectId,
    ) -> Result<
        Option<CalculatedCharacteristics>,
        crate::static_ability_processor::StaticEffectDiscoveryError,
    > {
        let Some(object) = self.object(id) else {
            return Ok(None);
        };
        if let Some(chars) = self.characteristicless_face_down_characteristics(id) {
            return Ok(Some(chars));
        }
        if object.zone == Zone::Battlefield && self.is_phased_out(id) {
            return Ok(None);
        }
        if let Some(mut chars) = crate::continuous::in_progress_characteristics(self, id) {
            chars.validate_numeric_range()?;
            self.normalize_current_characteristic_subtypes(object, &mut chars);
            return Ok(Some(chars));
        }
        let effects = self.try_all_continuous_effects_arc()?;
        // Checked discovery establishes that the shared cache describes this
        // exact revision. Consumers such as replacement discovery inspect all
        // zones repeatedly during payment simulation; recalculating each object
        // separately discards the layer batch already prepared for this state.
        let revision = self.effect_store.continuous_effects.revision();
        if self.continuous_state_is_clean()
            && self
                .runtime_cache
                .static_effects_cache
                .borrow()
                .has_checked_snapshot(revision)
        {
            let mut chars = self.calculated_characteristics_arc(id)
                .ok_or(crate::static_ability_processor::StaticEffectDiscoveryError::UnavailableCharacteristics { object: id })?
                .as_ref().clone();
            chars.validate_numeric_range()?;
            self.normalize_current_characteristic_subtypes(object, &mut chars);
            return Ok(Some(chars));
        }
        self.try_current_characteristics_with_effects(id, &effects)
    }

    /// Resolve an immutable group using one complete checked effects snapshot.
    /// Dirty states cannot publish revision-keyed cache entries, but discovery
    /// still need only run once while this shared borrow prevents mutations.
    pub(crate) fn try_current_characteristics_batch(
        &self,
        ids: &[ObjectId],
    ) -> Result<
        HashMap<ObjectId, CalculatedCharacteristics>,
        crate::static_ability_processor::StaticEffectDiscoveryError,
    > {
        let effects = self.try_all_continuous_effects_arc()?;
        let revision = self.effect_store.continuous_effects.revision();
        if self.continuous_state_is_clean()
            && self
                .runtime_cache
                .static_effects_cache
                .borrow()
                .has_checked_snapshot(revision)
        {
            self.prewarm_calculated_characteristics(ids);
            return ids
                .iter()
                .filter_map(|id| match self.try_current_characteristics(*id) {
                    Ok(Some(chars)) => Some(Ok((*id, chars))),
                    Ok(None) => None,
                    Err(error) => Some(Err(error)),
                })
                .collect();
        }
        let present: Vec<_> = ids
            .iter()
            .copied()
            .filter(|id| {
                self.object(*id).is_some_and(|object| {
                    object.zone != Zone::Battlefield || !self.is_phased_out(*id)
                })
            })
            .collect();
        let mut calculated = self.calculated_characteristics_batch_with_effects(&present, &effects);
        for id in present {
            let chars = calculated.get_mut(&id).ok_or(
                crate::static_ability_processor::StaticEffectDiscoveryError::UnavailableCharacteristics { object: id })?;
            chars.validate_numeric_range()?;
            self.normalize_current_characteristic_subtypes(
                self.object(id).expect("immutable existing object"),
                chars,
            );
        }
        Ok(calculated)
    }

    pub(crate) fn try_current_characteristics_with_effects(
        &self,
        id: ObjectId,
        effects: &[ContinuousEffect],
    ) -> Result<
        Option<CalculatedCharacteristics>,
        crate::static_ability_processor::StaticEffectDiscoveryError,
    > {
        let Some(object) = self.object(id) else {
            return Ok(None);
        };
        if let Some(chars) = self.characteristicless_face_down_characteristics(id) {
            return Ok(Some(chars));
        }
        if object.zone == Zone::Battlefield && self.is_phased_out(id) {
            return Ok(None);
        }
        let mut chars = self.calculated_characteristics_with_effects(id, effects)
            .ok_or(crate::static_ability_processor::StaticEffectDiscoveryError::UnavailableCharacteristics { object: id })?;
        chars.validate_numeric_range()?;
        self.normalize_current_characteristic_subtypes(object, &mut chars);
        Ok(Some(chars))
    }

    /// Return the object's current name in its zone.
    pub fn current_name(&self, id: ObjectId) -> Option<String> {
        Some(self.current_characteristics(id)?.name.to_owned_string())
    }

    /// Return the object's current controller in its zone.
    pub fn current_controller(&self, id: ObjectId) -> Option<PlayerId> {
        self.current_controller_excluding_change_effect(id, None)
    }

    pub(crate) fn current_controller_excluding_change_effect(
        &self,
        id: ObjectId,
        skipped_effect: Option<ContinuousEffectId>,
    ) -> Option<PlayerId> {
        let Some(object) = self.object(id) else {
            // An ability on the stack is controlled by the player who put it
            // there (CR 113.8), whatever now controls its source.
            return self.stack_ability_entry(id).map(|entry| entry.controller);
        };
        if self.is_face_up_planar_object(id) {
            return if self.grand_melee().is_some() {
                self.planar_controller_of_face(id)
            } else {
                self.planar_controller()
            };
        }
        if self.is_vanguard_card(id) {
            return Some(object.owner);
        }
        if self.is_face_up_scheme(id) {
            return Some(object.owner);
        }
        if self.is_conspiracy_card(id) {
            return Some(object.owner);
        }
        // A nested layer query must use its enclosing view without publishing
        // that partial controller into the game-level resolved cache.
        if skipped_effect.is_none()
            && let Some(chars) = crate::continuous::in_progress_characteristics(self, id)
        {
            return Some(chars.controller);
        }
        if skipped_effect.is_none()
            && self.continuous_state_is_clean()
            && let Some(controller) = self.cached_current_controller(id, object)
        {
            return Some(controller);
        }

        // Most dirty queries have no control-changing effects. Inspect borrowed
        // effects before allocating and cloning the complete registered set.
        if !self.continuous_state_is_clean()
            && !self.effect_store.continuous_effects.effects().iter().any(|effect|
                skipped_effect != Some(effect.id) && matches!(effect.modification,
                    Modification::ChangeController(_) | Modification::ChangeControllerToEffectController))
        {
            return Some(object.initial_controller);
        }
        let effects = self.effects_for_controller_query();
        self.controller_from_known_effects(id, object, &effects, skipped_effect)
    }

    fn cached_current_controller(&self, id: ObjectId, object: &Object) -> Option<PlayerId> {
        {
            let needs_rebuild = self
                .runtime_cache
                .controller_cache
                .borrow()
                .as_ref()
                .is_none_or(|cache| !cache.matches_state(self));
            if needs_rebuild {
                let change_effects = Arc::new(self.cached_effects_for_controller_query());
                *self.runtime_cache.controller_cache.borrow_mut() = Some(ControllerCache {
                    context_revision: self.continuous_context_revision(),
                    revision: self.effect_store.continuous_effects.revision(),
                    turn_number: self.turn.turn_number,
                    active_player: self.turn.active_player,
                    phase: self.turn.phase,
                    step: self.turn.step,
                    change_effects,
                    resolved: RefCell::new(Default::default()),
                });
            }
        }

        if let Some(controller) = self
            .runtime_cache
            .controller_cache
            .borrow()
            .as_ref()
            .and_then(|cache| cache.resolved.borrow().get(&id).copied())
        {
            return Some(controller);
        }

        let change_effects = {
            let cache = self.runtime_cache.controller_cache.borrow();
            Arc::clone(&cache.as_ref()?.change_effects)
        };
        let controller = self.controller_from_known_effects(id, object, &change_effects, None)?;
        if let Some(cache) = self.runtime_cache.controller_cache.borrow().as_ref() {
            cache.resolved.borrow_mut().insert(id, controller);
        }
        Some(controller)
    }

    fn cached_effects_for_controller_query(&self) -> Vec<ContinuousEffect> {
        // Control predicates can inspect copy/type/ability facts. Retain the
        // full known snapshot rather than querying discovery from a filter.
        self.cached_continuous_effects_snapshot_arc()
            .iter()
            .cloned()
            .collect()
    }

    fn effects_for_controller_query(&self) -> Vec<ContinuousEffect> {
        if self.continuous_state_is_clean() {
            self.cached_effects_for_controller_query()
        } else {
            self.effect_store
                .continuous_effects
                .effects_sorted()
                .into_iter()
                .cloned()
                .collect()
        }
    }

    fn controller_from_known_effects(
        &self,
        id: ObjectId,
        object: &Object,
        effects: &[ContinuousEffect],
        skipped_effect: Option<ContinuousEffectId>,
    ) -> Option<PlayerId> {
        let _tap_reads = self.derived_tap_read_scope();
        if !effects.iter().any(|effect| {
            skipped_effect != Some(effect.id)
                && matches!(
                    effect.modification,
                    Modification::ChangeController(_)
                        | Modification::ChangeControllerToEffectController
                )
        }) {
            return Some(object.initial_controller);
        }
        let query_effects: std::borrow::Cow<'_, [ContinuousEffect]> = match skipped_effect {
            Some(skipped) => std::borrow::Cow::Owned(
                effects
                    .iter()
                    .filter(|effect| effect.id != skipped)
                    .cloned()
                    .collect(),
            ),
            None => std::borrow::Cow::Borrowed(effects),
        };
        // Duration checks that omit one control effect need an independent
        // layer frame, not the enclosing frame that includes that effect.
        let isolated;
        let query_game = if skipped_effect.is_some() {
            isolated = self.clone();
            &isolated
        } else {
            self
        };
        crate::continuous::calculate_characteristics_with_effects(
            id,
            query_game.objects_map(),
            &query_effects,
            &query_game.battlefield,
            query_game.commander_objects(),
            query_game,
        )
        .map(|chars| chars.controller)
    }

    /// Return the object's current controller, falling back to its owner if the
    /// object cannot be evaluated through continuous effects.
    pub fn controller_of(&self, object: &Object) -> PlayerId {
        self.current_controller(object.id).unwrap_or(object.owner)
    }

    /// Return the object's current controller by object id.
    pub fn controller_of_id(&self, id: ObjectId) -> Option<PlayerId> {
        let Some(object) = self.object(id) else {
            return self.stack_ability_entry(id).map(|entry| entry.controller);
        };
        Some(self.controller_of(object))
    }

    /// Commit a controller change only after complete discovery succeeds.
    /// The original game is preserved on both preflight and post-change errors.
    pub fn set_current_controller(
        &mut self,
        id: ObjectId,
        controller: PlayerId,
    ) -> Result<(), crate::static_ability_processor::StaticEffectDiscoveryError> {
        if self.object(id).is_none() {
            return Ok(());
        }
        let mut working = self.continuous_query_snapshot()?;
        if working.current_controller(id) == Some(controller) {
            return Ok(());
        }
        if let Some(old) = working.current_controller(id)
            && !working.control_acquisition_allowed(id, old, controller) { return Ok(()); }
        working.stage_controller_change_for_assembly(id, controller);
        working.refresh_continuous_state()?;
        *self = working;
        Ok(())
    }

    /// Assign an authored initial controller below control-layer effects.
    /// Assembly callers must validate their complete isolated proposal before
    /// publishing it. This changes neither ownership nor effect chronology.
    pub fn stage_initial_controller_for_assembly(&mut self, id: ObjectId, controller: PlayerId) {
        let Some(object) = self.object_mut(id) else {
            return;
        };
        object.initial_controller = controller;
        let on_battlefield = object.zone == Zone::Battlefield;
        // CR 508.4: an entry controller is not a later control change, so
        // the control-transition baseline starts with it.
        if on_battlefield {
            self.battlefield_flags_mut()
                .controller_at_last_refresh
                .insert(id, controller);
        }
    }

    /// Stage an ordinary control-changing effect while assembling an isolated
    /// proposal. The caller must validate the complete proposal before publishing
    /// it. This is not an initial/default controller assignment.
    pub fn stage_controller_change_for_assembly(&mut self, id: ObjectId, controller: PlayerId) {
        if self.object(id).is_none() || self.current_controller(id) == Some(controller) {
            return;
        }
        if let Some(old) = self.current_controller(id)
            && !self.control_acquisition_allowed(id, old, controller) { return; }
        self.set_summoning_sick(id);
        let effect = ContinuousEffect::new(
            id,
            controller,
            EffectTarget::Specific(id),
            Modification::ChangeController(controller),
        )
        .until(Until::Forever);
        self.effect_store.continuous_effects.add_effect(effect);
        self.mark_continuous_state_dirty();
    }

    /// Return the object's current card types in its zone.
    pub fn current_card_types(&self, id: ObjectId) -> Option<Vec<crate::types::CardType>> {
        Some(self.current_characteristics(id)?.card_types.to_vec())
    }

    /// Return the object's current subtypes in its zone.
    pub fn current_subtypes(&self, id: ObjectId) -> Option<Vec<crate::types::Subtype>> {
        Some(self.current_characteristics(id)?.subtypes.to_vec())
    }

    /// Return the object's current supertypes in its zone.
    pub fn current_supertypes(&self, id: ObjectId) -> Option<Vec<crate::types::Supertype>> {
        Some(self.current_characteristics(id)?.supertypes.to_vec())
    }

    /// Return the object's current colors in its zone.
    pub fn current_colors(&self, id: ObjectId) -> Option<crate::color::ColorSet> {
        Some(self.current_characteristics(id)?.colors)
    }

    /// Return the object's current power in its zone, if any.
    pub fn current_power(&self, id: ObjectId) -> Option<i32> {
        self.current_characteristics(id)?.power
    }

    /// Return the object's current toughness in its zone, if any.
    pub fn current_toughness(&self, id: ObjectId) -> Option<i32> {
        self.current_characteristics(id)?.toughness
    }

    /// Return the abilities an object currently has in its zone.
    pub fn current_abilities(&self, id: ObjectId) -> Option<Vec<Ability>> {
        Some(self.current_characteristics(id)?.abilities.to_vec())
    }

    /// Return a specific current ability by index.
    pub fn current_ability(&self, id: ObjectId, ability_index: usize) -> Option<Ability> {
        self.current_abilities(id)?.get(ability_index).cloned()
    }

    /// Return a specific current activated ability by index.
    pub fn current_activated_ability(
        &self,
        id: ObjectId,
        ability_index: usize,
    ) -> Option<ActivatedAbility> {
        let ability = self.current_ability(id, ability_index)?;
        match ability.kind {
            AbilityKind::Activated(activated) => Some(activated),
            _ => None,
        }
    }

    /// Check if an object has a specific static ability using precomputed effects.
    pub fn object_has_ability_with_effects(
        &self,
        id: ObjectId,
        ability: &StaticAbility,
        effects: &[ContinuousEffect],
    ) -> bool {
        self.calculated_characteristics_with_effects(id, effects)
            .map(|c| c.static_abilities.contains(ability))
            .unwrap_or(false)
    }

    /// Check if an object has a specific card type using precomputed effects.
    pub fn object_has_card_type_with_effects(
        &self,
        id: ObjectId,
        card_type: crate::types::CardType,
        effects: &[ContinuousEffect],
    ) -> bool {
        self.calculated_characteristics_with_effects(id, effects)
            .map(|c| c.card_types.contains(&card_type))
            .unwrap_or(false)
    }

    /// Get calculated subtypes using precomputed effects.
    pub fn calculated_subtypes_with_effects(
        &self,
        id: ObjectId,
        effects: &[ContinuousEffect],
    ) -> Vec<crate::types::Subtype> {
        self.calculated_characteristics_with_effects(id, effects)
            .map(|c| c.subtypes.to_vec())
            .unwrap_or_default()
    }

    /// Get calculated toughness using precomputed effects.
    pub fn calculated_toughness_with_effects(
        &self,
        id: ObjectId,
        effects: &[ContinuousEffect],
    ) -> Option<i32> {
        self.calculated_characteristics_with_effects(id, effects)
            .and_then(|c| c.toughness)
    }

    /// Get the calculated power of a creature (with continuous effects applied).
    pub fn calculated_power(&self, id: ObjectId) -> Option<i32> {
        self.calculated_characteristics(id).and_then(|c| c.power)
    }

    /// Get the calculated toughness of a creature (with continuous effects applied).
    pub fn calculated_toughness(&self, id: ObjectId) -> Option<i32> {
        self.calculated_characteristics(id)
            .and_then(|c| c.toughness)
    }

    /// Check if an object has a specific static ability (with continuous effects applied).
    pub fn object_has_ability(&self, id: ObjectId, ability: &StaticAbility) -> bool {
        self.calculated_characteristics(id)
            .map(|c| c.static_abilities.contains(ability))
            .unwrap_or(false)
    }

    /// Whether an object's printed abilities include a static ability id.
    ///
    /// Unlike [`Self::current_has_static_ability_id`] this never asks for
    /// calculated characteristics, so it is safe on hot paths that run for
    /// every object.
    pub(crate) fn object_printed_static_ability(
        &self,
        id: ObjectId,
        ability_id: crate::static_abilities::StaticAbilityId,
    ) -> bool {
        self.object(id).is_some_and(|object| {
            object.abilities.iter().any(|ability| {
                matches!(&ability.kind, crate::ability::AbilityKind::Static(static_ability)
                    if static_ability.id() == ability_id)
            })
        })
    }

    /// Check if an object has a static ability with the given ID.
    pub fn object_has_static_ability_id(
        &self,
        id: ObjectId,
        ability_id: crate::static_abilities::StaticAbilityId,
    ) -> bool {
        self.current_has_static_ability_id(id, ability_id)
    }

    /// Check if an object currently has a static ability with the given ID.
    /// Whether a battlefield static ("You may activate abilities of creatures
    /// you control as though those creatures had haste") lets this object's
    /// {T}/{Q} abilities ignore summoning sickness.
    pub fn activates_abilities_as_though_haste(&self, id: ObjectId) -> bool {
        let Some(object) = self.object(id) else {
            return false;
        };
        for perm_id in self.battlefield.iter().copied() {
            let Some(perm) = self.object(perm_id) else {
                continue;
            };
            let controller = self.controller_of(perm);
            let filter_ctx = self.filter_context_for(controller, Some(perm_id));
            let matches_grant = |ability: &crate::static_abilities::StaticAbility| {
                ability.is_active(self, perm_id)
                    && ability
                        .activate_abilities_as_though_haste()
                        .is_some_and(|grant| grant.filter.matches(object, &filter_ctx, self))
            };
            let granted = if let Some(chars) = self.calculated_characteristics(perm_id) {
                chars
                    .static_abilities
                    .iter()
                    .any(|ability| matches_grant(ability))
            } else {
                perm.abilities.iter().any(|ability| {
                    matches!(&ability.kind, crate::ability::AbilityKind::Static(static_ability)
                        if ability.functions_in(&perm.zone) && matches_grant(static_ability))
                })
            };
            if granted {
                return true;
            }
        }
        false
    }

    pub fn current_has_static_ability_id(
        &self,
        id: ObjectId,
        ability_id: crate::static_abilities::StaticAbilityId,
    ) -> bool {
        // CR 702.26b: absence from the characteristic cache must not make a
        // phased-out permanent fall back to its printed abilities.
        if self.is_phased_out(id) {
            return false;
        }

        if let Some(chars) = self.calculated_characteristics(id) {
            return chars
                .static_abilities
                .iter()
                .any(|ability| ability.id() == ability_id && ability.is_active(self, id));
        }

        self.object(id).is_some_and(|object| {
            object.abilities.iter().any(|ability| {
                matches!(&ability.kind, crate::ability::AbilityKind::Static(static_ability)
                    if ability.functions_in(&object.zone)
                        && static_ability.id() == ability_id
                        && static_ability.is_active(self, id))
            }) || object
                .temporary_static_ability_grants
                .iter()
                .filter(|grant| !grant.is_expired(self.turn.turn_number))
                .filter_map(|grant| grant.materialize())
                .any(|ability| ability.id() == ability_id && ability.is_active(self, id))
        })
    }

    /// Get the calculated subtypes of an object (with continuous effects applied).
    pub fn calculated_subtypes(&self, id: ObjectId) -> Vec<crate::types::Subtype> {
        self.calculated_characteristics_arc(id)
            .map(|c| c.subtypes.to_vec())
            .unwrap_or_default()
    }

    /// Get the calculated card types of an object (with continuous effects applied).
    pub fn calculated_card_types(&self, id: ObjectId) -> Vec<crate::types::CardType> {
        self.calculated_characteristics_arc(id)
            .map(|c| c.card_types.to_vec())
            .unwrap_or_default()
    }

    /// Check if an object has a specific card type (with continuous effects applied).
    pub fn object_has_card_type(&self, id: ObjectId, card_type: crate::types::CardType) -> bool {
        self.current_card_types(id)
            .is_some_and(|card_types| card_types.contains(&card_type))
    }

    /// Check if an object currently has a specific card type.
    pub fn current_has_card_type(&self, id: ObjectId, card_type: crate::types::CardType) -> bool {
        self.object_has_card_type(id, card_type)
    }

    /// Check if an object currently has a specific subtype.
    pub fn current_has_subtype(&self, id: ObjectId, subtype: crate::types::Subtype) -> bool {
        self.current_subtypes(id)
            .is_some_and(|subtypes| subtypes.contains(&subtype))
    }

    /// Check if an object currently has a specific supertype.
    pub fn current_has_supertype(&self, id: ObjectId, supertype: crate::types::Supertype) -> bool {
        self.current_supertypes(id)
            .is_some_and(|supertypes| supertypes.contains(&supertype))
    }

    /// Check if an object is currently a creature.
    pub fn current_is_creature(&self, id: ObjectId) -> bool {
        self.current_has_card_type(id, crate::types::CardType::Creature)
    }

    // =========================================================================
    // "Can't" Effect Tracking (Rule 614.17)
    // =========================================================================

    /// Update the CantEffectTracker by scanning static abilities on the battlefield.
    ///
    /// Per Rule 614.17, "can't" effects are not replacement effects - they must
    /// be checked BEFORE attempting an action or event. This function scans all
    /// permanents on the battlefield and populates the tracker based on their
    /// static abilities.
    ///
    /// Call this after:
    /// - State-based actions are checked
    /// - Before processing any event that might be affected by "can't" effects
    /// - After any permanent enters or leaves the battlefield
    pub fn update_cant_effects(&mut self) {
        // Restriction sources' conditions can read tapped state.
        self.enter_derived_tap_reads();
        let prior_prohibitions = self.effect_store.cant_effects.cant_gain_control.clone();
        let prior_scan = self.effect_store.cant_effects.control_prohibitions_during_scan.replace(prior_prohibitions);
        self.update_cant_effects_inner();
        // A nested derived query must restore its caller's retained map,
        // rather than expose a partially rebuilt tracker to the outer scan.
        self.effect_store.cant_effects.control_prohibitions_during_scan = prior_scan;
        self.exit_derived_tap_reads();
    }

    fn update_cant_effects_inner(&mut self) {
        use crate::ability::AbilityKind;
        use crate::static_abilities::StaticAbility;

        self.expire_condition_ended_prevention_shields();

        // A duration ends permanently at its first false transition.
        let expired: std::collections::HashSet<usize> = self
            .effect_store
            .restriction_effects
            .iter()
            .enumerate()
            .filter_map(|(index, effect)| match &effect.duration {
                crate::effect::Until::ForAsLongAs(predicate)
                    if !crate::continuous::continuous_duration_predicate_matches(
                        predicate, self,
                    ) =>
                {
                    Some(index)
                }
                crate::effect::Until::OpponentsNextTurn
                    if !effect.is_pending()
                        && self.turn.turn_number > effect.expires_end_of_turn
                        && self.active_players().iter().any(|player| self.are_opponents(effect.controller, *player)) => Some(index),
                // CR 611.2a: "until <player>'s next turn" ends once, as that
                // turn begins; it must not apply again on later turns.
                duration
                    if duration.ends_at_next_turn_start()
                        && !effect.is_pending()
                        && self.turn.turn_number > effect.expires_end_of_turn
                        && self.is_active_player(duration.next_turn_owner(effect.controller)) =>
                {
                    Some(index)
                }
                _ => None,
            })
            .collect();
        let mut index = 0;
        self.effect_store.restriction_effects.retain(|_| {
            let retain = !expired.contains(&index);
            index += 1;
            retain
        });

        // Clear existing tracker
        self.effect_store.cant_effects.clear();
        self.effect_store
            .mana_spend_effects
            .retain_effect_permissions(self.turn.turn_number);
        self.battlefield_flags_mut().damage_persists.clear();
        let vanguard_hand_modifiers = self
            .vanguard
            .as_ref()
            .map(|state| state.hand_modifiers.clone())
            .unwrap_or_default();
        for player in self.players.get_mut_for_derived_update().iter_mut() {
            player.max_hand_size = 7_i32.saturating_add(
                vanguard_hand_modifiers
                    .get(&player.id)
                    .copied()
                    .unwrap_or(0),
            );
            player.land_plays_per_turn = 1;
        }

        let all_effects = if self.continuous_state_is_clean() {
            self.cached_continuous_effects_snapshot_arc()
        } else {
            Arc::new(self.all_continuous_effects())
        };
        if self.cant_effects_static_scan_can_stay_empty(all_effects.as_slice()) {
            return;
        }

        // If no continuous effect can add or remove a restriction-producing
        // static ability, only printed/temporary sources with such an ability
        // need inspection. This avoids deriving every permanent merely because
        // one source (for example Mycosynth Lattice) changes a player rule.
        let effects_can_change_cant_abilities = all_effects
            .iter()
            .any(Self::continuous_effect_requires_cant_update);
        let abilities_to_apply: Vec<(
            StaticAbility,
            ObjectId,
            PlayerId,
            Option<crate::continuous::AbilityOrigin>,
        )> = if !effects_can_change_cant_abilities {
            self.objects
                .iter()
                .flat_map(|(&object_id, object)| {
                    // CR 702.26b: phased-out sources do not supply static
                    // rule restrictions, even on the printed-only fast path.
                    if self.is_phased_out(object_id) {
                        return Vec::new();
                    }
                    let zone = object.zone;
                    let controller = self.controller_of(object);
                    let mut abilities = object
                        .abilities
                        .iter()
                        .enumerate()
                        .filter_map(|(slot, ability)| match &ability.kind {
                            AbilityKind::Static(static_ability)
                                if ability.functions_in(&zone)
                                    && Self::static_ability_requires_cant_update(
                                        static_ability,
                                    )
                                    && static_ability.is_active(self, object_id) =>
                            {
                                Some((
                                    static_ability.clone(),
                                    object_id,
                                    controller,
                                    Some(crate::continuous::AbilityOrigin::Printed(slot)),
                                ))
                            }
                            _ => None,
                        })
                        .collect::<Vec<_>>();
                    if zone == Zone::Battlefield {
                        abilities.extend(
                            object
                                .level_granted_abilities()
                                .into_iter()
                                .filter(|static_ability| {
                                    Self::static_ability_requires_cant_update(static_ability)
                                        && static_ability.is_active(self, object_id)
                                })
                                .map(|static_ability| {
                                    (static_ability, object_id, controller, None)
                                }),
                        );
                        abilities.extend(
                            object
                                .temporary_static_ability_grants
                                .iter()
                                .filter(|grant| !grant.is_expired(self.turn.turn_number))
                                .filter_map(|grant| grant.materialize())
                                .filter(|static_ability| {
                                    Self::static_ability_requires_cant_update(static_ability)
                                        && static_ability.is_active(self, object_id)
                                })
                                .map(|static_ability| {
                                    (static_ability, object_id, controller, None)
                                }),
                        );
                    }
                    abilities
                })
                .collect()
        } else {
            // Ability-changing effects require the fully layered view so
            // grants and removals are reflected in restriction tracking.
            let battlefield_ids: Vec<_> = self
                .objects
                .iter()
                .filter_map(|(&object_id, object)| {
                    (object.zone == Zone::Battlefield).then_some(object_id)
                })
                .collect();
            // A dirty state has no characteristics cache to consult, so derive
            // every recipient in one layer pass: one dependency sort for the
            // whole battlefield instead of one per permanent.
            let mut dirty_batch = if self.continuous_state_is_clean() {
                self.prewarm_calculated_characteristics(&battlefield_ids);
                None
            } else {
                Some(self.calculated_characteristics_batch_with_effects(
                    &battlefield_ids,
                    all_effects.as_slice(),
                ))
            };
            self.objects
                .iter()
                .flat_map(|(&object_id, object)| {
                    // CR 702.26b: phased-out sources do not supply static
                    // rule restrictions, even on the printed-only fast path.
                    if self.is_phased_out(object_id) {
                        return Vec::new();
                    }
                    let zone = object.zone;
                    let controller = self.controller_of(object);
                    match zone {
                        Zone::Battlefield => match dirty_batch.as_mut() {
                            None => self.calculated_characteristics_arc(object_id),
                            Some(batch) => batch.remove(&object_id).map(Arc::new),
                        }
                        .map(|chars| {
                            chars
                                .abilities
                                .iter()
                                .enumerate()
                                .filter_map(|(slot, ability)| {
                                    let AbilityKind::Static(static_ability) = &ability.kind else {
                                        return None;
                                    };
                                    (ability.functions_in(&zone)
                                        && static_ability.is_active(self, object_id))
                                    .then(|| {
                                        (
                                            static_ability.clone(),
                                            object_id,
                                            controller,
                                            chars.abilities.origin(slot).cloned(),
                                        )
                                    })
                                })
                                .collect::<Vec<_>>()
                        })
                        .unwrap_or_default(),
                        _ => object
                            .abilities
                            .iter()
                            .enumerate()
                            .filter_map(|(slot, ability)| {
                                if let AbilityKind::Static(static_ability) = &ability.kind {
                                    if ability.functions_in(&zone)
                                        && static_ability.is_active(self, object_id)
                                    {
                                        Some((
                                            static_ability.clone(),
                                            object_id,
                                            controller,
                                            Some(crate::continuous::AbilityOrigin::Printed(slot)),
                                        ))
                                    } else {
                                        None
                                    }
                                } else {
                                    None
                                }
                            })
                            .collect::<Vec<_>>(),
                    }
                })
                .collect()
        };

        // Now apply each ability's restrictions using the trait method.
        // Maximum-hand-size modifications are rule changes applied in
        // timestamp order (CR 613.11, 402.2) together with the spell-created
        // "no maximum hand size" effects below, so defer them.
        let mut hand_size_modifications: Vec<(u64, HandSizeModification)> = Vec::new();
        for (static_ability, permanent_id, controller, origin) in abilities_to_apply {
            if Self::static_ability_modifies_maximum_hand_size(&static_ability) {
                let timestamp = self
                    .effect_store
                    .continuous_effects
                    .get_object_timestamp(permanent_id)
                    .unwrap_or(0);
                hand_size_modifications.push((
                    timestamp,
                    HandSizeModification::Static(static_ability, permanent_id, controller),
                ));
                continue;
            }
            static_ability.apply_restrictions(self, permanent_id, controller);
            if let Some(pair) = crate::source_numbers::static_pair(&static_ability) {
                let owner =
                    crate::source_numbers::capture(permanent_id, Some(pair), origin.as_ref());
                if owner.is_none() {
                    self.record_token_resource_failure(
                        &crate::effects::ExecutionError::IncompleteEvidence(
                            "numeric cast restriction has no exact acquisition origin".into(),
                        ),
                    );
                }
                for restrictions in self
                    .effect_store
                    .cant_effects
                    .cant_cast_filters
                    .values_mut()
                {
                    for restriction in restrictions {
                        if restriction.source == Some(permanent_id)
                            && restriction.source_number_owner.is_none()
                            && crate::source_numbers::filter_pair(&restriction.filter) == Some(pair)
                        {
                            restriction.source_number_owner = owner.clone();
                        }
                    }
                }
            }
        }

        // Apply active restriction effects from spells/abilities.
        let current_turn = self.turn.turn_number;
        let mut retained_restrictions = Vec::new();
        let mut active_restrictions = Vec::new();
        for effect in &self.effect_store.restriction_effects {
            if effect.is_active(self, current_turn) {
                retained_restrictions.push(effect.clone());
                active_restrictions.push(effect.clone());
            } else if effect.is_pending()
                || (matches!(
                    effect.duration,
                    crate::effect::Until::ControllersNextUntapStep | crate::effect::Until::YourNextUntapStep
                        | crate::effect::Until::PlayersNextUntapStep { .. }
                ) && !effect.is_expired(current_turn)
                    && effect.untap_step_player(self).is_some())
            {
                retained_restrictions.push(effect.clone());
            }
        }
        self.effect_store.restriction_effects = retained_restrictions;

        let mut active_goad = Vec::new();
        for effect in &self.effect_store.goad_effects {
            if effect.is_active(self, current_turn) {
                active_goad.push(effect.clone());
            }
        }
        self.effect_store.goad_effects = active_goad;

        let mut restriction_tracker = CantEffectTracker::default();
        for effect in active_restrictions {
            if matches!(
                effect.restriction,
                crate::effect::Restriction::NoMaximumHandSize(_)
                    | crate::effect::Restriction::ReduceMaximumHandSize(_, _)
            ) {
                hand_size_modifications
                    .push((effect.timestamp, HandSizeModification::Restriction(effect)));
                continue;
            }
            effect.restriction.apply_with_tagged_objects(
                self,
                &mut restriction_tracker,
                effect.controller,
                Some(effect.source),
                effect.iterated_player,
                &effect.tagged_objects,
            );
        }
        hand_size_modifications.sort_by_key(|(timestamp, _)| *timestamp);
        for (_, modification) in hand_size_modifications {
            match modification {
                HandSizeModification::Static(static_ability, permanent_id, controller) => {
                    static_ability.apply_restrictions(self, permanent_id, controller);
                }
                HandSizeModification::Restriction(effect) => {
                    effect.restriction.apply_with_tagged_objects(
                        self,
                        &mut restriction_tracker,
                        effect.controller,
                        Some(effect.source),
                        effect.iterated_player,
                        &effect.tagged_objects,
                    );
                }
            }
        }
        self.effect_store.cant_effects.merge(restriction_tracker);

        // "Can't be regenerated" restrictions disable both new and existing shields.
        let cant_be_regenerated: Vec<_> = self
            .effect_store
            .cant_effects
            .cant_be_regenerated
            .iter()
            .copied()
            .collect();
        for object_id in cant_be_regenerated {
            self.effect_store
                .replacement_effects
                .remove_regeneration_shields_from_source(object_id);
            self.clear_regeneration_shields(object_id);
        }
    }

    fn static_ability_modifies_maximum_hand_size(static_ability: &StaticAbility) -> bool {
        use crate::static_abilities::StaticAbilityId;
        matches!(
            static_ability.id(),
            StaticAbilityId::NoMaximumHandSize
                | StaticAbilityId::SetMaximumHandSize
                | StaticAbilityId::ReduceMaximumHandSize
                | StaticAbilityId::IncreaseMaximumHandSize
                | StaticAbilityId::MaximumHandSizeSevenMinusYourGraveyardCardTypes
        )
    }

    fn cant_effects_static_scan_can_stay_empty(&self, all_effects: &[ContinuousEffect]) -> bool {
        use crate::ability::AbilityKind;

        if !self.effect_store.restriction_effects.is_empty()
            || !self.effect_store.goad_effects.is_empty()
        {
            return false;
        }

        if all_effects
            .iter()
            .any(Self::continuous_effect_requires_cant_update)
        {
            return false;
        }

        self.objects.values().all(|object| {
            let printed_abilities_are_irrelevant = object.abilities.iter().all(|ability| {
                if !ability.functions_in(&object.zone) {
                    return true;
                }
                match &ability.kind {
                    AbilityKind::Static(static_ability) => {
                        !Self::static_ability_requires_cant_update(static_ability)
                    }
                    _ => true,
                }
            });
            if !printed_abilities_are_irrelevant || object.zone != Zone::Battlefield {
                return printed_abilities_are_irrelevant;
            }

            let level_abilities_are_irrelevant = object
                .level_granted_abilities()
                .iter()
                .all(|ability| !Self::static_ability_requires_cant_update(ability));
            let temporary_abilities_are_irrelevant = object
                .temporary_static_ability_grants
                .iter()
                .filter(|grant| !grant.is_expired(self.turn.turn_number))
                .filter_map(|grant| grant.materialize())
                .all(|ability| !Self::static_ability_requires_cant_update(&ability));

            level_abilities_are_irrelevant && temporary_abilities_are_irrelevant
        })
    }

    fn continuous_effect_requires_cant_update(effect: &ContinuousEffect) -> bool {
        Self::modification_requires_cant_update(&effect.modification)
    }

    fn modification_requires_cant_update(modification: &Modification) -> bool {
        // Exhaustive on purpose: answering `false` for a variant that can add
        // or remove cant-relevant static abilities silently skips restriction
        // tracking (e.g. an aura's "doesn't untap" never taking effect).
        match modification {
            Modification::CopyOf { .. } | Modification::MergeComponent { .. }
            | Modification::ChangeText { .. }
        | Modification::RewriteText(_)
            // A fragment subset selects a complete precompiled rules graph.
            // It can add or remove the abilities this fast path scans for.
            | Modification::RemoveOptionalTextFragments(_)
            | Modification::SetTextBox(_)
            | Modification::CopyStaticAbilityVariants { .. }
            // Restriction modifications materialize as cant-relevant static
            // abilities in calculated characteristics.
            | Modification::Restriction(_)
            // Removals can strip cant-relevant statics granted by other
            // effects; rerun the scan rather than reason about ordering.
            | Modification::RemoveAbility(_)
            | Modification::RemoveStaticAbilityFamily(_)
            | Modification::RemoveAbilityGeneric { .. }
            | Modification::RemoveAllAbilities
        | Modification::RemoveLandRulesTextAbilities
            | Modification::RemoveAllAbilitiesExceptMana => true,
            Modification::AddAbility(static_ability) => {
                Self::static_ability_requires_cant_update(static_ability)
            }
            Modification::AddAbilityGeneric(ability) => Self::ability_requires_cant_update(ability),
            // Replacing the ability list can remove a printed restriction even
            // when none of the replacement abilities creates one.
            Modification::SetAbilities(_) => true,
            // Activated/triggered ability additions and pure characteristic
            // changes cannot introduce cant-relevant statics.
            Modification::CopyActivatedAbilities { .. }
            | Modification::CopyTriggeredAbilities { .. }
            | Modification::AddCombatDamageDrawAbility
            | Modification::ChangeController(_) | Modification::ChangeControllerToEffectController
            | Modification::SetName(_) | Modification::InsertNameWords { .. }
            | Modification::AddCardTypes(_)
            | Modification::RemoveCardTypes(_)
            | Modification::SetCardTypes(_)
            | Modification::AddSubtypes(_)
            | Modification::AddAllSubtypesOfFamily(_)
            | Modification::RemoveSubtypes(_)
            | Modification::RemoveAllSubtypesOfFamily(_)
            | Modification::SetSubtypes(_)
            | Modification::SetAuraAttachmentFilter(_)
            | Modification::AddSupertypes(_)
            | Modification::RemoveSupertypes(_)
            | Modification::RemoveAllCreatureTypes
            | Modification::AddColors(_)
            | Modification::RemoveColors(_)
            | Modification::SetColors(_)
            | Modification::MakeColorless
            | Modification::SetPower { .. }
            | Modification::SetToughness { .. }
            | Modification::SetPowerToughness { .. }
            | Modification::ModifyPower(_)
            | Modification::ModifyToughness(_)
            | Modification::ModifyPowerToughness { .. }
            | Modification::ModifyPowerToughnessValue { .. }
            | Modification::ModifyPowerToughnessByColorCount { .. }
            | Modification::SwitchPowerToughness => false,
        }
    }

    fn ability_requires_cant_update(ability: &crate::ability::Ability) -> bool {
        match &ability.kind {
            crate::ability::AbilityKind::Static(static_ability) => {
                Self::static_ability_requires_cant_update(static_ability)
            }
            _ => false,
        }
    }

    pub(crate) fn static_ability_requires_cant_update(
        static_ability: &crate::static_abilities::StaticAbility,
    ) -> bool {
        use crate::static_abilities::StaticAbilityId;

        !matches!(
            static_ability.id(),
            StaticAbilityId::Flying
                | StaticAbilityId::FirstStrike
                | StaticAbilityId::DoubleStrike
                | StaticAbilityId::Deathtouch
                | StaticAbilityId::Flash
                | StaticAbilityId::Haste
                | StaticAbilityId::Intimidate
                | StaticAbilityId::Lifelink
                | StaticAbilityId::Menace
                // Protection legality is evaluated directly by targeting,
                // attachment, blocking, and damage paths; it does not
                // populate CantEffectTracker through apply_restrictions.
                | StaticAbilityId::Protection
                | StaticAbilityId::Reach
                | StaticAbilityId::Trample
                | StaticAbilityId::TrampleOverPlaneswalkers
                | StaticAbilityId::Vigilance
                | StaticAbilityId::Fear
                | StaticAbilityId::Skulk
                | StaticAbilityId::Prowess
                | StaticAbilityId::Flanking
                | StaticAbilityId::UmbraArmor
                | StaticAbilityId::Landwalk
                | StaticAbilityId::Shadow
                | StaticAbilityId::Horsemanship
                | StaticAbilityId::Wither
                | StaticAbilityId::Infect
                | StaticAbilityId::Changeling
                | StaticAbilityId::Partner
                | StaticAbilityId::PartnerWith
                | StaticAbilityId::Toxic
                | StaticAbilityId::DoctorsCompanion
                | StaticAbilityId::Assist
                | StaticAbilityId::ReadAhead
                | StaticAbilityId::Anthem
                | StaticAbilityId::GrantAbility
                | StaticAbilityId::GrantObjectAbilityForFilter
                | StaticAbilityId::EquipmentGrant
                | StaticAbilityId::AttachedAbilityGrant
                | StaticAbilityId::CharacteristicDefiningPT
                | StaticAbilityId::SetBasePowerToughnessForFilter
                | StaticAbilityId::AddCardTypes
                | StaticAbilityId::RemoveCardTypes
                | StaticAbilityId::SetCardTypes
                | StaticAbilityId::AddSubtypes
                | StaticAbilityId::AddAllSubtypesOfFamily
                | StaticAbilityId::SetLandSubtypes
                | StaticAbilityId::SetCreatureSubtypes
                | StaticAbilityId::AddColors
                | StaticAbilityId::SetColors
                | StaticAbilityId::SetName
                | StaticAbilityId::MakeColorless
                | StaticAbilityId::AddSupertypes
                | StaticAbilityId::RemoveSupertypes
                | StaticAbilityId::CostReduction
                | StaticAbilityId::ActivatedAbilityCostReduction
                | StaticAbilityId::ActivatedAbilityCostIncrease
                | StaticAbilityId::ThisSpellCostReduction
                | StaticAbilityId::ThisSpellCostReductionManaCost
                | StaticAbilityId::CostIncrease
                | StaticAbilityId::CostReductionManaCost
                | StaticAbilityId::CostIncreaseManaCost
                | StaticAbilityId::CostIncreasePerAdditionalTarget
                | StaticAbilityId::CostIncreaseManaCostPerAdditionalTarget
                | StaticAbilityId::Affinity
                | StaticAbilityId::AffinityForArtifacts
                | StaticAbilityId::Delve
                | StaticAbilityId::Convoke
                | StaticAbilityId::Improvise
                | StaticAbilityId::BlackManaMayBePaidWithLife
                | StaticAbilityId::MinimumSpellTotalMana
                | StaticAbilityId::SpellManaSpendingRestriction
        )
    }

    pub fn keep_damage_marked(&mut self, object: ObjectId) {
        self.battlefield_flags_mut().damage_persists.insert(object);
    }

    pub fn damage_persists_on(&self, object: ObjectId) -> bool {
        self.battlefield_flags.damage_persists.contains(&object)
    }
}

#[cfg(test)]
mod chosen_option_tests {
    use super::*;

    #[test]
    fn named_color_creature_type_option_preserves_the_pair() {
        assert_eq!(
            named_color_creature_type_option(&GameState::new(vec![], 20), "blue Camarid"),
            Some((crate::color::Color::Blue, crate::types::Subtype::Camarid))
        );
        assert_eq!(named_color_creature_type_option(&GameState::new(vec![], 20), "blue artifact"), None);
    }

    #[test]
    fn linked_play_permission_can_force_one_land_entry_tapped() {
        let mut game = GameState::new(vec!["Alice".to_string()], 20);
        let alice = crate::ids::PlayerId::from_index(0);
        let land = crate::card::CardBuilder::new(crate::ids::CardId::new(), "Exiled Land")
            .card_types(vec![crate::types::CardType::Land])
            .build();
        let exiled_id = game.create_object_from_card(&land, alice, Zone::Exile);
        let mut decisions = crate::decision::SelectFirstDecisionMaker;

        let result = game
            .move_object_with_etb_processing_with_entry_options(
                exiled_id,
                Zone::Battlefield,
                &mut decisions,
                true,
                true,
            )
            .expect("replacement operation must execute successfully in this scenario")
            .assert_completed_without_additions()
            .expect("land should enter the battlefield");

        assert!(result.enters_tapped);
        assert!(game.is_tapped(result.new_id));
    }

    #[test]
    fn zero_counter_placement_does_not_mutate_or_publish_an_event() {
        let mut game = GameState::new(vec!["Alice".to_string()], 20);
        let alice = crate::ids::PlayerId::from_index(0);
        let card = crate::card::CardBuilder::new(crate::ids::CardId::new(), "Counter recipient")
            .card_types(vec![crate::types::CardType::Creature])
            .build();
        let recipient = game.create_object_from_card(&card, alice, Zone::Battlefield);
        game.take_pending_trigger_events();
        let counter = crate::object::CounterType::PlusOnePlusOne;
        assert!(game.add_counters(recipient, counter, 0).is_none());
        assert!(
            !game
                .object(recipient)
                .unwrap()
                .counters
                .contains_key(&counter)
        );
        assert!(game.take_pending_trigger_events().is_empty());
        let event = game.add_counters(recipient, counter, 1).unwrap();
        let placed = event
            .downcast::<crate::events::CounterPlacedEvent>()
            .unwrap();
        assert_eq!(
            (placed.permanent, placed.counter_type, placed.amount),
            (recipient, counter, 1)
        );
        assert_eq!(game.counter_count(recipient, counter), 1);
    }

    fn counter_count(game: &GameState, object: ObjectId) -> u32 {
        game.object(object)
            .and_then(|object| {
                object
                    .counters
                    .get(&crate::object::CounterType::PlusOnePlusOne)
                    .copied()
            })
            .unwrap_or(0)
    }

    fn counter_retaining_definition() -> crate::cards::CardDefinition {
        let ability = crate::ability::Ability::static_ability(
            crate::static_abilities::StaticAbility::from_model(
                ironsmith_core::StaticAbility::counters_remain_across_zone_changes(
                    vec![Zone::Hand, Zone::Library],
                    "Counters remain on this creature as it moves to any zone other than a player's hand or library.",
                ),
            ),
        )
        .in_zones(vec![
            Zone::Battlefield,
            Zone::Hand,
            Zone::Library,
            Zone::Graveyard,
            Zone::Stack,
            Zone::Exile,
            Zone::Command,
            Zone::Ante,
            Zone::OutsideGame,
        ]);
        crate::cards::builders::CardDefinitionBuilder::new(
            crate::ids::CardId::new(),
            "Counter Traveler",
        )
        .card_types(vec![crate::types::CardType::Creature])
        .with_ability(ability)
        .build()
    }

    #[test]
    fn typed_counter_retention_survives_nonexcluded_zone_changes() {
        let mut game = GameState::new(vec!["Alice".to_string()], 20);
        let alice = crate::ids::PlayerId::from_index(0);
        let object = game.create_object_from_definition(
            &counter_retaining_definition(),
            alice,
            Zone::Battlefield,
        );
        game.object_mut(object)
            .expect("counter traveler should exist")
            .counters
            .insert(crate::object::CounterType::PlusOnePlusOne, 3);

        let graveyard = game
            .move_object(
                object,
                Zone::Graveyard,
                crate::events::cause::EventCause::from_game_rule(),
            )
            .expect("counter traveler should move to the graveyard");
        assert_eq!(counter_count(&game, graveyard), 3);
        let exiled = game
            .move_object(
                graveyard,
                Zone::Exile,
                crate::events::cause::EventCause::from_game_rule(),
            )
            .expect("counter traveler should move to exile");
        assert_eq!(counter_count(&game, exiled), 3);
    }

    #[test]
    fn typed_counter_retention_clears_for_excluded_destinations() {
        for destination in [Zone::Hand, Zone::Library] {
            let mut game = GameState::new(vec!["Alice".to_string()], 20);
            let alice = crate::ids::PlayerId::from_index(0);
            let object = game.create_object_from_definition(
                &counter_retaining_definition(),
                alice,
                Zone::Battlefield,
            );
            game.object_mut(object)
                .expect("counter traveler should exist")
                .counters
                .insert(crate::object::CounterType::PlusOnePlusOne, 2);

            let moved = game
                .move_object(
                    object,
                    destination,
                    crate::events::cause::EventCause::from_game_rule(),
                )
                .expect("counter traveler should move");
            assert_eq!(counter_count(&game, moved), 0, "{destination:?}");
        }
    }

    #[test]
    fn ordinary_objects_still_lose_counters_when_they_change_zones() {
        let mut game = GameState::new(vec!["Alice".to_string()], 20);
        let alice = crate::ids::PlayerId::from_index(0);
        let ordinary = crate::cards::builders::CardDefinitionBuilder::new(
            crate::ids::CardId::new(),
            "Ordinary Creature",
        )
        .card_types(vec![crate::types::CardType::Creature])
        .build();
        let object = game.create_object_from_definition(&ordinary, alice, Zone::Battlefield);
        game.object_mut(object)
            .expect("ordinary creature should exist")
            .counters
            .insert(crate::object::CounterType::PlusOnePlusOne, 2);

        let moved = game
            .move_object(
                object,
                Zone::Graveyard,
                crate::events::cause::EventCause::from_game_rule(),
            )
            .expect("ordinary creature should move");
        assert_eq!(counter_count(&game, moved), 0);
    }
}

/// The zero-time, zero-cost suspend entry `CastSourceEffect` adds for a card
/// cast via granted suspend (no printed card has "Suspend 0—{0}").
fn is_synthetic_granted_suspend(
    method: &crate::alternative_cast::AlternativeCastingMethod,
) -> bool {
    matches!(
        method,
        crate::alternative_cast::AlternativeCastingMethod::Suspend { cost, time: ironsmith_core::SuspendTime::Fixed(0) }
            if cost.is_empty()
    )
}

/// One maximum-hand-size modification awaiting timestamp-ordered application.
enum HandSizeModification {
    Static(StaticAbility, ObjectId, PlayerId),
    Restriction(super::RestrictionEffectInstance),
}

impl GameState {
    /// Snapshot of the object whose effect granted `source` its ability at
    /// `ability_index` — the Equipment in `Equipped creature has "... Return
    /// Trusty Boomerang to its owner's hand."` — captured when that ability
    /// is activated or triggers so its resolution can name the grantor under
    /// [`crate::tag::GRANTING_SOURCE_TAG`]. `None` for the object's own
    /// abilities.
    pub(crate) fn granting_source_snapshot(
        &self,
        source: ObjectId,
        ability_index: usize,
    ) -> Option<crate::snapshot::ObjectSnapshot> {
        let chars = self.current_characteristics(source)?;
        let granting = chars.abilities.origin(ability_index)?.granting_source()?;
        if granting == source {
            return None;
        }
        let object = self.object(granting)?;
        Some(
            crate::snapshot::ObjectSnapshot::from_object_with_calculated_characteristics(
                object, self,
            ),
        )
    }

    /// The tag map entry exposing [`Self::granting_source_snapshot`].
    pub(crate) fn insert_granting_source_tag(
        &self,
        source: ObjectId,
        ability_index: usize,
        tagged_objects: &mut std::collections::HashMap<
            crate::tag::TagKey,
            Vec<crate::snapshot::ObjectSnapshot>,
        >,
    ) {
        if let Some(snapshot) = self.granting_source_snapshot(source, ability_index) {
            tagged_objects.insert(
                crate::tag::TagKey::from(crate::tag::GRANTING_SOURCE_TAG),
                vec![snapshot],
            );
        }
    }
}

#[cfg(test)]
mod replacement_direct_entry_zone_cause_contract_tests {
    use crate::events::cause::{CauseFilter, CauseType, ControllerFilter, EventCause};
    use crate::ids::{CardId, PlayerId};
    use crate::replacement::{ReplacementAction, ReplacementEffect};
    use crate::target::ObjectFilter;
    use crate::types::CardType;
    use crate::zone::Zone;
    fn check(matching_cause: bool) {
        let mut game = crate::tests::test_helpers::setup_two_player_game();
        let alice = PlayerId::from_index(0);
        let bob = PlayerId::from_index(1);
        let land_definition = crate::CardDefinitionBuilder::new(CardId::new(), "Entry proposal")
            .card_types(vec![CardType::Land])
            .build();
        let source_definition =
            crate::CardDefinitionBuilder::new(CardId::new(), "Entry replacement")
                .card_types(vec![CardType::Artifact])
                .build();
        let land = game.create_object_from_definition(&land_definition, alice, Zone::Hand);
        let stable = game.object(land).unwrap().stable_id;
        let source = game.create_object_from_definition(&source_definition, bob, Zone::Battlefield);
        let filter = CauseFilter::exact(CauseType::SpecialAction)
            .with_source(ObjectFilter::specific(land))
            .with_controller(ControllerFilter::Player(alice));
        let shield = game.effect_store.replacement_effects.add_one_shot_effect(
            ReplacementEffect::with_matcher(
                source,
                bob,
                crate::events::zones::matchers::WouldChangeZoneMatcher::new(
                    ObjectFilter::specific(land),
                    Some(Zone::Hand),
                    Some(Zone::Battlefield),
                )
                .with_cause_filter(filter),
                ReplacementAction::EnterTapped,
            ),
        );
        let cause = if matching_cause {
            EventCause::from_special_action(Some(land), alice)
        } else {
            EventCause::from_cost(land, alice)
        };
        let mut dm = crate::decision::SelectFirstDecisionMaker;
        let result = game
            .move_object_with_etb_processing_with_cause_and_entry_options_and_controller(
                land,
                Zone::Battlefield,
                cause,
                &mut dm,
                Some(alice),
                false,
                true,
                None,
            );
        assert!(result.is_ok());
        let arrival = game
            .objects_in_deterministic_order()
            .into_iter()
            .find(|object| object.stable_id == stable)
            .unwrap();
        assert_eq!(arrival.zone, Zone::Battlefield);
        assert_eq!(game.controller_of(arrival), alice);
        assert_eq!(
            game.is_tapped(arrival.id),
            matching_cause,
            "zone replacement must inspect the originating entry cause"
        );
        assert_eq!(
            game.effect_store
                .replacement_effects
                .get_effect(shield)
                .is_none(),
            matching_cause,
            "only the applicable shield is consumed"
        );
    }
    #[test]
    fn direct_entry_preserves_zone_cause_source_and_controller() {
        check(true);
    }
    #[test]
    fn direct_entry_rejects_nonmatching_zone_cause() {
        check(false);
    }
}

#[cfg(test)]
mod lingering_departure_snapshot_tests {
    use crate::ability::Ability;
    use crate::cards::builders::CardDefinitionBuilder;
    use crate::game_state::GameState;
    use crate::ids::{CardId, PlayerId};
    use crate::static_abilities::StaticAbility;
    use crate::target::ObjectFilter;
    use crate::types::{CardType, Supertype};
    use crate::zone::Zone;

    #[test]
    fn simultaneous_legend_departures_retain_granted_lingering_effect_from_saved_abilities() {
        for donor_first in [true, false] {
            let mut game = GameState::new(vec!["Alice".into(), "Bob".into()], 20);
            let alice = PlayerId::from_index(0);
            let definition =
                CardDefinitionBuilder::new(CardId::new(), "Lingering departure fixture")
                    .supertypes(vec![Supertype::Legendary])
                    .card_types(vec![CardType::Creature])
                    .power_toughness(crate::card::PowerToughness::fixed(2, 2))
                    .build();
            let donor = game.create_object_from_definition(&definition, alice, Zone::Battlefield);
            let recipient =
                game.create_object_from_definition(&definition, alice, Zone::Battlefield);
            let keep = game.create_object_from_definition(&definition, alice, Zone::Battlefield);
            game.object_mut(donor).unwrap().abilities_mut().push(Ability::static_ability(
                StaticAbility::grant_ability(ObjectFilter::specific(recipient),
                    StaticAbility::static_effects_continue_until_end_of_turn_after_leaving(
                        "If this permanent leaves the battlefield, this effect continues until end of turn."))));
            game.object_mut(recipient)
                .unwrap()
                .abilities_mut()
                .push(Ability::static_ability(StaticAbility::anthem(
                    ObjectFilter::creature(),
                    2,
                    2,
                )));
            game.refresh_continuous_state()
                .expect("granted continuation completes");
            assert_eq!(
                game.current_power(keep).zip(game.current_toughness(keep)),
                Some((4, 4))
            );
            let group = if donor_first {
                vec![donor, recipient, keep]
            } else {
                vec![recipient, donor, keep]
            };
            crate::rules::state_based::apply_legend_rule_choice_from_group(&mut game, keep, &group)
                .expect("simultaneous departure batch completes");
            game.refresh_continuous_state()
                .expect("lingering effect calculation completes");
            assert_eq!(game.battlefield.to_vec(), vec![keep]);
            assert_eq!(
                game.current_power(keep).zip(game.current_toughness(keep)),
                Some((4, 4)),
                "saved pre-event abilities must survive donor loss; donor_first={donor_first}"
            );
            assert!(game.effect_store.continuous_effects.effects().iter().any(
                |effect| effect.source == recipient
                    && effect.controller == alice
                    && effect.duration == crate::effect::Until::EndOfTurn
            ));
        }
    }
}

#[cfg(test)]
mod player_removal_notification_public_contract_tests {

    use crate::effects::{
        EffectContext, EnergyCountersEffect, PayEnergyEffect, PutCountersEffect, execute_effect,
    };
    use crate::events::MarkersChangedEvent;
    use crate::object::CounterType;
    use crate::target::{ChooseSpec, PlayerFilter};
    use crate::{CardId, Effect, GameState, PlayerId, Zone};
    fn setup() -> (GameState, crate::ObjectId, PlayerId) {
        let alice = PlayerId::from_index(0);
        let mut game = GameState::new(vec!["Alice".into(), "Bob".into()], 20);
        let card = crate::cards::builders::CardDefinitionBuilder::new(
            CardId::new(),
            "Removal notification owner",
        )
        .card_types(vec![crate::types::CardType::Artifact])
        .build();
        let source = game.create_object_from_definition(&card, alice, Zone::Battlefield);
        (game, source, alice)
    }
    #[test]
    fn object_removal_event_snapshot_control() {
        let (mut game, source, alice) = setup();
        let mut ctx = EffectContext::new_default(source, alice);
        execute_effect(
            &mut game,
            &Effect::new(PutCountersEffect::new(
                CounterType::Charge,
                7,
                ChooseSpec::SpecificObject(source),
            )),
            &mut ctx,
        )
        .unwrap();
        let (removed, event) = game
            .remove_counters(source, CounterType::Charge, 3, Some(source), Some(alice))
            .unwrap();
        assert_eq!(removed, 3);
        assert_eq!(game.counter_count(source, CounterType::Charge), 4);
        let marker = event.downcast::<MarkersChangedEvent>().unwrap();
        assert_eq!(marker.amount, 3);
        assert_eq!(marker.count_after, Some(4));
    }
    #[test]
    fn player_removal_event_preserves_actual_count_at_event_time() {
        let (mut game, source, alice) = setup();
        for kind in [
            CounterType::Energy,
            CounterType::Experience,
            CounterType::Poison,
            CounterType::Rad,
            CounterType::Named("ticket".into()),
        ] {
            game.add_player_counters_with_source(alice, kind, 7, Some(source), Some(alice))
                .unwrap();
            let (removed, event) = game
                .remove_player_counters_with_source(alice, kind, 3, Some(source), Some(alice))
                .unwrap();
            assert_eq!(removed, 3);
            assert_eq!(game.player(alice).unwrap().counter_count(kind), 4);
            let marker = event.downcast::<MarkersChangedEvent>().unwrap();
            assert_eq!(marker.amount, 3);
            assert_eq!(marker.source, Some(source));
            assert_eq!(
                marker.count_after,
                Some(4),
                "known player count must be captured before subsequent events"
            );
            game.add_player_counters_with_source(alice, kind, 2, Some(source), Some(alice))
                .unwrap();
            assert_eq!(game.player(alice).unwrap().counter_count(kind), 6);
            assert_eq!(marker.count_after, Some(4));
        }
    }
    #[test]
    fn energy_payment_notification_reports_zero_remaining() {
        let (mut game, source, alice) = setup();
        let mut ctx = EffectContext::new_default(source, alice);
        execute_effect(
            &mut game,
            &Effect::new(EnergyCountersEffect::you(u32::MAX)),
            &mut ctx,
        )
        .unwrap();
        let out = execute_effect(
            &mut game,
            &Effect::new(PayEnergyEffect::new(
                u32::MAX,
                ChooseSpec::Player(PlayerFilter::You),
            )),
            &mut ctx,
        )
        .unwrap();
        assert_eq!(out.as_count(), Some(i64::from(u32::MAX)));
        assert_eq!(game.player(alice).unwrap().energy_counters, 0);
        let marker = out
            .events
            .iter()
            .find_map(|e| e.downcast::<MarkersChangedEvent>())
            .unwrap();
        assert_eq!(marker.amount, u32::MAX);
        assert_eq!(
            marker.count_after,
            Some(0),
            "actual removal outcome and notification must agree"
        );
    }
}

/// CR 205.4c: the basic land card names (including snow-covered and Wastes).
fn is_basic_land_card_name(name: &str) -> bool {
    let name = name.trim();
    let base = name.strip_prefix("Snow-Covered ").unwrap_or(name);
    matches!(base, "Plains" | "Island" | "Swamp" | "Mountain" | "Forest" | "Wastes")
}
