//! Actual Dewshaper source plus immutable producer and independent-counter controls.
#[path="custom_final_next_wave_support.rs"] mod source_support;
use ironsmith::{CardDefinition,Effect,GameState,ObjectId,PlayerId,Zone};
use ironsmith::effects::{ExecutionContext,execute_effect};
use ironsmith::decision::DecisionMaker;
use ironsmith::events::{CauseType,EventCause};
use ironsmith::object::CounterType;
const A:PlayerId=PlayerId(0); const B:PlayerId=PlayerId(1);
fn definitions()->[CardDefinition;2]{
 let fixture:serde_json::Value=serde_json::from_str(include_str!("../../../fixtures/custom_mechanics/msem-final-owner-complete-inventory.json")).unwrap();
 let card=fixture["mechanics"].as_array().unwrap().iter().flat_map(|row|row["representative_cards"].as_array().unwrap()).find(|card|card["source_card_key"]=="Dewshaper Matriarch_TPW").unwrap();
 assert!(card["original_text"].as_str().unwrap().contains("other than a siphon ability"));
 source_support::definitions(card).unwrap()
}
#[derive(Default)] struct Allocations { counts:std::collections::VecDeque<u32>, asked:Vec<PlayerId> }
impl DecisionMaker for Allocations{
 fn decide_number(&mut self,_:&GameState,c:&ironsmith::decisions::context::NumberContext)->u32{
  self.asked.push(c.player);let n=self.counts.pop_front().expect("unexpected repeated replacement decision");assert!(n>=c.min&&n<=c.max);n
 }
}
fn apply(game:&mut GameState,source:ObjectId,target:ObjectId,cause:EventCause,count:u32,dm:&mut impl DecisionMaker){
 let mut ctx=ExecutionContext::new(source,A,dm);ctx.cause=cause;
 execute_effect(game,&Effect::put_counters(CounterType::PlusOnePlusOne,count as i32,ironsmith::target::ChooseSpec::SpecificObject(target)),&mut ctx).unwrap();
}
#[test]
fn actual_dewshaper_per_counter_choices_keep_counts_original_cause_and_controller(){
 for definition in definitions(){
  for mode in ["mixed","decline","cost","opponent-effect","excluded","near-name","departed-producer"]{
   let mut game=GameState::new(vec!["A".into(),"B".into()],20);
   let source=game.create_object_from_definition(&definition,A,Zone::Battlefield);
   let body=ironsmith_compiler_runtime::compile_to_runtime_definition("Counter recipient","Type: Creature — Human\nPower/Toughness: 8/8",false).unwrap();
   let target=game.create_object_from_definition(&body,B,Zone::Battlefield);
   let producer=game.create_object_from_definition(&body,A,Zone::Battlefield);
   let mut cause=EventCause::from_effect(producer,if mode=="opponent-effect"{B}else{A});
   if mode=="cost"{cause.cause_type=CauseType::Cost;}
   if mode=="excluded"||mode=="departed-producer"{cause.resolving_ability_designations=vec!["siphon".into()];}
   if mode=="near-name"{cause.resolving_ability_designations=vec!["siphoning".into()];}
   if mode=="departed-producer"{game.move_object(producer,Zone::Hand,EventCause::effect()).unwrap();}
   let eligible=matches!(mode,"mixed"|"decline"|"near-name");
   let mut dm=Allocations{counts:if mode=="decline"{vec![0,0,0]}else if eligible{vec![1,1,0]}else{vec![]}.into(),asked:vec![]};
   apply(&mut game,source,target,cause,3,&mut dm);
   assert_eq!(game.counter_count(target,CounterType::PlusOnePlusOne),if eligible&&mode!="decline"{1}else{3},"{mode}");
   assert_eq!(game.counter_count(target,CounterType::Flying),u32::from(eligible&&mode!="decline"),"{mode}");
   assert_eq!(game.counter_count(target,CounterType::Vigilance),u32::from(eligible&&mode!="decline"),"{mode}");
   assert_eq!(game.counter_count(target,CounterType::Stun),0,"{mode}");
   assert_eq!(dm.asked,if eligible{vec![A;3]}else{vec![]},"replacement owner chooses even on opponent permanent; producer exclusions do not prompt: {mode}");
   assert!(dm.counts.is_empty());
  }
 }
}
#[test]
fn ordinary_effect_from_a_current_siphon_source_is_eligible_and_exclusion_survives_source_departure(){
 for definition in definitions(){
  let mut game=GameState::new(vec!["A".into(),"B".into()],20);
  let watcher=game.create_object_from_definition(&definition,A,Zone::Battlefield);
  let fixture:serde_json::Value=serde_json::from_str(include_str!("../../../fixtures/custom_mechanics/msem-final-abilities.json")).unwrap();
  let card=&fixture["mechanics"].as_array().unwrap().iter().find(|row|row["id"]=="msem-919").unwrap()["representative_cards"][0];
  // A currently visible Siphon ability on the source is not the event producer.
  let spell=source_support::definitions(card).unwrap().into_iter().next().unwrap();
  let producer=game.create_object_from_definition(&spell,A,Zone::Stack);
  let mut dm=Allocations{counts:vec![1].into(),asked:vec![]};
  apply(&mut game,watcher,watcher,EventCause::from_effect(producer,A),1,&mut dm);
  assert_eq!(game.counter_count(watcher,CounterType::Flying),1);assert_eq!(dm.asked,vec![A]);
  let mut retained=EventCause::from_effect(producer,A);retained.resolving_ability_designations=vec!["siphon".into()];
  game.move_object(producer,Zone::Graveyard,EventCause::effect()).unwrap();
  apply(&mut game,watcher,watcher,retained,1,&mut dm);
  assert_eq!(game.counter_count(watcher,CounterType::Flying),1);assert_eq!(game.counter_count(watcher,CounterType::PlusOnePlusOne),1);
 }
}
#[test]
fn actual_siphon_payment_stays_a_cost_in_the_presence_of_actual_dewshaper(){
 use ironsmith::decision::{LegalAction,compute_legal_actions,SelectFirstDecisionMaker};
 use ironsmith::game_loop::{PriorityLoopState,PriorityResponse,apply_priority_response_with_dm,apply_decision_context_with_dm};
 let fixture:serde_json::Value=serde_json::from_str(include_str!("../../../fixtures/custom_mechanics/msem-final-abilities.json")).unwrap();
 let card=&fixture["mechanics"].as_array().unwrap().iter().find(|row|row["id"]=="msem-919").unwrap()["representative_cards"][0];
 let spells=source_support::definitions(card).unwrap();
 for (watcher_definition,spell_definition) in definitions().into_iter().zip(spells){
  let mut game=GameState::new(vec!["A".into(),"B".into()],20);game.turn.active_player=A;game.turn.priority_player=Some(A);game.turn.phase=ironsmith::Phase::FirstMain;game.turn.step=None;
  let watcher=game.create_object_from_definition(&watcher_definition,A,Zone::Battlefield);
  let body=ironsmith_compiler_runtime::compile_to_runtime_definition("Counter contributor","Type: Creature — Human\nPower/Toughness: 8/8",false).unwrap();
  let contributor=game.create_object_from_definition(&body,A,Zone::Battlefield);
  game.create_object_from_definition(&body,B,Zone::Battlefield);
  let spell=game.create_object_from_definition(&spell_definition,A,Zone::Hand);
  game.player_mut(A).unwrap().mana_pool.add(ironsmith::mana::ManaSymbol::Black,1);
  let action=compute_legal_actions(&game,A).unwrap().into_iter().find(|action|matches!(action,LegalAction::CastSpell{spell_id,..}if *spell_id==spell)).expect("real Siphon spell can use counter payments");
  let mut queue=ironsmith::triggers::TriggerQueue::new();let mut state=PriorityLoopState::new(2);let mut dm=SelectFirstDecisionMaker;
  let mut progress=apply_priority_response_with_dm(&mut game,&mut queue,&mut state,&PriorityResponse::PriorityAction(action),&mut dm).unwrap();
  for _ in 0..64{if !state.has_pending_action(){break;}let ironsmith::GameProgress::NeedsDecisionCtx(ctx)=progress else{panic!("{progress:?}")};progress=apply_decision_context_with_dm(&mut game,&mut queue,&mut state,&ctx,&mut dm).unwrap();}
  assert!(!state.has_pending_action());
  let count=|id,kind|game.object(id).map(|_|game.counter_count(id,kind)).or_else(||game.turn_store.turn_history.source_last_known_snapshot(id).map(|snapshot|snapshot.counter_count(kind))).unwrap();
  assert_eq!(count(watcher,CounterType::MinusOneMinusOne)+count(contributor,CounterType::MinusOneMinusOne),3,"all three generic units remain actual counter costs");
  for kind in [CounterType::Flying,CounterType::Vigilance,CounterType::Stun]{assert_eq!(count(watcher,kind)+count(contributor,kind),0,"Dewshaper cannot rewrite a cost as an effect");}
 }
}
