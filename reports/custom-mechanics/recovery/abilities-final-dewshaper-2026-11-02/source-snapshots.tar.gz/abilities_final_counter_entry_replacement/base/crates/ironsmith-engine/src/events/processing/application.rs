use super::TraitApplyResult;
use crate::effects::tokens::resources::checked_token_count;
use crate::events::{Event, EventKind};
use crate::filter::ObjectFilterExt as _;
use crate::game_state::{GameState, Target};
use crate::ids::PlayerId;
use crate::object::CounterType;
use crate::replacement::{
    EventModification, RedirectTarget, RedirectWhich, ReplacementAction, ReplacementEffect,
};
use crate::zone::Zone;

/// The current value of a static prevention amount ("X, where X is the number
/// of age counters on this enchantment"), read from its source.
/// Actual recipient damage and this exact ability's prevention are separate
/// facts. Other prevention never spends a dealt-damage cap.
pub(super) fn turn_prevention_remaining(
    game: &GameState, effect: &ReplacementEffect, target: crate::events::DamageTarget,
    maximum: u32, include_own_prevention: bool,
) -> u32 {
    let key = effect.application_key();
    let mut used = 0u128;
    for record in game.turn_store.turn_history.projected_records() {
        if let Some(damage) = record.event.downcast::<crate::events::DamageEvent>() {
            if damage.target == target { used += u128::from(damage.amount); }
        }
        if include_own_prevention {
            if let Some(prevented) = record.event.downcast::<crate::events::DamagePreventedEvent>() {
                if prevented.target == target && prevented.prevention_effect.as_ref() == Some(&key) { used += u128::from(prevented.amount); }
            }
        }
    }
    u128::from(maximum).saturating_sub(used) as u32
}

pub(super) fn resolve_static_prevention_amount(
    game: &GameState,
    effect: &ReplacementEffect,
    amount: &crate::effect::Value,
) -> Result<u32, crate::effects::ExecutionError> {
    let mut dm = crate::decision::SelectFirstDecisionMaker;
    let mut ctx = crate::effects::ExecutionContext::new(effect.source, effect.controller, &mut dm);
    if let Some(source) = game.object(effect.source) {
        ctx.optional_costs_paid = source.optional_costs_paid.clone();
        ctx.x_value = source.own_entry_x_value();
        ctx = ctx.with_tagged_objects(source.cast_tagged_objects.clone());
    }
    let amount = crate::effects::helpers::resolve_value(game, amount, &ctx)?;
    Ok(amount.max(0) as u32)
}

pub(super) fn excess_redirect_amount(game: &GameState, event: &Event) -> u32 {
    let Some(damage) = crate::events::downcast_event::<crate::events::DamageEvent>(event.inner()) else { return 0; };
    let crate::events::DamageTarget::Object(target) = damage.target else { return 0; };
    let keywords = crate::rules::damage::source_damage_keywords(game, damage.source, event.0.source_snapshot());
    crate::effects::damage::excess_damage_to_object(game, target, damage.amount, keywords).min(damage.amount)
}

pub(super) fn apply_trait_replacement(
    game: &mut GameState,
    event: Event,
    effect: &ReplacementEffect,
) -> Result<TraitApplyResult, crate::effects::ExecutionError> {
    Ok(match &effect.replacement {
        ReplacementAction::Prevent => TraitApplyResult::Prevented,

        ReplacementAction::PreventDamage => {
            let Some(damage) =
                crate::events::downcast_event::<crate::events::DamageEvent>(event.inner()).cloned()
            else {
                return Ok(TraitApplyResult::Unchanged(event));
            };
            if damage.is_unpreventable || damage.amount == 0 {
                TraitApplyResult::Unchanged(event)
            } else {
                queue_damage_prevented_event(game, &event, effect, &damage, damage.amount)?;
                TraitApplyResult::Prevented
            }
        }

        ReplacementAction::PreventDamageAmount(amount) => {
            let Some(damage) =
                crate::events::downcast_event::<crate::events::DamageEvent>(event.inner()).cloned()
            else {
                return Ok(TraitApplyResult::Unchanged(event));
            };
            let prevented = if damage.is_unpreventable {
                0
            } else {
                damage.amount.min(*amount)
            };
            if prevented == 0 {
                TraitApplyResult::Unchanged(event)
            } else {
                queue_damage_prevented_event(game, &event, effect, &damage, prevented)?;
                TraitApplyResult::Modified(event.rewrap(damage.reduced(prevented)))
            }
        }

        ReplacementAction::PreventDamageByRule(rule) => {
            let Some(damage) =
                crate::events::downcast_event::<crate::events::DamageEvent>(event.inner()).cloned()
            else {
                return Ok(TraitApplyResult::Unchanged(event));
            };
            // CR 615: a prevention cap is not SetTo. Unpreventable damage is
            // unchanged, and prevention events describe only actual prevention.
            let prevented = if damage.is_unpreventable || damage.amount == 0 {
                0
            } else {
                match rule {
                    ironsmith_core::StaticDamagePreventionAmount::All => damage.amount,
                    ironsmith_core::StaticDamagePreventionAmount::AllBut(remaining) => {
                        damage.amount.saturating_sub(*remaining)
                    }
                    ironsmith_core::StaticDamagePreventionAmount::FirstEachTurn(maximum) => damage.amount.min(turn_prevention_remaining(game,effect,damage.target,*maximum,true)),
                    ironsmith_core::StaticDamagePreventionAmount::AllButFirstEachTurn(maximum) => damage.amount.saturating_sub(turn_prevention_remaining(game,effect,damage.target,*maximum,false)),
                    ironsmith_core::StaticDamagePreventionAmount::Amount(amount)
                    // A lone event spends its source's whole shared budget;
                    // simultaneous events are allocated before application.
                    | ironsmith_core::StaticDamagePreventionAmount::SharedPerSource(amount) => {
                        damage.amount.min(resolve_static_prevention_amount(game, effect, amount)?)
                    }
                }
            };
            if prevented == 0 {
                TraitApplyResult::Unchanged(event)
            } else {
                queue_damage_prevented_event(game, &event, effect, &damage, prevented)?;
                TraitApplyResult::Modified(event.rewrap(damage.reduced(prevented)))
            }
        }

        ReplacementAction::PreventHalfDamage { round_up } => {
            let Some(damage) =
                crate::events::downcast_event::<crate::events::DamageEvent>(event.inner()).cloned()
            else {
                return Ok(TraitApplyResult::Unchanged(event));
            };
            let prevented = if damage.is_unpreventable {
                0
            } else if *round_up {
                damage.amount.div_ceil(2)
            } else {
                damage.amount / 2
            };
            if prevented == 0 {
                TraitApplyResult::Unchanged(event)
            } else {
                queue_damage_prevented_event(game, &event, effect, &damage, prevented)?;
                TraitApplyResult::Modified(event.rewrap(damage.reduced(prevented)))
            }
        }

        ReplacementAction::PreventDamageByRemovingSourceCounters { counter_type } => {
            let Some(damage) =
                crate::events::downcast_event::<crate::events::DamageEvent>(event.inner()).cloned()
            else {
                return Ok(TraitApplyResult::Unchanged(event));
            };
            let counters_to_remove = damage
                .amount
                .min(game.counter_count(effect.source, *counter_type));
            if counters_to_remove == 0 {
                return Ok(TraitApplyResult::Unchanged(event));
            }
            let prevented = if damage.is_unpreventable {
                0
            } else {
                counters_to_remove
            };
            if prevented > 0 {
                queue_damage_prevented_event(game, &event, effect, &damage, prevented)?;
            }
            queue_prevention_follow_up(
                game,
                crate::prevention::PreventionFollowUp {
                    source: effect.source,
                    controller: effect.controller,
                    prevented,
                    effects: vec![crate::effect::Effect::remove_counters(
                        *counter_type,
                        crate::effect::Value::from(counters_to_remove),
                        crate::target::ChooseSpec::Source,
                    )],
                    targets: Vec::new(),
                    target_assignments: Vec::new(),
                },
                damage.with_amount(prevented),
                event.provenance(),
                event.0.source_snapshot(),
            );
            if prevented > 0 {
                TraitApplyResult::Modified(event.rewrap(damage.reduced(prevented)))
            } else {
                TraitApplyResult::Unchanged(event)
            }
        }

        ReplacementAction::PreventDamageThen(effects)
        | ReplacementAction::PreventDamageThenFromProposedAmount(effects) => {
            let Some(damage) =
                crate::events::downcast_event::<crate::events::DamageEvent>(event.inner()).cloned()
            else {
                return Ok(TraitApplyResult::Unchanged(event));
            };
            let prevented = if damage.is_unpreventable {
                0
            } else {
                damage.amount
            };
            if prevented > 0 {
                queue_damage_prevented_event(game, &event, effect, &damage, prevented)?;
            }
            queue_prevention_follow_up(
                game,
                crate::prevention::PreventionFollowUp {
                    source: effect.source,
                    controller: effect.controller,
                    prevented,
                    effects: effects.clone(),
                    targets: Vec::new(),
                    target_assignments: Vec::new(),
                },
                damage.with_amount(
                    if matches!(
                        &effect.replacement,
                        ReplacementAction::PreventDamageThenFromProposedAmount(_)
                    ) {
                        damage.amount
                    } else {
                        prevented
                    },
                ),
                event.provenance(),
                event.0.source_snapshot(),
            );
            if prevented > 0 {
                TraitApplyResult::Prevented
            } else {
                TraitApplyResult::Unchanged(event)
            }
        }

        ReplacementAction::PreventWithShield {
            shield_id,
            max_amount,
        } => {
            let Some(damage) =
                crate::events::downcast_event::<crate::events::DamageEvent>(event.inner()).cloned()
            else {
                return Ok(TraitApplyResult::Unchanged(event));
            };
            let result = game.effect_store.prevention_effects.apply_chosen_shield(
                *shield_id,
                damage.amount,
                !damage.is_unpreventable,
                *max_amount,
            );
            for follow_up in result.follow_ups {
                let follow_up_damage = damage.with_amount(follow_up.prevented);
                queue_prevention_follow_up(
                    game,
                    follow_up,
                    follow_up_damage,
                    event.provenance(),
                    event.0.source_snapshot(),
                );
            }
            let prevented = damage.amount.saturating_sub(result.remaining);
            if prevented > 0 {
                queue_damage_prevented_event(game, &event, effect, &damage, prevented)?;
            }
            if prevented == 0 {
                TraitApplyResult::Unchanged(event)
            } else {
                TraitApplyResult::Modified(event.rewrap(damage.with_amount(result.remaining)))
            }
        }

        ReplacementAction::Skip => TraitApplyResult::Prevented,

        ReplacementAction::Instead(effects) => TraitApplyResult::Replaced(effects.clone()),

        ReplacementAction::Modify(EventModification::AddDynamic(value)) => {
            let delta = resolve_signed_value_for_replacement(value, game, effect)?;
            let mut resolved = effect.clone();
            resolved.replacement = ReplacementAction::Modify(EventModification::Add(delta));
            return apply_trait_replacement(game, event, &resolved);
        }
        ReplacementAction::Modify(modification) => {
            if let Some(tokens) =
                crate::events::downcast_event::<crate::events::CreateTokensEvent>(event.inner())
            {
                let modified = modify_token_groups_checked(game, effect, tokens, modification)?;
                return Ok(TraitApplyResult::Modified(event.rewrap(modified)));
            }
            if let Some(modified) =
                apply_damage_result_modification(game, &event, modification, effect)?
            {
                return Ok(TraitApplyResult::Modified(modified));
            }
            let modified = apply_trait_modification(game, &event, modification, effect);
            match modified {
                Some(e) => TraitApplyResult::Modified(e),
                None => TraitApplyResult::Unchanged(event),
            }
        }

        ReplacementAction::Double => {
            if let Some(create_tokens) =
                crate::events::downcast_event::<crate::events::CreateTokensEvent>(event.inner())
            {
                let covers = token_groups_covered(game, effect, &create_tokens);
                let modified =
                    create_tokens.scaled_token_groups(covers, |count| u128::from(count) * 2)?;
                return Ok(TraitApplyResult::Modified(event.rewrap(modified)));
            }
            if let Some(modified) = apply_damage_result_modification(
                game,
                &event,
                &EventModification::Multiply(2),
                effect,
            )? {
                return Ok(TraitApplyResult::Modified(modified));
            }
            let modified = apply_trait_double(&event);
            match modified {
                Some(e) => TraitApplyResult::Modified(e),
                None => TraitApplyResult::Unchanged(event),
            }
        }

        ReplacementAction::RewriteCounterKinds {selected,..} => {
            let Some(original)=crate::events::downcast_event::<crate::events::PutCountersEvent>(event.inner()) else{return Ok(TraitApplyResult::Unchanged(event));};
            let Some(selected)=selected else{return Err(crate::effects::ExecutionError::IncompleteEvidence("counter kind replacement has no retained allocation".into()));};
            if selected.len()==1 && selected[0]==(original.counter_type,original.count) {
                TraitApplyResult::Unchanged(event)
            }else{
                let target=match original.target {
                    crate::game_state::Target::Object(object)=>crate::target::ChooseSpec::SpecificObject(object),
                    crate::game_state::Target::Player(_)=>return Err(crate::effects::ExecutionError::IncompleteEvidence("counter-kind continuation currently requires a permanent proposal".into())),
                };
                TraitApplyResult::Replaced(vec![crate::effect::Effect::new(crate::effects::PutCounterBatchEffect {
                    target,counters:selected.clone(),use_replaced_event_cause:true,
                })])
            }
        }

        ReplacementAction::DoubleCounters { counter_type } => {
            let modified = apply_trait_double_counters(&event, *counter_type)?;
            match modified {
                Some(e) => TraitApplyResult::Modified(e),
                None => TraitApplyResult::Unchanged(event),
            }
        }

        ReplacementAction::HalveCounters { counter_type } => {
            let modified = apply_trait_halve_counters(&event, *counter_type);
            match modified {
                Some(e) => TraitApplyResult::Modified(e),
                None => TraitApplyResult::Unchanged(event),
            }
        }

        ReplacementAction::AddCountersToPlacement {
            counter_type,
            additional,
        } => {
            let modified =
                apply_trait_add_counters_to_placement(&event, *counter_type, *additional)?;
            match modified {
                Some(e) => TraitApplyResult::Modified(e),
                None => TraitApplyResult::Unchanged(event),
            }
        }

        ReplacementAction::SetPlayerCountersAndLockForTurn {
            counter_type,
            amount,
        } => {
            let modified = apply_trait_set_player_counters_and_lock_for_turn(
                game,
                &event,
                *counter_type,
                *amount,
            );
            match modified {
                Some(e) => TraitApplyResult::Modified(e),
                None => TraitApplyResult::Unchanged(event),
            }
        }

        ReplacementAction::ChangeDestination(new_zone) => {
            let modified = apply_trait_change_destination(&event, *new_zone);
            match modified {
                Some(e) => TraitApplyResult::Modified(e),
                None => TraitApplyResult::Unchanged(event),
            }
        }

        ReplacementAction::DiscardWithMadness => {
            if let Some(discard) =
                crate::events::downcast_event::<crate::events::DiscardEvent>(event.inner())
            {
                let mut discard = discard.with_destination(Zone::Exile);
                discard.madness_applied = true;
                TraitApplyResult::Modified(event.rewrap(discard))
            } else {
                TraitApplyResult::Unchanged(event)
            }
        }

        ReplacementAction::MoveToZoneWithCounters { .. } => TraitApplyResult::Replaced(Vec::new()),

        ReplacementAction::MoveToZoneThen { effects, .. } => {
            TraitApplyResult::Replaced(effects.clone())
        }

        ReplacementAction::ExileWithSourceLink => TraitApplyResult::Replaced(Vec::new()),

        ReplacementAction::ExileWithSourceLinkThen(effects) => {
            TraitApplyResult::Replaced(effects.clone())
        }

        ReplacementAction::ExileWithSourceLinkCountersThen { effects, .. } => {
            TraitApplyResult::Replaced(effects.clone())
        }

        ReplacementAction::EnterTapped => {
            let modified = apply_trait_enter_tapped(&event);
            match modified {
                Some(e) => TraitApplyResult::Modified(e),
                None => TraitApplyResult::Unchanged(event),
            }
        }

        ReplacementAction::EnterUntapped => {
            let modified = apply_trait_enter_untapped(&event);
            match modified {
                Some(e) => TraitApplyResult::Modified(e),
                None => TraitApplyResult::Unchanged(event),
            }
        }

        ReplacementAction::EnterUnderChosenControl { players } => {
            TraitApplyResult::NeedsInteraction {
                decision_ctx: super::entry_controller_choice_context(
                    game,
                    effect.source,
                    effect.controller,
                    players,
                ),
                redirect_zone: Zone::Battlefield,
                effect_id: effect.id,
                object_id: effect.source,
                filter: None,
                sacrifice_count: None,
                destinations: None,
            }
        }

        ReplacementAction::EnterUnderControl(controller) => {
            let modified = apply_trait_enter_under_control(&event, *controller);
            match modified {
                Some(e) => TraitApplyResult::Modified(e),
                None => TraitApplyResult::Unchanged(event),
            }
        }

        ReplacementAction::EnterWithIntrinsicStartingCounters(rule) => {
            let etb = crate::events::downcast_event::<crate::events::EnterBattlefieldEvent>(event.inner())
                .cloned().or_else(|| {
                    crate::events::downcast_event::<crate::events::ZoneChangeEvent>(event.inner())
                        .filter(|zone| zone.to == Zone::Battlefield && zone.objects.len() == 1)
                        .map(|zone| crate::events::EnterBattlefieldEvent::new(zone.objects[0], zone.from))
                }).ok_or_else(|| crate::effects::ExecutionError::InternalError(
                    "intrinsic starting counters require a single-object battlefield entry proposal".into()))?;
            let prospective = etb
                .try_prospective_game_state(game)
                .map_err(crate::effects::ExecutionError::ContinuousDiscovery)?
                .ok_or(crate::effects::ExecutionError::ObjectNotFound(etb.object))?;
            let chars = prospective
                .calculated_characteristics(etb.object)
                .ok_or(crate::effects::ExecutionError::ObjectNotFound(etb.object))?;
            let count = match rule {
                ironsmith_core::IntrinsicStartingCounter::Loyalty => chars.loyalty,
                ironsmith_core::IntrinsicStartingCounter::Defense => chars.defense,
            }
            .unwrap_or(0);
            let counter = rule.counter_type();
            let prior = etb
                .enters_with_counters
                .iter()
                .filter(|(kind, _)| *kind == counter)
                .try_fold(0_u32, |total, (_, value)| total.checked_add(*value))
                .ok_or_else(|| {
                    crate::effects::ExecutionError::InternalError(
                        "entry counter contribution overflow".into(),
                    )
                })?;
            prior.checked_add(count).ok_or_else(|| {
                crate::effects::ExecutionError::InternalError(
                    "intrinsic entry counter contribution overflow".into(),
                )
            })?;
            match apply_trait_enter_with_counters(&event, counter, count, &[], &[]) {
                Some(modified) => TraitApplyResult::Modified(modified),
                None => {
                    return Err(crate::effects::ExecutionError::InternalError(
                        "intrinsic starting-counter action could not modify its entry proposal"
                            .into(),
                    ));
                }
            }
        }

        ReplacementAction::EnterWithCounters {
            counter_type,
            counter_kinds_from,
            count,
            count_condition,
            otherwise_count,
            added_subtypes,
            added_abilities,
        } => {
            // The enter replacement can arrive as either event shape.
            let entering_object =
                crate::events::downcast_event::<crate::events::ZoneChangeEvent>(event.inner())
                    .filter(|zone_change| zone_change.to == Zone::Battlefield)
                    .and_then(|zone_change| zone_change.objects.first().copied())
                    .or_else(|| {
                        crate::events::downcast_event::<crate::events::EnterBattlefieldEvent>(
                            event.inner(),
                        )
                        .map(|etb| etb.object)
                    });
            let condition_source = entering_object.unwrap_or(effect.source);
            let selected_count = match (count_condition, otherwise_count) {
                (Some(condition), Some(otherwise_count)) => {
                    let eval_ctx = crate::condition_eval::ExternalEvaluationContext {
                        controller: effect.controller,
                        source: condition_source,
                        defending_player: None,
                        attacking_player: None,
                        filter_source: Some(condition_source),
                        iterated_player: None,
                        triggering_event: None,
                        trigger_identity: None,
                        ability_index: None,
                        options: Default::default(),
                    };
                    if crate::condition_eval::evaluate_condition_external(
                        game, condition, &eval_ctx,
                    ) {
                        count
                    } else {
                        otherwise_count
                    }
                }
                _ => count,
            };
            let value_source = if etb_value_uses_entering_object(selected_count) {
                condition_source
            } else {
                effect.source
            };
            // CR 611.3c/614.12: an entering object's own power or toughness
            // is read as it would exist on the battlefield, so external
            // static effects (an anthem) already apply.
            let prospective = if etb_value_uses_revealed_choice(selected_count)
                || etb_value_reads_entering_pt(selected_count)
            {
                crate::events::downcast_event::<crate::events::EnterBattlefieldEvent>(event.inner())
                    .and_then(|etb| etb.prospective_game_state(game))
                    .or_else(|| {
                        let zone_change = crate::events::downcast_event::<
                            crate::events::ZoneChangeEvent,
                        >(event.inner())
                        .filter(|zone_change| zone_change.to == Zone::Battlefield)?;
                        crate::events::EnterBattlefieldEvent::new(
                            *zone_change.objects.first()?,
                            zone_change.from,
                        )
                        .prospective_game_state(game)
                    })
            } else {
                None
            };
            let resolved_count = resolve_value_for_etb(
                selected_count,
                prospective.as_ref().unwrap_or(game),
                value_source,
            );
            let counter_type = sunburst_entry_counter_type(
                game,
                &event,
                condition_source,
                *counter_type,
                selected_count,
            );
            let entries = if let Some(source) = counter_kinds_from {
                let mut context = crate::effects::ExecutionContext::new_default(effect.source, effect.controller);
                let objects = crate::effects::helpers::resolve_objects_for_effect(game, &mut context, source)?;
                crate::effects::counters::kind_selection::kinds_on(game, &objects)
                    .into_iter().map(|kind| (kind, resolved_count)).collect::<Vec<_>>()
            } else { vec![(counter_type, resolved_count)] };
            let modified = apply_trait_enter_with_counter_entries(
                &event, &entries, added_subtypes, added_abilities,
            );
            match modified {
                Some(e) => TraitApplyResult::Modified(e),
                None => TraitApplyResult::Unchanged(event),
            }
        }

        ReplacementAction::EnterWithCounterChoice { counter_types, kinds, .. } => {
            if counter_types.is_empty() {
                return Ok(TraitApplyResult::Unchanged(event));
            }
            TraitApplyResult::NeedsInteraction {
                decision_ctx: super::counter_choice_context(
                    game,
                    effect.source,
                    effect.controller,
                    counter_types,
                    *kinds,
                ),
                redirect_zone: Zone::Battlefield,
                effect_id: effect.id,
                object_id: effect.source,
                filter: None,
                sacrifice_count: None,
                destinations: None,
            }
        }

        ReplacementAction::Tribute { count, .. } => {
            let opponents = super::tribute_opponents(game, effect.controller);
            if opponents.is_empty() {
                return Ok(TraitApplyResult::Unchanged(event));
            };
            let decision_ctx = if opponents.len() == 1 {
                super::tribute_boolean_context(game, effect.source, opponents[0], *count)
            } else {
                super::tribute_opponent_choice_context(
                    game,
                    effect.source,
                    effect.controller,
                    &opponents,
                )
            };
            TraitApplyResult::NeedsInteraction {
                decision_ctx,
                redirect_zone: Zone::Battlefield,
                effect_id: effect.id,
                object_id: effect.source,
                filter: None,
                sacrifice_count: None,
                destinations: None,
            }
        }

        ReplacementAction::Redirect { target, which } => {
            let modified = apply_trait_redirect(game, &event, target, which, effect.controller);
            match modified {
                Some(e) => TraitApplyResult::Modified(e),
                None => TraitApplyResult::Unchanged(event),
            }
        }

        ReplacementAction::RedirectDamageAmount { target, which, .. }
        | ReplacementAction::RedirectExcessDamage { target, which } => {
            use crate::events::{DamageEvent, DamageTarget, downcast_event};

            let Some(damage) = downcast_event::<DamageEvent>(event.inner()) else {
                return Ok(TraitApplyResult::Unchanged(event));
            };
            let redirected_amount = match &effect.replacement {
                ReplacementAction::RedirectDamageAmount { amount, .. } => (*amount).min(damage.amount),
                ReplacementAction::RedirectExcessDamage { .. } => excess_redirect_amount(game, &event),
                _ => unreachable!("partial redirect branch"),
            };
            if redirected_amount == 0 {
                return Ok(TraitApplyResult::Unchanged(event));
            }
            let Some(new_target) =
                resolve_trait_redirect_target(game, &event, target, which, effect.controller)
            else {
                return Ok(TraitApplyResult::Unchanged(event));
            };
            let redirected_target = match new_target {
                Target::Player(player_id) => DamageTarget::Player(player_id),
                Target::Object(object_id) => DamageTarget::Object(object_id),
            };


            let mut modified = damage
                .with_target(redirected_target)
                .with_amount(redirected_amount);
            if damage.amount > redirected_amount {
                modified =
                    modified.with_remainder(damage.target, damage.amount - redirected_amount);
            }
            TraitApplyResult::Modified(event.rewrap(modified))
        }

        ReplacementAction::AsEntersProgram(program) => {
            let Some(etb) = crate::events::downcast_event::<crate::events::EnterBattlefieldEvent>(
                event.inner(),
            ) else {
                return Ok(TraitApplyResult::Unchanged(event));
            };
            let mut pending = etb.clone();
            pending.pending_program = Some((program.clone(), effect.controller,
                crate::linked_exile::LinkedExileOwner::capture(
                    effect.source, program.linked_exile_pair,
                    effect.ability_origin.as_ref().map(|origin| &origin.ability),
                )));
            TraitApplyResult::Modified(event.rewrap(pending))
        }

        ReplacementAction::Additionally(_effects) => TraitApplyResult::Modified(event),

        ReplacementAction::HealRecipientThenProceed => {
            let Some(damage) =
                crate::events::downcast_event::<crate::events::DamageEvent>(event.inner())
            else {
                return Ok(TraitApplyResult::Unchanged(event));
            };
            if damage.amount > 0
                && let crate::events::DamageTarget::Object(recipient) = damage.target
            {
                game.clear_damage(recipient);
            }
            TraitApplyResult::Modified(event)
        }

        ReplacementAction::DeclineOptional(_) => TraitApplyResult::Modified(event),

        ReplacementAction::TokenCreationTemplates {
            templates,
            mode,
            choose_one,
            ..
        } => {
            if *choose_one {
                return Err(crate::effects::ExecutionError::InternalError(
                    "unselected token replacement alternatives".into(),
                ));
            }
            use crate::events::{CreateTokensEvent, downcast_event};
            use ironsmith_core::TokenCreationTemplateMode;
            let Some(tokens) = downcast_event::<CreateTokensEvent>(event.inner()).cloned() else {
                return Ok(TraitApplyResult::Unchanged(event));
            };
            let covers = token_groups_covered(game, effect, &tokens);
            let count = checked_token_count(tokens.matching_count(&covers))?;
            if count == 0 {
                return Ok(TraitApplyResult::Unchanged(event));
            }
            let mut modified = if *mode == TokenCreationTemplateMode::ReplaceEach {
                tokens.scaled_token_groups(&covers, |_| 0)?
            } else {
                tokens.clone()
            };
            let copies = if *mode == TokenCreationTemplateMode::AppendOnce {
                1
            } else {
                count
            };
            for template in templates {
                // "create that many tokens that are copies of enchanted
                // permanent" (Moonlit Meditation): the copiable values are
                // captured as the replacement applies (CR 707.2, 616.1).
                if let Some(copy) = template.downcast_ref::<crate::effects::CreateTokenCopyEffect>() {
                    let Some(copied) = replacement_copy_template_object(game, effect, &copy.target)
                    else {
                        return Ok(TraitApplyResult::Unchanged(event));
                    };
                    let Some(definition) = game.object(copied).map(|object| {
                        let mut definition = object.to_card_definition();
                        definition.card.is_token = true;
                        definition
                    }) else {
                        return Ok(TraitApplyResult::Unchanged(event));
                    };
                    modified = modified.with_template(definition, copies)?;
                    continue;
                }
                let Some(create) = template.downcast_ref::<crate::effects::CreateTokenEffect>()
                else {
                    return Err(crate::effects::ExecutionError::InternalError(
                        "token replacement contains a non-template effect".into(),
                    ));
                };
                if !matches!(create.count.unhinted(), crate::effect::Value::Fixed(1)) {
                    return Err(crate::effects::ExecutionError::InternalError(
                        "token replacement template has an unsupported quantity".into(),
                    ));
                }
                let mut definition = create.token.clone();
                crate::effects::tokens::materialize_named_creator_source_in_token(
                    &mut definition,
                    effect.source,
                );
                modified = modified.with_template(definition, copies)?;
            }
            TraitApplyResult::Modified(event.rewrap(modified))
        }

        ReplacementAction::AddTokens { token, count } => {
            let modified = apply_trait_add_tokens(&event, *token, *count)?;
            match modified {
                Some(e) => TraitApplyResult::Modified(e),
                None => TraitApplyResult::Unchanged(event),
            }
        }

        ReplacementAction::AddTokensPerCreated { token } => {
            use crate::events::{CreateTokensEvent, downcast_event};

            let Some(create_tokens) = downcast_event::<CreateTokensEvent>(event.inner()).cloned()
            else {
                return Ok(TraitApplyResult::Unchanged(event));
            };
            // "that many": every covered token, including ones an earlier
            // replacement added (CR 616.1).
            let that_many = checked_token_count(
                create_tokens.matching_count(token_groups_covered(game, effect, &create_tokens)),
            )?;
            match apply_trait_add_tokens(&event, *token, that_many)? {
                Some(e) => TraitApplyResult::Modified(e),
                None => TraitApplyResult::Unchanged(event),
            }
        }

        ReplacementAction::AddTokensOfOtherKinds { kinds } => {
            use crate::events::{CreateTokensEvent, downcast_event};

            let Some(create_tokens) = downcast_event::<CreateTokensEvent>(event.inner()).cloned()
            else {
                return Ok(TraitApplyResult::Unchanged(event));
            };
            // Each token group of one of `kinds` (the original token or one an
            // earlier replacement added, CR 616.1) becomes one of each kind.
            let covers = token_groups_covered(game, effect, &create_tokens);
            let covered: Vec<_> = create_tokens
                .group_keys()
                .into_iter()
                .filter(|key| {
                    covers(*key)
                        && create_tokens.group_object(*key).is_some_and(|token| {
                            kinds.iter().any(|kind| {
                                token.has_subtype(match kind {
                                    ironsmith_core::AdditionalTokenKind::Treasure => {
                                        crate::types::Subtype::Treasure
                                    }
                                    ironsmith_core::AdditionalTokenKind::Food => {
                                        crate::types::Subtype::Food
                                    }
                                    ironsmith_core::AdditionalTokenKind::Clue => {
                                        crate::types::Subtype::Clue
                                    }
                                    ironsmith_core::AdditionalTokenKind::Squirrel => {
                                        crate::types::Subtype::Squirrel
                                    }
                                })
                            })
                        })
                })
                .collect();
            let count =
                checked_token_count(create_tokens.matching_count(|key| covered.contains(&key)))?;
            // "Instead create one of each" replaces each matching token's
            // definition too; it does not retain a custom Food/Clue/Treasure
            // prototype or omit template groups added by an earlier effect.
            let mut modified =
                create_tokens.scaled_token_groups(|key| covered.contains(&key), |_| 0)?;
            let mut distinct = Vec::new();
            for kind in kinds {
                if !distinct.contains(kind) {
                    distinct.push(*kind);
                    modified = modified.with_additional_tokens(*kind, count)?;
                }
            }
            TraitApplyResult::Modified(event.rewrap(modified))
        }

        ReplacementAction::RedirectDrawToController => {
            use crate::events::{DrawEvent, downcast_event};

            let Some(draw) = downcast_event::<DrawEvent>(event.inner()) else {
                return Ok(TraitApplyResult::Unchanged(event));
            };
            if draw.player == effect.controller {
                return Ok(TraitApplyResult::Unchanged(event));
            }
            TraitApplyResult::Modified(event.rewrap(draw.with_player(effect.controller)))
        }

        ReplacementAction::ConvertUnspentMana(symbol) => {
            let Some(loss) =
                crate::events::downcast_event::<crate::events::ManaLostEvent>(event.inner())
            else {
                return Ok(TraitApplyResult::Unchanged(event));
            };
            if !crate::events::mana::POOL_SYMBOLS.contains(symbol) {
                return Err(crate::effects::ExecutionError::InternalError(
                    "invalid mana conversion type".into(),
                ));
            }
            let mut converted = loss.clone();
            converted.converted_to = Some(*symbol);
            TraitApplyResult::Modified(event.rewrap(converted))
        }

        ReplacementAction::RewriteMana { .. } => {
            let Some(mana) =
                crate::events::downcast_event::<crate::events::ManaAddedEvent>(event.inner())
            else {
                return Ok(TraitApplyResult::Unchanged(event));
            };
            let transform = effect.replacement.mana_transformation().ok_or_else(|| {
                crate::effects::ExecutionError::InternalError(
                    "mana rewrite choice was not resolved".into(),
                )
            })?;
            TraitApplyResult::Modified(
                event.rewrap(mana.clone().with_mana(transform.apply(&mana.mana))),
            )
        }

        ReplacementAction::ReplaceMana(mana) => {
            use crate::events::{ManaAddedEvent, downcast_event};

            let Some(mana_event) = downcast_event::<ManaAddedEvent>(event.inner()) else {
                return Ok(TraitApplyResult::Unchanged(event));
            };
            let replacement_mana =
                crate::events::mana::ManaTransformation::ReplaceTypes(mana).apply(&mana_event.mana);
            TraitApplyResult::Modified(event.rewrap(mana_event.clone().with_mana(replacement_mana)))
        }

        ReplacementAction::ReplaceManaExact(mana) => {
            use crate::events::{ManaAddedEvent, downcast_event};

            let Some(mana_event) = downcast_event::<ManaAddedEvent>(event.inner()) else {
                return Ok(TraitApplyResult::Unchanged(event));
            };
            TraitApplyResult::Modified(event.rewrap(mana_event.clone().with_mana(
                crate::events::mana::ManaTransformation::ReplaceExact(mana).apply(&mana_event.mana),
            )))
        }

        ReplacementAction::EnterAsCopy {
            source,
            enters_tapped,
            copy_duration,
            linked_exile_objects,
            additional_counters,
            name_override,
            added_colors,
            added_card_types,
            removes_other_card_types,
            added_supertypes,
            removed_supertypes,
            added_subtypes,
            added_abilities,
            set_base_power_toughness,
            copy_followups,
        } => {
            let modified = apply_trait_enter_as_copy(
                &event,
                *source,
                *enters_tapped,
                copy_duration.clone(),
                linked_exile_objects,
                additional_counters,
                name_override.clone(),
                *added_colors,
                added_card_types,
                *removes_other_card_types,
                added_supertypes,
                removed_supertypes,
                added_subtypes,
                added_abilities,
                *set_base_power_toughness,
                copy_followups,
            );
            match modified {
                Some(e) => TraitApplyResult::Modified(e),
                None => TraitApplyResult::Unchanged(event),
            }
        }

        ReplacementAction::EnterWithCharacteristics {
            face_down,
            added_card_types,
            added_subtypes,
            set_base_power_toughness,
        } => {
            let modified = apply_trait_enter_with_characteristics(
                &event,
                *face_down,
                added_card_types,
                added_subtypes,
                *set_base_power_toughness,
            );
            match modified {
                Some(e) => TraitApplyResult::Modified(e),
                None => TraitApplyResult::Unchanged(event),
            }
        }

        ReplacementAction::InteractiveDiscardOrRedirect {
            filter,
            redirect_zone,
        } => {
            let controller = effect.controller;
            let (matching_cards, hidden_hand_choice) =
                hand_replacement_choice_candidates(game, controller, filter);

            if matching_cards.is_empty() && !hidden_hand_choice {
                let modified = apply_trait_change_destination(&event, *redirect_zone);
                match modified {
                    Some(e) => TraitApplyResult::Modified(e),
                    None => TraitApplyResult::Unchanged(event),
                }
            } else {
                let candidates: Vec<crate::decisions::context::SelectableObject> = matching_cards
                    .iter()
                    .map(|&id| {
                        let name = game
                            .object(id)
                            .map(|o| o.name.to_string())
                            .unwrap_or_else(|| "Unknown".to_string());
                        crate::decisions::context::SelectableObject::new(id, name)
                    })
                    .collect();
                let source_name = game
                    .object(effect.source)
                    .map(|o| o.name.to_string())
                    .unwrap_or_else(|| "permanent".to_string());
                let discard_phrase = describe_discard_filter_card_phrase(filter);
                let redirect_phrase = describe_redirect_zone_phrase(*redirect_zone);
                let decision_ctx = crate::decisions::context::DecisionContext::SelectObjects(
                    hidden_hand_replacement_context(
                        crate::decisions::context::SelectObjectsContext::new(
                            controller,
                            Some(effect.source),
                            format!(
                                "Discard {} to put {} onto the battlefield, or it goes to {}",
                                discard_phrase, source_name, redirect_phrase
                            ),
                            candidates,
                            // Discarding is optional even when a matching card is visible.
                            // An empty selection redirects the entering object instead.
                            0,
                            Some(1),
                        ),
                        hidden_hand_choice,
                    ),
                );
                TraitApplyResult::NeedsInteraction {
                    decision_ctx,
                    redirect_zone: *redirect_zone,
                    effect_id: effect.id,
                    object_id: effect.source,
                    filter: Some(filter.clone()),
                    sacrifice_count: None,
                    destinations: None,
                }
            }
        }

        ReplacementAction::InteractiveSacrificeOrRedirect {
            filter,
            count,
            redirect_zone,
        } => {
            let controller = effect.controller;
            let matching_permanents =
                find_matching_sacrificable_permanents(game, controller, effect.source, filter);
            if *count == 0 {
                TraitApplyResult::Unchanged(event)
            } else if matching_permanents.len() < *count as usize {
                apply_trait_change_destination(&event, *redirect_zone)
                    .map(TraitApplyResult::Modified)
                    .unwrap_or(TraitApplyResult::Unchanged(event))
            } else {
                let candidates = matching_permanents
                    .into_iter()
                    .map(|id| {
                        let name = game
                            .object(id)
                            .map(|object| object.name.to_string())
                            .unwrap_or_else(|| "Unknown".to_string());
                        crate::decisions::context::SelectableObject::new(id, name)
                    })
                    .collect();
                let source_name = game
                    .object(effect.source)
                    .map(|object| object.name.to_string())
                    .unwrap_or_else(|| "permanent".to_string());
                let decision_ctx = crate::decisions::context::DecisionContext::SelectObjects(
                    crate::decisions::context::SelectObjectsContext::new(
                        controller,
                        Some(effect.source),
                        format!(
                            "Sacrifice {} {} to put {} onto the battlefield, or it goes to {}",
                            count,
                            filter.description(),
                            source_name,
                            describe_redirect_zone_phrase(*redirect_zone),
                        ),
                        candidates,
                        *count as usize,
                        Some(*count as usize),
                    ),
                );
                TraitApplyResult::NeedsInteraction {
                    decision_ctx,
                    redirect_zone: *redirect_zone,
                    effect_id: effect.id,
                    object_id: effect.source,
                    filter: Some(filter.clone()),
                    sacrifice_count: Some(*count),
                    destinations: None,
                }
            }
        }

        ReplacementAction::InteractivePayLifeOrEnterTapped { life_cost } => {
            let controller = effect.controller;
            let can_pay = game
                .player(controller)
                .map(|p| p.life >= *life_cost as i32)
                .unwrap_or(false);

            if !can_pay {
                let modified = apply_trait_enter_tapped(&event);
                match modified {
                    Some(e) => TraitApplyResult::Modified(e),
                    None => TraitApplyResult::Unchanged(event),
                }
            } else {
                let source_name = game.object(effect.source).map(|o| o.name.to_string());
                let mut bool_ctx = crate::decisions::context::BooleanContext::new(
                    controller,
                    Some(effect.source),
                    format!("Pay {} life? (If you don't, this enters tapped)", life_cost),
                );
                if let Some(name) = source_name {
                    bool_ctx = bool_ctx.with_source_name(name);
                }
                let decision_ctx = crate::decisions::context::DecisionContext::Boolean(bool_ctx);
                TraitApplyResult::NeedsInteraction {
                    decision_ctx,
                    redirect_zone: Zone::Battlefield,
                    effect_id: effect.id,
                    object_id: effect.source,
                    filter: None,
                    sacrifice_count: None,
                    destinations: None,
                }
            }
        }

        ReplacementAction::InteractiveRevealCardOrEnterTapped { filter } => {
            let controller = effect.controller;
            let (matching_cards, hidden_hand_choice) =
                hand_replacement_choice_candidates(game, controller, filter);
            if matching_cards.is_empty() && !hidden_hand_choice {
                return Ok(match apply_trait_enter_tapped(&event) {
                    Some(modified) => TraitApplyResult::Modified(modified),
                    None => TraitApplyResult::Unchanged(event),
                });
            }
            let candidates: Vec<crate::decisions::context::SelectableObject> = matching_cards
                .iter()
                .map(|&id| {
                    let name = game
                        .object(id)
                        .map(|o| o.name.to_string())
                        .unwrap_or_else(|| "Unknown".to_string());
                    crate::decisions::context::SelectableObject::new(id, name)
                })
                .collect();
            let source_name = game
                .object(effect.source)
                .map(|o| o.name.to_string())
                .unwrap_or_else(|| "permanent".to_string());
            let decision_ctx = crate::decisions::context::DecisionContext::SelectObjects(
                hidden_hand_replacement_context(
                    crate::decisions::context::SelectObjectsContext::new(
                        controller,
                        Some(effect.source),
                        format!(
                            "Reveal {} from your hand? (If you don't, {} enters tapped)",
                            describe_discard_filter_card_phrase(filter),
                            source_name
                        ),
                        candidates,
                        0,
                        Some(1),
                    ),
                    hidden_hand_choice,
                ),
            );
            // A hand filter whose fallback destination is the battlefield
            // itself is the reveal-or-enter-tapped gate; see
            // `continue_interactive_replacement`.
            TraitApplyResult::NeedsInteraction {
                decision_ctx,
                redirect_zone: Zone::Battlefield,
                effect_id: effect.id,
                object_id: effect.source,
                filter: Some(filter.clone()),
                sacrifice_count: None,
                destinations: None,
            }
        }

        ReplacementAction::InteractiveChooseDestination {
            destinations,
            description,
        } => {
            let options: Vec<crate::decisions::context::SelectableOption> = destinations
                .iter()
                .enumerate()
                .map(|(idx, zone)| {
                    let zone_name = match zone {
                        Zone::Library => "Top of library",
                        Zone::Graveyard => "Graveyard",
                        Zone::Hand => "Hand",
                        Zone::Exile => "Exile",
                        Zone::Battlefield => "Battlefield",
                        Zone::Stack => "Stack",
                        Zone::Command => "Command zone",
                        Zone::Ante => "Ante",
                        Zone::OutsideGame => "Outside the game",
                    };
                    crate::decisions::context::SelectableOption::new(idx, zone_name.to_string())
                })
                .collect();

            let controller = effect.controller;
            let decision_ctx = crate::decisions::context::DecisionContext::SelectOptions(
                crate::decisions::context::SelectOptionsContext::new(
                    controller,
                    Some(effect.source),
                    description.clone(),
                    options,
                    1,
                    1,
                ),
            );

            let default_zone = destinations.first().copied().unwrap_or(Zone::Graveyard);

            TraitApplyResult::NeedsInteraction {
                decision_ctx,
                redirect_zone: default_zone,
                effect_id: effect.id,
                object_id: effect.source,
                filter: None,
                sacrifice_count: None,
                destinations: Some(destinations.clone()),
            }
        }
    })
}

fn queue_damage_prevented_event(
    game: &mut GameState,
    original_event: &Event,
    effect: &ReplacementEffect,
    damage: &crate::events::DamageEvent,
    amount: u32,
) -> Result<(), crate::effects::ExecutionError> {
    if amount == 0 {
        return Ok(());
    }
    crate::events::damage::checked_damage_count(u128::from(amount), "prevented damage amount")?;
    let mut prevented = crate::events::DamagePreventedEvent::new(
        damage.source,
        damage.target,
        amount,
        effect.source,
        effect.controller,
        damage.is_combat,
    );
    prevented.prevention_effect = Some(effect.application_key());
    if let Some(snapshot) = damage.target_snapshot.clone() {
        prevented = prevented.with_target_snapshot(snapshot);
    }
    if let ReplacementAction::PreventWithShield { shield_id, .. } = &effect.replacement {
        prevented = prevented.with_prevention_shield(*shield_id);
    }
    game.queue_trigger_event(
        original_event.provenance(),
        crate::triggers::TriggerEvent::new_with_provenance(
            prevented,
            crate::provenance::ProvNodeId::default(),
        ),
    );
    Ok(())
}

pub(super) fn apply_trait_enter_under_control(
    event: &Event,
    controller: PlayerId,
) -> Option<Event> {
    use crate::events::{EnterBattlefieldEvent, ZoneChangeEvent, downcast_event};

    match event.kind() {
        EventKind::EnterBattlefield => {
            let etb = downcast_event::<EnterBattlefieldEvent>(event.inner())?;
            Some(event.rewrap(etb.with_controller_override(controller)))
        }
        EventKind::ZoneChange => {
            let zone_change = downcast_event::<ZoneChangeEvent>(event.inner())?;
            if zone_change.to == Zone::Battlefield {
                Some(
                    event.rewrap(
                        EnterBattlefieldEvent::new(*zone_change.objects.first()?, zone_change.from)
                            .with_controller_override(controller),
                    ),
                )
            } else {
                None
            }
        }
        _ => None,
    }
}

fn indefinite_article(text: &str) -> &'static str {
    let first = text
        .chars()
        .find(|ch| ch.is_ascii_alphabetic())
        .map(|ch| ch.to_ascii_lowercase());
    match first {
        Some('a' | 'e' | 'i' | 'o' | 'u') => "an",
        _ => "a",
    }
}

fn describe_discard_filter_card_phrase(filter: &crate::target::ObjectFilter) -> String {
    let mut phrase = filter.description().trim().to_string();
    if phrase.is_empty() {
        return "a card".to_string();
    }

    let lower = phrase.to_ascii_lowercase();
    let has_determiner = lower.starts_with("a ")
        || lower.starts_with("an ")
        || lower.starts_with("the ")
        || lower.starts_with("target ")
        || lower.starts_with("another ")
        || lower.starts_with("any ")
        || lower.starts_with("each ");
    if !has_determiner {
        phrase = format!("{} {}", indefinite_article(&phrase), phrase);
    }

    let lower = phrase.to_ascii_lowercase();
    if !lower.contains(" card") && !lower.ends_with("card") {
        phrase.push_str(" card");
    }
    phrase
}

fn describe_redirect_zone_phrase(zone: Zone) -> &'static str {
    match zone {
        Zone::Graveyard => "its owner's graveyard",
        Zone::Hand => "its owner's hand",
        Zone::Library => "its owner's library",
        Zone::Battlefield => "the battlefield",
        Zone::Stack => "the stack",
        Zone::Exile => "exile",
        Zone::Command => "the command zone",
        Zone::Ante => "ante",
        Zone::OutsideGame => "outside the game",
    }
}

/// Hand cards offered by an interactive "discard/reveal a X card from your
/// hand" replacement, and whether that choice depends on hidden hand
/// identities (symmetric across peers). When it does, this peer's
/// placeholders stay choosable and the prompt is always shown, so every peer
/// replays the owner's answer; the chosen card is opened publicly before the
/// replay (see `game_state::hidden_hand_choices`).
pub(crate) fn hand_replacement_choice_candidates(
    game: &GameState,
    controller: crate::ids::PlayerId,
    filter: &crate::target::ObjectFilter,
) -> (Vec<crate::ids::ObjectId>, bool) {
    let mut cards = find_matching_cards_in_hand(game, controller, filter);
    let hand: Vec<crate::ids::ObjectId> = game
        .player(controller)
        .map(|p| p.hand.to_vec())
        .unwrap_or_default();
    let hidden = game.hand_choice_depends_on_hidden_identity(filter, hand.iter().copied());
    if hidden {
        let filter_ctx = crate::target::FilterContext::new(controller);
        for id in game.hidden_hand_placeholder_candidates(filter, &filter_ctx, hand) {
            if !cards.contains(&id) {
                cards.push(id);
            }
        }
    }
    (cards, hidden)
}

/// Mark a hidden hand replacement prompt: always asked, and its chosen card
/// opened on every peer before the answer replays.
fn hidden_hand_replacement_context(
    ctx: crate::decisions::context::SelectObjectsContext,
    hidden: bool,
) -> crate::decisions::context::SelectObjectsContext {
    if !hidden {
        return ctx;
    }
    ctx.allow_partial_completion()
        .require_explicit_choice()
        .with_reveal_policy(crate::decisions::context::SelectionRevealPolicy::Public)
}

pub(super) fn find_matching_cards_in_hand(
    game: &GameState,
    controller: crate::ids::PlayerId,
    filter: &crate::target::ObjectFilter,
) -> Vec<crate::ids::ObjectId> {
    use crate::target::FilterContext;

    let filter_ctx = FilterContext::new(controller);
    game.player(controller)
        .map(|p| {
            p.hand
                .iter()
                .filter(|&&card_id| {
                    game.object(card_id)
                        .map(|obj| filter.matches(obj, &filter_ctx, game))
                        .unwrap_or(false)
                })
                .copied()
                .collect()
        })
        .unwrap_or_default()
}

pub(super) fn find_matching_sacrificable_permanents(
    game: &GameState,
    controller: crate::ids::PlayerId,
    source: crate::ids::ObjectId,
    filter: &crate::target::ObjectFilter,
) -> Vec<crate::ids::ObjectId> {
    use crate::target::FilterContext;

    let filter_ctx = FilterContext::new(controller).with_source(source);
    game.battlefield
        .iter()
        .copied()
        .filter(|id| {
            game.object(*id).is_some_and(|object| {
                game.controller_of(object) == controller
                    && game.can_be_sacrificed(*id)
                    && filter.matches(object, &filter_ctx, game)
            })
        })
        .collect()
}

/// A replacement sees every group in the modified event, including arbitrary
/// templates inserted by earlier replacements (CR 616.1).
/// The single permanent a token-copy replacement template names, read from
/// the replacement source's point of view ("enchanted permanent" is the
/// permanent the source Aura is attached to).
fn replacement_copy_template_object(
    game: &GameState,
    effect: &crate::replacement::ReplacementEffect,
    spec: &crate::target::ChooseSpec,
) -> Option<crate::ids::ObjectId> {
    use crate::filter::ObjectFilterExt as _;
    match spec.base() {
        crate::target::ChooseSpec::Tagged(tag)
            if matches!(tag.as_str(), "enchanted" | "equipped" | "fortified") =>
        {
            let source = game.object(effect.source)?;
            (source.zone == Zone::Battlefield)
                .then(|| source.attached_to.as_ref()?.object_id())
                .flatten()
        }
        crate::target::ChooseSpec::Object(filter) => {
            let filter_ctx = game.filter_context_for(effect.controller, Some(effect.source));
            let mut matches = game.battlefield.iter().copied().filter(|id| {
                game.object(*id)
                    .is_some_and(|object| filter.matches(object, &filter_ctx, game))
            });
            let first = matches.next()?;
            matches.next().is_none().then_some(first)
        }
        // A chosen candidate of a filtered copy template (one registered
        // alternative per matching permanent, Esix, Fractal Bloom).
        crate::target::ChooseSpec::SpecificObject(id) => game
            .object(*id)
            .is_some_and(|object| object.zone == Zone::Battlefield)
            .then_some(*id),
        _ => None,
    }
}

fn token_groups_covered<'a>(
    game: &'a GameState,
    effect: &'a ReplacementEffect,
    create_tokens: &'a crate::events::CreateTokensEvent,
) -> impl Fn(crate::events::tokens::TokenGroupKey) -> bool + 'a {
    let filter = effect
        .matcher
        .as_ref()
        .and_then(|matcher| matcher.token_group_filter());
    let filter_ctx = game.filter_context_for(effect.controller, Some(effect.source));
    move |key| {
        filter.is_none_or(|filter| {
            create_tokens
                .group_object(key)
                .is_some_and(|token| filter.matches(&token, &filter_ctx, game))
        })
    }
}

fn apply_trait_add_tokens(
    event: &Event,
    token: ironsmith_core::AdditionalTokenKind,
    count: u32,
) -> Result<Option<Event>, crate::effects::ExecutionError> {
    use crate::events::{CreateTokensEvent, downcast_event};
    if event.kind() != EventKind::CreateTokens || count == 0 {
        return Ok(None);
    }
    let Some(create_tokens) = downcast_event::<CreateTokensEvent>(event.inner()).cloned() else {
        return Ok(None);
    };
    Ok(Some(event.rewrap(
        create_tokens.with_additional_tokens(token, count)?,
    )))
}

fn modify_token_groups_checked(
    game: &GameState,
    effect: &ReplacementEffect,
    tokens: &crate::events::CreateTokensEvent,
    modification: &EventModification,
) -> Result<crate::events::CreateTokensEvent, crate::effects::ExecutionError> {
    let covers = token_groups_covered(game, effect, &tokens);
    match modification {
        EventModification::Multiply(factor) => {
            tokens.scaled_token_groups(covers, |count| u128::from(count) * u128::from(*factor))
        }
        EventModification::Add(delta) => tokens.adjusted_token_total(covers, |total| {
            (i64::from(total) + i64::from(*delta)).max(0) as u128
        }),
        EventModification::Subtract(delta) => {
            tokens.adjusted_token_total(covers, |total| u128::from(total.saturating_sub(*delta)))
        }
        EventModification::SetTo(value) => {
            tokens.adjusted_token_total(covers, |_| u128::from(*value))
        }
        EventModification::SetToAtLeast(value) => {
            let floor = resolve_value_for_replacement(value, game, effect.source);
            tokens.adjusted_token_total(covers, |total| u128::from(total.max(floor)))
        }
        EventModification::ReduceToZero => tokens.adjusted_token_total(covers, |_| 0),
        EventModification::Halve { round_up } => {
            let round_up = *round_up;
            tokens.adjusted_token_total(covers, move |total| {
                u128::from(if round_up { total.div_ceil(2) } else { total / 2 })
            })
        }
        EventModification::LeaveOneCounter => {
            tokens.adjusted_token_total(covers, |total| u128::from(total))
        }
        EventModification::AddDynamic(_) => {
            unreachable!("dynamic modifier normalized before dispatch")
        }
    }
}

include!("damage_result_modification.rs");

/// Shared unsigned quantity policy for count proposals. Specialized damage,
/// life, mana and token transactions retain their own validation policies.
fn modified_count(
    game: &GameState,
    count: u32,
    modification: &EventModification,
    effect: &ReplacementEffect,
) -> u32 {
    match modification {
        EventModification::Multiply(factor) => count.saturating_mul(*factor),
        EventModification::Add(delta) => count.saturating_add_signed(*delta),
        EventModification::Subtract(delta) => count.saturating_sub(*delta),
        EventModification::SetTo(value) => *value,
        EventModification::SetToAtLeast(value) => {
            count.max(resolve_value_for_replacement(value, game, effect.source))
        }
        EventModification::ReduceToZero => 0,
        EventModification::Halve { round_up } => {
            if *round_up { count.div_ceil(2) } else { count / 2 }
        }
        // Needs the target's current counters; see the removal arm below.
        EventModification::LeaveOneCounter => count,
        EventModification::AddDynamic(_) => {
            unreachable!("dynamic modifier normalized before dispatch")
        }
    }
}

fn apply_trait_modification(
    game: &GameState,
    event: &Event,
    modification: &EventModification,
    effect: &ReplacementEffect,
) -> Option<Event> {
    use crate::events::{DrawEvent, downcast_event};

    match event.kind() {
        EventKind::RemoveCounters => {
            let removal = crate::events::CounterRemovalEvent::from_event(event.inner())?;
            let count = if matches!(modification, EventModification::LeaveOneCounter) {
                let current = match removal.target() {
                    crate::game_state::Target::Object(object) => {
                        game.counter_count(object, removal.counter_type())
                    }
                    crate::game_state::Target::Player(_) => removal.count().saturating_add(1),
                };
                removal.count().min(current.saturating_sub(1))
            } else {
                modified_count(game, removal.count(), modification, effect)
            };
            Some(removal.with_count(event, count))
        }
        EventKind::KeywordAction => {
            let action = downcast_event::<crate::events::KeywordActionEvent>(event.inner())?;
            let amount = modified_count(game, action.amount, modification, effect);
            Some(event.rewrap(action.clone().with_amount(amount)))
        }
        EventKind::ManaAdded => {
            use crate::events::ManaAddedEvent;

            let mana_event = downcast_event::<ManaAddedEvent>(event.inner())?;
            let EventModification::Multiply(factor) = modification else {
                return None;
            };
            let mana =
                crate::events::mana::ManaTransformation::Multiply(*factor).apply(&mana_event.mana);
            Some(event.rewrap(mana_event.clone().with_mana(mana)))
        }
        EventKind::Draw => {
            let draw = downcast_event::<DrawEvent>(event.inner())?;
            let modified = draw.with_count(modified_count(game, draw.count, modification, effect));
            Some(event.rewrap(modified))
        }
        _ => None,
    }
}

fn apply_trait_double(event: &Event) -> Option<Event> {
    use crate::events::{DrawEvent, downcast_event};

    match event.kind() {
        EventKind::Draw => {
            let draw = downcast_event::<DrawEvent>(event.inner())?;
            Some(event.rewrap(draw.doubled()))
        }
        _ => None,
    }
}

fn apply_trait_double_counters(
    event: &Event,
    counter_type: Option<CounterType>,
) -> Result<Option<Event>, crate::effects::ExecutionError> {
    use crate::events::{EnterBattlefieldEvent, PutCountersEvent, downcast_event};

    match event.kind() {
        EventKind::PutCounters => {
            let Some(put_counters) = downcast_event::<PutCountersEvent>(event.inner()) else {
                return Ok(None);
            };
            if counter_type.is_none_or(|ct| ct == put_counters.counter_type) {
                Ok(Some(event.rewrap(
                    put_counters.with_count(
                        crate::events::damage::checked_damage_amount(
                            put_counters.maximum_count.map_or(
                                u128::from(put_counters.count) * 2,
                                |maximum| {
                                    (u128::from(put_counters.count) * 2).min(u128::from(maximum))
                                },
                            ),
                            "doubled counter result",
                        )?,
                    ),
                )))
            } else {
                Ok(None)
            }
        }
        EventKind::EnterBattlefield => {
            let Some(etb) = downcast_event::<EnterBattlefieldEvent>(event.inner()) else {
                return Ok(None);
            };
            let mut doubled = etb.clone();
            let mut changed = false;
            for (existing_type, count) in &mut doubled.enters_with_counters {
                if counter_type.is_none_or(|ct| ct == *existing_type) {
                    *count = crate::events::damage::checked_damage_amount(
                        u128::from(*count) * 2,
                        "doubled entry counters",
                    )?;
                    changed = true;
                }
            }
            Ok(changed.then(|| event.rewrap(doubled)))
        }
        _ => Ok(None),
    }
}

fn apply_trait_halve_counters(event: &Event, counter_type: Option<CounterType>) -> Option<Event> {
    use crate::events::{EnterBattlefieldEvent, PutCountersEvent, downcast_event};

    match event.kind() {
        EventKind::PutCounters => {
            let put_counters = downcast_event::<PutCountersEvent>(event.inner())?;
            if counter_type.is_none_or(|ct| ct == put_counters.counter_type) {
                Some(event.rewrap(put_counters.with_count(put_counters.count / 2)))
            } else {
                None
            }
        }
        EventKind::EnterBattlefield => {
            let etb = downcast_event::<EnterBattlefieldEvent>(event.inner())?;
            let mut halved = etb.clone();
            let mut changed = false;
            for (existing_type, count) in &mut halved.enters_with_counters {
                if counter_type.is_none_or(|ct| ct == *existing_type) {
                    *count /= 2;
                    changed = true;
                }
            }
            changed.then(|| event.rewrap(halved))
        }
        _ => None,
    }
}

fn apply_trait_add_counters_to_placement(
    event: &Event,
    counter_type: Option<CounterType>,
    additional: i64,
) -> Result<Option<Event>, crate::effects::ExecutionError> {
    use crate::events::{EnterBattlefieldEvent, PutCountersEvent, downcast_event};

    match event.kind() {
        EventKind::PutCounters => {
            let Some(put_counters) = downcast_event::<PutCountersEvent>(event.inner()) else {
                return Ok(None);
            };
            if counter_type.is_none_or(|ct| ct == put_counters.counter_type)
                && put_counters.count > 0
            {
                let total =
                    (i128::from(put_counters.count) + i128::from(additional)).max(0) as u128;
                let total = put_counters
                    .maximum_count
                    .map_or(total, |maximum| total.min(u128::from(maximum)));
                Ok(Some(event.rewrap(put_counters.with_count(
                    crate::events::damage::checked_damage_amount(total, "counter result addition")?,
                ))))
            } else {
                Ok(None)
            }
        }
        EventKind::EnterBattlefield => {
            let Some(etb) = downcast_event::<EnterBattlefieldEvent>(event.inner()) else {
                return Ok(None);
            };
            let mut increased = etb.clone();
            // Multiple contributions to one counter type are a single
            // placement. Apply the additive adjustment once to that total.
            let mut counters: Vec<(CounterType, u32)> = Vec::new();
            for (kind, count) in increased.enters_with_counters.drain(..) {
                if let Some((_, total)) =
                    counters.iter_mut().find(|(existing, _)| *existing == kind)
                {
                    *total = crate::events::damage::checked_damage_amount(
                        u128::from(*total) + u128::from(count),
                        "entry counter total",
                    )?;
                } else {
                    counters.push((kind, count));
                }
            }
            increased.enters_with_counters = counters;
            let mut changed = false;
            for (existing_type, count) in &mut increased.enters_with_counters {
                if *count > 0 && counter_type.is_none_or(|ct| ct == *existing_type) {
                    *count = crate::events::damage::checked_damage_amount(
                        (i128::from(*count) + i128::from(additional)).max(0) as u128,
                        "entry counter addition",
                    )?;
                    changed = true;
                }
            }
            Ok(changed.then(|| event.rewrap(increased)))
        }
        _ => Ok(None),
    }
}

fn apply_trait_set_player_counters_and_lock_for_turn(
    game: &mut GameState,
    event: &Event,
    counter_type: CounterType,
    amount: u32,
) -> Option<Event> {
    use crate::events::{PutCountersEvent, downcast_event};

    if event.kind() != EventKind::PutCounters {
        return None;
    }
    let put_counters = downcast_event::<PutCountersEvent>(event.inner())?;
    let crate::game_state::Target::Player(player) = put_counters.target else {
        return None;
    };
    if put_counters.counter_type != counter_type || put_counters.count == 0 {
        return None;
    }

    game.turn_store
        .turn_history
        .lock_player_counter_for_turn(player, counter_type);
    Some(event.rewrap(put_counters.with_count_limit(amount, amount)))
}

pub(super) fn apply_trait_change_destination(event: &Event, new_zone: Zone) -> Option<Event> {
    use crate::events::{DiscardEvent, EnterBattlefieldEvent, ZoneChangeEvent, downcast_event};

    match event.kind() {
        EventKind::Discard => {
            let discard = downcast_event::<DiscardEvent>(event.inner())?;
            Some(event.rewrap(discard.with_destination(new_zone)))
        }
        EventKind::ZoneChange => {
            let zone_change = downcast_event::<ZoneChangeEvent>(event.inner())?;
            Some(event.rewrap(zone_change.with_destination(new_zone)))
        }
        EventKind::EnterBattlefield => {
            let etb = downcast_event::<EnterBattlefieldEvent>(event.inner())?;
            Some(event.rewrap(ZoneChangeEvent::with_cause(
                etb.object,
                etb.from,
                new_zone,
                crate::events::cause::EventCause::effect(),
                None,
            )))
        }
        _ => None,
    }
}

pub(super) fn apply_trait_enter_tapped(event: &Event) -> Option<Event> {
    use crate::events::{EnterBattlefieldEvent, ZoneChangeEvent, downcast_event};

    match event.kind() {
        EventKind::EnterBattlefield => {
            let etb = downcast_event::<EnterBattlefieldEvent>(event.inner())?;
            Some(event.rewrap(etb.with_tapped()))
        }
        EventKind::ZoneChange => {
            let zone_change = downcast_event::<ZoneChangeEvent>(event.inner())?;
            if zone_change.to == Zone::Battlefield {
                Some(event.rewrap(EnterBattlefieldEvent::tapped(
                    *zone_change.objects.first()?,
                    zone_change.from,
                )))
            } else {
                None
            }
        }
        _ => None,
    }
}

fn apply_trait_enter_untapped(event: &Event) -> Option<Event> {
    use crate::events::{EnterBattlefieldEvent, ZoneChangeEvent, downcast_event};

    match event.kind() {
        EventKind::EnterBattlefield => {
            let etb = downcast_event::<EnterBattlefieldEvent>(event.inner())?;
            let mut untapped = etb.clone();
            untapped.enters_tapped = false;
            Some(event.rewrap(untapped))
        }
        EventKind::ZoneChange => {
            let zone_change = downcast_event::<ZoneChangeEvent>(event.inner())?;
            if zone_change.to == Zone::Battlefield {
                Some(event.rewrap(EnterBattlefieldEvent::new(
                    *zone_change.objects.first()?,
                    zone_change.from,
                )))
            } else {
                None
            }
        }
        _ => None,
    }
}

pub(super) fn apply_trait_enter_with_counters(
    event: &Event, counter_type: CounterType, count: u32,
    added_subtypes: &[crate::types::Subtype], added_abilities: &[crate::ability::Ability],
) -> Option<Event> {
    apply_trait_enter_with_counter_entries(event, &[(counter_type, count)], added_subtypes, added_abilities)
}

fn apply_trait_enter_with_counter_entries(
    event: &Event, counters: &[(CounterType, u32)],
    added_subtypes: &[crate::types::Subtype], added_abilities: &[crate::ability::Ability],
) -> Option<Event> {
    use crate::events::{EnterBattlefieldEvent, ZoneChangeEvent, downcast_event};
    let mut entering = match event.kind() {
        EventKind::EnterBattlefield => downcast_event::<EnterBattlefieldEvent>(event.inner())?.clone(),
        EventKind::ZoneChange => {
            let change = downcast_event::<ZoneChangeEvent>(event.inner())?;
            if change.to != Zone::Battlefield { return None; }
            EnterBattlefieldEvent::new(*change.objects.first()?, change.from)
        },
        _ => return None,
    };
    for (kind, count) in counters { entering = entering.with_counters(*kind, *count); }
    Some(event.rewrap(entering.with_added_subtypes(added_subtypes).with_added_abilities(added_abilities)))
}

fn apply_trait_enter_as_copy(
    event: &Event,
    source_id: crate::ids::ObjectId,
    enters_tapped: bool,
    copy_duration: Option<crate::effect::Until>,
    linked_exile_objects: &[crate::ids::ObjectId],
    additional_counters: &[(CounterType, u32)],
    name_override: Option<String>,
    added_colors: crate::color::ColorSet,
    added_card_types: &[crate::types::CardType],
    removes_other_card_types: bool,
    added_supertypes: &[crate::types::Supertype],
    removed_supertypes: &[crate::types::Supertype],
    added_subtypes: &[crate::types::Subtype],
    added_abilities: &[crate::ability::Ability],
    set_base_power_toughness: Option<(i32, i32)>,
    copy_followups: &[ironsmith_core::EnterAsCopyFollowup],
) -> Option<Event> {
    use crate::events::{EnterBattlefieldEvent, ZoneChangeEvent, downcast_event};

    let apply_copy_modifiers = |mut etb: EnterBattlefieldEvent| {
        // CR 707.9e: a later copy effect replaces an earlier copy choice; the
        // earlier choice's exceptions and additional effects no longer apply.
        if etb.enters_as_copy_of.is_some() {
            etb.discard_prior_copy_exceptions();
        }
        let abilities_before = etb.added_abilities.len();
        let tapped_before = etb.enters_tapped;
        let contribution = crate::events::zones::CopyExceptionContribution {
            counters: additional_counters.to_vec(),
            linked_exile: linked_exile_objects
                .iter()
                .copied()
                .filter(|id| !etb.linked_exile_with_entering.contains(id))
                .collect(),
            card_types: added_card_types
                .iter()
                .copied()
                .filter(|t| !etb.added_card_types.contains(t))
                .collect(),
            subtypes: added_subtypes
                .iter()
                .copied()
                .filter(|t| !etb.added_subtypes.contains(t))
                .collect(),
            supertypes: added_supertypes
                .iter()
                .copied()
                .filter(|t| !etb.added_supertypes.contains(t))
                .collect(),
            removed_supertypes: removed_supertypes
                .iter()
                .copied()
                .filter(|t| !etb.removed_supertypes.contains(t))
                .collect(),
            base_power_toughness: set_base_power_toughness,
            removes_other_card_types: removes_other_card_types && !etb.removes_other_card_types,
            added_ability_count: 0,
            enters_tapped: enters_tapped && !tapped_before,
        };
        etb = etb
            .with_copy_of(source_id)
            .with_copy_followups(copy_followups)
            .with_copy_duration(copy_duration.clone())
            .with_linked_exile_objects(linked_exile_objects)
            .with_copy_name_override(name_override.clone())
            .with_added_colors(added_colors)
            .with_added_card_types(added_card_types)
            .with_removes_other_card_types(removes_other_card_types)
            .with_added_supertypes(added_supertypes)
            .with_removed_supertypes(removed_supertypes)
            .with_added_subtypes(added_subtypes)
            .with_added_abilities(added_abilities);
        if let Some((power, toughness)) = set_base_power_toughness {
            etb = etb.with_base_power_toughness(power, toughness);
        }
        for (counter_type, count) in additional_counters {
            etb = etb.with_counters(*counter_type, *count);
        }
        if enters_tapped {
            etb = etb.with_tapped();
        }
        let mut contribution = contribution;
        contribution.added_ability_count = etb.added_abilities.len() - abilities_before;
        etb.prior_copy_exceptions = Some(Box::new(contribution));
        etb
    };

    match event.kind() {
        EventKind::EnterBattlefield => {
            let etb = downcast_event::<EnterBattlefieldEvent>(event.inner())?;
            Some(event.rewrap(apply_copy_modifiers(etb.clone())))
        }
        EventKind::ZoneChange => {
            let zone_change = downcast_event::<ZoneChangeEvent>(event.inner())?;
            if zone_change.to == Zone::Battlefield {
                Some(
                    event.rewrap(apply_copy_modifiers(EnterBattlefieldEvent::new(
                        *zone_change.objects.first()?,
                        zone_change.from,
                    ))),
                )
            } else {
                None
            }
        }
        _ => None,
    }
}

fn apply_trait_enter_with_characteristics(
    event: &Event,
    face_down: bool,
    added_card_types: &[crate::types::CardType],
    added_subtypes: &[crate::types::Subtype],
    set_base_power_toughness: Option<(i32, i32)>,
) -> Option<Event> {
    use crate::events::{EnterBattlefieldEvent, ZoneChangeEvent, downcast_event};

    let apply = |mut etb: EnterBattlefieldEvent| {
        etb.enters_face_down |= face_down;
        etb = etb
            .with_added_card_types(added_card_types)
            .with_added_subtypes(added_subtypes);
        if let Some((power, toughness)) = set_base_power_toughness {
            etb = etb.with_base_power_toughness(power, toughness);
        }
        etb
    };

    match event.kind() {
        EventKind::EnterBattlefield => {
            let etb = downcast_event::<EnterBattlefieldEvent>(event.inner())?;
            Some(event.rewrap(apply(etb.clone())))
        }
        EventKind::ZoneChange => {
            let zone_change = downcast_event::<ZoneChangeEvent>(event.inner())?;
            if zone_change.to == Zone::Battlefield {
                Some(event.rewrap(apply(EnterBattlefieldEvent::new(
                    *zone_change.objects.first()?,
                    zone_change.from,
                ))))
            } else {
                None
            }
        }
        _ => None,
    }
}

fn apply_trait_redirect(
    game: &GameState,
    event: &Event,
    redirect_target: &RedirectTarget,
    which: &RedirectWhich,
    effect_controller: PlayerId,
) -> Option<Event> {
    let new_target =
        resolve_trait_redirect_target(game, event, redirect_target, which, effect_controller)?;
    let redirectable = event.inner().redirectable_targets();
    let selected = match which {
        RedirectWhich::First => redirectable.first(),
        RedirectWhich::Index(idx) => redirectable.get(*idx),
        RedirectWhich::ByDescription(desc) => {
            redirectable.iter().find(|t| t.description == desc.as_str())
        }
    }?;
    let new_event_box = event
        .inner()
        .with_target_replaced(&selected.target, &new_target)?;
    Some(event.rewrap_boxed(new_event_box))
}

pub(super) fn resolve_trait_redirect_target(
    game: &GameState,
    event: &Event,
    redirect_target: &RedirectTarget,
    which: &RedirectWhich,
    effect_controller: PlayerId,
) -> Option<Target> {
    let redirectable = event.inner().redirectable_targets();
    let selected = match which {
        RedirectWhich::First => redirectable.first(),
        RedirectWhich::Index(idx) => redirectable.get(*idx),
        RedirectWhich::ByDescription(desc) => {
            redirectable.iter().find(|t| t.description == desc.as_str())
        }
    }?;

    // CR 614.9 constrains both ends, not merely the new recipient.
    if crate::events::downcast_event::<crate::events::DamageEvent>(event.inner()).is_some() {
        let original_valid = match selected.target {
            Target::Player(player) => game
                .player(player)
                .is_some_and(|player| player.is_in_game()),
            Target::Object(object) => {
                game.object(object)
                    .is_some_and(|object| object.zone == Zone::Battlefield)
                    && !game.is_phased_out(object)
                    && [
                        crate::types::CardType::Creature,
                        crate::types::CardType::Planeswalker,
                        crate::types::CardType::Battle,
                    ]
                    .into_iter()
                    .any(|kind| game.current_has_card_type(object, kind))
            }
        };
        if !original_valid {
            return None;
        }
    }

    let new_target = match redirect_target {
        RedirectTarget::ToController => Target::Player(effect_controller),
        RedirectTarget::ToPlayer(player_id) => Target::Player(*player_id),
        RedirectTarget::ToObject(object_id) => Target::Object(*object_id),
        RedirectTarget::ToSource => Target::Object(event.inner().source_object()?),
        RedirectTarget::ToSourceController => {
            let source = event.inner().source_object()?;
            let controller = if game.object(source).is_some() && !game.is_phased_out(source) {
                game.current_controller(source)
            } else {
                game.source_last_known_snapshot(source)
                    .or_else(|| event.0.source_snapshot())
                    .filter(|snapshot| snapshot.object_id == source)
                    .map(|snapshot| snapshot.controller)
            }?;
            Target::Player(controller)
        }
        RedirectTarget::ToAttachedPermanent(source) => match game.object(*source)?.attached_to? {
            crate::object::AttachmentTarget::Object(object) => Target::Object(object),
            crate::object::AttachmentTarget::Player(_) => return None,
        },
        RedirectTarget::ToRecipientController => {
            let Target::Object(recipient) = selected.target else {
                return None;
            };
            Target::Player(game.current_controller(recipient)?)
        }
    };

    if !selected.valid_redirect_types.is_valid(&new_target) {
        return None;
    }
    // CR 614.9: if the permanent the event would be redirected to is no
    // longer on the battlefield (or, for damage, is no longer a battle,
    // creature, or planeswalker), or the player has left the game, the
    // redirection does nothing and the event keeps its original recipient.
    match new_target {
        Target::Player(player_id) => {
            if !game
                .player(player_id)
                .is_some_and(|player| player.is_in_game())
            {
                return None;
            }
        }
        Target::Object(object_id) => {
            let on_battlefield = game
                .object(object_id)
                .is_some_and(|object| object.zone == crate::zone::Zone::Battlefield)
                && !game.is_phased_out(object_id);
            if !on_battlefield {
                return None;
            }
            let is_damage =
                crate::events::downcast_event::<crate::events::DamageEvent>(event.inner())
                    .is_some();
            if is_damage
                && ![
                    crate::types::CardType::Creature,
                    crate::types::CardType::Planeswalker,
                    crate::types::CardType::Battle,
                ]
                .into_iter()
                .any(|card_type| game.current_has_card_type(object_id, card_type))
            {
                return None;
            }
        }
    }
    Some(new_target)
}

fn resolve_value_for_etb(
    count: &crate::effect::Value,
    game: &GameState,
    source: crate::ids::ObjectId,
) -> u32 {
    resolve_value_for_replacement(count, game, source)
}

fn etb_value_uses_entering_object(value: &crate::effect::Value) -> bool {
    match value.unhinted() {
        crate::effect::Value::ManaSpentToCastThisSpell
        | crate::effect::Value::ManaFromSourceSpentToCastThisSpell { .. }
        | crate::effect::Value::ColorsOfManaSpentToCastThisSpell => true,
        crate::effect::Value::PowerOf(spec)
        | crate::effect::Value::ToughnessOf(spec)
        | crate::effect::Value::ManaValueOf(spec)
        | crate::effect::Value::CommanderCastCountOf(spec)
        | crate::effect::Value::CountersOn(spec, _)
            if matches!(spec.base(), crate::target::ChooseSpec::Source) =>
        {
            true
        }
        crate::effect::Value::Add(left, right) | crate::effect::Value::Min(left, right) => {
            etb_value_uses_entering_object(left) || etb_value_uses_entering_object(right)
        }
        crate::effect::Value::Scaled(inner, _)
        | crate::effect::Value::DividedRoundedDown(inner, _)
        | crate::effect::Value::HalfRoundedDown(inner) => etb_value_uses_entering_object(inner),
        _ => false,
    }
}

pub(super) fn resolve_value_for_etb_for_choice(
    count: &crate::effect::Value,
    game: &GameState,
    source: crate::ids::ObjectId,
) -> u32 {
    resolve_value_for_etb(count, game, source)
}

/// Dynamic additions keep the replacement controller, even when its source has
/// changed control since a resolving registration. Missing/oversized values
/// propagate to the enclosing replacement transaction instead of becoming zero.
fn resolve_signed_value_for_replacement(
    value: &crate::effect::Value,
    game: &GameState,
    effect: &ReplacementEffect,
) -> Result<i32, crate::effects::ExecutionError> {
    game.try_all_continuous_effects_arc()
        .map_err(crate::effects::ExecutionError::ContinuousDiscovery)?;
    let mut dm = crate::decision::SelectFirstDecisionMaker;
    let mut ctx = crate::effects::ExecutionContext::new(effect.source, effect.controller, &mut dm);
    if let Some(object) = game.object(effect.source) {
        ctx.x_value = object.own_entry_x_value();
        ctx.optional_costs_paid = object.optional_costs_paid.clone();
        ctx = ctx.with_tagged_objects(object.cast_tagged_objects.clone());
    }
    crate::effects::helpers::resolve_value(game, value, &ctx)
}

fn resolve_value_for_replacement(
    count: &crate::effect::Value,
    game: &GameState,
    source: crate::ids::ObjectId,
) -> u32 {
    let controller = game
        .object(source)
        .map(|o| game.controller_of(o))
        .unwrap_or(crate::ids::PlayerId::from_index(0));

    let mut dm = crate::decision::SelectFirstDecisionMaker;
    let mut ctx = crate::effects::ExecutionContext::new(source, controller, &mut dm);

    if let Some(source_obj) = game.object(source) {
        // CR 107.3m: without a cast, the X in the object's own mana cost is 0.
        ctx.x_value = source_obj.own_entry_x_value();
        ctx.optional_costs_paid = source_obj.optional_costs_paid.clone();
        if !source_obj.cast_tagged_objects.is_empty() {
            ctx = ctx.with_tagged_objects(source_obj.cast_tagged_objects.clone());
        }
    }

    crate::effects::helpers::resolve_value(game, count, &ctx)
        .unwrap_or(0)
        .max(0) as u32
}

fn resolve_value_for_replacement_checked(
    count: &crate::effect::Value,
    game: &GameState,
    source: crate::ids::ObjectId,
) -> Result<u32, crate::effects::ExecutionError> {
    let controller = game
        .object(source)
        .map(|o| game.controller_of(o))
        .unwrap_or(crate::ids::PlayerId::from_index(0));

    let mut dm = crate::decision::SelectFirstDecisionMaker;
    let mut ctx = crate::effects::ExecutionContext::new(source, controller, &mut dm);

    if let Some(source_obj) = game.object(source) {
        // CR 107.3m: without a cast, the X in the object's own mana cost is 0.
        ctx.x_value = source_obj.own_entry_x_value();
        ctx.optional_costs_paid = source_obj.optional_costs_paid.clone();
        if !source_obj.cast_tagged_objects.is_empty() {
            ctx = ctx.with_tagged_objects(source_obj.cast_tagged_objects.clone());
        }
    }

    Ok(crate::effects::helpers::resolve_value(game, count, &ctx)?.max(0) as u32)
}

/// A count of the as-enters revealed collection needs the prepared choice.
fn etb_value_reads_entering_pt(value: &crate::effect::Value) -> bool {
    use crate::effect::Value;
    match value.unhinted() {
        Value::SourcePower | Value::SourceToughness => true,
        Value::PowerOf(spec) | Value::ToughnessOf(spec)
            if matches!(spec.base(), crate::target::ChooseSpec::Source) =>
        {
            true
        }
        Value::Add(a, b) | Value::Min(a, b) => {
            etb_value_reads_entering_pt(a) || etb_value_reads_entering_pt(b)
        }
        Value::Scaled(inner, _)
        | Value::DividedRoundedDown(inner, _)
        | Value::HalfRoundedDown(inner) => etb_value_reads_entering_pt(inner),
        _ => false,
    }
}

pub(super) fn etb_value_uses_revealed_choice(value: &crate::effect::Value) -> bool {
    use crate::effect::Value;
    match value.unhinted() {
        Value::Count(filter) => filter
            .tagged_constraints
            .iter()
            .any(|constraint| constraint.tag.as_str() == crate::effects::PUBLIC_REVEALED_TAG),
        Value::Add(a, b) | Value::Min(a, b) => {
            etb_value_uses_revealed_choice(a) || etb_value_uses_revealed_choice(b)
        }
        Value::Scaled(inner, _)
        | Value::DividedRoundedDown(inner, _)
        | Value::HalfRoundedDown(inner) => etb_value_uses_revealed_choice(inner),
        _ => false,
    }
}

/// CR 702.44a: choose the counter kind from the entering object's base
/// characteristics, ignoring continuous type-changing effects.
fn sunburst_entry_counter_type(
    game: &GameState,
    event: &Event,
    entering_object: crate::ids::ObjectId,
    counter_type: CounterType,
    count: &crate::effect::Value,
) -> CounterType {
    if !matches!(
        counter_type,
        CounterType::PlusOnePlusOne | CounterType::Charge
    ) || !matches!(
        count.unhinted(),
        crate::effect::Value::ColorsOfManaSpentToCastThisSpell
    ) {
        return counter_type;
    }
    let is_sunburst_marker = |ability: &crate::ability::Ability| {
        matches!(&ability.kind, crate::ability::AbilityKind::Static(static_ability)
            if matches!(static_ability.keyword_marker_mechanic(),
                Some(ironsmith_core::KeywordMarkerMechanic::Sunburst | ironsmith_core::KeywordMarkerMechanic::EntryCountersFromSpentColors)))
    };
    if !game
        .object(entering_object)
        .is_some_and(|object| object.abilities.iter().any(is_sunburst_marker))
    {
        return counter_type;
    }
    let prospective =
        crate::events::downcast_event::<crate::events::EnterBattlefieldEvent>(event.inner())
            .filter(|etb| etb.object == entering_object)
            .and_then(|etb| etb.prospective_game_state(game));
    // CR 702.44a ignores type-changing effects, but observes a copy
    // replacement's base characteristics in the prospective entry state.
    let enters_as_creature = prospective.as_ref().unwrap_or(game)
        .object(entering_object)
        .is_some_and(|object| object.card_types.contains(&crate::types::CardType::Creature));
    if enters_as_creature {
        CounterType::PlusOnePlusOne
    } else {
        CounterType::Charge
    }
}

/// Retain the prevention source even if another assignment removes it before
/// the additional effect executes after the simultaneous damage event.
fn queue_prevention_follow_up(
    game: &mut GameState,
    follow_up: crate::prevention::PreventionFollowUp,
    damage: crate::events::DamageEvent,
    provenance: crate::provenance::ProvNodeId,
    event_source_snapshot: Option<&crate::snapshot::ObjectSnapshot>,
) {
    let damage_source_snapshot = game
        .object(damage.source)
        .filter(|_| !game.is_phased_out(damage.source))
        .map(|object| {
            crate::snapshot::ObjectSnapshot::from_object_with_calculated_characteristics(
                object, game,
            )
        })
        .or_else(|| {
            event_source_snapshot
                .filter(|snapshot| snapshot.object_id == damage.source)
                .cloned()
        })
        .or_else(|| game.source_last_known_snapshot(damage.source).cloned());
    let source_snapshot = game
        .object(follow_up.source)
        .filter(|_| !game.is_phased_out(follow_up.source))
        .map(|object| {
            crate::snapshot::ObjectSnapshot::from_object_with_calculated_characteristics(
                object, game,
            )
        })
        .or_else(|| game.source_last_known_snapshot(follow_up.source).cloned());
    game.effect_store
        .prevention_effects
        .queue_follow_up_with_snapshots(
            follow_up,
            damage,
            provenance,
            source_snapshot,
            damage_source_snapshot,
        );
}
#[cfg(test)]
mod quantitative_addition_range_tests {

    fn event_for(
        family: u8,
        source: crate::ids::ObjectId,
        player: crate::ids::PlayerId,
        amount: u32,
    ) -> crate::events::Event {
        match family {
            0 => crate::events::Event::damage(
                source,
                crate::events::DamageTarget::Player(player),
                amount,
                false,
                crate::events::EventCause::effect(),
            ),
            1 => crate::events::Event::life_gain(player, amount),
            2 => crate::events::Event::put_counters(
                source,
                crate::object::CounterType::Charge,
                amount,
                crate::events::EventCause::effect(),
            ),
            _ => crate::events::Event::draw(player, amount, false),
        }
    }
    fn quantity(family: u8, event: &crate::events::Event) -> u32 {
        match family {
            0 => {
                crate::events::downcast_event::<crate::events::DamageEvent>(event.inner())
                    .unwrap()
                    .amount
            }
            1 => {
                crate::events::downcast_event::<crate::events::LifeGainEvent>(event.inner())
                    .unwrap()
                    .amount
            }
            2 => {
                crate::events::downcast_event::<crate::events::PutCountersEvent>(event.inner())
                    .unwrap()
                    .count
            }
            _ => {
                crate::events::downcast_event::<crate::events::DrawEvent>(event.inner())
                    .unwrap()
                    .count
            }
        }
    }
    fn resolved(result: crate::events::processing::TraitEventResult) -> crate::events::Event {
        match result {
            crate::events::processing::TraitEventResult::Proceed(event)
            | crate::events::processing::TraitEventResult::Modified(event) => event,
            _ => panic!("numeric modification must yield a resolved typed event"),
        }
    }
    fn check(family: u8, amount: u32, delta: i32, expected: u32) {
        let mut game = crate::tests::test_helpers::setup_two_player_game();
        let alice = crate::ids::PlayerId::from_index(0);
        let definition = crate::cards::CardDefinitionBuilder::new(
            crate::ids::CardId::new(),
            "Quantitative range source",
        )
        .card_types(vec![crate::types::CardType::Artifact])
        .build();
        let source =
            game.create_object_from_definition(&definition, alice, crate::zone::Zone::Battlefield);
        let action = crate::replacement::ReplacementAction::Modify(
            crate::replacement::EventModification::Add(delta),
        );
        let effect = match family {
            0 => crate::replacement::ReplacementEffect::with_matcher(
                source,
                alice,
                crate::events::damage::matchers::DamageToPlayerMatcher::to_you(),
                action,
            ),
            1 => crate::replacement::ReplacementEffect::with_matcher(
                source,
                alice,
                crate::events::life::matchers::WouldGainLifeMatcher::you(),
                action,
            ),
            2 => crate::replacement::ReplacementEffect::with_matcher(
                source,
                alice,
                crate::events::counters::matchers::WouldPutCountersMatcher::any(),
                action,
            ),
            _ => crate::replacement::ReplacementEffect::with_matcher(
                source,
                alice,
                crate::events::cards::matchers::WouldDrawCardMatcher::you(),
                action,
            ),
        };
        let shield = game
            .effect_store
            .replacement_effects
            .add_one_shot_effect(effect);
        let mut dm = crate::decision::SelectFirstDecisionMaker;
        let result = crate::events::processing::process_with_dm(
            &mut game,
            event_for(family, source, alice, amount),
            &mut dm,
        );
        if family != 3 && i64::from(amount) + i64::from(delta) > i64::from(u32::MAX) {
            assert!(
                matches!(
                    result,
                    Err(crate::effects::ExecutionError::ResourceLimitExceeded {
                        requested: 4294967296,
                        maximum: 4294967295,
                        ..
                    })
                ),
                "{result:?}"
            );
            assert!(
                game.effect_store
                    .replacement_effects
                    .get_effect(shield)
                    .is_some()
            );
            return;
        }
        let result = result.unwrap();
        assert_eq!(
            quantity(family, &resolved(result)),
            expected,
            "replacement addition must preserve the unsigned carrier range"
        );
        assert_eq!(
            game.effect_store
                .replacement_effects
                .get_effect(shield)
                .is_none(),
            amount > 0
        );
        // This processor fixture resolves a proposal; it does not claim a physical
        // world commit of quantities outside the owning outcome's supported range.
        assert_eq!(game.player(alice).unwrap().life, 20);
        assert_eq!(
            game.counter_count(source, crate::object::CounterType::Charge),
            0
        );
        if amount > 0 {
            let next = crate::events::processing::process_with_dm(
                &mut game,
                event_for(family, source, alice, 2),
                &mut dm,
            )
            .unwrap();
            assert_eq!(
                quantity(family, &resolved(next)),
                2,
                "consumed one-shot must not modify the next event"
            );
        }
    }
    #[test]
    fn damage_add_zero_preserves_large_unsigned_amount() {
        check(0, u32::MAX, 0, u32::MAX);
    }
    #[test]
    fn life_gain_add_zero_preserves_large_unsigned_amount() {
        check(1, u32::MAX, 0, u32::MAX);
    }
    #[test]
    fn counter_add_zero_preserves_large_unsigned_count() {
        check(2, u32::MAX, 0, u32::MAX);
    }
    #[test]
    fn draw_add_zero_preserves_large_unsigned_count() {
        check(3, u32::MAX, 0, u32::MAX);
    }
    #[test]
    fn damage_add_one_crosses_signed_boundary_without_panicking() {
        check(0, i32::MAX as u32, 1, i32::MAX as u32 + 1);
    }
    #[test]
    fn life_gain_add_one_crosses_signed_boundary_without_panicking() {
        check(1, i32::MAX as u32, 1, i32::MAX as u32 + 1);
    }
    #[test]
    fn counter_add_one_crosses_signed_boundary_without_panicking() {
        check(2, i32::MAX as u32, 1, i32::MAX as u32 + 1);
    }
    #[test]
    fn draw_add_one_crosses_signed_boundary_without_panicking() {
        check(3, i32::MAX as u32, 1, i32::MAX as u32 + 1);
    }
    #[test]
    fn unsigned_addition_overflow_negative_and_zero_controls() {
        for family in 0..4 {
            check(family, u32::MAX, 1, u32::MAX);
            check(family, u32::MAX, -1, u32::MAX - 1);
            check(family, 1, i32::MIN, 0);
            check(family, 0, i32::MAX, 0);
            check(family, 2, -1, 1);
        }
    }
}

#[cfg(test)]
mod counter_kind_entry_projection_tests {
    use super::*;
    #[test]
    fn counter_kind_entry_projection_preserves_prior_metadata_and_empty_kind_sets() {
        use crate::events::{EnterBattlefieldEvent, ZoneChangeEvent, downcast_event};
        use crate::ids::ObjectId;
        use crate::types::Subtype;
        let id = ObjectId::from_raw(1);
        let donor = ObjectId::from_raw(2);
        let proposal = EnterBattlefieldEvent::new(id, Zone::Hand).with_tapped()
            .with_copy_of(donor).with_counters(CounterType::Charge, 3)
            .with_added_subtypes(&[Subtype::Vehicle]);
        let event = Event::new_with_provenance(proposal, crate::ProvNodeId::default());
        for entries in [vec![], vec![(CounterType::Charge, 1), (CounterType::Flying, 1)]] {
            let changed = apply_trait_enter_with_counter_entries(&event, &entries, &[Subtype::Dinosaur], &[]).unwrap();
            let etb = downcast_event::<EnterBattlefieldEvent>(changed.inner()).unwrap();
            assert_eq!(etb.object, id);
            assert_eq!(etb.from, Zone::Hand);
            assert!(etb.enters_tapped);
            assert_eq!(etb.enters_as_copy_of, Some(donor));
            assert!(etb.added_subtypes.contains(&Subtype::Vehicle));
            assert!(etb.added_subtypes.contains(&Subtype::Dinosaur));
            assert_eq!(etb.enters_with_counters.iter().find(|(kind, _)| *kind == CounterType::Charge).unwrap().1, if entries.is_empty() { 3 } else { 4 });
            assert_eq!(etb.enters_with_counters.iter().any(|(kind, _)| *kind == CounterType::Flying), !entries.is_empty());
            assert_eq!(changed.provenance(), event.provenance());
        }
        for destination in [Zone::Battlefield, Zone::Graveyard] {
            let zone = Event::new_with_provenance(ZoneChangeEvent::with_cause(id, Zone::Hand, destination, crate::events::EventCause::effect(), None), crate::ProvNodeId::default());
            let projected = apply_trait_enter_with_counter_entries(&zone, &[], &[], &[]);
            assert_eq!(projected.is_some(), destination == Zone::Battlefield);
            if let Some(projected) = projected {
                assert!(downcast_event::<EnterBattlefieldEvent>(projected.inner()).unwrap().enters_with_counters.is_empty());
            }
        }
        let legacy = apply_trait_enter_with_counters(&event, CounterType::Charge, 2, &[], &[]).unwrap();
        assert_eq!(downcast_event::<EnterBattlefieldEvent>(legacy.inner()).unwrap().enters_with_counters, vec![(CounterType::Charge, 5)]);
    }
}
