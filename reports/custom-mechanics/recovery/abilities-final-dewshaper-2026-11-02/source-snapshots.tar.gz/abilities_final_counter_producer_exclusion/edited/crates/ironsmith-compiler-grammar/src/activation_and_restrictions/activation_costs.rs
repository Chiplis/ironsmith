use super::*;
use crate::grammar::activation_costs::cant_shapes::{
    self, AttackUnlessScope, AttackUnlessSurface, BlockingCantFact, CantFallbackFact,
    DirectCantFact, ManaValueParityCantFact,
};

enum StaticAbilityShapeResolution {
    Ability(StaticAbility),
    Decline,
}

fn direct_cant_static_ability(tokens: &[OwnedLexToken]) -> Option<StaticAbilityShapeResolution> {
    if let Some(fact) = cant_shapes::parse_counter_limit_fact_tokens(tokens) {
        return Some(StaticAbilityShapeResolution::Ability(
            StaticAbility::counter_limit(
                fact.counter_type,
                fact.maximum,
                format_negated_restriction_display(tokens),
            ),
        ));
    }
    let fact = cant_shapes::parse_direct_cant_fact_tokens(tokens)?;
    let authored_self_surface = matches!(
        fact,
        DirectCantFact::SourceCantAttack
            | DirectCantFact::SourceCantBlock
            | DirectCantFact::SourceCantAttackItsOwner
            | DirectCantFact::SourceCantAttackPlayerAlreadyAttacked
            | DirectCantFact::SourceCantBeBlocked
            | DirectCantFact::SourceCantAttackAlone
            | DirectCantFact::SourceCantBlockAlone
            | DirectCantFact::SourceCantAttackOrBlock
            | DirectCantFact::SourceCantAttackOrBlockAlone
            | DirectCantFact::SourceCantAttackOrBlockUnlessMaxSpeed
    )
    .then(|| {
        crate::slice_primitives::select_position(tokens, |token| {
            token.is_word("can't") || token.is_word("cant") || token.is_word("cannot")
        })
        .and_then(|cant| {
            let subject_words = words(&tokens[..cant]);
            source_reference_surface_for_words(&subject_words)
        })
    })
    .flatten();
    let mut ability = match fact {
        DirectCantFact::TemporaryUnblockable => return Some(StaticAbilityShapeResolution::Decline),
        DirectCantFact::PlayerWouldGainNoLifeInstead => StaticAbility::restriction(
            crate::effect::Restriction::gain_life(PlayerFilter::Any),
            "If a player would gain life, that player gains no life instead".to_string(),
        ),
        DirectCantFact::PlayersCantGainLife => StaticAbility::players_cant_gain_life(),
        DirectCantFact::PlayersCantSearchLibraries => StaticAbility::players_cant_search(),
        DirectCantFact::DamageCantBePrevented => StaticAbility::damage_cant_be_prevented(),
        DirectCantFact::DamageToYouAsThoughInfect => StaticAbility::restriction(
            crate::effect::Restriction::damage_as_though_infect(PlayerFilter::You),
            "All damage is dealt to you as though its source had infect".to_string(),
        ),
        DirectCantFact::AllDamageAsThoughWither => StaticAbility::restriction(
            crate::effect::Restriction::all_damage_as_though_wither(),
            "All damage is dealt as though its source had wither".to_string(),
        ),
        DirectCantFact::CombatDamageCantBePrevented => StaticAbility::restriction(
            crate::effect::Restriction::PreventCombatDamage,
            "Combat damage can't be prevented".to_string(),
        ),
        DirectCantFact::YouCantLoseGame => StaticAbility::you_cant_lose_game(),
        DirectCantFact::OpponentsCantWinGame => StaticAbility::opponents_cant_win_game(),
        DirectCantFact::YourLifeTotalCantChange => StaticAbility::your_life_total_cant_change(),
        DirectCantFact::OpponentsCantCastSpells => StaticAbility::opponents_cant_cast_spells(),
        DirectCantFact::OpponentsCantDrawExtraCards => {
            StaticAbility::opponents_cant_draw_extra_cards()
        }
        DirectCantFact::CantHaveCountersPlaced => StaticAbility::cant_have_counters_placed(),
        DirectCantFact::ThisSpellCantBeCopied => StaticAbility::cant_be_copied(),
        DirectCantFact::ThisSpellCantBeCountered => StaticAbility::cant_be_countered_ability(),
        DirectCantFact::SourceCantAttack => StaticAbility::cant_attack(),
        DirectCantFact::SourceCantBlock => StaticAbility::cant_block(),
        DirectCantFact::SourceCantAttackItsOwner => StaticAbility::cant_attack_its_owner(),
        DirectCantFact::SourceCantAttackPlayerAlreadyAttacked => {
            StaticAbility::cant_attack_player_already_attacked_this_turn()
        }
        DirectCantFact::CreaturesCantAttackPlayersInactiveLastTurn => {
            StaticAbility::creatures_cant_attack_players_inactive_last_turn()
        }
        DirectCantFact::SourceLethalDamageMustBeFromSingleSource => {
            StaticAbility::lethal_damage_must_be_from_single_source()
        }
        DirectCantFact::OpponentCausesCantMakeYouSacrifice => StaticAbility::restriction(
            crate::effect::Restriction::BeSacrificedByCause {
                filter: ObjectFilter::permanent().controlled_by(PlayerFilter::You),
                cause: ironsmith_core::CauseFilter {
                    cause_type: Some(ironsmith_core::CauseTypeFilter::OneOf(vec![
                        ironsmith_core::CauseType::Effect, ironsmith_core::CauseType::Cost,
                    ])),
                    source_filter: None,
                    controller_filter: Some(ironsmith_core::ControllerFilter::Opponent),
                    ability_kind: None,
                excluded_ability_designations: Vec::new(),
},
            },
            format_negated_restriction_display(tokens),
        ),
        DirectCantFact::PermanentsYouControlCantBeSacrificed => {
            StaticAbility::permanents_you_control_cant_be_sacrificed()
        }
        DirectCantFact::SourceCantBeBlocked => StaticAbility::unblockable(),
        DirectCantFact::SourceCantAttackAlone => StaticAbility::restriction(
            crate::effect::Restriction::attack_alone(ObjectFilter::source()),
            format_negated_restriction_display(tokens),
        ),
        DirectCantFact::SourceCantBlockAlone => StaticAbility::restriction(
            crate::effect::Restriction::block_alone(ObjectFilter::source()),
            format_negated_restriction_display(tokens),
        ),
        DirectCantFact::SourceCantAttackOrBlock => StaticAbility::restriction(
            crate::effect::Restriction::attack_or_block(ObjectFilter::source()),
            format_negated_restriction_display(tokens),
        ),
        DirectCantFact::SourceCantAttackOrBlockAlone => StaticAbility::restriction(
            crate::effect::Restriction::attack_or_block_alone(ObjectFilter::source()),
            format_negated_restriction_display(tokens),
        ),
        DirectCantFact::SourceCantAttackOrBlockUnlessMaxSpeed => {
            let max_speed = PredicateAst::ValueComparison {
                left: crate::effect::Value::Speed(PlayerFilter::You),
                operator: crate::effect::ValueComparisonOperator::GreaterThanOrEqual,
                right: crate::effect::Value::Fixed(4),
            };
            StaticAbility::restriction(
                crate::effect::Restriction::attack_or_block(ObjectFilter::source()),
                "This creature can't attack or block".to_string(),
            )
            .with_condition(PredicateAst::Not(Box::new(max_speed)))
        }
        DirectCantFact::DomainAttackTax => {
            StaticAbility::cant_attack_you_unless_controller_pays_per_attacker_basic_land_types_among_lands_you_control()
        }
    };
    if let Some(surface) = authored_self_surface {
        ability = ability.with_self_subject_surface(surface);
    }
    Some(StaticAbilityShapeResolution::Ability(ability))
}

pub(crate) fn blocking_cant_static_ability(tokens: &[OwnedLexToken]) -> Option<StaticAbility> {
    let fact = cant_shapes::parse_blocking_cant_fact_tokens(tokens)?;
    let display = format_negated_restriction_display(tokens);
    Some(match fact {
        BlockingCantFact::MaximumBlockers {
            maximum_blockers, ..
        } => StaticAbility::cant_be_blocked_by_more_than(maximum_blockers),
        BlockingCantFact::PowerThreshold { comparison, .. } => match comparison {
            crate::filter::Comparison::LessThanOrEqual(threshold) => {
                StaticAbility::cant_be_blocked_by_power_or_less(threshold)
            }
            crate::filter::Comparison::GreaterThanOrEqual(threshold) => {
                StaticAbility::cant_be_blocked_by_power_or_greater(threshold)
            }
            _ => return None,
        },
        BlockingCantFact::DisallowedBlockers { filter, .. } => StaticAbility::restriction(
            crate::effect::Restriction::block_specific_attacker(filter, ObjectFilter::source()),
            display,
        ),
        BlockingCantFact::MinimumBlockers {
            minimum_blockers, ..
        } => StaticAbility::cant_be_blocked_except_by_n_or_more(minimum_blockers),
    })
}

/// Preserve full payment alternatives, attacker filters, and bound amounts.
fn typed_attack_tax_static_ability(
    tokens: &[OwnedLexToken],
) -> Result<Option<StaticAbility>, CardTextError> {
    let Some(cant) = tokens.iter().position(|token| {
        token.is_word("can't") || token.is_word("cant") || token.is_word("cannot")
    }) else {
        return Ok(None);
    };
    let Some(unless) = tokens.iter().position(|token| token.is_word("unless")) else {
        return Ok(None);
    };
    if unless <= cant {
        return Ok(None);
    }
    let scope = crate::lexer::token_word_refs(&tokens[cant + 1..unless]);
    let covers_planeswalkers = match scope.as_slice() {
        ["attack", "you"] => false,
        ["attack", "you", "or", "planeswalkers", "you", "control"] => true,
        _ => return Ok(None),
    };
    let Some(pays) = tokens
        .iter()
        .enumerate()
        .skip(unless + 1)
        .find_map(|(index, token)| token.is_word("pays").then_some(index))
    else {
        return Ok(None);
    };
    // "Each creature ... can't attack you ... unless its controller pays
    // {X}, where X is ... on that creature" (Nils): a per-attacker tax whose
    // amount reads the attacker being taxed.
    let singular_payer = match crate::lexer::token_word_refs(&tokens[unless + 1..pays]).as_slice() {
        ["their", "controller"] => false,
        ["its", "controller"] => true,
        _ => return Ok(None),
    };
    let where_index = tokens
        .iter()
        .enumerate()
        .skip(pays + 1)
        .find_map(|(index, token)| token.is_word("where").then_some(index));
    let per = if singular_payer {
        tokens
            .iter()
            .enumerate()
            .skip(pays + 1)
            .find_map(|(index, token)| token.is_word("for").then_some(index))
            .filter(|per| where_index.is_none_or(|where_index| *per < where_index))
            .unwrap_or(where_index.unwrap_or(tokens.len()))
    } else {
        let Some(per) = tokens
            .iter()
            .enumerate()
            .skip(pays + 1)
            .find_map(|(index, token)| token.is_word("for").then_some(index))
        else {
            return Ok(None);
        };
        per
    };
    let per_words =
        crate::lexer::token_word_refs(&tokens[per..where_index.unwrap_or(tokens.len())]);
    let per_words = per_words
        .iter()
        .copied()
        .filter(|word| !matches!(*word, "," | "."))
        .collect::<Vec<_>>();
    if !(singular_payer && per_words.is_empty())
        && !matches!(
            per_words.as_slice(),
            ["for", "each", "of", "those", "creatures"]
                | [
                    "for",
                    "each",
                    "creature",
                    "they",
                    "control",
                    "that's" | "thats",
                    "attacking",
                    "you"
                ]
        )
    {
        return Ok(None);
    }
    let Some(attackers) = parse_subject_object_filter(&tokens[..cant])? else {
        return Ok(None);
    };
    let Some(mut cost) = parse_payment_clause_as_total_cost(&tokens[pays + 1..per])? else {
        return Err(CardTextError::ParseError(
            "unsupported attack payment cost".into(),
        ));
    };
    if let Some(where_index) = where_index {
        let where_words = crate::lexer::token_word_refs(&tokens[where_index..]);
        let names_taxed_attacker =
            crate::word_primitives::sequence_occurs(
                &where_words,
                &["counters", "on", "that", "creature"],
            ) || crate::word_primitives::sequence_occurs(&where_words, &["counters", "on", "it"]);
        let value = if singular_payer && names_taxed_attacker {
            // The attacker being taxed is bound under this tag when the
            // cost is locked in at declaration (CR 508.1d/h).
            crate::effect::Value::CountersOn(
                Box::new(crate::target::ChooseSpec::Tagged(
                    ironsmith_core::TAXED_ATTACKER_TAG.into(),
                )),
                None,
            )
        } else {
            parse_value_binding_clause_lexed(&tokens[where_index..]).ok_or_else(|| {
                CardTextError::ParseError("unsupported attack-cost X definition".into())
            })?
        };
        let mut bound = false;
        cost = cost.try_map(|component| -> Result<_, CardTextError> {
            Ok(match component {
                crate::model::CompilerCost::Mana(mana) if mana.has_x() => {
                    bound = true;
                    crate::model::CompilerCost::DynamicMana(
                        ironsmith_core::DynamicManaCost::from_x(mana, value.clone()),
                    )
                }
                crate::model::CompilerCost::VariableMana { generic } => {
                    bound = true;
                    crate::model::CompilerCost::DynamicMana(
                        ironsmith_core::DynamicManaCost::from_x(
                            ManaCost::from_pips(vec![vec![ManaSymbol::X]]).add_generic(generic),
                            value.clone(),
                        ),
                    )
                }
                crate::model::CompilerCost::DynamicMana(mut dynamic) if dynamic.base.has_x() => {
                    bound = true;
                    dynamic.x_value = Some(value.clone());
                    crate::model::CompilerCost::DynamicMana(dynamic)
                }
                other => other,
            })
        })?;
        if !bound {
            return Err(CardTextError::ParseError(
                "attack-cost X definition has no X payment".into(),
            ));
        }
    }
    Ok(Some(StaticAbility::attack_cost(
        attackers,
        covers_planeswalkers,
        cost,
        format_negated_restriction_display(tokens),
    )))
}

/// "Creatures can't attack planeswalkers you control unless their controller
/// pays {1} for each creature they control that's attacking a planeswalker
/// you control." (Onakke Oathkeeper): attacks on the controller are free; only
/// attacks on that player's planeswalkers are taxed (CR 508.1g-h). The
/// player-inclusive wordings stay with the typed attack-tax reader above.
fn planeswalker_attack_tax_static_ability(tokens: &[OwnedLexToken]) -> Option<StaticAbility> {
    let fact = cant_shapes::parse_general_attack_tax_tokens(tokens)?;
    if fact.defenders != ironsmith_core::value_model::AttackTaxDefenders::ControllerPlaneswalkers {
        return None;
    }
    let mut costs = Vec::new();
    match fact.mana {
        Some(cant_shapes::AttackTaxManaAmount::Generic(amount)) if amount > 0 => {
            costs.push(crate::model::CompilerCost::Mana(ManaCost::from_pips(vec![vec![
                ManaSymbol::Generic(u8::try_from(amount).ok()?),
            ]])));
        }
        Some(cant_shapes::AttackTaxManaAmount::Generic(_)) | None => {}
        // A static ability has no announced X.
        Some(cant_shapes::AttackTaxManaAmount::X) => return None,
    }
    if fact.life > 0 {
        costs.push(crate::model::CompilerCost::Life(crate::effect::Value::Fixed(
            i32::try_from(fact.life).ok()?,
        )));
    }
    if costs.is_empty() {
        return None;
    }
    Some(
        StaticAbility::attack_cost(
            ObjectFilter::creature(),
            true,
            ironsmith_core::TotalCost::from_costs(costs),
            format_negated_restriction_display(tokens),
        )
        .with_attack_cost_planeswalkers_only(),
    )
}

fn attack_unless_static_ability(tokens: &[OwnedLexToken]) -> Option<StaticAbility> {
    let fact = cant_shapes::parse_attack_unless_condition_tokens(tokens)?;
    let display = format_negated_restriction_display(fact.display_tokens);
    match fact.scope {
        AttackUnlessScope::Attack => Some(match fact.surface {
            AttackUnlessSurface::ControllerCastCreatureSpellThisTurn => {
                StaticAbility::cant_attack_unless_controller_cast_creature_spell_this_turn()
            }
            AttackUnlessSurface::ControllerCastNoncreatureSpellThisTurn => {
                StaticAbility::cant_attack_unless_controller_cast_noncreature_spell_this_turn()
            }
            _ => StaticAbility::cant_attack_unless_condition(fact.condition, display),
        }),
        // "can't block unless ... also blocks": a blocking-group condition
        // judged against the whole blocker declaration.
        AttackUnlessScope::Block
            if matches!(
                fact.condition,
                crate::static_abilities::CantAttackUnlessConditionSpec::AttackingGroupCondition(
                    ironsmith_core::AttackingGroupAttackCondition::AtLeastNOtherCreaturesBlock(_)
                        | ironsmith_core::AttackingGroupAttackCondition::CreatureWithGreaterPowerAlsoBlocks
                )
            ) =>
        {
            Some(StaticAbility::cant_attack_unless_condition(fact.condition, display))
        }
        AttackUnlessScope::AttackOrBlock
        | AttackUnlessScope::Block
        | AttackUnlessScope::AttackAlone => {
            let crate::static_abilities::CantAttackUnlessConditionSpec::SourceCondition(condition) =
                fact.condition
            else {
                return None;
            };
            let restriction = match fact.scope {
                AttackUnlessScope::Block => crate::effect::Restriction::block(ObjectFilter::source()),
                AttackUnlessScope::AttackAlone => {
                    crate::effect::Restriction::attack_alone(ObjectFilter::source())
                }
                _ => crate::effect::Restriction::attack_or_block(ObjectFilter::source()),
            };
            Some(
                StaticAbility::restriction(restriction, display)
                    .with_condition(PredicateAst::Not(Box::new(condition))),
            )
        }
    }
}

fn parity_cant_static_ability(tokens: &[OwnedLexToken]) -> Option<StaticAbility> {
    let fact = cant_shapes::parse_mana_value_parity_cant_fact_tokens(tokens)?;
    let display = format_negated_restriction_display(tokens);
    Some(match fact {
        ManaValueParityCantFact::OpponentsCantCastSpells(parity) => StaticAbility::restriction(
            crate::effect::Restriction::cast_spells_matching(
                PlayerFilter::Opponent,
                ObjectFilter::spell().with_mana_value_parity(parity),
            ),
            display,
        ),
        ManaValueParityCantFact::OpponentsCantBlockWithCreatures(parity) => {
            StaticAbility::restriction(
                crate::effect::Restriction::block(
                    ObjectFilter::creature()
                        .opponent_controls()
                        .with_mana_value_parity(parity),
                ),
                display,
            )
        }
    })
}

fn fallback_cant_static_ability(tokens: &[OwnedLexToken]) -> Option<StaticAbility> {
    match cant_shapes::parse_cant_fallback_fact_tokens(tokens)? {
        CantFallbackFact::SourceCantAttackOrBlockUnlessEvenCounters => Some(
            StaticAbility::rule_fallback_text(format_negated_restriction_display(tokens)),
        ),
        // Parity-scoped damage doubling lowers through the functional
        // DoubleDamageAmountReplacement rule in the keyword-static family
        // (parse_damage_doubling_mana_value_marker_line tries it first).
        CantFallbackFact::SourceDamageDoubledForManaValueParity(_) => None,
    }
}

fn strip_per_blocking_creature_tail(tokens: &[OwnedLexToken]) -> &[OwnedLexToken] {
    for (index, token) in tokens.iter().enumerate() {
        if !token.is_word("for") {
            continue;
        }
        let tail = crate::lexer::token_word_refs(&tokens[index..]);
        if matches!(
            tail.as_slice(),
            ["for", "each", "of", "those", "creatures"]
                | ["for", "each", "blocking", "creature", "they", "control"]
                | ["for", "each", "blocking", "creature"]
                | [
                    "for", "each", "creature", "they", "control", "that's", "blocking", "it"
                ]
        ) {
            return &tokens[..index];
        }
    }
    tokens
}

/// "Black creatures can't attack unless their controller sacrifices a land
/// of their choice for each black creature they control that's attacking."
/// (Reclamation): the restricted creatures' attack cost, totalled over the
/// declaration (CR 508.1d/h). Charging each matching attacker one unit of the
/// action is exactly that total, whoever it attacks.
fn per_attacker_action_attack_cost_static_ability(
    tokens: &[OwnedLexToken],
) -> Result<Option<StaticAbility>, CardTextError> {
    let Some(cant) = crate::slice_primitives::select_position(tokens, |token| {
        token.is_word("can't") || token.is_word("cant") || token.is_word("cannot")
    }) else {
        return Ok(None);
    };
    let Some(unless) = crate::slice_primitives::select_position(&tokens[cant + 1..], |token| {
        token.is_word("unless")
    })
    .map(|idx| idx + cant + 1) else {
        return Ok(None);
    };
    if crate::lexer::token_word_refs(&tokens[cant + 1..unless]) != ["attack"] {
        return Ok(None);
    }
    let subject_words = crate::lexer::token_word_refs(&tokens[..cant]);
    if !subject_words.last().is_some_and(|word| word.ends_with('s')) {
        return Ok(None);
    }
    let payment = trim_edge_punctuation_tokens(&tokens[unless + 1..]);
    let payment_words = crate::lexer::token_word_refs(payment);
    if !matches!(
        payment_words.as_slice(),
        ["their" | "its", "controller", "sacrifices", ..]
    ) {
        return Ok(None);
    }
    let Some(verb) = payment.iter().position(|token| token.is_word("sacrifices")) else {
        return Ok(None);
    };
    let Some(per) = payment
        .iter()
        .enumerate()
        .skip(verb + 1)
        .find_map(|(index, token)| {
            (token.is_word("for") && payment.get(index + 1).is_some_and(|next| next.is_word("each")))
                .then_some(index)
        })
    else {
        return Ok(None);
    };
    let tail_words = crate::lexer::token_word_refs(&payment[per + 2..]);
    let Some(noun_words) = tail_words.strip_suffix(&["they", "control", "that's", "attacking"][..])
        .or_else(|| tail_words.strip_suffix(&["they", "control", "thats", "attacking"][..]))
    else {
        return Ok(None);
    };
    let singular = |words: &[&str]| -> Vec<String> {
        let mut words = words.iter().map(|word| (*word).to_string()).collect::<Vec<_>>();
        if let Some(last) = words.last_mut()
            && let Some(stripped) = last.strip_suffix('s')
        {
            *last = stripped.to_string();
        }
        words
    };
    if singular(noun_words) != singular(&subject_words) {
        return Ok(None);
    }
    let Some(attackers) = parse_subject_object_filter(&tokens[..cant])? else {
        return Ok(None);
    };
    let mut object_tokens = &payment[verb + 1..per];
    let object_words = crate::lexer::token_word_refs(object_tokens);
    if object_words.ends_with(&["of", "their", "choice"]) {
        let Some(of) = object_tokens.iter().rposition(|token| token.is_word("of")) else {
            return Ok(None);
        };
        object_tokens = &object_tokens[..of];
    }
    let mut cost_tokens = vec![OwnedLexToken::word(
        "sacrifice".to_string(),
        crate::cards::builders::TextSpan::synthetic(),
    )];
    cost_tokens.extend_from_slice(trim_edge_punctuation_tokens(object_tokens));
    let Ok(cost) = parse_compiler_activation_cost(&cost_tokens) else {
        return Ok(None);
    };
    Ok(Some(
        StaticAbility::block_cost(
            attackers,
            ObjectFilter::creature(),
            cost,
            format_negated_restriction_display(tokens),
        )
        .with_block_cost_attack_only(),
    ))
}

/// Whether the line is a typed per-attacker action attack cost, which the
/// static family owns rather than the statement probe.
pub(crate) fn is_per_attacker_action_attack_cost_line(tokens: &[OwnedLexToken]) -> bool {
    matches!(per_attacker_action_attack_cost_static_ability(tokens), Ok(Some(_)))
}

/// Parse a CR 509.1d blocking cost before the generic negated-restriction
/// family can incorrectly turn it into an unconditional prohibition.
fn block_cost_static_ability(
    tokens: &[OwnedLexToken],
) -> Result<Option<StaticAbility>, CardTextError> {
    if let Some(ability) = per_attacker_action_attack_cost_static_ability(tokens)? {
        return Ok(Some(ability));
    }
    let Some(cant_index) = crate::slice_primitives::select_position(tokens, |token| {
        token.is_word("can't") || token.is_word("cant") || token.is_word("cannot")
    }) else {
        return Ok(None);
    };
    let Some(unless_index) =
        crate::slice_primitives::select_position(&tokens[cant_index + 1..], |token| {
            token.is_word("unless")
        })
        .map(|idx| idx + cant_index + 1)
    else {
        return Ok(None);
    };

    let subject_words = crate::lexer::token_word_refs(&tokens[..cant_index]);
    let action_words = crate::lexer::token_word_refs(trim_edge_punctuation_tokens(
        &tokens[cant_index + 1..unless_index],
    ));
    // Passive wording taxes the blockers of the described attacker. The
    // cost engine already charges each declared blocker and its controller.
    if action_words == ["be", "blocked"]
        && matches!(
            subject_words.as_slice(),
            ["enchanted", "creature"] | ["equipped", "creature"] | ["this", "creature"]
        )
    {
        let payment = trim_edge_punctuation_tokens(&tokens[unless_index + 1..]);
        let Some(pay) = payment.iter().position(|token| token.is_word("pays")) else {
            return Ok(None);
        };
        let payer = crate::lexer::token_word_refs(&payment[..pay]);
        if !matches!(
            payer.as_slice(),
            ["defending", "player"] | ["the", "defending", "player"]
        ) {
            return Ok(None);
        }
        let cost_tokens =
            strip_per_blocking_creature_tail(trim_edge_punctuation_tokens(&payment[pay + 1..]));
        if cost_tokens.len() == payment[pay + 1..].len() {
            return Ok(None);
        }
        let Some(cost) = parse_payment_clause_as_total_cost(cost_tokens)? else {
            return Ok(None);
        };
        let attackers = if subject_words[0] == "this" {
            ObjectFilter::source()
        } else {
            let mut filter = ObjectFilter::creature();
            filter.with_attached_object = Some(Box::new(ObjectFilter::source()));
            filter
        };
        return Ok(Some(StaticAbility::block_cost(
            ObjectFilter::creature(),
            attackers,
            cost,
            format_negated_restriction_display(tokens),
        )));
    }
    let (blockers, blocker_is_attached_to_source) =
        if crate::word_primitives::parse_any_sequence_complete(
            &subject_words,
            &[&["this"], &["this", "creature"]],
        ) {
            (ObjectFilter::source(), false)
        } else if crate::word_primitives::parse_sequence_complete(&subject_words, &["creatures"]) {
            (ObjectFilter::creature(), false)
        } else if crate::word_primitives::parse_any_sequence_complete(
            &subject_words,
            &[&["enchanted", "creature"], &["equipped", "creature"]],
        ) {
            (ObjectFilter::creature(), true)
        } else if subject_words.contains(&"creatures") {
            let Some(filter) = parse_subject_object_filter(&tokens[..cant_index])? else {
                return Ok(None);
            };
            (filter, false)
        } else {
            return Ok(None);
        };

    let action_tokens = trim_edge_punctuation_tokens(&tokens[cant_index + 1..unless_index]);
    let action_words = crate::lexer::token_word_refs(action_tokens);
    // "can't attack or block unless ...": one typed BlockCost that also
    // charges the same cost when that creature attacks (CR 508.1d/h,
    // 509.1d). Nothing else lowers the attack half of this wording.
    let also_attack_cost =
        crate::word_primitives::parse_sequence_complete(&action_words, &["attack", "or", "block"]);
    // "This/Enchanted creature can't attack unless you/its controller pays
    // ..." (Brainwash): the same declaration cost with only its attack side.
    let attack_only = crate::word_primitives::parse_sequence_complete(&action_words, &["attack"])
        && crate::word_primitives::parse_any_sequence_complete(
            &subject_words,
            &[
                &["this"],
                &["this", "creature"],
                &["enchanted", "creature"],
                &["equipped", "creature"],
            ],
        );
    let attackers = if attack_only
        || crate::word_primitives::parse_any_sequence_complete(
            &action_words,
            &[&["block"], &["attack", "or", "block"]],
        ) {
        ObjectFilter::creature()
    } else if crate::word_primitives::parse_sequence_prefix(&action_words, &["block"]) {
        let Some(block_token_index) =
            crate::slice_primitives::select_position(action_tokens, |token| token.is_word("block"))
        else {
            return Ok(None);
        };
        let attacker_tokens = trim_edge_punctuation_tokens(&action_tokens[block_token_index + 1..]);
        parse_subject_object_filter(attacker_tokens)?
            .or_else(|| {
                crate::grammar::primitives::probe_shape(parse_object_filter(attacker_tokens, false))
            })
            .ok_or_else(|| {
                CardTextError::ParseError(format!(
                    "unsupported attacker filter for blocking cost (clause: '{}')",
                    crate::lexer::token_word_refs(attacker_tokens).join(" ")
                ))
            })?
    } else {
        return Ok(None);
    };

    let payment_tokens = trim_edge_punctuation_tokens(&tokens[unless_index + 1..]);
    let direct_action_cost = payment_tokens
        .first()
        .is_some_and(|token| token.is_word("you"))
        && crate::slice_primitives::select_position(payment_tokens, |token| {
            token.is_word("pay") || token.is_word("pays")
        })
        .is_none();
    let mut cost_tokens = if direct_action_cost {
        // Some declaration costs state the action directly ("unless you tap
        // ...") rather than introducing it with "pay". Feed the ordinary
        // activation-cost grammar the action after the payer pronoun.
        trim_edge_punctuation_tokens(&payment_tokens[1..])
    } else {
        let Some(pay_index) = crate::slice_primitives::select_position(payment_tokens, |token| {
            token.is_word("pay") || token.is_word("pays")
        }) else {
            return Ok(None);
        };
        let payer_words = crate::lexer::token_word_refs(&payment_tokens[..pay_index]);
        if !crate::word_primitives::parse_any_sequence_complete(
            &payer_words,
            &[&["you"], &["its", "controller"], &["their", "controller"]],
        ) {
            return Ok(None);
        }
        trim_edge_punctuation_tokens(&payment_tokens[pay_index.saturating_add(1)..])
    };
    if subject_words.contains(&"creatures") {
        cost_tokens = trim_edge_punctuation_tokens(strip_per_blocking_creature_tail(cost_tokens));
    }
    // The attack-only reading claims just explicit payments; any other
    // "can't attack unless ..." wording keeps its own grammar. That includes
    // payments the attack-unless reader already types, such as the scaled
    // per-counter tax of Phyrexian Marauder: two differing readings of one
    // line would leave the cant-clause registry with no static ability.
    if attack_only
        && (direct_action_cost
            || attack_unless_static_ability(tokens).is_some()
            || !matches!(parse_payment_clause_as_total_cost(cost_tokens), Ok(Some(_))))
    {
        return Ok(None);
    }
    let parsed_cost = if direct_action_cost {
        Some(parse_compiler_activation_cost(cost_tokens)?)
    } else {
        parse_payment_clause_as_total_cost(cost_tokens)?
    };
    let Some(cost) = parsed_cost else {
        return Err(CardTextError::ParseError(format!(
            "unsupported blocking payment cost (clause: '{}')",
            crate::lexer::token_word_refs(cost_tokens).join(" ")
        )));
    };

    let display = format_negated_restriction_display(tokens);
    let ability = if blocker_is_attached_to_source {
        StaticAbility::attached_block_cost(blockers, attackers, cost, display)
    } else {
        StaticAbility::block_cost(blockers, attackers, cost, display)
    };
    Ok(Some(if attack_only {
        ability.with_block_cost_attack_only()
    } else if also_attack_cost {
        ability.with_block_cost_also_attacking()
    } else {
        ability
    }))
}

fn except_for_cant_attack_static_ability(
    tokens: &[OwnedLexToken],
) -> Result<Option<StaticAbility>, CardTextError> {
    if !tokens.first().is_some_and(|token| token.is_word("except"))
        || !tokens.get(1).is_some_and(|token| token.is_word("for"))
    {
        return Ok(None);
    }
    let Some(comma_idx) =
        crate::slice_primitives::select_position(tokens, |token| token.kind == TokenKind::Comma)
    else {
        return Ok(None);
    };
    let exception_tokens = trim_edge_punctuation_tokens(&tokens[2..comma_idx]);
    let restriction_tokens = trim_edge_punctuation_tokens(&tokens[comma_idx + 1..]);
    let Some(parsed) = parse_negated_object_restriction_clause(restriction_tokens)? else {
        return Ok(None);
    };
    if parsed.target.is_some() {
        return Ok(None);
    }
    let crate::effect::Restriction::Attack(mut affected) = parsed.restriction else {
        return Ok(None);
    };

    let mut exception_filters = None;
    // Prefer the final conjunction so a card name that itself contains
    // "and" remains one named exception.
    for (and_idx, token) in exception_tokens.iter().enumerate().rev() {
        if !token.is_word("and") {
            continue;
        }
        let left = trim_edge_punctuation_tokens(&exception_tokens[..and_idx]);
        let right = trim_edge_punctuation_tokens(&exception_tokens[and_idx + 1..]);
        if left.is_empty() || right.is_empty() {
            continue;
        }
        let (Ok(left), Ok(right)) = (
            parse_object_filter(left, false),
            parse_object_filter(right, false),
        ) else {
            continue;
        };
        exception_filters = Some([left, right]);
        break;
    }
    let Some(exception_filters) = exception_filters else {
        return Ok(None);
    };

    let affected_types = affected
        .card_types
        .iter()
        .chain(affected.all_card_types.iter())
        .copied()
        .collect::<Vec<_>>();
    if affected_types.is_empty() {
        return Ok(None);
    }
    for exception in exception_filters {
        let exception_types = exception
            .card_types
            .iter()
            .chain(exception.all_card_types.iter())
            .copied()
            .collect::<Vec<_>>();
        let mut unsupported_exception_constraints = exception.clone();
        unsupported_exception_constraints.zone = None;
        unsupported_exception_constraints.card_types.clear();
        unsupported_exception_constraints.all_card_types.clear();
        unsupported_exception_constraints.name = None;
        if unsupported_exception_constraints != ObjectFilter::default() {
            return Ok(None);
        }
        if !affected_types
            .iter()
            .all(|card_type| crate::slice_primitives::contains(&exception_types, card_type))
        {
            return Ok(None);
        }
        let additional_types = exception_types
            .iter()
            .copied()
            .filter(|card_type| !crate::slice_primitives::contains(&affected_types, card_type))
            .collect::<Vec<_>>();
        if let Some(name) = exception.name {
            if !additional_types.is_empty()
                || affected.excluded_name.is_some()
                || !exception.subtypes.is_empty()
                || exception.colors.is_some()
            {
                return Ok(None);
            }
            affected.excluded_name = Some(name);
        } else {
            if additional_types.is_empty()
                || !exception.subtypes.is_empty()
                || exception.colors.is_some()
            {
                return Ok(None);
            }
            for card_type in additional_types {
                if !crate::slice_primitives::contains(&affected.excluded_card_types, &card_type) {
                    affected.excluded_card_types.push(card_type);
                }
            }
        }
    }

    Ok(Some(StaticAbility::restriction(
        crate::effect::Restriction::attack(affected),
        crate::lexer::render_token_slice(tokens)
            .trim()
            .trim_end_matches('.')
            .to_string(),
    )))
}

/// Whether the clause after a leading restriction duration is a mana-retention
/// clause ("until end of turn, you don't lose this mana ..."), which is not a
/// static restriction.
fn restriction_duration_remainder_retains_mana(tokens: &[OwnedLexToken]) -> bool {
    let Ok(Some((_, remainder))) = parse_restriction_duration(tokens) else {
        return false;
    };
    if remainder.len() >= tokens.len() {
        return false;
    }
    let words = normalize_cant_word_refs(&remainder);
    crate::grammar::activation_restrictions::parse_mana_retention_negated_clause_words(&words)
        .is_some()
}

use crate::recognition::ParseOutcome;
#[path = "activation_costs/cant_clause_readings.rs"]
mod cant_clause_readings;

fn opponent_effects_and_payments_cause() -> ironsmith_core::CauseFilter {
    ironsmith_core::CauseFilter {
        cause_type: Some(ironsmith_core::CauseTypeFilter::OneOf(vec![
            ironsmith_core::CauseType::Effect,
            ironsmith_core::CauseType::Cost,
        ])),
        source_filter: None,
        controller_filter: Some(ironsmith_core::ControllerFilter::Opponent),
        ability_kind: None,
    }
excluded_ability_designations: Vec::new(),
}

/// "Spells and abilities your opponents control can't cause you to discard
/// cards [or sacrifice permanents]." (Tamiyo, Collector of Tales): one
/// opponent-caused protection per action.
fn opponent_cause_protection_static_abilities(
    tokens: &[OwnedLexToken],
) -> Option<Vec<StaticAbility>> {
    let words = crate::lexer::token_word_refs(tokens);
    let words = words
        .iter()
        .copied()
        .filter(|word| *word != ".")
        .collect::<Vec<_>>();
    let head: &[&str] = &[
        "spells", "and", "abilities", "your", "opponents", "control", "can't", "cause", "you", "to",
    ];
    let head_alt: &[&str] = &[
        "spells", "and", "abilities", "your", "opponents", "control", "cant", "cause", "you", "to",
    ];
    let tail = words
        .strip_prefix(head)
        .or_else(|| words.strip_prefix(head_alt))?;
    let (discard, sacrifice) = match tail {
        ["discard", "cards"] => (true, false),
        ["discard", "cards", "or", "sacrifice", "permanents"]
        | ["sacrifice", "permanents", "or", "discard", "cards"] => (true, true),
        _ => return None,
    };
    let mut abilities = Vec::new();
    if discard {
        abilities.push(StaticAbility::restriction(
            crate::effect::Restriction::DiscardByCause {
                player: PlayerFilter::You,
                cause: opponent_effects_and_payments_cause(),
            },
            "Spells and abilities your opponents control can't cause you to discard cards"
                .to_string(),
        ));
    }
    if sacrifice {
        abilities.push(StaticAbility::restriction(
            crate::effect::Restriction::BeSacrificedByCause {
                filter: ObjectFilter::permanent().controlled_by(PlayerFilter::You),
                cause: opponent_effects_and_payments_cause(),
            },
            "Spells and abilities your opponents control can't cause you to sacrifice permanents"
                .to_string(),
        ));
    }
    Some(abilities)
}

/// "Triggered abilities you control can't cause you to sacrifice or exile
/// creature tokens you control." (The Master, Multiplied): a protection
/// against events caused by a resolving ability of one kind (CR 113.3c),
/// one typed restriction per protected action in a single rule surface.
fn ability_kind_cause_protection_static_ability(
    tokens: &[OwnedLexToken],
) -> Result<Option<StaticAbility>, CardTextError> {
    let word_tokens = tokens
        .iter()
        .enumerate()
        .filter_map(|(index, token)| token.as_word().map(|word| (index, word)))
        .filter(|(_, word)| *word != ".")
        .collect::<Vec<_>>();
    let words = word_tokens.iter().map(|(_, word)| *word).collect::<Vec<_>>();
    let (ability_kind, rest) = if let Some(rest) = words.strip_prefix(&["triggered", "abilities"][..]) {
        (ironsmith_core::CauseAbilityKindFilter::Triggered, rest)
    } else if let Some(rest) = words.strip_prefix(&["activated", "abilities"][..]) {
        (ironsmith_core::CauseAbilityKindFilter::Activated, rest)
    } else {
        return Ok(None);
    };
    let (controller, rest) = if let Some(rest) = rest.strip_prefix(&["you", "control"][..]) {
        (Some(ironsmith_core::ControllerFilter::You), rest)
    } else if let Some(rest) = rest.strip_prefix(&["your", "opponents", "control"][..]) {
        (Some(ironsmith_core::ControllerFilter::Opponent), rest)
    } else {
        (None, rest)
    };
    let Some(rest) = rest
        .strip_prefix(&["can't", "cause", "you", "to"][..])
        .or_else(|| rest.strip_prefix(&["cant", "cause", "you", "to"][..]))
    else {
        return Ok(None);
    };
    let (sacrifice, exile, rest) = match rest {
        ["sacrifice", "or", "exile", rest @ ..] | ["exile", "or", "sacrifice", rest @ ..] => {
            (true, true, rest)
        }
        ["sacrifice", rest @ ..] => (true, false, rest),
        ["exile", rest @ ..] => (false, true, rest),
        _ => return Ok(None),
    };
    if rest.is_empty() {
        return Ok(None);
    }
    let filter_start = word_tokens[words.len() - rest.len()].0;
    let filter_end = word_tokens
        .last()
        .map_or(tokens.len(), |(index, _)| index + 1);
    let mut filter =
        crate::object_filters::parse_object_filter_lexed(&tokens[filter_start..filter_end], false)?;
    if filter.zone.is_none() {
        filter.zone = Some(Zone::Battlefield);
    }
    let cause = ironsmith_core::CauseFilter {
        cause_type: None,
        source_filter: None,
        controller_filter: controller,
        ability_kind: Some(ability_kind),
    excluded_ability_designations: Vec::new(),
};
    let mut restrictions = Vec::new();
    if sacrifice {
        restrictions.push(crate::effect::Restriction::BeSacrificedByCause {
            filter: filter.clone(),
            cause: cause.clone(),
        });
    }
    if exile {
        restrictions.push(crate::effect::Restriction::BeExiledByCause { filter, cause });
    }
    Ok(Some(StaticAbility::restrictions(
        restrictions,
        format_negated_restriction_display(tokens),
    )))
}

pub fn parse_cant_clauses(
    tokens: &[OwnedLexToken],
) -> Result<Option<Vec<StaticAbility>>, CardTextError> {
    if let Some(abilities) = opponent_cause_protection_static_abilities(tokens) {
        return Ok(Some(abilities));
    }
    if let Some(ability) = ability_kind_cause_protection_static_ability(tokens)? {
        return Ok(Some(vec![ability]));
    }
    // The restriction in a repeated choice belongs to the procedure, not
    // to a static ability on its leading "repeat this process" words.
    if crate::grammar::effects::clause_primitive_shapes::parse_repeat_process_shape(tokens).is_some() {
        return Ok(None);
    }
    // A restriction starting on a future turn is a timed effect. Let the
    // clause reader retain both its referenced controller and start time.
    if crate::grammar::effects::clause_dispatch_shapes::parse_next_turn_cant_shape_tokens(tokens).is_some() {
        return Ok(None);
    }
    // Source untap-step rules have their own typed owner, including its
    // conditional tail. A generic restriction would be a different AST for
    // the same rule and make the static registry reject both readings.
    if matches!(
        crate::grammar::abilities::parse_doesnt_untap_during_untap_step_spec_lexed(tokens),
        Some(crate::grammar::abilities::DoesntUntapDuringUntapStepSpec::Source { .. })
    ) {
        return Ok(None);
    }
    if crate::keyword_static::parse_attached_untap_and_activation_restrictions_line(tokens)?.is_some() {
        return Ok(None);
    }
    // The conditional unblockable reader owns the whole subject and its
    // if/as-long-as/unless condition. A second generic restriction conflicts.
    if matches!(crate::keyword_static::parse_subject_cant_be_blocked_as_long_as_condition_line(tokens), Ok(Some(_))) {
        return Ok(None);
    }
    // "<attached> gets X/Y, and its activated abilities can't be activated"
    // is owned by the attached anthem compound reader.
    if crate::grammar::attached_object_static_lines::parse_attached_gets_and_activation_restriction_tokens(tokens).is_some() {
        return Ok(None);
    }
    // A mixed serial predicate owns the entire subject and every member.
    // A later "can't" must not make this reader reinterpret its first verb
    // as part of a target filter. The compound reader guards its recursion.
    if matches!(crate::keyword_static::parse_compound_self_predicate_line(tokens), Ok(Some(_))) {
        return Ok(None);
    }
    // "<self> can't be blocked unless all creatures defending player controls
    // block it" is a blocker-count rule, owned by the static marker reader.
    if crate::keyword_static::is_source_unblockable_unless_all_defenders_block_line(tokens) {
        return Ok(None);
    }
    // "... can't be blocked unless it's attacking its owner or a permanent
    // its owner controls" is an attack-target evasion rule, owned by its
    // static marker reader (with or without an authored subject).
    if crate::keyword_static::cant_be_blocked_unless_attacking_owner_subject_len(tokens).is_some() {
        return Ok(None);
    }
    Ok(parse_cant_clauses_unbound(tokens)?.map(|abilities| {
        abilities
            .into_iter()
            .map(bind_static_restriction_pronoun_to_source)
            .collect()
    }))
}

/// A static rule has no earlier object antecedent: "Creatures with power
/// less than this creature's power can't block it" names the source. Left as
/// the pronoun tag, the restriction would match nothing, since static rules
/// evaluate without tagged objects.
fn bind_static_restriction_pronoun_to_source(mut ability: StaticAbility) -> StaticAbility {
    fn is_bare_pronoun(filter: &ObjectFilter) -> bool {
        let [constraint] = filter.tagged_constraints.as_slice() else {
            return false;
        };
        constraint.tag.as_str() == crate::tag::CompilerReferenceTag::It.as_str()
            && constraint.relation == crate::filter::TaggedOpbjectRelation::IsTaggedObject
            && ObjectFilter {
                tagged_constraints: Vec::new(),
                ..filter.clone()
            } == ObjectFilter::default()
    }
    let ironsmith_core::StaticAbilityPayload::RuleRestriction {
        restriction,
        additional_restrictions,
        ..
    } = &mut ability.payload
    else {
        return ability;
    };
    for restriction in std::iter::once(restriction).chain(additional_restrictions.iter_mut()) {
        if let crate::effect::Restriction::BlockSpecificAttacker { attacker, .. }
        | crate::effect::Restriction::MustBlockSpecificAttacker { attacker, .. }
        | crate::effect::Restriction::MustBeBlockedBy { attacker, .. } = restriction
            && is_bare_pronoun(attacker)
        {
            *attacker = ObjectFilter::source();
        }
    }
    ability
}

fn parse_cant_clauses_unbound(
    tokens: &[OwnedLexToken],
) -> Result<Option<Vec<StaticAbility>>, CardTextError> {
    // A shared source subject followed by a positive predicate is owned by
    // the compound static reader, even when a later member is negated.
    let first_predicate = tokens.iter().position(|token| token.is_any_word(&["attacks", "blocks", "has", "gets", "is", "can", "can\'t", "cant"]));
    if let Some(index) = first_predicate {
        if !tokens[index].is_any_word(&["can\'t", "cant"])
            && crate::util::is_source_reference_words(&crate::lexer::token_word_refs(&tokens[..index]))
            && tokens[index + 1..].iter().any(|token| token.is_any_word(&["can\'t", "cant"])) {
            return Ok(None);
        }
    }
    // An imperative action may carry a later negated followup. Its verb is
    // owned by the effect sequence, not a static subject ending at "doesn't".
    if matches!(
        crate::grammar::semantic_lowering::parse_statement_effect_preference_tokens(tokens),
        Some(crate::grammar::semantic_lowering::StatementEffectPreference::LeadingEffectVerb)
    ) && crate::grammar::activation_restrictions::parse_filtered_unpreventability(tokens).is_none()
    {
        return Ok(None);
    }
    // These complete compound predicates retain the earlier stat setting or
    // attack permission; the negated suffix alone is not a second reading.
    if matches!(crate::keyword_static::parse_base_pt_and_blocker_restriction_line(tokens), Ok(Some(_)))
        || matches!(crate::keyword_static::parse_conditional_no_defender_and_unblockable_line(tokens), Ok(Some(_)))
    {
        return Ok(None);
    }
    if crate::word_primitives::parse_choice_sequence_complete(
        &crate::lexer::token_word_refs(tokens),
        &[
            &["spells"],
            &["and"],
            &["abilities"],
            &["your"],
            &["opponents"],
            &["control"],
            &["cant", "can't"],
            &["cause"],
            &["their"],
            &["controller"],
            &["to"],
            &["search"],
            &["their"],
            &["library"],
        ],
    ) {
        return Ok(Some(vec![StaticAbility::restriction(
            crate::effect::Restriction::SearchOwnLibraryFromOwnEffects(PlayerFilter::Opponent),
            "Spells and abilities your opponents control can't cause their controller to search their library".to_owned(),
        )]));
    }
    // These complete shapes lower through dedicated static-ability
    // productions. The generic negated-restriction grammar owns neither the
    // source-owner marker nor a quantified per-creature granted restriction.
    if crate::grammar::attached_object_static_lines::parse_attached_combat_restriction_tokens(
        tokens,
    )
    .is_some()
        || crate::grammar::attached_object_static_lines::parse_attached_action_restriction_list_tokens(tokens).is_some()
        || crate::grammar::abilities::is_this_creature_cant_attack_its_owner_line_lexed(tokens)
        || crate::grammar::abilities::parse_flying_block_restriction_line_lexed(tokens).is_some()
        || crate::grammar::anthem_grants::parse_keywords_and_cant_be_blocked_by_more_than_clause(
            tokens,
        )
        .is_some()
        || crate::grammar::anthem_grants::parse_cant_be_blocked_by_more_than_clause(tokens)
            .is_some_and(|clause| {
                crate::grammar::anthem_grants::parse_each_creature_subject(clause.subject_tokens)
                    .is_some()
            })
        // A filtered set granted a blocker-count restriction ("Boars you
        // control can't be blocked by more than one creature") is owned by
        // its grant production; the negated grammar would read the count as
        // a blocker filter.
        || matches!(
            crate::keyword_static::parse_filtered_blocker_count_restriction_line(tokens),
            Ok(Some(_))
        )
        || crate::grammar::keyword_static_lines::parse_dont_untap_during_controllers_step_tokens(
            tokens,
        )
        .is_some()
        || crate::keyword_static::parse_static_text_marker_line(tokens).is_some()
        || crate::grammar::anthem_grants::parse_cant_be_blocked_and_has_keywords_clause(tokens)
            .is_some()
        // The mirrored order ("<subject> has <keywords> and can't be blocked")
        // is one grant-plus-restriction production. Reading only its negated
        // half drops the granted keywords.
        || crate::grammar::attached_object_static_lines::parse_attached_has_tokens(tokens)
            .is_some_and(|clause| {
                crate::grammar::anthem_grants::parse_keywords_and_cant_be_blocked_clause(
                    clause.ability_tokens,
                ).is_some()
            })
        || matches!(
            crate::keyword_static::parse_subject_has_keywords_and_cant_be_blocked_line(tokens),
            Ok(Some(_))
        )
        // "<attached subject> has <keywords> and can't be blocked except by
        // ..." shares the attached subject across both verb phrases.
        || matches!(
            crate::keyword_static::parse_attached_has_keywords_and_negated_restriction_line(
                tokens
            ),
            Ok(Some(_))
        )
        // The filtered-subject mirror ("Fish you control have haste and
        // can't be blocked by Humans") is one grant-plus-restriction line.
        || matches!(
            crate::keyword_static::parse_subject_has_keywords_and_negated_restriction_line(
                tokens
            ),
            Ok(Some(_))
        )
        // A subject-scoped evasion line ("Blue creatures you control can't be
        // blocked") has its own canonical static ability. Competing here makes
        // the whole line ambiguous, and the statement fallback then renders it
        // as a pronoun grant that has lost the subject filter.
        || matches!(
            crate::keyword_static::parse_subject_cant_be_blocked_line(tokens),
            Ok(Some(_))
        )
    {
        // Flying-only evasion has a dedicated canonical static ability. The
        // generic negated-restriction route can recognize the same words but
        // does not lower to the same runtime model, so it must not compete for
        // this grammar-proven complete line.
        return Ok(None);
    }
    // A leading duration belongs to the effect sentence parser.  If this
    // rule claims it as a static restriction, the duration is lost and
    // temporary spell effects such as "Until end of turn, players can't gain
    // life" compile without a spell effect at all.
    if crate::token_primitives::parse_simple_restriction_duration_prefix(tokens).is_some() {
        return Ok(None);
    }

    if cant_shapes::parse_multi_sentence_cant_decline_tokens(tokens).is_some() {
        return Ok(None);
    }

    // An announced player target plus a duration belongs to a resolving spell
    // or ability. Do not send it through object-only static target parsing.
    if let Some((neg_start, _)) = find_negation_span(tokens)
        && super::activation_restriction_clauses::parse_player_restriction_subject(
            &tokens[..neg_start],
        )?
        .is_some_and(|(_, target)| target.is_some())
        && parse_restriction_duration(tokens)?.is_some()
    {
        return Ok(None);
    }

    // NOTE(equip-grant threshold, 2026-07-25): a guard declining
    // "equipped/enchanted creature has ..." lines here was tried and
    // REVERTED — with parse_cant_clauses out of the way the line reaches
    // parse_equipped_creature_has_line (whose parse_ability_line now handles
    // the by-more-than tail via KeywordAction::CantBeBlockedByMoreThan), but
    // compilation then fails downstream with "unsupported subject target
    // phrase (clause: 'trample')" from parse_subject_object_filter — a later
    // stage re-parses the grant subject. Root-cause that error before
    // re-adding the guard.

    if let Some((condition, remainder)) = strip_static_restriction_condition(tokens)?
        && remainder.as_slice() != tokens
    {
        let Some(abilities) = parse_cant_clauses(&remainder)? else {
            return Ok(None);
        };
        let conditioned = abilities
            .into_iter()
            .map(|ability| {
                ability
                    .clone()
                    .with_condition(condition.clone())
                    .unwrap_or(ability)
            })
            .collect::<Vec<_>>();
        return Ok(Some(conditioned));
    }

    // "This creature can't attack if it attacked during your last turn"
    // (Giant Turtle): a trailing turn-history condition gates the source's
    // own restriction, like the doesn't-untap form of the same condition.
    if let Some((neg_start, _)) = find_negation_span(tokens)
        && crate::util::is_source_reference_words(&crate::lexer::token_word_refs(
            &tokens[..neg_start],
        ))
        && let Some(if_index) = tokens.iter().rposition(|token| token.is_word("if"))
        && if_index > neg_start
        && let Some(condition) = crate::keyword_static::parse_attacked_during_controllers_last_turn(
            &trim_commas(&tokens[if_index + 1..]),
            crate::filter::ObjectFilter::source(),
        )
    {
        let head = trim_commas(&tokens[..if_index]);
        let Some(abilities) = parse_cant_clauses(&head)? else {
            return Ok(None);
        };
        return Ok(Some(
            abilities
                .into_iter()
                .map(|ability| {
                    ability
                        .clone()
                        .with_condition(condition.clone())
                        .unwrap_or(ability)
                })
                .collect(),
        ));
    }

    // "You have no maximum hand size and don't lose the game for having 0 or
    // less life" (Marina Vendrell's Grimoire): a shared player subject with a
    // positive hand-size rule and a negated player restriction. Each member
    // is its own static rule.
    if let Some(and_index) = tokens.iter().position(|token| token.is_word("and"))
        && let Some(have_index) = tokens[..and_index]
            .iter()
            .position(|token| token.is_word("have") || token.is_word("has"))
        && have_index > 0
        && let Ok(Some(hand_size)) =
            crate::keyword_static::parse_no_maximum_hand_size_line(&tokens[..and_index])
    {
        let mut negated = trim_commas(&tokens[..have_index]).to_vec();
        negated.extend(trim_commas(&tokens[and_index + 1..]).iter().cloned());
        if find_negation_span(&negated).is_some()
            && let Some(rest) = parse_cant_clauses(&negated)?
        {
            let mut abilities = vec![hand_size];
            abilities.extend(rest);
            return Ok(Some(abilities));
        }
    }

    // "Players can't play lands as long as ten or more lands are on the
    // battlefield" (Limited Resources) / "This creature can't be the target of
    // spells unless it attacked or blocked this turn" (Lurker): a trailing
    // static condition gates the whole restriction. "unless" is the negated
    // condition. Payment tails ("unless its controller pays ...") are not
    // static conditions and fall through to their own readers.
    if let Some((neg_start, neg_end)) = find_negation_span(tokens)
        && let Some((marker, condition_first, negated)) = tokens
            .iter()
            .enumerate()
            .skip(neg_end)
            .find_map(|(index, token)| {
                if token.is_word("unless") {
                    Some((index, index + 1, true))
                } else if token.is_word("as")
                    && tokens.get(index + 1).is_some_and(|next| next.is_word("long"))
                    && tokens.get(index + 2).is_some_and(|next| next.is_word("as"))
                {
                    Some((index, index + 3, false))
                } else {
                    None
                }
            })
        && marker > neg_start
        // Combat prohibitions with trailing conditions have dedicated owners
        // (attack taxes, conditional unblockability, "can't block as long as").
        && !matches!(
            crate::lexer::token_word_refs(&tokens[neg_end..marker]).as_slice(),
            ["attack", ..] | ["block", ..] | ["be", "blocked", ..]
        )
    {
        let head = trim_commas(&tokens[..marker]);
        let mut condition_tokens = trim_edge_punctuation_tokens(&tokens[condition_first..]).to_vec();
        // A source pronoun in the condition names the restricted object.
        if crate::util::is_source_reference_words(&crate::lexer::token_word_refs(
            &tokens[..neg_start],
        )) && condition_tokens.first().is_some_and(|token| token.is_word("it"))
        {
            let span = condition_tokens[0].span();
            let mut rebound = vec![
                OwnedLexToken::word("this".to_string(), span),
                OwnedLexToken::word("creature".to_string(), span),
            ];
            rebound.extend_from_slice(&condition_tokens[1..]);
            condition_tokens = rebound;
        }
        if !head.is_empty()
            && !condition_tokens.is_empty()
            && let Ok(condition) =
                crate::keyword_static::parse_static_condition_clause(&condition_tokens)
            && let Some(abilities) = parse_cant_clauses(&head)?
        {
            let condition = if negated {
                PredicateAst::Not(Box::new(condition))
            } else {
                condition
            };
            return Ok(Some(
                abilities
                    .into_iter()
                    .map(|ability| {
                        ability
                            .clone()
                            .with_condition(condition.clone())
                            .unwrap_or(ability)
                    })
                    .collect(),
            ));
        }
    }

    // A final origin can be shared by two different actions. Own the complete
    // clause before generic "or" splitting can turn a hand-only prohibition
    // into a ban on every land play.
    if let Some((_, neg_end)) = find_negation_span(tokens) {
        let tail = normalize_cant_word_refs(&tokens[neg_end..]);
        if crate::grammar::activation_restrictions::parse_compound_player_action_restriction_words(
            &tail,
        )
        .is_some()
            && let Some(restrictions) =
                super::activation_restriction_clauses::parse_cant_restrictions(tokens)?
            && restrictions
                .iter()
                .all(|restriction| restriction.target.is_none())
        {
            return Ok(Some(vec![StaticAbility::restrictions(
                restrictions
                    .into_iter()
                    .map(|parsed| parsed.restriction)
                    .collect(),
                format_negated_restriction_display(tokens),
            )]));
        }
    }

    // The combined attack-or-block wording is also superficially a blocking
    // payment clause. Claim its typed attack-unless meaning first so the
    // blocking-cost parser does not reinterpret the condition as a payment
    // segment (for example, `control seven or more lands`).
    let input = cant_clause_readings::CantClause {
        tokens,
        read_by_cache: Default::default(),
    };
    match cant_clause_readings::read(&input) {
        ParseOutcome::Match(matched) => return Ok(Some(matched.value.value)),
        ParseOutcome::NoMatch => {}
        ParseOutcome::Error(diagnostic) => return Err(diagnostic.into_card_text_error()),
    }
    // The declines the ladder made before its fallback still gate the fallback.
    if cant_clause_readings::declines(&input) {
        return Ok(None);
    }
    if cant_shapes::parse_stat_modifier_conjunction_decline_tokens(tokens).is_some() {
        return Ok(None);
    }

    if find_negation_span(tokens).is_none() {
        return Ok(None);
    }

    if let Some(segments) = split_cant_clause_on_or(tokens) {
        let mut abilities = Vec::new();
        for segment in segments {
            let Some(ability) = parse_cant_clause(&segment)? else {
                return Err(CardTextError::ParseError(format!(
                    "unsupported cant clause segment (clause: '{}')",
                    crate::lexer::token_word_refs(&segment).join(" ")
                )));
            };
            abilities.push(ability);
        }
        if !abilities.is_empty() {
            return Ok(Some(abilities));
        }
    }

    if let Some(expansion) = cant_shapes::parse_cant_conjunction_expansion_tokens(tokens) {
        let mut abilities = Vec::new();
        for segment in expansion.segments {
            let Some(ability) = parse_cant_clause(&segment)? else {
                return Err(CardTextError::ParseError(format!(
                    "unsupported cant clause segment (clause: '{}')",
                    crate::lexer::token_word_refs(&segment).join(" ")
                )));
            };
            abilities.push(ability);
        }
        if !abilities.is_empty() {
            return Ok(Some(abilities));
        }
    }

    parse_cant_clause(tokens).map(|ability| ability.map(|ability| vec![ability]))
}

pub fn split_cant_clause_on_or(tokens: &[OwnedLexToken]) -> Option<Vec<Vec<OwnedLexToken>>> {
    crate::grammar::activation_restrictions::parse_cant_restriction_or_split_tokens(tokens)
        .map(|split| vec![split.first, split.second])
}

/// "Players/You don't lose unspent [color] mana as steps and phases end."
/// (Upwelling, Omnath Locus of Mana, Leyline Tyrant.)
fn parse_unspent_mana_retention_static(
    tokens: &[OwnedLexToken],
    words: &[&str],
) -> Option<StaticAbility> {
    use crate::grammar::activation_restrictions::ManaRetentionSubject;

    let parsed =
        crate::grammar::activation_restrictions::parse_unspent_mana_retention_static_words(words)?;
    // `words` are normalized copies of every word of `tokens`, which the
    // complete parse above read.
    crate::word_claims::claim_tokens(tokens);
    let subject = match parsed.subject {
        ManaRetentionSubject::You => PlayerFilter::You,
        ManaRetentionSubject::AnyPlayer => PlayerFilter::Any,
    };
    Some(StaticAbility::restriction(
        crate::effect::Restriction::lose_unspent_mana(subject, parsed.color),
        format_negated_restriction_display(tokens),
    ))
}

pub fn parse_cant_clause(tokens: &[OwnedLexToken]) -> Result<Option<StaticAbility>, CardTextError> {
    if let Some(split) = crate::grammar::structure::split_trailing_if_clause_lexed(tokens)
        && !split.leading_tokens.is_empty()
        && split.leading_tokens.len() < tokens.len()
        && matches!(
            cant_shapes::parse_direct_cant_fact_tokens(split.leading_tokens),
            Some(
                DirectCantFact::SourceCantAttack
                    | DirectCantFact::SourceCantBlock
                    | DirectCantFact::SourceCantAttackOrBlock
            )
        )
        && let Some(ability) = parse_cant_clause(split.leading_tokens)?
    {
        let predicate = crate::grammar::filters::parse_intrinsic_source_counter_condition(
            split.predicate_tokens,
        )
        .unwrap_or(split.predicate);
        return Ok(Some(ability.with_condition(predicate)));
    }
    if let Some((condition, remainder)) = strip_static_restriction_condition(tokens)?
        && remainder.as_slice() != tokens
    {
        let Some(ability) = parse_cant_clause(&remainder)? else {
            return Ok(None);
        };
        let conditioned = ability.clone().with_condition(condition.clone());
        return Ok(Some(conditioned));
    }
    // "Shauku can't attack if there's another creature on the battlefield.":
    // a source combat prohibition gated by a trailing static condition (the
    // restriction applies only while the condition holds). "can't be blocked
    // if ..." belongs to parse_subject_cant_be_blocked_as_long_as_condition_line.
    if let Some(if_idx) = tokens.iter().rposition(|token| token.is_word("if"))
        && if_idx > 0
        && if_idx + 1 < tokens.len()
    {
        let leading = trim_edge_punctuation_tokens(&tokens[..if_idx]);
        let predicate_tokens = trim_edge_punctuation_tokens(&tokens[if_idx + 1..]);
        if !leading.is_empty()
            && !predicate_tokens.is_empty()
            && matches!(
                cant_shapes::parse_direct_cant_fact_tokens(leading),
                Some(
                    DirectCantFact::SourceCantAttack
                        | DirectCantFact::SourceCantBlock
                        | DirectCantFact::SourceCantAttackOrBlock
                )
            )
            && let Ok(predicate) = crate::keyword_static::parse_static_condition_clause(predicate_tokens)
            && let Some(ability) = parse_cant_clause(leading)?
        {
            return Ok(Some(ability.with_condition(predicate)));
        }
    }
    if let Some((_, remainder)) = parse_restriction_duration(tokens)?
        && !remainder.is_empty()
        && remainder.len() < tokens.len()
        && cant_shapes::parse_negated_untap_remainder_tokens(&remainder).is_some()
    {
        return Ok(None);
    }
    let normalized = normalize_cant_word_refs(tokens);
    if matches!(
        crate::grammar::activation_restrictions::parse_mana_retention_negated_clause_words(
            &normalized,
        ),
        Some(
            crate::grammar::activation_restrictions::ManaRetentionNegatedClause {
                tail: crate::grammar::activation_restrictions::ManaRetentionTailKind::ThisMana,
            }
        )
    ) {
        return Ok(None);
    }
    if let Some(ability) = parse_unspent_mana_retention_static(tokens, &normalized) {
        return Ok(Some(ability));
    }

    if let Some(fact) = cant_shapes::parse_per_attacker_cant_tax_tokens(tokens) {
        return Ok(Some(if fact.covers_planeswalkers {
            StaticAbility::cant_attack_you_or_planeswalkers_unless_controller_pays_per_attacker(
                fact.amount,
            )
        } else {
            StaticAbility::cant_attack_you_unless_controller_pays_per_attacker(fact.amount)
        }));
    }

    if let Some(ability) = typed_attack_tax_static_ability(tokens)? {
        return Ok(Some(ability));
    }

    if let Some(ability) = planeswalker_attack_tax_static_ability(tokens) {
        return Ok(Some(ability));
    }

    if let Some(ability) = attack_unless_static_ability(tokens) {
        return Ok(Some(ability));
    }

    if let Some(ability) = blocking_cant_static_ability(tokens) {
        return Ok(Some(ability));
    }

    // "can't block alone" is a block-legality requirement on the source
    // (CR 509.1b), not "can't block <an attacker named 'alone'>".
    if matches!(
        cant_shapes::parse_direct_cant_fact_tokens(tokens),
        Some(DirectCantFact::SourceCantBlockAlone)
    ) && let Some(StaticAbilityShapeResolution::Ability(ability)) =
        direct_cant_static_ability(tokens)
    {
        return Ok(Some(ability));
    }

    if let Some(action) = cant_shapes::parse_generic_negated_cant_action_tokens(tokens) {
        match action {
            cant_shapes::GenericNegatedCantAction::SourceBlocksAttacker {
                attacker_tokens, ..
            } => {
                let attacker_tokens = trim_commas(attacker_tokens);
                let attacker_filter = parse_subject_object_filter(&attacker_tokens)?
                    .or_else(|| {
                        crate::grammar::primitives::probe_shape(parse_object_filter(
                            &attacker_tokens,
                            false,
                        ))
                    })
                    .ok_or_else(|| {
                        CardTextError::ParseError(format!(
                            "unsupported blocker restriction filter (clause: '{}')",
                            crate::lexer::token_word_refs(tokens).join(" ")
                        ))
                    })?;
                return Ok(Some(StaticAbility::restriction(
                    crate::effect::Restriction::block_specific_attacker(
                        ObjectFilter::source(),
                        attacker_filter,
                    ),
                    format!(
                        "this creature can't block {}",
                        crate::lexer::token_word_refs(&attacker_tokens).join(" ")
                    ),
                )));
            }
            cant_shapes::GenericNegatedCantAction::SubjectCantTurnFaceUp {
                subject_tokens, ..
            } => {
                let subject_tokens = trim_commas(subject_tokens);
                let Some(filter) = parse_subject_object_filter(&subject_tokens)? else {
                    return Ok(None);
                };
                let subject_text = crate::lexer::token_word_refs(&subject_tokens).join(" ");
                if subject_text.is_empty() {
                    return Ok(None);
                }
                return Ok(Some(StaticAbility::restriction(
                    crate::effect::Restriction::turn_face_up(filter),
                    format!("{subject_text} can't be turned face up"),
                )));
            }
            cant_shapes::GenericNegatedCantAction::SubjectCantTransform {
                subject_tokens, ..
            } => {
                let subject_tokens = trim_commas(subject_tokens);
                let Some(filter) = parse_subject_object_filter(&subject_tokens)? else {
                    return Ok(None);
                };
                let subject_text = crate::lexer::token_word_refs(&subject_tokens).join(" ");
                if subject_text.is_empty() {
                    return Ok(None);
                }
                return Ok(Some(StaticAbility::restriction(
                    crate::effect::Restriction::transform(filter),
                    format!("{subject_text} can't transform"),
                )));
            }
        }
    }

    if let Some(ability) = parity_cant_static_ability(tokens) {
        return Ok(Some(ability));
    }

    if let Some(ability) = fallback_cant_static_ability(tokens) {
        return Ok(Some(ability));
    }

    if let Some(resolution) = direct_cant_static_ability(tokens) {
        match resolution {
            StaticAbilityShapeResolution::Ability(ability) => return Ok(Some(ability)),
            StaticAbilityShapeResolution::Decline => return Ok(None),
        }
    }

    if let Some(parsed) = parse_cant_restriction_clause(tokens)?
        && parsed.target.is_none()
        && matches!(
            parsed.restriction,
            crate::effect::Restriction::GainLife(_)
                | crate::effect::Restriction::SearchLibraries(_)
                | crate::effect::Restriction::CastSpellsMatching(_, _)
                | crate::effect::Restriction::PlayLandsMatching(_, _)
                | crate::effect::Restriction::ActivateLoyaltyAbilitiesOf(_)
                | crate::effect::Restriction::ActivateKeywordAbilitiesOf { .. }
                | crate::effect::Restriction::ActivateNonManaAbilities(_)
                | crate::effect::Restriction::ActivateNonManaNonLoyaltyAbilities(_)
                | crate::effect::Restriction::ActivateAbilitiesOf(_)
                | crate::effect::Restriction::ActivateTapAbilitiesOf(_)
                | crate::effect::Restriction::ActivateNonManaAbilitiesOf(_)
                | crate::effect::Restriction::CastMoreThanOneSpellEachTurn(_, _)
                | crate::effect::Restriction::BlockWithMoreThan { .. }
                | crate::effect::Restriction::VentureMoreThanOnceEachTurn(_)
                | crate::effect::Restriction::DrawCards(_)
                | crate::effect::Restriction::DrawExtraCards(_)
                | crate::effect::Restriction::GetCounters(_)
                | crate::effect::Restriction::RadiationGainsLife(_)
                | crate::effect::Restriction::LoseLife(_)
                | crate::effect::Restriction::ChangeLifeTotal(_)
                | crate::effect::Restriction::LoseGame(_)
                | crate::effect::Restriction::LoseGameForZeroLife(_)
                | crate::effect::Restriction::WinGame(_)
                | crate::effect::Restriction::PreventDamage
        )
    {
        let ability = StaticAbility::restriction(
            parsed.restriction,
            format_negated_restriction_display(tokens),
        );
        return Ok(Some(ability));
    }

    if let Some(parsed) = parse_negated_object_restriction_clause(tokens)?
        && parsed.target.is_none()
    {
        return Ok(Some(StaticAbility::restriction(
            parsed.restriction,
            format_negated_restriction_display(tokens),
        )));
    }
    Ok(None)
}

#[cfg(test)]
mod tests {
    use super::super::super::util::tokenize_line;
    use super::*;

    #[test]
    fn opponent_caused_sacrifice_protection_is_a_typed_static_restriction() {
        let tokens = tokenize_line(
            "Spells and abilities your opponents control can't cause you to sacrifice permanents.",
            0,
        );
        let ability = parse_cant_clause(&tokens)
            .unwrap()
            .expect("sacrifice protection must be static");
        let debug = format!("{ability:#?}");
        assert!(debug.contains("BeSacrificedByCause"), "{debug}");
        assert!(debug.contains("Opponent"), "{debug}");
        assert!(
            debug.contains("Cost"),
            "opponent-requested payments must be included: {debug}"
        );
    }

    #[test]
    fn extra_turn_attack_restriction_is_a_typed_condition() {
        let tokens = tokenize_line("This can't attack during extra turns.", 0);
        let ability = parse_cant_clause(&tokens)
            .expect("extra-turn attack restriction should parse")
            .expect("extra-turn attack restriction should be claimed");
        let debug = format!("{ability:#?}");
        assert!(debug.contains("CantAttack"), "{debug}");
        assert!(debug.contains("CurrentTurnIsExtra"), "{debug}");
    }

    #[test]
    fn permanents_cant_phase_in_is_a_typed_static_restriction() {
        let tokens = crate::lexer::lex_line("Permanents can't phase in.", 0)
            .expect("phase-in restriction should lex");
        let abilities = parse_cant_clauses(&tokens)
            .expect("phase-in restriction should parse")
            .expect("phase-in restriction should be claimed as static");
        assert_eq!(abilities.len(), 1);
        assert!(
            format!("{:#?}", abilities[0]).contains("PhaseIn"),
            "{abilities:#?}"
        );
        let repeated = parse_cant_clauses(&tokens)
            .expect("repeated phase-in restriction parse should not error")
            .expect("repeated phase-in restriction parse should remain static");
        assert!(
            format!("{:#?}", repeated[0]).contains("PhaseIn"),
            "{repeated:#?}"
        );

        let contextual = parse_cant_clauses(&tokens)
            .expect("phase-in restriction should parse in a card source context")
            .expect("phase-in restriction should remain static in a card source context");
        assert!(
            format!("{:#?}", contextual[0]).contains("PhaseIn"),
            "{contextual:#?}"
        );
    }

    #[test]
    fn except_for_named_and_type_filters_stay_one_attack_restriction() {
        let tokens = crate::lexer::lex_line(
            "Except for creatures named Akron Legionnaire and artifact creatures, creatures you control can't attack.",
            0,
        )
        .expect("exception restriction should lex");

        let abilities = parse_cant_clauses(&tokens)
            .expect("except-for attack restriction should parse")
            .expect("expected one static restriction");

        assert_eq!(abilities.len(), 1);
        assert_eq!(
            abilities[0].display(),
            "Except for creatures named Akron Legionnaire and artifact creatures, creatures you control can't attack"
        );
        let ironsmith_core::StaticAbilityPayload::RuleRestriction {
            restriction: crate::effect::Restriction::Attack(filter),
            ..
        } = &abilities[0].payload
        else {
            panic!("expected one typed attack restriction: {:#?}", abilities[0]);
        };
        assert_eq!(filter.controller, Some(PlayerFilter::You));
        assert_eq!(filter.excluded_name.as_deref(), Some("akron legionnaire"));
        assert!(
            filter.excluded_card_types.contains(&CardType::Artifact),
            "{filter:#?}"
        );
    }

    #[test]
    fn cant_attack_its_owner_or_their_planeswalkers_names_the_source_owner() {
        let tokens = tokenize_line(
            "This creature can't attack its owner or planeswalkers its owner controls.",
            0,
        );
        let abilities = parse_cant_clauses(&tokens)
            .expect("owner attack restriction should parse")
            .expect("expected a typed restriction");
        let [ability] = abilities.as_slice() else {
            panic!("expected one restriction: {abilities:#?}");
        };
        let ironsmith_core::StaticAbilityPayload::RuleRestriction {
            restriction:
                crate::effect::Restriction::AttackPlayerOrPlaneswalkersControlledBy {
                    attackers,
                    player: PlayerFilter::OwnerOf(owner_of),
                },
            ..
        } = &ability.payload
        else {
            panic!("expected the owner's player-or-planeswalkers ban: {ability:#?}");
        };
        assert!(attackers.source, "{attackers:#?}");
        assert_eq!(
            *owner_of,
            crate::filter::ObjectRef::tagged(ironsmith_core::SOURCE_OBJECT_TAG)
        );
    }

    #[test]
    fn pronoun_conjunction_inherits_the_typed_restriction_subject() {
        let tokens = tokenize_line(
            "Clerics your opponents control can't block, and they can't attack you or planeswalkers you control.",
            0,
        );

        let abilities = parse_cant_clauses(&tokens)
            .expect("shared-subject restrictions should parse")
            .expect("expected two typed restrictions");
        assert_eq!(abilities.len(), 2, "{abilities:#?}");

        let ironsmith_core::StaticAbilityPayload::RuleRestriction {
            restriction: crate::effect::Restriction::Block(blockers),
            ..
        } = &abilities[0].payload
        else {
            panic!("expected a block restriction: {:#?}", abilities[0]);
        };
        let ironsmith_core::StaticAbilityPayload::RuleRestriction {
            restriction:
                crate::effect::Restriction::AttackPlayerOrPlaneswalkersControlledBy {
                    attackers,
                    player: PlayerFilter::You,
                },
            ..
        } = &abilities[1].payload
        else {
            panic!("expected an attack-target restriction: {:#?}", abilities[1]);
        };

        assert_eq!(blockers, attackers);
        assert_eq!(blockers.controller, Some(PlayerFilter::Opponent));
        assert!(blockers.subtypes.contains(&crate::Subtype::Cleric));
        assert_eq!(
            abilities[1].display(),
            "clerics your opponents control can't attack you or planeswalkers you control"
        );
    }

    #[test]
    fn parse_cant_attack_or_block_unless_cards_in_exile_condition() {
        let tokens = tokenize_line(
            "This creature can't attack or block unless there are seven or more cards in exile.",
            0,
        );

        let abilities = parse_cant_clauses(&tokens)
            .expect("cant-attack-or-block-unless-exile-count should parse")
            .expect("expected a static restriction");

        assert_eq!(abilities.len(), 1);
        let debug = format!("{:?}", abilities[0]);
        assert!(debug.contains("AttackOrBlock"), "{debug}");
        assert!(debug.contains("ValueComparison"), "{debug}");
        assert!(debug.contains("GreaterThanOrEqual"), "{debug}");
        assert!(debug.contains("Fixed(7)"), "{debug}");
        assert!(debug.contains("Exile"), "{debug}");

        let display = abilities[0].display().to_ascii_lowercase();
        assert!(
            display.contains("can't attack or block unless there are seven or more cards in exile")
                || display
                    .contains("cant attack or block unless there are seven or more cards in exile"),
            "expected original conditional attack/block restriction text, got {display}"
        );
    }

    #[test]
    fn parse_direct_attack_or_block_tap_cost_with_combatant_exclusion() {
        let tokens = tokenize_line(
            "This creature can't attack or block unless you tap an untapped creature you control not declared as an attacking or blocking creature this combat.",
            0,
        );
        let abilities = parse_cant_clauses(&tokens)
            .expect("direct attack-or-block tap cost should not error")
            .expect("direct attack-or-block tap cost should parse");
        assert_eq!(abilities.len(), 1, "{abilities:#?}");
        assert!(matches!(
            abilities[0].payload,
            ironsmith_core::StaticAbilityPayload::BlockCost { .. }
        ));
    }

    #[test]
    fn u035_lowers_source_counter_limit_to_typed_static_payload() {
        let tokens = tokenize_line(
            "This creature can't have more than seven dream counters on it.",
            0,
        );
        let abilities = parse_cant_clauses(&tokens)
            .expect("counter limit should parse")
            .expect("counter limit should lower to a static ability");
        assert_eq!(abilities.len(), 1);
        assert_eq!(
            abilities[0].id(),
            crate::static_abilities::StaticAbilityId::CounterLimit
        );
        assert!(matches!(
            &abilities[0].payload,
            ironsmith_core::StaticAbilityPayload::CounterLimit {
                counter_type: CounterType::Dream,
                maximum: 7,
                ..
            }
        ));
    }

    #[test]
    fn parse_cant_attack_unless_routes_control_tail_through_capture_shape() {
        let cases = [
            (
                "This creature can't attack unless you control another artifact.",
                "other: true",
            ),
            (
                "This creature can't attack unless you control seven or more lands.",
                "PlayerHasAtLeast",
            ),
        ];

        for (text, expected_debug) in cases {
            let tokens = tokenize_line(text, 0);
            let abilities = parse_cant_clauses(&tokens)
                .expect("cant-attack-unless-control condition should parse")
                .expect("expected a static restriction");

            assert_eq!(abilities.len(), 1, "{text}");
            let debug = format!("{:?}", abilities[0]);
            assert!(debug.contains("CantAttackUnlessCondition"), "{debug}");
            assert!(debug.contains(expected_debug), "{debug}");
        }
    }

    #[test]
    fn parse_cant_attack_unless_routes_defending_player_control_tail_through_capture_shape() {
        let cases = [
            (
                "This creature can't attack unless defending player controls an Island.",
                "Island",
            ),
            (
                "This creature can't attack unless defending player controls a snow land.",
                "Snow",
            ),
            (
                "This creature can't attack unless defending player controls a creature with flying.",
                "Flying",
            ),
            (
                "This creature can't attack unless defending player controls a blue permanent.",
                "colors: Some",
            ),
        ];

        for (text, expected_debug) in cases {
            let tokens = tokenize_line(text, 0);
            let abilities = parse_cant_clauses(&tokens)
                .expect("cant-attack-unless-defending-player-controls condition should parse")
                .expect("expected a static restriction");

            assert_eq!(abilities.len(), 1, "{text}");
            let debug = format!("{:?}", abilities[0]);
            assert!(debug.contains("DefendingPlayerCondition"), "{debug}");
            assert!(debug.contains(expected_debug), "{debug}");
        }
    }

    #[test]
    fn parse_this_token_cant_be_blocked_clause() {
        let tokens = tokenize_line("This token can't be blocked.", 0);

        let abilities = parse_cant_clauses(&tokens)
            .expect("this-token-cant-be-blocked clause should parse")
            .expect("expected unblockable static ability");

        assert_eq!(abilities.len(), 1);
        let display = abilities[0].display().to_ascii_lowercase();
        let debug = format!("{:?}", abilities[0]).to_ascii_lowercase();
        assert!(
            display.contains("can't be blocked")
                || display.contains("cant be blocked")
                || display.contains("unblockable")
                || debug.contains("unblockable"),
            "expected unblockable static ability, display={display}, debug={debug}"
        );
    }

    #[test]
    fn compound_keyword_maximum_blocker_line_is_owned_by_the_grant_grammar() {
        let tokens = tokenize_line(
            "Equipped creature has trample and can't be blocked by more than one creature.",
            0,
        );

        assert!(
            parse_cant_clauses(&tokens)
                .expect("generic restriction probe should not error")
                .is_none()
        );
    }
}

#[cfg(test)]
mod filtered_block_cost_tests {
    use super::*;

    #[test]
    fn next_controller_turn_restriction_is_not_a_static_ability() {
        let tokens = crate::lexer::lex_line(
            "That creature can't attack during its controller's next turn.",
            0,
        ).unwrap();
        assert!(crate::grammar::effects::clause_dispatch_shapes::parse_next_turn_cant_shape_tokens(&tokens).is_some());
        assert!(parse_cant_clauses(&tokens).unwrap().is_none());
    }

    #[test]
    fn filtered_blockers_keep_their_life_payment_and_attacker_scope() {
        let tokens = crate::lexer::lex_line("Nonblue creatures can't block creatures you control unless their controller pays 1 life for each blocking creature they control.", 0).unwrap();
        let abilities = parse_cant_clauses(&tokens)
            .unwrap()
            .expect("filtered blocking cost");
        let [ability] = abilities.as_slice() else {
            panic!("one block cost: {abilities:#?}");
        };
        let ironsmith_core::StaticAbilityPayload::BlockCost {
            blockers,
            attackers,
            cost,
            ..
        } = &ability.payload
        else {
            panic!("typed blocking payment: {ability:#?}");
        };
        assert_eq!(blockers.excluded_colors, crate::color::ColorSet::BLUE);
        assert_eq!(attackers.controller, Some(crate::target::PlayerFilter::You));
        assert!(
            format!("{cost:?}").contains("Life"),
            "life payment: {cost:#?}"
        );
    }
}

#[cfg(test)]
mod durationless_filtered_unpreventability_admission_tests {
    use super::*;
    use crate::util::tokenize_line;

    #[test]
    fn complete_passive_damage_rule_is_static_despite_damage_effect_head() {
        for text in [
            "Damage dealt by sources with text added from this card can't be prevented.",
            "Damage that would be dealt by red creatures can't be prevented.",
        ] {
            let tokens = tokenize_line(text, 0);
            assert!(parse_cant_clauses(&tokens).unwrap().is_some(), "{text}");
        }
    }

    #[test]
    fn timed_or_imperative_damage_programs_remain_resolving() {
        for text in [
            "Damage dealt by red creatures can't be prevented this turn.",
            "Deal 2 damage to any target. Damage can't be prevented this turn.",
        ] {
            let tokens = tokenize_line(text, 0);
            assert!(parse_cant_clauses(&tokens).unwrap().is_none(), "{text}");
        }
    }
}
