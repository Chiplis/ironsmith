//! Composable zone change trigger.
//!
//! This unified trigger expresses zone-change patterns with a single
//! composable type.
//!
//! # Examples
//!
//! ```ignore
//! // "Whenever a creature dies"
//! ZoneChangeTrigger::new()
//!     .from(Zone::Battlefield)
//!     .to(Zone::Graveyard)
//!     .filter(ObjectFilter::creature())
//!
//! // "Whenever you discard a card"
//! ZoneChangeTrigger::new()
//!     .from(Zone::Hand)
//!     .to(Zone::Graveyard)
//!     .player(PlayerRelation::You)
//!
//! // "Whenever a card is put into your graveyard from anywhere"
//! ZoneChangeTrigger::new()
//!     .to(Zone::Graveyard)
//!     .player(PlayerRelation::You)
//! ```

use crate::events::EventKind;
use crate::events::cause::{CauseFilter, CauseFilterRuntimeExt as _};
use crate::events::zones::ZoneChangeEvent;
use crate::filter::ObjectFilterExt as _;
use crate::target::{ObjectFilter, PlayerFilter};
use crate::triggers::TriggerEvent;
use crate::triggers::matcher_trait::{
    TriggerContext, TriggerMatcher, current_turn_matches_player_filter,
};
use crate::types::CardType;
use crate::zone::Zone;
pub use ironsmith_core::trigger_model::{
    GraveyardTriggerSurface, TriggerSubjectNumber, ZoneChangeOriginCondition,
};

/// The ", if it entered from X or was cast from X" display suffix for a
/// zone-change origin condition.
pub(crate) fn moved_or_cast_origin_display_suffix(
    origin: &ZoneChangeOriginCondition,
    plural: bool,
) -> String {
    origin.display_suffix(plural)
}
use std::fmt;

/// Pattern for matching zones in zone change events.
#[derive(Clone, PartialEq, Default)]
pub enum ZonePattern {
    /// Match any zone.
    #[default]
    Any,
    /// Match a specific zone.
    Specific(Zone),
    /// Match any of these zones.
    OneOf(Vec<Zone>),
    /// Match any zone except this one.
    AnyExcept(Zone),
}

impl fmt::Debug for ZonePattern {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::Any => f.write_str("Any"),
            Self::Specific(zone) => write!(f, "Specific({zone:?})"),
            Self::OneOf(zones) => f.debug_tuple("OneOf").field(zones).finish(),
            Self::AnyExcept(zone) => write!(f, "AnyExcept({zone:?})"),
        }
    }
}

impl ZonePattern {
    /// Check if a zone matches this pattern.
    pub fn matches(&self, zone: Zone) -> bool {
        match self {
            ZonePattern::Any => true,
            ZonePattern::Specific(z) => zone == *z,
            ZonePattern::OneOf(zones) => zones.contains(&zone),
            ZonePattern::AnyExcept(z) => zone != *z,
        }
    }
}

impl From<Zone> for ZonePattern {
    fn from(zone: Zone) -> Self {
        ZonePattern::Specific(zone)
    }
}

/// How the player relates to the zone change (owner/controller of the object).
#[derive(Debug, Clone, PartialEq, Default)]
pub enum PlayerRelation {
    /// Match any player's objects.
    #[default]
    Any,
    /// Match objects owned/controlled by the trigger's controller.
    You,
    /// Match objects owned/controlled by an opponent of the trigger's controller.
    Opponent,
}

/// How many times the trigger fires for batch events.
#[derive(Debug, Clone, PartialEq, Default)]
pub enum CountMode {
    /// Fire once per object ("Whenever a creature dies").
    #[default]
    Each,
    /// Fire once for the batch ("Whenever one or more creatures die").
    OneOrMore,
}

/// A composable trigger for zone change events.
///
/// This single type can express:
/// - "Whenever a creature dies" (battlefield -> graveyard, creature filter)
/// - "Whenever you discard a card" (hand -> graveyard, you)
/// - "Whenever a permanent enters the battlefield" (any -> battlefield)
/// - "Whenever a card is put into your graveyard" (any -> graveyard, you)
/// - And many more combinations
#[derive(Debug, Clone, PartialEq)]
pub struct ZoneChangeTrigger {
    /// The zone the object is leaving.
    pub from: ZonePattern,
    /// The zone the object is entering.
    pub to: ZonePattern,
    /// Filter for matching objects.
    pub object_filter: ObjectFilter,
    /// Who owns/controls the object.
    pub player: PlayerRelation,
    /// Optional filter on what caused the zone change.
    pub cause_filter: Option<CauseFilter>,
    /// Require the event to be the linked exile duration return of this source.
    pub duration_return_from_source: bool,
    /// Match only a spell changing zones during its own successful resolution.
    pub during_own_resolution: bool,
    /// Optional active-turn qualifier.
    pub during_turn: Option<PlayerFilter>,
    /// Optional phase restriction on when the event occurs.
    pub timing: Option<ironsmith_core::TriggerTimingRestriction>,
    /// Optional provenance qualifier on how the destination object originated.
    pub origin_condition: Option<ZoneChangeOriginCondition>,
    /// How many times to fire for batch events.
    pub count_mode: CountMode,
    /// If true, only trigger for the source object ("When ~ dies").
    pub this_object: bool,
    /// Original source-reference surface for source-object trigger text.
    pub this_object_surface: Option<crate::target::SourceReferenceSurface>,
    /// Authored grammatical number for a named source-object subject.
    pub this_object_subject_number: TriggerSubjectNumber,
    /// Authored graveyard-event wording. Presentation-only; never read while matching.
    pub graveyard_surface: Option<GraveyardTriggerSurface>,
}

impl Default for ZoneChangeTrigger {
    fn default() -> Self {
        Self {
            from: ZonePattern::Any,
            to: ZonePattern::Any,
            object_filter: ObjectFilter::default(),
            player: PlayerRelation::Any,
            cause_filter: None,
            duration_return_from_source: false,
            during_own_resolution: false,
            during_turn: None,
            timing: None,
            origin_condition: None,
            count_mode: CountMode::Each,
            this_object: false,
            this_object_surface: None,
            this_object_subject_number: TriggerSubjectNumber::Singular,
            graveyard_surface: None,
        }
    }
}

impl ZoneChangeTrigger {
    /// Create a new zone change trigger with default settings (matches everything).
    pub fn new() -> Self {
        Self::default()
    }

    /// Require a linked exile duration return from this trigger source.
    pub fn duration_return_from_source(mut self) -> Self {
        self.duration_return_from_source = true;
        self
    }

    /// Require the moving spell to be in its own successful resolution.
    pub fn during_own_resolution(mut self) -> Self {
        self.during_own_resolution = true;
        self
    }

    /// Set the source zone pattern.
    pub fn from(mut self, zone: impl Into<ZonePattern>) -> Self {
        self.from = zone.into();
        self
    }

    /// Set the destination zone pattern.
    pub fn to(mut self, zone: impl Into<ZonePattern>) -> Self {
        self.to = zone.into();
        self
    }

    /// Set the object filter.
    pub fn filter(mut self, filter: ObjectFilter) -> Self {
        self.object_filter = filter;
        self
    }

    /// Set the player relation.
    pub fn player(mut self, player: PlayerRelation) -> Self {
        self.player = player;
        self
    }

    /// Set the cause filter.
    pub fn cause(mut self, cause: CauseFilter) -> Self {
        self.cause_filter = Some(cause);
        self
    }

    /// Set or clear the cause filter.
    pub fn cause_filter(mut self, cause_filter: Option<CauseFilter>) -> Self {
        self.cause_filter = cause_filter;
        self
    }

    /// Set the active-turn qualifier.
    pub fn during_turn(mut self, player: PlayerFilter) -> Self {
        self.during_turn = Some(player);
        self
    }

    /// Restrict this zone-change trigger to events that occur during combat.
    pub fn during_combat(mut self) -> Self {
        self.timing = Some(ironsmith_core::TriggerTimingRestriction::DuringCombat);
        self
    }

    /// Require additional provenance for the object entering the destination zone.
    pub fn origin_condition(mut self, condition: ZoneChangeOriginCondition) -> Self {
        self.origin_condition = Some(condition);
        self
    }

    /// Set the count mode.
    pub fn count(mut self, mode: CountMode) -> Self {
        self.count_mode = mode;
        self
    }

    /// Make this trigger only match the source object ("When ~ dies").
    pub fn this(mut self) -> Self {
        self.this_object = true;
        self
    }

    pub fn this_surface(mut self, surface: crate::target::SourceReferenceSurface) -> Self {
        self.this_object_surface = Some(surface);
        self
    }

    pub fn this_subject_number(mut self, number: TriggerSubjectNumber) -> Self {
        self.this_object_subject_number = number;
        self
    }

    pub fn graveyard_surface(mut self, surface: GraveyardTriggerSurface) -> Self {
        self.graveyard_surface = Some(surface);
        self
    }

    // === Convenience constructors for common patterns ===

    /// "Whenever a [filter] dies" (battlefield -> graveyard)
    pub fn dies(filter: ObjectFilter) -> Self {
        Self::new()
            .from(Zone::Battlefield)
            .to(Zone::Graveyard)
            .filter(filter)
    }

    /// "When ~ dies"
    pub fn this_dies() -> Self {
        // "Dies" means "is put into a graveyard from the battlefield" for any
        // permanent (CR 700.4), not only creatures: an uncrewed Vehicle or a
        // Role Aura with "when this dies" triggers too. The object with the
        // ability is the whole subject, so no type filter applies.
        Self::new()
            .from(Zone::Battlefield)
            .to(Zone::Graveyard)
            .graveyard_surface(GraveyardTriggerSurface::Dies)
            .this()
    }

    /// "Whenever a [filter] enters the battlefield"
    pub fn enters_battlefield(filter: ObjectFilter) -> Self {
        Self::new().to(Zone::Battlefield).filter(filter)
    }

    /// "When ~ enters the battlefield"
    pub fn this_enters_battlefield() -> Self {
        Self::enters_battlefield(ObjectFilter::default()).this()
    }

    /// "Whenever a [filter] leaves the battlefield"
    pub fn leaves_battlefield(filter: ObjectFilter) -> Self {
        Self::new().from(Zone::Battlefield).filter(filter)
    }

    /// "When ~ leaves the battlefield"
    pub fn this_leaves_battlefield() -> Self {
        Self::leaves_battlefield(ObjectFilter::default()).this()
    }

    /// "Whenever you discard a card"
    pub fn you_discard() -> Self {
        Self::new()
            .from(Zone::Hand)
            .to(Zone::Graveyard)
            .player(PlayerRelation::You)
    }

    /// "Whenever a card is put into your graveyard from anywhere"
    pub fn card_enters_your_graveyard() -> Self {
        Self::new().to(Zone::Graveyard).player(PlayerRelation::You)
    }

    /// "Whenever a [filter] is exiled"
    pub fn exiled(filter: ObjectFilter) -> Self {
        Self::new().to(Zone::Exile).filter(filter)
    }

    /// Generate display text for this trigger.
    fn generate_display(&self) -> String {
        fn subject_is_creature_subtype_only(filter: &ObjectFilter) -> bool {
            filter.all_card_types.is_empty()
                && filter.card_types.is_empty()
                && !filter.subtypes.is_empty()
                && filter
                    .subtypes
                    .iter()
                    .all(|subtype| subtype.is_creature_type())
        }

        fn subject_is_always_creature(filter: &ObjectFilter) -> bool {
            if !filter.all_card_types.is_empty() {
                return filter.all_card_types.contains(&CardType::Creature);
            }
            if filter.card_types.len() == 1 && filter.card_types[0] == CardType::Creature {
                return true;
            }
            // A filter naming only creature subtypes ("Insect you control")
            // reads as a creature in oracle text: "another Insect ... dies".
            subject_is_creature_subtype_only(filter)
        }

        fn subject_description_for_zone_change(filter: &ObjectFilter) -> String {
            if filter.other {
                let mut explicit_other = filter.clone();
                explicit_other.other = false;
                let description = explicit_other.description();
                let mut subject = description
                    .strip_prefix("a ")
                    .or_else(|| description.strip_prefix("an "))
                    .map(str::to_string)
                    .unwrap_or(description);
                if let Some(stripped) = subject.strip_prefix("another ") {
                    subject = stripped.to_string();
                }
                return format!("another {subject}");
            }
            if filter.all_card_types.is_empty()
                && filter.card_types.is_empty()
                && filter.subtypes.len() == 1
            {
                let description = filter.description();
                match filter.subtypes[0] {
                    crate::types::Subtype::Equipment => {
                        return description
                            .replace("equipment", "Equipment")
                            .replace("a Equipment", "an Equipment");
                    }
                    crate::types::Subtype::Aura => {
                        return description
                            .replace("aura", "Aura")
                            .replace("a Aura", "an Aura");
                    }
                    _ => {}
                }
            }
            filter.description()
        }

        fn owned_zone_phrase(owner: Option<&PlayerFilter>, zone: &str) -> String {
            match owner {
                Some(PlayerFilter::You) => format!("your {zone}"),
                Some(PlayerFilter::Opponent) => format!("an opponent's {zone}"),
                Some(PlayerFilter::NotYou) => format!("another player's {zone}"),
                Some(PlayerFilter::Teammate) => format!("a teammate's {zone}"),
                Some(PlayerFilter::Any) | None => format!("a {zone}"),
                Some(_) => format!("their {zone}"),
            }
        }

        fn graveyard_origin_phrase(trigger: &ZoneChangeTrigger) -> Option<String> {
            let owner = trigger.object_filter.owner.as_ref();
            match &trigger.from {
                ZonePattern::Any => Some("from anywhere".to_string()),
                ZonePattern::Specific(Zone::Battlefield) => {
                    Some("from the battlefield".to_string())
                }
                ZonePattern::Specific(Zone::Library) => {
                    Some(format!("from {}", owned_zone_phrase(owner, "library")))
                }
                ZonePattern::Specific(Zone::Hand) => {
                    Some(format!("from {}", owned_zone_phrase(owner, "hand")))
                }
                ZonePattern::Specific(Zone::Graveyard) => {
                    Some(format!("from {}", owned_zone_phrase(owner, "graveyard")))
                }
                ZonePattern::Specific(Zone::Exile) => Some("from exile".to_string()),
                ZonePattern::Specific(Zone::Command) => Some("from the command zone".to_string()),
                ZonePattern::Specific(Zone::Ante) => Some("from ante".to_string()),
                ZonePattern::Specific(Zone::Stack) => Some("from the stack".to_string()),
                ZonePattern::AnyExcept(zone) => {
                    let excluded = match zone {
                        Zone::Battlefield => "the battlefield",
                        Zone::Library => "a library",
                        Zone::Hand => "a hand",
                        Zone::Graveyard => "a graveyard",
                        Zone::Exile => "exile",
                        Zone::Command => "the command zone",
                        Zone::Ante => "ante",
                        Zone::Stack => "the stack",
                        Zone::OutsideGame => "outside the game",
                    };
                    Some(format!("from anywhere other than {excluded}"))
                }
                // "from your hand or library" (Desert Warfare): a list of
                // owned card zones shares one possessive.
                ZonePattern::OneOf(zones)
                    if zones.len() >= 2
                        && zones
                            .iter()
                            .all(|zone| matches!(zone, Zone::Hand | Zone::Library | Zone::Graveyard)) =>
                {
                    let names = zones
                        .iter()
                        .map(|zone| match zone {
                            Zone::Hand => "hand",
                            Zone::Library => "library",
                            _ => "graveyard",
                        })
                        .collect::<Vec<_>>();
                    let list = match names.as_slice() {
                        [first, second] => format!("{first} or {second}"),
                        [init @ .., last] => format!("{}, or {last}", init.join(", ")),
                        [] => return None,
                    };
                    Some(format!("from {}", owned_zone_phrase(owner, &list)))
                }
                ZonePattern::OneOf(_) | ZonePattern::Specific(Zone::OutsideGame) => None,
            }
        }

        fn card_zone_subject_description(trigger: &ZoneChangeTrigger) -> String {
            let mut subject = trigger.object_filter.clone();

            // A parsed `card` subject is represented by `nontoken` so tokens
            // which briefly visit a graveyard do not satisfy it. For display,
            // render that same filter in a card zone instead of leaking the
            // implementation detail as "nontoken creature/permanent".
            let explicit_card_subject = subject.nontoken
                && !matches!(trigger.from, ZonePattern::Specific(Zone::Battlefield));
            if explicit_card_subject {
                subject.nontoken = false;
                subject.zone = Some(Zone::Graveyard);
            } else {
                subject.zone = None;
            }

            // Ownership determines the destination graveyard below. Keeping
            // it on the noun would duplicate the relation as "you own ...
            // into your graveyard". A "dies" surface names no graveyard, so
            // the owner stays on the noun ("a creature you control but don't
            // own dies").
            let dies_surface = trigger.from == ZonePattern::Specific(Zone::Battlefield)
                && trigger.to == ZonePattern::Specific(Zone::Graveyard)
                && (trigger.graveyard_surface == Some(GraveyardTriggerSurface::Dies)
                    || (trigger.graveyard_surface.is_none()
                        && (subject_is_always_creature(&trigger.object_filter)
                            || subject_uses_mixed_death_surface(&trigger.object_filter))));
            let renders_owner_on_noun = dies_surface
                && matches!(
                    trigger.object_filter.owner,
                    Some(PlayerFilter::NotYou | PlayerFilter::Opponent)
                );
            if !renders_owner_on_noun {
                subject.owner = None;
            }
            let description = subject.description();
            description
                .strip_suffix(" in a graveyard")
                .unwrap_or(&description)
                .to_string()
        }

        fn pluralize_zone_change_word(word: &str) -> String {
            let lower = word.to_ascii_lowercase();
            let preserve_case = |lowercase: &str| {
                if word
                    .chars()
                    .next()
                    .is_some_and(|ch| ch.is_ascii_uppercase())
                {
                    let mut chars = lowercase.chars();
                    match chars.next() {
                        Some(first) => {
                            format!("{}{}", first.to_ascii_uppercase(), chars.as_str())
                        }
                        None => String::new(),
                    }
                } else {
                    lowercase.to_string()
                }
            };
            match lower.as_str() {
                "mouse" => return preserve_case("mice"),
                "elf" => return preserve_case("elves"),
                "dwarf" => return preserve_case("dwarves"),
                "wolf" => return preserve_case("wolves"),
                "werewolf" => return preserve_case("werewolves"),
                "myr" | "merfolk" | "equipment" | "plains" | "urzas" => {
                    return word.to_string();
                }
                _ => {}
            }
            if lower.ends_with('y')
                && lower.len() > 1
                && !matches!(
                    lower.chars().nth(lower.len() - 2),
                    Some('a' | 'e' | 'i' | 'o' | 'u')
                )
            {
                return format!("{}ies", &word[..word.len() - 1]);
            }
            if lower.ends_with('s')
                || lower.ends_with('x')
                || lower.ends_with('z')
                || lower.ends_with("ch")
                || lower.ends_with("sh")
            {
                return format!("{word}es");
            }
            format!("{word}s")
        }

        fn replace_bounded_phrase(text: &str, singular: &str, plural: &str) -> Option<String> {
            let mut output = String::with_capacity(text.len() + plural.len());
            let mut cursor = 0usize;
            let mut replaced = false;
            while let Some(relative) = text[cursor..].find(singular) {
                let start = cursor + relative;
                let end = start + singular.len();
                let left_boundary = text[..start]
                    .chars()
                    .next_back()
                    .is_none_or(|ch| !ch.is_ascii_alphanumeric());
                let right_boundary = text[end..]
                    .chars()
                    .next()
                    .is_none_or(|ch| !ch.is_ascii_alphanumeric());
                if !left_boundary || !right_boundary {
                    output.push_str(&text[cursor..end]);
                    cursor = end;
                    continue;
                }
                output.push_str(&text[cursor..start]);
                output.push_str(plural);
                cursor = end;
                replaced = true;
            }
            if !replaced {
                return None;
            }
            output.push_str(&text[cursor..]);
            Some(output)
        }

        fn pluralize_zone_change_subject(subject: &str, filter: &ObjectFilter) -> String {
            let subject = subject
                .strip_prefix("a ")
                .or_else(|| subject.strip_prefix("an "))
                .unwrap_or(subject);
            let mut subject = subject
                .strip_prefix("another ")
                .map(|rest| format!("other {rest}"))
                .unwrap_or_else(|| subject.to_string());

            // A card-zone subject such as "creature card" pluralizes the
            // head noun `card`, not its type adjective. Do this before the
            // structured card-type pass would produce "creatures card".
            if subject == "card" {
                return "cards".to_string();
            }
            if let Some(prefix) = subject.strip_suffix(" card") {
                return format!("{prefix} cards");
            }

            let mut replaced_structured_noun = false;
            for card_type in filter.card_types.iter().chain(filter.all_card_types.iter()) {
                if let Some(replaced) =
                    replace_bounded_phrase(&subject, card_type.name(), card_type.plural_name())
                {
                    subject = replaced;
                    replaced_structured_noun = true;
                }
            }
            for subtype in &filter.subtypes {
                let singular = subtype.to_string();
                let plural = pluralize_zone_change_word(&singular);
                if let Some(replaced) = replace_bounded_phrase(&subject, &singular, &plural) {
                    subject = replaced;
                    replaced_structured_noun = true;
                }
            }
            if replaced_structured_noun {
                return subject;
            }

            let split_at = [
                " with ",
                " without ",
                " that ",
                " named ",
                " not named ",
                " you control",
                " you don't control",
                " an opponent controls",
                " that player controls",
                " attached to ",
            ]
            .into_iter()
            .filter_map(|marker| subject.find(marker))
            .min()
            .unwrap_or(subject.len());
            let (noun_phrase, qualifier) = subject.split_at(split_at);
            let mut words = noun_phrase.split_whitespace().collect::<Vec<_>>();
            let Some(noun) = words.pop() else {
                return subject;
            };
            let plural = match noun.to_ascii_lowercase().as_str() {
                word if word.ends_with('s') => noun.to_string(),
                "card" => "cards".to_string(),
                "creature" => "creatures".to_string(),
                "permanent" => "permanents".to_string(),
                "land" => "lands".to_string(),
                "artifact" => "artifacts".to_string(),
                "enchantment" => "enchantments".to_string(),
                "planeswalker" => "planeswalkers".to_string(),
                "battle" => "battles".to_string(),
                "equipment" => noun.to_string(),
                word if word.ends_with('y') && word.len() > 1 => {
                    format!("{}ies", &noun[..noun.len() - 1])
                }
                word if word.ends_with('x')
                    || word.ends_with('z')
                    || word.ends_with("ch")
                    || word.ends_with("sh") =>
                {
                    format!("{noun}es")
                }
                _ => format!("{noun}s"),
            };
            words.push(plural.as_str());
            format!("{}{}", words.join(" "), qualifier)
        }

        fn subject_uses_mixed_death_surface(filter: &ObjectFilter) -> bool {
            filter.union_connective() == crate::filter::ObjectFilterUnionConnective::AndOr
                && filter.card_types.contains(&CardType::Creature)
        }

        fn enters_origin_phrase(trigger: &ZoneChangeTrigger) -> Option<String> {
            let ZonePattern::Specific(from_zone) = trigger.from else {
                return None;
            };
            let text = match from_zone {
                Zone::Graveyard => match trigger.object_filter.owner {
                    Some(crate::target::PlayerFilter::You) => "from your graveyard",
                    Some(crate::target::PlayerFilter::Opponent) => "from an opponent's graveyard",
                    _ => "from a graveyard",
                },
                Zone::Hand => match trigger.object_filter.owner {
                    Some(crate::target::PlayerFilter::You) => "from your hand",
                    Some(crate::target::PlayerFilter::Opponent) => "from an opponent's hand",
                    _ => "from hand",
                },
                Zone::Exile => match trigger.object_filter.owner {
                    Some(crate::target::PlayerFilter::You) => "from your exile",
                    Some(crate::target::PlayerFilter::Opponent) => "from an opponent's exile",
                    _ => "from exile",
                },
                _ => return None,
            };
            Some(text.to_string())
        }

        fn cause_phrase(trigger: &ZoneChangeTrigger) -> Option<String> {
            let cause_filter = trigger.cause_filter.as_ref()?;
            match &cause_filter.cause_type {
                Some(crate::events::cause::CauseTypeFilter::Not(
                    crate::events::cause::CauseType::SpecialAction,
                )) if cause_filter.source_filter.is_none()
                    && cause_filter.controller_filter.is_none() =>
                {
                    Some("without being played".to_string())
                }
                Some(crate::events::cause::CauseTypeFilter::Exact(
                    crate::events::cause::CauseType::Cost,
                )) if matches!(
                    cause_filter.controller_filter,
                    Some(crate::events::cause::ControllerFilter::You)
                ) =>
                {
                    if cause_filter.ability_kind == Some(
                        crate::events::cause::CauseAbilityKindFilter::ActivatedKeywordCost(
                            ironsmith_core::ActivatedAbilityKeyword::Craft))
                    {
                        return Some("while you're activating a craft ability".into());
                    }
                    let source_filter = cause_filter.source_filter.as_ref()?;
                    let [marker] = source_filter.ability_markers.as_slice() else {
                        return None;
                    };
                    let mut residual = source_filter.clone();
                    residual.ability_markers.clear();
                    if residual != ObjectFilter::default() || marker.trim().is_empty() {
                        return None;
                    }
                    let article = if matches!(
                        marker.chars().next().map(|ch| ch.to_ascii_lowercase()),
                        Some('a' | 'e' | 'i' | 'o' | 'u')
                    ) {
                        "an"
                    } else {
                        "a"
                    };
                    Some(format!(
                        "while you're activating {article} {} ability",
                        marker.to_ascii_lowercase()
                    ))
                }
                _ => None,
            }
        }

        fn spell_or_ability_you_control_exiles_display(
            trigger: &ZoneChangeTrigger,
        ) -> Option<String> {
            if trigger.from != ZonePattern::Specific(Zone::Battlefield)
                || trigger.to != ZonePattern::Specific(Zone::Exile)
                || trigger.player != PlayerRelation::Any
                || trigger.count_mode != CountMode::OneOrMore
                || trigger.this_object
                || trigger.during_turn.is_some()
            {
                return None;
            }
            let cause_filter = trigger.cause_filter.as_ref()?;
            if !matches!(
                cause_filter.cause_type,
                Some(crate::events::cause::CauseTypeFilter::EffectLike)
            ) || cause_filter.source_filter.is_some()
                || !matches!(
                    cause_filter.controller_filter,
                    Some(
                        crate::events::cause::ControllerFilter::ContextController
                            | crate::events::cause::ControllerFilter::You
                    )
                )
                || trigger.object_filter != ObjectFilter::permanent_card()
            {
                return None;
            }
            Some(
                "Whenever a spell or ability you control exiles one or more permanents from the battlefield"
                    .to_string(),
            )
        }

        fn private_origin_zones(trigger: &ZoneChangeTrigger) -> Option<Vec<Zone>> {
            let zones = match &trigger.from {
                ZonePattern::Specific(zone) => vec![*zone],
                ZonePattern::OneOf(zones) => zones.clone(),
                _ => return None,
            };
            (!zones.is_empty()
                && zones
                    .iter()
                    .all(|zone| matches!(zone, Zone::Hand | Zone::Library | Zone::Graveyard)))
            .then_some(zones)
        }

        fn source_zone_phrase(trigger: &ZoneChangeTrigger) -> Option<String> {
            if let Some(zones) = private_origin_zones(trigger) {
                let origins = zones
                    .iter()
                    .map(|zone| {
                        let name = match zone {
                            Zone::Hand => "hand",
                            Zone::Library => "library",
                            _ => "graveyard",
                        };
                        owned_zone_phrase(trigger.object_filter.owner.as_ref(), name)
                    })
                    .collect::<Vec<_>>();
                return Some(format!("from {}", origins.join(" and/or ")));
            }
            match &trigger.from {
                ZonePattern::Specific(Zone::Graveyard) => Some("from a graveyard".to_string()),
                ZonePattern::Specific(Zone::Battlefield) => {
                    Some("from the battlefield".to_string())
                }
                ZonePattern::Specific(Zone::Hand) => Some(
                    match trigger.object_filter.owner {
                        Some(crate::target::PlayerFilter::You) => "from your hand",
                        Some(crate::target::PlayerFilter::Opponent) => "from an opponent's hand",
                        _ => "from a hand",
                    }
                    .to_string(),
                ),
                ZonePattern::OneOf(zones)
                    if zones.contains(&Zone::Graveyard)
                        && zones.contains(&Zone::Battlefield)
                        && zones.len() == 2 =>
                {
                    Some("from graveyards and/or the battlefield".to_string())
                }
                _ => None,
            }
        }

        fn is_nontoken_card_subject_from_card_zones(trigger: &ZoneChangeTrigger) -> bool {
            let card_subject_anywhere_filter = trigger.object_filter == ObjectFilter::default()
                || trigger.object_filter == ObjectFilter::default().nontoken();
            if trigger.to != ZonePattern::Specific(Zone::Exile) {
                return false;
            }
            if matches!(&trigger.from, ZonePattern::Any) && card_subject_anywhere_filter {
                return true;
            }
            if matches!(&trigger.from, ZonePattern::Specific(Zone::Hand))
                && trigger.object_filter.nontoken
                && trigger.object_filter.card_types.is_empty()
                && trigger.object_filter.all_card_types.is_empty()
            {
                return true;
            }
            if matches!(&trigger.from, ZonePattern::OneOf(zones) if zones.is_empty())
                && card_subject_anywhere_filter
            {
                return true;
            }
            matches!(
                &trigger.from,
                ZonePattern::OneOf(zones)
                    if zones.contains(&Zone::Graveyard)
                        && zones.contains(&Zone::Battlefield)
                        && zones.len() == 2
            ) && trigger.object_filter == ObjectFilter::default().nontoken()
        }

        fn attached_subject_implies_battlefield(filter: &ObjectFilter) -> bool {
            filter.tagged_constraints.iter().any(|constraint| {
                constraint.relation == crate::filter::TaggedOpbjectRelation::IsTaggedObject
                    && matches!(constraint.tag.as_str(), "enchanted" | "equipped")
            })
        }

        if let Some(display) = spell_or_ability_you_control_exiles_display(self) {
            return display;
        }
        if self.from == ZonePattern::Any
            && self.to == ZonePattern::Specific(Zone::Battlefield)
            && self.player == PlayerRelation::Any
            && self.count_mode == CountMode::Each
            && !self.this_object
            && self
                .object_filter
                .has_player_puts_onto_battlefield_surface()
        {
            let filter_desc = subject_description_for_zone_change(&self.object_filter);
            let has_article = filter_desc.starts_with("a ")
                || filter_desc.starts_with("an ")
                || filter_desc.starts_with("another ");
            let article = if has_article {
                ""
            } else if matches!(
                filter_desc.chars().next().map(|c| c.to_ascii_lowercase()),
                Some('a' | 'e' | 'i' | 'o' | 'u')
            ) {
                "an "
            } else {
                "a "
            };
            return format!("Whenever a player puts {article}{filter_desc} onto the battlefield");
        }
        if self.this_object {
            let battlefield_subject = self.this_subject_text("permanent");
            let card_subject = self.this_subject_text("card");
            let enter_verb = match self.this_object_subject_number {
                TriggerSubjectNumber::Singular => "enters",
                TriggerSubjectNumber::Plural => "enter",
            };
            let origin_suffix = self
                .origin_condition
                .as_ref()
                .map(|origin| {
                    moved_or_cast_origin_display_suffix(
                        origin,
                        self.count_mode == CountMode::OneOrMore,
                    )
                })
                .unwrap_or_default();
            if self.to == ZonePattern::Specific(Zone::Battlefield)
                && let Some(origin_phrase) = enters_origin_phrase(self)
            {
                return format!(
                    "When {battlefield_subject} {enter_verb} {origin_phrase}{origin_suffix}"
                );
            }
            let mut display = match (&self.from, &self.to) {
                (
                    ZonePattern::Specific(Zone::Battlefield),
                    ZonePattern::Specific(Zone::Graveyard),
                ) if self.graveyard_surface == Some(GraveyardTriggerSurface::Dies)
                    || (self.graveyard_surface.is_none()
                        && subject_is_always_creature(&self.object_filter)) =>
                {
                    format!("When {battlefield_subject} dies")
                }
                (
                    ZonePattern::Specific(Zone::Battlefield),
                    ZonePattern::Specific(Zone::Graveyard),
                ) => format!("When {card_subject} is put into a graveyard from the battlefield"),
                (ZonePattern::Specific(Zone::Battlefield), ZonePattern::Specific(Zone::Exile)) => {
                    format!("When {battlefield_subject} is put into exile from the battlefield")
                }
                (_, ZonePattern::Specific(Zone::Battlefield)) => {
                    format!(
                        "When {battlefield_subject} {enter_verb} the battlefield{origin_suffix}"
                    )
                }
                (ZonePattern::Specific(Zone::Battlefield), _) => {
                    format!("When {battlefield_subject} leaves the battlefield")
                }
                (ZonePattern::Specific(Zone::Hand), ZonePattern::Specific(Zone::Graveyard)) => {
                    format!("When {card_subject} is discarded")
                }
                (_, ZonePattern::Specific(Zone::Graveyard)) => {
                    format!("When {card_subject} is put into a graveyard")
                }
                (_, ZonePattern::Specific(Zone::Exile)) => {
                    format!("When {battlefield_subject} is exiled")
                }
                (
                    ZonePattern::Specific(origin @ (Zone::Graveyard | Zone::Library | Zone::Exile)),
                    ZonePattern::Specific(Zone::Hand),
                ) => {
                    let owner = self.object_filter.owner.as_ref();
                    let origin = match origin {
                        Zone::Graveyard => owned_zone_phrase(owner, "graveyard"),
                        Zone::Library => owned_zone_phrase(owner, "library"),
                        _ => "exile".to_string(),
                    };
                    format!(
                        "When {card_subject} is put into {} from {origin}",
                        owned_zone_phrase(owner, "hand")
                    )
                }
                _ => "When this object changes zones".to_string(),
            };
            if let Some(cause_phrase) = cause_phrase(self) {
                display.push(' ');
                display.push_str(&cause_phrase);
            }
            if self.during_own_resolution {
                display.push_str(" during its resolution");
            }
            if let Some(during_turn) = &self.during_turn {
                let phrase = match during_turn {
                    PlayerFilter::You => Some("during your turn"),
                    PlayerFilter::Opponent => Some("during an opponent's turn"),
                    PlayerFilter::Any | PlayerFilter::Active => None,
                    PlayerFilter::Specific(_) => Some("during that player's turn"),
                    _ => Some("during the specified player's turn"),
                };
                if let Some(phrase) = phrase {
                    display.push(' ');
                    display.push_str(phrase);
                }
            }
            if matches!(
                self.timing,
                Some(ironsmith_core::TriggerTimingRestriction::DuringCombat)
            ) {
                display.push_str(" during combat");
            }
            if matches!(
                self.timing,
                Some(ironsmith_core::TriggerTimingRestriction::DuringDeclareAttackersStep)
            ) {
                display.push_str(" during the declare attackers step");
            }
            return display;
        }

        let mut parts = vec!["Whenever".to_string()];
        // "a spell or ability an opponent controls causes <subject> to be put
        // into <graveyard>" states the cause before the subject.
        let opponent_effect_cause = self.cause_filter.as_ref().is_some_and(|cause| {
            matches!(
                cause.cause_type,
                Some(crate::events::cause::CauseTypeFilter::EffectLike)
            ) && cause.source_filter.is_none()
                && matches!(
                    cause.controller_filter,
                    Some(crate::events::cause::ControllerFilter::ContextOpponent)
                )
        }) && self.to == ZonePattern::Specific(Zone::Graveyard);
        if opponent_effect_cause {
            parts.push("a spell or ability an opponent controls causes".to_string());
        }

        // Player relation
        match &self.player {
            PlayerRelation::You => parts.push("you".to_string()),
            PlayerRelation::Opponent => parts.push("an opponent".to_string()),
            PlayerRelation::Any => {}
        }

        // Object filter description
        let enters_under_controller = self.to == ZonePattern::Specific(Zone::Battlefield)
            && self.object_filter.has_enters_under_controller_surface()
            && self.object_filter.controller.is_some();
        let mut display_filter = self.object_filter.clone();
        if enters_under_controller {
            display_filter.controller = None;
        }
        // "is returned to your hand" / "to its owner's hand" names the owner
        // in the destination, not on the subject.
        let returned_to_hand = self.from == ZonePattern::Specific(Zone::Battlefield)
            && self.to == ZonePattern::Specific(Zone::Hand)
            && matches!(
                self.object_filter.owner,
                Some(PlayerFilter::You | PlayerFilter::Any)
            );
        // "leaves an opponent's graveyard" names the owner in the origin.
        let leaves_owned_graveyard = self.from == ZonePattern::Specific(Zone::Graveyard)
            && self.to == ZonePattern::Any
            && self.object_filter.owner.is_some();
        if returned_to_hand || leaves_owned_graveyard {
            display_filter.owner = None;
        }
        let mut filter_desc = if self.to == ZonePattern::Specific(Zone::Graveyard)
            || (self.to == ZonePattern::Specific(Zone::Exile)
                && private_origin_zones(self).is_some())
        {
            card_zone_subject_description(self)
        } else if is_nontoken_card_subject_from_card_zones(self) {
            if self.count_mode == CountMode::OneOrMore {
                "cards".to_string()
            } else {
                "card".to_string()
            }
        } else {
            subject_description_for_zone_change(&display_filter)
        };
        if let Some(rest) = filter_desc
            .strip_prefix("an opponent's ")
            .or_else(|| filter_desc.strip_prefix("opponent's "))
        {
            let article = if matches!(rest.chars().next(), Some('a' | 'e' | 'i' | 'o' | 'u')) {
                "an"
            } else {
                "a"
            };
            filter_desc = format!("{article} {rest} an opponent controls");
        }
        if self.to == ZonePattern::Specific(Zone::Battlefield)
            && enters_origin_phrase(self).is_some()
            && let Some(stripped) = filter_desc.strip_suffix(" you own")
        {
            filter_desc = stripped.to_string();
        }
        if self.count_mode == CountMode::OneOrMore {
            if let Some(rest) = filter_desc.strip_prefix("another ") {
                filter_desc = format!("other {rest}");
            }
            filter_desc = pluralize_zone_change_subject(&filter_desc, &self.object_filter);
            // "one or more creatures you control and/or creature cards in
            // your graveyard" (Kaya, Spirits' Justice): every arm of a batch
            // union is plural, not only the first.
            if !self.object_filter.any_of.is_empty() {
                filter_desc = filter_desc
                    .replace(" card in ", " cards in ")
                    .replace(" card and/or ", " cards and/or ")
                    .replace(" card or ", " cards or ");
            }
        }
        let has_article = filter_desc.starts_with("a ")
            || filter_desc.starts_with("an ")
            || filter_desc.starts_with("the ")
            || filter_desc.starts_with("this ")
            || filter_desc.starts_with("that ")
            || filter_desc.starts_with("another ")
            || filter_desc.starts_with("enchanted ")
            || filter_desc.starts_with("equipped ")
            || filter_desc.starts_with("your ")
            || self.object_filter.source;
        if self.count_mode == CountMode::OneOrMore {
            parts.push("one or more".to_string());
        } else if !has_article {
            let article = if matches!(
                filter_desc.chars().next().map(|c| c.to_ascii_lowercase()),
                Some('a' | 'e' | 'i' | 'o' | 'u')
            ) {
                "an"
            } else {
                "a"
            };
            parts.push(article.to_string());
        }
        if filter_desc != "object" {
            parts.push(filter_desc);
        } else {
            parts.push("card".to_string());
        }

        // Zone change description
        match (&self.from, &self.to) {
            (ZonePattern::Specific(Zone::Battlefield), ZonePattern::Specific(Zone::Graveyard))
                if self.graveyard_surface == Some(GraveyardTriggerSurface::Dies)
                    || (self.graveyard_surface.is_none()
                        && (subject_is_always_creature(&self.object_filter)
                            || subject_uses_mixed_death_surface(&self.object_filter))) =>
            {
                parts.push(
                    if self.count_mode == CountMode::OneOrMore {
                        "die"
                    } else {
                        "dies"
                    }
                    .to_string(),
                );
            }
            (ZonePattern::Specific(Zone::Battlefield), ZonePattern::Specific(Zone::Graveyard))
                if self.graveyard_surface.is_none()
                    && attached_subject_implies_battlefield(&self.object_filter) =>
            {
                let verb = if self.count_mode == CountMode::OneOrMore {
                    "are"
                } else {
                    "is"
                };
                let graveyard = owned_zone_phrase(self.object_filter.owner.as_ref(), "graveyard");
                parts.push(format!("{verb} put into {graveyard}"));
            }
            (ZonePattern::Specific(Zone::Battlefield), ZonePattern::Specific(Zone::Graveyard)) => {
                let verb = if self.count_mode == CountMode::OneOrMore {
                    "are"
                } else {
                    "is"
                };
                let graveyard = owned_zone_phrase(self.object_filter.owner.as_ref(), "graveyard");
                let verb = if opponent_effect_cause { "to be" } else { verb };
                parts.push(format!("{verb} put into {graveyard} from the battlefield"));
            }
            (ZonePattern::Specific(Zone::Hand), ZonePattern::Specific(Zone::Graveyard)) => {
                parts.push(
                    if self.count_mode == CountMode::OneOrMore {
                        "are discarded"
                    } else {
                        "is discarded"
                    }
                    .to_string(),
                );
            }
            (_, ZonePattern::Specific(Zone::Battlefield))
                if enters_origin_phrase(self).is_some() =>
            {
                let verb = if self.count_mode == CountMode::OneOrMore {
                    "enter"
                } else {
                    "enters"
                };
                parts.push(format!("{verb} {}", enters_origin_phrase(self).unwrap()));
            }
            (_, ZonePattern::Specific(Zone::Battlefield)) if enters_under_controller => {
                let verb = if self.count_mode == CountMode::OneOrMore {
                    "enter"
                } else {
                    "enters"
                };
                let controller = match self.object_filter.controller.as_ref() {
                    Some(PlayerFilter::You) => "your".to_string(),
                    Some(PlayerFilter::Opponent) => "an opponent's".to_string(),
                    Some(PlayerFilter::NotYou) => "another player's".to_string(),
                    Some(_) => "that player's".to_string(),
                    None => unreachable!("guarded by enters_under_controller"),
                };
                parts.push(format!("{verb} under {controller} control"));
            }
            (_, ZonePattern::Specific(Zone::Battlefield)) => {
                parts.push(
                    if self.count_mode == CountMode::OneOrMore {
                        "enter the battlefield"
                    } else {
                        "enters the battlefield"
                    }
                    .to_string(),
                );
            }
            (ZonePattern::Specific(Zone::Graveyard), ZonePattern::Any) if leaves_owned_graveyard => {
                let verb = if self.count_mode == CountMode::OneOrMore {
                    "leave"
                } else {
                    "leaves"
                };
                let graveyard = owned_zone_phrase(self.object_filter.owner.as_ref(), "graveyard");
                parts.push(format!("{verb} {graveyard}"));
            }
            (ZonePattern::Specific(Zone::Battlefield), ZonePattern::Specific(Zone::Hand))
                if returned_to_hand =>
            {
                let one_or_more = self.count_mode == CountMode::OneOrMore;
                let verb = if one_or_more { "are" } else { "is" };
                let hand = match (&self.object_filter.owner, one_or_more) {
                    (Some(PlayerFilter::You), _) => "your hand",
                    // An unconstrained permanent returned to any hand
                    // (Warped Devotion's "a player's hand").
                    (Some(PlayerFilter::Any), false)
                        if self.object_filter.controller.is_none() =>
                    {
                        "a player's hand"
                    }
                    (_, false) => "its owner's hand",
                    (_, true) => "their owners' hands",
                };
                parts.push(format!("{verb} returned to {hand}"));
            }
            // "is returned to your hand" / "are returned to hand" (bounce
            // triggers): the owner's hand, from the battlefield.
            (ZonePattern::Specific(Zone::Battlefield), ZonePattern::Specific(Zone::Hand)) => {
                let plural = self.count_mode == CountMode::OneOrMore;
                // The returned-to-hand subject names its controller only;
                // the owner is implied by "its owner's hand".
                if let Some(last) = parts.last_mut()
                    && last.contains(" a player owns but ")
                {
                    *last = last.replace(" a player owns but ", " ");
                }
                let hand = if self.object_filter.owner == Some(PlayerFilter::You) {
                    if let Some(last) = parts.last_mut()
                        && let Some(stripped) = last.strip_suffix(" you own")
                    {
                        *last = stripped.to_string();
                    }
                    "your hand"
                } else if plural {
                    "hand"
                } else {
                    "its owner's hand"
                };
                let verb = if plural { "are" } else { "is" };
                parts.push(format!("{verb} returned to {hand}"));
            }
            // "one or more cards are put into a library from anywhere".
            (_, ZonePattern::Specific(Zone::Library)) => {
                let verb = if self.count_mode == CountMode::OneOrMore {
                    "are"
                } else {
                    "is"
                };
                let library = owned_zone_phrase(self.object_filter.owner.as_ref(), "library");
                let origin = match &self.from {
                    ZonePattern::Any => " from anywhere".to_string(),
                    ZonePattern::Specific(zone) => format!(" from {}", zone_origin_name(*zone)),
                    _ => String::new(),
                };
                parts.push(format!("{verb} put into {library}{origin}"));
            }
            (ZonePattern::Specific(Zone::Battlefield), ZonePattern::AnyExcept(Zone::Graveyard)) => {
                parts.push(
                    if self.count_mode == CountMode::OneOrMore {
                        "leave the battlefield without dying"
                    } else {
                        "leaves the battlefield without dying"
                    }
                    .to_string(),
                );
            }
            // Exile from the battlefield is narrower than leaving it.
            (ZonePattern::Specific(Zone::Battlefield), ZonePattern::Specific(Zone::Exile)) => {
                parts.push(
                    if self.count_mode == CountMode::OneOrMore {
                        "are put into exile from the battlefield"
                    } else {
                        "is put into exile from the battlefield"
                    }
                    .to_string(),
                );
            }
            // "is put into the command zone" (Reyhan, Last of the Abzan): a
            // commander moved there from the battlefield (CR 903.9a).
            (ZonePattern::Specific(Zone::Battlefield), ZonePattern::Specific(Zone::Command)) => {
                parts.push(
                    if self.count_mode == CountMode::OneOrMore {
                        "are put into the command zone"
                    } else {
                        "is put into the command zone"
                    }
                    .to_string(),
                );
            }
            (ZonePattern::Specific(Zone::Battlefield), _) => {
                parts.push(
                    if self.count_mode == CountMode::OneOrMore {
                        "leave the battlefield"
                    } else {
                        "leaves the battlefield"
                    }
                    .to_string(),
                );
            }
            (_, ZonePattern::Specific(Zone::Graveyard)) => {
                let verb = if self.count_mode == CountMode::OneOrMore {
                    "are"
                } else {
                    "is"
                };
                // "one or more creature cards are put into graveyards from
                // anywhere": a batch bound for any graveyard is plural.
                let graveyard = if self.count_mode == CountMode::OneOrMore
                    && self.from == ZonePattern::Any
                    && matches!(self.object_filter.owner, None | Some(PlayerFilter::Any))
                {
                    "graveyards".to_string()
                } else {
                    owned_zone_phrase(self.object_filter.owner.as_ref(), "graveyard")
                };
                let verb = if opponent_effect_cause { "to be" } else { verb };
                parts.push(format!("{verb} put into {graveyard}"));
                if let Some(origin) = graveyard_origin_phrase(self) {
                    parts.push(origin);
                }
            }
            (_, ZonePattern::Specific(Zone::Exile)) => {
                let verb = if self.count_mode == CountMode::OneOrMore {
                    "are"
                } else {
                    "is"
                };
                if let Some(source_phrase) = source_zone_phrase(self) {
                    parts.push(format!("{verb} put into exile {source_phrase}"));
                } else {
                    parts.push(format!("{verb} put into exile"));
                }
            }
            // "Whenever your commander is put into the command zone from
            // anywhere" (Myth Unbound).
            (_, ZonePattern::Specific(Zone::Command)) => {
                let verb = if self.count_mode == CountMode::OneOrMore {
                    "are"
                } else {
                    "is"
                };
                let origin = match &self.from {
                    ZonePattern::Any => " from anywhere".to_string(),
                    ZonePattern::Specific(zone) => format!(" from {}", zone_origin_name(*zone)),
                    _ => String::new(),
                };
                parts.push(format!("{verb} put into the command zone{origin}"));
            }
            _ => {
                parts.push("changes zones".to_string());
            }
        }

        if let Some(cause_phrase) = cause_phrase(self) {
            parts.push(cause_phrase);
        }

        if let Some(during_turn) = &self.during_turn {
            let phrase = match during_turn {
                PlayerFilter::You => Some("during your turn"),
                PlayerFilter::Opponent => Some("during an opponent's turn"),
                PlayerFilter::Any | PlayerFilter::Active => None,
                PlayerFilter::Specific(_) => Some("during that player's turn"),
                _ => Some("during the specified player's turn"),
            };
            if let Some(phrase) = phrase {
                parts.push(phrase.to_string());
            }
        }

        if matches!(
            self.timing,
            Some(ironsmith_core::TriggerTimingRestriction::DuringCombat)
        ) {
            parts.push("during combat".to_string());
        }
        if matches!(
            self.timing,
            Some(ironsmith_core::TriggerTimingRestriction::DuringDeclareAttackersStep)
        ) {
            parts.push("during the declare attackers step".to_string());
        }

        let mut display = parts.join(" ");
        if let Some(origin) = &self.origin_condition {
            display.push_str(&moved_or_cast_origin_display_suffix(
                origin,
                self.count_mode == CountMode::OneOrMore,
            ));
        }
        display
    }

    fn this_subject(&self, fallback: &'static str) -> &'static str {
        use crate::types::CardType;
        if self.object_filter.card_types.contains(&CardType::Creature) {
            return "creature";
        }
        if self.object_filter.card_types.len() == 1 {
            return self.object_filter.card_types[0].self_subject(fallback);
        }
        // An untyped "when this dies" is almost always printed on a creature.
        if self.object_filter.card_types.is_empty()
            && self.graveyard_surface == Some(GraveyardTriggerSurface::Dies)
        {
            return "creature";
        }
        fallback
    }

    pub(crate) fn this_subject_text(&self, fallback: &'static str) -> String {
        let text = match &self.this_object_surface {
            Some(surface) => surface.display_text(),
            None => format!("this {}", self.this_subject(fallback)),
        };
        match text.as_str() {
            // Equipment, Siege, and Case are printed subtypes and are capitalized in
            // Oracle text even when the compiler's semantic token view is
            // lowercased.
            "this equipment" => "this Equipment".to_string(),
            "this siege" => "this Siege".to_string(),
            "this case" => "this Case".to_string(),
            _ => text,
        }
    }

    /// Capture the exact LKI set that satisfied a batch-style zone-change
    /// trigger. Aggregate values in the queued ability must not recount the
    /// battlefield after the objects have moved.
    pub(crate) fn matching_batch_snapshots(
        &self,
        event: &ZoneChangeEvent,
        ctx: &TriggerContext<'_>,
    ) -> Vec<crate::snapshot::ObjectSnapshot> {
        if self.count_mode != CountMode::OneOrMore {
            return Vec::new();
        }
        let player_matches = |controller: crate::ids::PlayerId| match &self.player {
            PlayerRelation::Any => true,
            PlayerRelation::You => controller == ctx.controller,
            PlayerRelation::Opponent => ctx.game.are_opponents(ctx.controller, controller),
        };
        if !self.uses_snapshot() {
            // Entry-style triggers see the objects as they now exist in the
            // destination zone ("whenever one or more creatures enter, put a
            // +1/+1 counter on each of them").
            return event
                .destination_objects()
                .iter()
                .filter_map(|&id| ctx.game.object(id))
                .filter(|object| object.zone == event.to)
                .filter(|object| !self.this_object || object.id == ctx.source_id)
                .filter(|object| player_matches(ctx.game.controller_of(object)))
                .filter(|object| self.object_filter.matches(object, &ctx.filter_ctx, ctx.game))
                .map(|object| {
                    crate::snapshot::ObjectSnapshot::from_object_with_calculated_characteristics(
                        object, ctx.game,
                    )
                })
                .collect();
        }
        matching_snapshots(event, &self.object_filter, ctx)
            .into_iter()
            .filter(|snapshot| {
                (!self.this_object || snapshot.object_id == ctx.source_id)
                    && match &self.player {
                        PlayerRelation::Any => true,
                        PlayerRelation::You => snapshot.controller == ctx.controller,
                        PlayerRelation::Opponent => ctx.game.are_opponents(ctx.controller, snapshot.controller),
                    }
            })
            .cloned()
            .collect()
    }
}

fn snapshot_matches_filter(
    snapshot: &crate::snapshot::ObjectSnapshot,
    filter: &ObjectFilter,
    ctx: &TriggerContext,
) -> bool {
    filter.matches_snapshot(snapshot, &ctx.filter_ctx, ctx.game)
}

fn matching_snapshots<'a>(
    zc: &'a ZoneChangeEvent,
    filter: &ObjectFilter,
    ctx: &TriggerContext,
) -> Vec<&'a crate::snapshot::ObjectSnapshot> {
    if zc.to == Zone::Battlefield {
        return zc.destination_snapshots.iter()
            .filter(|snapshot| zc.destination_objects().contains(&snapshot.object_id)
                && snapshot.zone == Zone::Battlefield
                && snapshot_matches_filter(snapshot, filter, ctx))
            .collect();
    }
    // A leaves-the-battlefield trigger looks back in time (CR 603.10a): a
    // characteristic comparison against the battlefield ("with the greatest
    // power among creatures that player controls") still sees the permanents
    // leaving in this event.
    let compares_characteristics =
        filter.power.is_some() || filter.toughness.is_some() || filter.mana_value.is_some()
            || filter.tagged_constraints.iter().any(|constraint|constraint.tag.as_str().starts_with("source_collection:"));
    if zc.from == Zone::Battlefield && compares_characteristics {
        let mut lookback_ctx = ctx.filter_ctx.clone();
        lookback_ctx.departed_battlefield_lookback = Some(zc.snapshots().to_vec().into());
        return zc
            .snapshots()
            .iter()
            .filter(|snapshot| filter.matches_snapshot(snapshot, &lookback_ctx, ctx.game))
            .collect();
    }
    zc.snapshots()
        .iter()
        .filter(|snapshot| snapshot_matches_filter(snapshot, filter, ctx))
        .collect()
}

fn source_zone_is_explicitly_looked_back(from: &ZonePattern, zone: Zone) -> bool {
    *from != ZonePattern::Any && from.matches(zone)
}

fn is_public_to_hand_or_library_zone_change(zc: &ZoneChangeEvent) -> bool {
    zc.from.is_public() && matches!(zc.to, Zone::Hand | Zone::Library)
}

impl ZoneChangeTrigger {
    fn accepts_game_departure(&self) -> bool {
        self.from != ZonePattern::Any && self.from.matches(Zone::Battlefield)
            && self.to == ZonePattern::Any
    }
    /// Reuse LKI/filter/cause matching for an LTB notification only. This
    /// temporary view is never published, committed, or offered to replacements.
    /// Destination-specific and unrestricted zone-change triggers reject it.
    fn matching_zone_event<'a>(&self, event: &'a TriggerEvent)
        -> Option<std::borrow::Cow<'a, ZoneChangeEvent>> {
        if event.kind() == EventKind::ZoneChange {
            return event.downcast::<ZoneChangeEvent>().map(std::borrow::Cow::Borrowed);
        }
        if event.kind() != EventKind::ObjectLeavesGame || !self.accepts_game_departure() {
            return None;
        }
        let departure = event.downcast::<crate::events::zones::ObjectLeavesGameEvent>()?;
        if departure.snapshot.zone != Zone::Battlefield { return None; }
        Some(std::borrow::Cow::Owned(ZoneChangeEvent::with_cause(
            departure.object, Zone::Battlefield, Zone::OutsideGame,
            departure.cause.clone(), Some(departure.snapshot.clone()),
        )))
    }
}

impl TriggerMatcher for ZoneChangeTrigger {
    fn matches(&self, event: &TriggerEvent, ctx: &TriggerContext) -> bool {
        let Some(zc) = self.matching_zone_event(event) else {
            return false;
        };

        if self.duration_return_from_source
            && zc.cause.duration_return_source != Some(ctx.source_id)
        {
            return false;
        }

        if self.during_own_resolution {
            let Some(resolving_spell) = zc.cause.resolving_spell else {
                return false;
            };
            // Nonbattlefield zone-change events use the destination object
            // id. Its pre-move snapshot retains the resolving stack identity.
            let moved_resolving_spell = zc.objects.contains(&resolving_spell)
                || zc.snapshots().iter().any(|snapshot| {
                    snapshot.object_id == resolving_spell
                        && (!(self.this_object || self.object_filter.source)
                            || ctx
                                .game
                                .object(ctx.source_id)
                                .is_some_and(|source| source.stable_id == snapshot.stable_id))
                });
            if !moved_resolving_spell {
                return false;
            }
        }

        if let Some(during_turn) = &self.during_turn
            && !current_turn_matches_player_filter(during_turn, ctx, None)
        {
            return false;
        }
        if matches!(
            self.timing,
            Some(ironsmith_core::TriggerTimingRestriction::DuringCombat)
        ) && ctx.game.turn.phase != crate::game_state::Phase::Combat
        {
            return false;
        }
        if matches!(
            self.timing,
            Some(ironsmith_core::TriggerTimingRestriction::DuringDeclareAttackersStep)
        ) && ctx.game.turn.step != Some(crate::game_state::Step::DeclareAttackers)
        {
            return false;
        }

        // Check zone patterns
        if !self.from.matches(zc.from) {
            return false;
        }
        if !self.to.matches(zc.to) {
            return false;
        }

        // Most nonbattlefield producers name the destination identity. An
        // explicit-origin source trigger (such as graveyard -> hand) is also
        // checked against its origin-zone LKI source, so retain that exact old
        // identity. Never equate later objects merely by their stable card id.
        if self.this_object
            && !zc.objects.contains(&ctx.source_id)
            && !(self.uses_snapshot()
                && zc.snapshots().iter().any(|snapshot| {
                    snapshot.object_id == ctx.source_id && snapshot.zone == zc.from
                }))
        {
            return false;
        }

        // A captured "card exiled this way" names an exact exile-zone object,
        // not merely the physical card's stable identity. If that card leaves
        // exile and the same source exiles it again, only the new registration
        // may observe the later duration return. Evaluate the tagged constraint
        // against origin LKI, then remove it from the destination filter: an
        // entering object necessarily has a new object ID.
        let mut destination_filter = self.object_filter.clone();
        let duration_origins = if self.duration_return_from_source {
            let exact_origin_tags = self.object_filter.tagged_constraints.iter()
                .filter(|constraint| constraint.relation == crate::target::TaggedOpbjectRelation::IsTaggedObject)
                .map(|constraint| &constraint.tag)
                .collect::<Vec<_>>();
            if exact_origin_tags.is_empty() {
                None
            } else {
                let origins = zc.snapshots().iter()
                    .filter(|origin| origin.zone == Zone::Exile
                        && exact_origin_tags.iter().all(|tag| {
                            ctx.filter_ctx.tagged_objects.get(*tag).is_some_and(|captured| {
                                captured.iter().any(|snapshot| snapshot.object_id == origin.object_id)
                            })
                        }))
                    .map(|origin| origin.stable_id)
                    .collect::<std::collections::HashSet<_>>();
                if origins.is_empty() {
                    return false;
                }
                destination_filter.tagged_constraints.retain(|constraint| {
                    !(constraint.relation == crate::target::TaggedOpbjectRelation::IsTaggedObject
                        && exact_origin_tags.iter().any(|tag| *tag == &constraint.tag))
                });
                Some(origins)
            }
        } else {
            None
        };

        // Entry characteristics are fixed when the entry completes. A later
        // grant in the same resolving program cannot retroactively make the
        // entrant satisfy a trigger (for example, entering with haste).
        let use_snapshot = (zc.to == Zone::Battlefield && !zc.destination_snapshots.is_empty())
            || (self.uses_snapshot() && !zc.snapshots().is_empty());
        let matching_snapshots = if use_snapshot {
            matching_snapshots(&zc, &destination_filter, ctx)
                .into_iter()
                .filter(|snapshot| duration_origins.as_ref().is_none_or(|origins| {
                    origins.contains(&snapshot.stable_id)
                }))
                .collect::<Vec<_>>()
        } else {
            Vec::new()
        };

        // Use the same completed entry or departure frame for controller checks.
        if self.player != PlayerRelation::Any {
            let player_matches = if use_snapshot {
                matching_snapshots
                    .iter()
                    .any(|snapshot| match &self.player {
                        PlayerRelation::You => snapshot.controller == ctx.controller,
                        PlayerRelation::Opponent => ctx.game.are_opponents(ctx.controller, snapshot.controller),
                        PlayerRelation::Any => true,
                    })
            } else {
                zc.destination_objects().iter().any(|&id| {
                    if let Some(obj) = ctx.game.object(id) {
                        if duration_origins.as_ref().is_some_and(|origins| !origins.contains(&obj.stable_id)) {
                            return false;
                        }
                        match &self.player {
                            PlayerRelation::You => ctx.game.controller_of(obj) == ctx.controller,
                            PlayerRelation::Opponent => {
                                ctx.game.controller_of(obj) != ctx.controller
                            }
                            PlayerRelation::Any => true,
                        }
                    } else if let Some(snapshot) = zc.snapshot.as_ref() {
                        if duration_origins.as_ref().is_some_and(|origins| !origins.contains(&snapshot.stable_id)) {
                            return false;
                        }
                        match &self.player {
                            PlayerRelation::You => snapshot.controller == ctx.controller,
                            PlayerRelation::Opponent => ctx.game.are_opponents(ctx.controller, snapshot.controller),
                            PlayerRelation::Any => true,
                        }
                    } else {
                        false
                    }
                })
            };

            if !player_matches {
                return false;
            }
        }

        // Completed entries and departures retain the characteristics at the
        // event boundary; other destination events use the current object.
        if use_snapshot {
            if matching_snapshots.is_empty() {
                return false;
            }
        } else {
            // Check the post-change object(s) for ETB and destination-zone triggers.
            let filter_matches = if zc.destination_objects().is_empty() {
                duration_origins.is_none()
            } else {
                zc.destination_objects().iter().any(|&id| {
                    if let Some(obj) = ctx.game.object(id) {
                        duration_origins.as_ref().is_none_or(|origins| origins.contains(&obj.stable_id))
                            && destination_filter.matches(obj, &ctx.filter_ctx, ctx.game)
                    } else if let Some(snapshot) = zc.snapshot.as_ref() {
                        duration_origins.as_ref().is_none_or(|origins| origins.contains(&snapshot.stable_id))
                            && snapshot_matches_filter(snapshot, &destination_filter, ctx)
                    } else {
                        duration_origins.is_none() && destination_filter == ObjectFilter::default()
                    }
                })
            };

            if !filter_matches {
                return false;
            }
        }

        // Check cause filter if specified
        if let Some(ref cause_filter) = self.cause_filter {
            let affected = matching_snapshots.first().copied()
                .map(|snapshot| snapshot.controller)
                .or_else(|| {
                    zc.objects
                        .first()
                        .and_then(|&id| ctx.game.object(id))
                        .map(|o| ctx.game.controller_of(o))
                })
                .unwrap_or(ctx.controller);

            // A cause source filter that names "this" object ("championed
            // with this creature") binds the cause to the trigger's own
            // source rather than to an object matched in a fresh context.
            let source_bound = cause_filter
                .source_filter
                .as_ref()
                .is_some_and(|filter| filter.source);
            if source_bound {
                let source_stable = ctx.game.object(ctx.source_id).map(|obj| obj.stable_id);
                let caused_by_source = zc.cause.source.is_some_and(|cause_source| {
                    cause_source == ctx.source_id
                        || (cause_filter.ability_kind != Some(crate::events::cause::CauseAbilityKindFilter::ChampionTrigger)
                            && source_stable.is_some()
                            && ctx.game.object(cause_source).map(|obj| obj.stable_id)
                                == source_stable)
                });
                if !caused_by_source {
                    return false;
                }
            }
            let unbound;
            let cause_filter = if source_bound {
                unbound = crate::events::cause::CauseFilter {
                    source_filter: None,
                    ..cause_filter.clone()
                };
                &unbound
            } else {
                cause_filter
            };
            if !cause_filter.matches_with_context_controller(
                &zc.cause,
                ctx.game,
                affected,
                ctx.controller,
            ) {
                return false;
            }
        }

        if let Some(ZoneChangeOriginCondition::MovedFromOrCastFrom {
            zone,
            zone_owner,
            caster,
            ..
        }) = &self.origin_condition
        {
            // Cards can only occupy their owner's graveyard/hand/library, so
            // an owned origin zone constrains the entering object's owner.
            let owner_matches = |owner: crate::ids::PlayerId| match zone_owner {
                None | Some(PlayerFilter::Any) => true,
                Some(PlayerFilter::You) => owner == ctx.controller,
                Some(PlayerFilter::Opponent) => ctx.game.are_opponents(ctx.controller, owner),
                // Unmodeled owner scopes never match rather than silently widening.
                Some(_) => false,
            };
            // The caster the "cast from" branch requires; `Err` marks an
            // unmodeled caster filter, which disables that branch entirely.
            let required_caster: Result<Option<crate::ids::PlayerId>, ()> = match caster {
                None | Some(PlayerFilter::Any) => Ok(None),
                Some(PlayerFilter::You) => Ok(Some(ctx.controller)),
                Some(_) => Err(()),
            };
            let object_satisfies_origin =
                |owner: crate::ids::PlayerId, stable_id: crate::ids::StableId| {
                    if !owner_matches(owner) {
                        return false;
                    }
                    if zc.from == *zone {
                        return true;
                    }
                    let Ok(required_caster) = required_caster else {
                        return false;
                    };
                    ctx.game
                        .turn_store
                        .turn_history
                        .object_was_cast_from_zone_by(stable_id, *zone, required_caster)
                };
            let origin_satisfied = zc.destination_objects().iter().any(|id| {
                ctx.game
                    .object(*id)
                    .is_some_and(|object| object_satisfies_origin(object.owner, object.stable_id))
            }) || zc
                .snapshots()
                .iter()
                .any(|snapshot| object_satisfies_origin(snapshot.owner, snapshot.stable_id));
            if !origin_satisfied {
                return false;
            }
        }

        true
    }

    fn subscribed_kinds(&self) -> Option<Vec<EventKind>> {
        let mut kinds = vec![EventKind::ZoneChange];
        if self.accepts_game_departure() { kinds.push(EventKind::ObjectLeavesGame); }
        Some(kinds)
    }

    fn trigger_count(&self, event: &TriggerEvent) -> u32 {
        match self.count_mode {
            CountMode::OneOrMore => 1,
            CountMode::Each => {
                if let Some(zc) = self.matching_zone_event(event) {
                    if self.this_object {
                        return 1;
                    }
                    let use_snapshot = self.uses_snapshot() && !zc.snapshots().is_empty();
                    if use_snapshot {
                        zc.snapshots().len() as u32
                    } else {
                        zc.destination_objects().len() as u32
                    }
                } else {
                    1
                }
            }
        }
    }

    fn trigger_count_with_context(&self, event: &TriggerEvent, ctx: &TriggerContext) -> u32 {
        match self.count_mode {
            CountMode::OneOrMore => 1,
            CountMode::Each => {
                if let Some(zc) = self.matching_zone_event(event) {
                    if self.this_object {
                        return 1;
                    }
                    let use_snapshot = self.uses_snapshot() && !zc.snapshots().is_empty();
                    if use_snapshot {
                        matching_snapshots(&zc, &self.object_filter, ctx).len() as u32
                    } else {
                        zc.destination_objects()
                            .iter()
                            .filter(|&&id| {
                                ctx.game.object(id).is_some_and(|obj| {
                                    self.object_filter.matches(obj, &ctx.filter_ctx, ctx.game)
                                })
                            })
                            .count() as u32
                    }
                } else {
                    1
                }
            }
        }
    }

    fn event_value_amount(&self, event: &TriggerEvent, ctx: &TriggerContext) -> Option<i32> {
        if !self.matches(event, ctx) {
            return None;
        }
        let zc = self.matching_zone_event(event)?;
        if self.this_object {
            return Some(1);
        }
        let use_snapshot = self.uses_snapshot() && !zc.snapshots().is_empty();
        let count = if use_snapshot {
            matching_snapshots(&zc, &self.object_filter, ctx).len()
        } else {
            zc.destination_objects()
                .iter()
                .filter(|&&id| {
                    ctx.game.object(id).is_some_and(|obj| {
                        self.object_filter.matches(obj, &ctx.filter_ctx, ctx.game)
                    }) || self.object_filter == ObjectFilter::default()
                })
                .count()
        };
        (count > 0).then_some(count as i32)
    }

    fn simultaneous_trigger_key(
        &self,
        event: &TriggerEvent,
    ) -> Option<crate::triggers::matcher_trait::SimultaneousTriggerKey> {
        (self.count_mode == CountMode::OneOrMore && self.matching_zone_event(event).is_some())
            .then_some(if event.kind() == EventKind::ObjectLeavesGame {
                crate::triggers::matcher_trait::SimultaneousTriggerKey::ObjectLeavesGameBatch
            } else {
                crate::triggers::matcher_trait::SimultaneousTriggerKey::ZoneChangeBatch
            })
    }

    fn uses_snapshot(&self) -> bool {
        // Zone change triggers often need LKI for the object's characteristics
        // at the moment it left its origin zone
        self.from != ZonePattern::Any
    }

    fn looks_back_for_source(&self, event: &TriggerEvent) -> bool {
        let Some(zc) = self.matching_zone_event(event) else {
            return false;
        };
        if !self.from.matches(zc.from) || !self.to.matches(zc.to) {
            return false;
        }

        let leaves_battlefield = zc.from == Zone::Battlefield
            && zc.to != Zone::Battlefield
            && source_zone_is_explicitly_looked_back(&self.from, Zone::Battlefield);
        let leaves_graveyard = zc.from == Zone::Graveyard
            && zc.to != Zone::Graveyard
            && source_zone_is_explicitly_looked_back(&self.from, Zone::Graveyard);
        let public_to_hand_or_library = is_public_to_hand_or_library_zone_change(&zc)
            && matches!(zc.to, Zone::Hand | Zone::Library);

        leaves_battlefield || leaves_graveyard || public_to_hand_or_library
    }

    fn display(&self) -> String {
        // A battlefield-to-exile move caused by this very object is the
        // champion exile: "When a Faerie is championed with this creature".
        if self.from == ZonePattern::Specific(Zone::Battlefield)
            && self.to == ZonePattern::Specific(Zone::Exile)
            && !self.this_object
            && self.cause_filter.as_ref().is_some_and(|cause| cause.ability_kind == Some(crate::events::cause::CauseAbilityKindFilter::ChampionTrigger))
            && self
                .cause_filter
                .as_ref()
                .and_then(|cause| cause.source_filter.as_ref())
                .is_some_and(|source| source.source)
        {
            let noun = self.object_filter.description();
            let article = if noun
                .chars()
                .next()
                .is_some_and(|ch| matches!(ch.to_ascii_lowercase(), 'a' | 'e' | 'i' | 'o' | 'u'))
            {
                "an"
            } else {
                "a"
            };
            return format!("When {article} {noun} is championed with this creature");
        }
        self.generate_display()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::card::{CardBuilder, PowerToughness};
    use crate::events::cause::EventCause;
    use crate::game_state::GameState;
    use crate::ids::{CardId, ObjectId, PlayerId, StableId};
    use crate::snapshot::ObjectSnapshot;
    use crate::types::CardType;

    fn setup_game() -> GameState {
        crate::tests::test_helpers::setup_two_player_game()
    }

    fn make_creature_snapshot(
        object_id: ObjectId,
        controller: PlayerId,
        name: &str,
    ) -> ObjectSnapshot {
        ObjectSnapshot::for_testing(object_id, controller, name)
            .with_card_types(vec![CardType::Creature])
            .with_pt(2, 2)
    }

    fn create_creature_in_zone(game: &mut GameState, owner: PlayerId, zone: Zone) -> ObjectId {
        let card = CardBuilder::new(CardId::new(), "Trigger Test Creature")
            .card_types(vec![CardType::Creature])
            .power_toughness(PowerToughness::fixed(2, 2))
            .build();
        game.create_object_from_card(&card, owner, zone)
    }

    fn spell_or_ability_you_control_exile_trigger() -> ZoneChangeTrigger {
        ZoneChangeTrigger::new()
            .from(Zone::Battlefield)
            .to(Zone::Exile)
            .filter(ObjectFilter::permanent_card())
            .count(CountMode::OneOrMore)
            .cause_filter(Some(
                crate::events::cause::CauseFilter::effect_like()
                    .with_controller(crate::events::cause::ControllerFilter::ContextController),
            ))
    }

    #[test]
    fn duration_return_requires_exact_source_and_not_an_external_exile_return() {
        let mut game = setup_game();
        let alice = PlayerId::from_index(0);
        let source = create_creature_in_zone(&mut game, alice, Zone::Battlefield);
        let other_source = create_creature_in_zone(&mut game, alice, Zone::Battlefield);
        let externally_returned = create_creature_in_zone(&mut game, alice, Zone::Exile);
        let duration_member = create_creature_in_zone(&mut game, alice, Zone::Exile);
        let trigger = ZoneChangeTrigger::new()
            .from(Zone::Exile)
            .to(Zone::Battlefield)
            .duration_return_from_source();

        game.move_object_by_effect(externally_returned, Zone::Battlefield)
            .expect("ordinary exile return must resolve");
        let external_event = game.take_pending_trigger_events().into_iter()
            .find(|event| event.downcast::<ZoneChangeEvent>().is_some_and(|zc| {
                zc.from == Zone::Exile && zc.to == Zone::Battlefield
            }))
            .expect("ordinary return event");
        assert_eq!(external_event.downcast::<ZoneChangeEvent>().unwrap().cause.duration_return_source, None);
        assert!(!trigger.matches(&external_event, &TriggerContext::for_source(source, alice, &game)));

        game.add_exiled_with_source_link_returning_to(source, duration_member, Zone::Battlefield);
        game.mark_return_exiled_when_source_leaves(source);
        let return_stable = game.object(duration_member).unwrap().stable_id;
        game.return_exiled_for_source_leave(source);
        game.process_pending_duration_end_returns(&mut crate::decision::SelectFirstDecisionMaker)
            .expect("duration return must resolve");
        // One-shot completion now matches observations at its own boundary.
        // Inspect that exact completed receipt, not an already-drained queue.
        let returned_id = game.find_object_by_stable_id(return_stable).unwrap();
        let duration_event = game.retained_action_observations()
            .find(|event| event.downcast::<ZoneChangeEvent>().is_some_and(|zc| {
                zc.from == Zone::Exile && zc.to == Zone::Battlefield && zc.result_objects.contains(&returned_id)
            })).cloned()
            .expect("duration return event");
        assert_eq!(duration_event.downcast::<ZoneChangeEvent>().unwrap().cause.duration_return_source, Some(source));
        assert!(trigger.matches(&duration_event, &TriggerContext::for_source(source, alice, &game)));
        assert!(!trigger.matches(&duration_event, &TriggerContext::for_source(other_source, alice, &game)));

        let returned = duration_event.downcast::<ZoneChangeEvent>().unwrap().result_objects[0];
        let reexiled = game.move_object_by_effect(returned, Zone::Exile)
            .expect("returned card can later leave");
        game.take_pending_trigger_events();
        game.move_object_by_effect(reexiled, Zone::Battlefield)
            .expect("same physical card can later blink");
        let later_event = game.take_pending_trigger_events().into_iter()
            .find(|event| event.downcast::<ZoneChangeEvent>().is_some_and(|zc| {
                zc.from == Zone::Exile && zc.to == Zone::Battlefield
            }))
            .expect("later entry event");
        assert_eq!(later_event.downcast::<ZoneChangeEvent>().unwrap().cause.duration_return_source, None);
        assert!(!trigger.matches(&later_event, &TriggerContext::for_source(source, alice, &game)));
    }

    #[test]
    fn old_exile_registration_does_not_match_later_exile_by_same_source() {
        let mut game = setup_game();
        let alice = PlayerId::from_index(0);
        let source = create_creature_in_zone(&mut game, alice, Zone::Battlefield);
        let first_exile = create_creature_in_zone(&mut game, alice, Zone::Exile);
        let first_snapshot = ObjectSnapshot::from_object(game.object(first_exile).unwrap(), &game);
        let returned = game.move_object_by_effect(first_exile, Zone::Battlefield)
            .expect("first exiled incarnation returns externally");
        game.take_pending_trigger_events();
        let second_exile = game.move_object_by_effect(returned, Zone::Exile)
            .expect("same physical card can be exiled again");
        game.take_pending_trigger_events();
        let second_snapshot = ObjectSnapshot::from_object(game.object(second_exile).unwrap(), &game);
        assert_eq!(first_snapshot.stable_id, second_snapshot.stable_id);
        assert_ne!(first_snapshot.object_id, second_snapshot.object_id);

        game.add_exiled_with_source_link_returning_to(source, second_exile, Zone::Battlefield);
        game.mark_return_exiled_when_source_leaves(source);
        game.return_exiled_for_source_leave(source);
        game.process_pending_duration_end_returns(&mut crate::decision::SelectFirstDecisionMaker)
            .expect("second duration return must resolve");
        // One-shot completion matches observations at its own boundary.
        let event = game.retained_action_observations()
            .find(|event| event.downcast::<ZoneChangeEvent>().is_some_and(|zc| {
                zc.from == Zone::Exile && zc.to == Zone::Battlefield
            })).cloned()
            .expect("second duration return event");
        let tag = crate::tag::TagKey::from("captured_exile");
        let trigger = ZoneChangeTrigger::new()
            .from(Zone::Exile)
            .to(Zone::Battlefield)
            .filter(ObjectFilter::tagged(tag.clone()))
            .duration_return_from_source();
        let first_tags = std::collections::HashMap::from([(tag.clone(), vec![first_snapshot])]);
        let second_tags = std::collections::HashMap::from([(tag, vec![second_snapshot])]);
        assert!(!trigger.matches(&event,
            &TriggerContext::for_delayed_source(source, alice, &game, &first_tags)));
        assert!(trigger.matches(&event,
            &TriggerContext::for_delayed_source(source, alice, &game, &second_tags)));
    }

    #[test]
    fn explicit_origin_source_uses_exact_pre_move_id_not_a_later_card_identity() {
        let mut game = setup_game();
        let alice = PlayerId::from_index(0);
        let original = create_creature_in_zone(&mut game, alice, Zone::Graveyard);
        let hand = game.move_object_by_effect(original, Zone::Hand).unwrap();
        assert_ne!(original, hand);
        let event = game
            .take_pending_trigger_events()
            .into_iter()
            .find(|event| event.kind() == EventKind::ZoneChange)
            .unwrap();
        let moved = event.downcast::<ZoneChangeEvent>().unwrap();
        assert_eq!(moved.objects, vec![hand]);
        assert_eq!(moved.snapshots()[0].object_id, original);
        let trigger = ZoneChangeTrigger::new()
            .from(Zone::Graveyard)
            .to(Zone::Hand)
            .this();
        assert!(trigger.matches(&event, &TriggerContext::for_source(original, alice, &game)));
        let later = game.move_object_by_effect(hand, Zone::Graveyard).unwrap();
        assert_ne!(later, original);
        assert!(
            !trigger.matches(&event, &TriggerContext::for_source(later, alice, &game)),
            "returning the same physical card cannot make its new graveyard identity the old event source"
        );
        let unrelated = create_creature_in_zone(&mut game, alice, Zone::Graveyard);
        assert!(!trigger.matches(&event, &TriggerContext::for_source(unrelated, alice, &game)));
    }

    #[test]
    fn test_zone_pattern_matching() {
        assert!(ZonePattern::Any.matches(Zone::Battlefield));
        assert!(ZonePattern::Any.matches(Zone::Graveyard));

        assert!(ZonePattern::Specific(Zone::Battlefield).matches(Zone::Battlefield));
        assert!(!ZonePattern::Specific(Zone::Battlefield).matches(Zone::Graveyard));

        assert!(ZonePattern::OneOf(vec![Zone::Hand, Zone::Graveyard]).matches(Zone::Hand));
        assert!(!ZonePattern::OneOf(vec![Zone::Hand, Zone::Graveyard]).matches(Zone::Battlefield));

        assert!(ZonePattern::AnyExcept(Zone::Battlefield).matches(Zone::Graveyard));
        assert!(!ZonePattern::AnyExcept(Zone::Battlefield).matches(Zone::Battlefield));
    }

    #[test]
    fn test_dies_trigger() {
        let game = setup_game();
        let alice = PlayerId::from_index(0);
        let source_id = ObjectId::from_raw(1);
        let creature_id = ObjectId::from_raw(2);

        let trigger = ZoneChangeTrigger::dies(ObjectFilter::creature());
        let ctx = TriggerContext::for_source(source_id, alice, &game);

        // Creature dying should match
        let event = TriggerEvent::new_with_provenance(
            ZoneChangeEvent::with_cause(
                creature_id,
                Zone::Battlefield,
                Zone::Graveyard,
                EventCause::from_sba(),
                Some(make_creature_snapshot(creature_id, alice, "Bear")),
            ),
            crate::provenance::ProvNodeId::default(),
        );
        assert!(trigger.matches(&event, &ctx));

        // Creature being exiled should not match
        let exile_event = TriggerEvent::new_with_provenance(
            ZoneChangeEvent::with_cause(
                creature_id,
                Zone::Battlefield,
                Zone::Exile,
                EventCause::from_sba(),
                Some(make_creature_snapshot(creature_id, alice, "Bear")),
            ),
            crate::provenance::ProvNodeId::default(),
        );
        assert!(!trigger.matches(&exile_event, &ctx));
    }

    #[test]
    fn leaves_without_dying_excludes_graveyard_and_keeps_batch_surface() {
        let game = setup_game();
        let alice = PlayerId::from_index(0);
        let bob = PlayerId::from_index(1);
        let source_id = ObjectId::from_raw(1);
        let creature_id = ObjectId::from_raw(2);
        let mut filter = ObjectFilter::creature();
        filter.controller = Some(PlayerFilter::You);
        filter.other = true;
        let trigger = ZoneChangeTrigger::new()
            .from(Zone::Battlefield)
            .to(ZonePattern::AnyExcept(Zone::Graveyard))
            .filter(filter)
            .count(CountMode::OneOrMore);
        let ctx = TriggerContext::for_source(source_id, alice, &game);

        assert_eq!(
            trigger.display(),
            "Whenever one or more other creatures you control leave the battlefield without dying"
        );
        let exiled = TriggerEvent::new_with_provenance(
            ZoneChangeEvent::with_cause(
                creature_id,
                Zone::Battlefield,
                Zone::Exile,
                EventCause::effect(),
                Some(make_creature_snapshot(creature_id, alice, "Returned Bear")),
            ),
            crate::provenance::ProvNodeId::default(),
        );
        assert!(trigger.matches(&exiled, &ctx));

        let died = TriggerEvent::new_with_provenance(
            ZoneChangeEvent::with_cause(
                creature_id,
                Zone::Battlefield,
                Zone::Graveyard,
                EventCause::effect(),
                Some(make_creature_snapshot(creature_id, alice, "Dead Bear")),
            ),
            crate::provenance::ProvNodeId::default(),
        );
        assert!(!trigger.matches(&died, &ctx));

        let opponents = TriggerEvent::new_with_provenance(
            ZoneChangeEvent::with_cause(
                creature_id,
                Zone::Battlefield,
                Zone::Hand,
                EventCause::effect(),
                Some(make_creature_snapshot(creature_id, bob, "Opponent Bear")),
            ),
            crate::provenance::ProvNodeId::default(),
        );
        assert!(!trigger.matches(&opponents, &ctx));
    }

    #[test]
    fn extraordinary_journey_matches_direct_or_cast_from_exile_entry() {
        let mut game = setup_game();
        let alice = PlayerId::from_index(0);
        let source_id = create_creature_in_zone(&mut game, alice, Zone::Battlefield);
        let entering_id = create_creature_in_zone(&mut game, alice, Zone::Battlefield);
        let trigger = ZoneChangeTrigger::enters_battlefield(ObjectFilter::creature().nontoken())
            .count(CountMode::OneOrMore)
            .origin_condition(ZoneChangeOriginCondition::moved_from_or_cast_from(
                Zone::Exile,
            ));

        assert_eq!(
            trigger.display(),
            "Whenever one or more nontoken creatures enter the battlefield, if one or more of them entered from exile or was cast from exile"
        );

        let direct_from_exile = TriggerEvent::new(
            ZoneChangeEvent::with_cause(
                entering_id,
                Zone::Exile,
                Zone::Battlefield,
                EventCause::from_game_rule(),
                None,
            ),
            crate::provenance::ProvNodeId::default(),
        );
        assert!(trigger.matches(
            &direct_from_exile,
            &TriggerContext::for_source(source_id, alice, &game)
        ));

        let from_stack = TriggerEvent::new(
            ZoneChangeEvent::with_cause(
                entering_id,
                Zone::Stack,
                Zone::Battlefield,
                EventCause::from_game_rule(),
                None,
            ),
            crate::provenance::ProvNodeId::default(),
        );
        assert!(!trigger.matches(
            &from_stack,
            &TriggerContext::for_source(source_id, alice, &game)
        ));

        let snapshot = ObjectSnapshot::from_object(game.object(entering_id).unwrap(), &game);
        game.record_turn_history_event(&TriggerEvent::new(
            crate::events::spells::SpellCastEvent::new_with_snapshot(
                entering_id,
                alice,
                Zone::Exile,
                snapshot,
            ),
            crate::provenance::ProvNodeId::default(),
        ));
        assert!(trigger.matches(
            &from_stack,
            &TriggerContext::for_source(source_id, alice, &game)
        ));
    }

    #[test]
    fn spell_or_ability_you_control_exile_trigger_uses_trigger_controller() {
        let game = setup_game();
        let alice = PlayerId::from_index(0);
        let bob = PlayerId::from_index(1);
        let source_id = ObjectId::from_raw(1);
        let exiled_id = ObjectId::from_raw(2);
        let trigger = spell_or_ability_you_control_exile_trigger();
        let ctx = TriggerContext::for_source(source_id, alice, &game);

        let event = TriggerEvent::new_with_provenance(
            ZoneChangeEvent::with_cause(
                exiled_id,
                Zone::Battlefield,
                Zone::Exile,
                EventCause::from_effect(source_id, alice),
                Some(make_creature_snapshot(exiled_id, bob, "Opponent Bear")),
            ),
            crate::provenance::ProvNodeId::default(),
        );
        assert!(trigger.matches(&event, &ctx));
        assert_eq!(trigger.event_value_amount(&event, &ctx), Some(1));

        let opponent_cause_event = TriggerEvent::new_with_provenance(
            ZoneChangeEvent::with_cause(
                exiled_id,
                Zone::Battlefield,
                Zone::Exile,
                EventCause::from_effect(exiled_id, bob),
                Some(make_creature_snapshot(exiled_id, bob, "Opponent Bear")),
            ),
            crate::provenance::ProvNodeId::default(),
        );
        assert!(!trigger.matches(&opponent_cause_event, &ctx));
    }

    #[test]
    fn spell_or_ability_you_control_exile_trigger_displays_active_voice() {
        assert_eq!(
            spell_or_ability_you_control_exile_trigger().display(),
            "Whenever a spell or ability you control exiles one or more permanents from the battlefield"
        );
    }

    #[test]
    fn hand_to_exile_nontoken_owned_cards_display_as_cards() {
        let mut filter = ObjectFilter::default().nontoken();
        filter.owner = Some(PlayerFilter::You);
        let trigger = ZoneChangeTrigger::new()
            .from(Zone::Hand)
            .to(Zone::Exile)
            .filter(filter)
            .count(CountMode::OneOrMore);

        assert_eq!(
            trigger.display(),
            "Whenever one or more cards are put into exile from your hand"
        );
    }

    #[test]
    fn library_to_owned_graveyard_preserves_card_subject_origin_and_batch_grammar() {
        let mut filter = ObjectFilter::creature().nontoken();
        filter.zone = None;
        filter.owner = Some(PlayerFilter::You);
        let trigger = ZoneChangeTrigger::new()
            .from(Zone::Library)
            .to(Zone::Graveyard)
            .filter(filter)
            .count(CountMode::OneOrMore);

        assert_eq!(
            trigger.display(),
            "Whenever one or more creature cards are put into your graveyard from your library"
        );
    }

    #[test]
    fn graveyard_card_subject_preserves_permanent_and_another_surfaces() {
        let mut permanent_card = ObjectFilter::permanent_card().nontoken();
        permanent_card.owner = Some(PlayerFilter::You);
        let permanent_trigger = ZoneChangeTrigger::new()
            .to(Zone::Graveyard)
            .filter(permanent_card)
            .count(CountMode::OneOrMore);
        assert_eq!(
            permanent_trigger.display(),
            "Whenever one or more permanent cards are put into your graveyard from anywhere"
        );

        let mut another_card = ObjectFilter::default().nontoken().other();
        another_card.owner = Some(PlayerFilter::You);
        let another_trigger = ZoneChangeTrigger::new()
            .to(Zone::Graveyard)
            .filter(another_card);
        assert_eq!(
            another_trigger.display(),
            "Whenever another card is put into your graveyard from anywhere"
        );
    }

    #[test]
    fn contextual_graveyard_owner_uses_their_for_destination_and_origin() {
        let mut filter = ObjectFilter::land().nontoken();
        filter.zone = None;
        filter.owner = Some(PlayerFilter::IteratedPlayer);
        let trigger = ZoneChangeTrigger::new()
            .from(Zone::Library)
            .to(Zone::Graveyard)
            .filter(filter)
            .count(CountMode::OneOrMore);

        assert_eq!(
            trigger.display(),
            "Whenever one or more land cards are put into their graveyard from their library"
        );
    }

    #[test]
    fn battlefield_to_owned_graveyard_preserves_another_permanent_surface() {
        let mut filter = ObjectFilter::artifact().other();
        filter.zone = None;
        filter.owner = Some(PlayerFilter::You);
        let trigger = ZoneChangeTrigger::new()
            .from(Zone::Battlefield)
            .to(Zone::Graveyard)
            .filter(filter);

        assert_eq!(
            trigger.display(),
            "Whenever another artifact is put into your graveyard from the battlefield"
        );
    }

    #[test]
    fn one_or_more_subtype_union_preserves_plural_and_or_etb_surface() {
        let mut filter = ObjectFilter::default();
        filter.subtypes = vec![
            crate::types::Subtype::Rabbit,
            crate::types::Subtype::Bat,
            crate::types::Subtype::Bird,
            crate::types::Subtype::Mouse,
        ];
        filter.controller = Some(PlayerFilter::You);
        filter.other = true;
        filter.set_union_connective(crate::filter::ObjectFilterUnionConnective::AndOr);

        let trigger = ZoneChangeTrigger::enters_battlefield(filter).count(CountMode::OneOrMore);

        assert_eq!(
            trigger.display(),
            "Whenever one or more other Rabbits, Bats, Birds, and/or Mice you control enter the battlefield"
        );
    }

    #[test]
    fn one_or_more_mixed_creature_artifact_union_uses_death_surface() {
        let mut filter = ObjectFilter::default();
        filter.card_types = vec![CardType::Creature, CardType::Artifact];
        filter.controller = Some(PlayerFilter::You);
        filter.other = true;
        filter.set_union_connective(crate::filter::ObjectFilterUnionConnective::AndOr);

        let trigger = ZoneChangeTrigger::dies(filter).count(CountMode::OneOrMore);

        assert_eq!(
            trigger.display(),
            "Whenever one or more other creatures and/or artifacts you control die"
        );
    }

    #[test]
    fn type_or_subtype_union_preserves_another_and_and_or_etb_surface() {
        let mut filter = ObjectFilter::default();
        filter.card_types = vec![CardType::Artifact];
        filter.subtypes = vec![crate::types::Subtype::Villain];
        filter.type_or_subtype_union = true;
        filter.controller = Some(PlayerFilter::You);
        filter.other = true;
        filter.set_union_connective(crate::filter::ObjectFilterUnionConnective::AndOr);

        let trigger = ZoneChangeTrigger::enters_battlefield(filter);

        assert_eq!(
            trigger.display(),
            "Whenever another artifact and/or Villain you control enters the battlefield"
        );
    }

    #[test]
    fn named_source_graveyard_trigger_keeps_the_short_name_surface() {
        let trigger = ZoneChangeTrigger::dies(ObjectFilter::source_with_surface(
            crate::target::SourceReferenceSurface::ShortName("Blex".to_string()),
        ));

        assert!(trigger.object_filter.source);
        assert_eq!(trigger.from, ZonePattern::Specific(Zone::Battlefield));
        assert_eq!(trigger.to, ZonePattern::Specific(Zone::Graveyard));
        assert_eq!(
            trigger.object_filter.source_surface,
            Some(crate::target::SourceReferenceSurface::ShortName(
                "Blex".to_string()
            ))
        );
    }

    #[test]
    fn test_this_dies_trigger() {
        let game = setup_game();
        let alice = PlayerId::from_index(0);
        let source_id = ObjectId::from_raw(1);
        let other_id = ObjectId::from_raw(2);

        let trigger = ZoneChangeTrigger::this_dies();
        let ctx = TriggerContext::for_source(source_id, alice, &game);

        // Source dying should match
        let event = TriggerEvent::new_with_provenance(
            ZoneChangeEvent::with_cause(
                source_id,
                Zone::Battlefield,
                Zone::Graveyard,
                EventCause::from_sba(),
                Some(make_creature_snapshot(source_id, alice, "Self")),
            ),
            crate::provenance::ProvNodeId::default(),
        );
        assert!(trigger.matches(&event, &ctx));

        // Other creature dying should not match
        let other_event = TriggerEvent::new_with_provenance(
            ZoneChangeEvent::with_cause(
                other_id,
                Zone::Battlefield,
                Zone::Graveyard,
                EventCause::from_sba(),
                Some(make_creature_snapshot(other_id, alice, "Other")),
            ),
            crate::provenance::ProvNodeId::default(),
        );
        assert!(!trigger.matches(&other_event, &ctx));
    }

    #[test]
    fn test_etb_trigger() {
        let game = setup_game();
        let alice = PlayerId::from_index(0);
        let source_id = ObjectId::from_raw(1);
        let creature_id = ObjectId::from_raw(2);

        let trigger = ZoneChangeTrigger::enters_battlefield(ObjectFilter::creature());
        let ctx = TriggerContext::for_source(source_id, alice, &game);

        // ETB from hand
        let from_hand = TriggerEvent::new_with_provenance(
            ZoneChangeEvent::with_cause(
                creature_id,
                Zone::Hand,
                Zone::Battlefield,
                crate::events::cause::EventCause::effect(),
                Some(make_creature_snapshot(creature_id, alice, "Bear")),
            ),
            crate::provenance::ProvNodeId::default(),
        );
        assert!(trigger.matches(&from_hand, &ctx));

        // ETB from graveyard (reanimate)
        let from_graveyard = TriggerEvent::new_with_provenance(
            ZoneChangeEvent::with_cause(
                creature_id,
                Zone::Graveyard,
                Zone::Battlefield,
                crate::events::cause::EventCause::effect(),
                Some(make_creature_snapshot(creature_id, alice, "Bear")),
            ),
            crate::provenance::ProvNodeId::default(),
        );
        assert!(trigger.matches(&from_graveyard, &ctx));
    }

    #[test]
    fn test_etb_other_filter_excludes_same_stable_object_after_zone_change() {
        let mut game = setup_game();
        let alice = PlayerId::from_index(0);
        let old_id = ObjectId::from_raw(41);
        let new_id = ObjectId::from_raw(42);

        let card = CardBuilder::new(CardId::from_raw(9001), "Soul Warden Probe")
            .card_types(vec![CardType::Creature])
            .power_toughness(PowerToughness::fixed(1, 1))
            .build();
        let mut source = crate::object::Object::from_card(new_id, &card, alice, Zone::Battlefield);
        source.stable_id = StableId::from(old_id);
        game.add_object(source);

        let mut snapshot = make_creature_snapshot(old_id, alice, "Soul Warden Probe");
        snapshot.stable_id = StableId::from(old_id);
        let event = TriggerEvent::new_with_provenance(
            ZoneChangeEvent::with_cause(
                new_id,
                Zone::Stack,
                Zone::Battlefield,
                crate::events::cause::EventCause::effect(),
                Some(snapshot),
            ),
            crate::provenance::ProvNodeId::default(),
        );

        let trigger = ZoneChangeTrigger::enters_battlefield(ObjectFilter::creature().other());
        let ctx = TriggerContext::for_source(new_id, alice, &game);

        assert!(
            !trigger.matches(&event, &ctx),
            "expected 'another creature ETB' to exclude the source across zone-change IDs"
        );
    }

    #[test]
    fn test_you_discard_trigger() {
        let game = setup_game();
        let alice = PlayerId::from_index(0);
        let bob = PlayerId::from_index(1);
        let source_id = ObjectId::from_raw(1);
        let card_id = ObjectId::from_raw(2);

        let trigger = ZoneChangeTrigger::you_discard();
        let ctx = TriggerContext::for_source(source_id, alice, &game);

        // Alice discarding should match
        let alice_discard = TriggerEvent::new_with_provenance(
            ZoneChangeEvent::with_cause(
                card_id,
                Zone::Hand,
                Zone::Graveyard,
                EventCause::from_effect(source_id, alice),
                Some(ObjectSnapshot::for_testing(card_id, alice, "Card")),
            ),
            crate::provenance::ProvNodeId::default(),
        );
        assert!(trigger.matches(&alice_discard, &ctx));

        // Bob discarding should not match
        let bob_discard = TriggerEvent::new_with_provenance(
            ZoneChangeEvent::with_cause(
                card_id,
                Zone::Hand,
                Zone::Graveyard,
                EventCause::from_effect(source_id, bob),
                Some(ObjectSnapshot::for_testing(card_id, bob, "Card")),
            ),
            crate::provenance::ProvNodeId::default(),
        );
        assert!(!trigger.matches(&bob_discard, &ctx));
    }

    #[test]
    fn test_zone_change_trigger_during_your_turn_qualifier() {
        let mut game = setup_game();
        let alice = PlayerId::from_index(0);
        let bob = PlayerId::from_index(1);
        let source_id = ObjectId::from_raw(1);
        let card_id = ObjectId::from_raw(2);

        let trigger = ZoneChangeTrigger::new()
            .from(ZonePattern::OneOf(vec![Zone::Graveyard, Zone::Battlefield]))
            .to(Zone::Exile)
            .filter(ObjectFilter::default().nontoken())
            .count(CountMode::OneOrMore)
            .during_turn(PlayerFilter::You);
        let event = TriggerEvent::new_with_provenance(
            ZoneChangeEvent::with_cause(
                card_id,
                Zone::Graveyard,
                Zone::Exile,
                EventCause::effect(),
                Some(ObjectSnapshot::for_testing(card_id, alice, "Exiled Card")),
            ),
            crate::provenance::ProvNodeId::default(),
        );

        game.turn.active_player = alice;
        {
            let ctx = TriggerContext::for_source(source_id, alice, &game);
            assert!(trigger.matches(&event, &ctx));
        }

        game.turn.active_player = bob;
        {
            let ctx = TriggerContext::for_source(source_id, alice, &game);
            assert!(!trigger.matches(&event, &ctx));
        }
    }

    #[test]
    fn test_batch_trigger_count() {
        let objects = vec![
            ObjectId::from_raw(1),
            ObjectId::from_raw(2),
            ObjectId::from_raw(3),
        ];
        let event = TriggerEvent::new_with_provenance(
            ZoneChangeEvent::batch(
                objects,
                Zone::Battlefield,
                Zone::Graveyard,
                EventCause::from_sba(),
            ),
            crate::provenance::ProvNodeId::default(),
        );

        // "Whenever a creature dies" fires 3 times
        let each_trigger = ZoneChangeTrigger::dies(ObjectFilter::creature());
        assert_eq!(each_trigger.trigger_count(&event), 3);

        // "Whenever one or more creatures die" fires once
        let batch_trigger =
            ZoneChangeTrigger::dies(ObjectFilter::creature()).count(CountMode::OneOrMore);
        assert_eq!(batch_trigger.trigger_count(&event), 1);
    }

    #[test]
    fn test_meld_leave_counts_one_dies_trigger_and_two_cards_to_destination() {
        let mut game = setup_game();
        let alice = PlayerId::from_index(0);

        let first = create_creature_in_zone(&mut game, alice, Zone::Graveyard);
        let second = create_creature_in_zone(&mut game, alice, Zone::Graveyard);
        let melded_id = ObjectId::from_raw(99);
        let snapshot = make_creature_snapshot(melded_id, alice, "Chittering Host");
        let event = TriggerEvent::new_with_provenance(
            ZoneChangeEvent::with_results(
                melded_id,
                vec![first, second],
                Zone::Battlefield,
                Zone::Graveyard,
                EventCause::from_sba(),
                Some(snapshot),
            ),
            crate::provenance::ProvNodeId::default(),
        );

        let dies_trigger = ZoneChangeTrigger::dies(ObjectFilter::creature());
        assert_eq!(dies_trigger.trigger_count(&event), 1);

        let card_to_graveyard_trigger = ZoneChangeTrigger::new()
            .to(Zone::Graveyard)
            .count(CountMode::Each);
        assert_eq!(card_to_graveyard_trigger.trigger_count(&event), 2);
    }

    #[test]
    fn authored_graveyard_surface_overrides_display_heuristics_only() {
        let explicit_dies = ZoneChangeTrigger::new()
            .from(Zone::Battlefield)
            .to(Zone::Graveyard)
            .filter(ObjectFilter::planeswalker())
            .graveyard_surface(GraveyardTriggerSurface::Dies);
        assert_eq!(explicit_dies.display(), "Whenever a planeswalker dies");

        let base_creature_trigger = ZoneChangeTrigger::dies(ObjectFilter::creature());
        let explicit_put = base_creature_trigger
            .clone()
            .graveyard_surface(GraveyardTriggerSurface::PutIntoGraveyard);
        assert_eq!(
            explicit_put.display(),
            "Whenever a creature is put into a graveyard from the battlefield"
        );

        let game = setup_game();
        let alice = PlayerId::from_index(0);
        let source_id = ObjectId::from_raw(1);
        let creature_id = ObjectId::from_raw(2);
        let event = TriggerEvent::new_with_provenance(
            ZoneChangeEvent::with_cause(
                creature_id,
                Zone::Battlefield,
                Zone::Graveyard,
                EventCause::from_sba(),
                Some(make_creature_snapshot(creature_id, alice, "Bear")),
            ),
            crate::provenance::ProvNodeId::default(),
        );
        let ctx = TriggerContext::for_source(source_id, alice, &game);
        assert!(base_creature_trigger.matches(&event, &ctx));
        assert!(explicit_put.matches(&event, &ctx));
    }

    fn craft_cost_cause(
        controller: crate::events::cause::ControllerFilter,
    ) -> crate::events::cause::CauseFilter {
        let mut source_filter = ObjectFilter::default();
        source_filter.ability_markers.push("craft".to_string());
        crate::events::cause::CauseFilter {
            cause_type: Some(crate::events::cause::CauseTypeFilter::Exact(
                crate::events::cause::CauseType::Cost,
            )),
            source_filter: Some(source_filter),
            controller_filter: Some(controller),
            ability_kind: None,
        }
    excluded_ability_designations: Vec::new(),
}

    #[test]
    fn source_exiled_for_your_marked_ability_cost_displays_activation_context() {
        let trigger = ZoneChangeTrigger::new()
            .from(Zone::Battlefield)
            .to(Zone::Exile)
            .filter(ObjectFilter::creature())
            .this()
            .cause(craft_cost_cause(
                crate::events::cause::ControllerFilter::You,
            ));

        assert_eq!(
            trigger.display(),
            "When this creature is put into exile from the battlefield while you're activating a craft ability"
        );
    }

    #[test]
    fn marked_ability_cost_for_an_opponent_does_not_claim_you_are_activating_it() {
        let trigger = ZoneChangeTrigger::new()
            .from(Zone::Battlefield)
            .to(Zone::Exile)
            .filter(ObjectFilter::creature())
            .this()
            .cause(craft_cost_cause(
                crate::events::cause::ControllerFilter::Opponent,
            ));

        assert_eq!(
            trigger.display(),
            "When this creature is put into exile from the battlefield"
        );
    }

    #[test]
    fn exile_owned_origin_union_display_preserves_origin_and_subject() {
        for (zones, origin) in [
            (
                vec![Zone::Library, Zone::Graveyard],
                "your library and/or your graveyard",
            ),
            (
                vec![Zone::Hand, Zone::Library],
                "your hand and/or your library",
            ),
            (vec![Zone::Library], "your library"),
        ] {
            let trigger = ZoneChangeTrigger::new()
                .from(ZonePattern::OneOf(zones))
                .to(Zone::Exile)
                .filter(
                    ObjectFilter::default()
                        .nontoken()
                        .owned_by(PlayerFilter::You),
                )
                .count(CountMode::OneOrMore);
            assert_eq!(
                trigger.display(),
                format!("Whenever one or more cards are put into exile from {origin}")
            );
        }
    }

    #[test]
    fn test_display() {
        let dies = ZoneChangeTrigger::dies(ObjectFilter::creature());
        assert!(dies.display().contains("dies"));

        let etb = ZoneChangeTrigger::enters_battlefield(ObjectFilter::default());
        assert!(etb.display().contains("enters the battlefield"));

        let discard = ZoneChangeTrigger::you_discard();
        assert!(discard.display().contains("discard"));

        let graveyard_or_battlefield_to_exile = ZoneChangeTrigger::new()
            .from(ZonePattern::OneOf(vec![Zone::Graveyard, Zone::Battlefield]))
            .to(Zone::Exile)
            .filter(ObjectFilter::default().nontoken())
            .count(CountMode::OneOrMore)
            .during_turn(PlayerFilter::You);
        assert_eq!(
            graveyard_or_battlefield_to_exile.display(),
            "Whenever one or more cards are put into exile from graveyards and/or the battlefield during your turn"
        );

        let anywhere_to_exile = ZoneChangeTrigger::new()
            .to(Zone::Exile)
            .count(CountMode::OneOrMore)
            .during_turn(PlayerFilter::You);
        assert_eq!(
            anywhere_to_exile.display(),
            "Whenever one or more cards are put into exile during your turn"
        );

        let nontoken_anywhere_to_exile = ZoneChangeTrigger::new()
            .to(Zone::Exile)
            .filter(ObjectFilter::default().nontoken())
            .count(CountMode::OneOrMore)
            .during_turn(PlayerFilter::You);
        assert_eq!(
            nontoken_anywhere_to_exile.display(),
            "Whenever one or more cards are put into exile during your turn"
        );
    }

    #[test]
    fn this_creature_dies_during_combat_keeps_the_timing_surface() {
        let trigger = ZoneChangeTrigger::new()
            .from(Zone::Battlefield)
            .to(Zone::Graveyard)
            .filter(ObjectFilter::creature())
            .this()
            .during_combat()
            .graveyard_surface(GraveyardTriggerSurface::Dies);

        assert_eq!(trigger.display(), "When this creature dies during combat");
    }

    #[test]
    fn test_display_does_not_duplicate_article_for_land_etb() {
        let trigger = ZoneChangeTrigger::enters_battlefield(ObjectFilter::land());
        assert_eq!(trigger.display(), "Whenever a land enters the battlefield");
    }

    #[test]
    fn test_display_preserves_enters_under_opponent_control_surface() {
        let mut land = ObjectFilter::land().controlled_by(PlayerFilter::Opponent);
        land.set_enters_under_controller_surface(true);
        let trigger = ZoneChangeTrigger::enters_battlefield(land);
        assert_eq!(
            trigger.display(),
            "Whenever a land enters under an opponent's control"
        );
    }
}

fn zone_origin_name(zone: Zone) -> &'static str {
    match zone {
        Zone::Battlefield => "the battlefield",
        Zone::Graveyard => "a graveyard",
        Zone::Hand => "a hand",
        Zone::Exile => "exile",
        Zone::Stack => "the stack",
        Zone::Library => "a library",
        _ => "anywhere",
    }
}
