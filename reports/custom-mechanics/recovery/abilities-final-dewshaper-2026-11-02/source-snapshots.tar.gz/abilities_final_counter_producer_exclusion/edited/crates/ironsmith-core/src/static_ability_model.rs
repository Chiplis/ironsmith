use crate::tag::TagKeyWalk;

use crate::ConditionConjunction;
use std::any::Any;

use crate::effect::SetQuantifierSurface;
use crate::{
    Ability, AbilityKind, ActivatedAbility, AlternativeCastingMethod, AnthemValue, CardType,
    ChoiceCount, ChooseSpec, Color, ColorSet, Condition, CostComponent, CounterType, DamagedBySource,
    DerivedAlternativeCast, GrantSpec, Grantable, KeywordActionKind, ManaCost, ManaSpendPermission,
    ObjectFilter, PlayerFilter, PresentationLabel, ProtectionFrom, ResolutionProgram, Restriction,
    SourceReferenceSurface, StaticAbilityId, Subtype, SubtypeFamily, Supertype, TotalCost,
    TriggeredAbility, Until, Value, ValueSurfaceHint, Zone,
};

mod grants;

pub use grants::*;

type AbilityModel<T, E, C, Cond, ICond = Condition> =
    Ability<StaticAbility<T, E, C, Cond, ICond>, T, E, C, ICond>;
type LevelAbilityModel<T, E, C, Cond, ICond = Condition> =
    crate::LevelAbility<StaticAbility<T, E, C, Cond, ICond>>;
type GrantSpecModel<T, E, C, Cond, ICond = Condition> =
    GrantSpec<StaticAbility<T, E, C, Cond, ICond>, E, C, Cond>;

/// A casting decision that the "as though it had flash" permission depends
/// on (CR 601.2b-c): X and optional costs are committed during casting, so the
/// permission lets casting begin and the completed proposal must satisfy it.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, Eq, Hash, TagKeyWalk)]
pub enum FlashCastChoice {
    /// "if X is N or less" (Silver Scrutiny).
    XAtMost(u32),
    /// "if it's cast using teamwork" (Quantum Reduction): the named optional
    /// cost was paid for this cast.
    OptionalCostPaid(crate::cost_model::OptionalCostRef),
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, Copy, PartialEq, Eq, TagKeyWalk)]
pub enum ConditionalSpellKeywordKind {
    Flash,
    Cascade,
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default, TagKeyWalk)]
pub enum StaticDamageSourceRelation {
    #[default]
    Any,
    /// The damage source must currently be blocking the static ability source.
    BlockingStaticSource,
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct PreventAllDamageToSelfFromSourcesMatchingSpec {
    pub source_filter: ObjectFilter,
    pub combat_only: bool,
    pub source_relation: StaticDamageSourceRelation,
    pub display: String,
}

/// The destination of a persistent redirection is resolved at the damage event.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, Copy, PartialEq, Eq, TagKeyWalk)]
pub enum StaticDamageRedirectDestination {
    Source,
    AttachedPermanent,
    DamagedPermanentController,
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct StaticDamageRedirectionSpec {
    #[cfg_attr(feature = "serde", serde(default))]
    pub excess_only: bool,
    #[cfg_attr(feature = "serde", serde(default))]
    pub noncombat_only: bool,
    pub source_filter: ObjectFilter,
    pub target_player_filter: Option<PlayerFilter>,
    pub target_object_filter: Option<ObjectFilter>,
    pub combat_only: bool,
    pub source_must_be_untapped: bool,
    pub destination: StaticDamageRedirectDestination,
    pub display: String,
}

/// A projected event matches retained triggered abilities without publishing a
/// real game action or changing combat/history state.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, Copy, PartialEq, Eq, TagKeyWalk)]
pub enum TriggerProjectionEvent { Attacks, Enters, Dies }

/// The actual phase boundary of a source-authored automatic operation.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, Copy, PartialEq, Eq, TagKeyWalk)]
pub enum PlayerActionBoundary { EndStep, BeginCombat }

/// A prevention amount retains prevention semantics, including unpreventable damage.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub enum StaticDamagePreventionAmount {
    All,
    Amount(Value),
    /// Prevent the portion above this amount, not a damage-setting replacement.
    AllBut(u32),
    /// Prevent this much of the damage one source would deal to every
    /// matching recipient at once: one budget per source, divided among its
    /// simultaneous recipients by the affected player ("If a creature would
    /// deal combat damage to you and/or one or more creatures you control,
    /// prevent X of that damage", Cover of Winter). Appended for stable ordinals.
    SharedPerSource(Value),
    /// First damage points this recipient would receive during the current turn.
    FirstEachTurn(u32),
    /// Prevent damage above this recipient's total dealt-damage cap for this turn.
    AllButFirstEachTurn(u32),
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct PreventMatchingDamageSpec {
    pub source_filter: ObjectFilter,
    pub target_player_filter: Option<PlayerFilter>,
    pub target_object_filter: Option<ObjectFilter>,
    pub combat_only: bool,
    pub noncombat_only: bool,
    pub maximum_damage: Option<u32>,
    pub amount: StaticDamagePreventionAmount,
    #[cfg_attr(feature = "serde", serde(default))]
    pub optional_by_controller: bool,
    pub display: String,
}

/// The amount referenced by a prevention effect's additional action.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default, TagKeyWalk)]
pub enum PreventionFollowUpAmount {
    /// "The damage prevented this way"; zero when prevention is prohibited.
    #[default]
    Prevented,
    /// "That many" referring to the damage proposed before this prevention.
    Proposed,
}

/// A complete all-damage prevention with additional effects. Amount-bearing
/// follow-ups explicitly distinguish actual prevention from proposed damage.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct StaticDamagePreventionFollowUp<E> {
    pub source_filter: ObjectFilter,
    pub target_player_filter: Option<PlayerFilter>,
    pub target_object_filter: Option<ObjectFilter>,
    pub combat_only: bool,
    pub noncombat_only: bool,
    pub damage_source_tag: Option<crate::tag::TagKey>,
    pub effects: Vec<E>,
    pub display: String,
    #[cfg_attr(feature = "serde", serde(default))]
    pub amount_basis: PreventionFollowUpAmount,
}

/// A scoped rule permission to ignore one targeting-protection ability.
/// The permission changes targeting legality; it does not remove the ability.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct TargetingAsThoughNoAbilitySpec {
    pub objects: Option<ObjectFilter>,
    pub players: Option<PlayerFilter>,
    pub sources_controlled_by: PlayerFilter,
    pub ignored_ability: StaticAbilityId,
    pub display: String,
}

/// A permission to ignore landwalk only while determining legal blockers.
/// `None` ignores all landwalk kinds; `Some` ignores only the named kind.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct BlockingAsThoughNoLandwalkSpec {
    pub objects: ObjectFilter,
    pub landwalk: Option<LandwalkKind>,
    pub display: String,
}

/// The quality of spell onto which a card's splice ability may be applied.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, Copy, PartialEq, Eq, TagKeyWalk)]
pub enum SpliceQuality {
    Arcane,
    InstantOrSorcery,
}

impl SpliceQuality {
    pub const fn oracle_surface(self) -> &'static str {
        match self {
            Self::Arcane => "Arcane",
            Self::InstantOrSorcery => "instant or sorcery",
        }
    }
}

/// Typed CR 702.47 splice ability payload.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct SpliceSpec<C> {
    /// Attributed custom payment identity, independent of official splice.
    #[cfg_attr(feature = "serde", serde(default))]
    pub custom_keyword: Option<String>,
    /// Source zone for adding this card's text; None preserves official hand splice.
    #[cfg_attr(feature = "serde", serde(default))]
    pub source_zone: Option<crate::zone::Zone>,
    /// Move the selected source as an additional cost instead of only revealing it.
    #[cfg_attr(feature = "serde", serde(default))]
    pub source_destination: Option<crate::zone::Zone>,
    /// Maximum selections sharing this source-zone/disposition program per spell.
    #[cfg_attr(feature = "serde", serde(default))]
    pub max_per_spell: Option<u32>,

    pub quality: SpliceQuality,
    pub cost: TotalCost<C>,
    /// The canonical oracle surface for the splice cost, when parsing retained one.
    ///
    /// Payment remains represented by `cost`; this field prevents typed choose-then-pay
    /// costs from being rendered as their lower-level execution steps.
    pub cost_surface: Option<String>,
    #[cfg_attr(feature = "serde", serde(default))]
    pub descriptive: bool,
}

/// Typed CR 702.120 escalate ability payload.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct EscalateSpec<C> {
    /// The additional cost paid once for each mode chosen beyond the first.
    pub cost: TotalCost<C>,
    /// The canonical oracle surface for the escalate cost, when parsing retained one.
    pub cost_surface: Option<String>,
    /// Ordinary per-mode payment has no Escalate keyword identity.
    #[cfg_attr(feature = "serde", serde(default))]
    pub descriptive: bool,
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, Copy, PartialEq, Eq, TagKeyWalk)]
pub enum GraveyardCountMetric {
    CardTypes,
    ManaValues,
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, Copy, PartialEq, Eq, TagKeyWalk)]
pub struct ConditionalSpellKeywordSpec {
    pub keyword: ConditionalSpellKeywordKind,
    pub metric: GraveyardCountMetric,
    pub threshold: u32,
}

/// A linked action performed after a damage-prevention replacement removes counters.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, Copy, PartialEq, Eq, TagKeyWalk)]
pub enum CounterRemovalFollowUp {
    /// Give every player counters for each counter the replacement actually removed.
    EachPlayerGetsCounters {
        counter_type: CounterType,
        counters_per_removed: u32,
    },
}

/// Authored punctuation joining damage prevention to its linked counter
/// removal. This affects only Oracle-facing text; replacement semantics are
/// identical for both surfaces.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default, TagKeyWalk)]
pub enum CounterRemovalPreventionSurface {
    #[default]
    Conjoined,
    SeparateSentences,
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, Copy, PartialEq, Eq, TagKeyWalk)]
pub enum AdditionalTokenKind {
    Treasure,
    Food,
    Clue,
    /// 1/1 green Squirrel creature token (Chatterfang, Squirrel General).
    Squirrel,
}

/// How complete token templates modify the matching groups of one creation event.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, Copy, PartialEq, Eq, TagKeyWalk)]
pub enum TokenCreationTemplateMode {
    AppendOnce,
    AppendForEach,
    ReplaceEach,
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, Eq, TagKeyWalk)]
pub enum PregameActionKind {
    ChosenOutsideGame(PregameChosenCardSpec),
    /// A per-source setup hook; its composed program is in the existing
    /// PregameAction payload effects and has no designation cardinality limit.
    SourceSetup { source_zone: Zone },
    BeginOnBattlefield(PregameBeginOnBattlefieldSpec),
    MulliganExileHandDrawSameCount,
    ChooseColor,
    RevealFromOpeningHand(PregameRevealFromOpeningHandSpec),
    /// "Before you shuffle your deck to start the game, you may reveal this
    /// card from your deck and exile three or more creature cards you
    /// drafted that aren't in your deck." (Volatile Chimera): the exiled
    /// cards are recorded as exiled with cards of this card's name.
    ExileDraftedCardsBeforeShuffle(PregameExileDraftedCardsSpec),
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, Eq, TagKeyWalk)]
pub struct PregameExileDraftedCardsSpec {
    /// Card types every exiled drafted card must have (any of them).
    pub card_types: Vec<CardType>,
    /// The fewest drafted cards the action exiles ("three or more").
    pub minimum: u32,
    /// The most drafted cards the action exiles ("a creature card you
    /// drafted", Caller of the Untamed: exactly one); `None` is unbounded.
    #[cfg_attr(feature = "serde", serde(default))]
    pub maximum: Option<u32>,
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, Eq, TagKeyWalk)]
pub struct PregameBeginOnBattlefieldSpec {
    pub require_not_starting_player: bool,
    pub counters: Vec<(CounterType, u32)>,
    pub exile_cards_from_hand: usize,
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default, TagKeyWalk)]
pub struct PregameRevealFromOpeningHandSpec {
    /// Oracle places the consequence before its timing clause (for example,
    /// "scry 3 at the beginning of your first upkeep").
    pub effect_before_timing: bool,
}

/// Imported setup metadata is evaluated against immutable original printed text,
/// never against rendered or expanded executable abilities.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, Eq, TagKeyWalk)]
pub enum PregameDeckCondition {
    Unrestricted,
    EveryCardPrintedTextContainsAny { exempt_types: Vec<CardType>, phrases: Vec<String> },
}
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, Eq, TagKeyWalk)]
pub struct PregameChosenCardSpec {
    pub designation: String,
    pub deck_condition: PregameDeckCondition,
    pub action: PregameChosenCardAction,
}
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, Eq, TagKeyWalk)]
pub enum PregameChosenCardAction {
    ExchangeWithOpeningHand,
}

/// A typed predicate for the starting-deck condition of CR 702.139 companion.
///
/// The variants describe reusable card/deck properties rather than named
/// companion cards, so setup validation is independent of a card's identity.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, Eq, TagKeyWalk)]
pub enum CompanionDeckCondition {
    OnlyManaValueParity { even: bool, lands_are_exempt: bool },
    NoRepeatedManaSymbols,
    CreatureSubtypes(Vec<Subtype>),
    NonlandManaValueAtLeast(u32),
    PermanentManaValueAtMost(u32),
    UniqueNonlandNames,
    SharedNonlandCardType,
    CardsAboveMinimumDeckSize(usize),
    PermanentsHaveActivatedAbility,
}

/// Immutable facts used to validate a companion against one starting-deck card.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, Eq, TagKeyWalk)]
pub struct CompanionDeckCardFacts {
    pub name: String,
    pub mana_cost: Option<ManaCost>,
    pub card_types: Vec<CardType>,
    pub subtypes: Vec<Subtype>,
    pub has_all_creature_types: bool,
    pub has_activated_ability: bool,
}

impl CompanionDeckCondition {
    /// Evaluate this condition against the complete starting deck.
    pub fn is_fulfilled_by(
        &self,
        deck: &[CompanionDeckCardFacts],
        minimum_deck_size: usize,
    ) -> bool {
        use std::collections::HashSet;

        let is_land = |card: &CompanionDeckCardFacts| card.card_types.contains(&CardType::Land);
        let is_permanent = |card: &CompanionDeckCardFacts| {
            card.card_types.iter().any(|card_type| {
                matches!(
                    card_type,
                    CardType::Artifact
                        | CardType::Battle
                        | CardType::Creature
                        | CardType::Enchantment
                        | CardType::Land
                        | CardType::Planeswalker
                )
            })
        };
        let mana_value =
            |card: &CompanionDeckCardFacts| card.mana_cost.as_ref().map_or(0, ManaCost::mana_value);

        match self {
            Self::OnlyManaValueParity {
                even,
                lands_are_exempt,
            } => deck.iter().all(|card| {
                (*lands_are_exempt && is_land(card)) || (mana_value(card) % 2 == 0) == *even
            }),
            Self::NoRepeatedManaSymbols => deck.iter().all(|card| {
                let mut symbols = HashSet::new();
                card.mana_cost.as_ref().is_none_or(|cost| {
                    cost.pips()
                        .iter()
                        .all(|symbol| symbols.insert(symbol.as_slice()))
                })
            }),
            Self::CreatureSubtypes(allowed) => deck.iter().all(|card| {
                !card.card_types.contains(&CardType::Creature)
                    || card.has_all_creature_types
                    || card
                        .subtypes
                        .iter()
                        .any(|subtype| allowed.contains(subtype))
            }),
            Self::NonlandManaValueAtLeast(minimum) => deck
                .iter()
                .all(|card| is_land(card) || mana_value(card) >= *minimum),
            Self::PermanentManaValueAtMost(maximum) => deck
                .iter()
                .all(|card| !is_permanent(card) || mana_value(card) <= *maximum),
            Self::UniqueNonlandNames => {
                let mut names = HashSet::new();
                deck.iter()
                    .filter(|card| !is_land(card))
                    .all(|card| names.insert(card.name.trim().to_ascii_lowercase()))
            }
            Self::SharedNonlandCardType => {
                let mut nonlands = deck.iter().filter(|card| !is_land(card));
                let Some(first) = nonlands.next() else {
                    return true;
                };
                first.card_types.iter().any(|shared_type| {
                    nonlands
                        .clone()
                        .all(|card| card.card_types.contains(shared_type))
                })
            }
            Self::CardsAboveMinimumDeckSize(additional) => {
                deck.len() >= minimum_deck_size.saturating_add(*additional)
            }
            Self::PermanentsHaveActivatedAbility => deck
                .iter()
                .all(|card| !is_permanent(card) || card.has_activated_ability),
        }
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct ThisSpellCastRestrictionKind {
    pub label: String,
    /// New cast-time facts are typed; old label-only artifacts retain their
    /// legacy conversion without changing their serialized representation.
    #[cfg_attr(
        feature = "serde",
        serde(default, skip_serializing_if = "Option::is_none")
    )]
    pub timing: Option<crate::ThisSpellCastTiming>,
    /// Appended: a typed cast-time condition that must hold for the spell to
    /// be cast ("You can't cast this spell unless <condition>").
    #[cfg_attr(
        feature = "serde",
        serde(default, skip_serializing_if = "Option::is_none")
    )]
    pub condition: Option<Condition>,
}

impl ThisSpellCastRestrictionKind {
    fn named(label: impl Into<String>) -> Self {
        Self {
            label: label.into(),
            timing: None,
            condition: None,
        }
    }

    pub fn timing(timing: crate::ThisSpellCastTiming) -> Self {
        Self {
            label: "typed cast timing".into(),
            timing: Some(timing),
            condition: None,
        }
    }

    /// "You can't cast this spell unless <condition>": castable only while
    /// the typed condition holds for the caster.
    pub fn only_if(condition: Condition) -> Self {
        Self {
            label: "typed cast condition".into(),
            timing: None,
            condition: Some(condition),
        }
    }

    pub fn during_declare_attackers_step() -> Self {
        Self::named("during declare attackers step")
    }

    pub fn during_declare_attackers_step_if_you_were_attacked_this_step() -> Self {
        Self::named("during declare attackers step if you were attacked")
    }

    pub fn during_combat() -> Self {
        Self::named("during combat")
    }

    pub fn during_combat_before_blockers_are_declared() -> Self {
        Self::named("during combat before blockers")
    }

    pub fn during_combat_after_blockers_are_declared() -> Self {
        Self::named("during combat after blockers")
    }

    pub fn during_combat_on_your_turn_before_blockers_are_declared() -> Self {
        Self::named("during combat on your turn before blockers")
    }

    pub fn during_combat_on_opponents_turn() -> Self {
        Self::named("during combat on opponents turn")
    }

    pub fn before_attackers_are_declared() -> Self {
        Self::named("before attackers are declared")
    }

    pub fn before_combat_damage_step() -> Self {
        Self::named("before combat damage step")
    }

    pub fn during_opponents_upkeep() -> Self {
        Self::named("during opponents upkeep")
    }

    pub fn during_opponents_turn_after_upkeep() -> Self {
        Self::named("during opponents turn after upkeep")
    }

    pub fn during_your_end_step() -> Self {
        Self::named("during your end step")
    }

    pub fn if_you_cast_another_spell_this_turn() -> Self {
        Self::named("if you cast another spell this turn")
    }

    pub fn if_you_cast_another_green_spell_this_turn() -> Self {
        Self::named("if you cast another green spell this turn")
    }

    pub fn if_opponent_cast_creature_spell_this_turn() -> Self {
        Self::named("if opponent cast creature spell this turn")
    }

    pub fn if_creature_is_attacking_you() -> Self {
        Self::named("if creature is attacking you")
    }

    pub fn if_creature_died_this_turn() -> Self {
        Self::named("if creature died this turn")
    }

    pub fn after_combat() -> Self {
        Self::named("after combat")
    }

    pub fn if_no_permanents_named_on_battlefield(name: impl AsRef<str>) -> Self {
        Self::named(format!("if no permanents named {}", name.as_ref()))
    }

    pub fn if_you_control_snow_land() -> Self {
        Self::named("if you control snow land")
    }

    pub fn if_you_control_fewer_creatures_than_each_opponent() -> Self {
        Self::named("if you control fewer creatures than each opponent")
    }

    pub fn if_you_control_subtype_or_more(subtype: Subtype, count: u32) -> Self {
        Self::named(format!("if you control {count}+ {subtype}"))
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, PartialEq)]
/// A static ability, over whatever vocabulary the phase using it speaks.
///
/// `ICond` is the intervening-if condition of any triggered ability this
/// payload links; see [`TriggeredAbility`]. It defaults to the resolved
/// [`Condition`] so the runtime spells this the way it always has.
#[derive(TagKeyWalk)]
pub struct StaticAbility<T, E, C, Cond, ICond = Condition> {
    pub id: Option<StaticAbilityId>,
    pub label: String,
    pub payload: StaticAbilityPayload<T, E, C, Cond, ICond>,
}

impl<T: Clone, E: Clone, C: Clone, Cond: Clone, ICond: Clone> Clone
    for StaticAbility<T, E, C, Cond, ICond>
{
    fn clone(&self) -> Self {
        // Grants can carry further static abilities. Guard each recursive
        // boundary before cloning the large payload enum in native debug
        // builds, rather than relying on the caller's thread stack size.
        #[cfg(not(target_arch = "wasm32"))]
        return stacker::maybe_grow(8 * 1024 * 1024, 64 * 1024 * 1024, || self.clone_payload());
        #[cfg(target_arch = "wasm32")]
        self.clone_payload()
    }
}

impl<T: Clone, E: Clone, C: Clone, Cond: Clone, ICond: Clone> StaticAbility<T, E, C, Cond, ICond> {
    fn clone_payload(&self) -> Self {
        Self {
            id: self.id,
            label: self.label.clone(),
            payload: self.payload.clone(),
        }
    }
}

/// Internal model-label prefix for an authored ability word that precedes an
/// explicit conditional static clause. The condition remains rules text; this
/// marker only lets compiled-text rendering restore the presentation prefix.
pub const EXPLICIT_STATIC_PRESENTATION_LABEL_PREFIX: &str = "__ironsmith_explicit_static_label:";

/// Internal presentation provenance for a static ability authored on a
/// Station threshold row (`N+ | ...`). The numeric suffix is derived from the
/// typed station-line CST; renderers must also verify the matching charge-
/// counter condition before restoring the row surface.
pub const STATION_THRESHOLD_STATIC_LABEL_PREFIX: &str = "__ironsmith_station_threshold_static:";

/// Presentation provenance for a leading `As long as it's your turn` static
/// condition. The executable condition remains `YourTurn`; this marker only
/// distinguishes that authored connective from an ordinary `During your
/// turn` line.
pub const AS_LONG_AS_ITS_YOUR_TURN_STATIC_LABEL_PREFIX: &str =
    "__ironsmith_as_long_as_its_your_turn:";

/// How an ability-loss continuous effect treats later attempts to grant the
/// same ability.
///
/// Ordinary "lose" effects remain timestamp ordered in layer 6. The two
/// prohibition modes additionally prevent the affected object from regaining
/// the removed ability while the effect applies.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default, TagKeyWalk)]
pub enum AbilityLossMode {
    #[default]
    Lose,
    LoseAndCantGain,
    LoseAndCantHaveOrGain,
}

impl AbilityLossMode {
    pub const fn prohibits_gain(self) -> bool {
        !matches!(self, Self::Lose)
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct PowerToughnessChoiceOption<T, E, C, Cond, ICond = Condition> {
    pub power: i32,
    pub toughness: i32,
    #[cfg_attr(feature = "serde", serde(default))]
    pub card_types: Option<Vec<crate::types::CardType>>,
    #[cfg_attr(feature = "serde", serde(default))]
    pub added_subtypes: Vec<crate::types::Subtype>,
    pub abilities: Vec<StaticAbility<T, E, C, Cond, ICond>>,
}

impl<T, E, C, Cond, ICond> PowerToughnessChoiceOption<T, E, C, Cond, ICond> {
    pub fn new(power: i32, toughness: i32) -> Self {
        Self {
            power,
            toughness,
            card_types: None,
            added_subtypes: Vec::new(),
            abilities: Vec::new(),
        }
    }

    pub fn with_abilities(
        power: i32,
        toughness: i32,
        abilities: Vec<StaticAbility<T, E, C, Cond, ICond>>,
    ) -> Self {
        Self {
            power,
            toughness,
            card_types: None,
            added_subtypes: Vec::new(),
            abilities,
        }
    }
}

/// An intrinsic starting-counter rule (CR 306.5b and 310.4b). The number is
/// read from the entering object's prospective printed characteristics.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, TagKeyWalk)]
pub enum IntrinsicStartingCounter {
    Loyalty,
    Defense,
}
impl IntrinsicStartingCounter {
    pub fn counter_type(self) -> CounterType {
        match self {
            Self::Loyalty => CounterType::Loyalty,
            Self::Defense => CounterType::Defense,
        }
    }
    pub fn card_type(self) -> crate::types::CardType {
        match self {
            Self::Loyalty => crate::types::CardType::Planeswalker,
            Self::Defense => crate::types::CardType::Battle,
        }
    }
}

/// The group named by a partner keyword: "partner—survivors" and
/// "partner - survivors" both name `survivors`; bare "partner" names none.
pub fn partner_group_identifier(keyword: &str) -> Option<String> {
    let group = keyword
        .trim()
        .to_lowercase()
        .strip_prefix("partner")?
        .trim_start_matches(|c: char| c.is_whitespace() || matches!(c, '-' | '—' | '–'))
        .trim()
        .to_string();
    (!group.is_empty()).then_some(group)
}

/// The copy limit stated by a deck-construction rule ("A deck can have any
/// number of cards named ~" → `Some(None)`, "up to seven" → `Some(Some(7))`).
pub fn deck_construction_copy_limit(text: &str) -> Option<Option<u32>> {
    let normalized = text.trim().trim_end_matches('.').to_ascii_lowercase();

    if normalized.starts_with("a deck can have any number of cards named ") {
        return Some(None);
    }
    let amount = normalized.strip_prefix("a deck can have up to ")?.split_whitespace().next()?;
    let limit = amount.parse().ok().or_else(|| {
        Some(match amount {
            "one" => 1,
            "two" => 2,
            "three" => 3,
            "four" => 4,
            "five" => 5,
            "six" => 6,
            "seven" => 7,
            "eight" => 8,
            "nine" => 9,
            "ten" => 10,
            _ => return None,
        })
    })?;
    Some(Some(limit))
}

/// How many colors a deck-construction rule has its owner circle ("As you
/// create your deck, circle two of the colors below." → 2, Cryptic Spires).
pub fn deck_construction_color_choice_count(text: &str) -> Option<u32> {
    let normalized = text.trim().to_ascii_lowercase();
    let rest = normalized.strip_prefix("as you create your deck, ")?;
    let rest = rest.strip_prefix("circle ").or_else(|| rest.strip_prefix("choose "))?;
    let (amount, rest) = rest.split_once(' ')?;
    if !rest.starts_with("of the colors") {
        return None;
    }
    amount.parse().ok().or(match amount {
        "one" => Some(1),
        "two" => Some(2),
        "three" => Some(3),
        "four" => Some(4),
        "five" => Some(5),
        _ => None,
    })
}

/// A keyword-marker line whose game effect the engine implements. It is
/// classified once, when the marker is built, so runtime checks read the
/// kind instead of the marker's text.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, Eq, TagKeyWalk)]
pub enum KeywordMarkerMechanic {
    /// Increase the distinct occurrence budget only during the specified named action.
    ClassTriggerChoiceAdjustment { action:String, class:String, additional:u32 },
    /// Optional replacement of one class occurrence by multiple occurrences.
    ClassTriggerMultiplication { class:String, multiplier:u32, once_each_turn:bool },
    /// CR 702.44 sunburst.
    Sunburst,
    /// CR 702.150 compleated.
    Compleated,
    /// CR 702.50 epic.
    Epic,
    /// Paradigm (Secrets of Strixhaven).
    Paradigm,
    /// "If this creature's power is negative, it assigns combat damage as
    /// though its power were positive" (Loot, the Anomaly).
    AssignsCombatDamageAsThoughPowerPositive,
    /// "This creature stations permanents using its toughness rather than
    /// its power."
    StationsUsingToughness,
    /// "This creature crews vehicles using its toughness rather than its
    /// power"; with `saddles`, it also saddles mounts that way.
    ContributesToughness { saddles: bool },
    /// "This creature crews vehicles as though its power were N greater";
    /// with `saddles`, it also saddles mounts that way.
    ContributesExtraPower { saddles: bool, amount: u32 },
    /// "You may remove a loyalty counter from a planeswalker you control
    /// rather than pay this Vehicle's crew cost."
    LoyaltyCounterPaysCrewCost,
    /// Attacking does not cause the source to tap. This operation does not
    /// itself give the source the keyword identity Vigilance.
    AttackingDoesNotCauseTap,
    /// A timing permission, independent of the Flash keyword's identity.
    CastAtInstantTiming,
    /// Deal damage in the first combat damage step, optionally also in the
    /// regular step. Does not confer either strike keyword's identity.
    EarlyCombatDamage { also_regular: bool },
    /// Nonzero damage to a creature is lethal, independently of keyword identity.
    DamageIsLethalToCreatures,
    /// Damage also causes the source's controller to gain that much life.
    DamageGrantsControllerLife,
    /// Damage to this creature also makes its controller lose that much life.
    /// Multiple instances are redundant and this is not a triggered ability.
    DamageCausesRecipientControllerLifeLoss,
    /// Damage to creatures places -1/-1 counters; optionally damage to
    /// players gives poison counters instead of life loss. No keyword identity.
    DamageAsCounters { poison_players: bool },
    /// Destroy instructions and lethal damage cannot destroy this permanent.
    DestructionImmune,
    /// An attachment may be attached even while it has the creature type.
    AttachWhileCreature,
    /// Replace destruction of the attached permanent by clearing its damage and destroying this source.
    DestroyAttachmentInstead,
    /// Exchange phased-in/out status during the controller's untap turn action.
    PhaseDuringUntap,
    /// Poison counters added to player combat damage without a Toxic identity.
    CombatDamageAddsPoison { amount: u32 },
    /// Assign excess combat damage beyond blockers, optionally beyond planeswalkers.
    OverflowCombatDamage { through_planeswalkers: bool },
    ExileGraveyardCardsForGenericMana,
    TapCreaturesForMana,
    TapArtifactsForGenericMana,
    /// Replace stack departures after a cast from the specified zone, irrespective of price.
    ExileOnStackExitIfCastFrom { zone: crate::Zone },
    /// A lasting player designation awarded by a continuous permanent-count condition.
    PermanentCountGrantsDesignation { #[cfg_attr(feature = "serde", serde(default))] history_requirements: Vec<crate::DesignationHistoryRequirement>, minimum: u32, historic_only: bool, enduring_story: bool, #[cfg_attr(feature = "serde", serde(default))] tapped_only: bool, #[cfg_attr(feature = "serde", serde(default))] named_designation: Option<String> },
    EntryLoyaltyReductionPerLifePip,
    DayNightTransformDefinition { day_face: bool },
    AnotherPlayerPaysGeneric,
    ChooseSagaEntryChapter,
    InitializeControllerSpeed,
    AssignCreatureSectors,
    CombatBandsAndDamageChoice,
    EntryCountersFromSpentColors,
    RecurringCopyOnFirstNameResolution,
    LinkOnGraveyardArrival,
    CastBothSplitHalvesFromHand,
    RevealSharedTypesForEntryCounters { amount: u32 },
    EntryCountersAndFollowingAbilities { amount: u32 },
    /// A live source instruction executed during its final chapter resolution.
    FinalChapterResolutionRemovesCounters { counter_name: String },
    /// Declared participation in the native precombat lore-counter action.
    PrecombatLoreProgression { stop_at_final_chapter: bool },
}

/// The mechanic a keyword-marker line carries, if the engine implements one.
pub fn keyword_marker_mechanic(text: &str) -> Option<KeywordMarkerMechanic> {
    use KeywordMarkerMechanic as M;
    if text.trim().trim_end_matches('.').eq_ignore_ascii_case("If this spell was cast from your graveyard, exile it instead of putting it anywhere else any time it would leave the stack") {
        return Some(M::ExileOnStackExitIfCastFrom { zone: crate::Zone::Graveyard });
    }
    let normalized = text.trim().trim_end_matches('.').to_ascii_lowercase();
    let label = |s:&str| !s.is_empty() && s.split_whitespace().all(|word|word.chars().all(|c|c.is_ascii_alphanumeric() || c=='-'));
    if let Some(body)=normalized.strip_prefix("as you ")
        && let Some((action,class))=body.split_once(", you may choose another ")
        && let Some(class)=class.strip_suffix(" ability to trigger")
        && label(action) && label(class)
    {return Some(M::ClassTriggerChoiceAdjustment{action:action.into(),class:class.into(),additional:1});}
    let (once_each_turn,body)=normalized.strip_prefix("once each turn, ").map(|body|(true,body)).unwrap_or((false,normalized.as_str()));
    if let Some(body)=body.strip_prefix("if you would trigger a ")
        && let Some(class)=body.strip_suffix(" ability of a permanent you control, you may have that ability trigger twice instead")
        && label(class)
    {return Some(M::ClassTriggerMultiplication{class:class.into(),multiplier:2,once_each_turn});}

    if let Some(tail) = normalized.strip_prefix("as your precombat main phase begins, put a lore counter on this permanent as a turn-based action") {
        let stop = match tail {
            "" => false,
            ", unless it has at least as many lore counters as its final chapter number" => true,
            _ => return None,
        };
        return Some(M::PrecombatLoreProgression { stop_at_final_chapter: stop });
    }

    if let Some(counter_name) = normalized.strip_prefix("as this saga's final chapter ability resolves, remove all ")
        .and_then(|body| body.strip_suffix(" counters from it"))
        .filter(|name| !name.is_empty() && name.chars().all(|c| c.is_ascii_alphanumeric() || matches!(c, ' ' | '+' | '-' | '/'))
            && !name.split_whitespace().any(|word| matches!(word, "and" | "or" | "if" | "then" | "unless")))
    { return Some(M::FinalChapterResolutionRemovesCounters { counter_name: counter_name.to_string() }); }

    if normalized == "if it's neither day nor night and no permanent establishes day, it becomes night. as it becomes day, if this permanent is back face up, transform it. this permanent can't transform except due to this ability. if a player casts at least two spells during their own turn, it becomes day next turn" { return Some(M::DayNightTransformDefinition { day_face: false }); }
    if normalized == "if it's neither day nor night, it becomes day. if it's night, this permanent enters transformed. as it becomes night, if this permanent is front face up, transform it. this permanent can't transform except due to this ability. if a player casts no spells during their own turn, it becomes night next turn" { return Some(M::DayNightTransformDefinition { day_face: true }); }
    if normalized == "as you cast this spell, before activating mana abilities, you may choose another player. that player may activate mana abilities before you do and may pay any amount of the generic mana in this spell's total cost before you pay the rest" { return Some(M::AnotherPlayerPaysGeneric); }
    if normalized == "if you have no speed while you control this permanent, your speed becomes 1 as a state-based action. whenever one or more opponents lose life during your turn, if your speed is less than 4, your speed increases by 1. this inherent ability has no source and triggers only once each turn. your speed remains after this permanent leaves the battlefield. max speed is 4" { return Some(M::InitializeControllerSpeed); }
    if normalized == "as a state-based action, each creature without a sector designation is assigned alpha, beta, or gamma sector by its controller. players who don't control a permanent with this ability assign first, then the other players assign, in active-player order within each group. a permanent keeps its sector until no player controls a permanent with this ability or an ability whose source has this ability. sector designations aren't copiable" { return Some(M::AssignCreatureSectors); }
    if normalized == "as you declare attackers, you may group one or more attacking creatures with this ability and up to one other attacking creature into a band. each creature can belong to only one band, and all members must attack the same player, planeswalker, or battle. the band lasts for the rest of combat even if this ability is lost; creatures removed from combat leave the band. members don't share abilities. a creature blocking any member blocks all members, and an effect that blocks one member blocks the whole band. if this creature is blocking an attacker, you choose how that attacker divides its combat damage among its blockers. if this creature is blocked, you choose how its blockers divide their combat damage among the creatures they block" { return Some(M::CombatBandsAndDamageChoice); }
    if normalized == "as this saga enters, choose a number between one and its final chapter number. it enters with the chosen number of lore counters. chapter abilities of this saga can't trigger the turn it entered unless it has exactly the number of lore counters specified in that chapter's symbol" { return Some(M::ChooseSagaEntryChapter); }
    if normalized == "if this permanent is entering as a creature, ignoring type-changing effects that would affect it, it enters with a +1/+1 counter on it for each color of mana spent to cast it. otherwise, it enters with a charge counter on it for each color of mana spent to cast it" { return Some(M::EntryCountersFromSpentColors); }
    if normalized == "if this permanent would enter with one or more loyalty counters on it and the player who cast it paid life for phyrexian mana symbols in its cost, it instead enters with two fewer loyalty counters for each of those symbols" { return Some(M::EntryLoyaltyReductionPerLifePip); }
    if let Some(rest) = normalized.strip_prefix("when this creature enters, put ")
        && let Some(amount) = rest.strip_suffix(" +1/+1 counters on target creature. if that's another creature, it gains the following abilities until end of turn")
            .or_else(|| rest.strip_suffix(" +1/+1 counter on target creature. if that's another creature, it gains the following abilities until end of turn")) {
        let amount = match amount { "a" | "one" => Some(1), "two" => Some(2), "three" => Some(3), _ => amount.parse().ok() };
        if let Some(amount) = amount { return Some(M::EntryCountersAndFollowingAbilities { amount }); }
    }
    if normalized == "if this is the first time a spell you control with this spell's name has resolved this game, at the beginning of each of your precombat main phases for the rest of the game, create a copy of this object in exile. you may cast the copy without paying its mana cost. exile this spell" { return Some(M::RecurringCopyOnFirstNameResolution); }
    if normalized == "you may cast one or both halves of this card from your hand. if you cast both, combine their characteristics and mana costs into one spell, then follow the left half's instructions before the right half's instructions" { return Some(M::CastBothSplitHalvesFromHand); }
    if normalized == "as this creature enters, reveal any number of cards from your hand that share a creature type with it. this creature enters with a +1/+1 counter on it for each card revealed this way" { return Some(M::RevealSharedTypesForEntryCounters { amount: 1 }); }
    if normalized == "on a permanent, this ability means \"when this permanent is put into a graveyard from the battlefield, exile it haunting target creature.\" on an instant or sorcery spell, this ability means \"when this spell is put into a graveyard during its resolution, exile it haunting target creature.\"" { return Some(M::LinkOnGraveyardArrival); }
    if normalized == "for each phyrexian mana symbol paid with life, this planeswalker enters with two fewer loyalty counters" { return Some(M::EntryLoyaltyReductionPerLifePip); }
    if let Some(amount) = normalized.strip_prefix("players dealt combat damage by this creature also get ")
        .and_then(|s| s.strip_suffix(" poison counters"))
        .and_then(|s| s.parse::<u32>().ok())
    { return Some(M::CombatDamageAddsPoison { amount }); }
    // Read independent action clauses, then the named lasting result. No
    // mechanic name participates in recognition or in the resulting program.
    if let Some((condition, result)) = normalized.split_once(", you are in your ")
        && let Some(name) = result.strip_suffix(" for the rest of the game")
        && !name.is_empty() && !name.contains(' ')
        && let Some(clauses) = condition.strip_prefix("if you ")
        && let Some(requirements) = clauses.split(", ").map(crate::DesignationHistoryRequirement::read_clause).collect::<Option<Vec<_>>>()
        && !requirements.is_empty()
    {
        return Some(M::PermanentCountGrantsDesignation { minimum: 0, historic_only: false, enduring_story: false, tapped_only: false, named_designation: Some(name.into()), history_requirements: requirements });
    }
    if let Some(rest) = normalized.strip_prefix("if you control ") {
        if let Some((amount, rest)) = rest.split_once(" or more ") {
            let minimum = match amount { "one" => Some(1), "two" => Some(2), "three" => Some(3), "four" => Some(4), "five" => Some(5), "six" => Some(6), "seven" => Some(7), "eight" => Some(8), "nine" => Some(9), "ten" => Some(10), _ => amount.parse().ok() };
            for (filter, historic_only, tapped_only) in [("permanents", false, false), ("tapped permanents", false, true), ("artifacts, legendaries, and/or sagas", true, false)] {
                if let Some(result) = rest.strip_prefix(filter).and_then(|s| s.trim_start().strip_prefix(',')).map(str::trim_start) {
                    let named_designation = result.strip_prefix("you are in your ").and_then(|s| s.strip_suffix(" for the rest of the game")).filter(|s| !s.is_empty()).map(str::to_string);
                    let enduring_story = match result { "you get the city's blessing for the rest of the game" => Some(false), "you have an enduring story for the rest of the game" => Some(true), _ if named_designation.is_some() => Some(false), _ => None };
                    if let (Some(minimum), Some(enduring_story)) = (minimum, enduring_story) {
                        return Some(M::PermanentCountGrantsDesignation { minimum, historic_only, enduring_story, tapped_only, named_designation, history_requirements: Vec::new() });
                    }
                }
            }
        }
    }
    match normalized.as_str() {
        "each card you exile from your graveyard while casting this spell pays for {1}" => return Some(M::ExileGraveyardCardsForGenericMana),
        "each creature you tap while casting this spell pays for {1} or one mana of that creature's color" => return Some(M::TapCreaturesForMana),
        "each artifact you tap after you're done activating mana abilities pays for {1}" => return Some(M::TapArtifactsForGenericMana),

        "this creature can deal excess combat damage to the controller of the planeswalker it's attacking" => return Some(M::OverflowCombatDamage { through_planeswalkers: true }),
        "this creature can deal excess combat damage to the player or planeswalker it's attacking" => return Some(M::OverflowCombatDamage { through_planeswalkers: false }),

        "this permanent cannot be destroyed" => return Some(M::DestructionImmune),
        "this permanent can be attached while it's a creature" => return Some(M::AttachWhileCreature),
        "if enchanted creature would be destroyed, instead remove all damage from it and destroy this aura"
        | "if enchanted permanent would be destroyed, instead remove all damage from it and destroy this aura" => return Some(M::DestroyAttachmentInstead),
        "this phases in or out before you untap during each of your untap steps" => return Some(M::PhaseDuringUntap),
        "this deals damage to creatures in the form of -1/-1 counters" => return Some(M::DamageAsCounters { poison_players: false }),
        "this deals damage to creatures in the form of -1/-1 counters and to players in the form of poison counters" => return Some(M::DamageAsCounters { poison_players: true }),
        "any amount of damage this deals to a creature is enough to destroy it" => return Some(M::DamageIsLethalToCreatures),
        "damage dealt by this creature also causes you to gain that much life" => return Some(M::DamageGrantsControllerLife),
        "damage dealt to this creature also causes its controller to lose that much life" => return Some(M::DamageCausesRecipientControllerLifeLoss),
        "sunburst" => return Some(M::Sunburst),
        "compleated" => return Some(M::Compleated),
        "epic" => return Some(M::Epic),
        "paradigm" => return Some(M::Paradigm),
        "you may cast this spell any time you could cast an instant" => return Some(M::CastAtInstantTiming),
        "this creature deals combat damage before creatures without first strike" => return Some(M::EarlyCombatDamage { also_regular: false }),
        "this creature deals both first-strike and regular combat damage" => return Some(M::EarlyCombatDamage { also_regular: true }),
        "attacking doesn't cause this creature to tap" => {
            return Some(M::AttackingDoesNotCauseTap);
        }
        "this creature assigns combat damage as though its power were positive" => {
            return Some(M::AssignsCombatDamageAsThoughPowerPositive);
        }
        "this creature stations permanents using its toughness rather than its power" => {
            return Some(M::StationsUsingToughness);
        }
        "this creature crews vehicles using its toughness rather than its power" => {
            return Some(M::ContributesToughness { saddles: false });
        }
        "this creature saddles mounts and crews vehicles using its toughness rather than its power" => {
            return Some(M::ContributesToughness { saddles: true });
        }
        _ => {}
    }
    if normalized
        .starts_with("you may remove a loyalty counter from a planeswalker you control rather than pay ")
        && normalized.ends_with("'s crew cost")
    {
        return Some(M::LoyaltyCounterPaysCrewCost);
    }
    [
        ("this creature crews vehicles as though its power were ", false),
        ("this creature saddles mounts and crews vehicles as though its power were ", true),
        ("this token saddles mounts and crews vehicles as though its power were ", true),
    ]
    .into_iter()
    .find_map(|(prefix, saddles)| {
        let amount = normalized.strip_prefix(prefix)?.strip_suffix(" greater")?.parse().ok()?;
        Some(M::ContributesExtraPower { saddles, amount })
    })
}

/// What a conspiracy's draft-time rule does to the draft (CR 905):
/// whether the card is drafted face up or revealed, whether its drafter
/// notes who passed it, and how many colors players choose for it.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default, TagKeyWalk)]
pub struct DraftRule {
    /// "Draft this card face up."
    pub face_up: bool,
    /// "Reveal this card as you draft it ..."
    pub revealed: bool,
    /// "... and note the player who passed it to you" (Cogwork Tracker).
    pub notes_passing_player: bool,
    /// Colors chosen as it's drafted (Paliano, the High City: three).
    pub chosen_colors: u32,
    /// "You may draft an additional card from that booster pack. If you do,
    /// put this card into that booster pack." (Cogwork Librarian)
    pub exchange_pick: bool,
    /// The text says more than these fields model (Lore Seeker's added
    /// booster pack), so a reading of the fields is not the whole rule.
    pub unmodeled: bool,
}

/// Classify a conspiracy's draft-time rule text.
pub fn draft_rule(text: &str) -> DraftRule {
    let normalized = text.trim().trim_end_matches('.').to_ascii_lowercase();
    let chosen_colors = if normalized.contains("choose") {
        normalized
            .split(|c: char| !c.is_ascii_alphabetic())
            .filter(|word| *word == "color")
            .count() as u32
    } else {
        0
    };
    DraftRule {
        face_up: normalized == "draft this card face up",
        revealed: normalized.starts_with("reveal this card as you draft it"),
        notes_passing_player: normalized.contains("note the player who passed it to you"),
        chosen_colors,
        exchange_pick: normalized.contains("draft an additional card from that booster pack")
            && normalized.contains("put this card into that booster pack"),
        unmodeled: !normalized.split(". ").all(|sentence| {
            matches!(
                sentence,
                "draft this card face up"
                    | "reveal this card as you draft it"
                    | "reveal this card as you draft it and note the player who passed it to you"
                    | "the player to your right chooses a color, you choose another color, then the player to your left chooses a third color"
                    | "as you draft a card, you may draft an additional card from that booster pack"
                    | "if you do, put this card into that booster pack"
            )
        }),
    }
}

/// Timing of an action permission, independent of spell and activation timing.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, Copy, PartialEq, Eq, TagKeyWalk)]
pub enum ImmediateActionTiming { Priority, Sorcery, Attacking }

/// An atomic characteristic adjustment while a permanent becomes its new face.
/// Changing a counter kind neither removes nor places a counter.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub enum TransformCharacteristicAdjustment {
    CounterKind(crate::CounterType),
    ColorsFromNamedActivationPayment(String),
}

/// Multiplicity of one declared terminal continuation, local to a source
/// spell's successful disposition. The default preserves independent copies.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, Eq, Hash, Default, TagKeyWalk)]
pub enum SpellResolutionProgramMultiplicity {
    #[default]
    PerInstance,
    OncePerDeclaredKey { key: String },
}
impl SpellResolutionProgramMultiplicity {
    pub fn is_per_instance(&self) -> bool { matches!(self, Self::PerInstance) }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, Default, TagKeyWalk)]
pub enum StaticAbilityPayload<T, E, C, Cond, ICond = Condition> {
    #[default]
    None,
    /// Authored self-reference used to present an otherwise payloadless leaf
    /// static ability. Runtime semantics still come from `StaticAbility::id`.
    SelfSubjectSurface {
        surface: SourceReferenceSurface,
    },
    /// Presentation provenance for keyword abilities authored together on one
    /// source line. The following `keyword_count` keyword surfaces belong to
    /// one comma-separated Oracle line; this marker has no game semantics.
    SourceLineKeywordGroup {
        keyword_count: usize,
    },
    /// Presentation provenance for executable static abilities emitted from
    /// one authored source-line chunk. The following `member_count` abilities
    /// may be structurally recombined only when their typed payloads agree.
    SourceLineStaticGroup {
        member_count: usize,
    },
    /// Counters on the source survive a zone change unless the destination is
    /// one of the explicitly excluded zones. This is a property of the moving
    /// object, not a counter-placement replacement.
    CountersRemainAcrossZoneChanges {
        excluded_destinations: Vec<Zone>,
        display: String,
    },
    /// A priority special action available to any player. Paying `cost`
    /// causes only that player to ignore this source's applicable static
    /// restriction through the current turn boundary.
    AnyPlayerMayPayManaToIgnoreSourceEffectUntilEndOfTurn {
        cost: ManaCost,
        display: String,
    },
    /// The legend rule does not apply to matching permanents controlled by
    /// this ability's controller.  The filter is evaluated per candidate;
    /// unlike the legacy identifier alone, it does not exempt that player's
    /// unrelated legendary permanents.
    LegendRuleDoesntApplyToController {
        filter: ObjectFilter,
    },
    /// Matching permanents are goaded by this source's controller.
    GoadMatching {
        filter: ObjectFilter,
    },
    Companion(CompanionDeckCondition),
    Anthem(Anthem<ICond>),
    AttachedAbilityGrant(Box<AttachedAbilityGrant<T, E, C, Cond>>),
    AttachedChosenLandwalkGrant(AttachedChosenLandwalkGrant),
    /// Compiler-owned alternatives for independently removable printed text.
    OptionalTextFragments(Box<OptionalTextFragmentsSpec<T, E, C, Cond, ICond>>),
    Conditional {
        ability: Box<StaticAbility<T, E, C, Cond, ICond>>,
        condition: ICond,
        /// The condition and body are generated rules, not authored word occurrences.
        #[cfg_attr(feature = "serde", serde(default, skip_serializing_if = "static_implied_words_are_false"))]
        implied_words: bool,
    },
    GrantObjectAbilityForFilter(Box<GrantObjectAbilityForFilter<T, E, C, Cond, ICond>>),
    CopyActivatedAbilities(CopyActivatedAbilities),
    CopyStaticAbilityVariants(CopyStaticAbilityVariants),
    CopyTriggeredAbilities(CopyTriggeredAbilities),
    CostReduction(CostReduction<ICond>),
    CostReductionManaCost(CostReductionManaCost<ICond>),
    CostIncrease(CostIncrease<ICond>),
    /// "Spells your opponents cast that target this creature cost an
    /// additional 3 life to cast." (Terror of the Peaks)
    CostIncreaseLife {
        filter: ObjectFilter,
        amount: u32,
        display: String,
    },
    /// "You may activate abilities of creatures you control as though those
    /// creatures had haste." (Tyvar, Jubilant Brawler; Thousand-Year Elixir)
    ActivateAbilitiesAsThoughHaste {
        filter: ObjectFilter,
        display: String,
    },
    /// Timing permission for loyalty abilities of matching permanents.
    /// This does not change activation counts, costs, or who may activate them.
    LoyaltyAbilitiesAnyTime {
        filter: ObjectFilter,
    },
    CostIncreaseManaCost(CostIncreaseManaCost<ICond>),
    ThisSpellCostReduction(ThisSpellCostReduction<Cond>),
    ThisSpellCostReductionManaCost(ThisSpellCostReductionManaCost<Cond>),
    ThisSpellCastRestriction {
        kind: ThisSpellCastRestrictionKind,
        display: String,
    },
    ThisSpellXMaximum {
        maximum: Value,
        display: String,
        /// A text-defined X is an exact value, not merely an upper bound.
        #[cfg_attr(feature = "serde", serde(default, skip_serializing_if = "Option::is_none"))]
        definition: Option<Value>,
    },
    ThisSpellXMinimum {
        minimum: Value,
        display: String,
    },
    DieRollResultAdjustment(DieRollResultAdjustment),
    LevelAbility(Box<LevelAbilityModel<T, E, C, Cond>>),
    HexproofFrom(ObjectFilter),
    Protection(ProtectionFrom),
    PreventAllCombatDamageToPermanentsMatching(ObjectFilter),
    /// "Prevent all combat damage that would be dealt to and dealt by
    /// enchanted creature." (Ghostly Possession)
    PreventAllCombatDamageToAndByPermanentsMatching(ObjectFilter),
    PreventAllNoncombatDamageToPermanentsMatching(ObjectFilter),
    /// "Prevent all damage that would be dealt to attacking creatures you
    /// control." (Iroas, God of Victory)
    PreventAllDamageToPermanentsMatching(ObjectFilter),
    PreventAllDamageToSelfFromSourcesMatching(PreventAllDamageToSelfFromSourcesMatchingSpec),
    RuleRestriction {
        restriction: Restriction,
        additional_restrictions: Vec<Restriction>,
        display: String,
    },
    PregameAction {
        kind: PregameActionKind,
        text: String,
        effects: Vec<E>,
    },
    BandsWithOther(ObjectFilter),
    Dredge(u32),
    CounterLimit {
        counter_type: CounterType,
        maximum: u32,
        display: String,
    },
    Ward(TotalCost<C>),
    Morph(TotalCost<C>),
    Disguise(TotalCost<C>),
    Megamorph(TotalCost<C>),
    CanBlockAdditionalCreatureEachCombat(usize),
    CanBlockAsThoughReachForSubtype(Subtype),
    CanBlockAsThoughNoShadow,
    CanAttackPlayersWhoAttackedControllerLastTurnAsThoughNoDefender,
    TargetingAsThoughNoAbility(TargetingAsThoughNoAbilitySpec),
    CantBeBlockedByMoreThan(usize),
    CantBeBlockedExceptByNOrMore(usize),
    CantBeBlockedByPowerOrLess(i32),
    CantBeBlockedByPowerOrGreater(i32),
    CantBeBlockedAsLongAsDefendingPlayerControlsCardTypes(Vec<CardType>),
    CantAttackUnlessCondition {
        condition: CantAttackUnlessConditionSpec<ICond>,
        display: String,
    },
    /// A cost that must be paid for a matching creature to block a matching
    /// attacker. The total cost is locked from this payload when blockers are
    /// declared (CR 509.1d), rather than recomputed during payment.
    /// A cost imposed per matching attacker against this ability's controller.
    AttackCost {
        attackers: ObjectFilter,
        covers_planeswalkers: bool,
        cost: TotalCost<C>,
        display: String,
        /// "can't attack planeswalkers you control unless ..." (Onakke
        /// Oathkeeper): only attacks on the controller's planeswalkers are
        /// taxed, never attacks on the player (CR 508.1g-h).
        #[cfg_attr(feature = "serde", serde(default))]
        planeswalkers_only: bool,
    },
    BlockCost {
        blockers: ObjectFilter,
        blocker_is_attached_to_source: bool,
        attackers: ObjectFilter,
        cost: TotalCost<C>,
        display: String,
        /// "can't attack or block unless ...": the same cost is also due when
        /// the blocker-side creature attacks (CR 508.1d/h).
        #[cfg_attr(feature = "serde", serde(default))]
        also_attack_cost: bool,
        /// "can't attack unless ..." with no blocking half (Brainwash): only
        /// the attack-side cost exists; `blockers` names the attacker.
        #[cfg_attr(feature = "serde", serde(default))]
        attack_only: bool,
    },
    MayChooseNotToUntapDuringUntapStep(String),
    UntapDuringEachOtherPlayersUntapStep {
        filter: ObjectFilter,
        display: String,
        /// "during each opponent's untap step" (Teferi, Who Slows the
        /// Sunset's emblem): only opponents' untap steps, not teammates'.
        #[cfg_attr(feature = "serde", serde(default))]
        opponents_only: bool,
    },
    /// "Players can't untap more than one land during their untap steps."
    /// (Winter Orb): each affected player untaps at most `max` matching
    /// permanents during their untap step, choosing which.
    UntapStepLimit {
        player: PlayerFilter,
        filter: ObjectFilter,
        max: u32,
        display: String,
    },
    /// "each player chooses artifact, creature, or land during their untap
    /// step. That player can untap only permanents of the chosen type this
    /// step." (Storage Matrix, CR 502.3).
    UntapStepChosenCardTypeOnly {
        player: PlayerFilter,
        card_types: Vec<CardType>,
        display: String,
    },
    /// "If an opponent would search a library, that player searches the top
    /// four cards of that library instead." (Aven Mindcensor)
    SearchLimitedToTopCards {
        searcher: PlayerFilter,
        count: u32,
        display: String,
    },
    /// "Prevent all damage that would be dealt to you."
    PreventAllDamageToYou,
    /// "[You] have protection from [quality]" (Absolute Virtue, Serra's
    /// Emissary): CR 702.16b/c/e/j for a player.
    PlayerProtectionFrom {
        player: PlayerFilter,
        source_filter: ObjectFilter,
        display: String,
    },
    /// "While an opponent is choosing targets as part of casting a spell they
    /// control or activating an ability they control, that player must choose
    /// at least one Flagbearer on the battlefield if able."
    OpponentsMustTargetFlagbearers,
    FirstEquipCostAlternative(String),
    ControlAttachedPermanent(String),
    SetColors {
        filter: ObjectFilter,
        colors: ColorSet,
        /// This color definition does not contribute to Commander color identity.
        #[cfg_attr(feature = "serde", serde(default))]
        exclude_from_color_identity: bool,
    },
    AddColors {
        filter: ObjectFilter,
        colors: ColorSet,
    },
    SetName {
        filter: ObjectFilter,
        name: String,
    },
    CountAsCardNamedForSpellEffect {
        spell_name: String,
        counted_name: String,
    },
    AddSupertypes {
        filter: ObjectFilter,
        supertypes: Vec<Supertype>,
    },
    RemoveSupertypes {
        filter: ObjectFilter,
        supertypes: Vec<Supertype>,
    },
    MaxCreaturesCanAttackEachCombat(usize),
    MaxCreaturesCanAttackYouEachCombat(usize),
    MaxCreaturesCanBlockEachCombat(usize),
    /// "No more than N creatures can attack this planeswalker each combat."
    MaxCreaturesCanAttackSourceEachCombat(usize),
    /// "can block as though it were untapped" (CR 509.1a).
    CanBlockAsThoughUntapped,
    TriggerEventProjection { observed: TriggerProjectionEvent, sources: ObjectFilter, subjects: ObjectFilter, projected: TriggerProjectionEvent },
    /// Matching blockers ignore tapping only while blocking this source.
    CanBeBlockedAsThoughBlockersWereUntapped(ObjectFilter),
    AdditionalSpellTargets { filter: ObjectFilter, amount: u32 },
    /// Blocker-side landwalk permission (CR 702.14).
    CanBlockAsThoughNoLandwalk,
    ChooseBasicLandTypeAsEnters(String),
    ChooseLandTypeAsEnters(String),
    Enchant(crate::AuraAttachmentFilter),
    /// Cast timing permission requiring at least one matching chosen object target.
    FlashIfTargetsMatching(ObjectFilter),
    /// Cast timing permission requiring a casting decision (X, optional cost).
    FlashIfCastChoice(FlashCastChoice),
    EnchantedLandIsChosenType(String),
    /// "This land is the chosen type." (Multiversal Passage): the source land's
    /// subtypes become the basic land type chosen as it entered.
    SourceLandIsChosenType(String),
    AddChosenCreatureType {
        filter: ObjectFilter,
        display: String,
        /// "Creatures you control are the chosen type" (Conspiracy): the
        /// chosen type replaces their creature types instead of being added
        /// (CR 205.1a).
        #[cfg_attr(feature = "serde", serde(default))]
        replace_existing: bool,
    },
    AddChosenBasicLandType {
        filter: ObjectFilter,
        display: String,
    },
    /// The source has the abilities of the ability stickers on every object
    /// matching `filter` (Clandestine Chameleon).
    SourceHasAbilityStickerAbilitiesOf {
        filter: ObjectFilter,
        display: String,
    },
    AddChosenColor {
        filter: ObjectFilter,
        display: String,
    },
    SetChosenColor {
        filter: ObjectFilter,
        display: String,
    },
    SetMaximumHandSize {
        player: PlayerFilter,
        amount: u32,
    },
    ReduceMaximumHandSize {
        player: PlayerFilter,
        by: u32,
    },
    IncreaseMaximumHandSize {
        player: PlayerFilter,
        by: u32,
    },
    MaximumHandSizeSevenMinusYourGraveyardCardTypes {
        player: PlayerFilter,
        min_card_types: u32,
    },
    DuplicateMatchingTriggeredAbilities {
        source_filter: Option<ObjectFilter>,
        event_matcher: Option<T>,
        count: u32,
        display: String,
    },
    SuppressMatchingTriggeredAbilities {
        source_filter: Option<ObjectFilter>,
        event_matcher: Option<T>,
        display: String,
    },
    ExertAttack {
        only_if_not_exerted_this_turn: bool,
        linked_trigger: Option<TriggeredAbility<T, E, ICond>>,
        display: String,
    },
    EnlistAttack {
        linked_trigger: TriggeredAbility<T, E, ICond>,
        display: String,
    },
    EquipmentGrant(Vec<StaticAbility<T, E, C, Cond, ICond>>),
    SoulbondSharedPowerToughness {
        power: i32,
        toughness: i32,
    },
    SoulbondSharedAbility(Box<StaticAbility<T, E, C, Cond, ICond>>),
    SoulbondSharedObjectAbility(Box<AbilityModel<T, E, C, Cond, ICond>>),
    RemoveAbilityForFilter {
        filter: ObjectFilter,
        ability: Box<StaticAbility<T, E, C, Cond, ICond>>,
        mode: AbilityLossMode,
    },
    RemoveObjectAbilitiesForFilter {
        filter: ObjectFilter,
        abilities: Vec<AbilityModel<T, E, C, Cond>>,
        display: String,
        mode: AbilityLossMode,
    },
    RemoveAllAbilities(ObjectFilter),
    RemoveAllAbilitiesExceptMana(ObjectFilter),
    SetBasePowerToughness {
        filter: ObjectFilter,
        power: i32,
        toughness: i32,
    },
    SetBasePowerToughnessValue {
        filter: ObjectFilter,
        power: Value,
        toughness: Value,
    },
    SetBasePower {
        filter: ObjectFilter,
        power: i32,
    },
    /// Layer 7b base toughness only (Maha, Its Feathers Night).
    SetBaseToughness {
        filter: ObjectFilter,
        toughness: i32,
    },
    SourceCharacteristicsOfLastExiledCreatureCard {
        filter: ObjectFilter,
        retained_subtypes: Vec<Subtype>,
    },
    AddCardTypes {
        filter: ObjectFilter,
        card_types: Vec<CardType>,
    },
    RemoveCardTypes {
        filter: ObjectFilter,
        card_types: Vec<CardType>,
        condition: Option<ICond>,
    },
    SetCardTypes {
        filter: ObjectFilter,
        card_types: Vec<CardType>,
    },
    AddSubtypes {
        filter: ObjectFilter,
        subtypes: Vec<Subtype>,
    },
    AddAllSubtypesOfFamily {
        filter: ObjectFilter,
        family: SubtypeFamily,
    },
    SetLandSubtypes {
        filter: ObjectFilter,
        subtypes: Vec<Subtype>,
    },
    SetCreatureSubtypes {
        filter: ObjectFilter,
        subtypes: Vec<Subtype>,
    },
    MakeColorless(ObjectFilter),
    CostIncreasePerTargetBeyondFirst(u32),
    CostIncreaseManaCostPerTargetBeyondFirst(ManaCost),
    /// Mandatory nonmana cost paid once for every target announced for this
    /// spell (for example, "costs 3 life more to cast for each target").
    AdditionalLifeCostPerTarget(u32),
    /// Replaces the normal commander tax with a life payment for each prior
    /// cast of this commander from the command zone.
    CommanderTaxLifeSubstitution {
        life_per_previous_cast: u32,
    },
    MinimumSpellTotalMana(u32),
    /// "Buyback costs cost {N} less" (Memory Crystal): reduces the generic
    /// mana of a paid buyback cost, never below zero (CR 601.2f, 702.27).
    BuybackCostReduction(u32),
    PlayersSkipUpkeep {
        player: PlayerFilter,
    },
    PlayerSkipsDrawStep {
        player: PlayerFilter,
    },
    /// CR 502 / 614.1b: matching players skip their untap steps (Stasis).
    PlayersSkipUntapStep {
        player: PlayerFilter,
    },
    PlayersSkipExtraTurns {
        player: PlayerFilter,
    },
    ActivatedAbilityCostReduction {
        #[cfg_attr(feature = "serde", serde(default, skip_serializing_if = "static_implied_words_are_false"))]
        optional: bool,
        filter: ObjectFilter,
        reduction: u32,
        replacement_mana_cost: Option<ManaCost>,
        display: Option<String>,
        condition: Option<ActivatedAbilityCostCondition>,
        per_matching_objects: Option<ObjectFilter>,
        per_basic_land_types_among: Option<ObjectFilter>,
        #[cfg_attr(feature = "serde", serde(default))]
        multiplier: Option<Value>,
        minimum_total_mana: Option<u32>,
        /// "This ability costs {1}{U} less": the exact mana symbols removed
        /// from the bound ability's printed mana cost (CR 118.7). Lowering
        /// folds it into `replacement_mana_cost` once the ability is known.
        #[cfg_attr(feature = "serde", serde(default))]
        reduction_mana: Option<ManaCost>,
    },
    ActivatedAbilityCostIncrease {
        filter: ObjectFilter,
        increase: TotalCost<C>,
        activator: Option<PlayerFilter>,
        non_mana_only: bool,
        condition: Option<ICond>,
        #[cfg_attr(feature = "serde", serde(default))]
        ability_condition: Option<ActivatedAbilityCostCondition>,
        #[cfg_attr(feature = "serde", serde(default))]
        display: Option<String>,
    },
    ChooseColorAsEnters {
        excluded: Option<Color>,
        display: String,
        /// How many different colors are chosen ("choose two colors", Seal
        /// of the Guildpact); one for the ordinary "choose a color".
        #[cfg_attr(feature = "serde", serde(default = "crate::static_ability_model::one_chosen_color"))]
        count: u32,
    },
    ChoosePlayerAsEnters {
        filter: PlayerFilter,
        display: String,
        /// How many different players are chosen ("choose two players",
        /// Bitter Feud, Sower of Discord); one for "choose a player".
        #[cfg_attr(feature = "serde", serde(default = "crate::static_ability_model::one_chosen_color"))]
        count: u32,
    },
    NoteLifeTotalAsEnters(String),
    DiscardHandAsEnters(String),
    RevealFromHandAsEnters {
        filter: ObjectFilter,
        count: ChoiceCount,
        optional: bool,
        display: String,
    },
    ChooseCardNameAsEnters {
        display: String,
        reveal_opponents_hands: bool,
        require_nonland_from_revealed_opponents: bool,
        /// "you and an opponent each choose a card name" (Null Chamber): an
        /// opponent names a second card after you (CR 607.2b-style shared
        /// choice record). Appended with a serde default.
        #[cfg_attr(feature = "serde", serde(default))]
        opponent_also_chooses: bool,
        /// "other than a basic land card name".
        #[cfg_attr(feature = "serde", serde(default))]
        exclude_basic_land_names: bool,
    },
    ChooseCreatureTypeAsEnters(String),
    ChooseNamedOptionAsEnters {
        options: Vec<String>,
        display: String,
        /// "choose 2, 3, or 4 at random": the option is picked uniformly at
        /// random rather than by the controller.
        #[cfg_attr(feature = "serde", serde(default))]
        at_random: bool,
        /// "As this creature enters, each player chooses war or peace"
        /// (Archangel of Strife): every player makes the choice, in APNAP
        /// order, and each player's option is recorded on the permanent
        /// ("players who chose war"). Appended with a serde default.
        #[cfg_attr(feature = "serde", serde(default))]
        each_player: bool,
    },
    ChoosePowerToughnessAsEntersOrTurnsFaceUp {
        options: Vec<PowerToughnessChoiceOption<T, E, C, Cond, ICond>>,
        display: String,
        /// "As this creature enters, flip a coin. If the coin comes up heads,
        /// it enters as ...; if tails, ..." (Molten Sentry): no player
        /// chooses; the game's deterministic RNG picks one option uniformly.
        #[cfg_attr(feature = "serde", serde(default))]
        at_random: bool,
    },
    EnterAsCopyAsEnters {
        spec: EnterAsCopyAsEntersSpec<T, E, C, Cond, ICond>,
        display: String,
    },
    /// A structured resolution program performed as the source enters and/or
    /// is turned face up.
    ///
    /// Unlike an ordinary permanent spell effect, entry programs also apply
    /// when the card enters without being cast. `subject` retains only the
    /// authored self-kind (for example, "this Vehicle") for canonical
    /// rendering.
    /// An immediate program during casting, after the complete target proposal
    /// is validated and before the total price is locked. Its outputs belong to
    /// the proposed spell's transaction and are rolled back if casting fails.
    CastAnnouncementProgram {
        program: ResolutionProgram<E>,
    },
    AsEntersEffectProgram {
        program: ResolutionProgram<E>,
        subject: String,
        also_turns_face_up: bool,
        /// Suppress entry execution for an authored "As this is turned face
        /// up" program. Such programs also set `also_turns_face_up`.
        turns_face_up_only: bool,
        uses_enters_with_counter_surface: bool,
        /// When present, this is an immediate "as this transforms into ..."
        /// program rather than an entry replacement program. The legacy
        /// payload name is retained for serialized-model compatibility.
        transforms_into: Option<String>,
        #[cfg_attr(feature = "serde", serde(default, skip_serializing_if = "Option::is_none"))]
        transform_characteristics: Option<TransformCharacteristicAdjustment>,
        presentation_label: Option<PresentationLabel>,
        /// Authored as a self entry replacement: "If this land would enter,
        /// instead <program>, then put this land onto the battlefield"
        /// (Sheltered Valley). Same CR 614.1c/614.12 semantics as "As this
        /// enters"; only the rendered surface differs.
        #[cfg_attr(feature = "serde", serde(default))]
        entry_instead_surface: bool,
    },
    EntersWithCharacteristicsForFilter {
        #[cfg_attr(feature="serde", serde(default, skip_serializing_if="face_down_entry_is_false"))]
        face_down: bool,
        filter: ObjectFilter,
        card_types: Vec<CardType>,
        subtypes: Vec<Subtype>,
        power: i32,
        toughness: i32,
    },
    DoubleDamageFromSourcesYouControlOfChosenType(String),
    RedirectDamageToSourceController {
        source_filter: ObjectFilter,
        target_player_filter: PlayerFilter,
        display: String,
    },
    AdditionalLandPlays(u32),
    RevealFirstCardYouDrawEachTurn {
        optional: bool,
        your_turns_only: bool,
        /// Exact authored reveal/trigger group (CR 607.2f).
        #[cfg_attr(feature = "serde", serde(default, skip_serializing_if = "Option::is_none"))]
        linked_reveal_pair: Option<crate::LinkedExilePair>,
    },
    ExileToCounteredExileInsteadOfGraveyard {
        player: PlayerFilter,
        counter_type: CounterType,
    },
    ExileToExileInsteadOfGraveyard {
        filter: ObjectFilter,
        graveyard_owner: PlayerFilter,
        exclude_cycled: bool,
        /// The card has a linked ability using "cards exiled with" its
        /// source (CR 607.2a), so the replacement records that link.
        #[cfg_attr(feature = "serde", serde(default))]
        link_to_source: bool,
    },
    ExileWouldDieInstead {
        filter: ObjectFilter,
        damaged_by: Option<DamagedBySource>,
        #[cfg_attr(feature = "serde", serde(default))]
        damager_filter: Option<ObjectFilter>,
        #[cfg_attr(feature = "serde", serde(default))]
        damager_filter_surface: Option<String>,
        exile_with_counters: Vec<(CounterType, u32)>,
        follow_up_effects: Vec<E>,
    },
    /// "If this would be put into <to_zone> from anywhere, [reveal this and]
    /// shuffle it into its owner's library instead" when the wording is not
    /// the printed graveyard-and-reveal form (whose payload is `None`).
    ShuffleIntoOwnersLibraryInstead {
        to_zone: Zone,
        reveal: bool,
    },
    /// A removable static ability redirecting matching zone-change events.
    RedirectZoneChange {
        filter: ObjectFilter,
        from_zone: Option<Zone>,
        to_zone: Option<Zone>,
        destination: Zone,
    },
    ModifyDamageAmountReplacement {
        source_filter: ObjectFilter,
        target_player_filter: Option<PlayerFilter>,
        target_object_filter: Option<ObjectFilter>,
        delta: i32,
        /// When present, evaluated in the replacement source context at application.
        #[cfg_attr(
            feature = "serde",
            serde(default, skip_serializing_if = "Option::is_none")
        )]
        dynamic_delta: Option<Value>,
        noncombat_only: bool,
        display: String,
    },
    MinimumDamageAmountReplacement {
        source_filter: ObjectFilter,
        target_player_filter: Option<PlayerFilter>,
        target_object_filter: Option<ObjectFilter>,
        floor: Value,
        noncombat_only: bool,
        display: String,
    },
    DoubleDamageAmountReplacement {
        source_filter: ObjectFilter,
        target_player_filter: Option<PlayerFilter>,
        target_object_filter: Option<ObjectFilter>,
        factor: u32,
        combat_only: bool,
        #[cfg_attr(feature = "serde", serde(default))]
        noncombat_only: bool,
        display: String,
    },
    /// "If a source would deal damage to you or a permanent you control,
    /// prevent half that damage, rounded up." (Gisela, Blade of Goldnight)
    PreventHalfDamageReplacement {
        source_filter: ObjectFilter,
        target_player_filter: Option<PlayerFilter>,
        target_object_filter: Option<ObjectFilter>,
        round_up: bool,
        display: String,
    },
    DoubleCountersReplacement {
        filter: ObjectFilter,
        player_filter: Option<PlayerFilter>,
        counter_type: Option<CounterType>,
        /// Who must be putting the counters ("If you would put", "If an
        /// opponent would put"); `None` matches any actor.
        #[cfg_attr(feature = "serde", serde(default))]
        actor: Option<PlayerFilter>,
        /// With `player_filter` set, also match permanents matching `filter`
        /// ("on a permanent or player").
        #[cfg_attr(feature = "serde", serde(default))]
        includes_permanents: bool,
        /// "half that many ... rounded down" instead of "twice that many".
        #[cfg_attr(feature = "serde", serde(default))]
        halve: bool,
        /// "If an effect would put ..." (Doubling Season): counters put on
        /// as a cost or by a game rule aren't doubled (CR 614.1a rulings).
        #[cfg_attr(feature = "serde", serde(default))]
        effect_only: bool,
        display: String,
    },
    AddCountersPlacementReplacement {
        filter: ObjectFilter,
        player_filter: Option<PlayerFilter>,
        counter_type: Option<CounterType>,
        additional: i64,
        /// The cause the placement must come from ("if a modular triggered
        /// ability would put ..."); `None` for every cause.
        #[cfg_attr(feature = "serde", serde(default, skip_serializing_if = "Option::is_none"))]
        cause: Option<crate::CauseFilter>,
        display: String,
    },
    PlayerCounterPerTurnLimitReplacement {
        player_filter: PlayerFilter,
        counter_type: CounterType,
        maximum: u32,
        display: String,
    },
    DoubleTokenCreationReplacement {
        controller: PlayerFilter,
        display: String,
    },
    /// "three times that many of those tokens are created instead" (Ojer Taq,
    /// Deepest Foundation): a token-creation multiplier other than two.
    MultiplyTokenCreationReplacement {
        controller: PlayerFilter,
        token_filter: Option<ObjectFilter>,
        factor: u32,
        display: String,
    },
    AddTokenCreationReplacement {
        controller: PlayerFilter,
        token_filter: ObjectFilter,
        additional_token: AdditionalTokenKind,
        additional: i32,
        /// "those tokens plus that many 1/1 green Squirrel creature tokens":
        /// one additional token per token being created (Chatterfang).
        #[cfg_attr(feature = "serde", serde(default))]
        per_created: bool,
        display: String,
    },
    ConditionalSpellKeyword(ConditionalSpellKeywordSpec),
    Splice(SpliceSpec<C>),
    Escalate(EscalateSpec<C>),
    NamedActionReplacement {
        label: String,
        source_filter: ObjectFilter,
        performer_filter: Option<PlayerFilter>,
        #[cfg_attr(feature = "serde", serde(default, skip_serializing_if = "Option::is_none"))]
        object_requirement: Option<crate::filter_model::NamedActionObjectRequirement>,
        replacement_effects: Vec<E>,
        optional: bool,
        display: String,
    },
    KeywordActionReplacement {
        action: KeywordActionKind,
        source_filter: ObjectFilter,
        performer_filter: Option<PlayerFilter>,
        replacement_effects: Vec<E>,
        optional: bool,
        display: String,
    },
    ConditionalDrawReplacement {
        condition: ICond,
        replacement_effects: Vec<E>,
        optional: bool,
        display: String,
        /// "... except the first card you draw during each of your draw
        /// steps" (Reed Richards): that draw is never replaced.
        #[cfg_attr(feature = "serde", serde(default, skip_serializing_if = "static_implied_words_are_false"))]
        except_first_of_draw_step: bool,
    },
    /// "If you would draw one or more cards, you draw that many cards plus
    /// one instead." (Quantum Riddler). Applies once per draw instruction.
    /// "If you would create a Clue, Food, or Treasure token, instead create
    /// one of each." (Academy Manufactor)
    CreateOneOfEachTokenReplacement {
        kinds: Vec<AdditionalTokenKind>,
        display: String,
    },
    /// "If an opponent would draw a card except the first one they draw in
    /// each of their draw steps, instead that player skips that draw and you
    /// draw a card." (Notion Thief)
    RedirectDrawReplacement {
        drawer: PlayerFilter,
        except_first_of_draw_step: bool,
        display: String,
    },
    /// "If you would draw a card, instead <effects>." (Underrealm Lich)
    DrawReplacementWithEffects {
        drawer: PlayerFilter,
        /// "except the first one they draw in each of their draw steps"
        except_first_of_draw_step: bool,
        replacement_effects: Vec<E>,
        display: String,
        /// "If a cycling ability of <filter> would cause you to draw a card"
        /// (Unpredictable Cyclone): only draws proposed by a resolving
        /// cycling ability whose source matches are replaced.
        #[cfg_attr(feature = "serde", serde(default, skip_serializing_if = "Option::is_none"))]
        cycling_source: Option<ObjectFilter>,
    },
    DrawExtraCardsReplacement {
        extra: u32,
        /// "except the first one you draw in each of your draw steps"
        /// (Alhammarret's Archive, Teferi's Ageless Insight).
        #[cfg_attr(feature = "serde", serde(default))]
        except_first_of_draw_step: bool,
        /// "if you would draw one or more cards, ... that many plus one"
        /// applies once per draw instruction; "if you would draw a card, draw
        /// two cards instead" applies to every card drawn (CR 121.2).
        #[cfg_attr(feature = "serde", serde(default))]
        per_instruction: bool,
        display: String,
    },
    LoseGameReplacement {
        replacement_effects: Vec<E>,
        optional: bool,
        display: String,
    },
    DrawReplacementRevealTopMatchingToHandRestBottom {
        count: u32,
        filter: ObjectFilter,
        order: crate::LibraryBottomOrder,
        display: String,
    },
    CharacteristicDefiningPt {
        power: Value,
        toughness: Value,
    },
    DiscardOrRedirectReplacement {
        filter: ObjectFilter,
        redirect_zone: Zone,
    },
    SacrificeOrRedirectReplacement {
        filter: ObjectFilter,
        count: u32,
        redirect_zone: Zone,
    },
    PayLifeOrEnterTapped(u32),
    /// "As this land enters, you may reveal a Plains or Island card from
    /// your hand. If you don't, this land enters tapped." (SOI shadow lands,
    /// STX snarls). `subject` and `tail_subject` keep the authored noun
    /// phrases ("this land", "it") for rendering.
    RevealCardOrEnterTapped {
        filter: ObjectFilter,
        subject: String,
        tail_subject: String,
    },
    /// "If a nontoken creature would enter and it wasn't cast, exile it
    /// instead." (Containment Priest). A matching object that would enter the
    /// battlefield goes to `destination` instead; `not_cast` limits the gate to
    /// objects not entering from the stack.
    RedirectWouldEnter {
        filter: ObjectFilter,
        not_cast: bool,
        destination: Zone,
        display: String,
        /// With `not_cast`: a cast object also qualifies when no mana was
        /// spent to cast it ("if it wasn't cast or no mana was spent to cast
        /// it", Primeval Spawn).
        #[cfg_attr(feature = "serde", serde(default))]
        or_no_mana_spent: bool,
    },
    /// "If a land is tapped for two or more mana, it produces {C} instead of
    /// any other type and amount." (Damping Sphere). Mana a matching source is
    /// tapped for, when at least `minimum_amount` mana would be added, becomes
    /// exactly `replacement_mana`.
    ManaProductionReplacement {
        source_filter: ObjectFilter,
        minimum_amount: u32,
        replacement_mana: Vec<crate::ManaSymbol>,
        display: String,
    },
    /// "If you tap a permanent for mana, it produces three times as much of
    /// that mana instead." (Nyxbloom Ancient, Mana Reflection)
    ManaProductionMultiplierReplacement {
        source_filter: ObjectFilter,
        factor: u32,
        display: String,
    },
    /// "If you would gain life, you gain twice that much life instead." (Boon
    /// Reflection) / "If an opponent would lose life ..., they lose twice that
    /// much life instead." (Bloodletter of Aclazotz).
    DoubleLifeChangeReplacement {
        player: PlayerFilter,
        loss: bool,
        display: String,
    },
    ManaSpendPermission {
        permission: ManaSpendPermission,
        display: String,
    },
    Landwalk(LandwalkKind),
    Bloodthirst(u32),
    Tribute(u32),
    PreventDamageToSelfRemoveCounter {
        counter_type: CounterType,
        amount: Value,
        follow_up: Option<CounterRemovalFollowUp>,
        /// Each counter removed prevents one point of the incoming damage,
        /// rather than replacing the entire damage event.
        one_damage_per_counter: bool,
        surface: CounterRemovalPreventionSurface,
    },
    PreventDamageToSelfPutCountersInstead {
        counter_type: CounterType,
        display: String,
    },
    /// "If damage would be dealt to this creature, instead that damage is
    /// dealt, but all other damage already dealt to it is healed."
    HealDamageBeforeDamageToSelf {
        display: String,
    },
    PreventConstrainedDamageToSelfPutCountersInstead {
        counter_type: CounterType,
        display: String,
        source_filter: Option<ObjectFilter>,
        combat_only: Option<bool>,
    },
    PreventDamageToYouFromSourceFilter {
        amount: u32,
        source_filter: ObjectFilter,
        display: String,
    },
    /// Prevent matching damage and execute an additional effect using that event.
    DamagePreventionWithFollowUp {
        source_filter: ObjectFilter,
        target_filter: ObjectFilter,
        combat_only: Option<bool>,
        recipient_tag: crate::tag::TagKey,
        effects: Vec<E>,
    },
    ReplaceDamageWithCountersInstead {
        counter_type: CounterType,
        display: String,
        source_filter: ObjectFilter,
        target_filter: ObjectFilter,
        combat_only: Option<bool>,
    },
    CantAttackYouUnlessControllerPaysPerAttacker(u32),
    CantAttackYouOrPlaneswalkersUnlessControllerPaysPerAttacker(u32),
    CantAttackYouUnlessControllerPaysPerAttackerBasicLandTypesAmongLandsYouControl,
    Grants(Box<GrantSpecModel<T, E, C, Cond, ICond>>),
    NativeAlternativeCastFromZone {
        zone: Zone,
        method: crate::alternative_cast_model::AlternativeCastKeyword,
    },
    EntersTappedUnlessCondition {
        condition: ICond,
        display: String,
    },
    EntersWithCountersIfCondition {
        counter: CounterType,
        count: Value,
        condition: ICond,
        display: String,
        added_abilities: Vec<AbilityModel<T, E, C, Cond, ICond>>,
    },
    IntrinsicStartingCounters(IntrinsicStartingCounter),
    EntersWithCountersValue {
        counter: CounterType,
        count: Value,
    },
    EntersWithCounterChoice {
        counter_types: Vec<CounterType>,
        count: Value,
        /// "escapes with your choice of ..." (Tizerus Charger): the choice
        /// applies only when this entry condition holds.
        #[cfg_attr(feature = "serde", serde(default = "Option::default"))]
        condition: Option<ICond>,
        #[cfg_attr(feature = "serde", serde(default))]
        display: String,
        /// How many different kinds are chosen, each receiving `count`
        /// counters ("your choice of two different counters on it from
        /// among ...", Grimdancer). Ordinary single choices are 1. Appended
        /// last for serialized-field compatibility.
        #[cfg_attr(feature = "serde", serde(default = "one_counter_choice_kind"))]
        kinds: u32,
    },
    EntersTappedForFilter(ObjectFilter),
    EntersUntappedForFilter(ObjectFilter),
    EntersWithCountersAndSubtypesForFilter {
        filter: ObjectFilter,
        counter: CounterType,
        /// When present, use each distinct positive counter kind on these
        /// objects instead of the fixed counter kind.
        #[cfg_attr(feature = "serde", serde(default, skip_serializing_if = "Option::is_none"))]
        counter_kinds_from: Option<ChooseSpec>,
        count: Value,
        /// When present, `count` applies if this condition is true for the
        /// entering object and `otherwise_count` applies if it is false.
        count_condition: Option<Condition>,
        otherwise_count: Option<Value>,
        subtypes: Vec<Subtype>,
    },
    EntersUnderChosenControl(PlayerFilter),
    // Append new payloads so existing serialized variant positions stay stable.
    BlockingAsThoughNoLandwalk(BlockingAsThoughNoLandwalkSpec),
    CanBlockAdditionalForEach {
        additional: u32,
        filter: ObjectFilter,
    },
    PreventMatchingDamage(PreventMatchingDamageSpec),
    PreventMatchingDamageWithFollowUp(StaticDamagePreventionFollowUp<E>),
    AddLifeGainReplacement {
        player: PlayerFilter,
        additional: i32,
        display: String,
    },
    TokenCreationTemplates {
        controller: PlayerFilter,
        token_filter: ObjectFilter,
        templates: Vec<E>,
        mode: TokenCreationTemplateMode,
        choose_one: bool,
        optional: bool,
        display: String,
    },
    ActorCountersAddition {
        filter: ObjectFilter,
        player_filter: Option<PlayerFilter>,
        actor: PlayerFilter,
        counter_type: Option<CounterType>,
        additional: i64,
        display: String,
    },
    RedirectMatchingDamage(StaticDamageRedirectionSpec),
    NoMaximumHandSizeFor(PlayerFilter),
    MaximumHandSizeFromSourceCounters {
        player: PlayerFilter,
        counter_type: CounterType,
    },
    SpellManaSpendingRestriction(crate::mana::ManaSpendingRestriction),
    ManaProductionRewrite {
        rule: crate::mana::ManaOutputRewrite,
        display: String,
    },
    /// Replaces a numerical roll batch with extra dice, ignoring that many low rolls.
    ExtraDieIgnoreLowest {
        player: PlayerFilter,
        additional: u32,
    },
    ConvertUnspentMana {
        player: PlayerFilter,
        symbol: crate::mana::ManaSymbol,
    },
    /// Changes the hand-to-exile action, not the later spell's foretell cost.
    /// Appended to preserve published payload discriminants.
    ForetellSpecialActionModifier {
        generic_reduction: u32,
        any_players_turn: bool,
        /// The reduction applies only to the controller's first foretell
        /// special action each turn ("The first card you foretell each turn
        /// costs {0} to foretell", Ranar the Ever-Watchful).
        #[cfg_attr(feature = "serde", serde(default))]
        first_each_turn: bool,
        /// The reduction changes the plot special action (CR 702.170a)
        /// instead of the foretell one ("Plotting cards from your hand costs
        /// {2} less", Doc Aurlock). Older payloads mean foretell.
        #[cfg_attr(feature = "serde", serde(default))]
        plot: bool,
    },
    ExtraCoinIgnoreOne { player: PlayerFilter },
    FirstCoinBatchHeadsWin { player: PlayerFilter },
    /// Appended to preserve all previously published payload variant ordinals.
    /// This source's controller may inspect its exact linked exile members.
    /// Presence with no pair is explicitly unresolved, never source-wide.
    LookAtSourceExiledCards {
        pair: Option<crate::LinkedExilePair>,
        source: SourceReferenceSurface,
    },
    /// "If <event> would happen, <effects> instead." (Tainted Remedy, Lich,
    /// Delaying Shield): a replacement whose program runs in place of the
    /// event with the replaced event as context (CR 614.1a, 614.6).
    /// Appended to preserve published payload variant ordinals.
    EventReplacementWithEffects {
        event: crate::ReplacedEventSpec,
        replacement_effects: Vec<E>,
        display: String,
        /// "you may <program> instead": an optional replacement; declining
        /// it lets the event happen (CR 614.1a, 616.1).
        #[cfg_attr(feature = "serde", serde(default))]
        optional: bool,
    },
    /// "If an opponent would mill one or more cards, they mill twice that
    /// many cards instead." (Bruvac), "If a source would deal 4 or more
    /// damage to a permanent or player, that source deals 3 damage to that
    /// permanent or player instead." (Divine Presence): the watched event
    /// still happens with a modified amount (CR 614.1a, 616.1). `optional`
    /// reads "you may" ("You may look at an additional two cards each time
    /// you surveil"). Appended to preserve published payload variant ordinals.
    EventAmountReplacement {
        event: crate::AmountEventSpec,
        modifier: crate::AmountModifierSpec,
        optional: bool,
        display: String,
    },
    /// "You may pay {0} rather than pay the echo cost for permanents you
    /// control." (Thick-Skinned Goblin): an alternative price for the echo
    /// upkeep payment of a matching permanent (CR 118.9, 702.30a).
    /// Appended to preserve published payload variant ordinals.
    EchoCostAlternative {
        filter: ObjectFilter,
        replacement_mana_cost: ManaCost,
        display: String,
    },
    /// A keyword granted to matching spells as they are cast (CR 601.2b,
    /// 601.2f): "Each Sliver spell you cast has replicate. The replicate cost
    /// is equal to its mana cost." The engine discovers it while casting.
    /// Appended to preserve published payload variant ordinals.
    GrantSpellKeyword {
        filter: ObjectFilter,
        keyword: crate::GrantedSpellKeyword<C>,
        /// Authored "Each ..." subject surface; presentation only.
        #[cfg_attr(feature = "serde", serde(default))]
        set_quantifier_surface: Option<SetQuantifierSurface>,
    },    /// "You may cast creature spells from your graveyard using their sneak
    /// abilities." (Ninja Teen): matching cards may be cast from `zone` with
    /// their `method` alternative cost, printed or granted. Appended to
    /// preserve published payload variant ordinals.
    AlternativeCastFromZoneForFilter {
        filter: ObjectFilter,
        zone: Zone,
        method: crate::alternative_cast_model::AlternativeCastKeyword,
    },
    /// "If <trigger> attacks, <required> attack if able." (Viashino Bey,
    /// War's Toll, Magnetic Web): an attack requirement that exists only for
    /// declarations in which a creature matching `trigger` attacks
    /// (CR 508.1d). Both filters are read from this source's perspective.
    /// Appended to preserve published payload variant ordinals.
    ConditionalAttackRequirement {
        trigger: ObjectFilter,
        required: ObjectFilter,
    },
    /// "Enchanted creature is a copy of the chosen creature." (Metamorphic
    /// Alteration): a layer-1 copy effect (CR 707.2, 613.2a) on the object
    /// this source is attached to, using the copiable values of the object
    /// chosen as this source entered. Appended to preserve published payload
    /// variant ordinals.
    AttachedIsCopyOfChosenObject(String),
    /// Adds once to each color or color-combination devotion query.
    DevotionIncrease { amount: u32 },
    /// "If a spell or ability an opponent controls causes you to discard this
    /// card, put it onto the battlefield with two +1/+1 counters on it
    /// instead of putting it into your graveyard." (Dodecapod): the discard
    /// replacement of `OpponentEffectDiscardThisToBattlefieldReplacement`
    /// with entry counters. Appended to preserve published payload ordinals.
    OpponentDiscardThisToBattlefieldWithCounters { counter_type: CounterType, count: u32 },
    /// "All morph costs cost {2} more." (Exiled Doomsayer): every player's
    /// turn-face-up special action (CR 116.2b) paid with a morph or
    /// megamorph cost (CR 702.37) costs `generic_increase` more. Casting a
    /// spell face down is unaffected. Appended to preserve published payload
    /// ordinals.
    MorphCostIncrease { generic_increase: u32 },
    /// "Unlock costs you pay cost {1} less." (Inquisitive Glimmer): the
    /// controller's unlock-a-door special action (CR 709.5c) costs
    /// `generic_reduction` less generic mana. Appended to preserve published
    /// payload ordinals.
    UnlockCostReduction { generic_reduction: u32 },
    /// "As long as the top card of your graveyard is a creature card, this
    /// creature has the full text of that card and has the text "{2}:
    /// Discard a card."" (Volrath's Shapeshifter): while the top card of the
    /// controller's graveyard matches `filter`, a layer-1 effect (CR 613.2a)
    /// gives this permanent that card's full text, i.e. its copiable values
    /// (CR 707.2), plus `abilities` (labelled by `ability_labels`). The
    /// overwrite replaces this very static ability in the permanent's text
    /// but the effect keeps applying while the condition holds. Appended to
    /// preserve published payload variant ordinals.
    SourceHasFullTextOfTopGraveyardCard {
        filter: ObjectFilter,
        abilities: Vec<AbilityModel<T, E, C, Cond, ICond>>,
        ability_labels: Vec<String>,
        display: String,
    },
    /// "If you would begin your draw step, you may skip that step instead.
    /// If you do, you gain 2 life." (Fasting; CR 614.10): before the
    /// controller's draw step begins they may skip it; accepting runs
    /// `if_you_do` with this permanent as its source. Appended to preserve
    /// published payload variant ordinals.
    MaySkipDrawStepWithFollowup {
        if_you_do: Vec<E>,
        display: String,
    },
    /// A priority special action for the player `player` names (evaluated
    /// for this source): sacrificing a permanent of their choice causes that
    /// player to ignore this source's static restrictions until end of turn
    /// (Damping Engine). Appended to preserve published payload ordinals.
    PlayerMaySacrificePermanentToIgnoreSourceEffectUntilEndOfTurn {
        player: PlayerFilter,
        display: String,
    },
    /// "You can't choose an untapped creature as this spell's target as you
    /// cast it." (Enthralling Hold): while this spell's targets are announced
    /// (CR 601.2c), no object matching `forbidden` may be chosen. It is not a
    /// targeting requirement, so the resolution recheck (CR 608.2b) ignores
    /// it. Appended to preserve published payload variant ordinals.
    CastTargetRestriction {
        forbidden: ObjectFilter,
        display: String,
    },
    /// "As this Equipment enters, choose a creature you control it could be
    /// attached to. If you do, it enters attached to that creature."
    /// (Grifter's Blade): as this non-Aura enters, its controller chooses a
    /// battlefield object matching `filter` it could be attached to, and it
    /// enters attached to that object. Appended to preserve published
    /// payload variant ordinals.
    EntersAttachedToChosenObject {
        filter: ObjectFilter,
        display: String,
    },
    /// "Spells cost an additional \"Sacrifice a Swamp\" to cast for each
    /// black mana symbol in their mana costs." / "Activated abilities cost an
    /// additional ... to activate for each black mana symbol in their
    /// activation costs." (Drought): each `symbol` in the spell's mana cost
    /// (or the ability's activation cost) adds one sacrifice of a `sacrifice`
    /// permanent its payer controls to the total cost (CR 601.2f, 602.2b).
    /// Appended to preserve published payload variant ordinals.
    AdditionalSacrificePerManaSymbol {
        activated_abilities: bool,
        symbol: crate::mana::ManaSymbol,
        sacrifice: ObjectFilter,
        display: String,
    },
    /// "If a spell or ability you control would counter a spell, instead
    /// exile that spell and you may play that card without paying its mana
    /// cost." (Guile): every spell counter performed by a spell or ability
    /// this permanent's controller controls exiles the spell instead and
    /// grants `permission`. Appended to preserve published payload ordinals.
    ControllerCounterExilePermission {
        permission: crate::effect::CounterExilePermission,
        display: String,
    },
    /// "The attacking player chooses how each creature blocks each combat."
    /// (Invasion Plans): while this permanent is on the battlefield, the
    /// attacking (active) player makes every blocking declaration (CR 509.1).
    /// Appended to preserve published payload ordinals.
    AttackingPlayerChoosesBlocks {
        display: String,
    },
    /// "Its controller may exile three cards from their graveyard for that
    /// player to ignore this effect until end of turn." (Lost in Thought):
    /// a priority special action for the controller of the object this Aura
    /// is attached to; paying `cost` makes that player ignore this source's
    /// static restrictions until end of turn. Appended to preserve published
    /// payload ordinals.
    AttachedControllerMayPayCostToIgnoreSourceEffectUntilEndOfTurn {
        cost: TotalCost<C>,
        display: String,
    },
    /// "As this enchantment enters, choose two basic land types."
    /// (Illusionary Terrain): `count` distinct basic land types, recorded in
    /// choice order on the entering permanent. Appended to preserve published
    /// payload ordinals.
    ChooseBasicLandTypesAsEnters {
        display: String,
        count: u32,
    },
    /// "Basic lands of the first chosen type are the second chosen type."
    /// (Illusionary Terrain): objects matching `filter` that have the first
    /// chosen basic land type have their land types set to the second
    /// (CR 305.7). Appended to preserve published payload ordinals.
    FirstChosenLandTypeBecomesSecond {
        filter: ObjectFilter,
        display: String,
    },
    RevealCardsDrawn { player: PlayerFilter },
    /// Damage from one chosen player's source to a distinct chosen player or
    /// a permanent that player controls. Correlation is evaluated per event.
    DamageBetweenChosenPlayers { factor: u32, display: String },
    /// One grouped continuous rule spanning type and ability layers.
    AddSubtypesAndGrantAbilities {
        filter: ObjectFilter, subtypes: Vec<Subtype>,
        abilities: Vec<AbilityModel<T, E, C, Cond, ICond>>, display: String,
    },
    /// A planar roll batch gains one physical die; its roller chooses one
    /// result to ignore before any roll event or planar consequence occurs.
    ExtraPlanarDieIgnoreOne { player: PlayerFilter },
    /// Commander pairing (CR 702.124): plain partner, partner with a named
    /// card, a named partner group ("partner—survivors"), or "choose a
    /// Background". Typed so deck validation never reads ability text.
    /// Appended to preserve published payload discriminants.
    CommanderPairing {
        partner_with: Option<String>,
        group: Option<String>,
        choose_background: bool,
    },
    /// "A deck can have any number of / up to N cards named ~": the copy
    /// limit deck validation enforces (`None` = any number). Appended.
    DeckConstructionCopyLimit { maximum: Option<u32> },
    /// "As you create your deck, circle N of the colors below." Appended.
    DeckConstructionColorChoice { count: u32 },
    /// A keyword-marker line with an implemented mechanic. Appended.
    KeywordMarkerMechanic { mechanic: KeywordMarkerMechanic },
    /// Toxic N (CR 702.164). Appended.
    Toxic { amount: u32 },
    /// A conspiracy's draft-time rule. Appended.
    DraftRule { rule: DraftRule },
    /// "This creature attacks a player you noted for cards named <name>
    /// each combat if able" (Cogwork Tracker). Appended.
    MustAttackDraftNotedPlayers { card_name: String },
    /// Identity of a user-defined keyword. Its executable rules are separate
    /// abilities, not an alias for an official keyword with similar behavior.
    CustomKeywordIdentity { name: String },
    /// One ability-sticker row of an Unfinity sticker sheet (CR 123.7): the
    /// row's ticket cost (CR 107.17a, one per {TK} symbol) and the abilities
    /// the sticker gives the permanent it is put on. A sticker sheet is not a
    /// card (CR 123.2), so the row has no effect of its own. Appended.
    TicketAbilitySticker {
        tickets: u32,
        abilities: Vec<AbilityModel<T, E, C, Cond, ICond>>,
    },
    /// One power/toughness-sticker row of a sticker sheet (CR 123.8) and its
    /// ticket cost (CR 107.17a). Appended.
    TicketPowerToughnessSticker {
        tickets: u32,
        power: i32,
        toughness: i32,
    },
    /// A static permission to pay and execute instructions immediately,
    /// without an activated ability or a response window before instructions.
    IntrinsicImmediateAction {
        cost: TotalCost<C>,
        timing: ImmediateActionTiming,
        source_zone: Zone,
        player: PlayerFilter,
        condition: Option<ICond>,
        shared_turn_group: Option<String>,
        effects: Vec<E>,
        once: bool,
    },
    /// An ongoing layer-1 copy of the attachment itself, with an explicit
    /// exception retaining all three recipient type categories. Appended.
    AttachedIsCopyOfSource { retain_original_types: bool },
    /// Replace one occurrence of a matching optional cost, preserving its receipt identity.
    OptionalCostPaymentAlternative { filter: ObjectFilter, reference: crate::OptionalCostRef, replacement: TotalCost<C> },
    /// An independently offered alternative price of one resolving named operation.
    /// Copiable abilities added to original tokens created by a named operation.

    /// A source-wide payment substitution, applied to the final total cost.
    GenericManaTapPayment {
        spells: bool,
        activated_abilities: bool,
        exclude_source: bool,
        #[cfg_attr(feature = "serde", serde(default))]
        name: Option<String>,
        display: String,
    },
    /// A source cannot be tapped to pay a particular opaque named payment.
    GenericManaTapPaymentProhibition { name: String },
    NamedActionPaymentAlternative { label: String, player: PlayerFilter, effects: Vec<E>, display: String },
    NamedActionTokenAbilityGrant { label: String, player: PlayerFilter, abilities: Vec<AbilityModel<T, E, C, Cond, ICond>>, display: String },
    /// Activation-local permission. Does not change the object's actual zone
    /// or the instructions of the independently resolving ability.
    ActivateAbilitiesAsThoughZone {
        filter: ObjectFilter,
        designation: String,
        from: Zone,
        as_though: Zone,
        display: String,
    },
    /// A source-authored automatic player action. Multiple qualifying providers
    /// produce one completion for this player/instruction at this actual boundary.
    PhaseBoundaryPlayerAction { boundary: PlayerActionBoundary, label: String, condition: ICond },
    /// A replacement for the successfully resolving source spell's normal
    /// graveyard disposition. Equal destinations share one move. Independent
    /// instances retain their continuations unless an authored key explicitly
    /// declares that multiple instances of that one recipe are redundant.
    SpellResolutionDestinationProgram {
        origin_zone: Option<Zone>,
        destination: Zone,
        follow_up: ResolutionProgram<E>,
        #[cfg_attr(feature = "serde", serde(default, skip_serializing_if = "SpellResolutionProgramMultiplicity::is_per_instance"))]
        multiplicity: SpellResolutionProgramMultiplicity,
    },

    /// Source-authored shared selection rule. Matching only offers an
    /// externally invocable program; unselected programs never trigger.
    TriggerClassEventChoice {
        class: String,
        event: T,
        sources: Option<ObjectFilter>,
        include_event_source: bool,
        destination_subject: bool,
        maximum: u32,
        optional: bool,
        automatic: bool,
        /// Whether the observed event itself causes the selected program to
        /// trigger, rather than the selection invoking an eventless program.
        caused_by_event: bool,
    },
    /// Change any chosen subset of a placement's individual counters to
    /// controller-chosen kinds. Other counters retain their original kind.
    CounterKindReplacement {
        filter: ObjectFilter,
        cause: crate::CauseFilter,
        kinds: Vec<CounterType>,
        display: String,
    },
}

/// The printed ticket cost of a sticker-sheet row: one {TK} per ticket
/// (CR 107.17a).
pub fn ticket_cost_symbols(tickets: u32) -> String {
    "{TK}".repeat(tickets as usize)
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct DieRollResultAdjustment {
    pub player: PlayerFilter,
    pub life_cost: u32,
    pub mana_cost: Option<crate::mana::ManaCost>,
    pub amount: u32,
    pub reroll: bool,
    pub once_each_turn: bool,
    pub display: String,
    /// "you may remove a <kind> counter from this creature" (Xenosquirrels):
    /// the adjustment is paid by removing one such counter from the source
    /// instead of paying life.
    #[cfg_attr(feature = "serde", serde(default))]
    pub source_counter_cost: Option<CounterType>,
    /// "If you would roll one or more six-sided dice, instead roll them and
    /// you may exchange one result with this creature's base power or base
    /// toughness" (Vedalken Squirrel-Whacker): instead of +/- arithmetic, one
    /// retained result of each qualifying roll may be swapped with the
    /// source's base power or base toughness.
    #[cfg_attr(feature = "serde", serde(default))]
    pub exchange_with_source_base_pt: bool,
    /// Only rolls of dice with this many sides qualify.
    #[cfg_attr(feature = "serde", serde(default))]
    pub sides: Option<u32>,
}

impl<T, E, C, Cond, ICond> StaticAbility<T, E, C, Cond, ICond>
where
    C: Clone,
{
    pub fn trigger_class_event_choice(class: String, event: T, sources: Option<ObjectFilter>,
        include_event_source: bool, destination_subject: bool, maximum: u32, optional: bool, automatic: bool, caused_by_event: bool) -> Self {
        Self { id: None, label: format!("Select a {class} triggered program at the declared event"),
            payload: StaticAbilityPayload::TriggerClassEventChoice {class,event,sources,include_event_source,destination_subject,maximum,optional,automatic,caused_by_event} }
    }

    /// Translate a static ability from one phase's vocabulary into another's.
    ///
    /// `map_intervening` is where a linked trigger's recognized intervening-if
    /// predicate becomes a resolved condition.
    pub fn try_map<T2, E2, C2, ICond2, Err, FT, FE, FC, FI>(
        self,
        mut map_trigger: FT,
        mut map_effect: FE,
        mut map_cost: FC,
        mut map_intervening: FI,
    ) -> Result<StaticAbility<T2, E2, C2, Cond, ICond2>, Err>
    where
        E2: Clone,
        C2: CostComponent,
        FT: FnMut(T) -> Result<T2, Err>,
        FE: FnMut(E) -> Result<E2, Err>,
        FC: FnMut(C) -> Result<C2, Err>,
        FI: FnMut(ICond) -> Result<ICond2, Err>,
    {
        fn map_total_cost<C, C2, Err, FC>(
            cost: TotalCost<C>,
            map_cost: &mut FC,
        ) -> Result<TotalCost<C2>, Err>
        where
            C: Clone,
            FC: FnMut(C) -> Result<C2, Err>,
        {
            cost.try_map(map_cost)
        }

        fn map_triggered<T, E, IC, T2, E2, IC2, Err, FT, FE, FI>(
            triggered: TriggeredAbility<T, E, IC>,
            map_trigger: &mut FT,
            map_effect: &mut FE,
            map_intervening: &mut FI,
        ) -> Result<TriggeredAbility<T2, E2, IC2>, Err>
        where
            E2: Clone,
            FT: FnMut(T) -> Result<T2, Err>,
            FE: FnMut(E) -> Result<E2, Err>,
            FI: FnMut(IC) -> Result<IC2, Err>,
        {
            Ok(TriggeredAbility {
                trigger: map_trigger(triggered.trigger)?,
                effects: triggered.effects.try_map_effects(map_effect)?,
                choices: triggered.choices,
                intervening_if: triggered.intervening_if.map(map_intervening).transpose()?,
                presentation_label: triggered.presentation_label,
            })
        }

        fn map_activated<E, C, IC, E2, C2, IC2, Err, FE, FC, FI>(
            activated: ActivatedAbility<E, C, IC>,
            map_effect: &mut FE,
            map_cost: &mut FC,
            map_intervening: &mut FI,
        ) -> Result<ActivatedAbility<E2, C2, IC2>, Err>
        where
            C: Clone,
            E2: Clone,
            FE: FnMut(E) -> Result<E2, Err>,
            FC: FnMut(C) -> Result<C2, Err>,
            FI: FnMut(IC) -> Result<IC2, Err>,
        {
            Ok(ActivatedAbility {
                keyword: activated.keyword,
                mana_cost: map_total_cost(activated.mana_cost, map_cost)?,
                effects: activated.effects.try_map_effects(&mut *map_effect)?,
                choices: activated.choices,
                timing: activated.timing,
                additional_restrictions: activated.additional_restrictions,
                activation_restrictions: activated
                    .activation_restrictions
                    .into_iter()
                    .map(&mut *map_intervening)
                    .collect::<Result<Vec<_>, Err>>()?,
                mana_output: activated.mana_output,
                activation_condition: activated
                    .activation_condition
                    .map(&mut *map_intervening)
                    .transpose()?,
                mana_usage_restrictions: activated
                    .mana_usage_restrictions
                    .into_iter()
                    .map(|restriction| restriction.try_map_effects(&mut *map_effect))
                    .collect::<Result<Vec<_>, Err>>()?,
                is_loyalty_ability: activated.is_loyalty_ability,
            })
        }

        #[expect(
            clippy::type_complexity,
            reason = "the generic mapping boundary preserves every semantic model parameter"
        )]
        fn map_ability<T, E, C, Cond, IC, T2, E2, C2, IC2, Err, FT, FE, FC, FI>(
            ability: Ability<StaticAbility<T, E, C, Cond, IC>, T, E, C, IC>,
            map_trigger: &mut FT,
            map_effect: &mut FE,
            map_cost: &mut FC,
            map_intervening: &mut FI,
        ) -> Result<Ability<StaticAbility<T2, E2, C2, Cond, IC2>, T2, E2, C2, IC2>, Err>
        where
            C: Clone,
            E2: Clone,
            C2: CostComponent,
            FT: FnMut(T) -> Result<T2, Err>,
            FE: FnMut(E) -> Result<E2, Err>,
            FC: FnMut(C) -> Result<C2, Err>,
            FI: FnMut(IC) -> Result<IC2, Err>,
        {
            let kind = match ability.kind {
                AbilityKind::Static(static_ability) => AbilityKind::Static(map_static_ability(
                    static_ability,
                    map_trigger,
                    map_effect,
                    map_cost,
                    map_intervening,
                )?),
                AbilityKind::Triggered(triggered) => AbilityKind::Triggered(map_triggered(
                    triggered,
                    map_trigger,
                    map_effect,
                    map_intervening,
                )?),
                AbilityKind::Activated(activated) => AbilityKind::Activated(map_activated(
                    activated,
                    map_effect,
                    map_cost,
                    map_intervening,
                )?),
            };
            Ok(Ability {
                kind,
                designations: ability.designations.clone(),
                functional_zones: ability.functional_zones,
            })
        }

        fn map_alternative_cast<E, C, Cond, E2, C2, Err, FE, FC>(
            method: AlternativeCastingMethod<E, C, Cond>,
            map_effect: &mut FE,
            map_cost: &mut FC,
        ) -> Result<AlternativeCastingMethod<E2, C2, Cond>, Err>
        where
            C: Clone,
            E2: Clone,
            C2: CostComponent,
            FE: FnMut(E) -> Result<E2, Err>,
            FC: FnMut(C) -> Result<C2, Err>,
        {
            method.try_map(map_effect, map_cost)
        }

        fn map_derived_alternative_cast<C, C2, Err, FC>(
            spec: DerivedAlternativeCast<C>,
            map_cost: &mut FC,
        ) -> Result<DerivedAlternativeCast<C2>, Err>
        where
            C: Clone,
            FC: FnMut(C) -> Result<C2, Err>,
        {
            Ok(match spec {
                DerivedAlternativeCast::FlashbackFromCardManaCost { additional_costs } => {
                    let mut mapped = Vec::with_capacity(additional_costs.len());
                    for cost in additional_costs {
                        mapped.push(map_cost(cost)?);
                    }
                    DerivedAlternativeCast::FlashbackFromCardManaCost {
                        additional_costs: mapped,
                    }
                }
                DerivedAlternativeCast::EscapeFromCardManaCost { exile_count } => {
                    DerivedAlternativeCast::EscapeFromCardManaCost { exile_count }
                }
                DerivedAlternativeCast::RetraceFromCardManaCost => {
                    DerivedAlternativeCast::RetraceFromCardManaCost
                }
                DerivedAlternativeCast::BlitzFromCardManaCost => {
                    DerivedAlternativeCast::BlitzFromCardManaCost
                }
                DerivedAlternativeCast::EmergeFromCardManaCost => {
                    DerivedAlternativeCast::EmergeFromCardManaCost
                }
                DerivedAlternativeCast::MiracleFromCardManaCostReducedBy { reduction } => {
                    DerivedAlternativeCast::MiracleFromCardManaCostReducedBy { reduction }
                }
                DerivedAlternativeCast::ManaValueAsGenericFromHand => {
                    DerivedAlternativeCast::ManaValueAsGenericFromHand
                }
                DerivedAlternativeCast::MadnessFromCardManaCost => {
                    DerivedAlternativeCast::MadnessFromCardManaCost
                }
                DerivedAlternativeCast::ForetellFromCardManaCostReducedBy { reduction } => {
                    DerivedAlternativeCast::ForetellFromCardManaCostReducedBy { reduction }
                }
                DerivedAlternativeCast::PlotFromCardManaCost => {
                    DerivedAlternativeCast::PlotFromCardManaCost
                }
                DerivedAlternativeCast::ZoneCastFromCardManaCost {
                    zone,
                    additional_costs,
                } => {
                    let mut mapped = Vec::with_capacity(additional_costs.len());
                    for cost in additional_costs {
                        mapped.push(map_cost(cost)?);
                    }
                    DerivedAlternativeCast::ZoneCastFromCardManaCost {
                        zone,
                        additional_costs: mapped,
                    }
                }
                DerivedAlternativeCast::LifeEqualManaValueFromHand { usage_limit } => {
                    DerivedAlternativeCast::LifeEqualManaValueFromHand { usage_limit }
                }
                DerivedAlternativeCast::LifeEqualManaValueFromZone { zone, usage_limit } => {
                    DerivedAlternativeCast::LifeEqualManaValueFromZone { zone, usage_limit }
                }
                DerivedAlternativeCast::GraveyardCastFromCardManaCost {
                    additional_costs,
                    usage_limit,
                    condition,
                    exiles_after_resolution,
                } => {
                    let mut mapped = Vec::with_capacity(additional_costs.len());
                    for cost in additional_costs {
                        mapped.push(map_cost(cost)?);
                    }
                    DerivedAlternativeCast::GraveyardCastFromCardManaCost {
                        additional_costs: mapped,
                        usage_limit,
                        condition,
                        exiles_after_resolution,
                    }
                }
            })
        }

        #[expect(
            clippy::type_complexity,
            reason = "the generic mapping boundary preserves every semantic model parameter"
        )]
        fn map_grantable<T, E, C, Cond, IC, T2, E2, C2, IC2, Err, FT, FE, FC, FI>(
            grantable: Grantable<StaticAbility<T, E, C, Cond, IC>, E, C, Cond>,
            map_trigger: &mut FT,
            map_effect: &mut FE,
            map_cost: &mut FC,
            map_intervening: &mut FI,
        ) -> Result<Grantable<StaticAbility<T2, E2, C2, Cond, IC2>, E2, C2, Cond>, Err>
        where
            C: Clone,
            E2: Clone,
            C2: CostComponent,
            FT: FnMut(T) -> Result<T2, Err>,
            FE: FnMut(E) -> Result<E2, Err>,
            FC: FnMut(C) -> Result<C2, Err>,
            FI: FnMut(IC) -> Result<IC2, Err>,
        {
            Ok(match grantable {
                Grantable::Ability(static_ability) => Grantable::Ability(map_static_ability(
                    static_ability,
                    map_trigger,
                    map_effect,
                    map_cost,
                    map_intervening,
                )?),
                Grantable::AlternativeCast(method) => {
                    Grantable::AlternativeCast(map_alternative_cast(method, map_effect, map_cost)?)
                }
                Grantable::DerivedAlternativeCast(spec) => {
                    Grantable::DerivedAlternativeCast(map_derived_alternative_cast(spec, map_cost)?)
                }
                Grantable::PlayFrom => Grantable::PlayFrom,
                Grantable::AlternativePrice { costs, origin } => Grantable::AlternativePrice {
                    costs: costs
                        .into_iter()
                        .map(&mut *map_cost)
                        .collect::<Result<_, _>>()?,
                    origin,
                },
            })
        }

        #[expect(
            clippy::type_complexity,
            reason = "the generic mapping boundary preserves every semantic model parameter"
        )]
        fn map_grant_spec<T, E, C, Cond, IC, T2, E2, C2, IC2, Err, FT, FE, FC, FI>(
            spec: GrantSpec<StaticAbility<T, E, C, Cond, IC>, E, C, Cond>,
            map_trigger: &mut FT,
            map_effect: &mut FE,
            map_cost: &mut FC,
            map_intervening: &mut FI,
        ) -> Result<GrantSpec<StaticAbility<T2, E2, C2, Cond, IC2>, E2, C2, Cond>, Err>
        where
            C: Clone,
            E2: Clone,
            C2: CostComponent,
            FT: FnMut(T) -> Result<T2, Err>,
            FE: FnMut(E) -> Result<E2, Err>,
            FC: FnMut(C) -> Result<C2, Err>,
            FI: FnMut(IC) -> Result<IC2, Err>,
        {
            Ok(GrantSpec {
                grantable: map_grantable(
                    spec.grantable,
                    map_trigger,
                    map_effect,
                    map_cost,
                    map_intervening,
                )?,
                filter: spec.filter,
                zone: spec.zone,
                additional_zones: spec.additional_zones,
                beneficiary: spec.beneficiary,
                usage_limit: spec.usage_limit,
                max_plays: spec.max_plays,
                cast_this_way_filter: spec.cast_this_way_filter,
                on_use_effects: spec
                    .on_use_effects
                    .into_iter()
                    .map(&mut *map_effect)
                    .collect::<Result<_, _>>()?,
                requires_linked_exile_pair: spec.requires_linked_exile_pair,
                land_play_companion: spec.land_play_companion,
                may_look_at_linked_exile: spec.may_look_at_linked_exile,
            cast_mana_spend_mode: spec.cast_mana_spend_mode,
                linked_exile_pair: spec.linked_exile_pair,
                linked_exile_class_level: spec.linked_exile_class_level,
                source_exiled_surface: spec.source_exiled_surface,
                filtered_zone_surface: spec.filtered_zone_surface,
                top_card_only: spec.top_card_only,
                instant_timing: spec.instant_timing,
                may_look_at_top: spec.may_look_at_top,
                cast_this_way_grants: spec
                    .cast_this_way_grants
                    .into_iter()
                    .map(|ability| {
                        map_static_ability(
                            ability,
                            map_trigger,
                            map_effect,
                            map_cost,
                            map_intervening,
                        )
                    })
                    .collect::<Result<Vec<_>, _>>()?,
                permanent_this_way_grants: spec
                    .permanent_this_way_grants
                    .into_iter()
                    .map(|ability| {
                        map_static_ability(
                            ability,
                            map_trigger,
                            map_effect,
                            map_cost,
                            map_intervening,
                        )
                    })
                    .collect::<Result<Vec<_>, _>>()?,
            })
        }

        fn map_static_ability<T, E, C, Cond, IC, T2, E2, C2, IC2, Err, FT, FE, FC, FI>(
            ability: StaticAbility<T, E, C, Cond, IC>,
            map_trigger: &mut FT,
            map_effect: &mut FE,
            map_cost: &mut FC,
            map_intervening: &mut FI,
        ) -> Result<StaticAbility<T2, E2, C2, Cond, IC2>, Err>
        where
            C: Clone,
            E2: Clone,
            C2: CostComponent,
            FT: FnMut(T) -> Result<T2, Err>,
            FE: FnMut(E) -> Result<E2, Err>,
            FC: FnMut(C) -> Result<C2, Err>,
            FI: FnMut(IC) -> Result<IC2, Err>,
        {
            let payload = match ability.payload {
            StaticAbilityPayload::TriggerClassEventChoice { class, event, sources, include_event_source, destination_subject, maximum, optional, automatic, caused_by_event } => {
                StaticAbilityPayload::TriggerClassEventChoice {
                    class, event: map_trigger(event)?, sources, include_event_source, destination_subject, maximum, optional, automatic, caused_by_event,
                }
            }
            StaticAbilityPayload::IntrinsicImmediateAction { cost, timing, source_zone, player, condition, shared_turn_group, effects, once } => {
                StaticAbilityPayload::IntrinsicImmediateAction {
                    cost: map_total_cost(cost, map_cost)?, timing, source_zone, player, shared_turn_group, once,
                    condition: condition.map(&mut *map_intervening).transpose()?,
                    effects: effects.into_iter().map(&mut *map_effect).collect::<Result<Vec<_>, Err>>()?,
                }
            }
            StaticAbilityPayload::GenericManaTapPaymentProhibition { name } => StaticAbilityPayload::GenericManaTapPaymentProhibition { name },
            StaticAbilityPayload::GenericManaTapPayment { spells, activated_abilities, exclude_source, name, display } =>
                StaticAbilityPayload::GenericManaTapPayment { spells, activated_abilities, exclude_source, name, display },
            StaticAbilityPayload::CustomKeywordIdentity { name } => {
                StaticAbilityPayload::CustomKeywordIdentity { name }
            }
            StaticAbilityPayload::TicketAbilitySticker { tickets, abilities } => {
                StaticAbilityPayload::TicketAbilitySticker {
                    tickets,
                    abilities: abilities
                        .into_iter()
                        .map(|ability| {
                            map_ability(ability, map_trigger, map_effect, map_cost, map_intervening)
                        })
                        .collect::<Result<Vec<_>, _>>()?,
                }
            }
            StaticAbilityPayload::TicketPowerToughnessSticker {
                tickets,
                power,
                toughness,
            } => StaticAbilityPayload::TicketPowerToughnessSticker {
                tickets,
                power,
                toughness,
            },
            StaticAbilityPayload::None => StaticAbilityPayload::None,
            StaticAbilityPayload::SelfSubjectSurface { surface } => {
                StaticAbilityPayload::SelfSubjectSurface { surface }
            }
            StaticAbilityPayload::SourceLineKeywordGroup { keyword_count } => {
                StaticAbilityPayload::SourceLineKeywordGroup { keyword_count }
            }
            StaticAbilityPayload::SourceLineStaticGroup { member_count } => {
                StaticAbilityPayload::SourceLineStaticGroup { member_count }
            }
            StaticAbilityPayload::CountersRemainAcrossZoneChanges {
                excluded_destinations,
                display,
            } => StaticAbilityPayload::CountersRemainAcrossZoneChanges {
                excluded_destinations,
                display,
            },
            StaticAbilityPayload::AnyPlayerMayPayManaToIgnoreSourceEffectUntilEndOfTurn {
                cost,
                display,
            } => StaticAbilityPayload::AnyPlayerMayPayManaToIgnoreSourceEffectUntilEndOfTurn {
                cost,
                display,
            },
            StaticAbilityPayload::LegendRuleDoesntApplyToController { filter } => {
                StaticAbilityPayload::LegendRuleDoesntApplyToController { filter }
            }
            StaticAbilityPayload::GoadMatching { filter } => StaticAbilityPayload::GoadMatching { filter },
            StaticAbilityPayload::ConditionalAttackRequirement { trigger, required } => {
                StaticAbilityPayload::ConditionalAttackRequirement { trigger, required }
            }
            StaticAbilityPayload::Companion(condition) => {
                StaticAbilityPayload::Companion(condition)
            }
            StaticAbilityPayload::ConditionalSpellKeyword(spec) => {
                StaticAbilityPayload::ConditionalSpellKeyword(spec)
            }
            StaticAbilityPayload::Splice(spec) => StaticAbilityPayload::Splice(SpliceSpec {
                custom_keyword: spec.custom_keyword,
                source_zone: spec.source_zone,
                source_destination: spec.source_destination,
                max_per_spell: spec.max_per_spell,
                descriptive: spec.descriptive,
                quality: spec.quality,
                cost: spec.cost.try_map(&mut *map_cost)?,
                cost_surface: spec.cost_surface,
            }),
            StaticAbilityPayload::Escalate(spec) => {
                StaticAbilityPayload::Escalate(EscalateSpec {
                    descriptive: spec.descriptive,
                    cost: spec.cost.try_map(&mut *map_cost)?,
                    cost_surface: spec.cost_surface,
                })
            }
            StaticAbilityPayload::PlayersSkipUpkeep { player } => {
                StaticAbilityPayload::PlayersSkipUpkeep { player }
            }
            StaticAbilityPayload::PlayerSkipsDrawStep { player } => {
                StaticAbilityPayload::PlayerSkipsDrawStep { player }
            }
            StaticAbilityPayload::PlayersSkipUntapStep { player } => {
                StaticAbilityPayload::PlayersSkipUntapStep { player }
            }
            StaticAbilityPayload::LookAtSourceExiledCards { pair, source } => {
                StaticAbilityPayload::LookAtSourceExiledCards { pair, source }
            }
            StaticAbilityPayload::EventReplacementWithEffects {
                event,
                replacement_effects,
                display,
                optional,
            } => StaticAbilityPayload::EventReplacementWithEffects {
                event,
                replacement_effects: replacement_effects
                    .into_iter()
                    .map(&mut *map_effect)
                    .collect::<Result<Vec<_>, _>>()?,
                display,
                optional,
            },
            StaticAbilityPayload::EventAmountReplacement {
                event,
                modifier,
                optional,
                display,
            } => StaticAbilityPayload::EventAmountReplacement {
                event,
                modifier,
                optional,
                display,
            },
            StaticAbilityPayload::NamedActionPaymentAlternative { label, player, effects, display } => StaticAbilityPayload::NamedActionPaymentAlternative {
                label, player, display, effects: effects.into_iter().map(&mut *map_effect).collect::<Result<Vec<_>, _>>()?,
            },
            StaticAbilityPayload::NamedActionTokenAbilityGrant { label, player, abilities, display } => StaticAbilityPayload::NamedActionTokenAbilityGrant {
                label, player, display, abilities: abilities.into_iter().map(|ability| map_ability(ability, &mut *map_trigger, &mut *map_effect, &mut *map_cost, &mut *map_intervening)).collect::<Result<Vec<_>, _>>()?,
            },
            StaticAbilityPayload::ActivateAbilitiesAsThoughZone { filter, designation, from, as_though, display } =>
                StaticAbilityPayload::ActivateAbilitiesAsThoughZone { filter, designation, from, as_though, display },
            StaticAbilityPayload::OptionalCostPaymentAlternative {filter,reference,replacement} => StaticAbilityPayload::OptionalCostPaymentAlternative {
                filter, reference, replacement: replacement.try_map(&mut *map_cost)?,
            },
            StaticAbilityPayload::GrantSpellKeyword {
                filter,
                keyword,
                set_quantifier_surface,
            } => StaticAbilityPayload::GrantSpellKeyword {
                filter,
                keyword: keyword.try_map(&mut *map_cost)?,
                set_quantifier_surface,
            },
            StaticAbilityPayload::AlternativeCastFromZoneForFilter {
                filter,
                zone,
                method,
            } => StaticAbilityPayload::AlternativeCastFromZoneForFilter {
                filter,
                zone,
                method,
            },
            StaticAbilityPayload::PlayersSkipExtraTurns { player } => {
                StaticAbilityPayload::PlayersSkipExtraTurns { player }
            }
            StaticAbilityPayload::Anthem(anthem) => {
                StaticAbilityPayload::Anthem(anthem.try_map_condition(&mut *map_intervening)?)
            }
            StaticAbilityPayload::AttachedAbilityGrant(grant) => {
                let grant = *grant;
                StaticAbilityPayload::AttachedAbilityGrant(Box::new(AttachedAbilityGrant {
                    ability: map_ability(
                        grant.ability,
                        map_trigger,
                        map_effect,
                        map_cost,
                        &mut Ok,
                    )?,
                    additional_abilities: grant
                        .additional_abilities
                        .into_iter()
                        .map(|ability| map_ability(ability, map_trigger, map_effect, map_cost, &mut Ok))
                        .collect::<Result<Vec<_>, _>>()?,
                    display: grant.display,
                    condition: grant.condition,
                    protection_does_not_remove_controlled_attachments: grant
                        .protection_does_not_remove_controlled_attachments,
                }))
            }
            StaticAbilityPayload::AttachedChosenLandwalkGrant(grant) => {
                StaticAbilityPayload::AttachedChosenLandwalkGrant(grant)
            }
            StaticAbilityPayload::OptionalTextFragments(spec) => {
                let spec=*spec;
                let mut variants=Vec::with_capacity(spec.variants.len());
                for variant in spec.variants {
                    let mut abilities=Vec::with_capacity(variant.abilities.len());
                    for ability in variant.abilities {abilities.push(map_ability(ability,&mut *map_trigger,&mut *map_effect,&mut *map_cost,&mut *map_intervening)?);}
                    variants.push(OptionalTextFragmentVariant {
                        removed: variant.removed, abilities, ability_labels: variant.ability_labels,
                        spell_effect: variant.spell_effect.map(|program|program.try_map_effects(&mut *map_effect)).transpose()?,
                        aura_attach_filter: variant.aura_attach_filter, canonical_text: variant.canonical_text,
                    });
                }
                StaticAbilityPayload::OptionalTextFragments(Box::new(OptionalTextFragmentsSpec {
                    labels: spec.labels, variants, invariant_slots: spec.invariant_slots,
                    current_removed: spec.current_removed, casting_payment: spec.casting_payment,
                }))
            }
            StaticAbilityPayload::Conditional { ability, condition, implied_words } => {
                StaticAbilityPayload::Conditional {
                    implied_words,
                    ability: Box::new(map_static_ability(
                        *ability,
                        map_trigger,
                        map_effect,
                        map_cost,
                        map_intervening,
                    )?),
                    condition: map_intervening(condition)?,
                }
            }
            StaticAbilityPayload::GrantObjectAbilityForFilter(grant) => {
                let grant = *grant;
                StaticAbilityPayload::GrantObjectAbilityForFilter(Box::new(
                    GrantObjectAbilityForFilter {
                        filter: grant.filter,
                        ability: map_ability(
                            grant.ability,
                            map_trigger,
                            map_effect,
                            map_cost,
                            map_intervening,
                        )?,
                        additional_abilities: grant
                            .additional_abilities
                            .into_iter()
                            .map(|ability| {
                                map_ability(
                                    ability,
                                    map_trigger,
                                    map_effect,
                                    map_cost,
                                    map_intervening,
                                )
                            })
                            .collect::<Result<Vec<_>, _>>()?,
                        display: grant.display,
                        condition: grant.condition.map(&mut *map_intervening).transpose()?,
                        set_quantifier_surface: grant.set_quantifier_surface,
                        derived_ability_display: grant.derived_ability_display,
                    },
                ))
            }
            StaticAbilityPayload::CopyActivatedAbilities(copy) => {
                StaticAbilityPayload::CopyActivatedAbilities(copy)
            }
            StaticAbilityPayload::CopyStaticAbilityVariants(copy) => {
                StaticAbilityPayload::CopyStaticAbilityVariants(copy)
            }
            StaticAbilityPayload::CopyTriggeredAbilities(copy) => {
                StaticAbilityPayload::CopyTriggeredAbilities(copy)
            }
            StaticAbilityPayload::CostReduction(reduction) => StaticAbilityPayload::CostReduction(
                reduction.try_map_condition(&mut *map_intervening)?,
            ),
            StaticAbilityPayload::CostReductionManaCost(reduction) => StaticAbilityPayload::CostReductionManaCost(
                reduction.try_map_condition(&mut *map_intervening)?,
            ),
            StaticAbilityPayload::CostIncrease(increase) => StaticAbilityPayload::CostIncrease(
                increase.try_map_condition(&mut *map_intervening)?,
            ),
            StaticAbilityPayload::CostIncreaseLife {
                filter,
                amount,
                display,
            } => StaticAbilityPayload::CostIncreaseLife {
                filter,
                amount,
                display,
            },
            StaticAbilityPayload::ActivateAbilitiesAsThoughHaste { filter, display } => {
                StaticAbilityPayload::ActivateAbilitiesAsThoughHaste { filter, display }
            }
            StaticAbilityPayload::LoyaltyAbilitiesAnyTime { filter } => {
                StaticAbilityPayload::LoyaltyAbilitiesAnyTime { filter }
            }
            StaticAbilityPayload::CostIncreaseManaCost(increase) => StaticAbilityPayload::CostIncreaseManaCost(
                increase.try_map_condition(&mut *map_intervening)?,
            ),
            StaticAbilityPayload::ThisSpellCostReduction(reduction) => {
                StaticAbilityPayload::ThisSpellCostReduction(reduction)
            }
            StaticAbilityPayload::ThisSpellCostReductionManaCost(reduction) => {
                StaticAbilityPayload::ThisSpellCostReductionManaCost(reduction)
            }
            StaticAbilityPayload::ThisSpellCastRestriction { kind, display } => {
                StaticAbilityPayload::ThisSpellCastRestriction { kind, display }
            }
            StaticAbilityPayload::ThisSpellXMaximum { maximum, display, definition } => {
                StaticAbilityPayload::ThisSpellXMaximum { maximum, display, definition }
            }
            StaticAbilityPayload::ThisSpellXMinimum { minimum, display } => {
                StaticAbilityPayload::ThisSpellXMinimum { minimum, display }
            }
            StaticAbilityPayload::DieRollResultAdjustment(spec) => {
                StaticAbilityPayload::DieRollResultAdjustment(spec)
            }
            StaticAbilityPayload::ExtraCoinIgnoreOne { player } => StaticAbilityPayload::ExtraCoinIgnoreOne { player },
            StaticAbilityPayload::FirstCoinBatchHeadsWin { player } => StaticAbilityPayload::FirstCoinBatchHeadsWin { player },
            StaticAbilityPayload::ExtraDieIgnoreLowest { player, additional } => {
                StaticAbilityPayload::ExtraDieIgnoreLowest { player, additional }
            }
            StaticAbilityPayload::ExtraPlanarDieIgnoreOne { player } => {
                StaticAbilityPayload::ExtraPlanarDieIgnoreOne { player }
            }
            StaticAbilityPayload::CommanderPairing {
                partner_with,
                group,
                choose_background,
            } => StaticAbilityPayload::CommanderPairing {
                partner_with,
                group,
                choose_background,
            },
            StaticAbilityPayload::DeckConstructionCopyLimit { maximum } => {
                StaticAbilityPayload::DeckConstructionCopyLimit { maximum }
            }
            StaticAbilityPayload::DeckConstructionColorChoice { count } => {
                StaticAbilityPayload::DeckConstructionColorChoice { count }
            }
            StaticAbilityPayload::KeywordMarkerMechanic { mechanic } => {
                StaticAbilityPayload::KeywordMarkerMechanic { mechanic }
            }
            StaticAbilityPayload::Toxic { amount } => StaticAbilityPayload::Toxic { amount },
            StaticAbilityPayload::DraftRule { rule } => StaticAbilityPayload::DraftRule { rule },
            StaticAbilityPayload::MustAttackDraftNotedPlayers { card_name } => {
                StaticAbilityPayload::MustAttackDraftNotedPlayers { card_name }
            }
            StaticAbilityPayload::LevelAbility(level) => {
                let level = *level;
                let mut abilities = Vec::with_capacity(level.abilities.len());
                for ability in level.abilities {
                    abilities.push(map_static_ability(
                        ability,
                        map_trigger,
                        map_effect,
                        map_cost,
                        &mut Ok,
                    )?);
                }
                StaticAbilityPayload::LevelAbility(Box::new(crate::LevelAbility {
                    min_level: level.min_level,
                    max_level: level.max_level,
                    power_toughness: level.power_toughness,
                    abilities,
                }))
            }
            StaticAbilityPayload::HexproofFrom(filter) => StaticAbilityPayload::HexproofFrom(filter),
            StaticAbilityPayload::Protection(from) => StaticAbilityPayload::Protection(from),
            StaticAbilityPayload::PreventAllCombatDamageToPermanentsMatching(filter) => {
                StaticAbilityPayload::PreventAllCombatDamageToPermanentsMatching(filter)
            }
            StaticAbilityPayload::PreventAllCombatDamageToAndByPermanentsMatching(filter) => {
                StaticAbilityPayload::PreventAllCombatDamageToAndByPermanentsMatching(filter)
            }
            StaticAbilityPayload::PreventAllDamageToPermanentsMatching(filter) => {
                StaticAbilityPayload::PreventAllDamageToPermanentsMatching(filter)
            }
            StaticAbilityPayload::PreventAllNoncombatDamageToPermanentsMatching(filter) => {
                StaticAbilityPayload::PreventAllNoncombatDamageToPermanentsMatching(filter)
            }
            StaticAbilityPayload::PreventAllDamageToSelfFromSourcesMatching(spec) => {
                StaticAbilityPayload::PreventAllDamageToSelfFromSourcesMatching(spec)
            }
            StaticAbilityPayload::RuleRestriction {
                restriction,
                additional_restrictions,
                display,
            } => StaticAbilityPayload::RuleRestriction {
                restriction,
                additional_restrictions,
                display,
            },
            StaticAbilityPayload::PregameAction {
                kind,
                text,
                effects,
            } => {
                let mut mapped_effects = Vec::with_capacity(effects.len());
                for effect in effects {
                    mapped_effects.push(map_effect(effect)?);
                }
                StaticAbilityPayload::PregameAction {
                    kind,
                    text,
                    effects: mapped_effects,
                }
            }
            StaticAbilityPayload::BandsWithOther(filter) => {
                StaticAbilityPayload::BandsWithOther(filter)
            }
            StaticAbilityPayload::Dredge(amount) => StaticAbilityPayload::Dredge(amount),
            StaticAbilityPayload::CounterLimit {
                counter_type,
                maximum,
                display,
            } => StaticAbilityPayload::CounterLimit {
                counter_type,
                maximum,
                display,
            },
            StaticAbilityPayload::Ward(cost) => {
                StaticAbilityPayload::Ward(map_total_cost(cost, map_cost)?)
            }
            StaticAbilityPayload::Morph(cost) => {
                StaticAbilityPayload::Morph(map_total_cost(cost, map_cost)?)
            }
            StaticAbilityPayload::Disguise(cost) => {
                StaticAbilityPayload::Disguise(map_total_cost(cost, map_cost)?)
            }
            StaticAbilityPayload::Megamorph(cost) => {
                StaticAbilityPayload::Megamorph(map_total_cost(cost, map_cost)?)
            }
            StaticAbilityPayload::CanBlockAdditionalCreatureEachCombat(count) => {
                StaticAbilityPayload::CanBlockAdditionalCreatureEachCombat(count)
            }
            StaticAbilityPayload::CanBlockAdditionalForEach { additional, filter } => {
                StaticAbilityPayload::CanBlockAdditionalForEach { additional, filter }
            }
            StaticAbilityPayload::CanBlockAsThoughReachForSubtype(subtype) => {
                StaticAbilityPayload::CanBlockAsThoughReachForSubtype(subtype)
            }
            StaticAbilityPayload::CanBlockAsThoughNoShadow => {
                StaticAbilityPayload::CanBlockAsThoughNoShadow
            }
            StaticAbilityPayload::CanAttackPlayersWhoAttackedControllerLastTurnAsThoughNoDefender => {
                StaticAbilityPayload::CanAttackPlayersWhoAttackedControllerLastTurnAsThoughNoDefender
            }
            StaticAbilityPayload::TargetingAsThoughNoAbility(spec) => {
                StaticAbilityPayload::TargetingAsThoughNoAbility(spec)
            }
            StaticAbilityPayload::BlockingAsThoughNoLandwalk(spec) => {
                StaticAbilityPayload::BlockingAsThoughNoLandwalk(spec)
            }
            StaticAbilityPayload::CantBeBlockedByMoreThan(count) => {
                StaticAbilityPayload::CantBeBlockedByMoreThan(count)
            }
            StaticAbilityPayload::CantBeBlockedExceptByNOrMore(count) => {
                StaticAbilityPayload::CantBeBlockedExceptByNOrMore(count)
            }
            StaticAbilityPayload::CantBeBlockedByPowerOrLess(power) => {
                StaticAbilityPayload::CantBeBlockedByPowerOrLess(power)
            }
            StaticAbilityPayload::CantBeBlockedByPowerOrGreater(power) => {
                StaticAbilityPayload::CantBeBlockedByPowerOrGreater(power)
            }
            StaticAbilityPayload::CantBeBlockedAsLongAsDefendingPlayerControlsCardTypes(
                card_types,
            ) => StaticAbilityPayload::CantBeBlockedAsLongAsDefendingPlayerControlsCardTypes(
                card_types,
            ),
            StaticAbilityPayload::CantAttackUnlessCondition { condition, display } => {
                StaticAbilityPayload::CantAttackUnlessCondition {
                    condition: condition.try_map_condition(&mut *map_intervening)?,
                    display,
                }
            }
            StaticAbilityPayload::AttackCost {
                attackers,
                covers_planeswalkers,
                cost,
                display,
                planeswalkers_only,
            } => StaticAbilityPayload::AttackCost {
                attackers,
                covers_planeswalkers,
                cost: map_total_cost(cost, map_cost)?,
                display,
                planeswalkers_only,
            },
            StaticAbilityPayload::BlockCost {
                blockers,
                blocker_is_attached_to_source,
                attackers,
                cost,
                display,
                also_attack_cost,
                attack_only,
            } => StaticAbilityPayload::BlockCost {
                blockers,
                blocker_is_attached_to_source,
                attackers,
                cost: map_total_cost(cost, map_cost)?,
                display,
                also_attack_cost,
                attack_only,
            },
            StaticAbilityPayload::MayChooseNotToUntapDuringUntapStep(subject) => {
                StaticAbilityPayload::MayChooseNotToUntapDuringUntapStep(subject)
            }
            StaticAbilityPayload::UntapStepLimit {
                player,
                filter,
                max,
                display,
            } => StaticAbilityPayload::UntapStepLimit {
                player,
                filter,
                max,
                display,
            },
            StaticAbilityPayload::UntapStepChosenCardTypeOnly {
                player,
                card_types,
                display,
            } => StaticAbilityPayload::UntapStepChosenCardTypeOnly {
                player,
                card_types,
                display,
            },
            StaticAbilityPayload::SearchLimitedToTopCards {
                searcher,
                count,
                display,
            } => StaticAbilityPayload::SearchLimitedToTopCards {
                searcher,
                count,
                display,
            },
            StaticAbilityPayload::PreventAllDamageToYou => StaticAbilityPayload::PreventAllDamageToYou,
            StaticAbilityPayload::PlayerProtectionFrom {
                player,
                source_filter,
                display,
            } => StaticAbilityPayload::PlayerProtectionFrom {
                player,
                source_filter,
                display,
            },
            StaticAbilityPayload::OpponentsMustTargetFlagbearers => {
                StaticAbilityPayload::OpponentsMustTargetFlagbearers
            }
            StaticAbilityPayload::UntapDuringEachOtherPlayersUntapStep { filter, display, opponents_only } => {
                StaticAbilityPayload::UntapDuringEachOtherPlayersUntapStep { filter, display, opponents_only }
            }
            StaticAbilityPayload::FirstEquipCostAlternative(display) => {
                StaticAbilityPayload::FirstEquipCostAlternative(display)
            }
            StaticAbilityPayload::EchoCostAlternative {
                filter,
                replacement_mana_cost,
                display,
            } => StaticAbilityPayload::EchoCostAlternative {
                filter,
                replacement_mana_cost,
                display,
            },
            StaticAbilityPayload::ControlAttachedPermanent(display) => {
                StaticAbilityPayload::ControlAttachedPermanent(display)
            }
            StaticAbilityPayload::SetColors { filter, colors, exclude_from_color_identity } => {
                StaticAbilityPayload::SetColors { filter, colors, exclude_from_color_identity }
            }
            StaticAbilityPayload::AddColors { filter, colors } => {
                StaticAbilityPayload::AddColors { filter, colors }
            }
            StaticAbilityPayload::SetName { filter, name } => {
                StaticAbilityPayload::SetName { filter, name }
            }
            StaticAbilityPayload::CountAsCardNamedForSpellEffect {
                spell_name,
                counted_name,
            } => StaticAbilityPayload::CountAsCardNamedForSpellEffect {
                spell_name,
                counted_name,
            },
            StaticAbilityPayload::AddSupertypes { filter, supertypes } => {
                StaticAbilityPayload::AddSupertypes { filter, supertypes }
            }
            StaticAbilityPayload::RemoveSupertypes { filter, supertypes } => {
                StaticAbilityPayload::RemoveSupertypes { filter, supertypes }
            }
            StaticAbilityPayload::MaxCreaturesCanAttackEachCombat(maximum) => {
                StaticAbilityPayload::MaxCreaturesCanAttackEachCombat(maximum)
            }
            StaticAbilityPayload::MaxCreaturesCanAttackYouEachCombat(maximum) => {
                StaticAbilityPayload::MaxCreaturesCanAttackYouEachCombat(maximum)
            }
            StaticAbilityPayload::MaxCreaturesCanBlockEachCombat(maximum) => {
                StaticAbilityPayload::MaxCreaturesCanBlockEachCombat(maximum)
            }
            StaticAbilityPayload::MaxCreaturesCanAttackSourceEachCombat(maximum) => {
                StaticAbilityPayload::MaxCreaturesCanAttackSourceEachCombat(maximum)
            }
            StaticAbilityPayload::AdditionalSpellTargets { filter, amount } => StaticAbilityPayload::AdditionalSpellTargets { filter, amount },
            StaticAbilityPayload::CanBeBlockedAsThoughBlockersWereUntapped(filter) => {
                StaticAbilityPayload::CanBeBlockedAsThoughBlockersWereUntapped(filter)
            }
            StaticAbilityPayload::PhaseBoundaryPlayerAction { boundary, label, condition } => StaticAbilityPayload::PhaseBoundaryPlayerAction { boundary, label, condition: map_intervening(condition)? },
            StaticAbilityPayload::TriggerEventProjection { observed, sources, subjects, projected } => StaticAbilityPayload::TriggerEventProjection { observed, sources, subjects, projected },
            StaticAbilityPayload::CanBlockAsThoughUntapped => {
                StaticAbilityPayload::CanBlockAsThoughUntapped
            }
            StaticAbilityPayload::CanBlockAsThoughNoLandwalk => {
                StaticAbilityPayload::CanBlockAsThoughNoLandwalk
            }
            StaticAbilityPayload::ChooseBasicLandTypeAsEnters(display) => {
                StaticAbilityPayload::ChooseBasicLandTypeAsEnters(display)
            }
            StaticAbilityPayload::ChooseLandTypeAsEnters(display) => {
                StaticAbilityPayload::ChooseLandTypeAsEnters(display)
            }
            StaticAbilityPayload::Enchant(filter) => StaticAbilityPayload::Enchant(filter),
            StaticAbilityPayload::FlashIfTargetsMatching(filter) => StaticAbilityPayload::FlashIfTargetsMatching(filter),
            StaticAbilityPayload::FlashIfCastChoice(choice) => StaticAbilityPayload::FlashIfCastChoice(choice),
            StaticAbilityPayload::EnchantedLandIsChosenType(display) => {
                StaticAbilityPayload::EnchantedLandIsChosenType(display)
            }
            StaticAbilityPayload::SourceLandIsChosenType(display) => {
                StaticAbilityPayload::SourceLandIsChosenType(display)
            }
            StaticAbilityPayload::ChooseBasicLandTypesAsEnters { display, count } => {
                StaticAbilityPayload::ChooseBasicLandTypesAsEnters { display, count }
            }
            StaticAbilityPayload::FirstChosenLandTypeBecomesSecond { filter, display } => {
                StaticAbilityPayload::FirstChosenLandTypeBecomesSecond { filter, display }
            }
            StaticAbilityPayload::AttachedIsCopyOfChosenObject(display) => {
                StaticAbilityPayload::AttachedIsCopyOfChosenObject(display)
            }
            StaticAbilityPayload::AttachedIsCopyOfSource { retain_original_types } => {
                StaticAbilityPayload::AttachedIsCopyOfSource { retain_original_types }
            }
            StaticAbilityPayload::AddChosenCreatureType {
                filter,
                display,
                replace_existing,
            } => StaticAbilityPayload::AddChosenCreatureType {
                filter,
                display,
                replace_existing,
            },
            StaticAbilityPayload::SourceHasAbilityStickerAbilitiesOf { filter, display } => {
                StaticAbilityPayload::SourceHasAbilityStickerAbilitiesOf { filter, display }
            }
            StaticAbilityPayload::AddChosenBasicLandType { filter, display } => {
                StaticAbilityPayload::AddChosenBasicLandType { filter, display }
            }
            StaticAbilityPayload::AddChosenColor { filter, display } => {
                StaticAbilityPayload::AddChosenColor { filter, display }
            }
            StaticAbilityPayload::SetChosenColor { filter, display } => {
                StaticAbilityPayload::SetChosenColor { filter, display }
            }
            StaticAbilityPayload::NoMaximumHandSizeFor(player) => StaticAbilityPayload::NoMaximumHandSizeFor(player),
            StaticAbilityPayload::MaximumHandSizeFromSourceCounters { player, counter_type } =>
                StaticAbilityPayload::MaximumHandSizeFromSourceCounters { player, counter_type },
            StaticAbilityPayload::SetMaximumHandSize { player, amount } => {
                StaticAbilityPayload::SetMaximumHandSize { player, amount }
            }
            StaticAbilityPayload::ReduceMaximumHandSize { player, by } => {
                StaticAbilityPayload::ReduceMaximumHandSize { player, by }
            }
            StaticAbilityPayload::IncreaseMaximumHandSize { player, by } => {
                StaticAbilityPayload::IncreaseMaximumHandSize { player, by }
            }
            StaticAbilityPayload::DevotionIncrease { amount } => {
                StaticAbilityPayload::DevotionIncrease { amount }
            }
            StaticAbilityPayload::MorphCostIncrease { generic_increase } => {
                StaticAbilityPayload::MorphCostIncrease { generic_increase }
            }
            StaticAbilityPayload::UnlockCostReduction { generic_reduction } => {
                StaticAbilityPayload::UnlockCostReduction { generic_reduction }
            }
            StaticAbilityPayload::OpponentDiscardThisToBattlefieldWithCounters {
                counter_type,
                count,
            } => StaticAbilityPayload::OpponentDiscardThisToBattlefieldWithCounters {
                counter_type,
                count,
            },
            StaticAbilityPayload::SourceHasFullTextOfTopGraveyardCard {
                filter,
                abilities,
                ability_labels,
                display,
            } => StaticAbilityPayload::SourceHasFullTextOfTopGraveyardCard {
                filter,
                abilities: abilities
                    .into_iter()
                    .map(|ability| {
                        map_ability(ability, map_trigger, map_effect, map_cost, map_intervening)
                    })
                    .collect::<Result<Vec<_>, _>>()?,
                ability_labels,
                display,
            },
            StaticAbilityPayload::MaySkipDrawStepWithFollowup { if_you_do, display } => {
                StaticAbilityPayload::MaySkipDrawStepWithFollowup {
                    if_you_do: if_you_do
                        .into_iter()
                        .map(&mut *map_effect)
                        .collect::<Result<Vec<_>, _>>()?,
                    display,
                }
            }
            StaticAbilityPayload::PlayerMaySacrificePermanentToIgnoreSourceEffectUntilEndOfTurn {
                player,
                display,
            } => StaticAbilityPayload::PlayerMaySacrificePermanentToIgnoreSourceEffectUntilEndOfTurn {
                player,
                display,
            },
            StaticAbilityPayload::CastTargetRestriction { forbidden, display } => {
                StaticAbilityPayload::CastTargetRestriction { forbidden, display }
            }
            StaticAbilityPayload::AdditionalSacrificePerManaSymbol {
                activated_abilities,
                symbol,
                sacrifice,
                display,
            } => StaticAbilityPayload::AdditionalSacrificePerManaSymbol {
                activated_abilities,
                symbol,
                sacrifice,
                display,
            },
            StaticAbilityPayload::EntersAttachedToChosenObject { filter, display } => {
                StaticAbilityPayload::EntersAttachedToChosenObject { filter, display }
            }
            StaticAbilityPayload::ControllerCounterExilePermission { permission, display } => {
                StaticAbilityPayload::ControllerCounterExilePermission { permission, display }
            }
            StaticAbilityPayload::AttackingPlayerChoosesBlocks { display } => {
                StaticAbilityPayload::AttackingPlayerChoosesBlocks { display }
            }
            StaticAbilityPayload::AttachedControllerMayPayCostToIgnoreSourceEffectUntilEndOfTurn {
                cost,
                display,
            } => StaticAbilityPayload::AttachedControllerMayPayCostToIgnoreSourceEffectUntilEndOfTurn {
                cost: map_total_cost(cost, map_cost)?,
                display,
            },
            StaticAbilityPayload::MaximumHandSizeSevenMinusYourGraveyardCardTypes {
                player,
                min_card_types,
            } => StaticAbilityPayload::MaximumHandSizeSevenMinusYourGraveyardCardTypes {
                player,
                min_card_types,
            },
            StaticAbilityPayload::DuplicateMatchingTriggeredAbilities {
                source_filter,
                event_matcher,
                count,
                display,
            } => StaticAbilityPayload::DuplicateMatchingTriggeredAbilities {
                source_filter,
                event_matcher: event_matcher.map(&mut *map_trigger).transpose()?,
                count,
                display,
            },
            StaticAbilityPayload::SuppressMatchingTriggeredAbilities {
                source_filter,
                event_matcher,
                display,
            } => StaticAbilityPayload::SuppressMatchingTriggeredAbilities {
                source_filter,
                event_matcher: event_matcher.map(&mut *map_trigger).transpose()?,
                display,
            },
            StaticAbilityPayload::ExertAttack {
                only_if_not_exerted_this_turn,
                linked_trigger,
                display,
            } => StaticAbilityPayload::ExertAttack {
                only_if_not_exerted_this_turn,
                linked_trigger: linked_trigger
                    .map(|triggered| map_triggered(triggered, map_trigger, map_effect, map_intervening))
                    .transpose()?,
                display,
            },
            StaticAbilityPayload::EnlistAttack {
                linked_trigger,
                display,
            } => StaticAbilityPayload::EnlistAttack {
                linked_trigger: map_triggered(linked_trigger, map_trigger, map_effect, map_intervening)?,
                display,
            },
            StaticAbilityPayload::EquipmentGrant(abilities) => {
                let mut mapped = Vec::with_capacity(abilities.len());
                for ability in abilities {
                    mapped.push(map_static_ability(
                        ability,
                        map_trigger,
                        map_effect,
                        map_cost,
                        map_intervening,
                    )?);
                }
                StaticAbilityPayload::EquipmentGrant(mapped)
            }
            StaticAbilityPayload::SoulbondSharedPowerToughness { power, toughness } => {
                StaticAbilityPayload::SoulbondSharedPowerToughness { power, toughness }
            }
            StaticAbilityPayload::SoulbondSharedAbility(ability) => {
                StaticAbilityPayload::SoulbondSharedAbility(Box::new(map_static_ability(
                    *ability,
                    map_trigger,
                    map_effect,
                    map_cost,
                    map_intervening,
                )?))
            }
            StaticAbilityPayload::SoulbondSharedObjectAbility(ability) => {
                StaticAbilityPayload::SoulbondSharedObjectAbility(Box::new(map_ability(
                    *ability,
                    map_trigger,
                    map_effect,
                    map_cost,
                    map_intervening,
                )?))
            }
            StaticAbilityPayload::RemoveAbilityForFilter {
                filter,
                ability,
                mode,
            } => {
                StaticAbilityPayload::RemoveAbilityForFilter {
                    filter,
                    ability: Box::new(map_static_ability(
                        *ability,
                        map_trigger,
                        map_effect,
                        map_cost,
                        map_intervening,
                    )?),
                    mode,
                }
            }
            StaticAbilityPayload::RemoveObjectAbilitiesForFilter {
                filter,
                abilities,
                display,
                mode,
            } => StaticAbilityPayload::RemoveObjectAbilitiesForFilter {
                filter,
                abilities: abilities
                    .into_iter()
                    .map(|ability| map_ability(ability, map_trigger, map_effect, map_cost, &mut Ok))
                    .collect::<Result<Vec<_>, _>>()?,
                display,
                mode,
            },
            StaticAbilityPayload::RemoveAllAbilities(filter) => {
                StaticAbilityPayload::RemoveAllAbilities(filter)
            }
            StaticAbilityPayload::RemoveAllAbilitiesExceptMana(filter) => {
                StaticAbilityPayload::RemoveAllAbilitiesExceptMana(filter)
            }
            StaticAbilityPayload::SetBasePowerToughness {
                filter,
                power,
                toughness,
            } => StaticAbilityPayload::SetBasePowerToughness {
                filter,
                power,
                toughness,
            },
            StaticAbilityPayload::SetBasePowerToughnessValue {
                filter,
                power,
                toughness,
            } => StaticAbilityPayload::SetBasePowerToughnessValue {
                filter,
                power,
                toughness,
            },
            StaticAbilityPayload::SetBasePower { filter, power } => {
                StaticAbilityPayload::SetBasePower { filter, power }
            }
            StaticAbilityPayload::SetBaseToughness { filter, toughness } => {
                StaticAbilityPayload::SetBaseToughness { filter, toughness }
            }
            StaticAbilityPayload::SourceCharacteristicsOfLastExiledCreatureCard {
                filter,
                retained_subtypes,
            } => StaticAbilityPayload::SourceCharacteristicsOfLastExiledCreatureCard {
                filter,
                retained_subtypes,
            },
            StaticAbilityPayload::AddCardTypes { filter, card_types } => {
                StaticAbilityPayload::AddCardTypes { filter, card_types }
            }
            StaticAbilityPayload::RemoveCardTypes {
                filter,
                card_types,
                condition,
            } => StaticAbilityPayload::RemoveCardTypes {
                filter,
                card_types,
                condition: condition.map(&mut *map_intervening).transpose()?,
            },
            StaticAbilityPayload::SetCardTypes { filter, card_types } => {
                StaticAbilityPayload::SetCardTypes { filter, card_types }
            }
            StaticAbilityPayload::AddSubtypes { filter, subtypes } => {
                StaticAbilityPayload::AddSubtypes { filter, subtypes }
            }
            StaticAbilityPayload::AddAllSubtypesOfFamily { filter, family } => {
                StaticAbilityPayload::AddAllSubtypesOfFamily { filter, family }
            }
            StaticAbilityPayload::SetLandSubtypes { filter, subtypes } => {
                StaticAbilityPayload::SetLandSubtypes { filter, subtypes }
            }
            StaticAbilityPayload::SetCreatureSubtypes { filter, subtypes } => {
                StaticAbilityPayload::SetCreatureSubtypes { filter, subtypes }
            }
            StaticAbilityPayload::MakeColorless(filter) => StaticAbilityPayload::MakeColorless(filter),
            StaticAbilityPayload::CostIncreasePerTargetBeyondFirst(amount) => {
                StaticAbilityPayload::CostIncreasePerTargetBeyondFirst(amount)
            }
            StaticAbilityPayload::CostIncreaseManaCostPerTargetBeyondFirst(cost) => {
                StaticAbilityPayload::CostIncreaseManaCostPerTargetBeyondFirst(cost)
            }
            StaticAbilityPayload::AdditionalLifeCostPerTarget(amount) => {
                StaticAbilityPayload::AdditionalLifeCostPerTarget(amount)
            }
            StaticAbilityPayload::CommanderTaxLifeSubstitution {
                life_per_previous_cast,
            } => StaticAbilityPayload::CommanderTaxLifeSubstitution {
                life_per_previous_cast,
            },
            StaticAbilityPayload::MinimumSpellTotalMana(amount) => {
                StaticAbilityPayload::MinimumSpellTotalMana(amount)
            }
            StaticAbilityPayload::BuybackCostReduction(amount) => {
                StaticAbilityPayload::BuybackCostReduction(amount)
            }
            StaticAbilityPayload::ActivatedAbilityCostReduction {
                optional,
                filter,
                reduction,
                replacement_mana_cost,
                display,
                condition,
                per_matching_objects,
                per_basic_land_types_among,
                multiplier,
                minimum_total_mana,
                reduction_mana,
            } => StaticAbilityPayload::ActivatedAbilityCostReduction {
                optional,
                filter,
                reduction,
                replacement_mana_cost,
                display,
                condition,
                per_matching_objects,
                per_basic_land_types_among,
                multiplier,
                minimum_total_mana,
                reduction_mana,
            },
            StaticAbilityPayload::ActivatedAbilityCostIncrease {
                filter,
                increase,
                activator,
                non_mana_only,
                condition,
                ability_condition,
                display,
            } => StaticAbilityPayload::ActivatedAbilityCostIncrease {
                filter,
                increase: map_total_cost(increase, map_cost)?,
                activator,
                non_mana_only,
                condition: condition.map(&mut *map_intervening).transpose()?,
                ability_condition,
                display,
            },
            StaticAbilityPayload::ChooseColorAsEnters {
                excluded,
                display,
                count,
            } => StaticAbilityPayload::ChooseColorAsEnters {
                excluded,
                display,
                count,
            },
            StaticAbilityPayload::ChoosePlayerAsEnters {
                filter,
                display,
                count,
            } => StaticAbilityPayload::ChoosePlayerAsEnters {
                filter,
                display,
                count,
            },
            StaticAbilityPayload::NoteLifeTotalAsEnters(display) => {
                StaticAbilityPayload::NoteLifeTotalAsEnters(display)
            }
            StaticAbilityPayload::DiscardHandAsEnters(display) => {
                StaticAbilityPayload::DiscardHandAsEnters(display)
            }
            StaticAbilityPayload::RevealFromHandAsEnters {
                filter,
                count,
                optional,
                display,
            } => StaticAbilityPayload::RevealFromHandAsEnters {
                filter,
                count,
                optional,
                display,
            },
            StaticAbilityPayload::ChooseCardNameAsEnters {
                display,
                reveal_opponents_hands,
                require_nonland_from_revealed_opponents,
                opponent_also_chooses,
                exclude_basic_land_names,
            } => StaticAbilityPayload::ChooseCardNameAsEnters {
                display,
                reveal_opponents_hands,
                require_nonland_from_revealed_opponents,
                opponent_also_chooses,
                exclude_basic_land_names,
            },
            StaticAbilityPayload::ChooseCreatureTypeAsEnters(display) => {
                StaticAbilityPayload::ChooseCreatureTypeAsEnters(display)
            }
            StaticAbilityPayload::ChooseNamedOptionAsEnters {
                options,
                display,
                at_random,
                each_player,
            } => StaticAbilityPayload::ChooseNamedOptionAsEnters {
                options,
                display,
                at_random,
                each_player,
            },
            StaticAbilityPayload::ChoosePowerToughnessAsEntersOrTurnsFaceUp {
                options,
                display,
                at_random,
            } => StaticAbilityPayload::ChoosePowerToughnessAsEntersOrTurnsFaceUp {
                at_random,
                options: options
                    .into_iter()
                    .map(|option| {
                        Ok(PowerToughnessChoiceOption {
                            power: option.power,
                            toughness: option.toughness,
                            card_types: option.card_types,
                            added_subtypes: option.added_subtypes,
                            abilities: option
                                .abilities
                                .into_iter()
                                .map(|ability| {
                                    map_static_ability(
                                        ability,
                                        map_trigger,
                                        map_effect,
                                        map_cost,
                                        map_intervening,
                                    )
                                })
                                .collect::<Result<Vec<_>, _>>()?,
                        })
                })
                    .collect::<Result<Vec<_>, _>>()?,
                display,
            },
            StaticAbilityPayload::EnterAsCopyAsEnters { spec, display } => {
                let mut added_abilities = Vec::with_capacity(spec.added_abilities.len());
                for ability in spec.added_abilities {
                    added_abilities.push(map_ability(
                        ability,
                        map_trigger,
                        map_effect,
                        map_cost,
                        map_intervening,
                    )?);
                }
                StaticAbilityPayload::EnterAsCopyAsEnters {
                    spec: EnterAsCopyAsEntersSpec {
                        filter: spec.filter,
                        affected_filter: spec.affected_filter,
                        may: spec.may,
                        enters_tapped_if_chosen: spec.enters_tapped_if_chosen,
                        copy_duration: spec.copy_duration,
                        linked_exile_pair: spec.linked_exile_pair,
                        copy_source_self: spec.copy_source_self,
                        copy_source_enchanted: spec.copy_source_enchanted,
                        name_override: spec.name_override,
                        added_colors: spec.added_colors,
                        added_card_types: spec.added_card_types,
                        removes_other_card_types: spec.removes_other_card_types,
                        added_supertypes: spec.added_supertypes,
                        removed_supertypes: spec.removed_supertypes,
                        added_subtypes: spec.added_subtypes,
                        added_abilities,
                        set_base_power_toughness: spec.set_base_power_toughness,
                        additional_counters: spec.additional_counters.clone(),
                        additional_x_counters: spec.additional_x_counters.clone(),
                        keep_other_source_abilities: spec.keep_other_source_abilities,
                        additional_counters_source_filter: spec.additional_counters_source_filter.clone(),
                        added_abilities_source_filter: spec.added_abilities_source_filter.clone(),
                        set_base_power_toughness_from_self: spec
                            .set_base_power_toughness_from_self,
                        conditional_additional_counters: spec
                            .conditional_additional_counters
                            .clone(),
                        copy_followups: spec.copy_followups,
                    },
                    display,
                }
            }
            StaticAbilityPayload::CastAnnouncementProgram { program } =>
                StaticAbilityPayload::CastAnnouncementProgram { program: program.try_map_effects(&mut *map_effect)? },
            StaticAbilityPayload::SpellResolutionDestinationProgram { origin_zone, destination, follow_up, multiplicity } =>
                StaticAbilityPayload::SpellResolutionDestinationProgram {
                    origin_zone, destination,
                    follow_up: follow_up.try_map_effects(&mut *map_effect)?,
                    multiplicity,
                },
            StaticAbilityPayload::AsEntersEffectProgram {
                program,
                subject,
                also_turns_face_up,
                turns_face_up_only,
                uses_enters_with_counter_surface,
                transforms_into,
                transform_characteristics,
                presentation_label,
                entry_instead_surface,
            } => StaticAbilityPayload::AsEntersEffectProgram {
                program: program.try_map_effects(&mut *map_effect)?,
                subject,
                also_turns_face_up,
                turns_face_up_only,
                uses_enters_with_counter_surface,
                transforms_into,
                transform_characteristics,
                presentation_label,
                entry_instead_surface,
            },
            StaticAbilityPayload::EntersWithCharacteristicsForFilter {
                face_down,
                filter,
                card_types,
                subtypes,
                power,
                toughness,
            } => StaticAbilityPayload::EntersWithCharacteristicsForFilter {
                face_down,
                filter,
                card_types,
                subtypes,
                power,
                toughness,
            },
            StaticAbilityPayload::DoubleDamageFromSourcesYouControlOfChosenType(display) => {
                StaticAbilityPayload::DoubleDamageFromSourcesYouControlOfChosenType(display)
            }
            StaticAbilityPayload::RedirectDamageToSourceController {
                source_filter,
                target_player_filter,
                display,
            } => StaticAbilityPayload::RedirectDamageToSourceController {
                source_filter,
                target_player_filter,
                display,
            },
            StaticAbilityPayload::AdditionalLandPlays(count) => {
                StaticAbilityPayload::AdditionalLandPlays(count)
            }
            StaticAbilityPayload::RevealCardsDrawn { player } => StaticAbilityPayload::RevealCardsDrawn { player },
            StaticAbilityPayload::DamageBetweenChosenPlayers { factor, display } => StaticAbilityPayload::DamageBetweenChosenPlayers { factor, display },
            StaticAbilityPayload::AddSubtypesAndGrantAbilities { filter, subtypes, abilities, display } => StaticAbilityPayload::AddSubtypesAndGrantAbilities {
                filter, subtypes, display,
                abilities: abilities.into_iter().map(|ability|
                    map_ability(ability, map_trigger, map_effect, map_cost, map_intervening)).collect::<Result<Vec<_>, _>>()?,
            },
            StaticAbilityPayload::RevealFirstCardYouDrawEachTurn {
                optional,
                your_turns_only,
                linked_reveal_pair,
            } => StaticAbilityPayload::RevealFirstCardYouDrawEachTurn {
                optional,
                your_turns_only,
                linked_reveal_pair,
            },
            StaticAbilityPayload::ExileToCounteredExileInsteadOfGraveyard {
                player,
                counter_type,
            } => StaticAbilityPayload::ExileToCounteredExileInsteadOfGraveyard {
                player,
                counter_type,
            },
            StaticAbilityPayload::ExileToExileInsteadOfGraveyard {
                filter,
                graveyard_owner,
                exclude_cycled,
                link_to_source,
            } => StaticAbilityPayload::ExileToExileInsteadOfGraveyard {
                filter,
                graveyard_owner,
                exclude_cycled,
                link_to_source,
            },
            StaticAbilityPayload::ExileWouldDieInstead {
                filter,
                damaged_by,
                damager_filter,
                damager_filter_surface,
                exile_with_counters,
                follow_up_effects,
            } => StaticAbilityPayload::ExileWouldDieInstead {
                filter,
                damaged_by,
                damager_filter,
                damager_filter_surface,
                exile_with_counters,
                follow_up_effects: follow_up_effects
                    .into_iter()
                    .map(map_effect)
                    .collect::<Result<Vec<_>, _>>()?,
            },
            StaticAbilityPayload::RedirectZoneChange {
                filter, from_zone, to_zone, destination,
            } => StaticAbilityPayload::RedirectZoneChange {
                filter, from_zone, to_zone, destination,
            },
            StaticAbilityPayload::ShuffleIntoOwnersLibraryInstead { to_zone, reveal } => {
                StaticAbilityPayload::ShuffleIntoOwnersLibraryInstead { to_zone, reveal }
            }
            StaticAbilityPayload::ModifyDamageAmountReplacement {
                source_filter,
                target_player_filter,
                target_object_filter,
                delta,
                dynamic_delta,
                noncombat_only,
                display,
            } => StaticAbilityPayload::ModifyDamageAmountReplacement {
                source_filter,
                target_player_filter,
                target_object_filter,
                delta,
                dynamic_delta,
                noncombat_only,
                display,
            },
            StaticAbilityPayload::MinimumDamageAmountReplacement {
                source_filter,
                target_player_filter,
                target_object_filter,
                floor,
                noncombat_only,
                display,
            } => StaticAbilityPayload::MinimumDamageAmountReplacement {
                source_filter,
                target_player_filter,
                target_object_filter,
                floor,
                noncombat_only,
                display,
            },
            StaticAbilityPayload::DoubleDamageAmountReplacement {
                source_filter,
                target_player_filter,
                target_object_filter,
                factor,
                combat_only,
                noncombat_only,
                display,
            } => StaticAbilityPayload::DoubleDamageAmountReplacement {
                source_filter,
                target_player_filter,
                target_object_filter,
                factor,
                combat_only,
                noncombat_only,
                display,
            },
            StaticAbilityPayload::SpellManaSpendingRestriction(rule) =>
                StaticAbilityPayload::SpellManaSpendingRestriction(rule),
            StaticAbilityPayload::RedirectMatchingDamage(spec) =>
                StaticAbilityPayload::RedirectMatchingDamage(spec),
            StaticAbilityPayload::PreventMatchingDamage(spec) =>
                StaticAbilityPayload::PreventMatchingDamage(spec),
            StaticAbilityPayload::PreventMatchingDamageWithFollowUp(spec) =>
                StaticAbilityPayload::PreventMatchingDamageWithFollowUp(StaticDamagePreventionFollowUp {
                    source_filter: spec.source_filter,
                    target_player_filter: spec.target_player_filter,
                    target_object_filter: spec.target_object_filter,
                    combat_only: spec.combat_only,
                    noncombat_only: spec.noncombat_only,
                    damage_source_tag: spec.damage_source_tag,
                    amount_basis: spec.amount_basis,
                    effects: spec.effects.into_iter().map(map_effect).collect::<Result<Vec<_>, _>>()?,
                    display: spec.display,
                }),
            StaticAbilityPayload::PreventHalfDamageReplacement {
                source_filter,
                target_player_filter,
                target_object_filter,
                round_up,
                display,
            } => StaticAbilityPayload::PreventHalfDamageReplacement {
                source_filter,
                target_player_filter,
                target_object_filter,
                round_up,
                display,
            },
            StaticAbilityPayload::DoubleCountersReplacement {
                filter,
                player_filter,
                counter_type,
                actor,
                includes_permanents,
                halve,
                effect_only,
                display,
            } => StaticAbilityPayload::DoubleCountersReplacement {
                filter,
                player_filter,
                counter_type,
                actor,
                includes_permanents,
                halve,
                effect_only,
                display,
            },
            StaticAbilityPayload::CounterKindReplacement {filter,cause,kinds,display} =>
                StaticAbilityPayload::CounterKindReplacement {filter,cause,kinds,display},
            StaticAbilityPayload::AddCountersPlacementReplacement {
                filter,
                player_filter,
                counter_type,
                additional,
                cause,
                display,
            } => StaticAbilityPayload::AddCountersPlacementReplacement {
                filter,
                player_filter,
                counter_type,
                additional,
                cause,
                display,
            },
            StaticAbilityPayload::PlayerCounterPerTurnLimitReplacement {
                player_filter,
                counter_type,
                maximum,
                display,
            } => StaticAbilityPayload::PlayerCounterPerTurnLimitReplacement {
                player_filter,
                counter_type,
                maximum,
                display,
            },
            StaticAbilityPayload::DoubleTokenCreationReplacement {
                controller,
                display,
            } => StaticAbilityPayload::DoubleTokenCreationReplacement {
                controller,
                display,
            },
            StaticAbilityPayload::MultiplyTokenCreationReplacement {
                controller,
                token_filter,
                factor,
                display,
            } => StaticAbilityPayload::MultiplyTokenCreationReplacement {
                controller,
                token_filter,
                factor,
                display,
            },
            StaticAbilityPayload::AddTokenCreationReplacement {
                controller,
                token_filter,
                additional_token,
                additional,
                per_created,
                display,
            } => StaticAbilityPayload::AddTokenCreationReplacement {
                controller,
                token_filter,
                additional_token,
                additional,
                per_created,
                display,
            },
            StaticAbilityPayload::NamedActionReplacement { label, source_filter, performer_filter, object_requirement, replacement_effects, optional, display } =>
                StaticAbilityPayload::NamedActionReplacement { label, source_filter, performer_filter, object_requirement,
                    replacement_effects: replacement_effects.into_iter().map(map_effect).collect::<Result<Vec<_>, _>>()?, optional, display },
            StaticAbilityPayload::KeywordActionReplacement {
                action,
                source_filter,
                performer_filter,
                replacement_effects,
                optional,
                display,
            } => StaticAbilityPayload::KeywordActionReplacement {
                action,
                source_filter,
                performer_filter,
                replacement_effects: replacement_effects
                    .into_iter()
                    .map(map_effect)
                    .collect::<Result<Vec<_>, _>>()?,
                optional,
                display,
            },
            StaticAbilityPayload::DrawExtraCardsReplacement {
                extra,
                except_first_of_draw_step,
                per_instruction,
                display,
            } => StaticAbilityPayload::DrawExtraCardsReplacement {
                extra,
                except_first_of_draw_step,
                per_instruction,
                display,
            },
            StaticAbilityPayload::CreateOneOfEachTokenReplacement { kinds, display } => {
                StaticAbilityPayload::CreateOneOfEachTokenReplacement { kinds, display }
            }
            StaticAbilityPayload::DrawReplacementWithEffects {
                drawer,
                except_first_of_draw_step,
                replacement_effects,
                display,
                cycling_source,
            } => StaticAbilityPayload::DrawReplacementWithEffects {
                drawer,
                except_first_of_draw_step,
                replacement_effects: replacement_effects
                    .into_iter()
                    .map(map_effect)
                    .collect::<Result<Vec<_>, _>>()?,
                display,
                cycling_source,
            },
            StaticAbilityPayload::RedirectDrawReplacement {
                drawer,
                except_first_of_draw_step,
                display,
            } => StaticAbilityPayload::RedirectDrawReplacement {
                drawer,
                except_first_of_draw_step,
                display,
            },
            StaticAbilityPayload::ConditionalDrawReplacement {
                condition,
                replacement_effects,
                optional,
                display,
                except_first_of_draw_step,
            } => StaticAbilityPayload::ConditionalDrawReplacement {
                condition: map_intervening(condition)?,
                replacement_effects: replacement_effects
                    .into_iter()
                    .map(map_effect)
                    .collect::<Result<Vec<_>, _>>()?,
                optional,
                display,
                except_first_of_draw_step,
            },
            StaticAbilityPayload::LoseGameReplacement {
                replacement_effects,
                optional,
                display,
            } => StaticAbilityPayload::LoseGameReplacement {
                replacement_effects: replacement_effects
                    .into_iter()
                    .map(map_effect)
                    .collect::<Result<Vec<_>, _>>()?,
                optional,
                display,
            },
            StaticAbilityPayload::DrawReplacementRevealTopMatchingToHandRestBottom {
                count,
                filter,
                order,
                display,
            } => StaticAbilityPayload::DrawReplacementRevealTopMatchingToHandRestBottom {
                count,
                filter,
                order,
                display,
            },
            StaticAbilityPayload::CharacteristicDefiningPt { power, toughness } => {
                StaticAbilityPayload::CharacteristicDefiningPt { power, toughness }
            }
            StaticAbilityPayload::DiscardOrRedirectReplacement {
                filter,
                redirect_zone,
            } => StaticAbilityPayload::DiscardOrRedirectReplacement {
                filter,
                redirect_zone,
            },
            StaticAbilityPayload::SacrificeOrRedirectReplacement {
                filter,
                count,
                redirect_zone,
            } => StaticAbilityPayload::SacrificeOrRedirectReplacement {
                filter,
                count,
                redirect_zone,
            },
            StaticAbilityPayload::PayLifeOrEnterTapped(value) => {
                StaticAbilityPayload::PayLifeOrEnterTapped(value)
            }
            StaticAbilityPayload::RevealCardOrEnterTapped {
                filter,
                subject,
                tail_subject,
            } => StaticAbilityPayload::RevealCardOrEnterTapped {
                filter,
                subject,
                tail_subject,
            },
            StaticAbilityPayload::RedirectWouldEnter {
                filter,
                not_cast,
                destination,
                display,
                or_no_mana_spent,
            } => StaticAbilityPayload::RedirectWouldEnter {
                filter,
                not_cast,
                destination,
                display,
                or_no_mana_spent,
            },
            StaticAbilityPayload::ManaProductionMultiplierReplacement {
                source_filter,
                factor,
                display,
            } => StaticAbilityPayload::ManaProductionMultiplierReplacement {
                source_filter,
                factor,
                display,
            },
            StaticAbilityPayload::ConvertUnspentMana { player, symbol } =>
                StaticAbilityPayload::ConvertUnspentMana { player, symbol },
            StaticAbilityPayload::ManaProductionRewrite { rule, display } =>
                StaticAbilityPayload::ManaProductionRewrite { rule, display },
            StaticAbilityPayload::ManaProductionReplacement {
                source_filter,
                minimum_amount,
                replacement_mana,
                display,
            } => StaticAbilityPayload::ManaProductionReplacement {
                source_filter,
                minimum_amount,
                replacement_mana,
                display,
            },
            StaticAbilityPayload::TokenCreationTemplates { controller, token_filter, templates, mode, choose_one, optional, display } =>
                StaticAbilityPayload::TokenCreationTemplates {
                    controller, token_filter,
                    templates: templates.into_iter().map(map_effect).collect::<Result<Vec<_>, _>>()?,
                    mode, choose_one, optional, display,
                },
            StaticAbilityPayload::ActorCountersAddition { filter, player_filter, actor, counter_type, additional, display } =>
                StaticAbilityPayload::ActorCountersAddition { filter, player_filter, actor, counter_type, additional, display },
            StaticAbilityPayload::AddLifeGainReplacement { player, additional, display } =>
                StaticAbilityPayload::AddLifeGainReplacement { player, additional, display },
            StaticAbilityPayload::DoubleLifeChangeReplacement {
                player,
                loss,
                display,
            } => StaticAbilityPayload::DoubleLifeChangeReplacement {
                player,
                loss,
                display,
            },
            StaticAbilityPayload::ManaSpendPermission {
                permission,
                display,
            } => StaticAbilityPayload::ManaSpendPermission {
                permission,
                display,
            },
            StaticAbilityPayload::Landwalk(kind) => StaticAbilityPayload::Landwalk(kind),
            StaticAbilityPayload::Bloodthirst(amount) => {
                StaticAbilityPayload::Bloodthirst(amount)
            }
            StaticAbilityPayload::Tribute(amount) => StaticAbilityPayload::Tribute(amount),
            StaticAbilityPayload::PreventDamageToSelfRemoveCounter {
                counter_type,
                amount,
                follow_up,
                one_damage_per_counter,
                surface,
            } => StaticAbilityPayload::PreventDamageToSelfRemoveCounter {
                counter_type,
                amount,
                follow_up,
                one_damage_per_counter,
                surface,
            },
            StaticAbilityPayload::PreventDamageToSelfPutCountersInstead {
                counter_type,
                display,
            } => StaticAbilityPayload::PreventDamageToSelfPutCountersInstead {
                counter_type,
                display,
            },
            StaticAbilityPayload::HealDamageBeforeDamageToSelf { display } => {
                StaticAbilityPayload::HealDamageBeforeDamageToSelf { display }
            }
            StaticAbilityPayload::PreventConstrainedDamageToSelfPutCountersInstead {
                counter_type,
                display,
                source_filter,
                combat_only,
            } => StaticAbilityPayload::PreventConstrainedDamageToSelfPutCountersInstead {
                counter_type,
                display,
                source_filter,
                combat_only,
            },
            StaticAbilityPayload::PreventDamageToYouFromSourceFilter {
                amount,
                source_filter,
                display,
            } => StaticAbilityPayload::PreventDamageToYouFromSourceFilter {
                amount,
                source_filter,
                display,
            },
            StaticAbilityPayload::DamagePreventionWithFollowUp {
                source_filter, target_filter, combat_only, recipient_tag, effects,
            } => StaticAbilityPayload::DamagePreventionWithFollowUp {
                source_filter, target_filter, combat_only, recipient_tag,
                effects: effects.into_iter().map(map_effect).collect::<Result<Vec<_>, _>>()?,
            },
            StaticAbilityPayload::ReplaceDamageWithCountersInstead {
                counter_type,
                display,
                source_filter,
                target_filter,
                combat_only,
            } => StaticAbilityPayload::ReplaceDamageWithCountersInstead {
                counter_type,
                display,
                source_filter,
                target_filter,
                combat_only,
            },
            StaticAbilityPayload::CantAttackYouUnlessControllerPaysPerAttacker(amount) => {
                StaticAbilityPayload::CantAttackYouUnlessControllerPaysPerAttacker(amount)
            }
            StaticAbilityPayload::CantAttackYouOrPlaneswalkersUnlessControllerPaysPerAttacker(
                amount,
            ) => StaticAbilityPayload::CantAttackYouOrPlaneswalkersUnlessControllerPaysPerAttacker(
                amount,
            ),
            StaticAbilityPayload::CantAttackYouUnlessControllerPaysPerAttackerBasicLandTypesAmongLandsYouControl => {
                StaticAbilityPayload::CantAttackYouUnlessControllerPaysPerAttackerBasicLandTypesAmongLandsYouControl
            }
            StaticAbilityPayload::Grants(spec) => {
                StaticAbilityPayload::Grants(Box::new(map_grant_spec(
                    *spec,
                    map_trigger,
                    map_effect,
                    map_cost,
                    map_intervening,
                )?))
            }
            StaticAbilityPayload::ForetellSpecialActionModifier {
                generic_reduction,
                any_players_turn,
                first_each_turn,
                plot,
            } => StaticAbilityPayload::ForetellSpecialActionModifier {
                generic_reduction,
                any_players_turn,
                first_each_turn,
                plot,
            },
            StaticAbilityPayload::NativeAlternativeCastFromZone { zone, method } => {
                StaticAbilityPayload::NativeAlternativeCastFromZone { zone, method }
            }
            StaticAbilityPayload::EntersTappedUnlessCondition { condition, display } => {
                StaticAbilityPayload::EntersTappedUnlessCondition {
                    condition: map_intervening(condition)?,
                    display,
                }
            }
            StaticAbilityPayload::EntersWithCountersIfCondition {
                counter,
                count,
                condition,
                display,
                added_abilities,
            } => StaticAbilityPayload::EntersWithCountersIfCondition {
                counter,
                count,
                condition: map_intervening(condition)?,
                display,
                added_abilities: added_abilities
                    .into_iter()
                    .map(|ability| {
                        map_ability(ability, map_trigger, map_effect, map_cost, map_intervening)
                    })
                    .collect::<Result<Vec<_>, _>>()?,
            },
            StaticAbilityPayload::IntrinsicStartingCounters(rule) => StaticAbilityPayload::IntrinsicStartingCounters(rule),
            StaticAbilityPayload::EntersWithCountersValue { counter, count } => {
                StaticAbilityPayload::EntersWithCountersValue { counter, count }
            }
            StaticAbilityPayload::EntersWithCounterChoice {
                counter_types,
                count,
                kinds,
                condition,
                display,
            } => StaticAbilityPayload::EntersWithCounterChoice {
                counter_types,
                count,
                kinds,
                condition: condition.map(|condition| map_intervening(condition)).transpose()?,
                display,
            },
            StaticAbilityPayload::EntersUnderChosenControl(players) => StaticAbilityPayload::EntersUnderChosenControl(players),
            StaticAbilityPayload::EntersTappedForFilter(filter) => {
                StaticAbilityPayload::EntersTappedForFilter(filter)
            }
            StaticAbilityPayload::EntersUntappedForFilter(filter) => {
                StaticAbilityPayload::EntersUntappedForFilter(filter)
            }
            StaticAbilityPayload::EntersWithCountersAndSubtypesForFilter {
                filter,
                counter,
                counter_kinds_from,
                count,
                count_condition,
                otherwise_count,
                subtypes,
            } => StaticAbilityPayload::EntersWithCountersAndSubtypesForFilter {
                filter,
                counter,
                counter_kinds_from,
                count,
                count_condition,
                otherwise_count,
                subtypes,
            },
            };

            Ok(StaticAbility {
                id: ability.id,
                label: ability.label,
                payload,
            })
        }

        map_static_ability(
            self,
            &mut map_trigger,
            &mut map_effect,
            &mut map_cost,
            &mut map_intervening,
        )
    }
}

impl<
    T: Clone + PartialEq + std::fmt::Debug + 'static,
    E: Clone + PartialEq + std::fmt::Debug + 'static,
    C: Clone + PartialEq + std::fmt::Debug + 'static,
    Cond: Clone + PartialEq + std::fmt::Debug + 'static,
    ICond: Clone + PartialEq + std::fmt::Debug + ConditionConjunction + 'static,
> StaticAbility<T, E, C, Cond, ICond>
{
    fn identified(id: StaticAbilityId, label: impl Into<String>) -> Self {
        Self {
            id: Some(id),
            label: label.into(),
            payload: StaticAbilityPayload::None,
        }
    }

    pub fn new(label: impl std::fmt::Debug + 'static) -> Self {
        let label_any = &label as &dyn Any;
        if let Some(id) = label_any.downcast_ref::<StaticAbilityId>() {
            return Self::identified(*id, format!("{id:?}"));
        }
        if let Some(payload) = label_any.downcast_ref::<Anthem<ICond>>() {
            return Self {
                id: Some(StaticAbilityId::Anthem),
                label: "anthem".to_string(),
                payload: StaticAbilityPayload::Anthem(payload.clone()),
            };
        }
        if let Some(payload) = label_any.downcast_ref::<AttachedAbilityGrant<T, E, C, Cond>>() {
            return Self {
                id: Some(StaticAbilityId::AttachedAbilityGrant),
                label: payload.display.clone(),
                payload: StaticAbilityPayload::AttachedAbilityGrant(Box::new(payload.clone())),
            };
        }
        if let Some(payload) = label_any.downcast_ref::<AttachedChosenLandwalkGrant>() {
            return Self {
                id: Some(StaticAbilityId::AttachedChosenLandwalkGrant),
                label: payload.display.clone(),
                payload: StaticAbilityPayload::AttachedChosenLandwalkGrant(payload.clone()),
            };
        }
        if let Some(payload) =
            label_any.downcast_ref::<GrantObjectAbilityForFilter<T, E, C, Cond, ICond>>()
        {
            // One grant model, two surfaces. The id and label still tell the
            // two apart for text reconstruction; the payload no longer does.
            let (id, label) = if payload.derived_ability_display {
                (StaticAbilityId::GrantAbility, "grant ability".to_string())
            } else {
                (
                    StaticAbilityId::GrantObjectAbilityForFilter,
                    payload.display.clone(),
                )
            };
            return Self {
                id: Some(id),
                label,
                payload: StaticAbilityPayload::GrantObjectAbilityForFilter(Box::new(
                    payload.clone(),
                )),
            };
        }
        if let Some(payload) = label_any.downcast_ref::<RemoveCardTypesForFilter<ICond>>() {
            return Self {
                id: Some(StaticAbilityId::RemoveCardTypes),
                label: "remove card types".to_string(),
                payload: StaticAbilityPayload::RemoveCardTypes {
                    filter: payload.filter.clone(),
                    card_types: payload.types.clone(),
                    condition: payload.condition.clone(),
                },
            };
        }
        if let Some(payload) = label_any.downcast_ref::<CopyActivatedAbilities>() {
            return Self {
                id: Some(StaticAbilityId::CopyActivatedAbilities),
                label: "copy activated abilities".to_string(),
                payload: StaticAbilityPayload::CopyActivatedAbilities(payload.clone()),
            };
        }
        if let Some(payload) = label_any.downcast_ref::<CopyStaticAbilityVariants>() {
            return Self {
                id: Some(StaticAbilityId::CopyStaticAbilityVariants),
                label: payload.display.clone(),
                payload: StaticAbilityPayload::CopyStaticAbilityVariants(payload.clone()),
            };
        }
        if let Some(payload) = label_any.downcast_ref::<CopyTriggeredAbilities>() {
            return Self {
                id: Some(StaticAbilityId::CopyTriggeredAbilities),
                label: payload.display.clone(),
                payload: StaticAbilityPayload::CopyTriggeredAbilities(payload.clone()),
            };
        }
        if let Some(payload) = label_any.downcast_ref::<CostReduction<ICond>>() {
            return Self {
                id: Some(StaticAbilityId::CostReduction),
                label: "cost reduction".to_string(),
                payload: StaticAbilityPayload::CostReduction(payload.clone()),
            };
        }
        if let Some(payload) = label_any.downcast_ref::<CostReductionManaCost<ICond>>() {
            return Self {
                id: Some(StaticAbilityId::CostReductionManaCost),
                label: "cost reduction mana cost".to_string(),
                payload: StaticAbilityPayload::CostReductionManaCost(payload.clone()),
            };
        }
        if let Some(payload) = label_any.downcast_ref::<CostIncrease<ICond>>() {
            return Self {
                id: Some(StaticAbilityId::CostIncrease),
                label: "cost increase".to_string(),
                payload: StaticAbilityPayload::CostIncrease(payload.clone()),
            };
        }
        if let Some(payload) = label_any.downcast_ref::<CostIncreaseManaCost<ICond>>() {
            return Self {
                id: Some(StaticAbilityId::CostIncreaseManaCost),
                label: "cost increase mana cost".to_string(),
                payload: StaticAbilityPayload::CostIncreaseManaCost(payload.clone()),
            };
        }
        if let Some(payload) = label_any.downcast_ref::<ThisSpellCostReduction<Cond>>() {
            let id = if payload.affinity_filter.is_some() {
                StaticAbilityId::Affinity
            } else {
                StaticAbilityId::ThisSpellCostReduction
            };
            return Self {
                id: Some(id),
                label: "this spell cost reduction".to_string(),
                payload: StaticAbilityPayload::ThisSpellCostReduction(payload.clone()),
            };
        }
        if let Some(payload) = label_any.downcast_ref::<ThisSpellCostReductionManaCost<Cond>>() {
            return Self {
                id: Some(StaticAbilityId::ThisSpellCostReductionManaCost),
                label: "this spell cost reduction mana cost".to_string(),
                payload: StaticAbilityPayload::ThisSpellCostReductionManaCost(payload.clone()),
            };
        }
        if let Some(payload) = label_any.downcast_ref::<LandwalkKind>() {
            return Self {
                id: Some(StaticAbilityId::Landwalk),
                label: payload.display(),
                payload: StaticAbilityPayload::Landwalk(*payload),
            };
        }
        Self {
            id: None,
            label: format!("{label:?}"),
            payload: StaticAbilityPayload::None,
        }
    }

    pub fn foretell_special_action_modifier(generic_reduction: u32, any_players_turn: bool) -> Self {
        let timing = if any_players_turn { " and can be done on any player's turn" } else { "" };
        Self {
            id: Some(StaticAbilityId::ForetellSpecialActionModifier),
            label: format!("Foretelling cards from your hand costs {{{generic_reduction}}} less{timing}."),
            payload: StaticAbilityPayload::ForetellSpecialActionModifier {
                generic_reduction,
                any_players_turn,
                first_each_turn: false,
                plot: false,
            },
        }
    }

    /// "Plotting cards from your hand costs {N} less." The plot special
    /// action's cost (the card's plot cost, CR 702.170a) is reduced by N
    /// generic mana for the source's controller.
    pub fn plot_special_action_modifier(generic_reduction: u32) -> Self {
        Self {
            id: Some(StaticAbilityId::ForetellSpecialActionModifier),
            label: format!("Plotting cards from your hand costs {{{generic_reduction}}} less."),
            payload: StaticAbilityPayload::ForetellSpecialActionModifier {
                generic_reduction,
                any_players_turn: false,
                first_each_turn: false,
                plot: true,
            },
        }
    }

    /// "The first card you foretell each turn costs {0} to foretell." The
    /// foretell special action costs {2} (CR 702.143a), so the first action
    /// each turn is reduced by that whole amount.
    pub fn foretell_first_each_turn_free() -> Self {
        Self {
            id: Some(StaticAbilityId::ForetellSpecialActionModifier),
            label: "The first card you foretell each turn costs {0} to foretell.".to_string(),
            payload: StaticAbilityPayload::ForetellSpecialActionModifier {
                generic_reduction: 2,
                any_players_turn: false,
                first_each_turn: true,
                plot: false,
            },
        }
    }

    pub fn native_alternative_cast_from_zone(
        zone: Zone,
        method: crate::alternative_cast_model::AlternativeCastKeyword,
    ) -> Self {
        Self {
            id: Some(StaticAbilityId::NativeAlternativeCastFromZone),
            label: format!(
                "You may cast this card from your {} using its {} ability.",
                format!("{zone:?}").to_lowercase(),
                format!("{method:?}").to_lowercase()
            ),
            payload: StaticAbilityPayload::NativeAlternativeCastFromZone { zone, method },
        }
    }

    pub fn level(ability: LevelAbilityModel<T, E, C, Cond>) -> Self {
        Self {
            id: Some(StaticAbilityId::LevelAbilities),
            label: "level".to_string(),
            payload: StaticAbilityPayload::LevelAbility(Box::new(ability)),
        }
    }

    pub fn flash_if_targets_matching(filter: ObjectFilter) -> Self {
        Self {
            id: Some(StaticAbilityId::Flash),
            label: format!(
                "You may cast this spell as though it had flash if it targets {}",
                filter.description()
            ),
            payload: StaticAbilityPayload::FlashIfTargetsMatching(filter),
        }
    }

    pub fn flash_if_cast_choice(choice: FlashCastChoice) -> Self {
        let condition = match &choice {
            FlashCastChoice::XAtMost(max) => format!("X is {max} or less"),
            FlashCastChoice::OptionalCostPaid(cost) => {
                format!("it's cast using {}", cost.display_label().to_ascii_lowercase())
            }
        };
        Self {
            id: Some(StaticAbilityId::Flash),
            label: format!("You may cast this spell as though it had flash if {condition}"),
            payload: StaticAbilityPayload::FlashIfCastChoice(choice),
        }
    }

    pub fn flash() -> Self {
        Self {
            id: Some(StaticAbilityId::Flash),
            label: "flash".to_string(),
            payload: StaticAbilityPayload::None,
        }
    }

    pub fn this_spell_cast_restriction(
        kind: ThisSpellCastRestrictionKind,
        text: impl Into<String>,
    ) -> Self {
        let display = text.into();
        Self {
            id: Some(StaticAbilityId::ThisSpellCastRestriction),
            label: display.clone(),
            payload: StaticAbilityPayload::ThisSpellCastRestriction { kind, display },
        }
    }

    pub fn this_spell_x_maximum(maximum: Value, text: impl Into<String>) -> Self {
        let display = text.into();
        Self {
            id: Some(StaticAbilityId::ThisSpellXMaximum),
            label: display.clone(),
            payload: StaticAbilityPayload::ThisSpellXMaximum { maximum, display, definition: None },
        }
    }

    pub fn this_spell_x_minimum(minimum: Value, text: impl Into<String>) -> Self {
        let display = text.into();
        Self {
            id: Some(StaticAbilityId::ThisSpellXMinimum),
            label: display.clone(),
            payload: StaticAbilityPayload::ThisSpellXMinimum { minimum, display },
        }
    }

    pub fn extra_coin_ignore_one(player: PlayerFilter, display: impl Into<String>) -> Self {
        Self {
            id: Some(StaticAbilityId::ExtraCoinIgnoreOne),
            label: display.into(),
            payload: StaticAbilityPayload::ExtraCoinIgnoreOne { player },
        }
    }

    pub fn first_coin_batch_heads_win(player: PlayerFilter, display: impl Into<String>) -> Self {
        Self {
            id: Some(StaticAbilityId::FirstCoinBatchHeadsWin),
            label: display.into(),
            payload: StaticAbilityPayload::FirstCoinBatchHeadsWin { player },
        }
    }

    pub fn extra_die_ignore_lowest(
        player: PlayerFilter,
        additional: u32,
        display: impl Into<String>,
    ) -> Self {
        Self {
            id: Some(StaticAbilityId::ExtraDieIgnoreLowest),
            label: display.into(),
            payload: StaticAbilityPayload::ExtraDieIgnoreLowest { player, additional },
        }
    }

    pub fn extra_planar_die_ignore_one(player: PlayerFilter, display: impl Into<String>) -> Self {
        Self {
            id: Some(StaticAbilityId::ExtraPlanarDieIgnoreOne),
            label: display.into(),
            payload: StaticAbilityPayload::ExtraPlanarDieIgnoreOne { player },
        }
    }

    pub fn die_roll_result_adjustment(
        player: PlayerFilter,
        life_cost: u32,
        amount: u32,
        once_each_turn: bool,
        display: impl Into<String>,
    ) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::DieRollResultAdjustment),
            label: display.clone(),
            payload: StaticAbilityPayload::DieRollResultAdjustment(DieRollResultAdjustment {
                player,
                life_cost,
                mana_cost: None,
                amount,
                reroll: false,
                once_each_turn,
                display,
                source_counter_cost: None,
                exchange_with_source_base_pt: false,
                sides: None,
            }),
        }
    }

    /// "After you roll a die, you may remove a <kind> counter from this
    /// creature. If you do, increase or decrease the result by N."
    pub fn die_roll_result_adjustment_removing_source_counter(
        player: PlayerFilter,
        counter_type: CounterType,
        amount: u32,
        once_each_turn: bool,
        display: impl Into<String>,
    ) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::DieRollResultAdjustment),
            label: display.clone(),
            payload: StaticAbilityPayload::DieRollResultAdjustment(DieRollResultAdjustment {
                player,
                life_cost: 0,
                mana_cost: None,
                amount,
                reroll: false,
                once_each_turn,
                display,
                source_counter_cost: Some(counter_type),
                exchange_with_source_base_pt: false,
                sides: None,
            }),
        }
    }

    /// "If you would roll one or more <N>-sided dice, instead roll them and
    /// you may exchange one result with this creature's base power or base
    /// toughness."
    pub fn die_roll_result_exchange_with_source_base_pt(
        player: PlayerFilter,
        sides: Option<u32>,
        display: impl Into<String>,
    ) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::DieRollResultAdjustment),
            label: display.clone(),
            payload: StaticAbilityPayload::DieRollResultAdjustment(DieRollResultAdjustment {
                player,
                life_cost: 0,
                mana_cost: None,
                amount: 0,
                reroll: false,
                once_each_turn: false,
                display,
                source_counter_cost: None,
                exchange_with_source_base_pt: true,
                sides,
            }),
        }
    }

    pub fn die_roll_reroll(
        player: PlayerFilter,
        mana_cost: crate::mana::ManaCost,
        once_each_turn: bool,
        display: impl Into<String>,
    ) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::DieRollResultAdjustment),
            label: display.clone(),
            payload: StaticAbilityPayload::DieRollResultAdjustment(DieRollResultAdjustment {
                player,
                life_cost: 0,
                mana_cost: Some(mana_cost),
                amount: 0,
                reroll: true,
                once_each_turn,
                display,
                source_counter_cost: None,
                exchange_with_source_base_pt: false,
                sides: None,
            }),
        }
    }

    pub fn morph(cost: TotalCost<C>) -> Self {
        Self {
            id: Some(StaticAbilityId::Morph),
            label: "morph".to_string(),
            payload: StaticAbilityPayload::Morph(cost),
        }
    }

    pub fn disguise(cost: TotalCost<C>) -> Self {
        Self {
            id: Some(StaticAbilityId::Disguise),
            label: "disguise".to_string(),
            payload: StaticAbilityPayload::Disguise(cost),
        }
    }

    pub fn daybound() -> Self {
        Self::identified(StaticAbilityId::Daybound, "Daybound")
    }

    pub fn nightbound() -> Self {
        Self::identified(StaticAbilityId::Nightbound, "Nightbound")
    }

    pub fn day_night_starts_day_as_enters() -> Self {
        Self::identified(
            StaticAbilityId::DayNightStartsDayAsEnters,
            "If it's neither day nor night, it becomes day as this creature enters",
        )
    }

    pub fn megamorph(cost: TotalCost<C>) -> Self {
        Self {
            id: Some(StaticAbilityId::Megamorph),
            label: "megamorph".to_string(),
            payload: StaticAbilityPayload::Megamorph(cost),
        }
    }

    /// "If this enchantment leaves the battlefield, this effect continues
    /// until end of turn."
    pub fn static_effects_continue_until_end_of_turn_after_leaving(
        display: impl Into<String>,
    ) -> Self {
        Self::identified(
            StaticAbilityId::StaticEffectsContinueUntilEndOfTurnAfterLeaving,
            display,
        )
    }

    pub fn keyword_marker(marker: impl Into<String>) -> Self {
        let text = marker.into();
        if let Some(ability) = Self::known_keyword_marker(&text) {
            return ability;
        }
        match keyword_marker_mechanic(&text) {
            Some(mechanic) => Self {
                id: Some(StaticAbilityId::KeywordMarker),
                label: text,
                payload: StaticAbilityPayload::KeywordMarkerMechanic { mechanic },
            },
            None => Self::identified(StaticAbilityId::KeywordMarker, text),
        }
    }

    /// An ability-sticker row of a sticker sheet (CR 123.7).
    pub fn ticket_ability_sticker(
        tickets: u32,
        abilities: Vec<AbilityModel<T, E, C, Cond, ICond>>,
    ) -> Self {
        Self {
            id: Some(StaticAbilityId::TicketSticker),
            label: format!("{} \u{2014} ability sticker", ticket_cost_symbols(tickets)),
            payload: StaticAbilityPayload::TicketAbilitySticker { tickets, abilities },
        }
    }

    /// A power/toughness-sticker row of a sticker sheet (CR 123.8).
    pub fn ticket_power_toughness_sticker(tickets: u32, power: i32, toughness: i32) -> Self {
        Self {
            id: Some(StaticAbilityId::TicketSticker),
            label: format!("{} \u{2014} {power}/{toughness}", ticket_cost_symbols(tickets)),
            payload: StaticAbilityPayload::TicketPowerToughnessSticker {
                tickets,
                power,
                toughness,
            },
        }
    }

    pub fn generic_mana_tap_payment_prohibition(name: impl Into<String>) -> Self {
        let name=name.into();
        Self { id: Some(StaticAbilityId::KeywordMarker), label: format!("cannot tap for {name}"),
            payload: StaticAbilityPayload::GenericManaTapPaymentProhibition { name } }
    }
    pub fn generic_mana_tap_payment(spells: bool, activated_abilities: bool, exclude_source: bool, display: impl Into<String>) -> Self {
        let display = display.into();
        Self { id: Some(StaticAbilityId::SpellManaSpendingRestriction), label: display.clone(),
            payload: StaticAbilityPayload::GenericManaTapPayment { spells, activated_abilities, exclude_source, name: None, display } }
    }

    pub fn custom_keyword_identity(name: impl Into<String>) -> Self {
        let name = name.into();
        Self {
            id: Some(StaticAbilityId::KeywordMarker),
            label: name.clone(),
            payload: StaticAbilityPayload::CustomKeywordIdentity { name },
        }
    }

    /// Preserve that multiple keyword abilities were authored together on one
    /// Oracle source line. This metadata is inert at runtime and is consumed
    /// only by compiled-text rendering.
    pub fn source_line_keyword_group(keyword_count: usize) -> Self {
        Self {
            id: Some(StaticAbilityId::SourceLineKeywordGroup),
            label: "source-line keyword group".to_string(),
            payload: StaticAbilityPayload::SourceLineKeywordGroup { keyword_count },
        }
    }

    /// Preserve that several lowered static abilities came from one authored
    /// Oracle source-line chunk. This metadata is inert at runtime.
    pub fn source_line_static_group(member_count: usize) -> Self {
        Self {
            id: Some(StaticAbilityId::SourceLineStaticGroup),
            label: "source-line static group".to_string(),
            payload: StaticAbilityPayload::SourceLineStaticGroup { member_count },
        }
    }

    pub fn dredge(amount: u32) -> Self {
        Self {
            id: Some(StaticAbilityId::Dredge),
            label: format!("Dredge {amount}"),
            payload: StaticAbilityPayload::Dredge(amount),
        }
    }

    pub fn bands_with_other(filter: ObjectFilter, display: impl Into<String>) -> Self {
        Self {
            id: Some(StaticAbilityId::BandsWithOther),
            label: display.into(),
            payload: StaticAbilityPayload::BandsWithOther(filter),
        }
    }

    pub fn reveal_to_add_spell_text(quality: SpliceQuality, cost: TotalCost<C>, cost_surface: String) -> Self
    where C: CostComponent,
    {
        Self { id: None, label: format!("As you cast an {} spell, you may reveal this card from your hand and pay {cost_surface}. If you do, add this card's effects to that spell.", quality.oracle_surface()),
            payload: StaticAbilityPayload::Splice(SpliceSpec { custom_keyword: None, source_zone: None, source_destination: None, max_per_spell: None, quality, cost, cost_surface: Some(cost_surface), descriptive: true }) }
    }

    /// Existing splice program with explicit source-zone and movement cost.
    pub fn move_to_add_spell_text(quality: SpliceQuality, cost: TotalCost<C>, cost_surface: String,
        source_zone: crate::zone::Zone, destination: crate::zone::Zone, max_per_spell: Option<u32>) -> Self
    where C: CostComponent,
    {
        let mut ability = Self::reveal_to_add_spell_text(quality, cost, cost_surface.clone());
        let movement = if destination == crate::zone::Zone::Exile {
            format!("exile this card from your {source_zone}")
        } else {
            format!("put this card from your {source_zone} into {destination}")
        };
        ability.label = format!("As you cast an {} spell, you may {movement} and pay {cost_surface}. If you do, add this card's effects to that spell.", quality.oracle_surface());
        if let Some(max) = max_per_spell {
            if destination == crate::zone::Zone::Exile && max == 1 {
                ability.label.push_str(" You may exile only one card this way per spell.");
            } else {
                ability.label.push_str(&format!(" You may move only {max} cards this way per spell."));
            }
        }
        if let StaticAbilityPayload::Splice(spec) = &mut ability.payload {
            spec.source_zone = Some(source_zone);
            spec.source_destination = Some(destination);
            spec.max_per_spell = max_per_spell;
        }
        ability
    }

    pub fn splice(quality: SpliceQuality, cost: TotalCost<C>) -> Self
    where
        C: CostComponent,
    {
        Self::splice_with_cost_surface(quality, cost, None)
    }

    pub fn splice_with_cost_surface(
        quality: SpliceQuality,
        cost: TotalCost<C>,
        cost_surface: Option<String>,
    ) -> Self
    where
        C: CostComponent,
    {
        let separator = if cost.has_non_mana_costs() {
            "—"
        } else {
            " "
        };
        let rendered_cost = cost_surface.clone().unwrap_or_else(|| cost.display());
        Self {
            id: Some(StaticAbilityId::Splice),
            label: format!(
                "Splice onto {}{separator}{}",
                quality.oracle_surface(),
                rendered_cost
            ),
            payload: StaticAbilityPayload::Splice(SpliceSpec {
                custom_keyword: None,
                source_zone: None, source_destination: None, max_per_spell: None,
                descriptive: false,
                quality,
                cost,
                cost_surface,
            }),
        }
    }

    pub fn payment_per_extra_mode(cost: TotalCost<C>, cost_surface: String) -> Self
    where C: CostComponent,
    {
        Self { id: None, label: format!("Pay {cost_surface} for each mode chosen beyond the first."),
            payload: StaticAbilityPayload::Escalate(EscalateSpec { cost, cost_surface: Some(cost_surface), descriptive: true }) }
    }

    pub fn escalate(cost: TotalCost<C>) -> Self
    where
        C: CostComponent,
    {
        Self::escalate_with_cost_surface(cost, None)
    }

    pub fn escalate_with_cost_surface(cost: TotalCost<C>, cost_surface: Option<String>) -> Self
    where
        C: CostComponent,
    {
        let separator = if cost.has_non_mana_costs() {
            "—"
        } else {
            " "
        };
        let rendered_cost = cost_surface.clone().unwrap_or_else(|| cost.display());
        Self {
            id: Some(StaticAbilityId::Escalate),
            label: format!("Escalate{separator}{rendered_cost}"),
            payload: StaticAbilityPayload::Escalate(EscalateSpec { cost, cost_surface, descriptive: false }),
        }
    }

    pub fn keyword_fallback_text(text: impl Into<String>) -> Self {
        Self::identified(StaticAbilityId::KeywordFallbackText, text)
    }

    pub fn companion(condition: CompanionDeckCondition, text: impl Into<String>) -> Self {
        Self {
            id: Some(StaticAbilityId::Companion),
            label: text.into(),
            payload: StaticAbilityPayload::Companion(condition),
        }
    }

    pub fn draft_rule_text(text: impl Into<String>) -> Self {
        let text = text.into();
        Self {
            id: Some(StaticAbilityId::DraftRuleText),
            payload: StaticAbilityPayload::DraftRule { rule: draft_rule(&text) },
            label: text,
        }
    }

    pub fn hidden_agenda() -> Self {
        Self::identified(StaticAbilityId::HiddenAgenda, "Hidden agenda")
    }

    pub fn double_agenda() -> Self {
        Self::identified(StaticAbilityId::DoubleAgenda, "Double agenda")
    }

    pub fn starting_player() -> Self {
        Self::identified(StaticAbilityId::StartingPlayer, "You are the starting player. If multiple players would be the starting player, one of those players is chosen at random.")
    }

    pub fn deck_construction_rule_text(text: impl Into<String>) -> Self {
        let text = text.into();
        if let Some(count) = deck_construction_color_choice_count(&text) {
            return Self {
                id: Some(StaticAbilityId::DeckConstructionRuleText),
                label: text,
                payload: StaticAbilityPayload::DeckConstructionColorChoice { count },
            };
        }
        let Some(maximum) = deck_construction_copy_limit(&text) else {
            return Self::identified(StaticAbilityId::DeckConstructionRuleText, text);
        };
        Self {
            id: Some(StaticAbilityId::DeckConstructionRuleText),
            label: text,
            payload: StaticAbilityPayload::DeckConstructionCopyLimit { maximum },
        }
    }

    /// CR 701.49d: "You can't enter this dungeon unless you 'venture into
    /// [quality].'" The label is the quality (for Undercity, "Undercity").
    pub fn dungeon_entry_restriction(quality: impl Into<String>) -> Self {
        Self::identified(StaticAbilityId::DungeonEntryRestriction, quality)
    }

    pub fn rule_fallback_text(text: impl Into<String>) -> Self {
        Self::identified(StaticAbilityId::RuleFallbackText, text)
    }

    pub fn dungeon_room_trigger_duplication(text: impl Into<String>) -> Self {
        Self::identified(StaticAbilityId::DungeonRoomTriggerDuplication, text)
    }

    /// CR 702.16n: "This effect doesn't remove this Aura." (`all_auras`
    /// false) or "This effect doesn't remove Auras." (`all_auras` true).
    pub fn protection_doesnt_remove_auras(all_auras: bool, text: impl Into<String>) -> Self {
        let id = if all_auras {
            StaticAbilityId::ProtectionDoesntRemoveAuras
        } else {
            StaticAbilityId::ProtectionDoesntRemoveThisAura
        };
        Self::identified(id, text)
    }

    fn known_keyword_marker(text: &str) -> Option<Self> {
        let normalized = text.trim().trim_end_matches('.').to_ascii_lowercase();
        if normalized.ends_with(" can't be blocked") || normalized.ends_with(" cant be blocked") {
            return Some(Self::unblockable());
        }
        Some(match normalized.as_str() {
            "flying" => Self::flying(),
            "first strike" => Self::first_strike(),
            "double strike" => Self::double_strike(),
            "deathtouch" => Self::deathtouch(),
            "lifelink" => Self::lifelink(),
            "vigilance" => Self::vigilance(),
            "trample" => Self::trample(),
            "reach" => Self::reach(),
            "defender" => Self::defender(),
            "flash" => Self::flash(),
            "haste" => Self::haste(),
            "menace" => Self::menace(),
            "hexproof" => Self::hexproof(),
            "indestructible" => Self::indestructible(),
            "shroud" => Self::shroud(),
            "wither" => Self::wither(),
            "infect" => Self::infect(),
            "skulk" => Self::skulk(),
            "prowess" => Self::prowess(),
            "cascade" => Self::cascade(),
            "unleash" => Self::unleash(),
            "split second" => Self::split_second(),
            "rebound" => Self::rebound(),
            "fear" => Self::fear(),
            "intimidate" => Self::intimidate(),
            "shadow" => Self::shadow(),
            "horsemanship" => Self::horsemanship(),
            "flanking" => Self::flanking(),
            "umbra armor" => Self::umbra_armor(),
            "phasing" => Self::phasing(),
            "improvise" => Self::improvise(),
            "convoke" => Self::convoke(),
            "affinity for artifacts" => Self::affinity_for_artifacts(),
            "delve" => Self::delve(),
            "changeling" => Self::changeling(),
            "space sculptor" => Self::space_sculptor(),
            "this creature can't be blocked" | "can't be blocked" => Self::unblockable(),
            "plainswalk" => Self::landwalk(Subtype::Plains),
            "islandwalk" => Self::landwalk(Subtype::Island),
            "swampwalk" => Self::landwalk(Subtype::Swamp),
            "mountainwalk" => Self::landwalk(Subtype::Mountain),
            "forestwalk" => Self::landwalk(Subtype::Forest),
            "desertwalk" => Self::landwalk(Subtype::Desert),
            "snow plainswalk" => Self::snow_landwalk(Subtype::Plains),
            "snow islandwalk" => Self::snow_landwalk(Subtype::Island),
            "snow swampwalk" => Self::snow_landwalk(Subtype::Swamp),
            "snow mountainwalk" => Self::snow_landwalk(Subtype::Mountain),
            "snow forestwalk" => Self::snow_landwalk(Subtype::Forest),
            "landwalk" => Self::any_landwalk(),
            "nonbasic landwalk" => Self::nonbasic_landwalk(),
            "artifact landwalk" => Self::artifact_landwalk(),
            "legendary landwalk" => Self::legendary_landwalk(),
            "snow landwalk" => Self::snow_any_landwalk(),
            "protection from white" => Self::protection(ProtectionFrom::Color(ColorSet::WHITE)),
            "protection from blue" => Self::protection(ProtectionFrom::Color(ColorSet::BLUE)),
            "protection from black" => Self::protection(ProtectionFrom::Color(ColorSet::BLACK)),
            "protection from red" => Self::protection(ProtectionFrom::Color(ColorSet::RED)),
            "protection from green" => Self::protection(ProtectionFrom::Color(ColorSet::GREEN)),
            "protection from all colors" => Self::protection(ProtectionFrom::AllColors),
            "protection from colorless" => Self::protection(ProtectionFrom::Colorless),
            "protection from everything" => Self::protection(ProtectionFrom::Everything),
            "protection from human" | "protection from humans" => Self::protection(
                ProtectionFrom::Permanents(ObjectFilter::creature().with_subtype(Subtype::Human)),
            ),
            _ => return None,
        })
    }

    pub fn restriction(restriction: Restriction, detail: impl std::fmt::Debug) -> Self {
        Self::restrictions(vec![restriction], detail)
    }

    /// A rule restriction whose display is already plain rule text (no
    /// Debug quoting/escaping of embedded quotation marks).
    pub fn restriction_with_display(restriction: Restriction, display: String) -> Self {
        Self {
            id: Some(StaticAbilityId::RuleRestriction),
            label: display.clone(),
            payload: StaticAbilityPayload::RuleRestriction {
                restriction,
                additional_restrictions: Vec::new(),
                display,
            },
        }
    }

    /// A single static rule surface which applies several independent typed
    /// restrictions. Compound Oracle sentences use this to avoid manufacturing
    /// multiple abilities with duplicate display text.
    pub fn restrictions(restrictions: Vec<Restriction>, detail: impl std::fmt::Debug) -> Self {
        let mut restrictions = restrictions.into_iter();
        let restriction = restrictions
            .next()
            .expect("a rule-restriction ability requires at least one restriction");
        let additional_restrictions = restrictions.collect();
        let display = format!("{detail:?}").trim_matches('"').to_string();
        Self {
            id: Some(StaticAbilityId::RuleRestriction),
            label: display.clone(),
            payload: StaticAbilityPayload::RuleRestriction {
                restriction,
                additional_restrictions,
                display,
            },
        }
    }

    pub fn protection(filter: ProtectionFrom) -> Self {
        Self {
            id: Some(StaticAbilityId::Protection),
            label: "protection".to_string(),
            payload: StaticAbilityPayload::Protection(filter),
        }
    }

    pub fn must_attack() -> Self {
        Self::identified(StaticAbilityId::MustAttack, "must attack")
    }

    pub fn conditional_attack_requirement(trigger: ObjectFilter, required: ObjectFilter) -> Self {
        Self {
            id: Some(StaticAbilityId::ConditionalAttackRequirement),
            label: "conditional attack requirement".into(),
            payload: StaticAbilityPayload::ConditionalAttackRequirement { trigger, required },
        }
    }

    pub fn goad_matching(filter: ObjectFilter) -> Self {
        Self {
            id: Some(StaticAbilityId::GoadMatching),
            label: "Matching permanents are goaded".into(),
            payload: StaticAbilityPayload::GoadMatching { filter },
        }
    }

    pub fn attached_goaded_by_source_controller(display: impl Into<String>) -> Self {
        Self::identified(StaticAbilityId::AttachedGoadedBySourceController, display)
    }

    /// A typed special-action permission for an Aura's attached object's
    /// controller. Paying the sacrifice cost causes that player to ignore the
    /// source's static effect for the rest of the turn without using the stack.
    pub fn attached_controller_may_sacrifice_permanent_to_ignore_source_effect_until_end_of_turn(
        display: impl Into<String>,
    ) -> Self {
        Self::identified(
            StaticAbilityId::AttachedControllerMaySacrificePermanentToIgnoreSourceEffectUntilEndOfTurn,
            display,
        )
    }

    /// A typed, source-scoped special-action permission. It is intentionally
    /// separate from an activated ability because taking the action does not
    /// use the stack.
    /// "That player may sacrifice a permanent of their choice for that player
    /// to ignore this effect until end of turn." (Damping Engine)
    /// "You can't choose <forbidden> as this spell's target as you cast it."
    /// "As this Equipment enters, choose <filter> it could be attached to.
    /// If you do, it enters attached to that <object>." (Grifter's Blade)
    pub fn enters_attached_to_chosen_object(
        filter: ObjectFilter,
        display: impl Into<String>,
    ) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::EntersAttachedToChosenObject),
            label: display.clone(),
            payload: StaticAbilityPayload::EntersAttachedToChosenObject { filter, display },
        }
    }

    /// "<Spells|Activated abilities> cost an additional \"Sacrifice a
    /// <filter>\" ... for each <color> mana symbol in their <mana|activation>
    /// costs." (Drought)
    pub fn additional_sacrifice_per_mana_symbol(
        activated_abilities: bool,
        symbol: crate::mana::ManaSymbol,
        sacrifice: ObjectFilter,
        display: impl Into<String>,
    ) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::AdditionalSacrificePerManaSymbol),
            label: display.clone(),
            payload: StaticAbilityPayload::AdditionalSacrificePerManaSymbol {
                activated_abilities,
                symbol,
                sacrifice,
                display,
            },
        }
    }

    /// "If a spell or ability you control would counter a spell, instead
    /// exile that spell and you may play that card without paying its mana
    /// cost." (Guile)
    pub fn controller_counter_exile_permission(
        permission: crate::effect::CounterExilePermission,
        display: impl Into<String>,
    ) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::ControllerCounterExilePermission),
            label: display.clone(),
            payload: StaticAbilityPayload::ControllerCounterExilePermission { permission, display },
        }
    }

    /// "The attacking player chooses how each creature blocks each combat."
    /// (Invasion Plans)
    pub fn attacking_player_chooses_blocks(display: impl Into<String>) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::AttackingPlayerChoosesBlocks),
            label: display.clone(),
            payload: StaticAbilityPayload::AttackingPlayerChoosesBlocks { display },
        }
    }

    /// "Its controller may exile three cards from their graveyard for that
    /// player to ignore this effect until end of turn." (Lost in Thought)
    pub fn attached_controller_may_pay_cost_to_ignore_source_effect_until_end_of_turn(
        cost: TotalCost<C>,
        display: impl Into<String>,
    ) -> Self {
        let display = display.into();
        Self {
            id: Some(
                StaticAbilityId::AttachedControllerMayPayCostToIgnoreSourceEffectUntilEndOfTurn,
            ),
            label: display.clone(),
            payload: StaticAbilityPayload::AttachedControllerMayPayCostToIgnoreSourceEffectUntilEndOfTurn {
                cost,
                display,
            },
        }
    }

    pub fn cast_target_restriction(forbidden: ObjectFilter, display: impl Into<String>) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::ThisSpellCastRestriction),
            label: display.clone(),
            payload: StaticAbilityPayload::CastTargetRestriction { forbidden, display },
        }
    }

    pub fn player_may_sacrifice_permanent_to_ignore_source_effect_until_end_of_turn(
        player: PlayerFilter,
        display: impl Into<String>,
    ) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::PlayerMaySacrificePermanentToIgnoreSourceEffectUntilEndOfTurn),
            label: display.clone(),
            payload: StaticAbilityPayload::PlayerMaySacrificePermanentToIgnoreSourceEffectUntilEndOfTurn {
                player,
                display,
            },
        }
    }

    pub fn any_player_may_pay_mana_to_ignore_source_effect_until_end_of_turn(
        cost: ManaCost,
        display: impl Into<String>,
    ) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::AnyPlayerMayPayManaToIgnoreSourceEffectUntilEndOfTurn),
            label: display.clone(),
            payload: StaticAbilityPayload::AnyPlayerMayPayManaToIgnoreSourceEffectUntilEndOfTurn {
                cost,
                display,
            },
        }
    }

    pub fn all_creatures_attack_attached_controller_each_combat_if_able() -> Self {
        Self::identified(
            StaticAbilityId::AllCreaturesAttackAttachedControllerEachCombatIfAble,
            "All creatures attack enchanted creature's controller each combat if able",
        )
    }

    pub fn must_block() -> Self {
        Self::identified(StaticAbilityId::MustBlock, "must block")
    }

    pub fn unblockable() -> Self {
        Self::identified(StaticAbilityId::Unblockable, "unblockable")
    }

    pub fn make_colorless(filter: ObjectFilter) -> Self {
        Self {
            id: Some(StaticAbilityId::MakeColorless),
            label: "make colorless".to_string(),
            payload: StaticAbilityPayload::MakeColorless(filter),
        }
    }

    pub fn cant_block() -> Self {
        Self {
            id: Some(StaticAbilityId::CantBlock),
            label: "cant block".to_string(),
            payload: StaticAbilityPayload::None,
        }
    }

    pub fn grants(spec: GrantSpecModel<T, E, C, Cond, ICond>) -> Self {
        Self {
            id: Some(StaticAbilityId::Grants),
            label: "grants".to_string(),
            payload: StaticAbilityPayload::Grants(Box::new(spec)),
        }
    }

    pub fn set_base_power_toughness(filter: ObjectFilter, power: i32, toughness: i32) -> Self {
        Self {
            id: Some(StaticAbilityId::SetBasePowerToughnessForFilter),
            label: "set base power toughness".to_string(),
            payload: StaticAbilityPayload::SetBasePowerToughness {
                filter,
                power,
                toughness,
            },
        }
    }

    pub fn set_base_power_toughness_value(
        filter: ObjectFilter,
        power: Value,
        toughness: Value,
    ) -> Self {
        Self {
            id: Some(StaticAbilityId::SetBasePowerToughnessForFilter),
            label: "set base power toughness value".to_string(),
            payload: StaticAbilityPayload::SetBasePowerToughnessValue {
                filter,
                power,
                toughness,
            },
        }
    }

    pub fn set_base_power(filter: ObjectFilter, power: i32) -> Self {
        Self {
            id: Some(StaticAbilityId::SetBasePowerToughnessForFilter),
            label: "set base power".to_string(),
            payload: StaticAbilityPayload::SetBasePower { filter, power },
        }
    }

    pub fn set_base_toughness(filter: ObjectFilter, toughness: i32) -> Self {
        Self {
            id: Some(StaticAbilityId::SetBasePowerToughnessForFilter),
            label: "set base toughness".to_string(),
            payload: StaticAbilityPayload::SetBaseToughness { filter, toughness },
        }
    }

    pub fn source_characteristics_of_last_exiled_creature_card(
        filter: ObjectFilter,
        retained_subtypes: Vec<Subtype>,
    ) -> Self {
        Self {
            id: Some(StaticAbilityId::SourceCharacteristicsOfLastExiledCreatureCard),
            label: "source characteristics of last exiled creature card".to_string(),
            payload: StaticAbilityPayload::SourceCharacteristicsOfLastExiledCreatureCard {
                filter,
                retained_subtypes,
            },
        }
    }

    /// "As long as the top card of your graveyard is a creature card, this
    /// creature has the full text of that card and has the text ..."
    /// (Volrath's Shapeshifter).
    pub fn source_has_full_text_of_top_graveyard_card(
        filter: ObjectFilter,
        abilities: Vec<AbilityModel<T, E, C, Cond, ICond>>,
        ability_labels: Vec<String>,
        display: String,
    ) -> Self {
        Self {
            id: Some(StaticAbilityId::SourceHasFullTextOfTopGraveyardCard),
            label: display.clone(),
            payload: StaticAbilityPayload::SourceHasFullTextOfTopGraveyardCard {
                filter,
                abilities,
                ability_labels,
                display,
            },
        }
    }

    pub fn can_attack_as_though_no_defender() -> Self {
        Self::identified(
            StaticAbilityId::CanAttackAsThoughNoDefender,
            "can attack as though no defender",
        )
    }

    pub fn can_attack_as_though_haste() -> Self {
        Self::identified(
            StaticAbilityId::CanAttackAsThoughHaste,
            "can attack as though haste",
        )
    }

    /// "All creatures can attack your opponents and planeswalkers your
    /// opponents control as though those creatures had haste." (Frenzied
    /// Saddlebrute)
    pub fn creatures_can_attack_opponents_as_though_haste() -> Self {
        Self::identified(
            StaticAbilityId::CreaturesCanAttackOpponentsAsThoughHaste,
            "All creatures can attack your opponents and planeswalkers your opponents control as though those creatures had haste",
        )
    }

    pub fn set_colors(filter: ObjectFilter, colors: ColorSet) -> Self {
        Self {
            id: Some(StaticAbilityId::SetColors),
            label: "set colors".to_string(),
            payload: StaticAbilityPayload::SetColors { filter, colors, exclude_from_color_identity: false },
        }
    }

    pub fn set_colors_without_color_identity(filter: ObjectFilter, colors: ColorSet) -> Self {
        let mut ability = Self::set_colors(filter, colors);
        if let StaticAbilityPayload::SetColors { exclude_from_color_identity, .. } = &mut ability.payload {
            *exclude_from_color_identity = true;
        }
        ability
    }

    pub fn add_card_types(filter: ObjectFilter, card_types: Vec<CardType>) -> Self {
        Self {
            id: Some(StaticAbilityId::AddCardTypes),
            label: "add card types".to_string(),
            payload: StaticAbilityPayload::AddCardTypes { filter, card_types },
        }
    }

    pub fn remove_card_types(
        filter: ObjectFilter,
        card_types: Vec<CardType>,
        condition: Option<ICond>,
    ) -> Self {
        Self {
            id: Some(StaticAbilityId::RemoveCardTypes),
            label: "remove card types".to_string(),
            payload: StaticAbilityPayload::RemoveCardTypes {
                filter,
                card_types,
                condition,
            },
        }
    }

    pub fn add_subtypes(filter: ObjectFilter, subtypes: Vec<Subtype>) -> Self {
        Self {
            id: Some(StaticAbilityId::AddSubtypes),
            label: "add subtypes".to_string(),
            payload: StaticAbilityPayload::AddSubtypes { filter, subtypes },
        }
    }

    pub fn changeling() -> Self {
        Self::identified(StaticAbilityId::Changeling, "changeling")
    }

    pub fn living_metal() -> Self {
        Self::identified(StaticAbilityId::LivingMetal, "living metal")
    }

    pub fn ward(amount: impl Into<TotalCost<C>>) -> Self {
        Self {
            id: Some(StaticAbilityId::Ward),
            label: "ward".to_string(),
            payload: StaticAbilityPayload::Ward(amount.into()),
        }
    }

    pub fn can_block_additional_for_each(additional: u32, filter: ObjectFilter) -> Self {
        Self {
            id: Some(StaticAbilityId::CanBlockAdditionalForEach),
            label: "can block additional creatures per matching permanent".to_string(),
            payload: StaticAbilityPayload::CanBlockAdditionalForEach { additional, filter },
        }
    }

    pub fn can_block_any_number() -> Self {
        Self::identified(
            StaticAbilityId::CanBlockAnyNumber,
            "can block any number of creatures",
        )
    }

    pub fn can_block_additional_creature_each_combat(additional: usize) -> Self {
        Self {
            id: Some(StaticAbilityId::CanBlockAdditionalCreatureEachCombat),
            label: "can block additional creature".to_string(),
            payload: StaticAbilityPayload::CanBlockAdditionalCreatureEachCombat(additional),
        }
    }

    pub fn can_block_subtype_as_though_reach(subtype: Subtype) -> Self {
        let subtype_text = subtype.to_string();
        let plural = if subtype_text.ends_with('s') {
            subtype_text
        } else {
            format!("{subtype_text}s")
        };
        Self {
            id: Some(StaticAbilityId::CanBlockFlying),
            label: format!("This creature can block {plural} as though it had reach"),
            payload: StaticAbilityPayload::CanBlockAsThoughReachForSubtype(subtype),
        }
    }

    pub fn can_block_as_though_reach_subtype(&self) -> Option<Subtype> {
        match self.payload {
            StaticAbilityPayload::CanBlockAsThoughReachForSubtype(subtype) => Some(subtype),
            _ => None,
        }
    }

    pub fn can_block_as_though_no_landwalk() -> Self {
        Self {
            id: Some(StaticAbilityId::CanBlockAsThoughNoLandwalk),
            label: "This creature can block creatures with landwalk abilities as though they didn't have those abilities".to_string(),
            payload: StaticAbilityPayload::CanBlockAsThoughNoLandwalk,
        }
    }

    pub fn additional_spell_targets(filter: ObjectFilter, amount: u32) -> Self {
        Self { id: Some(StaticAbilityId::AdditionalSpellTargets), label: format!("You may choose up to {amount} additional targets for matching spells").into(), payload: StaticAbilityPayload::AdditionalSpellTargets { filter, amount } }
    }

    pub fn can_be_blocked_as_though_blockers_were_untapped(filter: ObjectFilter) -> Self {
        Self {
            id: Some(StaticAbilityId::CanBeBlockedAsThoughBlockersWereUntapped),
            label: "Matching creatures can block this creature as though they were untapped".into(),
            payload: StaticAbilityPayload::CanBeBlockedAsThoughBlockersWereUntapped(filter),
        }
    }

    pub fn trigger_event_projection(observed: TriggerProjectionEvent, sources: ObjectFilter, subjects: ObjectFilter, projected: TriggerProjectionEvent) -> Self {
        Self { id: Some(StaticAbilityId::TriggerEventProjection), label: "Project matching events onto the abilities of matching objects".into(), payload: StaticAbilityPayload::TriggerEventProjection { observed, sources, subjects, projected } }
    }

    pub fn can_block_as_though_untapped() -> Self {
        Self {
            id: Some(StaticAbilityId::CanBlockAsThoughUntapped),
            label: "This creature can block as though it were untapped".to_string(),
            payload: StaticAbilityPayload::CanBlockAsThoughUntapped,
        }
    }

    pub fn can_block_as_though_no_shadow() -> Self {
        Self {
            id: Some(StaticAbilityId::CanBlockAsThoughNoShadow),
            label:
                "This creature can block creatures with shadow as though they didn't have shadow"
                    .to_string(),
            payload: StaticAbilityPayload::CanBlockAsThoughNoShadow,
        }
    }

    pub fn blocks_as_though_no_shadow(&self) -> bool {
        matches!(self.payload, StaticAbilityPayload::CanBlockAsThoughNoShadow)
    }

    pub fn can_attack_players_who_attacked_controller_last_turn_as_though_no_defender() -> Self {
        Self {
            id: Some(StaticAbilityId::CanAttackAsThoughNoDefender),
            label: "This creature can attack players who attacked you during their last turn as though it didn't have defender".to_string(),
            payload: StaticAbilityPayload::CanAttackPlayersWhoAttackedControllerLastTurnAsThoughNoDefender,
        }
    }

    pub fn blocking_as_though_no_landwalk(spec: BlockingAsThoughNoLandwalkSpec) -> Self {
        Self {
            id: Some(StaticAbilityId::BlockingAsThoughNoLandwalk),
            label: spec.display.clone(),
            payload: StaticAbilityPayload::BlockingAsThoughNoLandwalk(spec),
        }
    }

    pub fn targeting_as_though_no_ability(spec: TargetingAsThoughNoAbilitySpec) -> Self {
        Self {
            id: Some(StaticAbilityId::TargetingAsThoughNoAbility),
            label: spec.display.clone(),
            payload: StaticAbilityPayload::TargetingAsThoughNoAbility(spec),
        }
    }

    pub fn doesnt_untap() -> Self {
        Self {
            id: Some(StaticAbilityId::DoesntUntap),
            label: "doesnt untap".to_string(),
            payload: StaticAbilityPayload::None,
        }
    }

    pub fn cant_attack() -> Self {
        Self::identified(StaticAbilityId::CantAttack, "cant attack")
    }

    pub fn enters_tapped_unless_condition(condition: ICond, display: impl Into<String>) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::EntersTappedUnlessCondition),
            label: display.clone(),
            payload: StaticAbilityPayload::EntersTappedUnlessCondition { condition, display },
        }
    }

    pub fn haste() -> Self {
        Self::identified(StaticAbilityId::Haste, "haste")
    }

    pub fn flying() -> Self {
        Self::identified(StaticAbilityId::Flying, "flying")
    }

    pub fn trample() -> Self {
        Self::identified(StaticAbilityId::Trample, "trample")
    }

    /// Trample over planeswalkers (CR 702.19c).
    pub fn trample_over_planeswalkers() -> Self {
        Self::identified(
            StaticAbilityId::TrampleOverPlaneswalkers,
            "trample over planeswalkers",
        )
    }

    pub fn menace() -> Self {
        Self::identified(StaticAbilityId::Menace, "menace")
    }

    pub fn banding() -> Self {
        Self::identified(StaticAbilityId::Banding, "banding")
    }

    pub fn hexproof() -> Self {
        Self::identified(StaticAbilityId::Hexproof, "hexproof")
    }

    pub fn improvise() -> Self {
        Self::identified(StaticAbilityId::Improvise, "improvise")
    }

    pub fn convoke() -> Self {
        Self::identified(StaticAbilityId::Convoke, "convoke")
    }

    pub fn affinity_for_artifacts() -> Self {
        Self::identified(
            StaticAbilityId::AffinityForArtifacts,
            "affinity for artifacts",
        )
    }

    pub fn delve() -> Self {
        Self::identified(StaticAbilityId::Delve, "delve")
    }

    pub fn first_strike() -> Self {
        Self::identified(StaticAbilityId::FirstStrike, "first strike")
    }

    pub fn double_strike() -> Self {
        Self::identified(StaticAbilityId::DoubleStrike, "double strike")
    }

    pub fn deathtouch() -> Self {
        Self::identified(StaticAbilityId::Deathtouch, "deathtouch")
    }

    pub fn lifelink() -> Self {
        Self::identified(StaticAbilityId::Lifelink, "lifelink")
    }

    pub fn vigilance() -> Self {
        Self::identified(StaticAbilityId::Vigilance, "vigilance")
    }

    pub fn reach() -> Self {
        Self::identified(StaticAbilityId::Reach, "reach")
    }

    pub fn defender() -> Self {
        Self::identified(StaticAbilityId::Defender, "defender")
    }

    pub fn phasing() -> Self {
        Self::identified(StaticAbilityId::Phasing, "phasing")
    }

    pub fn indestructible() -> Self {
        Self::identified(StaticAbilityId::Indestructible, "indestructible")
    }

    pub fn shroud() -> Self {
        Self::identified(StaticAbilityId::Shroud, "shroud")
    }

    pub fn wither() -> Self {
        Self::identified(StaticAbilityId::Wither, "wither")
    }

    pub fn infect() -> Self {
        Self::identified(StaticAbilityId::Infect, "infect")
    }

    pub fn cascade() -> Self {
        Self::identified(StaticAbilityId::Cascade, "cascade")
    }

    pub fn cascade_land_drop() -> Self {
        Self::identified(
            StaticAbilityId::CascadeLandDrop,
            "As you cascade, you may put a land card from among the exiled cards onto the battlefield tapped",
        )
    }

    pub fn read_ahead() -> Self {
        Self::identified(StaticAbilityId::ReadAhead, "read ahead")
    }

    pub fn skulk() -> Self {
        Self::identified(StaticAbilityId::Skulk, "skulk")
    }

    pub fn prowess() -> Self {
        Self::identified(StaticAbilityId::Prowess, "prowess")
    }

    pub fn granted_inline_ability(&self) -> Option<&AbilityModel<T, E, C, Cond>> {
        None
    }

    pub fn toxic(amount: u32) -> Self {
        Self {
            id: Some(StaticAbilityId::Toxic),
            label: format!("toxic {amount}"),
            payload: StaticAbilityPayload::Toxic { amount },
        }
    }

    pub fn unleash() -> Self {
        Self::identified(StaticAbilityId::Unleash, "unleash")
    }

    pub fn any_landwalk() -> Self {
        Self::new(LandwalkKind::AnyLand)
    }

    pub fn nonbasic_landwalk() -> Self {
        Self::new(LandwalkKind::NonbasicLand)
    }

    pub fn artifact_landwalk() -> Self {
        Self::new(LandwalkKind::ArtifactLand)
    }

    pub fn legendary_landwalk() -> Self {
        Self::new(LandwalkKind::LegendaryLand)
    }

    pub fn snow_any_landwalk() -> Self {
        Self::new(LandwalkKind::SnowLand)
    }

    pub fn chosen_type_landwalk(snow: bool) -> Self {
        Self::new(LandwalkKind::ChosenType { snow })
    }

    pub fn sacrificed_land_types_landwalk() -> Self {
        Self::new(LandwalkKind::SacrificedLandTypes)
    }

    pub fn landwalk(kind: Subtype) -> Self {
        Self::new(LandwalkKind::Subtype {
            subtype: kind,
            snow: false,
        })
    }

    pub fn snow_landwalk(subtype: Subtype) -> Self {
        Self::new(LandwalkKind::Subtype {
            subtype,
            snow: true,
        })
    }

    pub fn hexproof_from(filter: ObjectFilter) -> Self {
        Self {
            id: Some(StaticAbilityId::HexproofFrom),
            label: "hexproof from".into(),
            payload: StaticAbilityPayload::HexproofFrom(filter),
        }
    }

    pub fn id(&self) -> StaticAbilityId {
        self.id.unwrap_or(StaticAbilityId::RuleFallbackText)
    }

    pub fn display(&self) -> String {
        self.label.clone()
    }

    pub fn with_text(mut self, text: impl Into<String>) -> Self {
        self.label = text.into();
        self
    }

    /// Retain the authored noun used for a payloadless leaf ability's source.
    /// This is presentation metadata; the ability id continues to carry the
    /// executable behavior.
    pub fn with_self_subject_surface(mut self, surface: SourceReferenceSurface) -> Self {
        if matches!(self.payload, StaticAbilityPayload::None) {
            self.payload = StaticAbilityPayload::SelfSubjectSurface { surface };
        }
        self
    }

    pub fn with_condition(self, condition: ICond) -> Self {
        match self.payload {
            StaticAbilityPayload::CostIncrease(mut increase) => {
                increase.condition = Some(match increase.condition {
                    Some(existing) => existing.and(condition),
                    None => condition,
                });
                StaticAbility {
                    id: self.id,
                    label: self.label,
                    payload: StaticAbilityPayload::CostIncrease(increase),
                }
            }
            StaticAbilityPayload::ActivatedAbilityCostIncrease {
                filter,
                increase,
                activator,
                non_mana_only,
                condition: existing,
                ability_condition,
                display,
            } => StaticAbility {
                id: self.id,
                label: self.label,
                payload: StaticAbilityPayload::ActivatedAbilityCostIncrease {
                    filter,
                    increase,
                    activator,
                    non_mana_only,
                    ability_condition,
                    display,
                    condition: Some(match existing {
                        Some(existing) => existing.and(condition),
                        None => condition,
                    }),
                },
            },
            StaticAbilityPayload::Conditional {
                ability,
                condition: existing,
                implied_words: false,
            } => {
                let combined = existing.and(condition);
                StaticAbility {
                    id: ability.id,
                    label: ability.label.clone(),
                    payload: StaticAbilityPayload::Conditional {
                        implied_words: false,
                        ability,
                        condition: combined,
                    },
                }
            }
            payload => {
                let ability = StaticAbility {
                    id: self.id,
                    label: self.label,
                    payload,
                };
                StaticAbility {
                    id: ability.id,
                    label: ability.label.clone(),
                    payload: StaticAbilityPayload::Conditional {
                        implied_words: false,
                        ability: Box::new(ability),
                        condition,
                    },
                }
            }
        }
    }

    /// Wrap this ability in a condition while preserving the Oracle label that
    /// presented that condition (for example, `Max speed`).
    ///
    /// The label belongs to the wrapper rather than the underlying ability so
    /// runtime behavior remains entirely driven by `condition`.
    pub fn with_labeled_condition(self, condition: ICond, label: impl Into<String>) -> Self {
        let id = self.id;
        Self {
            id,
            label: label.into(),
            payload: StaticAbilityPayload::Conditional {
                implied_words: false,
                ability: Box::new(self),
                condition,
            },
        }
    }

    /// Preserve a generated condition/body as an independent word-provenance
    /// scope. An authored outer condition can still be edited independently.
    pub fn with_implied_condition(self, condition: ICond) -> Self {
        Self {
            id: self.id,
            label: self.label.clone(),
            payload: StaticAbilityPayload::Conditional {
                ability: Box::new(self), condition, implied_words: true,
            },
        }
    }

    pub fn unwrap_or(self, _fallback: Self) -> Self {
        self
    }
    pub fn unwrap_or_else<F: FnOnce() -> Self>(self, _fallback: F) -> Self {
        self
    }

    pub fn unsupported_parser_line(text: impl Into<String>, reason: impl Into<String>) -> Self {
        Self::new(format!("{} ({})", text.into(), reason.into()))
    }

    pub fn characteristic_defining_pt(
        power: impl Into<Value>,
        toughness: impl Into<Value>,
    ) -> Self {
        Self {
            id: Some(StaticAbilityId::CharacteristicDefiningPT),
            label: "characteristic defining pt".to_string(),
            payload: StaticAbilityPayload::CharacteristicDefiningPt {
                power: power.into(),
                toughness: toughness.into(),
            },
        }
    }

    pub fn cant_be_blocked_by_more_than(count: usize) -> Self {
        Self {
            id: Some(StaticAbilityId::CantBeBlockedByMoreThan),
            label: format!("can't be blocked by more than {count} creature"),
            payload: StaticAbilityPayload::CantBeBlockedByMoreThan(count),
        }
    }

    pub fn cant_be_blocked_except_by_n_or_more(count: usize) -> Self {
        Self {
            id: Some(StaticAbilityId::CantBeBlockedExceptByNOrMore),
            label: format!("can't be blocked except by {count} or more creatures"),
            payload: StaticAbilityPayload::CantBeBlockedExceptByNOrMore(count),
        }
    }
    pub fn enters_tapped_ability() -> Self {
        Self::identified(StaticAbilityId::EntersTapped, "enters tapped")
    }
    pub fn enters_prepared_ability() -> Self {
        Self::identified(StaticAbilityId::EntersPrepared, "enters prepared")
    }
    pub fn remove_all_abilities(filter: ObjectFilter) -> Self {
        Self {
            id: Some(StaticAbilityId::RemoveAllAbilitiesForFilter),
            label: "remove all abilities".to_string(),
            payload: StaticAbilityPayload::RemoveAllAbilities(filter),
        }
    }
    pub fn can_block_only_flying() -> Self {
        Self::identified(StaticAbilityId::CanBlockOnlyFlying, "can block only flying")
    }
    pub fn partner() -> Self {
        Self {
            id: Some(StaticAbilityId::Partner),
            label: "partner".to_string(),
            payload: StaticAbilityPayload::CommanderPairing {
                partner_with: None,
                group: None,
                choose_background: false,
            },
        }
    }
    /// A partner variant keyword ("Partner—Survivors", "Choose a
    /// Background"). The keyword itself names the pairing group.
    pub fn partner_variant(display: impl AsRef<str>) -> Self {
        let keyword = display.as_ref().trim();
        let normalized = keyword.to_lowercase();
        let choose_background = normalized == "choose a background";
        Self {
            id: Some(StaticAbilityId::Partner),
            label: keyword.to_string(),
            payload: StaticAbilityPayload::CommanderPairing {
                partner_with: None,
                group: (!choose_background)
                    .then(|| partner_group_identifier(&normalized))
                    .flatten(),
                choose_background,
            },
        }
    }
    pub fn partner_with(partner_name: impl AsRef<str>) -> Self {
        let partner_name = partner_name.as_ref().trim();
        Self {
            id: Some(StaticAbilityId::PartnerWith),
            label: format!("partner with {partner_name}"),
            payload: StaticAbilityPayload::CommanderPairing {
                partner_with: Some(partner_name.to_string()),
                group: None,
                choose_background: false,
            },
        }
    }
    pub fn start_your_engines() -> Self {
        Self::identified(StaticAbilityId::StartYourEngines, "start your engines")
    }
    pub fn space_sculptor() -> Self {
        Self::identified(StaticAbilityId::SpaceSculptor, "space sculptor")
    }
    pub fn assist() -> Self {
        Self::identified(StaticAbilityId::Assist, "assist")
    }
    pub fn ascend() -> Self {
        Self::identified(StaticAbilityId::Ascend, "ascend")
    }
    pub fn storied() -> Self {
        Self::identified(StaticAbilityId::Storied, "storied")
    }
    pub fn split_second() -> Self {
        Self::identified(StaticAbilityId::SplitSecond, "split second")
    }
    pub fn rebound() -> Self {
        Self::identified(StaticAbilityId::Rebound, "rebound")
    }
    pub fn fear() -> Self {
        Self::identified(StaticAbilityId::Fear, "fear")
    }
    pub fn intimidate() -> Self {
        Self::identified(StaticAbilityId::Intimidate, "intimidate")
    }
    pub fn shadow() -> Self {
        Self::identified(StaticAbilityId::Shadow, "shadow")
    }
    pub fn horsemanship() -> Self {
        Self::identified(StaticAbilityId::Horsemanship, "horsemanship")
    }
    pub fn flanking() -> Self {
        Self::identified(StaticAbilityId::Flanking, "flanking")
    }
    pub fn umbra_armor() -> Self {
        Self::identified(StaticAbilityId::UmbraArmor, "umbra armor")
    }
    pub fn bloodthirst(amount: u32) -> Self {
        Self {
            id: Some(StaticAbilityId::Bloodthirst),
            label: format!("bloodthirst {amount}"),
            payload: StaticAbilityPayload::Bloodthirst(amount),
        }
    }
    pub fn tribute(amount: u32) -> Self {
        Self {
            id: Some(StaticAbilityId::Tribute),
            label: format!("tribute {amount}"),
            payload: StaticAbilityPayload::Tribute(amount),
        }
    }
    pub fn krrik_black_mana_may_be_paid_with_life() -> Self {
        Self {
            id: Some(StaticAbilityId::BlackManaMayBePaidWithLife),
            label: "krrik".into(),
            payload: StaticAbilityPayload::None,
        }
    }
    pub fn spell_mana_spending_rule(&self) -> Option<&crate::mana::ManaSpendingRestriction> {
        match &self.payload {
            StaticAbilityPayload::SpellManaSpendingRestriction(rule) => Some(rule),
            StaticAbilityPayload::Conditional { ability, .. } => ability.spell_mana_spending_rule(),
            _ => None,
        }
    }

    pub fn spell_mana_spending_restriction(
        rule: crate::mana::ManaSpendingRestriction,
        display: impl Into<String>,
    ) -> Self {
        Self {
            id: Some(StaticAbilityId::SpellManaSpendingRestriction),
            label: display.into(),
            payload: StaticAbilityPayload::SpellManaSpendingRestriction(rule),
        }
    }

    pub fn minimum_spell_total_mana(amount: u32) -> Self {
        Self {
            id: Some(StaticAbilityId::MinimumSpellTotalMana),
            label: "minimum spell total mana".into(),
            payload: StaticAbilityPayload::MinimumSpellTotalMana(amount),
        }
    }
    pub fn cant_pay_life_or_sacrifice_nonland_for_cast_or_activate() -> Self {
        Self {
            id: Some(StaticAbilityId::CantPayLifeOrSacrificeNonlandForCastOrActivate),
            label: "cant pay life or sac nonland".into(),
            payload: StaticAbilityPayload::None,
        }
    }
    pub fn cant_attack_unless_condition(
        condition: CantAttackUnlessConditionSpec<ICond>,
        display: impl Into<String>,
    ) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::CantAttackUnlessCondition),
            label: display.clone(),
            payload: StaticAbilityPayload::CantAttackUnlessCondition { condition, display },
        }
    }
    pub fn attack_cost(
        attackers: ObjectFilter,
        covers_planeswalkers: bool,
        cost: TotalCost<C>,
        display: impl Into<String>,
    ) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::AttackCost),
            label: display.clone(),
            payload: StaticAbilityPayload::AttackCost {
                attackers,
                covers_planeswalkers,
                cost,
                display,
                planeswalkers_only: false,
            },
        }
    }

    /// Restricts an attack cost to attacks on the controller's planeswalkers
    /// ("can't attack planeswalkers you control unless ..."). No-op for other
    /// payloads.
    pub fn with_attack_cost_planeswalkers_only(mut self) -> Self {
        if let StaticAbilityPayload::AttackCost {
            covers_planeswalkers,
            planeswalkers_only,
            ..
        } = &mut self.payload
        {
            *covers_planeswalkers = true;
            *planeswalkers_only = true;
        }
        self
    }

    pub fn block_cost(
        blockers: ObjectFilter,
        attackers: ObjectFilter,
        cost: TotalCost<C>,
        display: impl Into<String>,
    ) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::BlockCost),
            label: display.clone(),
            payload: StaticAbilityPayload::BlockCost {
                blockers,
                blocker_is_attached_to_source: false,
                attackers,
                cost,
                display,
                also_attack_cost: false,
                attack_only: false,
            },
        }
    }
    /// Marks a block cost as also charged when that creature attacks
    /// ("can't attack or block unless ..."). No-op for other payloads.
    pub fn with_block_cost_also_attacking(mut self) -> Self {
        if let StaticAbilityPayload::BlockCost {
            also_attack_cost, ..
        } = &mut self.payload
        {
            *also_attack_cost = true;
        }
        self
    }

    /// Marks a block cost as an attack-only cost ("can't attack unless ...").
    /// No-op for other payloads.
    pub fn with_block_cost_attack_only(mut self) -> Self {
        if let StaticAbilityPayload::BlockCost {
            also_attack_cost,
            attack_only,
            ..
        } = &mut self.payload
        {
            *also_attack_cost = true;
            *attack_only = true;
        }
        self
    }

    pub fn attached_block_cost(
        blockers: ObjectFilter,
        attackers: ObjectFilter,
        cost: TotalCost<C>,
        display: impl Into<String>,
    ) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::BlockCost),
            label: display.clone(),
            payload: StaticAbilityPayload::BlockCost {
                blockers,
                blocker_is_attached_to_source: true,
                attackers,
                cost,
                display,
                also_attack_cost: false,
                attack_only: false,
            },
        }
    }
    pub fn lethal_damage_must_be_from_single_source() -> Self {
        Self {
            id: Some(StaticAbilityId::LethalDamageMustBeFromSingleSource),
            label: "lethal damage must be from a single source".into(),
            payload: StaticAbilityPayload::None,
        }
    }
    pub fn creatures_cant_attack_players_inactive_last_turn() -> Self {
        Self {
            id: Some(StaticAbilityId::CreaturesCantAttackPlayersInactiveLastTurn),
            label: "creatures cant attack a player unless that player cast a spell or put a nontoken permanent onto the battlefield during their last turn".into(),
            payload: StaticAbilityPayload::None,
        }
    }
    pub fn cant_attack_player_already_attacked_this_turn() -> Self {
        Self {
            id: Some(StaticAbilityId::CantAttackPlayerAlreadyAttackedThisTurn),
            label: "cant attack a player it has already attacked this turn".into(),
            payload: StaticAbilityPayload::None,
        }
    }
    pub fn cant_attack_its_owner() -> Self {
        Self {
            id: Some(StaticAbilityId::CantAttackItsOwner),
            label: "cant attack its owner".into(),
            payload: StaticAbilityPayload::None,
        }
    }
    pub fn reduce_activated_ability_costs(
        filter: ObjectFilter,
        reduction: u32,
        minimum_total_mana: Option<u32>,
    ) -> Self {
        Self {
            id: Some(StaticAbilityId::ActivatedAbilityCostReduction),
            label: "reduce activated ability costs".into(),
            payload: StaticAbilityPayload::ActivatedAbilityCostReduction {
                optional: false,
                filter,
                reduction,
                replacement_mana_cost: None,
                display: None,
                condition: None,
                per_matching_objects: None,
                per_basic_land_types_among: None,
                multiplier: None,
                minimum_total_mana,
                reduction_mana: None,
            },
        }
    }
    pub fn reduce_activated_ability_costs_with_display(
        filter: ObjectFilter,
        reduction: u32,
        minimum_total_mana: Option<u32>,
        display: impl Into<String>,
    ) -> Self {
        Self {
            id: Some(StaticAbilityId::ActivatedAbilityCostReduction),
            label: "reduce activated ability costs".into(),
            payload: StaticAbilityPayload::ActivatedAbilityCostReduction {
                optional: false,
                filter,
                reduction,
                replacement_mana_cost: None,
                display: Some(display.into()),
                condition: None,
                per_matching_objects: None,
                per_basic_land_types_among: None,
                multiplier: None,
                minimum_total_mana,
                reduction_mana: None,
            },
        }
    }
    /// Add an independent gate without losing an existing target/ability gate.
    pub fn with_activated_ability_cost_condition(
        mut self,
        condition: ActivatedAbilityCostCondition,
    ) -> Self {
        fn add<T, E, C, Cond, ICond>(
            ability: &mut StaticAbility<T, E, C, Cond, ICond>,
            condition: ActivatedAbilityCostCondition,
        ) {
            let existing = match &mut ability.payload {
                StaticAbilityPayload::ActivatedAbilityCostReduction { condition, .. } => condition,
                StaticAbilityPayload::ActivatedAbilityCostIncrease {
                    ability_condition, ..
                } => ability_condition,
                StaticAbilityPayload::Conditional { ability, .. } => {
                    add(ability, condition);
                    return;
                }
                _ => return,
            };
            *existing = Some(match existing.take() {
                None => condition,
                Some(old) if old == condition => old,
                Some(old) => ActivatedAbilityCostCondition::All(vec![old, condition]),
            });
        }
        add(&mut self, condition);
        self
    }
    pub fn reduce_activated_ability_costs_if_targets(
        filter: ObjectFilter,
        reduction: u32,
        condition: ActivatedAbilityCostCondition,
        minimum_total_mana: Option<u32>,
    ) -> Self {
        Self {
            id: Some(StaticAbilityId::ActivatedAbilityCostReduction),
            label: "reduce activated ability costs if targets".into(),
            payload: StaticAbilityPayload::ActivatedAbilityCostReduction {
                optional: false,
                filter,
                reduction,
                replacement_mana_cost: None,
                display: None,
                condition: Some(condition),
                per_matching_objects: None,
                per_basic_land_types_among: None,
                multiplier: None,
                minimum_total_mana,
                reduction_mana: None,
            },
        }
    }
    pub fn reduce_activated_ability_costs_for_each(
        filter: ObjectFilter,
        reduction: u32,
        per_filter: ObjectFilter,
        minimum_total_mana: Option<u32>,
    ) -> Self {
        Self {
            id: Some(StaticAbilityId::ActivatedAbilityCostReduction),
            label: "reduce activated ability costs for each".into(),
            payload: StaticAbilityPayload::ActivatedAbilityCostReduction {
                optional: false,
                filter,
                reduction,
                replacement_mana_cost: None,
                display: None,
                condition: None,
                per_matching_objects: Some(per_filter),
                per_basic_land_types_among: None,
                multiplier: None,
                minimum_total_mana,
                reduction_mana: None,
            },
        }
    }
    pub fn reduce_activated_ability_costs_for_each_basic_land_type(
        filter: ObjectFilter,
        reduction: u32,
        lands_filter: ObjectFilter,
        minimum_total_mana: Option<u32>,
    ) -> Self {
        Self {
            id: Some(StaticAbilityId::ActivatedAbilityCostReduction),
            label: "reduce activated ability costs for each basic land type".into(),
            payload: StaticAbilityPayload::ActivatedAbilityCostReduction {
                optional: false,
                filter,
                reduction,
                replacement_mana_cost: None,
                display: None,
                condition: None,
                per_matching_objects: None,
                per_basic_land_types_among: Some(lands_filter),
                multiplier: None,
                minimum_total_mana,
                reduction_mana: None,
            },
        }
    }
    pub fn replace_activated_ability_mana_cost(
        filter: ObjectFilter,
        replacement_mana_cost: ManaCost,
        display: impl Into<String>,
    ) -> Self {
        Self {
            id: Some(StaticAbilityId::ActivatedAbilityCostReduction),
            label: "replace activated ability mana cost".into(),
            payload: StaticAbilityPayload::ActivatedAbilityCostReduction {
                optional: false,
                filter,
                reduction: 0,
                replacement_mana_cost: Some(replacement_mana_cost),
                display: Some(display.into()),
                condition: None,
                per_matching_objects: None,
                per_basic_land_types_among: None,
                multiplier: None,
                minimum_total_mana: None,
                reduction_mana: None,
            },
        }
    }
    pub fn remove_all_abilities_except_mana(filter: ObjectFilter) -> Self {
        Self {
            id: Some(StaticAbilityId::RemoveAllAbilitiesExceptManaForFilter),
            label: "remove all abilities except mana".to_string(),
            payload: StaticAbilityPayload::RemoveAllAbilitiesExceptMana(filter),
        }
    }
    pub fn set_card_types(filter: ObjectFilter, card_types: Vec<CardType>) -> Self {
        Self {
            id: Some(StaticAbilityId::SetCardTypes),
            label: "set card types".to_string(),
            payload: StaticAbilityPayload::SetCardTypes { filter, card_types },
        }
    }

    pub fn set_card_types_with_surface(
        filter: ObjectFilter,
        card_types: Vec<CardType>,
        surface: impl Into<String>,
    ) -> Self {
        Self {
            id: Some(StaticAbilityId::SetCardTypes),
            label: surface.into(),
            payload: StaticAbilityPayload::SetCardTypes { filter, card_types },
        }
    }
    pub fn set_land_subtypes(filter: ObjectFilter, subtypes: Vec<Subtype>) -> Self {
        Self {
            id: Some(StaticAbilityId::SetLandSubtypes),
            label: "set land subtypes".to_string(),
            payload: StaticAbilityPayload::SetLandSubtypes { filter, subtypes },
        }
    }
    pub fn set_creature_subtypes(filter: ObjectFilter, subtypes: Vec<Subtype>) -> Self {
        Self {
            id: Some(StaticAbilityId::SetCreatureSubtypes),
            label: "set creature subtypes".to_string(),
            payload: StaticAbilityPayload::SetCreatureSubtypes { filter, subtypes },
        }
    }
    pub fn add_all_subtypes_of_family(filter: ObjectFilter, family: SubtypeFamily) -> Self {
        Self {
            id: Some(StaticAbilityId::AddAllSubtypesOfFamily),
            label: "add all subtypes of family".to_string(),
            payload: StaticAbilityPayload::AddAllSubtypesOfFamily { filter, family },
        }
    }
    pub fn prevent_constrained_damage_to_self_put_counters_instead(
        counter_type: CounterType,
        display: impl Into<String>,
        source_filter: Option<ObjectFilter>,
        combat_only: Option<bool>,
    ) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::PreventConstrainedDamageToSelfPutCountersInstead),
            label: display.clone(),
            payload: StaticAbilityPayload::PreventConstrainedDamageToSelfPutCountersInstead {
                counter_type,
                display,
                source_filter,
                combat_only,
            },
        }
    }
    pub fn prevent_damage_to_you_from_source_filter(
        amount: u32,
        source_filter: ObjectFilter,
        display: impl Into<String>,
    ) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::PreventDamageToYouFromSourceFilter),
            label: display.clone(),
            payload: StaticAbilityPayload::PreventDamageToYouFromSourceFilter {
                amount,
                source_filter,
                display,
            },
        }
    }
    pub fn opponents_must_target_flagbearers() -> Self {
        Self {
            id: Some(StaticAbilityId::OpponentsMustTargetFlagbearers),
            label: "While an opponent is choosing targets as part of casting a spell they control or activating an ability they control, that player must choose at least one Flagbearer on the battlefield if able".to_string(),
            payload: StaticAbilityPayload::OpponentsMustTargetFlagbearers,
        }
    }
    /// A player has protection from sources matching `source_filter`
    /// (CR 702.16): they can't be targeted, enchanted or dealt damage by
    /// them. The filter is evaluated with the protection's source as the
    /// filter source (so "the chosen card type" reads that permanent's choice).
    pub fn player_protection_from(
        player: PlayerFilter,
        source_filter: ObjectFilter,
        display: impl Into<String>,
    ) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::PlayerProtectionFrom),
            label: display.clone(),
            payload: StaticAbilityPayload::PlayerProtectionFrom {
                player,
                source_filter,
                display,
            },
        }
    }

    pub fn prevent_all_damage_to_you() -> Self {
        Self {
            id: Some(StaticAbilityId::PreventAllDamageToYou),
            label: "Prevent all damage that would be dealt to you".to_string(),
            payload: StaticAbilityPayload::PreventAllDamageToYou,
        }
    }
    pub fn search_limited_to_top_cards(
        searcher: PlayerFilter,
        count: u32,
        display: impl Into<String>,
    ) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::SearchLimitedToTopCards),
            label: display.clone(),
            payload: StaticAbilityPayload::SearchLimitedToTopCards {
                searcher,
                count,
                display,
            },
        }
    }
    pub fn untap_step_limit(
        player: PlayerFilter,
        filter: ObjectFilter,
        max: u32,
        display: impl Into<String>,
    ) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::UntapStepLimit),
            label: display.clone(),
            payload: StaticAbilityPayload::UntapStepLimit {
                player,
                filter,
                max,
                display,
            },
        }
    }
    pub fn untap_step_chosen_card_type_only(
        player: PlayerFilter,
        card_types: Vec<CardType>,
        display: impl Into<String>,
    ) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::UntapStepChosenCardTypeOnly),
            label: display.clone(),
            payload: StaticAbilityPayload::UntapStepChosenCardTypeOnly {
                player,
                card_types,
                display,
            },
        }
    }
    pub fn untap_during_each_other_players_untap_step(
        filter: ObjectFilter,
        display: impl Into<String>,
    ) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::UntapDuringEachOtherPlayersUntapStep),
            label: display.clone(),
            payload: StaticAbilityPayload::UntapDuringEachOtherPlayersUntapStep { filter, display, opponents_only: false },
        }
    }
    pub fn untap_during_each_opponents_untap_step(
        filter: ObjectFilter,
        display: impl Into<String>,
    ) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::UntapDuringEachOtherPlayersUntapStep),
            label: display.clone(),
            payload: StaticAbilityPayload::UntapDuringEachOtherPlayersUntapStep { filter, display, opponents_only: true },
        }
    }
    pub fn pregame_action(kind: PregameActionKind, display: impl Into<String>) -> Self {
        let text = display.into();
        Self {
            id: Some(StaticAbilityId::PregameAction),
            label: text.clone(),
            payload: StaticAbilityPayload::PregameAction {
                kind,
                text,
                effects: Vec::new(),
            },
        }
    }
    pub fn pregame_action_with_effects(
        kind: PregameActionKind,
        display: impl Into<String>,
        effects: Vec<E>,
    ) -> Self {
        let text = display.into();
        Self {
            id: Some(StaticAbilityId::PregameAction),
            label: text.clone(),
            payload: StaticAbilityPayload::PregameAction {
                kind,
                text,
                effects,
            },
        }
    }
    pub fn reduce_maximum_hand_size(player: PlayerFilter, by: u32) -> Self {
        Self {
            id: Some(StaticAbilityId::ReduceMaximumHandSize),
            label: "reduce maximum hand size".into(),
            payload: StaticAbilityPayload::ReduceMaximumHandSize { player, by },
        }
    }
    pub fn increase_maximum_hand_size(player: PlayerFilter, by: u32) -> Self {
        Self {
            id: Some(StaticAbilityId::IncreaseMaximumHandSize),
            label: "increase maximum hand size".into(),
            payload: StaticAbilityPayload::IncreaseMaximumHandSize { player, by },
        }
    }
    /// "All morph costs cost {N} more." (Exiled Doomsayer). Turning a
    /// permanent face up is a special action (CR 116.2b), so this shares the
    /// special-action-modifier id with the foretell/plot modifiers.
    pub fn morph_cost_increase(generic_increase: u32) -> Self {
        Self {
            id: Some(StaticAbilityId::ForetellSpecialActionModifier),
            label: format!("All morph costs cost {{{generic_increase}}} more."),
            payload: StaticAbilityPayload::MorphCostIncrease { generic_increase },
        }
    }
    /// "Unlock costs you pay cost {N} less." (Inquisitive Glimmer).
    /// Unlocking a door is a special action (CR 116.2m, 709.5c), so this
    /// shares the special-action-modifier id with the morph/foretell ones.
    pub fn unlock_cost_reduction(generic_reduction: u32) -> Self {
        Self {
            id: Some(StaticAbilityId::ForetellSpecialActionModifier),
            label: format!("Unlock costs you pay cost {{{generic_reduction}}} less."),
            payload: StaticAbilityPayload::UnlockCostReduction { generic_reduction },
        }
    }
    pub fn devotion_increase(amount: u32) -> Self {
        Self {
            id: Some(StaticAbilityId::DevotionIncrease),
            label: format!("Your devotion to each color and each combination of colors is increased by {amount}."),
            payload: StaticAbilityPayload::DevotionIncrease { amount },
        }
    }
    pub fn set_maximum_hand_size(player: PlayerFilter, amount: u32) -> Self {
        Self {
            id: Some(StaticAbilityId::SetMaximumHandSize),
            label: "set maximum hand size".into(),
            payload: StaticAbilityPayload::SetMaximumHandSize { player, amount },
        }
    }
    pub fn equipment_grant(abilities: Vec<StaticAbility<T, E, C, Cond, ICond>>) -> Self {
        Self {
            id: Some(StaticAbilityId::EquipmentGrant),
            label: "equipment grant".to_string(),
            payload: StaticAbilityPayload::EquipmentGrant(abilities),
        }
    }
    pub fn soulbond_shared_object_ability(ability: AbilityModel<T, E, C, Cond, ICond>) -> Self {
        let text = match &ability.kind {
            AbilityKind::Static(static_ability) => static_ability.label.clone(),
            AbilityKind::Triggered(_) | AbilityKind::Activated(_) => "an ability".to_string(),
        };
        Self {
            id: Some(StaticAbilityId::SoulbondSharedBonus),
            label: format!(
                "As long as this creature is paired with another creature, both creatures have \"{text}\""
            ),
            payload: StaticAbilityPayload::SoulbondSharedObjectAbility(Box::new(ability)),
        }
    }
    pub fn grant_object_ability_for_filter(
        filter: ObjectFilter,
        ability: AbilityModel<T, E, C, Cond, ICond>,
        display: impl Into<String>,
    ) -> Self {
        let display = display.into();
        Self::new(GrantObjectAbilityForFilter::new(filter, ability, display))
    }
    pub fn boast_twice_each_turn() -> Self {
        Self::identified(StaticAbilityId::BoastTwiceEachTurn, "boast twice each turn")
    }
    pub fn loyalty_abilities_twice_each_turn() -> Self {
        Self::identified(
            StaticAbilityId::LoyaltyAbilitiesTwiceEachTurn,
            "loyalty abilities twice each turn",
        )
    }
    pub fn first_equip_cost_alternative(display: impl Into<String>) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::FirstEquipCostAlternative),
            label: display.clone(),
            payload: StaticAbilityPayload::FirstEquipCostAlternative(display),
        }
    }
    pub fn equip_abilities_any_time() -> Self {
        Self::identified(
            StaticAbilityId::EquipAbilitiesAnyTime,
            "activate equip abilities any time",
        )
    }
    pub fn exhaust_abilities_as_though_unactivated_this_turn() -> Self {
        Self::identified(
            StaticAbilityId::ExhaustAbilitiesAsThoughUnactivatedThisTurn,
            "activate exhaust abilities as though unactivated this turn",
        )
    }
    pub fn vote_additional_time_while_voting() -> Self {
        Self::identified(
            StaticAbilityId::VoteAdditionalTimeWhileVoting,
            "vote additional time while voting",
        )
    }
    /// The label is the noted card family's name.
    pub fn must_attack_draft_noted_players(card_name: impl Into<String>) -> Self {
        let card_name = card_name.into();
        Self {
            id: Some(StaticAbilityId::MustAttackDraftNotedPlayers),
            label: card_name.clone(),
            payload: StaticAbilityPayload::MustAttackDraftNotedPlayers { card_name },
        }
    }
    pub fn may_discard_source_any_time_you_could_cast_instant() -> Self {
        Self::identified(
            StaticAbilityId::MayDiscardSourceAnyTimeYouCouldCastInstant,
            "you may discard this card any time you could cast an instant",
        )
    }
    pub fn may_plot_nonland_cards_from_top_of_library() -> Self {
        Self::identified(
            StaticAbilityId::MayPlotNonlandCardsFromTopOfLibrary,
            "you may plot nonland cards from the top of your library",
        )
    }
    pub fn source_loyalty_abilities_twice_each_turn() -> Self {
        Self::identified(
            StaticAbilityId::SourceLoyaltyAbilitiesTwiceEachTurn,
            "this permanent's loyalty abilities twice each turn",
        )
    }
    pub fn power_up_abilities_additional_time() -> Self {
        Self::identified(
            StaticAbilityId::PowerUpAbilitiesAdditionalTime,
            "power-up abilities of permanents you control an additional time",
        )
    }
    /// "If you would begin your draw step, you may skip that step instead.
    /// If you do, <effects>." (Fasting; CR 614.10)
    pub fn may_skip_draw_step_with_followup(if_you_do: Vec<E>, display: impl Into<String>) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::MaySkipDrawStepWithFollowup),
            label: display.clone(),
            payload: StaticAbilityPayload::MaySkipDrawStepWithFollowup { if_you_do, display },
        }
    }
    pub fn may_skip_turn_while_source_tapped_then_untap() -> Self {
        Self::identified(
            StaticAbilityId::MaySkipTurnWhileSourceTappedThenUntap,
            "if you would begin your turn while this artifact is tapped, you may skip that turn instead. if you do, untap this artifact",
        )
    }
    pub fn cant_be_blocked_unless_all_defending_creatures_block() -> Self {
        Self::identified(
            StaticAbilityId::CantBeBlockedUnlessAllDefendingCreaturesBlock,
            "can't be blocked unless all creatures defending player controls block it",
        )
    }
    pub fn opponents_attack_with_at_least_one_creature() -> Self {
        Self::identified(
            StaticAbilityId::OpponentsAttackWithAtLeastOneCreature,
            "each opponent must attack with at least one creature each combat if able",
        )
    }
    pub fn opponents_attack_you_with_at_least_one_creature() -> Self {
        Self::identified(
            StaticAbilityId::OpponentsAttackYouWithAtLeastOneCreature,
            "each opponent must attack you or a planeswalker you control with at least one creature each combat if able",
        )
    }
    pub fn lose_life_for_unspent_mana() -> Self {
        Self::identified(
            StaticAbilityId::LoseLifeForUnspentMana,
            "a player losing unspent mana causes that player to lose that much life",
        )
    }
    pub fn opponents_face_villainous_choice_additional_time() -> Self {
        Self::identified(
            StaticAbilityId::OpponentsFaceVillainousChoiceAdditionalTime,
            "opponents face villainous choices an additional time",
        )
    }
    pub fn vote_additional_vote_while_voting() -> Self {
        Self::identified(
            StaticAbilityId::VoteAdditionalVoteWhileVoting,
            "vote additional vote while voting",
        )
    }
    pub fn exert_attack(
        only_if_not_exerted_this_turn: bool,
        linked_trigger: Option<TriggeredAbility<T, E, ICond>>,
        display: impl Into<String>,
    ) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::ExertAttack),
            label: display.clone(),
            payload: StaticAbilityPayload::ExertAttack {
                only_if_not_exerted_this_turn,
                linked_trigger,
                display,
            },
        }
    }
    pub fn enlist_attack(
        linked_trigger: TriggeredAbility<T, E, ICond>,
        display: impl Into<String>,
    ) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::EnlistAttack),
            label: display.clone(),
            payload: StaticAbilityPayload::EnlistAttack {
                linked_trigger,
                display,
            },
        }
    }
    pub fn cant_attack_you_unless_controller_pays_per_attacker(cost: u32) -> Self {
        Self {
            id: Some(StaticAbilityId::CantAttackYouUnlessControllerPaysPerAttacker),
            label: "cant attack you unless pays per attacker".to_string(),
            payload: StaticAbilityPayload::CantAttackYouUnlessControllerPaysPerAttacker(cost),
        }
    }
    /// Oracle's planeswalker-inclusive wording, which also spells the payment as
    /// "for each of those creatures" rather than "for each creature they control
    /// that's attacking you".
    pub fn cant_attack_you_or_planeswalkers_unless_controller_pays_per_attacker(cost: u32) -> Self {
        Self {
            id: Some(StaticAbilityId::CantAttackYouOrPlaneswalkersUnlessControllerPaysPerAttacker),
            label: "cant attack you or planeswalkers unless pays per attacker".to_string(),
            payload:
                StaticAbilityPayload::CantAttackYouOrPlaneswalkersUnlessControllerPaysPerAttacker(
                    cost,
                ),
        }
    }
    pub fn cant_attack_you_unless_controller_pays_per_attacker_basic_land_types_among_lands_you_control()
    -> Self {
        Self {
            id: Some(
                StaticAbilityId::CantAttackYouUnlessControllerPaysPerAttackerBasicLandTypesAmongLandsYouControl,
            ),
            label: "cant attack you unless pays per attacker basic land types".to_string(),
            payload:
                StaticAbilityPayload::CantAttackYouUnlessControllerPaysPerAttackerBasicLandTypesAmongLandsYouControl,
        }
    }
    pub fn cant_be_blocked_by_power_or_less(power: i32) -> Self {
        Self {
            id: Some(StaticAbilityId::CantBeBlockedByPowerOrLess),
            label: format!("can't be blocked by creatures with power {power} or less"),
            payload: StaticAbilityPayload::CantBeBlockedByPowerOrLess(power),
        }
    }
    pub fn cant_be_blocked_by_power_or_greater(power: i32) -> Self {
        Self {
            id: Some(StaticAbilityId::CantBeBlockedByPowerOrGreater),
            label: format!("can't be blocked by creatures with power {power} or greater"),
            payload: StaticAbilityPayload::CantBeBlockedByPowerOrGreater(power),
        }
    }
    pub fn cant_attack_unless_controller_cast_creature_spell_this_turn() -> Self {
        Self::identified(
            StaticAbilityId::CantAttackUnlessControllerCastCreatureSpellThisTurn,
            "cant attack unless controller cast creature spell",
        )
    }
    pub fn cant_attack_unless_controller_cast_noncreature_spell_this_turn() -> Self {
        Self::identified(
            StaticAbilityId::CantAttackUnlessControllerCastNonCreatureSpellThisTurn,
            "cant attack unless controller cast noncreature spell",
        )
    }
    pub fn players_cant_gain_life() -> Self {
        Self::identified(
            StaticAbilityId::PlayersCantGainLife,
            "players cant gain life",
        )
    }
    pub fn players_cant_search() -> Self {
        Self::identified(StaticAbilityId::PlayersCantSearch, "players cant search")
    }
    pub fn damage_cant_be_prevented() -> Self {
        Self::identified(
            StaticAbilityId::DamageCantBePrevented,
            "damage cant be prevented",
        )
    }
    pub fn you_cant_lose_game() -> Self {
        Self::identified(StaticAbilityId::YouCantLoseGame, "you cant lose game")
    }
    pub fn opponents_cant_win_game() -> Self {
        Self::identified(
            StaticAbilityId::OpponentsCantWinGame,
            "opponents cant win game",
        )
    }
    pub fn your_life_total_cant_change() -> Self {
        Self::identified(
            StaticAbilityId::YourLifeTotalCantChange,
            "your life total cant change",
        )
    }
    pub fn opponents_cant_cast_spells() -> Self {
        Self::identified(
            StaticAbilityId::OpponentsCantCastSpells,
            "opponents cant cast spells",
        )
    }
    pub fn opponents_cant_draw_extra_cards() -> Self {
        Self::identified(
            StaticAbilityId::OpponentsCantDrawExtraCards,
            "opponents cant draw extra cards",
        )
    }
    pub fn cant_have_counters_placed() -> Self {
        Self::identified(
            StaticAbilityId::CantHaveCountersPlaced,
            "cant have counters placed",
        )
    }
    pub fn counter_limit(
        counter_type: CounterType,
        maximum: u32,
        display: impl Into<String>,
    ) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::CounterLimit),
            label: display.clone(),
            payload: StaticAbilityPayload::CounterLimit {
                counter_type,
                maximum,
                display,
            },
        }
    }
    pub fn cant_be_copied() -> Self {
        Self::identified(StaticAbilityId::CantBeCopied, "This spell can't be copied")
    }
    pub fn cant_be_countered_ability() -> Self {
        Self::identified(
            StaticAbilityId::CantBeCountered,
            "cant be countered ability",
        )
    }
    pub fn permanents_you_control_cant_be_sacrificed() -> Self {
        Self::identified(
            StaticAbilityId::PermanentsCantBeSacrificed,
            "permanents you control cant be sacrificed",
        )
    }
    pub fn cant_be_blocked_as_long_as_defending_player_controls_card_type(
        card_type: CardType,
    ) -> Self {
        Self::cant_be_blocked_as_long_as_defending_player_controls_card_types(vec![card_type])
    }
    pub fn cant_be_blocked_as_long_as_defending_player_controls_card_types(
        card_types: Vec<CardType>,
    ) -> Self {
        Self {
            id: Some(StaticAbilityId::RuleRestriction),
            label: "cant be blocked as long as defending controls card types".into(),
            payload: StaticAbilityPayload::CantBeBlockedAsLongAsDefendingPlayerControlsCardTypes(
                card_types,
            ),
        }
    }
    pub fn cant_be_blocked_unless_attacking_owner_or_owners_permanent() -> Self {
        Self::identified(
            StaticAbilityId::CantBeBlockedUnlessAttackingOwnerOrOwnersPermanent,
            "can't be blocked unless it's attacking its owner or a permanent its owner controls",
        )
    }
    pub fn cant_be_blocked_while_defending_player_controls_most_creatures() -> Self {
        Self::identified(
            StaticAbilityId::CantBeBlockedWhileDefendingPlayerControlsMostCreatures,
            "can't be blocked as long as defending player controls the most creatures or is tied for the most",
        )
    }
    pub fn set_name(filter: ObjectFilter, name: impl Into<String>) -> Self {
        let name = name.into();
        Self {
            id: Some(StaticAbilityId::SetName),
            label: format!("set name {name}"),
            payload: StaticAbilityPayload::SetName { filter, name },
        }
    }
    pub fn count_as_card_named_for_spell_effect(
        spell_name: impl Into<String>,
        counted_name: impl Into<String>,
    ) -> Self {
        let spell_name = spell_name.into();
        let counted_name = counted_name.into();
        Self {
            id: Some(StaticAbilityId::CountAsCardNamedForSpellEffect),
            label: format!(
                "If this card is in a graveyard, effects from spells named {spell_name} count it as a card named {counted_name}."
            ),
            payload: StaticAbilityPayload::CountAsCardNamedForSpellEffect {
                spell_name,
                counted_name,
            },
        }
    }
    pub fn soulbond_shared_power_toughness(power: i32, toughness: i32) -> Self {
        let signed = |value: i32| {
            if value >= 0 {
                format!("+{value}")
            } else {
                value.to_string()
            }
        };
        Self {
            id: Some(StaticAbilityId::SoulbondSharedBonus),
            label: format!(
                "As long as this creature is paired with another creature, each of those creatures gets {}/{}",
                signed(power),
                signed(toughness)
            ),
            payload: StaticAbilityPayload::SoulbondSharedPowerToughness { power, toughness },
        }
    }
    pub fn soulbond_shared_ability(ability: StaticAbility<T, E, C, Cond, ICond>) -> Self {
        let label = ability.display();
        Self {
            id: Some(StaticAbilityId::SoulbondSharedBonus),
            label: format!(
                "As long as this creature is paired with another creature, both creatures have {label}"
            ),
            payload: StaticAbilityPayload::SoulbondSharedAbility(Box::new(ability)),
        }
    }
    pub fn add_colors(filter: ObjectFilter, colors: ColorSet) -> Self {
        Self {
            id: Some(StaticAbilityId::AddColors),
            label: "add colors".to_string(),
            payload: StaticAbilityPayload::AddColors { filter, colors },
        }
    }
    pub fn control_attached_permanent(display: impl Into<String>) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::ControlAttachedPermanent),
            label: display.clone(),
            payload: StaticAbilityPayload::ControlAttachedPermanent(display),
        }
    }
    pub fn prevent_damage_to_self_remove_counter(
        counter_type: CounterType,
        amount: impl Into<Value>,
    ) -> Self {
        Self::prevent_damage_to_self_remove_counter_with_follow_up(counter_type, amount, None)
    }

    pub fn prevent_damage_to_self_remove_counter_with_follow_up(
        counter_type: CounterType,
        amount: impl Into<Value>,
        follow_up: Option<CounterRemovalFollowUp>,
    ) -> Self {
        Self {
            id: Some(StaticAbilityId::PreventDamageToSelfRemoveCounter),
            label: "prevent damage to self remove counter".to_string(),
            payload: StaticAbilityPayload::PreventDamageToSelfRemoveCounter {
                counter_type,
                amount: amount.into(),
                follow_up,
                one_damage_per_counter: false,
                surface: CounterRemovalPreventionSurface::Conjoined,
            },
        }
    }

    pub fn with_separate_counter_removal_sentence(mut self) -> Self {
        if let StaticAbilityPayload::PreventDamageToSelfRemoveCounter { surface, .. } =
            &mut self.payload
        {
            *surface = CounterRemovalPreventionSurface::SeparateSentences;
        }
        self
    }

    pub fn prevent_one_damage_to_self_per_removed_counter(counter_type: CounterType) -> Self {
        Self {
            id: Some(StaticAbilityId::PreventDamageToSelfRemoveCounter),
            label: "prevent one damage to self per removed counter".to_string(),
            payload: StaticAbilityPayload::PreventDamageToSelfRemoveCounter {
                counter_type,
                amount: Value::EventValue(crate::EventValueSpec::Amount),
                follow_up: None,
                one_damage_per_counter: true,
                surface: CounterRemovalPreventionSurface::Conjoined,
            },
        }
    }
    pub fn prevent_damage_to_self_put_counters_instead(
        counter_type: CounterType,
        display: impl Into<String>,
    ) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::PreventDamageToSelfPutCountersInstead),
            label: display.clone(),
            payload: StaticAbilityPayload::PreventDamageToSelfPutCountersInstead {
                counter_type,
                display,
            },
        }
    }
    /// "If damage would be dealt to this creature, instead that damage is
    /// dealt, but all other damage already dealt to it is healed."
    pub fn heal_damage_before_damage_to_self(display: impl Into<String>) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::HealDamageBeforeDamageToSelf),
            label: display.clone(),
            payload: StaticAbilityPayload::HealDamageBeforeDamageToSelf { display },
        }
    }

    pub fn damage_prevention_with_follow_up(
        source_filter: ObjectFilter,
        target_filter: ObjectFilter,
        combat_only: Option<bool>,
        recipient_tag: crate::tag::TagKey,
        effects: Vec<E>,
    ) -> Self {
        Self {
            id: Some(StaticAbilityId::DamagePreventionWithFollowUp),
            label: "damage prevention with follow-up".into(),
            payload: StaticAbilityPayload::DamagePreventionWithFollowUp {
                source_filter,
                target_filter,
                combat_only,
                recipient_tag,
                effects,
            },
        }
    }
    pub fn replace_damage_with_counters_instead(
        counter_type: CounterType,
        source_filter: ObjectFilter,
        target_filter: ObjectFilter,
        combat_only: Option<bool>,
        display: impl Into<String>,
    ) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::ReplaceDamageWithCountersInstead),
            label: display.clone(),
            payload: StaticAbilityPayload::ReplaceDamageWithCountersInstead {
                counter_type,
                display,
                source_filter,
                target_filter,
                combat_only,
            },
        }
    }
    pub fn add_supertypes(filter: ObjectFilter, supertypes: Vec<Supertype>) -> Self {
        Self {
            id: Some(StaticAbilityId::AddSupertypes),
            label: "add supertypes".to_string(),
            payload: StaticAbilityPayload::AddSupertypes { filter, supertypes },
        }
    }
    pub fn add_subtypes_and_grant_abilities(filter: ObjectFilter, subtypes: Vec<Subtype>, abilities: Vec<AbilityModel<T, E, C, Cond, ICond>>, display: impl Into<String>) -> Self {
        let display = display.into();
        Self { id: Some(StaticAbilityId::AddSubtypes), label: display.clone(),
            payload: StaticAbilityPayload::AddSubtypesAndGrantAbilities { filter, subtypes, abilities, display } }
    }
    pub fn damage_between_chosen_players(factor: u32, display: impl Into<String>) -> Self {
        let display = display.into();
        Self { id: Some(StaticAbilityId::ModifyDamageAmountReplacement), label: display.clone(),
            payload: StaticAbilityPayload::DamageBetweenChosenPlayers { factor, display } }
    }
    pub fn reveal_cards_drawn(player: PlayerFilter, display: impl Into<String>) -> Self {
        Self { id: Some(StaticAbilityId::RevealCardsDrawn), label: display.into(),
            payload: StaticAbilityPayload::RevealCardsDrawn { player } }
    }
    pub fn reveal_first_card_you_draw_each_turn(optional: bool, your_turns_only: bool) -> Self {
        Self {
            id: Some(StaticAbilityId::RevealFirstCardYouDrawEachTurn),
            label: "reveal first card".into(),
            payload: StaticAbilityPayload::RevealFirstCardYouDrawEachTurn {
                optional,
                your_turns_only,
                linked_reveal_pair: None,
            },
        }
    }
    pub fn increase_activated_ability_costs(filter: ObjectFilter, increase: TotalCost<C>) -> Self {
        Self {
            id: Some(StaticAbilityId::ActivatedAbilityCostIncrease),
            label: "increase activated ability costs".to_string(),
            payload: StaticAbilityPayload::ActivatedAbilityCostIncrease {
                filter,
                increase,
                activator: None,
                non_mana_only: false,
                condition: None,
                ability_condition: None,
                display: None,
            },
        }
    }
    /// "Activated abilities of <filter> cost <increase> more to activate
    /// unless they're mana abilities." (Anointed Peacekeeper)
    pub fn increase_non_mana_activated_ability_costs(
        filter: ObjectFilter,
        increase: TotalCost<C>,
    ) -> Self {
        Self {
            id: Some(StaticAbilityId::ActivatedAbilityCostIncrease),
            label: "increase activated ability costs".to_string(),
            payload: StaticAbilityPayload::ActivatedAbilityCostIncrease {
                filter,
                increase,
                activator: None,
                non_mana_only: true,
                condition: None,
                ability_condition: None,
                display: None,
            },
        }
    }
    pub fn increase_activated_ability_costs_for_activator(
        activator: PlayerFilter,
        increase: TotalCost<C>,
        non_mana_only: bool,
    ) -> Self {
        Self {
            id: Some(StaticAbilityId::ActivatedAbilityCostIncrease),
            label: "increase activated ability costs".to_string(),
            payload: StaticAbilityPayload::ActivatedAbilityCostIncrease {
                filter: ObjectFilter::default(),
                increase,
                activator: Some(activator),
                non_mana_only,
                condition: None,
                ability_condition: None,
                display: None,
            },
        }
    }
    pub fn cant_be_blocked_by_lower_power_than_source() -> Self {
        Self {
            id: Some(StaticAbilityId::CantBeBlockedByLowerPowerThanSource),
            label: "cant be blocked by lower power than source".into(),
            payload: StaticAbilityPayload::None,
        }
    }
    pub fn doctors_companion() -> Self {
        Self {
            id: Some(StaticAbilityId::DoctorsCompanion),
            label: "doctors companion".into(),
            payload: StaticAbilityPayload::None,
        }
    }
    pub fn conditional_spell_keyword(spec: ConditionalSpellKeywordSpec) -> Self {
        Self {
            id: Some(StaticAbilityId::ConditionalSpellKeyword),
            label: "conditional spell keyword".into(),
            payload: StaticAbilityPayload::ConditionalSpellKeyword(spec),
        }
    }
    pub fn damage_not_removed_during_cleanup() -> Self {
        Self::identified(
            StaticAbilityId::DamageNotRemovedDuringCleanup,
            "damage not removed during cleanup",
        )
    }
    pub fn choose_basic_land_type_as_enters(display: impl Into<String>) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::ChooseBasicLandTypeAsEnters),
            label: display.clone(),
            payload: StaticAbilityPayload::ChooseBasicLandTypeAsEnters(display),
        }
    }
    pub fn choose_basic_land_types_as_enters(display: impl Into<String>, count: u32) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::ChooseBasicLandTypeAsEnters),
            label: display.clone(),
            payload: StaticAbilityPayload::ChooseBasicLandTypesAsEnters { display, count },
        }
    }
    pub fn first_chosen_land_type_becomes_second(
        filter: ObjectFilter,
        display: impl Into<String>,
    ) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::SetLandSubtypes),
            label: display.clone(),
            payload: StaticAbilityPayload::FirstChosenLandTypeBecomesSecond { filter, display },
        }
    }
    pub fn choose_land_type_as_enters(display: impl Into<String>) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::ChooseLandTypeAsEnters),
            label: display.clone(),
            payload: StaticAbilityPayload::ChooseLandTypeAsEnters(display),
        }
    }
    pub fn source_land_is_chosen_type(display: impl Into<String>) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::SourceLandIsChosenType),
            label: display.clone(),
            payload: StaticAbilityPayload::SourceLandIsChosenType(display),
        }
    }
    pub fn enchant(filter: crate::AuraAttachmentFilter) -> Self {
        let description = match &filter {
            crate::AuraAttachmentFilter::Object(filter) => filter.description(),
            crate::AuraAttachmentFilter::Player(filter) => filter.description(),
        };
        let description = description
            .strip_prefix("an ")
            .or_else(|| description.strip_prefix("a "))
            .unwrap_or(&description);
        Self {
            id: Some(StaticAbilityId::Enchant),
            label: format!("Enchant {description}"),
            payload: StaticAbilityPayload::Enchant(filter),
        }
    }

    pub fn attached_is_copy_of_source(retain_original_types: bool) -> Self {
        Self {
            id: Some(StaticAbilityId::AttachedIsCopyOfSource),
            label: "attached copy of source".into(),
            payload: StaticAbilityPayload::AttachedIsCopyOfSource { retain_original_types },
        }
    }
    pub fn attached_is_copy_of_chosen_object(display: impl Into<String>) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::AttachedIsCopyOfChosenObject),
            label: display.clone(),
            payload: StaticAbilityPayload::AttachedIsCopyOfChosenObject(display),
        }
    }

    pub fn enchanted_land_is_chosen_type(display: impl Into<String>) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::EnchantedLandIsChosenType),
            label: display.clone(),
            payload: StaticAbilityPayload::EnchantedLandIsChosenType(display),
        }
    }
    pub fn add_chosen_creature_type(filter: ObjectFilter, display: impl Into<String>) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::AddChosenCreatureType),
            label: display.clone(),
            payload: StaticAbilityPayload::AddChosenCreatureType {
                filter,
                display,
                replace_existing: false,
            },
        }
    }
    /// "<objects> are the chosen type": their creature types become exactly
    /// the creature type chosen for the source.
    pub fn set_chosen_creature_type(filter: ObjectFilter, display: impl Into<String>) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::AddChosenCreatureType),
            label: display.clone(),
            payload: StaticAbilityPayload::AddChosenCreatureType {
                filter,
                display,
                replace_existing: true,
            },
        }
    }
    pub fn add_chosen_basic_land_type(filter: ObjectFilter, display: impl Into<String>) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::AddChosenBasicLandType),
            label: display.clone(),
            payload: StaticAbilityPayload::AddChosenBasicLandType { filter, display },
        }
    }
    pub fn add_chosen_color(filter: ObjectFilter, display: impl Into<String>) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::AddChosenColor),
            label: display.clone(),
            payload: StaticAbilityPayload::AddChosenColor { filter, display },
        }
    }
    pub fn set_chosen_color(filter: ObjectFilter, display: impl Into<String>) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::SetChosenColor),
            label: display.clone(),
            payload: StaticAbilityPayload::SetChosenColor { filter, display },
        }
    }
    pub fn choose_creature_type_as_enters(display: impl Into<String>) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::ChooseCreatureTypeAsEnters),
            label: display.clone(),
            payload: StaticAbilityPayload::ChooseCreatureTypeAsEnters(display),
        }
    }
    pub fn choose_named_option_as_enters(options: Vec<String>, display: impl Into<String>) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::ChooseNamedOptionAsEnters),
            label: display.clone(),
            payload: StaticAbilityPayload::ChooseNamedOptionAsEnters {
                options,
                display,
                at_random: false,
                each_player: false,
            },
        }
    }

    /// "As this enters, each player chooses <A> or <B>": every player
    /// chooses, and each player's option is recorded on the permanent.
    pub fn each_player_chooses_named_option_as_enters(
        options: Vec<String>,
        display: impl Into<String>,
    ) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::ChooseNamedOptionAsEnters),
            label: display.clone(),
            payload: StaticAbilityPayload::ChooseNamedOptionAsEnters {
                options,
                display,
                at_random: false,
                each_player: true,
            },
        }
    }

    pub fn choose_named_option_at_random_as_enters(
        options: Vec<String>,
        display: impl Into<String>,
    ) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::ChooseNamedOptionAsEnters),
            label: display.clone(),
            payload: StaticAbilityPayload::ChooseNamedOptionAsEnters {
                options,
                display,
                at_random: true,
                each_player: false,
            },
        }
    }

    pub fn choose_power_toughness_as_enters_or_turns_face_up(
        options: Vec<(i32, i32)>,
        display: impl Into<String>,
    ) -> Self {
        let options = options
            .into_iter()
            .map(|(power, toughness)| PowerToughnessChoiceOption::new(power, toughness))
            .collect();
        Self::choose_power_toughness_options_as_enters_or_turns_face_up(options, display)
    }

    pub fn choose_power_toughness_options_as_enters_or_turns_face_up(
        options: Vec<PowerToughnessChoiceOption<T, E, C, Cond, ICond>>,
        display: impl Into<String>,
    ) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::ChoosePowerToughnessAsEntersOrTurnsFaceUp),
            label: display.clone(),
            payload: StaticAbilityPayload::ChoosePowerToughnessAsEntersOrTurnsFaceUp {
                options,
                display,
                at_random: false,
            },
        }
    }

    /// "As this creature enters, flip a coin. If the coin comes up heads,
    /// this creature enters as a 5/2 creature with haste. If it comes up
    /// tails, ... a 2/5 creature with defender." (Molten Sentry).
    pub fn power_toughness_options_at_random_as_enters(
        options: Vec<PowerToughnessChoiceOption<T, E, C, Cond, ICond>>,
        display: impl Into<String>,
    ) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::ChoosePowerToughnessAsEntersOrTurnsFaceUp),
            label: display.clone(),
            payload: StaticAbilityPayload::ChoosePowerToughnessAsEntersOrTurnsFaceUp {
                options,
                display,
                at_random: true,
            },
        }
    }

    pub fn duplicate_matching_triggered_abilities(
        source_filter: Option<ObjectFilter>,
        event_matcher: Option<T>,
        count: u32,
        display: impl Into<String>,
    ) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::DuplicateMatchingTriggeredAbilities),
            label: display.clone(),
            payload: StaticAbilityPayload::DuplicateMatchingTriggeredAbilities {
                source_filter,
                event_matcher,
                count,
                display,
            },
        }
    }
    pub fn suppress_matching_triggered_abilities(
        source_filter: Option<ObjectFilter>,
        event_matcher: Option<T>,
        display: impl Into<String>,
    ) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::SuppressMatchingTriggeredAbilities),
            label: display.clone(),
            payload: StaticAbilityPayload::SuppressMatchingTriggeredAbilities {
                source_filter,
                event_matcher,
                display,
            },
        }
    }
    pub fn double_damage_from_sources_you_control_of_chosen_type(
        display: impl Into<String>,
    ) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::DoubleDamageFromSourcesYouControlOfChosenType),
            label: display.clone(),
            payload: StaticAbilityPayload::DoubleDamageFromSourcesYouControlOfChosenType(display),
        }
    }

    pub fn redirect_damage_to_source_controller(
        source_filter: ObjectFilter,
        target_player_filter: PlayerFilter,
        display: impl Into<String>,
    ) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::RedirectDamageToSourceController),
            label: display.clone(),
            payload: StaticAbilityPayload::RedirectDamageToSourceController {
                source_filter,
                target_player_filter,
                display,
            },
        }
    }
    pub fn with_enter_as_copy_as_enters(
        spec: EnterAsCopyAsEntersSpec<T, E, C, Cond, ICond>,
        display: impl Into<String>,
    ) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::EnterAsCopyAsEnters),
            label: display.clone(),
            payload: StaticAbilityPayload::EnterAsCopyAsEnters { spec, display },
        }
    }
    pub fn cast_announcement_program(program: ResolutionProgram<E>) -> Self {
        Self {id:None,label:"As you cast this spell".into(),payload:StaticAbilityPayload::CastAnnouncementProgram {program}}
    }
    pub fn spell_resolution_destination_program(
        origin_zone: Option<Zone>,
        destination: Zone,
        follow_up: ResolutionProgram<E>,
    ) -> Self {
        Self {
            id: None,
            label: format!("As this spell resolves, put it into {destination:?} and perform its continuation"),
            payload: StaticAbilityPayload::SpellResolutionDestinationProgram {
                origin_zone, destination, follow_up,
                multiplicity: SpellResolutionProgramMultiplicity::PerInstance,
            },
        }
    }

    pub fn with_spell_resolution_program_multiplicity(mut self, policy: SpellResolutionProgramMultiplicity) -> Self {
        if let StaticAbilityPayload::SpellResolutionDestinationProgram { multiplicity, .. } = &mut self.payload { *multiplicity = policy; }
        self
    }

    pub fn as_enters_effect_program(
        program: ResolutionProgram<E>,
        subject: impl Into<String>,
        also_turns_face_up: bool,
        uses_enters_with_counter_surface: bool,
        presentation_label: Option<PresentationLabel>,
    ) -> Self {
        let subject = subject.into();
        let label = if also_turns_face_up {
            format!("As {subject} enters or is turned face up")
        } else {
            format!("As {subject} enters")
        };
        Self {
            id: Some(StaticAbilityId::AsEntersEffectProgram),
            label,
            payload: StaticAbilityPayload::AsEntersEffectProgram {
                program,
                subject,
                also_turns_face_up,
                turns_face_up_only: false,
                uses_enters_with_counter_surface,
                transforms_into: None,
                transform_characteristics: None,
                presentation_label,
                entry_instead_surface: false,
            },
        }
    }
    /// Mark an "as enters" program as authored in the entry-replacement form
    /// "If this <permanent> would enter, instead <program>, then put this
    /// <permanent> onto the battlefield".
    pub fn with_entry_instead_surface(mut self) -> Self {
        if let StaticAbilityPayload::AsEntersEffectProgram {
            subject,
            entry_instead_surface,
            ..
        } = &mut self.payload
        {
            *entry_instead_surface = true;
            self.label = format!("If {subject} would enter");
        }
        self
    }
    pub fn as_turns_face_up_effect_program(
        program: ResolutionProgram<E>,
        subject: impl Into<String>,
        presentation_label: Option<PresentationLabel>,
    ) -> Self {
        let subject = subject.into();
        Self {
            id: Some(StaticAbilityId::AsEntersEffectProgram),
            label: format!("As {subject} is turned face up"),
            payload: StaticAbilityPayload::AsEntersEffectProgram {
                program,
                subject,
                also_turns_face_up: true,
                turns_face_up_only: true,
                uses_enters_with_counter_surface: false,
                transforms_into: None,
                transform_characteristics: None,
                presentation_label,
                entry_instead_surface: false,
            },
        }
    }
    pub fn as_transforms_effect_program(
        program: ResolutionProgram<E>,
        subject: impl Into<String>,
        destination: impl Into<String>,
        presentation_label: Option<PresentationLabel>,
    ) -> Self {
        let subject = subject.into();
        let destination = destination.into();
        Self {
            id: Some(StaticAbilityId::AsEntersEffectProgram),
            label: format!("As {subject} transforms into {destination}"),
            payload: StaticAbilityPayload::AsEntersEffectProgram {
                program,
                subject,
                also_turns_face_up: false,
                turns_face_up_only: false,
                uses_enters_with_counter_surface: false,
                transforms_into: Some(destination),
                transform_characteristics: None,
                presentation_label,
                entry_instead_surface: false,
            },
        }
    }
    pub fn with_transform_characteristics(mut self, adjustment: TransformCharacteristicAdjustment) -> Self {
        if let StaticAbilityPayload::AsEntersEffectProgram { transform_characteristics, .. } = &mut self.payload {
            *transform_characteristics = Some(adjustment);
        }
        self
    }
    pub fn choose_color_as_enters(excluded: Option<Color>, display: impl Into<String>) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::ChooseColorAsEnters),
            label: display.clone(),
            payload: StaticAbilityPayload::ChooseColorAsEnters {
                excluded,
                display,
                count: 1,
            },
        }
    }
    /// "As this enters, choose two colors." (Seal of the Guildpact): `count`
    /// different colors are chosen and recorded together.
    pub fn choose_colors_as_enters(count: u32, display: impl Into<String>) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::ChooseColorAsEnters),
            label: display.clone(),
            payload: StaticAbilityPayload::ChooseColorAsEnters {
                excluded: None,
                display,
                count,
            },
        }
    }
    pub fn choose_color_as_becomes_attached(display: impl Into<String>) -> Self {
        Self {
            id: Some(StaticAbilityId::ChooseColorAsBecomesAttached),
            label: display.into(),
            payload: StaticAbilityPayload::None,
        }
    }
    /// "As this Equipment becomes attached to a creature, choose a creature
    /// card name and a creature type." (Psychic Paper)
    pub fn choose_creature_card_name_and_type_as_becomes_attached(
        display: impl Into<String>,
    ) -> Self {
        Self {
            id: Some(StaticAbilityId::ChooseCreatureCardNameAndTypeAsBecomesAttached),
            label: display.into(),
            payload: StaticAbilityPayload::None,
        }
    }
    /// "As this Equipment becomes attached to a creature, choose an exiled
    /// creature card used to craft this Equipment." (Dinosaur Headdress)
    pub fn choose_craft_material_as_becomes_attached(display: impl Into<String>) -> Self {
        Self {
            id: Some(StaticAbilityId::ChooseCraftMaterialAsBecomesAttached),
            label: display.into(),
            payload: StaticAbilityPayload::None,
        }
    }
    /// "Equipped creature's name and creature type are the last chosen name
    /// and creature type." (Psychic Paper)
    pub fn attached_has_source_chosen_name_and_creature_type() -> Self {
        Self {
            id: Some(StaticAbilityId::AttachedHasSourceChosenNameAndCreatureType),
            label: "Equipped creature's name and creature type are the last chosen name and creature type".into(),
            payload: StaticAbilityPayload::None,
        }
    }
    pub fn choose_player_as_enters(display: impl Into<String>) -> Self {
        Self::choose_player_as_enters_matching(PlayerFilter::Any, display)
    }
    pub fn choose_player_as_enters_matching(
        filter: PlayerFilter,
        display: impl Into<String>,
    ) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::ChoosePlayerAsEnters),
            label: display.clone(),
            payload: StaticAbilityPayload::ChoosePlayerAsEnters {
                filter,
                display,
                count: 1,
            },
        }
    }
    /// "As this enters, choose two players." (Bitter Feud, Sower of
    /// Discord): `count` different players, recorded together.
    pub fn choose_players_as_enters(
        filter: PlayerFilter,
        count: u32,
        display: impl Into<String>,
    ) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::ChoosePlayerAsEnters),
            label: display.clone(),
            payload: StaticAbilityPayload::ChoosePlayerAsEnters {
                filter,
                display,
                count,
            },
        }
    }
    pub fn note_life_total_as_enters(display: impl Into<String>) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::NoteLifeTotalAsEnters),
            label: display.clone(),
            payload: StaticAbilityPayload::NoteLifeTotalAsEnters(display),
        }
    }
    pub fn discard_hand_as_enters(display: impl Into<String>) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::DiscardHandAsEnters),
            label: display.clone(),
            payload: StaticAbilityPayload::DiscardHandAsEnters(display),
        }
    }
    pub fn reveal_from_hand_as_enters(
        filter: ObjectFilter,
        count: ChoiceCount,
        optional: bool,
        display: impl Into<String>,
    ) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::RevealFromHandAsEnters),
            label: display.clone(),
            payload: StaticAbilityPayload::RevealFromHandAsEnters {
                filter,
                count,
                optional,
                display,
            },
        }
    }
    pub fn choose_card_name_as_enters(display: impl Into<String>) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::ChooseCardNameAsEnters),
            label: display.clone(),
            payload: StaticAbilityPayload::ChooseCardNameAsEnters {
                display,
                reveal_opponents_hands: false,
                require_nonland_from_revealed_opponents: false,
                opponent_also_chooses: false,
                exclude_basic_land_names: false,
            },
        }
    }
    pub fn choose_revealed_hand_nonland_card_name_as_enters(display: impl Into<String>) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::ChooseCardNameAsEnters),
            label: display.clone(),
            payload: StaticAbilityPayload::ChooseCardNameAsEnters {
                display,
                reveal_opponents_hands: true,
                require_nonland_from_revealed_opponents: true,
                opponent_also_chooses: false,
                exclude_basic_land_names: false,
            },
        }
    }
    /// "As this enters, you and an opponent each choose a card name other than
    /// a basic land card name." (Null Chamber)
    pub fn you_and_an_opponent_choose_nonbasic_card_names_as_enters(
        display: impl Into<String>,
    ) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::ChooseCardNameAsEnters),
            label: display.clone(),
            payload: StaticAbilityPayload::ChooseCardNameAsEnters {
                display,
                reveal_opponents_hands: false,
                require_nonland_from_revealed_opponents: false,
                opponent_also_chooses: true,
                exclude_basic_land_names: true,
            },
        }
    }
    pub fn redirect_damage_from_you_and_other_permanents_to_source() -> Self {
        Self::identified(
            StaticAbilityId::RedirectDamageToSource,
            "redirect damage from you and other permanents to source",
        )
    }
    pub fn max_attackers_each_combat(n: usize) -> Self {
        Self {
            id: Some(StaticAbilityId::MaxCreaturesCanAttackEachCombat),
            label: format!("no more than {n} creatures can attack each combat"),
            payload: StaticAbilityPayload::MaxCreaturesCanAttackEachCombat(n),
        }
    }
    pub fn max_attackers_can_attack_you_each_combat(n: usize) -> Self {
        Self {
            id: Some(StaticAbilityId::MaxCreaturesCanAttackYouEachCombat),
            label: format!("no more than {n} creatures can attack you each combat"),
            payload: StaticAbilityPayload::MaxCreaturesCanAttackYouEachCombat(n),
        }
    }
    pub fn max_attackers_can_attack_source_each_combat(n: usize) -> Self {
        let noun = if n == 1 { "creature" } else { "creatures" };
        Self {
            id: Some(StaticAbilityId::MaxCreaturesCanAttackSourceEachCombat),
            label: format!("no more than {n} {noun} can attack this planeswalker each combat"),
            payload: StaticAbilityPayload::MaxCreaturesCanAttackSourceEachCombat(n),
        }
    }
    pub fn max_blockers_each_combat(n: usize) -> Self {
        Self {
            id: Some(StaticAbilityId::MaxCreaturesCanBlockEachCombat),
            label: format!("no more than {n} creatures can block each combat"),
            payload: StaticAbilityPayload::MaxCreaturesCanBlockEachCombat(n),
        }
    }
    pub fn shuffle_into_library_from_graveyard() -> Self {
        Self {
            id: Some(StaticAbilityId::ShuffleIntoLibraryFromGraveyard),
            label: "shuffle into library from graveyard".into(),
            payload: StaticAbilityPayload::None,
        }
    }
    /// The self-shuffle replacement for another replaced destination or
    /// without the reveal; the printed graveyard-and-reveal form keeps
    /// [`Self::shuffle_into_library_from_graveyard`].
    pub fn shuffle_into_owners_library_instead(to_zone: Zone, reveal: bool) -> Self {
        if to_zone == Zone::Graveyard && reveal {
            return Self::shuffle_into_library_from_graveyard();
        }
        Self {
            id: Some(StaticAbilityId::ShuffleIntoLibraryFromGraveyard),
            label: "shuffle into owner's library instead".into(),
            payload: StaticAbilityPayload::ShuffleIntoOwnersLibraryInstead { to_zone, reveal },
        }
    }
    pub fn permanents_enter_tapped() -> Self {
        Self {
            id: Some(StaticAbilityId::AllPermanentsEnterTapped),
            label: "permanents enter tapped".into(),
            payload: StaticAbilityPayload::None,
        }
    }
    pub fn creatures_entering_dont_cause_abilities_to_trigger() -> Self {
        Self {
            id: Some(StaticAbilityId::CreaturesEnteringDontCauseAbilitiesToTrigger),
            label: "creatures entering dont cause abilities to trigger".into(),
            payload: StaticAbilityPayload::None,
        }
    }
    pub fn creatures_assign_combat_damage_using_toughness() -> Self {
        Self::identified(
            StaticAbilityId::CreaturesAssignCombatDamageUsingToughness,
            "Each creature assigns combat damage equal to its toughness rather than its power",
        )
    }
    pub fn this_creature_assigns_combat_damage_using_toughness() -> Self {
        Self::identified(
            StaticAbilityId::ThisCreatureAssignsCombatDamageUsingToughness,
            "This creature assigns combat damage equal to its toughness rather than its power",
        )
    }
    pub fn creatures_you_control_assign_combat_damage_using_toughness() -> Self {
        Self {
            id: Some(StaticAbilityId::CreaturesYouControlAssignCombatDamageUsingToughness),
            label: "Each creature you control assigns combat damage equal to its toughness rather than its power".into(),
            payload: StaticAbilityPayload::None,
        }
    }
    pub fn lethal_damage_to_creatures_you_control_uses_power() -> Self {
        Self::identified(
            StaticAbilityId::LethalDamageToCreaturesYouControlUsesPower,
            "lethal damage to creatures you control uses power",
        )
    }
    pub fn planeswalkers_you_control_dont_die_at_zero_loyalty() -> Self {
        Self::identified(
            StaticAbilityId::PlaneswalkersYouControlDontDieAtZeroLoyalty,
            "Planeswalkers you control aren't put into their owners' graveyards for having 0 loyalty",
        )
    }
    pub fn players_cant_cycle() -> Self {
        Self {
            id: Some(StaticAbilityId::PlayersCantCycle),
            label: "players cant cycle".into(),
            payload: StaticAbilityPayload::None,
        }
    }
    pub fn you_are_the_starting_player() -> Self {
        Self::identified(StaticAbilityId::YouAreTheStartingPlayer, "you are the starting player")
    }
    pub fn starting_life_bonus(_amount: i32) -> Self {
        Self::identified(StaticAbilityId::StartingLifeBonus, "starting life bonus")
    }
    pub fn buyback_cost_reduction(amount: u32) -> Self {
        Self {
            id: Some(StaticAbilityId::BuybackCostReduction),
            label: "buyback cost reduction".to_string(),
            payload: StaticAbilityPayload::BuybackCostReduction(amount),
        }
    }
    pub fn cost_increase_per_target_beyond_first(cost: u32) -> Self {
        Self {
            id: Some(StaticAbilityId::CostIncreasePerAdditionalTarget),
            label: "cost increase per target beyond first".to_string(),
            payload: StaticAbilityPayload::CostIncreasePerTargetBeyondFirst(cost),
        }
    }
    pub fn cost_increase_mana_cost_per_target_beyond_first(cost: ManaCost) -> Self {
        Self {
            id: Some(StaticAbilityId::CostIncreaseManaCostPerAdditionalTarget),
            label: "mana cost increase per target beyond first".to_string(),
            payload: StaticAbilityPayload::CostIncreaseManaCostPerTargetBeyondFirst(cost),
        }
    }
    pub fn loyalty_abilities_any_time(filter: ObjectFilter) -> Self {
        Self {
            id: Some(StaticAbilityId::LoyaltyAbilitiesAnyTime),
            label: "You may activate loyalty abilities any time you could cast an instant"
                .to_string(),
            payload: StaticAbilityPayload::LoyaltyAbilitiesAnyTime { filter },
        }
    }

    pub fn activate_abilities_as_though_haste(
        filter: ObjectFilter,
        display: impl Into<String>,
    ) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::ActivateAbilitiesAsThoughHaste),
            label: display.clone(),
            payload: StaticAbilityPayload::ActivateAbilitiesAsThoughHaste { filter, display },
        }
    }
    pub fn cost_increase_life(
        filter: ObjectFilter,
        amount: u32,
        display: impl Into<String>,
    ) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::CostIncreaseLife),
            label: display.clone(),
            payload: StaticAbilityPayload::CostIncreaseLife {
                filter,
                amount,
                display,
            },
        }
    }
    pub fn additional_life_cost_per_target(amount: u32) -> Self {
        Self {
            id: Some(StaticAbilityId::CostIncreasePerAdditionalTarget),
            label: format!("This spell costs {amount} life more to cast for each target"),
            payload: StaticAbilityPayload::AdditionalLifeCostPerTarget(amount),
        }
    }
    pub fn commander_tax_life_substitution(life_per_previous_cast: u32) -> Self {
        Self {
            id: Some(StaticAbilityId::CommanderTaxLifeSubstitution),
            label: format!(
                "Rather than pay {{2}} for each previous time you've cast this spell from the command zone this game, pay {life_per_previous_cast} life that many times"
            ),
            payload: StaticAbilityPayload::CommanderTaxLifeSubstitution {
                life_per_previous_cast,
            },
        }
    }
    pub fn players_skip_upkeep() -> Self {
        Self::player_skips_upkeep(PlayerFilter::Any)
    }
    pub fn player_skips_upkeep(player: PlayerFilter) -> Self {
        Self {
            id: Some(StaticAbilityId::PlayersSkipUpkeep),
            label: "players skip upkeep".into(),
            payload: StaticAbilityPayload::PlayersSkipUpkeep { player },
        }
    }
    pub fn look_at_source_exiled_cards(source: SourceReferenceSurface) -> Self {
        Self {
            id: Some(StaticAbilityId::LookAtSourceExiledCards),
            label: format!("You may look at cards exiled with {}", source.display_text()),
            payload: StaticAbilityPayload::LookAtSourceExiledCards { pair: None, source },
        }
    }

    /// The outer option identifies a standalone inspector; an absent inner
    /// pair is an unresolved semantic scope and requires explicit recovery.
    pub fn source_exiled_inspection_pair(&self) -> Option<Option<crate::LinkedExilePair>> {
        match &self.payload {
            StaticAbilityPayload::LookAtSourceExiledCards { pair, .. } => Some(*pair),
            StaticAbilityPayload::Conditional { ability, .. } => ability.source_exiled_inspection_pair(),
            _ => None,
        }
    }

    pub fn player_skips_draw_step(player: PlayerFilter) -> Self {
        Self {
            id: Some(StaticAbilityId::PlayerSkipsDrawStep),
            label: "skip your draw step".into(),
            payload: StaticAbilityPayload::PlayerSkipsDrawStep { player },
        }
    }
    pub fn players_skip_untap_steps(player: PlayerFilter) -> Self {
        Self {
            id: Some(StaticAbilityId::PlayersSkipUntapStep),
            label: "players skip their untap steps".into(),
            payload: StaticAbilityPayload::PlayersSkipUntapStep { player },
        }
    }
    pub fn players_skip_extra_turns(player: PlayerFilter) -> Self {
        Self {
            id: Some(StaticAbilityId::PlayersSkipExtraTurns),
            label: "players skip extra turns".into(),
            payload: StaticAbilityPayload::PlayersSkipExtraTurns { player },
        }
    }
    pub fn legend_rule_doesnt_apply() -> Self {
        Self::identified(
            StaticAbilityId::LegendRuleDoesntApply,
            "legend rule doesnt apply",
        )
    }
    pub fn legend_rule_doesnt_apply_to_controller() -> Self {
        Self::legend_rule_doesnt_apply_to_controller_matching(ObjectFilter::permanent())
    }
    pub fn legend_rule_doesnt_apply_to_controller_matching(filter: ObjectFilter) -> Self {
        let noun = if filter.token {
            "tokens".to_string()
        } else if let ([], [subtype]) = (filter.card_types.as_slice(), filter.subtypes.as_slice()) {
            // "doesn't apply to Spiders you control" (Spider-Verse).
            format!("{subtype}s")
        } else if filter.card_types == [CardType::Creature] {
            "creatures".to_string()
        } else {
            "permanents".to_string()
        };
        Self {
            id: Some(StaticAbilityId::LegendRuleDoesntApplyToController),
            label: format!("The \"legend rule\" doesn't apply to {noun} you control"),
            payload: StaticAbilityPayload::LegendRuleDoesntApplyToController { filter },
        }
    }
    /// "The legend rule doesn't apply to <objects>": every matching permanent
    /// is exempt, whoever controls it. Shares the controller-scoped payload;
    /// the id selects the cross-controller reading.
    pub fn legend_rule_doesnt_apply_to_matching(filter: ObjectFilter, display: String) -> Self {
        Self {
            id: Some(StaticAbilityId::LegendRuleDoesntApplyToMatching),
            label: display,
            payload: StaticAbilityPayload::LegendRuleDoesntApplyToController { filter },
        }
    }
    pub fn legend_rule_doesnt_apply_to_tokens_you_control() -> Self {
        let mut filter = ObjectFilter::permanent();
        filter.token = true;
        Self {
            id: Some(StaticAbilityId::LegendRuleDoesntApplyToControllerTokens),
            label: "The \"legend rule\" doesn't apply to tokens you control".to_string(),
            payload: StaticAbilityPayload::LegendRuleDoesntApplyToController { filter },
        }
    }
    pub fn remove_supertypes(filter: ObjectFilter, supertypes: Vec<Supertype>) -> Self {
        Self {
            id: Some(StaticAbilityId::RemoveSupertypes),
            label: "remove supertypes".into(),
            payload: StaticAbilityPayload::RemoveSupertypes { filter, supertypes },
        }
    }
    pub fn prevent_all_damage_dealt_to_creatures() -> Self {
        Self {
            id: Some(StaticAbilityId::PreventAllDamageDealtToCreatures),
            label: "prevent all damage dealt to creatures".into(),
            payload: StaticAbilityPayload::None,
        }
    }
    pub fn prevent_all_damage_dealt_to_and_by_this_permanent() -> Self {
        Self {
            id: Some(StaticAbilityId::PreventAllDamageDealtToAndByThisPermanent),
            label: "prevent all damage dealt to and dealt by this permanent".into(),
            payload: StaticAbilityPayload::None,
        }
    }
    pub fn prevent_damage_to_other_creature_you_control_put_counters_instead(
        _counter_type: CounterType,
        display: impl Into<String>,
    ) -> Self {
        Self {
            id: Some(StaticAbilityId::PreventDamageToOtherCreatureYouControlPutCountersInstead),
            label: display.into(),
            payload: StaticAbilityPayload::None,
        }
    }
    pub fn prevent_all_combat_damage_to_self() -> Self {
        Self {
            id: Some(StaticAbilityId::PreventAllCombatDamageToSelf),
            label: "prevent all combat damage to self".into(),
            payload: StaticAbilityPayload::None,
        }
    }
    pub fn prevent_all_combat_damage_to_permanents_matching(filter: ObjectFilter) -> Self {
        Self {
            id: Some(StaticAbilityId::PreventAllCombatDamageToPermanentsMatching),
            label: "prevent all combat damage to permanents matching filter".into(),
            payload: StaticAbilityPayload::PreventAllCombatDamageToPermanentsMatching(filter),
        }
    }
    pub fn prevent_all_combat_damage_to_and_by_permanents_matching(filter: ObjectFilter) -> Self {
        Self {
            id: Some(StaticAbilityId::PreventAllCombatDamageToAndByPermanentsMatching),
            label: "prevent all combat damage to and by permanents matching filter".into(),
            payload: StaticAbilityPayload::PreventAllCombatDamageToAndByPermanentsMatching(filter),
        }
    }
    pub fn prevent_all_damage_to_permanents_matching(filter: ObjectFilter) -> Self {
        Self {
            id: Some(StaticAbilityId::PreventAllDamageToPermanentsMatching),
            label: "prevent all damage to permanents matching filter".into(),
            payload: StaticAbilityPayload::PreventAllDamageToPermanentsMatching(filter),
        }
    }
    pub fn prevent_all_noncombat_damage_to_permanents_matching(filter: ObjectFilter) -> Self {
        Self {
            id: Some(StaticAbilityId::PreventAllNoncombatDamageToPermanentsMatching),
            label: "prevent all noncombat damage to permanents matching filter".into(),
            payload: StaticAbilityPayload::PreventAllNoncombatDamageToPermanentsMatching(filter),
        }
    }
    pub fn prevent_all_damage_to_self_from_sources_matching(
        spec: PreventAllDamageToSelfFromSourcesMatchingSpec,
    ) -> Self {
        Self {
            id: Some(StaticAbilityId::PreventAllDamageToSelfFromSourcesMatching),
            label: spec.display.clone(),
            payload: StaticAbilityPayload::PreventAllDamageToSelfFromSourcesMatching(spec),
        }
    }
    pub fn prevent_all_damage_to_self() -> Self {
        Self {
            id: Some(StaticAbilityId::PreventAllDamageToSelf),
            label: "prevent all damage to self".into(),
            payload: StaticAbilityPayload::None,
        }
    }
    pub fn prevent_all_noncombat_damage_to_other_creatures_you_control() -> Self {
        Self {
            id: Some(StaticAbilityId::PreventAllNoncombatDamageToOtherCreaturesYouControl),
            label: "prevent all noncombat damage to other creatures you control".into(),
            payload: StaticAbilityPayload::None,
        }
    }
    pub fn prevent_all_damage_to_self_by_creatures() -> Self {
        Self {
            id: Some(StaticAbilityId::PreventAllDamageToSelfByCreatures),
            label: "prevent all damage to self by creatures".into(),
            payload: StaticAbilityPayload::None,
        }
    }
    pub fn may_choose_not_to_untap_during_untap_step(subject: impl Into<String>) -> Self {
        let subject = subject.into();
        Self {
            id: Some(StaticAbilityId::MayChooseNotToUntapDuringUntapStep),
            label: format!("You may choose not to untap {subject} during your untap step"),
            payload: StaticAbilityPayload::MayChooseNotToUntapDuringUntapStep(subject),
        }
    }
    pub fn flying_only_restriction() -> Self {
        Self {
            id: Some(StaticAbilityId::FlyingOnlyRestriction),
            label: "flying only restriction".into(),
            payload: StaticAbilityPayload::None,
        }
    }
    pub fn flying_restriction() -> Self {
        Self {
            id: Some(StaticAbilityId::FlyingRestriction),
            label: "flying restriction".into(),
            payload: StaticAbilityPayload::None,
        }
    }
    pub fn assigns_damage_as_unblocked() -> Self {
        Self {
            id: Some(StaticAbilityId::AssignsDamageAsUnblocked),
            label: "assigns damage as unblocked".into(),
            payload: StaticAbilityPayload::None,
        }
    }
    /// "This creature has all abilities of ability stickers on <objects>."
    /// (Clandestine Chameleon)
    pub fn source_has_ability_sticker_abilities_of(
        filter: ObjectFilter,
        display: impl Into<String>,
    ) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::SourceHasAbilityStickerAbilitiesOf),
            label: display.clone(),
            payload: StaticAbilityPayload::SourceHasAbilityStickerAbilitiesOf { filter, display },
        }
    }
    /// "Equipped creature has all abilities of ability stickers on this
    /// Equipment." (Pin Collection)
    pub fn attached_has_source_ability_sticker_abilities() -> Self {
        Self {
            id: Some(StaticAbilityId::AttachedHasSourceAbilityStickerAbilities),
            label: "equipped creature has all abilities of ability stickers on this Equipment"
                .into(),
            payload: StaticAbilityPayload::None,
        }
    }
    /// "The monarch controls enchanted creature." (Fealty to the Realm)
    pub fn monarch_controls_attached_permanent() -> Self {
        Self {
            id: Some(StaticAbilityId::MonarchControlsAttachedPermanent),
            label: "the monarch controls enchanted creature".into(),
            payload: StaticAbilityPayload::None,
        }
    }
    /// "All instances of color words in the text of spells and permanents
    /// are changed to the chosen color word." (Swirl the Mists)
    pub fn all_color_words_become_chosen_color() -> Self {
        Self {
            id: Some(StaticAbilityId::AllColorWordsBecomeChosenColor),
            label: "all instances of color words in the text of spells and permanents are changed to the chosen color word"
                .into(),
            payload: StaticAbilityPayload::None,
        }
    }
    /// "Equipped creature has all names of nonlegendary creature cards in
    /// addition to its name." (Spy Kit)
    pub fn attached_has_all_nonlegendary_creature_card_names() -> Self {
        Self {
            id: Some(StaticAbilityId::AttachedHasAllNonlegendaryCreatureCardNames),
            label: "equipped creature has all names of nonlegendary creature cards in addition to its name"
                .into(),
            payload: StaticAbilityPayload::None,
        }
    }
    pub fn may_assign_damage_as_unblocked() -> Self {
        Self {
            id: Some(StaticAbilityId::MayAssignDamageAsUnblocked),
            label: "may assign damage as unblocked".into(),
            payload: StaticAbilityPayload::None,
        }
    }
    /// "If this creature is unblocked, you may have it assign its combat
    /// damage to a creature defending player controls." (Cunning Giant)
    /// "You may assign this creature's combat damage divided as you choose
    /// among defending player and/or any number of creatures they control."
    /// (Butcher Orgg)
    pub fn may_divide_combat_damage_among_defending_player_and_creatures() -> Self {
        Self {
            id: Some(StaticAbilityId::MayDivideCombatDamageAmongDefendingPlayerAndCreatures),
            label: "may divide combat damage among defending player and creatures they control"
                .into(),
            payload: StaticAbilityPayload::None,
        }
    }
    pub fn may_assign_unblocked_damage_to_defending_creature() -> Self {
        Self {
            id: Some(StaticAbilityId::MayAssignUnblockedDamageToDefendingCreature),
            label: "may assign unblocked damage to a creature defending player controls".into(),
            payload: StaticAbilityPayload::None,
        }
    }
    pub fn you_assign_combat_damage_of_creatures_attacking_you() -> Self {
        Self {
            id: Some(StaticAbilityId::YouAssignCombatDamageOfCreaturesAttackingYou),
            label: "you assign combat damage of creatures attacking you".into(),
            payload: StaticAbilityPayload::None,
        }
    }
    pub fn remove_ability(
        filter: ObjectFilter,
        ability: StaticAbility<T, E, C, Cond, ICond>,
    ) -> Self {
        Self::remove_ability_with_mode(filter, ability, AbilityLossMode::Lose)
    }

    pub fn remove_ability_with_mode(
        filter: ObjectFilter,
        ability: StaticAbility<T, E, C, Cond, ICond>,
        mode: AbilityLossMode,
    ) -> Self {
        Self {
            id: Some(StaticAbilityId::RemoveAbilityForFilter),
            label: format!("remove {}", ability.display()),
            payload: StaticAbilityPayload::RemoveAbilityForFilter {
                filter,
                ability: Box::new(ability),
                mode,
            },
        }
    }
    pub fn remove_object_abilities(
        filter: ObjectFilter,
        abilities: Vec<AbilityModel<T, E, C, Cond>>,
        display: impl Into<String>,
    ) -> Self {
        Self::remove_object_abilities_with_mode(filter, abilities, display, AbilityLossMode::Lose)
    }

    pub fn remove_object_abilities_with_mode(
        filter: ObjectFilter,
        abilities: Vec<AbilityModel<T, E, C, Cond>>,
        display: impl Into<String>,
        mode: AbilityLossMode,
    ) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::RemoveAbilityForFilter),
            label: format!("remove {display}"),
            payload: StaticAbilityPayload::RemoveObjectAbilitiesForFilter {
                filter,
                abilities,
                display,
                mode,
            },
        }
    }
    pub fn look_at_top_card_of_library() -> Self {
        Self {
            id: Some(StaticAbilityId::LookAtTopCardOfLibrary),
            label: "You may look at the top card of your library any time.".into(),
            payload: StaticAbilityPayload::None,
        }
    }
    pub fn look_at_face_down_creatures_you_dont_control() -> Self {
        Self {
            id: Some(StaticAbilityId::LookAtFaceDownCreaturesYouDontControl),
            label: "You may look at face-down creatures you don't control any time.".into(),
            payload: StaticAbilityPayload::None,
        }
    }
    pub fn all_players_look_at_top_cards_of_libraries() -> Self {
        Self {
            id: Some(StaticAbilityId::AllPlayersLookAtTopCardsOfLibraries),
            label: "Players play with the top card of their libraries revealed.".into(),
            payload: StaticAbilityPayload::None,
        }
    }
    pub fn all_players_look_at_your_top_library_card() -> Self {
        Self {
            id: Some(StaticAbilityId::AllPlayersLookAtYourTopLibraryCard),
            label: "Play with the top card of your library revealed.".into(),
            payload: StaticAbilityPayload::None,
        }
    }
    pub fn controller_plays_with_hand_revealed() -> Self {
        Self {
            id: Some(StaticAbilityId::ControllerPlaysWithHandRevealed),
            label: "Play with your hand revealed.".into(),
            payload: StaticAbilityPayload::None,
        }
    }
    pub fn players_play_with_hands_revealed() -> Self {
        Self {
            id: Some(StaticAbilityId::PlayersPlayWithHandsRevealed),
            label: "Players play with their hands revealed.".into(),
            payload: StaticAbilityPayload::None,
        }
    }
    pub fn opponents_play_with_hands_revealed() -> Self {
        Self {
            id: Some(StaticAbilityId::OpponentsPlayWithHandsRevealed),
            label: "Your opponents play with their hands revealed.".into(),
            payload: StaticAbilityPayload::None,
        }
    }
    pub fn control_opponents_while_searching_libraries() -> Self {
        Self {
            id: Some(StaticAbilityId::ControlOpponentsWhileSearchingLibraries),
            label: "You control your opponents while they're searching their libraries.".into(),
            payload: StaticAbilityPayload::None,
        }
    }
    pub fn opponent_search_exile_found_cards() -> Self {
        Self {
            id: Some(StaticAbilityId::OpponentSearchExileFoundCards),
            label: "While an opponent is searching their library, they exile each card they find. You may play those cards for as long as they remain exiled, and you may spend mana as though it were mana of any color to cast them.".into(),
            payload: StaticAbilityPayload::None,
        }
    }
    pub fn cast_this_card_from_library_while_searching() -> Self {
        Self {
            id: Some(StaticAbilityId::CastThisCardFromLibraryWhileSearching),
            label: "While you're searching your library, you may cast this card from your library."
                .into(),
            payload: StaticAbilityPayload::None,
        }
    }
    pub fn additional_land_plays(count: u32) -> Self {
        Self {
            id: Some(StaticAbilityId::RuleRestriction),
            label: "additional land plays".to_string(),
            payload: StaticAbilityPayload::AdditionalLandPlays(count),
        }
    }
    pub fn no_maximum_hand_size_for(player: PlayerFilter) -> Self {
        Self {
            id: Some(StaticAbilityId::NoMaximumHandSize),
            label: "scoped no maximum hand size".into(),
            payload: StaticAbilityPayload::NoMaximumHandSizeFor(player),
        }
    }
    pub fn maximum_hand_size_from_source_counters(
        player: PlayerFilter,
        counter_type: CounterType,
    ) -> Self {
        Self {
            id: Some(StaticAbilityId::SetMaximumHandSize),
            label: "maximum hand size from source counters".into(),
            payload: StaticAbilityPayload::MaximumHandSizeFromSourceCounters {
                player,
                counter_type,
            },
        }
    }
    pub fn no_maximum_hand_size() -> Self {
        Self {
            id: Some(StaticAbilityId::NoMaximumHandSize),
            label: "no maximum hand size".into(),
            payload: StaticAbilityPayload::None,
        }
    }
    pub fn can_be_commander() -> Self {
        Self {
            id: Some(StaticAbilityId::CanBeCommander),
            label: "can be commander".into(),
            payload: StaticAbilityPayload::None,
        }
    }
    pub fn max_hand_size_seven_minus_your_graveyard_card_types(
        player: PlayerFilter,
        min_card_types: u32,
    ) -> Self {
        Self {
            id: Some(StaticAbilityId::MaximumHandSizeSevenMinusYourGraveyardCardTypes),
            label: "max hand size seven minus your graveyard card types".into(),
            payload: StaticAbilityPayload::MaximumHandSizeSevenMinusYourGraveyardCardTypes {
                player,
                min_card_types,
            },
        }
    }
    pub fn effect_discard_to_library_replacement() -> Self {
        Self {
            id: Some(StaticAbilityId::EffectDiscardToLibraryReplacement),
            label: "effect discard to library replacement".into(),
            payload: StaticAbilityPayload::None,
        }
    }
    pub fn opponent_effect_discard_to_library_replacement() -> Self {
        Self {
            id: Some(StaticAbilityId::OpponentEffectDiscardToLibraryReplacement),
            label: "If a spell or ability an opponent controls causes you to discard a card, you may reveal that card and put it on top of your library instead of putting it anywhere else".into(),
            payload: StaticAbilityPayload::None,
        }
    }
    pub fn opponent_effect_discard_this_to_battlefield_replacement() -> Self {
        Self {
            id: Some(StaticAbilityId::OpponentEffectDiscardThisToBattlefieldReplacement),
            label: "opponent effect discard this to battlefield replacement".into(),
            payload: StaticAbilityPayload::None,
        }
    }
    pub fn opponent_effect_discard_this_to_battlefield_with_counters_replacement(
        counter_type: CounterType,
        count: u32,
    ) -> Self {
        Self {
            id: Some(StaticAbilityId::OpponentEffectDiscardThisToBattlefieldReplacement),
            label: "opponent effect discard this to battlefield replacement".into(),
            payload: StaticAbilityPayload::OpponentDiscardThisToBattlefieldWithCounters {
                counter_type,
                count,
            },
        }
    }
    pub fn draw_replacement_exile_top_face_down() -> Self {
        Self {
            id: Some(StaticAbilityId::DrawReplacementExileTopFaceDown),
            label: "draw replacement exile top face down".into(),
            payload: StaticAbilityPayload::None,
        }
    }
    pub fn draw_replacement_double() -> Self {
        Self {
            id: Some(StaticAbilityId::DrawReplacementDouble),
            label: "draw replacement double".into(),
            payload: StaticAbilityPayload::None,
        }
    }

    pub fn draw_replacement_skip_empty_library() -> Self {
        Self {
            id: Some(StaticAbilityId::DrawReplacementSkipEmptyLibrary),
            label: "draw replacement skip empty library".into(),
            payload: StaticAbilityPayload::None,
        }
    }

    pub fn draw_extra_cards_replacement(extra: u32, display: impl Into<String>) -> Self {
        Self::draw_extra_cards_replacement_with_options(extra, false, true, display)
    }
    /// "If you would create a Clue, Food, or Treasure token, instead create
    /// one of each." (Academy Manufactor)
    pub fn create_one_of_each_token_replacement(
        kinds: Vec<AdditionalTokenKind>,
        display: impl Into<String>,
    ) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::CreateOneOfEachTokenReplacement),
            label: display.clone(),
            payload: StaticAbilityPayload::CreateOneOfEachTokenReplacement { kinds, display },
        }
    }
    /// "If an opponent would draw a card ..., instead that player skips that
    /// draw and you draw a card." (Notion Thief)
    pub fn redirect_draw_replacement(
        drawer: PlayerFilter,
        except_first_of_draw_step: bool,
        display: impl Into<String>,
    ) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::RedirectDrawReplacement),
            label: display.clone(),
            payload: StaticAbilityPayload::RedirectDrawReplacement {
                drawer,
                except_first_of_draw_step,
                display,
            },
        }
    }
    pub fn draw_extra_cards_replacement_with_options(
        extra: u32,
        except_first_of_draw_step: bool,
        per_instruction: bool,
        display: impl Into<String>,
    ) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::DrawExtraCardsReplacement),
            label: display.clone(),
            payload: StaticAbilityPayload::DrawExtraCardsReplacement {
                extra,
                except_first_of_draw_step,
                per_instruction,
                display,
            },
        }
    }
    pub fn conditional_draw_replacement(
        condition: ICond,
        replacement_effects: Vec<E>,
        display: impl Into<String>,
    ) -> Self {
        Self::conditional_draw_replacement_with_optional(
            condition,
            replacement_effects,
            false,
            display,
        )
    }

    pub fn conditional_draw_replacement_with_optional(
        condition: ICond,
        replacement_effects: Vec<E>,
        optional: bool,
        display: impl Into<String>,
    ) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::ConditionalDrawReplacement),
            label: display.clone(),
            payload: StaticAbilityPayload::ConditionalDrawReplacement {
                condition,
                replacement_effects,
                optional,
                display,
                except_first_of_draw_step: false,
            },
        }
    }

    /// The conditional draw replacement never replaces the first card drawn
    /// during each of the controller's draw steps.
    pub fn with_draw_step_first_draw_exception(mut self) -> Self {
        if let StaticAbilityPayload::ConditionalDrawReplacement {
            except_first_of_draw_step,
            ..
        } = &mut self.payload
        {
            *except_first_of_draw_step = true;
        }
        self
    }

    pub fn lose_game_replacement(
        replacement_effects: Vec<E>,
        optional: bool,
        display: impl Into<String>,
    ) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::LoseGameReplacement),
            label: display.clone(),
            payload: StaticAbilityPayload::LoseGameReplacement {
                replacement_effects,
                optional,
                display,
            },
        }
    }

    pub fn draw_replacement_exile_top_and_play(count: u32) -> Self {
        Self {
            id: Some(StaticAbilityId::DrawReplacementExileTopAndPlay),
            label: format!("draw replacement exile top {count} and play"),
            payload: StaticAbilityPayload::None,
        }
    }

    pub fn draw_replacement_reveal_top_matching_to_hand_rest_bottom(
        count: u32,
        filter: ObjectFilter,
        order: crate::LibraryBottomOrder,
        display: impl Into<String>,
    ) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::DrawReplacementRevealTopMatchingToHandRestBottom),
            label: display.clone(),
            payload: StaticAbilityPayload::DrawReplacementRevealTopMatchingToHandRestBottom {
                count,
                filter,
                order,
                display,
            },
        }
    }

    pub fn named_action_replacement(label: String, source_filter: ObjectFilter, performer_filter: Option<PlayerFilter>, replacement_effects: Vec<E>, optional: bool, display: String) -> Self {
        Self { id: Some(StaticAbilityId::KeywordActionReplacement), label: display.clone(),
            payload: StaticAbilityPayload::NamedActionReplacement { label, source_filter, performer_filter, object_requirement: None, replacement_effects, optional, display } }
    }

    pub fn with_named_action_object_requirement(mut self, minimum:u32, filter:ObjectFilter)->Self {
        if let StaticAbilityPayload::NamedActionReplacement {object_requirement,..}=&mut self.payload {
            *object_requirement=Some(crate::filter_model::NamedActionObjectRequirement {minimum,filter:Box::new(filter)});
        }
        self
    }

    pub fn keyword_action_replacement(
        action: KeywordActionKind,
        source_filter: ObjectFilter,
        replacement_effects: Vec<E>,
        display: impl Into<String>,
    ) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::KeywordActionReplacement),
            label: display.clone(),
            payload: StaticAbilityPayload::KeywordActionReplacement {
                action,
                source_filter,
                performer_filter: None,
                replacement_effects,
                optional: false,
                display,
            },
        }
    }

    pub fn keyword_action_replacement_for_player(
        action: KeywordActionKind,
        performer_filter: PlayerFilter,
        replacement_effects: Vec<E>,
        display: impl Into<String>,
    ) -> Self {
        Self::keyword_action_replacement_for_player_with_optional(
            action,
            performer_filter,
            replacement_effects,
            false,
            display,
        )
    }

    pub fn keyword_action_replacement_for_player_with_optional(
        action: KeywordActionKind,
        performer_filter: PlayerFilter,
        replacement_effects: Vec<E>,
        optional: bool,
        display: impl Into<String>,
    ) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::KeywordActionReplacement),
            label: display.clone(),
            payload: StaticAbilityPayload::KeywordActionReplacement {
                action,
                source_filter: ObjectFilter::default(),
                performer_filter: Some(performer_filter),
                replacement_effects,
                optional,
                display,
            },
        }
    }

    pub fn exile_to_countered_exile_instead_of_graveyard(
        player: PlayerFilter,
        counter_type: CounterType,
    ) -> Self {
        Self {
            id: Some(StaticAbilityId::ExileToCounteredExileInsteadOfGraveyard),
            label: "exile to countered exile instead of graveyard".into(),
            payload: StaticAbilityPayload::ExileToCounteredExileInsteadOfGraveyard {
                player,
                counter_type,
            },
        }
    }

    pub fn exile_to_exile_instead_of_graveyard(
        filter: ObjectFilter,
        graveyard_owner: PlayerFilter,
    ) -> Self {
        Self::exile_to_exile_instead_of_graveyard_with_options(filter, graveyard_owner, false)
    }

    pub fn exile_to_exile_instead_of_graveyard_unless_cycled(
        filter: ObjectFilter,
        graveyard_owner: PlayerFilter,
    ) -> Self {
        Self::exile_to_exile_instead_of_graveyard_with_options(filter, graveyard_owner, true)
    }

    fn exile_to_exile_instead_of_graveyard_with_options(
        filter: ObjectFilter,
        graveyard_owner: PlayerFilter,
        exclude_cycled: bool,
    ) -> Self {
        Self {
            id: Some(StaticAbilityId::ExileToExileInsteadOfGraveyard),
            label: "exile instead of graveyard".into(),
            payload: StaticAbilityPayload::ExileToExileInsteadOfGraveyard {
                filter,
                graveyard_owner,
                exclude_cycled,
                link_to_source: false,
            },
        }
    }

    pub fn exile_would_die_instead(filter: ObjectFilter) -> Self {
        Self::exile_would_die_instead_with_damage_source(filter, None)
    }

    pub fn redirect_zone_change(
        filter: ObjectFilter,
        from_zone: Option<Zone>,
        to_zone: Option<Zone>,
        destination: Zone,
    ) -> Self {
        Self {
            id: Some(StaticAbilityId::RedirectZoneChange),
            label: "zone-change replacement".into(),
            payload: StaticAbilityPayload::RedirectZoneChange {
                filter,
                from_zone,
                to_zone,
                destination,
            },
        }
    }

    pub fn exile_would_die_instead_with_damage_source(
        filter: ObjectFilter,
        damaged_by: Option<DamagedBySource>,
    ) -> Self {
        Self::exile_would_die_instead_with_damage_source_and_follow_up(filter, damaged_by, vec![])
    }

    pub fn exile_would_die_instead_with_damage_filter(
        filter: ObjectFilter,
        damager_filter: ObjectFilter,
    ) -> Self {
        Self::exile_would_die_instead_with_damage_filter_surface(filter, damager_filter, None)
    }

    pub fn exile_would_die_instead_with_damage_filter_surface(
        filter: ObjectFilter,
        damager_filter: ObjectFilter,
        damager_filter_surface: Option<String>,
    ) -> Self {
        Self {
            id: Some(StaticAbilityId::ExileWouldDieInstead),
            label: "exile would die instead".into(),
            payload: StaticAbilityPayload::ExileWouldDieInstead {
                filter,
                damaged_by: None,
                damager_filter: Some(damager_filter),
                damager_filter_surface,
                exile_with_counters: Vec::new(),
                follow_up_effects: Vec::new(),
            },
        }
    }

    pub fn exile_would_die_instead_with_damage_source_and_follow_up(
        filter: ObjectFilter,
        damaged_by: Option<DamagedBySource>,
        follow_up_effects: Vec<E>,
    ) -> Self {
        Self::exile_would_die_instead_with_damage_source_counters_and_follow_up(
            filter,
            damaged_by,
            Vec::new(),
            follow_up_effects,
        )
    }

    pub fn exile_would_die_instead_with_damage_source_counters_and_follow_up(
        filter: ObjectFilter,
        damaged_by: Option<DamagedBySource>,
        exile_with_counters: Vec<(CounterType, u32)>,
        follow_up_effects: Vec<E>,
    ) -> Self {
        Self {
            id: Some(StaticAbilityId::ExileWouldDieInstead),
            label: "exile would die instead".into(),
            payload: StaticAbilityPayload::ExileWouldDieInstead {
                filter,
                damaged_by,
                damager_filter: None,
                damager_filter_surface: None,
                exile_with_counters,
                follow_up_effects,
            },
        }
    }
    /// "You may pay <mana> rather than pay the echo cost for <permanents>."
    /// (CR 118.9, 702.30a)
    pub fn echo_cost_alternative(
        filter: ObjectFilter,
        replacement_mana_cost: ManaCost,
        display: impl Into<String>,
    ) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::EchoCostAlternative),
            label: display.clone(),
            payload: StaticAbilityPayload::EchoCostAlternative {
                filter,
                replacement_mana_cost,
                display,
            },
        }
    }
    /// Matching cards may be cast from `zone` using their `method`
    /// alternative cost ("... using their sneak abilities").
    pub fn alternative_cast_from_zone_for_filter(
        filter: ObjectFilter,
        zone: Zone,
        method: crate::alternative_cast_model::AlternativeCastKeyword,
        display: impl Into<String>,
    ) -> Self {
        Self {
            id: Some(StaticAbilityId::AlternativeCastFromZoneForFilter),
            label: display.into(),
            payload: StaticAbilityPayload::AlternativeCastFromZoneForFilter {
                filter,
                zone,
                method,
            },
        }
    }
    /// A keyword granted to matching spells as they are cast (CR 601.2b).
    pub fn named_action_payment_alternative(label: impl Into<String>, player: PlayerFilter, effects: Vec<E>, display: impl Into<String>) -> Self {
        let display = display.into();
        Self { id: Some(StaticAbilityId::NamedActionPaymentAlternative), label: display.clone(), payload: StaticAbilityPayload::NamedActionPaymentAlternative { label: label.into(), player, effects, display } }
    }
    pub fn named_action_token_ability_grant(label: impl Into<String>, player: PlayerFilter, abilities: Vec<AbilityModel<T, E, C, Cond, ICond>>, display: impl Into<String>) -> Self {
        let display = display.into();
        Self { id: Some(StaticAbilityId::NamedActionTokenAbilityGrant), label: display.clone(), payload: StaticAbilityPayload::NamedActionTokenAbilityGrant { label: label.into(), player, abilities, display } }
    }
    pub fn grant_spell_keyword(
        filter: ObjectFilter,
        keyword: crate::GrantedSpellKeyword<C>,
        set_quantifier_surface: Option<SetQuantifierSurface>,
        display: impl Into<String>,
    ) -> Self {
        Self {
            id: Some(StaticAbilityId::GrantSpellKeyword),
            label: display.into(),
            payload: StaticAbilityPayload::GrantSpellKeyword {
                filter,
                keyword,
                set_quantifier_surface,
            },
        }
    }
    /// An amount-modifying replacement over one watched event (CR 614.1a).
    pub fn event_amount_replacement(
        event: crate::AmountEventSpec,
        modifier: crate::AmountModifierSpec,
        optional: bool,
        display: impl Into<String>,
    ) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::EventAmountReplacement),
            label: display.clone(),
            payload: StaticAbilityPayload::EventAmountReplacement {
                event,
                modifier,
                optional,
                display,
            },
        }
    }
    /// "If <event> would happen, <effects> instead." (CR 614.1a)
    pub fn event_replacement_with_effects(
        event: crate::ReplacedEventSpec,
        replacement_effects: Vec<E>,
        display: impl Into<String>,
    ) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::EventReplacementWithEffects),
            label: display.clone(),
            payload: StaticAbilityPayload::EventReplacementWithEffects {
                event,
                replacement_effects,
                display,
                optional: false,
            },
        }
    }
    /// "If <event> would happen, you may <effects> instead." (Pulmonic
    /// Sliver's granted ability): the optional form (CR 614.1a).
    pub fn optional_event_replacement_with_effects(
        event: crate::ReplacedEventSpec,
        replacement_effects: Vec<E>,
        display: impl Into<String>,
    ) -> Self {
        let mut ability = Self::event_replacement_with_effects(event, replacement_effects, display);
        if let StaticAbilityPayload::EventReplacementWithEffects { optional, .. } =
            &mut ability.payload
        {
            *optional = true;
        }
        ability
    }
    /// "If you would draw a card, instead <effects>." (Underrealm Lich)
    pub fn draw_replacement_with_effects(
        drawer: PlayerFilter,
        except_first_of_draw_step: bool,
        replacement_effects: Vec<E>,
        display: impl Into<String>,
    ) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::DrawReplacementWithEffects),
            label: display.clone(),
            payload: StaticAbilityPayload::DrawReplacementWithEffects {
                drawer,
                except_first_of_draw_step,
                replacement_effects,
                display,
                cycling_source: None,
            },
        }
    }
    /// "If a cycling ability of <filter> would cause you to draw a card,
    /// instead <effects>." (Unpredictable Cyclone)
    pub fn draw_replacement_with_effects_for_cycling_source(
        drawer: PlayerFilter,
        cycling_source: ObjectFilter,
        replacement_effects: Vec<E>,
        display: impl Into<String>,
    ) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::DrawReplacementWithEffects),
            label: display.clone(),
            payload: StaticAbilityPayload::DrawReplacementWithEffects {
                drawer,
                except_first_of_draw_step: false,
                replacement_effects,
                display,
                cycling_source: Some(cycling_source),
            },
        }
    }
    pub fn modify_damage_amount_replacement(
        source_filter: ObjectFilter,
        target_player_filter: Option<PlayerFilter>,
        target_object_filter: Option<ObjectFilter>,
        delta: i32,
        display: impl Into<String>,
    ) -> Self {
        Self::modify_damage_amount_replacement_with_noncombat_only(
            source_filter,
            target_player_filter,
            target_object_filter,
            delta,
            false,
            display,
        )
    }

    pub fn modify_damage_amount_replacement_with_noncombat_only(
        source_filter: ObjectFilter,
        target_player_filter: Option<PlayerFilter>,
        target_object_filter: Option<ObjectFilter>,
        delta: i32,
        noncombat_only: bool,
        display: impl Into<String>,
    ) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::ModifyDamageAmountReplacement),
            label: display.clone(),
            payload: StaticAbilityPayload::ModifyDamageAmountReplacement {
                source_filter,
                target_player_filter,
                target_object_filter,
                delta,
                dynamic_delta: None,
                noncombat_only,
                display,
            },
        }
    }
    /// A live additive bonus is distinct from a resolving, captured X bonus.
    pub fn with_dynamic_damage_delta(mut self, value: Value) -> Self {
        if let StaticAbilityPayload::ModifyDamageAmountReplacement { dynamic_delta, .. } =
            &mut self.payload
        {
            *dynamic_delta = Some(value);
        }
        self
    }
    /// Restrict a multiplied-damage replacement to noncombat damage
    /// ("would deal noncombat damage", Solphim, Mayhem Dominus).
    pub fn with_noncombat_only_damage_multiplier(mut self) -> Self {
        if let StaticAbilityPayload::DoubleDamageAmountReplacement { noncombat_only, .. } =
            &mut self.payload
        {
            *noncombat_only = true;
        }
        self
    }
    pub fn minimum_damage_amount_replacement(
        source_filter: ObjectFilter,
        target_player_filter: Option<PlayerFilter>,
        target_object_filter: Option<ObjectFilter>,
        floor: Value,
        noncombat_only: bool,
        display: impl Into<String>,
    ) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::ModifyDamageAmountReplacement),
            label: display.clone(),
            payload: StaticAbilityPayload::MinimumDamageAmountReplacement {
                source_filter,
                target_player_filter,
                target_object_filter,
                floor,
                noncombat_only,
                display,
            },
        }
    }
    pub fn double_damage_amount_replacement(
        source_filter: ObjectFilter,
        target_player_filter: Option<PlayerFilter>,
        target_object_filter: Option<ObjectFilter>,
        display: impl Into<String>,
    ) -> Self {
        Self::multiply_damage_amount_replacement(
            source_filter,
            target_player_filter,
            target_object_filter,
            2,
            false,
            display,
        )
    }

    pub fn multiply_damage_amount_replacement(
        source_filter: ObjectFilter,
        target_player_filter: Option<PlayerFilter>,
        target_object_filter: Option<ObjectFilter>,
        factor: u32,
        combat_only: bool,
        display: impl Into<String>,
    ) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::ModifyDamageAmountReplacement),
            label: display.clone(),
            payload: StaticAbilityPayload::DoubleDamageAmountReplacement {
                source_filter,
                target_player_filter,
                target_object_filter,
                factor,
                combat_only,
                noncombat_only: false,
                display,
            },
        }
    }

    pub fn prevent_matching_damage_with_follow_up(spec: StaticDamagePreventionFollowUp<E>) -> Self {
        Self {
            id: Some(StaticAbilityId::PreventMatchingDamage),
            label: spec.display.clone(),
            payload: StaticAbilityPayload::PreventMatchingDamageWithFollowUp(spec),
        }
    }

    pub fn redirect_matching_damage(spec: StaticDamageRedirectionSpec) -> Self {
        Self {
            id: Some(StaticAbilityId::RedirectMatchingDamage),
            label: spec.display.clone(),
            payload: StaticAbilityPayload::RedirectMatchingDamage(spec),
        }
    }

    pub fn prevent_matching_damage(spec: PreventMatchingDamageSpec) -> Self {
        Self {
            id: Some(StaticAbilityId::PreventMatchingDamage),
            label: spec.display.clone(),
            payload: StaticAbilityPayload::PreventMatchingDamage(spec),
        }
    }

    pub fn prevent_half_damage_replacement(
        source_filter: ObjectFilter,
        target_player_filter: Option<PlayerFilter>,
        target_object_filter: Option<ObjectFilter>,
        round_up: bool,
        display: impl Into<String>,
    ) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::PreventHalfDamageReplacement),
            label: display.clone(),
            payload: StaticAbilityPayload::PreventHalfDamageReplacement {
                source_filter,
                target_player_filter,
                target_object_filter,
                round_up,
                display,
            },
        }
    }

    pub fn double_counters_replacement(
        filter: ObjectFilter,
        counter_type: Option<CounterType>,
        display: impl Into<String>,
    ) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::DoubleCountersReplacement),
            label: display.clone(),
            payload: StaticAbilityPayload::DoubleCountersReplacement {
                filter,
                player_filter: None,
                counter_type,
                actor: None,
                includes_permanents: false,
                halve: false,
                effect_only: false,
                display,
            },
        }
    }

    /// Restrict a counter-doubling replacement to counters put on by an
    /// effect ("If an effect would put one or more counters ...").
    pub fn effect_caused_counters_only(mut self) -> Self {
        if let StaticAbilityPayload::DoubleCountersReplacement { effect_only, .. } =
            &mut self.payload
        {
            *effect_only = true;
        }
        self
    }

    /// "If you would put one or more counters on a permanent or player, put
    /// twice that many of each of those kinds of counters on that permanent
    /// or player instead." (Innkeeper's Talent, Vorinclex); `halve` reads
    /// "they put half that many ... instead, rounded down".
    pub fn actor_counter_multiplier_replacement(
        actor: PlayerFilter,
        halve: bool,
        display: impl Into<String>,
    ) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::DoubleCountersReplacement),
            label: display.clone(),
            payload: StaticAbilityPayload::DoubleCountersReplacement {
                filter: ObjectFilter::permanent(),
                player_filter: Some(PlayerFilter::Any),
                counter_type: None,
                actor: Some(actor),
                includes_permanents: true,
                halve,
                effect_only: false,
                display,
            },
        }
    }

    pub fn counters_remain_across_zone_changes(
        excluded_destinations: Vec<Zone>,
        display: impl Into<String>,
    ) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::CountersRemainAcrossZoneChanges),
            label: display.clone(),
            payload: StaticAbilityPayload::CountersRemainAcrossZoneChanges {
                excluded_destinations,
                display,
            },
        }
    }

    pub fn actor_counters_addition_replacement(
        filter: ObjectFilter,
        player_filter: Option<PlayerFilter>,
        actor: PlayerFilter,
        counter_type: Option<CounterType>,
        additional: impl Into<i64>,
        display: impl Into<String>,
    ) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::AddCountersPlacementReplacement),
            label: display.clone(),
            payload: StaticAbilityPayload::ActorCountersAddition {
                filter,
                player_filter,
                actor,
                counter_type,
                additional: additional.into(),
                display,
            },
        }
    }

    pub fn add_counters_placement_replacement(
        filter: ObjectFilter,
        counter_type: Option<CounterType>,
        additional: impl Into<i64>,
        display: impl Into<String>,
    ) -> Self {
        let display = display.into();
        let additional = additional.into();
        Self {
            id: Some(StaticAbilityId::AddCountersPlacementReplacement),
            label: display.clone(),
            payload: StaticAbilityPayload::AddCountersPlacementReplacement {
                filter,
                player_filter: None,
                counter_type,
                additional,
                cause: None,
                display,
            },
        }
    }

    /// "If you would get one or more counters, you get that many plus one of
    /// each of those kinds of counters instead." (Winding Constrictor)
    pub fn add_player_counters_placement_replacement(
        player_filter: PlayerFilter,
        counter_type: Option<CounterType>,
        additional: impl Into<i64>,
        display: impl Into<String>,
    ) -> Self {
        let display = display.into();
        let additional = additional.into();
        Self {
            id: Some(StaticAbilityId::AddCountersPlacementReplacement),
            label: display.clone(),
            payload: StaticAbilityPayload::AddCountersPlacementReplacement {
                filter: ObjectFilter::default(),
                player_filter: Some(player_filter),
                counter_type,
                additional,
                cause: None,
                display,
            },
        }
    }

    /// Limit a counter-placement addition to placements from a matching
    /// cause ("If a modular triggered ability would put ..." — Zabaz).
    pub fn with_counter_placement_cause(mut self, required: crate::CauseFilter) -> Self {
        if let StaticAbilityPayload::AddCountersPlacementReplacement { cause, .. } =
            &mut self.payload
        {
            *cause = Some(required);
        }
        self
    }

    pub fn double_player_counters_replacement(
        player_filter: PlayerFilter,
        counter_type: Option<CounterType>,
        display: impl Into<String>,
    ) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::DoubleCountersReplacement),
            label: display.clone(),
            payload: StaticAbilityPayload::DoubleCountersReplacement {
                filter: ObjectFilter::default(),
                player_filter: Some(player_filter),
                counter_type,
                actor: None,
                includes_permanents: false,
                halve: false,
                effect_only: false,
                display,
            },
        }
    }

    pub fn player_counter_per_turn_limit_replacement(
        player_filter: PlayerFilter,
        counter_type: CounterType,
        maximum: u32,
        display: impl Into<String>,
    ) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::PlayerCounterPerTurnLimitReplacement),
            label: display.clone(),
            payload: StaticAbilityPayload::PlayerCounterPerTurnLimitReplacement {
                player_filter,
                counter_type,
                maximum,
                display,
            },
        }
    }

    pub fn multiply_token_creation_replacement(
        controller: PlayerFilter,
        token_filter: Option<ObjectFilter>,
        factor: u32,
        display: impl Into<String>,
    ) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::MultiplyTokenCreationReplacement),
            label: display.clone(),
            payload: StaticAbilityPayload::MultiplyTokenCreationReplacement {
                controller,
                token_filter,
                factor,
                display,
            },
        }
    }
    pub fn double_token_creation_replacement(
        controller: PlayerFilter,
        display: impl Into<String>,
    ) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::DoubleTokenCreationReplacement),
            label: display.clone(),
            payload: StaticAbilityPayload::DoubleTokenCreationReplacement {
                controller,
                display,
            },
        }
    }

    pub fn add_token_creation_replacement(
        controller: PlayerFilter,
        token_filter: ObjectFilter,
        additional_token: AdditionalTokenKind,
        additional: i32,
        display: impl Into<String>,
    ) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::AddTokenCreationReplacement),
            label: display.clone(),
            payload: StaticAbilityPayload::AddTokenCreationReplacement {
                controller,
                token_filter,
                additional_token,
                additional,
                per_created: false,
                display,
            },
        }
    }

    /// "If one or more tokens would be created under your control, those
    /// tokens plus that many <token> tokens are created instead."
    pub fn add_token_per_created_replacement(
        controller: PlayerFilter,
        token_filter: ObjectFilter,
        additional_token: AdditionalTokenKind,
        display: impl Into<String>,
    ) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::AddTokenCreationReplacement),
            label: display.clone(),
            payload: StaticAbilityPayload::AddTokenCreationReplacement {
                controller,
                token_filter,
                additional_token,
                additional: 1,
                per_created: true,
                display,
            },
        }
    }

    pub fn discard_or_redirect_replacement(filter: ObjectFilter, redirect_zone: Zone) -> Self {
        Self {
            id: Some(StaticAbilityId::DiscardOrRedirectReplacement),
            label: "discard or redirect replacement".into(),
            payload: StaticAbilityPayload::DiscardOrRedirectReplacement {
                filter,
                redirect_zone,
            },
        }
    }
    pub fn sacrifice_or_redirect_replacement(
        filter: ObjectFilter,
        count: u32,
        redirect_zone: Zone,
    ) -> Self {
        Self {
            id: Some(StaticAbilityId::SacrificeOrRedirectReplacement),
            label: "sacrifice or redirect replacement".into(),
            payload: StaticAbilityPayload::SacrificeOrRedirectReplacement {
                filter,
                count,
                redirect_zone,
            },
        }
    }
    pub fn pay_life_or_enter_tapped(value: u32) -> Self {
        Self {
            id: Some(StaticAbilityId::PayLifeOrEnterTappedReplacement),
            label: "pay life or enter tapped".to_string(),
            payload: StaticAbilityPayload::PayLifeOrEnterTapped(value),
        }
    }
    pub fn reveal_card_or_enter_tapped(
        filter: ObjectFilter,
        subject: impl Into<String>,
        tail_subject: impl Into<String>,
    ) -> Self {
        Self {
            id: Some(StaticAbilityId::RevealCardOrEnterTappedReplacement),
            label: "reveal card or enter tapped".to_string(),
            payload: StaticAbilityPayload::RevealCardOrEnterTapped {
                filter,
                subject: subject.into(),
                tail_subject: tail_subject.into(),
            },
        }
    }
    pub fn redirect_would_enter(
        filter: ObjectFilter,
        not_cast: bool,
        destination: Zone,
        display: impl Into<String>,
    ) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::RedirectWouldEnterReplacement),
            label: display.clone(),
            payload: StaticAbilityPayload::RedirectWouldEnter {
                filter,
                not_cast,
                destination,
                display,
                or_no_mana_spent: false,
            },
        }
    }

    /// "If this creature would enter and it wasn't cast or no mana was spent
    /// to cast it, exile it instead." (Primeval Spawn)
    pub fn redirect_would_enter_unless_paid_cast(
        filter: ObjectFilter,
        destination: Zone,
        display: impl Into<String>,
    ) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::RedirectWouldEnterReplacement),
            label: display.clone(),
            payload: StaticAbilityPayload::RedirectWouldEnter {
                filter,
                not_cast: true,
                destination,
                display,
                or_no_mana_spent: true,
            },
        }
    }
    pub fn mana_production_multiplier_replacement(
        source_filter: ObjectFilter,
        factor: u32,
        display: impl Into<String>,
    ) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::ManaProductionMultiplierReplacement),
            label: display.clone(),
            payload: StaticAbilityPayload::ManaProductionMultiplierReplacement {
                source_filter,
                factor,
                display,
            },
        }
    }
    pub fn convert_unspent_mana(player: PlayerFilter, symbol: crate::mana::ManaSymbol) -> Self {
        Self {
            id: Some(StaticAbilityId::ConvertUnspentMana),
            label: format!(
                "If {} would lose unspent mana, that mana becomes {} instead",
                player.description(),
                format!("{symbol:?}").to_ascii_lowercase()
            ),
            payload: StaticAbilityPayload::ConvertUnspentMana { player, symbol },
        }
    }

    pub fn mana_production_rewrite(
        rule: crate::mana::ManaOutputRewrite,
        display: impl Into<String>,
    ) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::ManaProductionRewrite),
            label: display.clone(),
            payload: StaticAbilityPayload::ManaProductionRewrite { rule, display },
        }
    }

    pub fn mana_production_replacement(
        source_filter: ObjectFilter,
        minimum_amount: u32,
        replacement_mana: Vec<crate::ManaSymbol>,
        display: impl Into<String>,
    ) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::ManaProductionReplacement),
            label: display.clone(),
            payload: StaticAbilityPayload::ManaProductionReplacement {
                source_filter,
                minimum_amount,
                replacement_mana,
                display,
            },
        }
    }
    pub fn token_creation_templates(
        controller: PlayerFilter,
        token_filter: ObjectFilter,
        templates: Vec<E>,
        mode: TokenCreationTemplateMode,
        choose_one: bool,
        optional: bool,
        display: impl Into<String>,
    ) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::TokenCreationTemplates),
            label: display.clone(),
            payload: StaticAbilityPayload::TokenCreationTemplates {
                controller,
                token_filter,
                templates,
                mode,
                choose_one,
                optional,
                display,
            },
        }
    }

    pub fn add_life_gain_replacement(
        player: PlayerFilter,
        additional: i32,
        display: impl Into<String>,
    ) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::AddLifeGainReplacement),
            label: display.clone(),
            payload: StaticAbilityPayload::AddLifeGainReplacement {
                player,
                additional,
                display,
            },
        }
    }

    pub fn double_life_change_replacement(
        player: PlayerFilter,
        loss: bool,
        display: impl Into<String>,
    ) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::DoubleLifeChangeReplacement),
            label: display.clone(),
            payload: StaticAbilityPayload::DoubleLifeChangeReplacement {
                player,
                loss,
                display,
            },
        }
    }
    pub fn copy_activated_abilities(copy: CopyActivatedAbilities) -> Self {
        Self {
            id: Some(StaticAbilityId::CopyActivatedAbilities),
            label: "copy activated abilities".to_string(),
            payload: StaticAbilityPayload::CopyActivatedAbilities(copy),
        }
    }
    pub fn copy_static_ability_variants(copy: CopyStaticAbilityVariants) -> Self {
        Self {
            id: Some(StaticAbilityId::CopyStaticAbilityVariants),
            label: copy.display.clone(),
            payload: StaticAbilityPayload::CopyStaticAbilityVariants(copy),
        }
    }
    pub fn copy_triggered_abilities(copy: CopyTriggeredAbilities) -> Self {
        Self {
            id: Some(StaticAbilityId::CopyTriggeredAbilities),
            label: copy.display.clone(),
            payload: StaticAbilityPayload::CopyTriggeredAbilities(copy),
        }
    }
    pub fn mana_spend_permission(perm: ManaSpendPermission, display: impl Into<String>) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::ManaSpendPermission),
            label: display.clone(),
            payload: StaticAbilityPayload::ManaSpendPermission {
                permission: perm,
                display,
            },
        }
    }
    pub fn enters_with_counters_if_condition(
        counter: CounterType,
        count: Value,
        condition: ICond,
        display: impl Into<String>,
    ) -> Self {
        Self::enters_with_counters_and_abilities_if_condition(
            counter,
            count,
            condition,
            display,
            Vec::new(),
        )
    }

    pub fn enters_with_counters_and_abilities_if_condition(
        counter: CounterType,
        count: Value,
        condition: ICond,
        display: impl Into<String>,
        added_abilities: Vec<AbilityModel<T, E, C, Cond, ICond>>,
    ) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::EnterWithCountersIfCondition),
            label: display.clone(),
            payload: StaticAbilityPayload::EntersWithCountersIfCondition {
                counter,
                count,
                condition,
                display,
                added_abilities,
            },
        }
    }
    pub fn intrinsic_starting_counters(rule: IntrinsicStartingCounter) -> Self {
        Self {
            id: Some(StaticAbilityId::EnterWithCounters),
            label: match rule {
                IntrinsicStartingCounter::Loyalty => {
                    "Enters with loyalty counters equal to its printed loyalty number"
                }
                IntrinsicStartingCounter::Defense => {
                    "Enters with defense counters equal to its printed defense number"
                }
            }
            .into(),
            payload: StaticAbilityPayload::IntrinsicStartingCounters(rule),
        }
    }

    pub fn enters_with_counters_value(counter: CounterType, count: Value) -> Self {
        let counter_text = counter.description();
        let label = match &count {
            Value::Fixed(1) => {
                let article = match counter_text
                    .chars()
                    .next()
                    .map(|ch| ch.to_ascii_lowercase())
                {
                    Some('a' | 'e' | 'i' | 'o' | 'u') => "an",
                    _ => "a",
                };
                if count.has_surface_hint(ValueSurfaceHint::AdditionalEntryCounter) {
                    format!(
                        "Enters the battlefield with an additional {counter_text} counter on it"
                    )
                } else {
                    format!("Enters the battlefield with {article} {counter_text} counter on it")
                }
            }
            _ => "enters with counters value".to_string(),
        };
        Self {
            id: Some(StaticAbilityId::EnterWithCounters),
            label,
            payload: StaticAbilityPayload::EntersWithCountersValue { counter, count },
        }
    }

    pub fn enters_with_counter_choice(counter_types: Vec<CounterType>, count: Value) -> Self {
        Self {
            id: Some(StaticAbilityId::EnterWithCounters),
            label: "enters with counter choice".to_string(),
            payload: StaticAbilityPayload::EntersWithCounterChoice {
                counter_types,
                count,
                kinds: 1,
                condition: None,
                display: String::new(),
            },
        }
    }

    /// "enters with your choice of two different counters on it from among
    /// A, B, and C" (Grimdancer): `kinds` different kinds, `count` of each.
    pub fn enters_with_distinct_counter_choice(
        counter_types: Vec<CounterType>,
        count: Value,
        kinds: u32,
    ) -> Self {
        Self {
            id: Some(StaticAbilityId::EnterWithCounters),
            label: "enters with counter choice".to_string(),
            payload: StaticAbilityPayload::EntersWithCounterChoice {
                counter_types,
                count,
                kinds,
                condition: None,
                display: String::new(),
            },
        }
    }

    pub fn enters_with_counter_choice_if_condition(
        counter_types: Vec<CounterType>,
        count: Value,
        condition: ICond,
        display: impl Into<String>,
    ) -> Self {
        let display = display.into();
        Self {
            id: Some(StaticAbilityId::EnterWithCounters),
            label: "enters with counter choice".to_string(),
            payload: StaticAbilityPayload::EntersWithCounterChoice {
                counter_types,
                count,
                kinds: 1,
                condition: Some(condition),
                display,
            },
        }
    }

    pub fn enters_under_chosen_control(players: PlayerFilter) -> Self {
        Self {
            id: Some(StaticAbilityId::EntersUnderChosenControl),
            label: "enters under chosen control".into(),
            payload: StaticAbilityPayload::EntersUnderChosenControl(players),
        }
    }
    pub fn enters_tapped_for_filter(filter: ObjectFilter) -> Self {
        Self {
            id: Some(StaticAbilityId::EnterTappedForFilter),
            label: "enters tapped for filter".to_string(),
            payload: StaticAbilityPayload::EntersTappedForFilter(filter),
        }
    }
    pub fn enters_untapped_for_filter(filter: ObjectFilter) -> Self {
        Self {
            id: Some(StaticAbilityId::EnterUntappedForFilter),
            label: "enters untapped for filter".to_string(),
            payload: StaticAbilityPayload::EntersUntappedForFilter(filter),
        }
    }
    pub fn enters_tapped_unless_control_two_or_more_other_lands() -> Self {
        Self::identified(
            StaticAbilityId::EntersTappedUnlessControlTwoOrMoreOtherLands,
            "enters tapped unless control two or more other lands",
        )
    }
    pub fn enters_tapped_unless_control_two_or_fewer_other_lands() -> Self {
        Self::identified(
            StaticAbilityId::EntersTappedUnlessControlTwoOrFewerOtherLands,
            "enters tapped unless control two or fewer other lands",
        )
    }
    pub fn enters_tapped_unless_control_two_or_more_basic_lands() -> Self {
        Self::identified(
            StaticAbilityId::EntersTappedUnlessControlTwoOrMoreBasicLands,
            "enters tapped unless control two or more basic lands",
        )
    }
    pub fn enters_tapped_unless_a_player_has_13_or_less_life() -> Self {
        Self::identified(
            StaticAbilityId::EntersTappedUnlessAPlayerHas13OrLessLife,
            "enters tapped unless a player has 13 or less life",
        )
    }
    pub fn enters_tapped_unless_two_or_more_opponents() -> Self {
        Self::identified(
            StaticAbilityId::EntersTappedUnlessTwoOrMoreOpponents,
            "enters tapped unless two or more opponents",
        )
    }
    pub fn enters_with_counter_kinds_for_filter(
        filter: ObjectFilter, counter_source: ChooseSpec, count: Value,
    ) -> Self {
        let mut ability = Self::enters_with_counters_and_subtypes_for_filter(
            filter, CounterType::PlusOnePlusOne, count, Vec::new(),
        );
        if let StaticAbilityPayload::EntersWithCountersAndSubtypesForFilter { counter_kinds_from, .. } = &mut ability.payload {
            *counter_kinds_from = Some(counter_source);
        }
        ability
    }

    pub fn enters_with_counters_and_subtypes_for_filter(
        filter: ObjectFilter,
        counter: CounterType,
        count: Value,
        subtypes: Vec<Subtype>,
    ) -> Self {
        Self {
            id: Some(StaticAbilityId::EnterWithCountersForFilter),
            label: "enters with counters and subtypes for filter".to_string(),
            payload: StaticAbilityPayload::EntersWithCountersAndSubtypesForFilter {
                filter,
                counter,
                counter_kinds_from: None,
                count,
                count_condition: None,
                otherwise_count: None,
                subtypes,
            },
        }
    }

    pub fn enters_with_counters_and_subtypes_for_filter_if_otherwise(
        filter: ObjectFilter,
        counter: CounterType,
        count: Value,
        count_condition: Condition,
        otherwise_count: Value,
        subtypes: Vec<Subtype>,
    ) -> Self {
        Self {
            id: Some(StaticAbilityId::EnterWithCountersForFilter),
            label: "conditional enters with counters and subtypes for filter".to_string(),
            payload: StaticAbilityPayload::EntersWithCountersAndSubtypesForFilter {
                filter,
                counter,
                counter_kinds_from: None,
                count,
                count_condition: Some(count_condition),
                otherwise_count: Some(otherwise_count),
                subtypes,
            },
        }
    }

    pub fn enters_face_down_for_filter(filter:ObjectFilter)->Self {
        Self {
            id:Some(StaticAbilityId::EnterWithCharacteristicsForFilter),
            label:"enters face-down for filter".into(),
            payload:StaticAbilityPayload::EntersWithCharacteristicsForFilter {
                face_down:true,filter,card_types:Vec::new(),subtypes:Vec::new(),power:2,toughness:2,
            },
        }
    }

    pub fn enters_with_characteristics_for_filter(
        filter: ObjectFilter,
        card_types: Vec<CardType>,
        subtypes: Vec<Subtype>,
        power: i32,
        toughness: i32,
    ) -> Self {
        Self {
            id: Some(StaticAbilityId::EnterWithCharacteristicsForFilter),
            label: "enters with characteristics for filter".to_string(),
            payload: StaticAbilityPayload::EntersWithCharacteristicsForFilter {
                face_down: false,
                filter,
                card_types,
                subtypes,
                power,
                toughness,
            },
        }
    }
}

#[cfg(test)]
mod tests;

#[cfg(all(test, feature = "serde"))]
mod cast_timing_payload_tests {
    #[test]
    fn old_label_only_payload_stays_stable_and_new_timing_is_typed() {
        let old = super::ThisSpellCastRestrictionKind::during_combat();
        let value = serde_json::to_value(&old).unwrap();
        assert!(value.get("timing").is_none());
        let restored: super::ThisSpellCastRestrictionKind = serde_json::from_value(value).unwrap();
        assert_eq!(restored, old);
        let new = super::ThisSpellCastRestrictionKind::timing(
            crate::ThisSpellCastTiming::DuringDeclareBlockersStep,
        );
        let restored: super::ThisSpellCastRestrictionKind =
            serde_json::from_str(&serde_json::to_string(&new).unwrap()).unwrap();
        assert_eq!(
            restored.timing,
            Some(crate::ThisSpellCastTiming::DuringDeclareBlockersStep)
        );
    }
}

/// Serde default for [`StaticAbilityPayload::ChooseColorAsEnters`]'s count:
/// payloads written before multi-color choices choose one color.
pub fn one_chosen_color() -> u32 {
    1
}

/// Serde default for `EntersWithCounterChoice::kinds`: payloads written
/// before multi-kind choices choose one counter kind.
pub fn one_counter_choice_kind() -> u32 {
    1
}

#[cfg(feature = "serde")]
fn static_implied_words_are_false(value: &bool) -> bool { !*value }

#[cfg(all(test, feature = "serde"))]
mod entry_counter_choice_serde_tests {
    #[derive(Debug, serde::Serialize, serde::Deserialize)]
    enum ConditionWithoutDefault { Allowed }

    #[test]
    fn entry_counter_choice_missing_condition_needs_no_default_condition_bound() {
        type Payload = super::StaticAbilityPayload<(), (), (), (), ConditionWithoutDefault>;
        let payload = Payload::EntersWithCounterChoice {
            counter_types: vec![crate::CounterType::Flying],
            count: crate::Value::Fixed(1),
            kinds: 1,
            condition: None,
            display: String::new(),
        };
        let mut encoded = serde_json::to_value(payload).unwrap();
        encoded["EntersWithCounterChoice"].as_object_mut().unwrap().remove("condition");
        let restored: Payload = serde_json::from_value(encoded).unwrap();
        let Payload::EntersWithCounterChoice { condition, .. } = restored else { panic!("counter choice"); };
        assert!(condition.is_none());
    }
}

#[cfg(feature="serde")]
fn face_down_entry_is_false(value:&bool)->bool{!*value}
#[cfg(all(test,feature="serde"))]
mod resolution_recipe_policy_tests {
    use super::*;
    type Model=StaticAbility<(),(),(),()>;
    #[test]
    fn default_instance_policy_keeps_old_wire_shape_and_declared_keys_round_trip(){
        let original=Model::spell_resolution_destination_program(Some(Zone::Hand),Zone::Exile,ResolutionProgram::from_effects(vec![()]));
        let default=serde_json::to_value(&original).unwrap();
        assert!(default["payload"]["SpellResolutionDestinationProgram"].get("multiplicity").is_none());
        let restored:Model=serde_json::from_value(default).unwrap();
        assert!(matches!(restored.payload,StaticAbilityPayload::SpellResolutionDestinationProgram{multiplicity:SpellResolutionProgramMultiplicity::PerInstance,..}));
        let declared=original.with_spell_resolution_program_multiplicity(SpellResolutionProgramMultiplicity::OncePerDeclaredKey{key:"authored recipe".into()});
        let wire=serde_json::to_value(&declared).unwrap();let restored:Model=serde_json::from_value(wire).unwrap();assert_eq!(declared,restored);
    }
}
