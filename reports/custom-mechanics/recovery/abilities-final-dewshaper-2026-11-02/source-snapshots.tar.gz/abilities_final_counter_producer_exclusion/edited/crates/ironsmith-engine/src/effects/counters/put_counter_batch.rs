//! Simultaneous heterogeneous counter originals, including replacement continuations.
use crate::effects::{EffectExecutor,ExecutionContext,ExecutionError};
use crate::effect::EffectOutcome;
use crate::game_state::GameState;
pub use ironsmith_core::PutCounterBatchEffect;
impl EffectExecutor for PutCounterBatchEffect {
    fn execute(&self,game:&mut GameState,ctx:&mut ExecutionContext)->Result<EffectOutcome,ExecutionError>{
        self.execute_with_outputs(game,ctx).map(crate::effects::CompletedEffectOutputs::into_outcome)
    }
    fn execute_with_outputs(&self,game:&mut GameState,ctx:&mut ExecutionContext)->Result<crate::effects::CompletedEffectOutputs,ExecutionError>{
        let (cause,provenance,maximum)=if self.use_replaced_event_cause {
            let original=ctx.triggering_event.as_ref().ok_or_else(||ExecutionError::IncompleteEvidence("counter continuation has no original event".into()))?;
            let event=original.downcast::<crate::events::PutCountersEvent>().ok_or_else(||ExecutionError::IncompleteEvidence("counter continuation requires original counter placement".into()))?;
            (event.cause.clone(),original.provenance(),event.maximum_count)
        }else{(ctx.cause.clone(),ctx.provenance,None)};
        // A cap on a whole heterogeneous proposal needs its explicit allocation
        // contract. Existing permanent counter proposals have no such cap;
        // player one-counter limits can produce only one nonempty branch.
        if maximum.is_some() && self.counters.iter().filter(|(_,count)|*count>0).count()>1 {
            return Err(ExecutionError::IncompleteEvidence("heterogeneous counter continuation requires a whole-proposal count-limit allocation".into()));
        }
        let recipients=crate::effects::helpers::resolve_objects_for_effect(game,ctx,&self.target)?;
        if ctx.decision_maker.awaiting_choice(){return Ok(crate::effects::CompletedEffectOutputs::aggregate_only(EffectOutcome::count(0)));}
        let mut programs=Vec::new();
        for recipient in recipients {
            for &(kind,count) in &self.counters {
                if count==0{continue;}
                let mut event=crate::events::PutCountersEvent::with_cause(crate::game_state::Target::Object(recipient),kind,count,cause.clone());event.maximum_count=maximum;
                programs.push((crate::effects::ExecutionContextCheckpoint::capture(ctx),crate::events::Event::new_with_provenance(event,provenance)));
            }
        }
        super::prepared_placement::execute_scoped_counter_placements_with_outputs(game,ctx,programs,|_,_|Ok(()))
    }
    fn get_target_spec(&self)->Option<&crate::target::ChooseSpec>{Some(&self.target)}
    fn result_action(&self)->Option<crate::effect::PriorEffectAction>{Some(crate::effect::PriorEffectAction::CountersPut)}
}
