use crate::effect::Effect;
pub use ironsmith_core::{
    AdaptEffect, AddManaEffect, AddManaFromCommanderColorIdentityEffect, AddManaOfAnyColorEffect,
    AddManaOfAnyOneColorEffect, AddManaOfLandProducedTypesEffect, AddManaOfNotedTypeEffect,
    AdditionalLandPlaysEffect, AdditionalPhase, AdditionalPhasesEffect, AdditionalStepAnchor, AdditionalStepKind, AdditionalStepsEffect, AmassEffect, EmpowerJaceEffect, CollectEvidenceEffect, AmplifyEffect,
    AssignNoCombatDamageEffect, AttachObjectsEffect, AttachToEffect, AuraSwapEffect, BackupEffect,
    BattlefieldController, BecomeBasicLandTypeChoiceEffect, BecomeColorChoiceEffect,
    BecomeCreatureTypeChoiceEffect, BecomeMonarchEffect, BecomePlottedEffect, BecomeForetoldEffect, GrantLoyaltyActivationAllowanceEffect,
    GrantTapUncontrolledLandsForManaEffect, LoyaltyActivationAllowance, LoyaltyActivationScope,
    BecomeSaddledUntilEotEffect, BeholdEffect, BidLifeEffect as CoreBidLifeEffect, BolsterEffect,
    CantEffect, CastSourceEffect, CastTaggedEffect as CoreCastTaggedEffect, ChooseCardNameEffect, ChooseCardTypeEffect,
    RemoveOptionalTextFragmentEffect, ChangeTextEffect, ChooseColorEffect, ChooseCreatureTypeEffect, ChooseLandTypeEffect,
    ChooseModeEffect as CoreChooseModeEffect, ChooseNamedOptionEffect, ChooseNewTargetsEffect,
    RippleEffect, ChooseNumberAtRandomEffect, ChooseNumberEffect, ChooseObjectsEffect, ChoosePlayerEffect,
    ChooseSpellCastHistoryEffect, CipherEffect, ClashEffect, ClearGoadEffect, ClearSuspectedEffect,
    CombatDamagePreventionTarget, ConditionalEffect as CoreConditionalEffect, ConniveEffect,
    ConspireCostEffect, ConsultTopOfLibraryEffect, ConsultTopOfLibraryStopRule,
    ControlCombatChoicesThisTurnEffect, ControlPlayerEffect, ConvertEffect, CopySpellEffect,
    CopySpellForEachTargetEffect, CounterEffect, CreateEmblemEffect as CoreCreateEmblemEffect,
    CreateTokenEffect as CoreCreateTokenEffect, CrewCostEffect, SaddleCostEffect,
    CumulativeUpkeepEffect as CoreCumulativeUpkeepEffect, DealDamageEffect,
    DealDistributedDamageEffect, DelayedTriggerSpec, DestroyEffect, DestroyNoRegenerationEffect,
    DetainEffect, DevourEffect, DirectionalAdjacentPlayerControlEffect, DiscardEffect,
    DiscardHandEffect, DiscoverEffect, DoubleCountersEffect, DoubleManaPoolEffect, DrawCardsEffect,
    DrawForEachTaggedMatchingEffect, EachPlayerScryEffect, EarthbendEffect, EmitGiftGivenEffect,
    EmitKeywordActionEffect, PerformNamedActionEffect, EmptyManaPoolEffect, ActivateManaAbilityOfEachLandEffect,
    EndCombatPhaseEffect, EndTurnEffect,
    EnergyCountersEffect, EvolveEffect, ExchangeControlEffect, ExchangeLifeTotalsEffect,
    ExchangeTextBoxesEffect, ExchangeValueOperand, ExchangeValuesEffect, ExchangeZonesEffect,
    ExecuteWithSourceEffect as CoreExecuteWithSourceEffect, ExertCostEffect, ExileEffect,
    ExileInsteadOfGraveyardEffect, ExileTaggedWhenSourceLeavesEffect, ExileTopOfLibraryEffect,
    ExileUntilDuration, ExileUntilEffect, ExperienceCountersEffect, ExploreEffect,
    GivePlayerCountersEffect,
    ExtraTurnAfterNextTurnEffect, ExtraTurnEffect, FatesealEffect, FightEffect, FlipCoinEffect,
    FlipEffect, ForEachControllerOfTaggedEffect, ForEachCounterKindPutOrRemoveEffect,
    ForEachObject as CoreForEachObject,
    ForEachObjectCorrelatedResultEffect as CoreForEachObjectCorrelatedResultEffect,
    ForEachTaggedEffect, ForEachTaggedPlayerEffect, ForPlayersEffect, CollectManaPaymentsEffect, GainLifeEffect, GoadEffect,
    BindXValueEffect,
    MustAttackPlayerThisTurnEffect,
    GrantAbilitiesTargetEffect as CoreGrantAbilitiesTargetEffect,
    GrantBySpecEffect as CoreGrantBySpecEffect, GrantEffect as CoreGrantEffect,
    GrantEndThisEffectPaymentEffect, GrantNextSpellCostReductionEffect, GrantPlayTaggedDuration,
    GrantPlayTaggedEffect as CoreGrantPlayTaggedEffect,
    GrantRepeatableManaPaymentActionUntilEndOfTurnEffect as CoreGrantRepeatableManaPaymentActionUntilEndOfTurnEffect,
    GrantTaggedSpellFreeCastUntilEndOfTurnEffect, GrantTaggedSpellLifeCostByManaValueEffect,
    HauntExileEffect as CoreHauntExileEffect, HealDamageEffect, IfEffect as CoreIfEffect,
    IncubateEffect, InvestigateEffect, LearnEffect, LibraryBottomOrder, LibraryConsultMode,
    LibraryPlacementOrder, LifeBidStart, LocalRewriteEffect as CoreLocalRewriteEffect,
    LookAtHandEffect, LookAtObjectsEffect, LookAtTopCardsEffect, LoseLifeEffect, LoseTheGameEffect,
    ManaRestrictedEffect as CoreManaRestrictedEffect, ManaRetainedEffect as CoreManaRetainedEffect,
    ManaRetentionDuration, ManaTypeSource, ManifestCardFromHandEffect, ManifestDreadEffect,
    ManifestObjectsEffect, ManifestTopCardOfLibraryEffect, MayCastForMiracleCostEffect,
    MayCastMatchingSpellWithoutPayingManaCostEffect, MayEffect, MayMoveToZoneEffect, MeldEffect,
    GrantExileControllerInspectionEffect, SetPermanentDesignationEffect, PermanentDesignation, MillEffect, ModifyPowerToughnessEffect, ModifyPowerToughnessForEachEffect, MonstrosityEffect,
    MoveAllCountersEffect, MoveCountersEffect, MoveOneCounterEffect, MoveToLibraryNthFromTopEffect,
    MoveToLibraryTopOrBottomChoiceEffect, MoveToZoneAttackTargetMode,
    NewTargetRestriction, NextAdaptIgnoresCountersEffect, NinjutsuCostEffect, NinjutsuEffect,
    CastFaceDownUsingActivationManaEffect, RegisterExtraDieReplacementEffect, NoteActivationManaTypeEffect, NoteActivationManaPaymentEffect, NoteTriggeringCreatureTypeEffect, NoteCountersEffect, NoteLifeTotalEffect, RedistributeLifeTotalsEffect, CoinFlipLifeStakesEffect, RedirectEnteringSourceEffect, OpenAttractionEffect, PayAnyEnergyEffect,
    PayAnyLifeEffect, PayEnergyEffect, PayLifeEffect, PayManaEffect, PhaseInEffect,
    PhaseOutDuration, PhaseOutEffect, PlaySubgameEffect, PoisonCountersEffect, PopulateEffect,
    PrepareEffect, PreventAllCombatDamageEffect,
    PreventAllDamageEffect as CorePreventAllDamageEffect,
    PreventAllDamageToTargetEffect as CorePreventAllDamageToTargetEffect,
    PreventDamageEffect as CorePreventDamageEffect, PreventNextTimeDamageEffect,
    PreventNextTimeDamageSource, PreventNextTimeDamageTarget, NextTimeDamagePreventionPortion,
    ProliferateEffect,
    PutCounterOfChosenKindEffect, PutCounterOfKindChosenFromEffect, PutCounterOfRandomKindEffect, PutCountersEffect, PutCounterBatchEffect, PutOntoBattlefieldEffect, PutStickerEffect,
    PutTaggedRemainderOnLibraryBottomEffect, RearrangeLookedCardsInLibraryEffect,
    ReconfigureEffect, RedirectAllDamageThisTurnToTargetEffect, RedirectNextDamageToTargetEffect,
    RedirectNextTimeDamageDestination, RedirectNextTimeDamageSource,
    RedirectNextTimeDamageToSourceEffect, ReduceSpeedEffect,
    ReflexiveTriggerEffect as CoreReflexiveTriggerEffect,
    RegenerateEffect as CoreRegenerateEffect, RegisterCounterPlacementReplacementEffect,
    RegisterDamagedBySourceZoneReplacementEffect,
    RegisterEventReplacementEffect, RegisterDrawReplacementEffect, RegisterEnterTappedReplacementEffect,
    RegisterEnterUnderControlReplacementEffect, RegisterEnterWithCountersReplacementEffect,
    RegisterFutureZoneReplacementEffect, RegisterManaReplacementEffect, RegisterManaRewriteEffect, RegisterManaSpendPermissionEffect,
    RegisterNextBatchEnterAsCopyEffect, RegisterNextBatchEnterWithCountersEffect,
    RegisterZoneReplacementEffect,
    RemoveAnyCountersAmongEffect, RemoveAnyCountersFromSourceEffect, RemoveCountersEffect,
    BecomeBlockedEffect, RemoveFromCombatEffect, ReselectAttackTargetEffect, ExchangeBlocksEffect, UnblockSoleBlockedAttackersEffect, BlockAttackerOfChoiceEffect, RollToVisitAttractionsEffect, TagPlayersEffect, KeepGreatestManaValuePlayersEffect, RollDieKeepHighestPlayersEffect, RetainSpellChoicesEffect, PutRetainedSpellCopyOntoStackEffect, ChooseFriendsOrFoesEffect, RemoveUpToAnyCountersEffect, RemoveUpToCountersEffect, RenownEffect,
    ReorderGraveyardEffect, ReorderLibraryTopEffect, ReorderTopPlanarDeckEffect,
    RepeatProcessPromptEffect,
    ReplaceNextDamageToTargetEffect as CoreReplaceNextDamageToTargetEffect, ReplacementApplyMode,
    ResolvesDespiteIllegalTargetsEffect, RestartGameEffect, RetainManaUntilEndOfTurnEffect,
    RetargetMode, RetargetStackObjectEffect, ReturnAllToBattlefieldEffect, ReturnAsAuraOptions,
    ReturnFromGraveyardOrExileToBattlefieldEffect, ReturnFromGraveyardToBattlefieldEffect,
    ReturnFromGraveyardToHandEffect, ReturnToHandEffect, RevealChosenPlayerEffect,
    RevealChosenSubtypeEffect,
    RevealFromHandEffect, RevealSourceFromHandDuration, RevealSourceFromHandEffect,
    RevealTaggedEffect, RevealTopEffect, ReverseTurnOrderEffect, RingTemptsYouEffect,
    RollDiceChooseResultEffect, RollDieEffect, RollPlanarDieEffect, SacrificeEffect,
    SacrificePlayerEffect,
    SacrificeTargetEffect,
    ScheduleEffectsWhenTaggedLeavesEffect as CoreScheduleEffectsWhenTaggedLeavesEffect, ScryEffect,
    SearchLibraryEffect as CoreSearchLibraryEffect, SearchLibrarySlot,
    SearchLibrarySlotsEffect as CoreSearchLibrarySlotsEffect, SecretChoiceEffect,
    SecretObjectChoice, SequenceEffect as CoreSequenceEffect, SetBasePowerToughnessEffect,
    SetClassLevelEffect, SetLifeTotalEffect, SharedTypeConstraint, DayNightDesignation,
    SetDayNightEffect, ChoosePlayerOptionEffect, PlayerOptionChooser, player_option_choice_tag,
    ControlVotesThisTurnEffect,
    ShuffleGraveyardIntoLibraryEffect, ShuffleHandAndGraveyardIntoLibraryEffect,
    ShuffleLibraryEffect, ShuffleObjectsIntoLibraryEffect, SkipCombatPhasesEffect,
    SkipCombatPhasesThisTurnEffect, SkipDrawStepEffect, SkipScheduledEffect, ScheduledSkipKind, SkipMainPhasesThisTurnEffect,
    SkipNextCombatPhaseThisTurnEffect, SkipTurnEffect, SneakCostEffect, SolveCaseEffect,
    LinkPermanentsEffect, SoulbondPairEffect, SupportEffect, SurveilEffect, SuspectEffect, TagAttachedToSourceEffect,
    TagMatchingObjectsEffect, TagOtherBlockParticipantEffect, TagTriggeringAttackerEffect,
    TagTriggeringBlockersEffect, TagTriggeringDamageTargetEffect, TagTriggeringObjectEffect,
    TagSplicedCardsEffect, TagLastDamageSourceEffect, LinkObjectsToGroupEffect,
    TagTriggeringSourceEffect, TaggedEffect as CoreTaggedEffect, TaggedLeavesAbilitySource,
    TakeInitiativeEffect, TapEffect, TargetOnlyEffect, TicketCountersEffect, TransformEffect,
    UnattachObjectsEffect, UnearthEffect, UnlessActionEffect, UnlessPaysEffect,
    UnlockRoomDoorEffect, UntapEffect, VariableCasualtyPlaneswalkerCopyEffect,
    VentureIntoDungeonEffect, VillainousChoiceEffect as CoreVillainousChoiceEffect,
    WinTheGameEffect, WithIdEffect as CoreWithIdEffect,
};

pub type ChooseModeEffect = CoreChooseModeEffect<Effect>;
pub type CreateEmblemEffect = CoreCreateEmblemEffect<crate::effect::EmblemDescription>;
pub type CreateTokenEffect = CoreCreateTokenEffect<crate::cards::CardDefinition>;
pub type ConditionalEffect = CoreConditionalEffect<Effect>;
pub type CumulativeUpkeepEffect = CoreCumulativeUpkeepEffect<Effect>;
pub type ExecuteWithSourceEffect = CoreExecuteWithSourceEffect<Effect>;
pub type ForEachObject = CoreForEachObject<Effect>;
pub type ForEachObjectCorrelatedResultEffect = CoreForEachObjectCorrelatedResultEffect<Effect>;
pub type HauntExileEffect = CoreHauntExileEffect<Effect>;
pub type IfEffect = CoreIfEffect<Effect>;
pub type LocalRewriteEffect = CoreLocalRewriteEffect<Effect>;
pub type ManaRestrictedEffect = CoreManaRestrictedEffect<Effect>;
pub type ManaRetainedEffect = CoreManaRetainedEffect<Effect>;
pub type PreventAllDamageEffect = CorePreventAllDamageEffect<Effect>;
pub type PreventDamageEffect = CorePreventDamageEffect<Effect>;
pub type PreventAllDamageToTargetEffect = CorePreventAllDamageToTargetEffect<Effect>;
pub type ReplaceNextDamageToTargetEffect = CoreReplaceNextDamageToTargetEffect<Effect>;
pub type RegenerateEffect = CoreRegenerateEffect<Effect>;
pub type ScheduleEffectsWhenTaggedLeavesEffect = CoreScheduleEffectsWhenTaggedLeavesEffect<Effect>;
pub type SequenceEffect = CoreSequenceEffect<Effect>;
pub type WithIdEffect = CoreWithIdEffect<Effect>;
pub type TaggedEffect = CoreTaggedEffect<Effect>;
pub type ReflexiveTriggerEffect = CoreReflexiveTriggerEffect<Effect>;
pub type RepeatEffectsEffect = ironsmith_core::RepeatEffectsEffect<Effect>;
pub type RepeatProcessEffect = ironsmith_core::RepeatProcessEffect<Effect>;
pub type GrantRepeatableManaPaymentActionUntilEndOfTurnEffect =
    CoreGrantRepeatableManaPaymentActionUntilEndOfTurnEffect<Effect>;
pub type BidLifeEffect = CoreBidLifeEffect<Effect>;
pub type VoteChoice = ironsmith_core::VoteChoice<Effect>;
pub type VoteEffect = ironsmith_core::VoteEffect<Effect>;
pub type VillainousChoiceEffect = CoreVillainousChoiceEffect<Effect>;
pub type GrantEffect = CoreGrantEffect<crate::grant::Grantable, crate::grant::GrantDuration>;
pub type GrantBySpecEffect =
    CoreGrantBySpecEffect<crate::grant::GrantSpec, crate::grant::GrantDuration>;
pub type SearchLibraryEffect = CoreSearchLibraryEffect;
pub type SearchLibrarySlotsEffect = CoreSearchLibrarySlotsEffect;

pub type CopyPtAdjustment = ironsmith_core::CopyPtAdjustment;
pub type CopyAttackTargetMode = ironsmith_core::CopyAttackTargetMode;
pub type CreateTokenCopyEffect =
    ironsmith_core::CreateTokenCopyEffect<crate::static_abilities::StaticAbility>;
pub type ScheduleDelayedTriggerEffect = ironsmith_core::ScheduleDelayedTriggerEffect<Effect>;

pub type GrantAbilitiesTargetEffect =
    CoreGrantAbilitiesTargetEffect<crate::static_abilities::StaticAbility>;
pub type ApplyContinuousEffect = ironsmith_core::ApplyContinuousEffect<
    crate::continuous::EffectTarget,
    crate::continuous::Modification,
    continuous::RuntimeModification,
    crate::ConditionExpr,
>;

pub type GrantNextSpellAbilityEffect =
    ironsmith_core::GrantNextSpellAbilityEffect<crate::ability::Ability>;

#[derive(Debug, Clone, PartialEq, serde::Serialize, ironsmith_core::tag::TagKeyWalk)]
pub struct ScaleXValueEffect {
    pub target: crate::target::ChooseSpec,
    pub multiplier: u32,
}

impl ScaleXValueEffect {
    pub fn new(target: crate::target::ChooseSpec, multiplier: u32) -> Self {
        Self { target, multiplier }
    }
}

pub mod cards {
    #[derive(Debug, Clone, PartialEq, serde::Serialize, ironsmith_core::tag::TagKeyWalk)]
    pub struct ImprintFromHandEffect {
        pub filter: crate::target::ObjectFilter,
    }

    impl ImprintFromHandEffect {
        pub fn new(filter: crate::target::ObjectFilter) -> Self {
            Self { filter }
        }
    }
}

pub mod continuous {
    #[derive(Debug, Clone, PartialEq, serde::Serialize, ironsmith_core::tag::TagKeyWalk)]
    pub enum RuntimeModification {
        ModifyPowerToughness {
            power: crate::effect::Value,
            toughness: crate::effect::Value,
        },
        ChangeControllerToEffectController,
        ChangeControllerToPlayer(crate::target::PlayerFilter),
        CopyOf {
            source: crate::target::ChooseSpec,
            preserve_source_abilities: bool,
            name_override: Option<String>,
            name_override_surface: Option<crate::target::SourceReferenceSurface>,
            add_supertypes: Vec<crate::types::Supertype>,
            copy_exception_surface: Option<String>,
        },
        RemoveAllAbilities,
        RemoveThisAbility,
        /// "except it doesn't copy that creature's color" (CR 707.9b): the
        /// source keeps the colors it has as the effect begins.
        RetainSourceColors,
    ClearCopyManaCost,
    RetainSourceName,
    CopyAbilityAbsent(String),
        SetAuraAttachmentFilter(crate::AuraAttachmentFilter),
        /// Abilities added as copiable exceptions, applied in layer 1 rather than ordinary grants.
        CopyOfWithAbilities {
            source: crate::target::ChooseSpec,
            preserve_source_abilities: bool,
            name_override: Option<String>,
            name_override_surface: Option<crate::target::SourceReferenceSurface>,
            add_supertypes: Vec<crate::types::Supertype>,
            copy_exception_surface: Option<String>,
            abilities: Vec<crate::ability::Ability>,
        },
    }
}

pub mod composition {
    pub type VoteOption = ironsmith_core::VoteOption<crate::effect::Effect>;
}

pub mod consult_helpers {
    pub use ironsmith_core::{LibraryBottomOrder, LibraryConsultMode};
}

pub mod mana {
    pub use ironsmith_core::{
        AddManaEqualToManaCostEffect, AddManaLostThisWayEffect, AddManaOfChosenColorEffect, AddManaOfColorsAmongEffect,
        AddManaOfImprintedColorsEffect,
        AddOneManaOfAnyColorAmongEffect, AddScaledManaEffect,
    };
}

pub use ironsmith_core::RegisterDamageMultiplierEffect;
pub use ironsmith_core::{RegisterDamageCounterReplacementEffect, RegisteredReplacementExpiry};
pub use ironsmith_core::RegisterDamageAdditionEffect;
pub use ironsmith_core::RegisterTokenCreationMultiplierEffect;

pub use ironsmith_core::DealDamageBySourcesEffect;

pub use ironsmith_core::DealDamageEachEffect;

pub type CastTaggedEffect = CoreCastTaggedEffect<crate::costs::Cost>;
pub type GrantPlayTaggedEffect = CoreGrantPlayTaggedEffect<crate::costs::Cost>;

pub use ironsmith_core::DealDamageToRecipientsEffect;

pub type MoveToZoneEffect = ironsmith_core::MoveToZoneEffect<crate::continuous::Modification>;

pub type NamedActionProgramEffect = ironsmith_core::NamedActionProgramEffect<Effect>;
