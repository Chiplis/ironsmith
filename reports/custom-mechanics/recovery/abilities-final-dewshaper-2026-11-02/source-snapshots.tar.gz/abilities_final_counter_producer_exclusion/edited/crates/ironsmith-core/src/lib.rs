//! Shared domain-model crate for the workspace refactor.
//!
//! Shared domain-model crate for the workspace refactor.
//!
//! Low-level card model and value types live here so runtime, compiler, and
//! registry layers can share them without introducing forbidden dependency
//! edges.

// The derive macros name this crate by its package name from inside it too.
extern crate self as ironsmith_core;

use crate::tag::TagKeyWalk;

pub mod ability_model;
pub mod alternative_cast_model;
pub mod anthem_model;
pub mod attachment_model;
pub mod card;
pub mod cardinal;
pub mod cause_model;
pub mod color;
pub mod continuous_model;
pub mod cost_model;
pub mod counter;
pub mod definition_model;
pub mod keyword_forms;
pub mod effect;
pub mod effect_model;
pub mod event_model;
pub mod filter_model;
pub mod functional_zones;
pub mod grant_model;
pub mod granted_spell_keyword_model;
pub use granted_spell_keyword_model::{
    GrantedSpellKeyword, GrantedSpellKeywordKind, GrantedSpellKeywordPrice,
};
pub mod ids;
pub mod interned;
pub mod mana;
pub mod library_movement;
pub mod ordinal;
pub mod resolution_model;
pub mod semantic_audit;
pub mod spell_cost_condition_model;
pub mod spell_timing_model;
pub mod static_ability_id;
pub mod static_ability_model;
pub mod replaced_event_model;
pub use replaced_event_model::ReplacedEventSpec;
pub mod amount_replacement_model;
pub use amount_replacement_model::{AmountEventSpec, AmountModifierSpec};
pub mod suspend;
pub use suspend::SuspendTime;
pub mod tag;
pub mod target_model;
pub mod text_change;
pub use text_change::{ChangeTextEffect, TextChange, TextChangeError, TextChangeSelection, TextWord};
pub mod token_text;
pub use token_text::{TokenNameTextRole, TokenTextRoles, TokenWordRole, subtype_derived_token_name};
pub mod trigger_model;
pub mod types;
pub mod custom_subtypes;
pub mod value_model;
pub mod zone;

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, TagKeyWalk)]
pub struct WorkspaceSplitMarker;

pub use ability_model::{
    Ability, AbilityKind, ActivatedAbility, ActivatedAbilityKeyword, ActivationGroupRule, ActivatedPresentationLabel, ActivationTiming,
    LevelAbility, ManaPaymentPredicate, ManaPaymentPurpose, ManaTurnFaceUpMethod, ManaSpendAbilityGrantDuration,
    ManaSpendBonusCondition, ManaSpendGrantedKeyword, ManaSpendPayload, ManaUsageRestriction,
    ManaUsageSubtypeRequirement, PresentationKeyword, PresentationLabel, ProtectionFrom,
    RestrictedManaUnit, TriggeredAbility,
};
pub use alternative_cast_model::{
    AlternativeCastRequirements, AlternativeCastingMethod, ZoneCastInstructions, ZoneChangeRedirectSpec, FREE_CAST_AS_THOUGH_FLASH_METHOD,
    TrapCondition,
};
pub use anthem_model::{AnthemCountExpression, AnthemValue, SourceCounterPronounSurface};
pub use attachment_model::AuraAttachmentFilter;
pub use card::{Card, CardBuilder, LinkedFaceLayout, PowerToughness, PtValue};
pub use cardinal::{cardinal_word, parse_cardinal_word, parse_cardinal_words};
pub use cause_model::{
    CauseAbilityKind, CauseAbilityKindFilter, CauseFilter, CauseType, CauseTypeFilter,
    ControllerFilter, EventCause,
};
pub use color::{Color, ColorSet};
pub use continuous_model::{
    CompiledContinuousEffectTarget, CompiledContinuousModification, CompiledPtSublayer,
};
pub use cost_model::{
    AlternativeCostReference, AlternativeCostReferenceSurface, CoreCostComponent, Cost,
    CostComponent, DynamicManaCost, DynamicManaDisplayHint, OptionalCost, OptionalCostKind,
    OptionalCostRef, OptionalCostsPaid, TotalCost, TotalCostKind,
};
pub use counter::CounterType;
pub use definition_model::CardDefinition;
pub use effect::{
    DELAYED_DURATION_PLAYER_TAG,
    AdaptEffect, AddManaEffect, AddManaEqualToManaCostEffect, AddManaLostThisWayEffect,
    AddManaFromCommanderColorIdentityEffect, AddManaOfAnyColorEffect,
    AddManaOfAnyOneColorEffect, AddManaOfChosenColorEffect, AddManaOfColorsAmongEffect,
    AddManaOfImprintedColorsEffect, AddManaOfLandProducedTypesEffect, AddManaOfNotedTypeEffect,
    AddOneManaOfAnyColorAmongEffect, AddScaledManaEffect, AdditionalLandPlaysEffect,
    AdditionalPhase, AdditionalPhasesEffect, AdditionalStepAnchor, AdditionalStepKind, AdditionalStepsEffect, AmassEffect, EmpowerJaceEffect, CollectEvidenceEffect, AmplifyEffect, AnimationDurationSurface,
    AnimationPtSurface, ApplyContinuousEffect, AscendEffect, DesignationHistoryRequirement, AssignNoCombatDamageEffect, TriggerAbilitiesByClassEffect,
    AttachObjectsEffect, AttachToEffect, AuraSwapEffect, BackupEffect, BattlefieldController,
    BattlefieldEntryCounterSpec, BattlefieldEntryCounterSurface, BecomeBasicLandTypeChoiceEffect,
    BecomeColorChoiceEffect, BecomeCreatureTypeChoiceEffect, BecomeForetoldWithCostEffect,
    BecomeMonarchEffect, BecomePlottedEffect, BecomeForetoldEffect, GrantLoyaltyActivationAllowanceEffect,
    GrantTapUncontrolledLandsForManaEffect, GrantPayLifeManaAbilityUntilEndOfTurnEffect, LoyaltyActivationAllowance, LoyaltyActivationScope, BecomeSaddledUntilEotEffect, BeholdEffect,
    BidLifeEffect, BolsterEffect, CantEffect, CastSourceEffect, CastTaggedAlternativePayment,
    CastTaggedEffect, ChoiceAggregateConstraint, ChoiceAggregateMetric, ChoiceCount,
    ChooseCardNameEffect, ChooseCardTypeEffect, ChooseColorEffect, ChooseCreatureTypeEffect,
    ChooseLandTypeEffect, ChooseModeEffect, ChooseNamedOptionEffect, ChooseNewTargetsEffect,
    RippleEffect, ChooseNumberAtRandomEffect, ChooseNumberEffect, ChooseObjectsEffect, ChoosePlayerEffect,
    ChooseSpellCastHistoryEffect, CipherEffect, ClashEffect, ClashOpponentMode, ClearGoadEffect,
    ClearSuspectedEffect, CoinFace, CoinFlipKind, CoinFlipOpponentTags, CoinFlipStopCondition, CoinFlipLossAction, CombatDamagePreventionTarget, ConditionalEffect,
    ConditionalModeRange, ConditionalSurface, ConniveEffect, ConspireCostEffect,
    ConsultTopOfLibraryEffect, ConsultTopOfLibraryStopRule, ContinuousDurationObject,
    ContinuousDurationPlayer, ContinuousDurationPredicate, ControlCombatChoicesThisTurnEffect,
    ControlPlayerEffect, ConvertEffect, CopyAttackTargetMode, CopyPtAdjustment, CopySpellEffect,
    CopySpellForEachTargetEffect, CounterEffect, CounterExileGate, CounterExilePermission, CreateEmblemEffect, CreateTokenCopyEffect,
    CreateTokenEffect, CrewCostEffect, SaddleCostEffect, CumulativeUpkeepEffect, DamageDistributionMode,
    DamageFilter, DealDamageEffect, DealDistributedDamageEffect, DelayedTriggerDuration,
    DelayedTriggerPrepayment, DelayedTriggerSpec, DestinationPlayerReferenceSurface, DestroyEffect,
    DestroyNoRegenerationEffect, DetainEffect, DevourEffect,
    DirectionalAdjacentPlayerControlEffect, SeatingDirection, DiscardEffect, DiscardHandEffect, DiscoverEffect,
    DoubleCountersEffect, DoubleManaPoolEffect, DrawCardsEffect, DrawForEachTaggedMatchingEffect,
    DrawTheGameEffect, EachPlayerScryEffect, EarthbendEffect, EffectId, EffectMode,
    EffectPredicate, EmitGiftGivenEffect, EmitKeywordActionEffect, PerformNamedActionEffect, EmitKeywordActionObjectTag,
    EmptyManaPoolEffect, ActivateManaAbilityOfEachLandEffect, ActivateAbilityWithoutCostsEffect, EndCombatPhaseEffect, DeclareBlockersByRandomPilesThisTurnEffect, EndTurnEffect,
    EnergyCountersEffect, EvolveEffect,
    ExcessDamageRedirect, ExchangeControlEffect, ExchangeLifeTotalsEffect, ExchangeTextBoxesEffect,
    ExchangeValueOperand, ExchangeValuesEffect, ExchangeZonesEffect, ExecuteWithSourceEffect,
    ExertCostEffect, ExileEffect, ExileInsteadOfGraveyardEffect, ExileTaggedWhenSourceLeavesEffect,
    ExileTopLibrarySurface, ExileTopOfLibraryEffect, ExileUntilDuration, ExileUntilEffect,
    ExiledWithSourceDestinationSurface, ExiledWithSourceMoveSurface,
    ExiledWithSourceMoveVerbSurface, ExiledWithSourceReferenceSurface,
    ExiledWithSourceSubjectSurface, ExperienceCountersEffect, ExploreEffect, GivePlayerCountersEffect,
    ExtraTurnAfterNextTurnEffect, ExtraTurnEffect, FatesealEffect, FightEffect, FlipCoinEffect,
    FlipEffect, ForEachControllerOfTaggedEffect, ForEachCounterKindPutOrRemoveEffect,
    ForEachObject, ForEachObjectCorrelatedResultEffect, ForEachAnnouncedTargetSlotEffect, ForEachTaggedEffect,
    ForEachTaggedPlayerEffect, ForPlayersEffect, CollectManaPaymentsEffect, GainLifeEffect, GoadEffect,
    BindXValueEffect,
    MustAttackPlayerThisTurnEffect,
    GrantAbilitiesTargetEffect, GrantBySpecEffect, GrantEffect, GrantNextSpellAbilityEffect,
    GrantNextSpellCostReductionEffect, NextSpellGrantMode, GrantPlayTaggedDuration, GrantPlayTaggedEffect,
    GrantPlayTaggedManaReferenceSurface, GrantPlayTaggedObjectSurface, GrantPlayTaggedSurface,
    GrantEndThisEffectPaymentEffect, GrantRepeatableManaPaymentActionUntilEndOfTurnEffect,
    GrantTaggedSpellFreeCastUntilEndOfTurnEffect, GrantTaggedSpellLifeCostByManaValueEffect,
    HauntExileEffect, HealDamageEffect, IfEffect, IncreaseSpeedEffect, IncubateEffect,
    InvestigateEffect, LearnEffect, LibraryBottomOrder, LibraryConsultMode, LibraryPlacementOrder,
    LibraryRemainderSurface, LifeBidStart, LinkedExileFollowUp, LocalRewriteEffect,
    LookAtHandEffect, LookAtObjectsEffect, LookAtTopCardsEffect, LoseLifeEffect, LoseTheGameEffect,
    ManaRestrictedEffect, ManaRetainedEffect, ManaRetentionDuration, ManaTypeSource,
    CustomStatusExpiryEvent, DescribedFaceDownCastPermission, ManifestCardFromHandEffect, ManifestDreadEffect, ManifestObjectsEffect,
    ManifestTopCardOfLibraryEffect, MayCastForMiracleCostEffect, MayCastMatchingSpellPayment,
    LinkExiledCardsEffect, CreateLinkedFaceTokenEffect, MayCastMatchingSpellWithoutPayingManaCostEffect, MayEffect, MayMoveToZoneEffect, MeldEffect, MergePermanentsEffect,
    GrantExileControllerInspectionEffect, SetPermanentDesignationEffect, PermanentDesignation, MillEffect, ModifyPowerToughnessEffect, ModifyPowerToughnessForEachEffect, MonstrosityEffect,
    MoveAllCountersEffect, MoveCountersEffect, MoveOneCounterEffect, MoveToLibraryNthFromTopEffect,
    MoveToLibraryTopOrBottomChoiceEffect, MoveToZoneAttackTargetMode, MoveToZoneEffect,
    MoveToZoneVerbSurface, NewTargetRestriction, NextAdaptIgnoresCountersEffect,
    NinjutsuCostEffect, NinjutsuEffect, CastFaceDownUsingActivationManaEffect, RegisterExtraDieReplacementEffect, NoteActivationManaTypeEffect, NoteActivationManaPaymentEffect, NoteTriggeringCreatureTypeEffect, NoteCountersEffect, NoteLifeTotalEffect, RedistributeLifeTotalsEffect, CoinFlipLifeStakesEffect, RedirectEnteringSourceEffect,
    OpenAttractionEffect, PayAnyEnergyEffect, PayAnyLifeEffect, PayEnergyEffect, PayLifeEffect,
    PayManaEffect, PhaseInEffect, PhaseOutDuration, PhaseOutEffect, PlaySubgameEffect,
    PlayerControlDuration, PlayerControlStart, PoisonCountersEffect, PopulateEffect, PrepareEffect,
    PreventAllCombatDamageEffect, PreventAllDamageEffect, PreventAllDamageToTargetEffect,
    PreventDamageEffect, PreventNextTimeDamageEffect, PreventNextTimeDamageSource,
    PreventNextTimeDamageTarget, NextTimeDamagePreventionPortion, PreventionTarget,
    PriorEffectResultActor,
    PriorEffectResultQuantifier, PriorEffectResultSurface, ProliferateEffect,
    PutCounterOfChosenKindEffect, PutCountersEffect, PutCounterBatchEffect, PutOntoBattlefieldEffect, PutStickerEffect,
    PutTaggedRemainderOnLibraryBottomEffect, RearrangeLookedCardsInLibraryEffect,
    ReconfigureEffect, ReselectAttackTargetEffect, ExchangeBlocksEffect, UnblockSoleBlockedAttackersEffect, BlockAttackerOfChoiceEffect, PlayWithHandRevealedEffect, RevealSourceInHandUntilOwnersNextTurnEffect, HandRevealDuration, TagPlayersEffect, KeepGreatestManaValuePlayersEffect, RollDieKeepHighestPlayersEffect, RetainSpellChoicesEffect, PutRetainedSpellCopyOntoStackEffect, ChooseFriendsOrFoesEffect, RedirectAllDamageThisTurnToTargetEffect, TimedDamageRedirectDestination, TimedDamageRedirectionScope, RedirectNextDamageDestination,
    RedirectNextDamageToTargetEffect, RedirectNextTimeDamageDestination,
    RedirectNextTimeDamageSource, RedirectNextTimeDamageToSourceEffect, ReduceSpeedEffect,
    ReflexiveTriggerEffect, RegenerateEffect, RegisterCounterPlacementReplacementEffect,
    RegisterDamagedBySourceZoneReplacementEffect,
    RegisterEventReplacementEffect, RegisterDrawReplacementEffect, RegisterEnterTappedReplacementEffect,
    RegisterEnterUnderControlReplacementEffect, RegisterEnterWithCountersReplacementEffect,
    RegisterFutureZoneReplacementEffect, RegisterManaReplacementEffect, RegisterManaRewriteEffect, RegisterManaSpendPermissionEffect,
    RegisterNextBatchEnterAsCopyEffect, RegisterNextBatchEnterWithCountersEffect,
    RegisterZoneReplacementEffect,
    RemoveAnyCountersAmongEffect, RemoveAnyCountersFromSourceEffect, RemoveCountersEffect,
    BecomeBlockedEffect, RemoveFromCombatEffect, RemoveUpToAnyCountersEffect, RemoveUpToCountersEffect, RenownEffect,
    ReorderGraveyardEffect, ReorderLibraryTopEffect, ReorderTopPlanarDeckEffect,
    RepeatEffectsEffect, RepeatProcessEffect, RepeatProcessPromptEffect, RepeatProcessPromptKind,
    RepeatProcessChoiceHistory, RollToVisitAttractionsEffect,
    ReplaceNextDamageToTargetEffect, ReplacementApplyMode, ResolvesDespiteIllegalTargetsEffect,
    RestartGameEffect, RestrictionDurationSurface, RestrictionStart,
    RetainManaUntilEndOfTurnEffect, RetargetMode, RetargetStackObjectEffect,
    ReturnAllToBattlefieldEffect, ReturnAsAuraOptions,
    ReturnFromGraveyardOrExileToBattlefieldEffect, ReturnFromGraveyardToBattlefieldEffect,
    ReturnFromGraveyardToHandEffect, ReturnToHandEffect, RevealChosenPlayerEffect,
    RevealChosenSubtypeEffect,
    RevealFromHandEffect, RevealSourceFromHandDuration, RevealSourceFromHandEffect,
    RevealTaggedEffect, RevealTopEffect, ReverseTurnOrderEffect, RingTemptsYouEffect,
    RollDiceChooseResultEffect, RollDieEffect, RollAndStoreDieResultsEffect, RerollStoredDieResultsEffect, RollPlanarDieEffect, SacrificeEffect,
    SacrificePlayerEffect,
    SacrificeTargetEffect, ScheduleDelayedTriggerEffect, ScheduleEffectsWhenTaggedLeavesEffect,
    ScryEffect, SearchLibraryEffect, SearchLibrarySlot, SearchLibrarySlotsEffect,
    SearchResultReferenceSurface, SearchSelectionMode, SecretChoiceEffect, SecretObjectChoice,
    SequenceEffect, SequenceSurface, SetBasePowerToughnessEffect, SetClassLevelEffect,
    DayNightDesignation, SetDayNightEffect,
    ChoosePlayerOptionEffect, PlayerOptionChooser, player_option_choice_tag,
    PlayerNumberChoice, player_guess_tag, player_number_extreme_tag, player_option_participants_tag,
    ControlVotesThisTurnEffect, PutCounterOfKindChosenFromEffect, PutCounterOfRandomKindEffect,
    SetLifeTotalEffect, SetQuantifierSurface, SharedTypeConstraint,
    ShuffleGraveyardIntoLibraryEffect, ShuffleHandAndGraveyardIntoLibraryEffect,
    ShuffleLibraryEffect, ShuffleObjectsIntoLibraryEffect, SkipCombatPhasesEffect,
    SkipCombatPhasesThisTurnEffect, SkipDrawStepEffect, SkipScheduledEffect, ScheduledSkipKind, SkipMainPhasesThisTurnEffect,
    SkipNextCombatPhaseThisTurnEffect, SkipTurnEffect, SneakCostEffect, SolveCaseEffect,
    RemoveOptionalTextFragmentEffect, LinkPermanentsEffect, SoulbondPairEffect, SupportEffect, SurveilEffect, SuspectEffect, TagAttachedToSourceEffect,
    TagMatchingObjectsEffect, TagOtherBlockParticipantEffect, TagTriggeringAttackerEffect,
    TagTriggeringBlockersEffect, TagTriggeringDamageTargetEffect, TagTriggeringObjectEffect,
    TagSplicedCardsEffect, TagLastDamageSourceEffect, LinkObjectsToGroupEffect, ObjectGroupAssignment,
    TagTriggeringSourceEffect, TaggedEffect, TaggedLeavesAbilitySource, TakeInitiativeEffect,
    TapEffect, TargetOnlyEffect, TicketCountersEffect, TokenAbilityPresentation,
    TokenCopyReferenceSurface, TransformEffect, TurnFaceDownEffect, TurnFaceUpEffect, TypeRetentionSurface,
    UnattachObjectsEffect, UnearthEffect, UnlessActionEffect, UnlessPaysEffect,
    UnlockRoomDoorEffect, UntapEffect, Until, VariableCasualtyPlaneswalkerCopyEffect,
    VentureIntoDungeonEffect, VillainousChoiceEffect, VoteChoice, VoteEffect, VoteOption, VotePayload,
    WinTheGameEffect, WithIdEffect, ZoneReplacementLibraryPlacement,
};
pub use effect_model::{CastEventQuantity, Comparison, EventValueSpec, ValueComparisonOperator};
pub use event_model::KeywordActionKind;
pub use filter_model::{
    AdditionalCostObjectAction, AdditionalCostObjectSurface, AlternativeCastKind,
    ChosenNameSourceSurface, Comparison as FilterComparison, CounterConstraint,
    CounterSourceHistoryConstraint, CountersPutOnThisTurnConstraint,
    DemonstrativeAntecedentSurface, ExcludedNameSurface,
    GlobalCharacteristicDomainSurface, GraveyardEntryHistorySurface, LiteralNameSurface,
    ObjectCharacteristic, ObjectCharacteristicRelation, ObjectCharacteristicRelationKind,
    ObjectFilter, ObjectFilterUnionConnective, ObjectFilterUnionSurface, ObjectRef,
    ParityRequirement, PlayedByOpponentSurface, PlayerFilter, PlayerQuantity, PlayerTurnHistoryFilter, TargetObjectPlayerRelation,
    PowerToughnessRelation, PtReference,
    SameNameAntecedentSurface, SourcePowerRelation, StackObjectKind, TaggedObjectConstraint,
    TaggedOpbjectRelation, TargetabilityConstraint,
};
pub use grant_model::{
    DerivedAlternativeCast, GrantDuration, GrantSpec, GrantStaticAbility, GrantUsageLimit,
    Grantable, SourceExiledGrantSurface, SourceExiledManaRiderSurface,
};
pub use ids::{
    CardId, IdCountersSnapshot, ObjectId, PlayerId, StableId, reset_runtime_id_counters,
    restore_id_counters, snapshot_id_counters,
};
pub use interned::{InternedI32Slice, InternedStr};
pub use mana::{ManaCost, ManaSymbol, ManaOutputRewrite, ManaRewriteInput, ManaRewriteOutput, ManaRewriteQuantity};
pub use ordinal::{ordinal_word, parse_ordinal_word, parse_ordinal_words};
pub use resolution_model::{LinkedExileDefinition, LinkedExilePair, ResolutionProgram, ResolutionSegment, SelfReplacementBranch};
pub use spell_cost_condition_model::ThisSpellCostCondition;
pub use spell_timing_model::ThisSpellCastTiming;
pub use static_ability_id::StaticAbilityId;
pub use static_ability_model::{
    TokenCreationTemplateMode,
    DraftRule, KeywordMarkerMechanic, deck_construction_color_choice_count, draft_rule,
    keyword_marker_mechanic,
    AbilityLossMode, ActivatedAbilityCostCondition, AdditionalTokenKind, Anthem,
    AnthemReplacementSurface, AttachedAbilityGrant, AttachedChosenLandwalkGrant,
    AttackCostCondition, AttackingGroupAttackCondition, CantAttackUnlessConditionSpec,
    CompanionDeckCardFacts, CompanionDeckCondition, ConditionalAdditionalCounters,
    ConditionalSpellKeywordKind, ConditionalSpellKeywordSpec, CopyActivatedAbilities, FlashCastChoice,
    CopyStaticAbilityVariants, CopyTriggeredAbilities, CostIncrease, CostIncreaseManaCost,
    CostReduction, CostReductionCharacteristicIntersection, CostReductionManaCost,
    CounterRemovalFollowUp, CounterRemovalPreventionSurface, DefendingPlayerAttackCondition,
    EnterAsCopyAsEntersSpec, EnterAsCopyFollowup, EnterAsCopyLinkedExilePairSpec, EscalateSpec,
    GrantObjectAbilityForFilter, GraveyardCountMetric, IntrinsicStartingCounter, LandwalkKind, OptionalLifeAdditionalCost,
    OptionalTextFragmentVariant, OptionalTextFragmentsSpec,
    PowerToughnessChoiceOption, PregameChosenCardSpec, PregameChosenCardAction, PregameDeckCondition, PregameActionKind, PregameBeginOnBattlefieldSpec,
    PregameExileDraftedCardsSpec, PregameRevealFromOpeningHandSpec,
    PreventAllDamageToSelfFromSourcesMatchingSpec,
    StaticDamageRedirectDestination, StaticDamageRedirectionSpec,
    PreventMatchingDamageSpec, StaticDamagePreventionAmount, StaticDamagePreventionFollowUp, PreventionFollowUpAmount,
    RemoveCardTypesForFilter, SetColorsForFilter, SpliceQuality, SpliceSpec, StaticAbility,
    StaticAbilityPayload, StaticAbilityVariantSelector, StaticDamageSourceRelation,
    ThisSpellCastRestrictionKind, ThisSpellCostReduction, ThisSpellCostReductionManaCost,
};
pub use tag::{
    ATTACKING_GROUP_TAG, CAST_CONTROLLED_OBJECTS_TAG, CLASH_OPPONENT_TAG, CAST_MODIFIED_CREATURES_TAG,
    CHOSEN_OBJECTS_TAG, COMBAT_DAMAGE_GROUP_TAG, EXPLOITED_TAG, EXPLOITER_TAG,
    INITIATIVE_HOLDER_TAG, LINKED_TRIGGER_PLAYER_TAG, TRIGGERING_EVENT_CONTROLLER_TAG, TRIGGERING_EVENT_CAUSE_CONTROLLER_TAG, MANA_PAID_OBJECT_TAG, MANA_SOURCES_SPENT_TO_CAST_TAG, TAXED_ATTACKER_TAG, BLOCK_PAIR_SUBJECT_TAG,
    MANIFEST_DREAD_GRAVEYARD_TAG, PREVIOUS_ITERATED_OBJECTS_TAG, PRIOR_EXILED_CARD_TAG,
    REVEALED_THIS_WAY_TAG, SOURCE_EXILED_TAG, SOURCE_EXILED_THIS_RESOLUTION_TAG, SOURCE_OBJECT_TAG, GRANTING_SOURCE_TAG, SPELLS_CAST_THIS_TURN_TAG, TagKey, ZONE_CHANGE_GROUP_TAG, TAP_STATE_GROUP_TAG,
};
pub use target_model::{
    ChooseSpec, ChooseSpecSurfaceHint, SacrificedObjectKind, SourceReferenceSurface,
};
pub use trigger_model::{
    AttackTargetRestriction, ClashWinTriggerSurface, CountMode as CompilerTriggerCountMode,
    CounterPutOnTrigger as CompilerCounterPutOnTrigger, DamagedBySource, GraveyardTriggerSurface,
    Trigger as CompilerTrigger, TriggerIntroSurface as CompilerTriggerIntroSurface, TriggerKind,
    TriggerTimingRestriction, ZoneChangeTrigger as CompilerZoneChangeTrigger,
};
pub use types::{CardType, Subtype, SubtypeFamily, Supertype};
pub use value_model::{
    CreationNumericProperty, FrozenNumericParameter, AttachmentConditionHost, Condition, CombatParticipantCondition, ConditionConjunction, DeathHistoryControllerSurface,
    DistinctCharacteristic,
    ActivatedAbilityKindSelector, EffectMetric, EffectMetricSource, ManaSpendPermission, ManaSpendScope,
    ManaSpentCastReferenceSurface, PermanentLeftBattlefieldControlSurface, PriorEffectAction,
    PriorEffectMetricQuery, ColorChoiceReference, ObjectRule, Restriction, SourceCounterThresholdSurface, TaggedObjectMatchMode,
    TurnHistoryCondition, TurnHistoryCount, Value, ValueSurfaceHint,
};
pub use zone::Zone;

pub use filter_model::describe_filter_static_ability;

pub use effect::RegisterDamageMultiplierEffect;
pub use effect::{RegisterDamageCounterReplacementEffect, RegisteredReplacementExpiry};
pub use effect::RegisterDamageAdditionEffect;
pub use effect::RegisterTokenCreationMultiplierEffect;
pub use effect::DealDamageToRecipientsEffect;

mod damage_history_model;
pub use damage_history_model::{
    DamageHistoryQuery, DamageHistoryRecipients, DamageHistoryReduction, DamageHistorySources,
};

pub use effect::DealDamageBySourcesEffect;

pub use effect::DealDamageEachEffect;

pub use effect::{DamageRecipientSetBinding, DamageSourceSetBinding};

pub mod effect_capabilities;

pub use effect::{NamedActionProgramEffect, FirstResolutionEachTurnEffect};
pub use effect::GrantActivationCostAlternativeEffect;

pub use effect::RecordSourceCollectionEffect;
