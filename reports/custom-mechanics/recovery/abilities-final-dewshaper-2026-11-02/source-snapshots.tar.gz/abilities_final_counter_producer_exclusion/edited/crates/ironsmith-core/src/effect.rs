//! Shared effect-domain metadata.
//!
//! These types describe effect identity and selection cardinality without
//! pulling in the runtime execution engine.

use crate::tag::TagKeyWalk;

use crate::filter_model::{
    AlternativeCastKind, ObjectFilter, ObjectRef, PlayerFilter, StackObjectKind,
};
use crate::mana::{ManaCost, ManaSymbol};
use crate::tag::TagKey;
use crate::target_model::ChooseSpec;
use crate::types::{CardType, Subtype, Supertype};
use crate::value_model::{PriorEffectAction, Restriction, Value};
use crate::zone::Zone;
use crate::{Color, ColorSet, CounterType, SourceReferenceSurface};

mod ascend;
mod first_resolution;
pub use first_resolution::*;
mod trigger_class_choice;
pub use trigger_class_choice::*;
mod chosen_counter_kind;
mod mana_damage_and_control;
mod player_option_choice;
mod reselect_attack;
mod hand_reveal;
mod friend_or_foe;
mod tie_break;
mod retained_spell;
mod attraction_visits;
pub use attraction_visits::*;
pub use ascend::*;
pub use friend_or_foe::*;
pub use chosen_counter_kind::*;
pub use mana_damage_and_control::*;
pub use player_option_choice::*;
pub use reselect_attack::*;
pub use hand_reveal::*;
pub use tie_break::*;
pub use retained_spell::*;

/// Identifier for an effect within an effect sequence.
///
/// Used to reference effects for conditional logic ("if you do" patterns).
/// Effects are labeled with `Effect::WithId` and referenced by `Effect::If`.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, TagKeyWalk)]
pub struct EffectId(pub u32);

impl EffectId {
    /// Special ID used by ForEachControllerOfTaggedEffect to store the count
    /// of tagged objects for the current controller during iteration.
    pub const TAGGED_COUNT: Self = Self(u32::MAX);

    /// The zone change performed by a replacement, for reflexive follow-ups.
    pub const REPLACED_EVENT: Self = Self(u32::MAX - 1);

    /// The unique retained counter-removal producer of one activation.
    pub const ACTIVATION_COUNTER_COST: Self = Self(u32::MAX - 2);

    /// Spell copies a copy-count replacement added beyond the instruction's
    /// own number ("plus an additional time"), for their new-target choice.
    pub const ADDITIONAL_COPIES: Self = Self(u32::MAX - 3);

    /// The unique retained random-result producer of one activation's cost
    /// ("{6}, Roll a d8: Monstrosity X, where X is the result").
    pub const ACTIVATION_RESULT_COST: Self = Self(u32::MAX - 4);

    /// Compiler-only placeholder for a labelled operation's prior action
    /// receipt. Reference resolution must replace it before materialization.
    pub const PENDING_PRIOR_ACTION: Self = Self(u32::MAX - 5);
}

impl From<u32> for EffectId {
    fn from(value: u32) -> Self {
        Self(value)
    }
}

/// Specifies how many objects/players to choose.
///
/// Used for effects like "Exile any number of target spells" (Mindbreak Trap)
/// or "Choose up to two target creatures".
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, Copy, PartialEq, Eq, TagKeyWalk)]
pub struct ChoiceCount {
    /// Minimum number to choose (0 for "any number" or "up to").
    pub min: usize,
    /// Maximum number to choose. None means unlimited ("any number").
    pub max: Option<usize>,
    /// Whether this count came from a dynamic `X target ...` clause.
    pub dynamic_x: bool,
    /// Whether a dynamic X count is optional ("up to X") instead of exact.
    pub up_to_x: bool,
    /// Whether the chosen object(s) should be selected at random.
    pub random: bool,
    /// Whether the source explicitly authored the otherwise semantic-neutral
    /// word "exactly" before a fixed or dynamic count.
    pub explicit_exactly: bool,
}

/// Distinguishes exact, optional, and "all matching" search instructions.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, Copy, PartialEq, Eq, TagKeyWalk)]
pub enum SearchSelectionMode {
    /// "a card", "three cards", or other exact-count search phrasing.
    Exact,
    /// "up to N", "any number", or otherwise optional search phrasing.
    Optional,
    /// "all cards ..." search phrasing.
    AllMatching,
}

/// Aggregate value used to constrain a group of chosen objects.
///
/// Unlike an [`ObjectFilter`], this applies to the selection as a whole. For
/// example, "choose any number of creatures with total power 4 or less" uses
/// `Power` with a maximum of 4.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, Copy, PartialEq, Eq, TagKeyWalk)]
pub enum ChoiceAggregateMetric {
    Power,
    Toughness,
    ManaValue,
    /// Number of distinct card types represented by the entire selection.
    DistinctCardTypes,
    /// Maximum matching assigning one different color to each selected object.
    DistinctColorRepresentatives,
    /// Total number of mana symbols of one color among the chosen objects'
    /// mana costs ("with fifteen or more black mana symbols among their mana
    /// costs", Baron Helmut Zemo). A hybrid or Phyrexian symbol of that color
    /// counts once. Appended; additive like the stat totals.
    ManaSymbolsOfColor(crate::color::Color),
}

/// Upper bound on an aggregate characteristic of a group of chosen objects.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct ChoiceAggregateConstraint {
    pub metric: ChoiceAggregateMetric,
    /// Optional lower bound on the aggregate selection. This is used by
    /// costs such as "collect evidence N", where any number of cards may be
    /// selected but their total mana value must reach a threshold.
    pub minimum: Option<Value>,
    pub maximum: Value,
}

impl ChoiceAggregateConstraint {
    pub fn at_most(metric: ChoiceAggregateMetric, maximum: impl Into<Value>) -> Self {
        Self {
            metric,
            minimum: None,
            maximum: maximum.into(),
        }
    }

    pub fn at_least(metric: ChoiceAggregateMetric, minimum: impl Into<Value>) -> Self {
        Self {
            metric,
            minimum: Some(minimum.into()),
            maximum: Value::Fixed(i32::MAX),
        }
    }

    pub fn total_power_at_most(maximum: impl Into<Value>) -> Self {
        Self::at_most(ChoiceAggregateMetric::Power, maximum)
    }

    pub fn total_mana_value_at_most(maximum: impl Into<Value>) -> Self {
        Self::at_most(ChoiceAggregateMetric::ManaValue, maximum)
    }

    pub fn total_mana_value_at_least(minimum: impl Into<Value>) -> Self {
        Self::at_least(ChoiceAggregateMetric::ManaValue, minimum)
    }
}

/// Object identity used by a predicate-bearing resolution duration.
///
/// Semantic references are materialized to `Specific` when the resolving
/// spell or ability creates its continuous effect. This keeps the duration's
/// operands distinct from both the effect source and the fixed affected set.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, Eq, Hash, TagKeyWalk)]
pub enum ContinuousDurationObject {
    Source,
    AffectedObject,
    Tagged(TagKey),
    Specific(crate::ObjectId),
    /// Exact current source in this zone, or its explicitly recorded own
    /// exile arrival from this resolution. Materialized once to Specific;
    /// never follows a later unrelated incarnation or searches by stable ID.
    SourceInZone(crate::Zone),
}

/// Player identity used by a predicate-bearing resolution duration.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, Eq, Hash, TagKeyWalk)]
pub enum ContinuousDurationPlayer {
    EffectController,
    ControllerOf(ContinuousDurationObject),
    Tagged(TagKey),
    Specific(crate::PlayerId),
}

/// A reusable current-state predicate for CR 611.2b durations.
///
/// These predicates are evaluated against current game state, but their
/// duration is latched: a false initial value starts no effect, and a false
/// value after the effect starts expires it permanently.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub enum ContinuousDurationPredicate {
    All(Vec<ContinuousDurationPredicate>),
    ObjectOnBattlefield(ContinuousDurationObject),
    /// Exact object identity remaining in a specified zone. Unlike a
    /// battlefield-presence predicate, phasing does not end this relation.
    ObjectInZone {
        object: ContinuousDurationObject,
        zone: crate::zone::Zone,
    },
    ObjectTapped(ContinuousDurationObject),
    ObjectControlledBy {
        object: ContinuousDurationObject,
        player: ContinuousDurationPlayer,
    },
    ObjectHasCounter {
        object: ContinuousDurationObject,
        counter_type: CounterType,
        minimum: u32,
    },
    ObjectAttachedTo {
        attachment: ContinuousDurationObject,
        attached_to: ContinuousDurationObject,
    },
    ObjectIsEnchanted(ContinuousDurationObject),
    /// The exact object remains a face-up permanent. Its first transition to
    /// face down ends the duration ("until this creature is turned face
    /// down", Vesuvan Shapeshifter).
    ObjectFaceUp(ContinuousDurationObject),
    PlayerIsMonarch(ContinuousDurationPlayer),
    ObjectPowerAtMostObject {
        lesser: ContinuousDurationObject,
        greater: ContinuousDurationObject,
    },
}

impl ContinuousDurationPredicate {
    pub fn all(predicates: impl IntoIterator<Item = Self>) -> Self {
        Self::All(predicates.into_iter().collect())
    }

    pub fn affected_object_has_counter(counter_type: CounterType) -> Self {
        Self::ObjectHasCounter {
            object: ContinuousDurationObject::AffectedObject,
            counter_type,
            minimum: 1,
        }
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, Default)]
#[expect(
    clippy::large_enum_variant,
    reason = "continuous durations preserve typed predicates inline"
)]
#[derive(TagKeyWalk)]
pub enum Until {
    #[default]
    Forever,
    EndOfTurn,
    /// The earlier of the current turn ending or any player rolling the
    /// specified result. `matching_rolls_observed` is materialized when the
    /// continuous effect resolves so rolls that happened earlier in the turn
    /// do not immediately expire it.
    EndOfTurnOrAnyPlayerRolls {
        result: u32,
        matching_rolls_observed: u32,
    },
    YourNextTurn,
    YourNextTurnEnd,
    YourNextUpkeep,
    ControllersNextUntapStep,
    /// "until the next end step": ends as the first end step to begin after
    /// the effect was created begins (this turn's, unless it already began).
    NextEndStep,
    EndOfCombat,
    ThisLeavesTheBattlefield,
    SourceUntaps,
    YouStopControllingThis,
    /// A CR 611.2b duration whose predicate is materialized at resolution and
    /// whose first transition to false is permanent.
    ForAsLongAs(ContinuousDurationPredicate),
    TurnsPass(crate::value_model::Value),
    /// Ends when this exact incarnation completes casting from the named zone.
    /// Merely leaving that zone (including proposal before payment) is not enough.
    ObjectIsCast {
        object: ContinuousDurationObject,
        from_zone: crate::zone::Zone,
    },
    /// A fixed resolving controller's next untap step, distinct from the
    /// affected permanent's current controller after a control change.
    YourNextUntapStep,
    /// Ends as the exact affected object's current controller's next actual
    /// untap step begins, before phasing. Skipped steps do not begin.
    UntilControllersNextUntapStep {
        object: ContinuousDurationObject,
    },
    /// A rule applying during a named player's next actual untap step.
    /// Resolution freezes the player to Specific; the affected set stays live.
    PlayersNextUntapStep {
        player: PlayerFilter,
    },
    /// Ends with the controller's next actual upkeep, including an additional
    /// upkeep. An upkeep already underway when this starts is not the next one.
    YourNextUpkeepEnd,
    /// "until that player's next turn" (Teferi's Reproach): `YourNextTurn`
    /// keyed to a named player instead of the effect controller. Resolution
    /// freezes the player to `Specific`.
    PlayersNextTurn {
        player: PlayerFilter,
    },
    /// "until the end of defending player's next turn" (Nuka-Nuke
    /// Launcher): `YourNextTurnEnd` keyed to a named player. Only delayed
    /// trigger registrations own it (`ScheduleDelayedTriggerEffect::
    /// duration_player`).
    PlayersNextTurnEnd {
        player: PlayerFilter,
    },
    /// "until a player casts a creature spell" (Soul Sculptor): ends as soon
    /// as any player completes casting a creature spell after the effect was
    /// created. `creature_spells_observed` is the game-wide count materialized
    /// when the effect resolves. Appended.
    AnyPlayerCastsCreatureSpell {
        creature_spells_observed: u32,
    },
    /// Ends as the first future turn with any opponent of the effect controller
    /// as an active player begins. Extra turns and shared team turns are actual
    /// turn boundaries, not a predicted turn-order position. Appended.
    OpponentsNextTurn,
}

impl Until {
    /// Whether this duration ends as a player's next turn begins
    /// ("until your next turn" / "until that player's next turn").
    pub fn ends_at_next_turn_start(&self) -> bool {
        matches!(self, Self::YourNextTurn | Self::PlayersNextTurn { .. })
    }

    /// The player whose next turn ends a next-turn duration: the frozen named
    /// player of `PlayersNextTurn`, otherwise the effect `controller`.
    pub fn next_turn_owner(&self, controller: crate::PlayerId) -> crate::PlayerId {
        match self {
            Self::PlayersNextTurn {
                player: PlayerFilter::Specific(player),
            } => *player,
            _ => controller,
        }
    }

    /// CR 611.2b / 702.26f: a for-as-long-as duration tracks the exact visible
    /// source and ends permanently on departure or phasing. This is deliberately
    /// different from the literal "until this leaves" event duration.
    pub fn while_source_remains_on_battlefield() -> Self {
        Self::ForAsLongAs(ContinuousDurationPredicate::ObjectOnBattlefield(
            ContinuousDurationObject::Source,
        ))
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq)]
#[expect(
    clippy::large_enum_variant,
    reason = "effect predicates preserve typed object filters inline"
)]
#[derive(TagKeyWalk)]
pub enum EffectPredicate {
    Succeeded,
    Failed,
    Happened,
    DidNotHappen,
    SearchedLibrary,
    HappenedNotReplaced,
    ExcessDamageDealt,
    /// "If excess damage was dealt to a creature this way" (Vikya,
    /// Scorching Stalwart): excess damage dealt to a recipient that was a
    /// creature, not to a planeswalker or battle (CR 120.4a). Appended.
    ExcessDamageDealtToCreature,
    DealtDamageToPlayer,
    /// The antecedent damage instruction's CR 120.4a excess-to-controller
    /// replacement applied ("If excess damage would be dealt ..., instead
    /// ... and you convert Megatron"): it assigned damage to a player,
    /// whether or not that damage was then prevented.
    ExcessDamageRedirected,
    AffectedObjectMatchesCardType {
        card_type: CardType,
        negated: bool,
    },
    /// At least one object affected for a matching player has the greatest
    /// mana value among every object affected by the producer. Equal maxima
    /// intentionally satisfy the predicate.
    ///
    /// The producer must retain per-player affected-object partitions. This
    /// is the generic result shape used by simultaneous participant actions
    /// such as comparing what each player discarded.
    PlayerAffectedObjectHasGreatestManaValue {
        player: PlayerFilter,
    },
    /// A result predicate over the captured objects produced by one prior
    /// action, preserving the authored `... this way` relationship.
    ///
    /// Unlike the legacy card-type-only predicate, this retains the complete
    /// object filter plus voice and quantifier presentation. Runtime matching
    /// is still performed against the antecedent's last-known-information
    /// memory rather than live objects.
    PriorEffectResult(PriorEffectResultSurface),
    Value(crate::effect_model::Comparison),
    Chosen,
    WasDeclined,
    /// A qualifying subset of one exact producer's affected objects shares
    /// the characteristic. Empty/short collections cannot satisfy the gate.
    AffectedObjectsShare {
        required_count: u32,
        characteristic: crate::ObjectCharacteristic,
    },
    /// Compare only the objects of the named action, excluding other actions
    /// in the same compound producer (such as draws preceding discards).
    PlayerActionObjectHasGreatestManaValue {
        player: PlayerFilter,
        action: PriorEffectAction,
    },
    /// Match only the explicit original instruction's produced-object packet.
    /// Missing evidence is unknown, including for the negative form. Appended.
    ResultObjectsMatch { filter: ObjectFilter, negated: bool },
}

/// Authored grammatical subject for a prior-result predicate.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, Copy, PartialEq, Eq, TagKeyWalk)]
pub enum PriorEffectResultActor {
    /// Passive surface such as "a creature card is exiled this way."
    Passive,
    /// Active controller surface such as "you discard a card this way."
    You,
    /// Active iterated-player surface such as "that player discards a card this way."
    ThatPlayer,
    /// Reflexive source surface such as "it connives this way."
    It,
}

/// Authored cardinality for a prior-result predicate.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, Copy, PartialEq, Eq, TagKeyWalk)]
pub enum PriorEffectResultQuantifier {
    /// An ordinary singular result ("a creature card").
    One,
    /// An explicit nonzero plural result ("one or more nonland cards").
    OneOrMore,
    /// The action itself is the predicate and has no object noun surface.
    ActionOnly,
}

/// Typed presentation and filtering data for a `... this way` result gate.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct PriorEffectResultSurface {
    /// Invert the complete filtered result predicate (for example, no matching
    /// cards were revealed), rather than matching individual nonmatching cards.
    #[cfg_attr(feature = "serde", serde(default))]
    pub negated: bool,
    pub action: PriorEffectAction,
    /// Authored present-tense zone-change wording for an exile result gate.
    #[cfg_attr(feature = "serde", serde(default))]
    pub put_into_exile_surface: bool,
    pub filter: ObjectFilter,
    pub actor: PriorEffectResultActor,
    pub quantifier: PriorEffectResultQuantifier,
    /// Explicit number of matching result objects required by the predicate.
    ///
    /// This is distinct from `quantifier`: it retains counted surfaces such
    /// as "two nonland cards were milled this way" and is evaluated against
    /// the prior effect's affected-object memory.
    pub required_count: Option<u32>,
    /// Characteristic that at least one pair among the matching result objects
    /// must share, for predicates such as "two cards that share a color".
    pub shared_characteristic: Option<crate::ObjectCharacteristic>,
}

impl PriorEffectResultSurface {
    pub fn new(
        action: PriorEffectAction,
        filter: ObjectFilter,
        actor: PriorEffectResultActor,
        quantifier: PriorEffectResultQuantifier,
    ) -> Self {
        Self {
            negated: false,
            action,
            put_into_exile_surface: false,
            filter,
            actor,
            quantifier,
            required_count: None,
            shared_characteristic: None,
        }
    }

    pub fn with_count_sharing(
        mut self,
        required_count: u32,
        characteristic: crate::ObjectCharacteristic,
    ) -> Self {
        self.required_count = Some(required_count);
        self.shared_characteristic = Some(characteristic);
        self
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, Copy, PartialEq, Eq, TagKeyWalk)]
pub enum GrantPlayTaggedDuration {
    UntilEndOfTurn,
    UntilYourNextTurnStart,
    UntilYourNextTurnEnd,
    UntilYourNextEndStep,
    /// The permission remains active until the same source object next exiles
    /// another card.
    UntilSourceExilesAnother,
    ForAsLongAsExiled,
    ForAsLongAsYouControlSource,
    /// Appended; ends permanently when the exact source leaves or phases out.
    ForAsLongAsSourceOnBattlefield,
    /// Appended: "During your next turn, you may play that card." The
    /// permission is active only during the effect controller's next turn — not for the
    /// rest of the current turn (Galvanic Relay).
    DuringYourNextTurn,
    /// Appended: "Until that player's next end step, they may play that
    /// card" (Casey & Raph): the permission holder's own next end step,
    /// rather than the effect controller's (`UntilYourNextEndStep`).
    UntilPlayerNextEndStep,
    /// Appended: "Until end of combat on your next turn, you may play that
    /// card" (Brazen Cannonade): through the combat phase of the effect controller's
    /// next turn.
    UntilEndOfCombatOnYourNextTurn,
    /// The permission holder's next turn, independently of the effect controller.
    /// `UntilYourNextTurnEnd` instead refers to the effect controller's next turn.
    UntilPlayerNextTurnEnd,
    /// Holder-relative counterparts to the controller-relative next-turn boundaries.
    UntilPlayerNextTurnStart,
    DuringPlayerNextTurn,
    UntilEndOfCombatOnPlayerNextTurn,
    /// Persistent exact-exile permission, usable after the current turn ends.
    AfterCurrentTurnForAsLongAsExiled,
}

/// Oracle-facing noun phrase for a temporary permission over a tagged card
/// collection. Runtime identity remains carried by the grant's `tag`; this
/// only preserves distinctions that cannot be recovered from that tag.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, Eq, TagKeyWalk)]
pub enum GrantPlayTaggedObjectSurface {
    It,
    ThatCard,
    /// Authored definite reference that repeats the card's current zone.
    ThatCardFromExile,
    ThatSpell,
    Them,
    ThoseCards,
    SpellsFromAmongThoseCards,
    SpellsFromAmongThoseExiledCards,
    CardsExiledWithSource {
        source: SourceReferenceSurface,
    },
    SpellFromAmongCardsExiledWithSource {
        creature_spell: bool,
        source: SourceReferenceSurface,
    },
    ThisCard,
    /// "cards exiled this way" / "lands and cast spells from among cards
    /// exiled this way": the same exiled set as `ThoseCards`, authored as
    /// the explicit result reference. Appended.
    CardsExiledThisWay {
        lands_and_spells: bool,
    },
    /// "lands and cast spells from among the exiled cards" (Elder Brain): the
    /// instruction's exiled set, authored as a definite description. Appended.
    LandsAndSpellsFromAmongTheExiledCards,
}

/// Oracle-facing reference used by a flexible-mana suffix on a temporary
/// tagged-card permission.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, Copy, PartialEq, Eq, TagKeyWalk)]
pub enum GrantPlayTaggedManaReferenceSurface {
    It,
    ThatSpell,
    Them,
    ThoseSpells,
}

/// Presentation provenance for a temporary tagged-card permission.
///
/// The duration and playable set remain typed by `GrantPlayTaggedEffect`.
/// These fields preserve only authored placement and reference wording.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, Eq, Default, TagKeyWalk)]
pub struct GrantPlayTaggedSurface {
    pub leading_duration: bool,
    pub object: Option<GrantPlayTaggedObjectSurface>,
    pub mana_reference: Option<GrantPlayTaggedManaReferenceSurface>,
    /// Authored source noun in "for as long as you control this ...".
    /// Runtime duration semantics remain carried by
    /// `GrantPlayTaggedDuration::ForAsLongAsYouControlSource`.
    pub control_source: Option<SourceReferenceSurface>,
    /// Authored source noun; the corresponding duration carries the semantics.
    #[cfg_attr(
        feature = "serde",
        serde(default, skip_serializing_if = "Option::is_none")
    )]
    pub battlefield_source: Option<SourceReferenceSurface>,
    /// Authored source noun in "until you exile another card with this ...".
    /// The event-bounded lifetime itself is carried by
    /// `GrantPlayTaggedDuration::UntilSourceExilesAnother`.
    pub until_source_exiles_another: Option<SourceReferenceSurface>,
    /// The flexible-mana rider was authored as its own sentence: "If you
    /// cast a spell this way, you may spend mana as though it were mana of
    /// any type to cast it." Runtime semantics stay on the mana spend mode.
    #[cfg_attr(feature = "serde", serde(default))]
    pub mana_spend_followup: bool,
}

impl GrantPlayTaggedSurface {
    pub fn with_leading_duration(mut self, leading: bool) -> Self {
        self.leading_duration = leading;
        self
    }

    pub fn with_object(mut self, object: GrantPlayTaggedObjectSurface) -> Self {
        self.object = Some(object);
        self
    }

    pub fn with_mana_reference(mut self, reference: GrantPlayTaggedManaReferenceSurface) -> Self {
        self.mana_reference = Some(reference);
        self
    }

    pub fn with_control_source(mut self, source: SourceReferenceSurface) -> Self {
        self.control_source = Some(source);
        self
    }

    pub fn with_until_source_exiles_another(mut self, source: SourceReferenceSurface) -> Self {
        self.until_source_exiles_another = Some(source);
        self
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, Copy, PartialEq, Eq, TagKeyWalk)]
pub enum ReplacementApplyMode {
    OneShot,
    UntilEndOfTurn,
    UntilYourNextTurn,
    Resolution,
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub enum PreventNextTimeDamageSource {
    Choice,
    ChoiceMatching(crate::filter_model::ObjectFilter),
    Target(ChooseSpec),
    Filter(crate::filter_model::ObjectFilter),
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq)]
#[expect(
    clippy::large_enum_variant,
    reason = "damage-target constraints preserve typed choices inline"
)]
#[derive(TagKeyWalk)]
pub enum PreventNextTimeDamageTarget {
    AnyTarget,
    Omitted,
    You,
    /// Damage dealt to you and/or permanents matching the filter
    /// ("you and/or creatures you control").
    YouAndPermanents(crate::filter_model::ObjectFilter),
    /// Damage dealt to any player ("to one or more players").
    AnyPlayer,
    Target(ChooseSpec),
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub enum RedirectNextTimeDamageSource {
    Choice,
    Filter(crate::filter_model::ObjectFilter),
    Target(crate::target_model::ChooseSpec),
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, Copy, PartialEq, Eq, TagKeyWalk)]
pub enum RedirectNextTimeDamageDestination {
    SourceObject,
    Controller,
    SourceController,
    TargetObject,
    /// The source of the damage being replaced, not the ability source.
    DamageSource,
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq)]
#[expect(
    clippy::large_enum_variant,
    reason = "retarget modes preserve typed choice specifications inline"
)]
#[derive(TagKeyWalk)]
pub enum RetargetMode {
    All,
    OneToFixed(crate::target_model::ChooseSpec),
    /// "The copy targets that creature" (Feather, Radiant Arbiter): every
    /// target instance that can legally become the fixed object changes to
    /// it. Appended to preserve serialized ordinals.
    AllToFixed(crate::target_model::ChooseSpec),
    /// Change exactly one target occurrence to a newly chosen legal target.
    /// Appended to preserve existing serialized ordinals.
    One,
}

impl RetargetMode {
    /// The fixed new target of a fixed-target mode.
    pub fn fixed_target(&self) -> Option<&crate::target_model::ChooseSpec> {
        match self {
            Self::OneToFixed(spec) | Self::AllToFixed(spec) => Some(spec),
            Self::All | Self::One => None,
        }
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub enum DelayedTriggerSpec {
    /// A fully typed zone change, including event provenance restrictions.
    ZoneChange(crate::trigger_model::ZoneChangeTrigger),
    /// An event-time condition qualifies the delayed event matcher, rather
    /// than becoming an intervening condition checked again on resolution.
    ConditionQualified {
        trigger: Box<DelayedTriggerSpec>,
        condition: crate::value_model::Condition,
        surface: String,
    },
    AsPermanentsUntap {
        player: PlayerFilter,
        source_must_be_controlled: bool,
    },
    BeginningOfUpkeep(PlayerFilter),
    BeginningOfDrawStep(PlayerFilter),
    BeginningOfEndStep(PlayerFilter),
    BeginningOfCleanupStep(PlayerFilter),
    /// The first cleanup step that begins after this delayed trigger is
    /// registered. The scheduling effect is one-shot; the player filter
    /// distinguishes "the next cleanup step" from "your next cleanup step".
    BeginningOfNextCleanupStep(PlayerFilter),
    BeginningOfCombat(PlayerFilter),
    BeginningOfMainPhase(PlayerFilter),
    BeginningOfPrecombatMainPhase(PlayerFilter),
    BeginningOfPostcombatMainPhase(PlayerFilter),
    EndOfCombat,
    SourceControllerLosesControl {
        source_description: String,
    },
    ThisEntersBattlefield,
    ThisEntersBattlefieldWithSurface {
        surface: SourceReferenceSurface,
        subject_number: crate::trigger_model::TriggerSubjectNumber,
    },
    EntersBattlefield {
        filter: ObjectFilter,
        cause_filter: Option<crate::cause_model::CauseFilter>,
        count: crate::trigger_model::CountMode,
        tapped: Option<bool>,
    },
    ThisDies,
    ThisLeavesBattlefield,
    ThisAttacksAndIsntBlocked,
    ThisBlocksObject {
        filter: ObjectFilter,
        min_blocked_objects: Option<u32>,
    },
    ThisBecomesBlockedByObject(ObjectFilter),
    Attacks(ObjectFilter),
    /// "whenever a creature attacks you or a planeswalker you control"
    /// (Tamiyo, Seasoned Scholar +2).
    AttacksYou(ObjectFilter),
    /// "Until end of turn, whenever a player taps an Island for mana, ..."
    /// (High Tide).
    PlayerTapsForMana {
        player: PlayerFilter,
        filter: ObjectFilter,
    },
    AttacksAndIsntBlocked(ObjectFilter),
    AttacksOneOrMore(ObjectFilter),
    Blocks(ObjectFilter),
    BlocksOneOrMore(ObjectFilter),
    BecomesBlocked(ObjectFilter),
    LeavesBattlefield(ObjectFilter),
    Dies(ObjectFilter),
    PermanentBecomesTapped(ObjectFilter),
    DealsCombatDamage(ObjectFilter),
    DealsCombatDamageTo {
        source: ObjectFilter,
        target: ObjectFilter,
    },
    DealsCombatDamageToPlayer {
        source: ObjectFilter,
        player: PlayerFilter,
    },
    DealsCombatDamageToPlayerOneOrMore {
        source: ObjectFilter,
        player: PlayerFilter,
        /// "... to a player" (once for each damaged player) rather than
        /// "... to one or more players" (once for the whole event).
        #[cfg_attr(feature = "serde", serde(default))]
        each_damaged_player: bool,
        #[cfg_attr(feature = "serde", serde(default))]
        per_source_controller: bool,
        #[cfg_attr(feature = "serde", serde(default))]
        recipient_passive: bool,
        #[cfg_attr(feature = "serde", serde(default))]
        during_your_turn: bool,
    },
    IsDealtDamage(ChooseSpec),
    PutIntoGraveyard(ObjectFilter),
    PutIntoGraveyardFromZone {
        filter: ObjectFilter,
        from: crate::zone::Zone,
        one_or_more: bool,
    },
    SpellCast {
        filter: Option<ObjectFilter>,
        caster: PlayerFilter,
        timing: Option<crate::trigger_model::TriggerTimingRestriction>,
        during_turn: Option<PlayerFilter>,
        min_spells_this_turn: Option<u32>,
        exact_spells_this_turn: Option<u32>,
        from_not_hand: bool,
        first_spell_of_game: bool,
    },
    PlayerPlaysLand {
        player: PlayerFilter,
        filter: ObjectFilter,
    },
    PlayerDrawsCard(PlayerFilter),
    AbilityActivated {
        activator: PlayerFilter,
        filter: ObjectFilter,
        non_mana_only: bool,
        loyalty_only: bool,
        activation_cost_has_tap: Option<bool>,
    },
    Either(Box<DelayedTriggerSpec>, Box<DelayedTriggerSpec>),
    /// Each actual life gain/loss while this registration is active.
    LifeChanged {
        player: PlayerFilter,
        gained: bool,
        during_turn: Option<PlayerFilter>,
    },
    ControlChanged(crate::trigger_model::ControlChangeTrigger),
    PermanentBecomesUntapped {
        filter: ObjectFilter,
    },
    PlayerDiscardsCard {
        player: PlayerFilter,
        filter: Option<ObjectFilter>,
        cause_controller: Option<PlayerFilter>,
        effect_like_only: bool,
        one_or_more: bool,
    },
    /// Append-only: preserve published delayed-trigger variant ordinals.
    /// One player declaration, grouped independently of individual attackers.
    PlayerAttackDeclaration {
        attacker: PlayerFilter,
        defender: PlayerFilter,
        grouping: crate::trigger_model::PlayerAttackGrouping,
    },
    /// Append-only. "Whenever [object] deals damage" for the registration's
    /// lifetime, combat or noncombat alike (CR 120.1). A registration that
    /// watches a captured object names it with a `source` filter.
    DealsDamage { source: ObjectFilter },
    /// Append-only. "Whenever [object] is dealt damage by [source]" for the
    /// registration's lifetime (CR 120.1); a watched recipient is `source`.
    DealsDamageTo {
        source: ObjectFilter,
        target: ObjectFilter,
    },
    /// Append-only. "Whenever [creature] attacks alone" for the
    /// registration's lifetime: the only creature declared as an attacker
    /// (CR 506.5).
    AttacksAlone(ObjectFilter),
    /// "Whenever damage [from a <quality> source] is prevented this way":
    /// the delayed ability is linked to the prevention shield created just
    /// before it was registered (CR 603.7, 615.5); the filter qualifies the
    /// prevented damage's source.
    DamagePreventedThisWay {
        source_filter: Option<ObjectFilter>,
    },
    /// Append-only. "At the beginning of the declare attackers step on
    /// [player's] turn" (CR 508): fires once attackers have been declared
    /// (or none were) in that player's declare attackers step.
    BeginningOfDeclareAttackersStep(PlayerFilter),
    /// A delayed cast watcher linked to the preceding play grant.
    SpellCastThroughPreviousPermission,
    /// Append-only. Keyword actions can be watched for a bounded duration,
    /// including an exact captured object such as a visited Attraction.
    KeywordAction {
        action: crate::KeywordActionKind,
        player: PlayerFilter,
        source_filter: Option<ObjectFilter>,
        during_your_turn: bool,
    },
    /// Append-only. "Whenever you play a land or cast a spell this way"
    /// (Apple of Eden, Isu Relic): a delayed watcher linked to the exact play
    /// grants made by the preceding instruction, observing both land plays
    /// and spell casts made through them.
    PlayedOrCastThroughPreviousPermission,
}

/// Lifetime policy for a delayed trigger registration.
///
/// The runtime anchors turn-relative variants when the scheduling effect
/// resolves, so intervening extra turns do not change their meaning.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default, TagKeyWalk)]
pub enum DelayedTriggerDuration {
    #[default]
    Forever,
    EndOfTurn,
    EndOfCombat,
    UntilControllerNextTurn,
    UntilControllerNextTurnEnd,
    /// "For as long as this creature remains tapped" (Giant Oyster): the
    /// registration ends once the ability's source untaps or leaves the
    /// battlefield. Appended for wire stability.
    WhileSourceTapped,
}

/// A cost that may be paid while a delayed trigger is pending to cancel that
/// registration before it fires.
///
/// This models clauses such as "unless they pay {1} before that draw step".
/// The runtime resolves `player` when the delayed trigger is registered so the
/// payment window remains valid even after the originating source changes
/// zones.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct DelayedTriggerPrepayment<E> {
    pub player: PlayerFilter,
    pub cost: crate::cost_model::TotalCost<crate::cost_model::Cost<E>>,
}

impl<E> DelayedTriggerPrepayment<E> {
    pub fn new(
        player: PlayerFilter,
        cost: crate::cost_model::TotalCost<crate::cost_model::Cost<E>>,
    ) -> Self {
        Self { player, cost }
    }
}

/// A source-owned collection shared by repeated registrations of one watcher.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, Eq, Hash, TagKeyWalk)]
pub struct SourceCollectionScope {
    pub name: String,
    pub tag: crate::tag::TagKey,
    pub zone: crate::zone::Zone,
    pub capture_from: EffectId,
    pub capture_action: crate::PriorEffectAction,
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct ScheduleDelayedTriggerEffect<E> {
    #[cfg_attr(feature = "serde", serde(default))]
    pub source_collection_scope: Option<SourceCollectionScope>,
    pub trigger: DelayedTriggerSpec,
    pub effects: Vec<E>,
    /// Explicit free cast-object references imported by this delayed body. Local
    /// producers never appear here, even inside optional branches.
    #[cfg_attr(feature = "serde", serde(default, skip_serializing_if = "Vec::is_empty"))]
    pub object_reference_imports: Vec<crate::tag::TagKey>,
    pub one_shot: bool,
    pub start_next_turn: bool,
    pub duration: DelayedTriggerDuration,
    pub until_end_of_turn: bool,
    pub until_end_of_combat: bool,
    /// Preserve an authored duration before the trigger clause, such as
    /// "Until end of turn, whenever ...", instead of moving it to the event.
    pub leading_duration_surface: bool,
    pub watch_ability_source: bool,
    /// Capture every object target chosen for the resolving spell or ability
    /// and register one watcher per object.
    pub watch_all_object_targets: bool,
    /// Preserve the authored set-reference surface for a watched tagged set,
    /// such as "either of those creatures".
    pub either_of_watched_objects: bool,
    /// A collection-scoped lifetime: the registration expires once none of
    /// the captured objects under `tag` remain in `zone`.
    pub while_any_tagged_object_in_zone: Option<(crate::tag::TagKey, crate::zone::Zone)>,
    pub target_choices: Vec<ChooseSpec>,
    pub target_tag: Option<crate::tag::TagKey>,
    pub target_filter: Option<ObjectFilter>,
    pub controller: PlayerFilter,
    /// Optional payment window that cancels this delayed registration.
    pub prepayment: Option<DelayedTriggerPrepayment<E>>,
    /// Resolve numeric `... damage prevented this way` values from the
    /// prevention shield created immediately before this registration.
    ///
    /// The runtime captures the shield identity when this effect resolves;
    /// the delayed ability therefore observes the amount actually prevented,
    /// even after the shield itself is exhausted and removed.
    pub event_value_from_prior_prevention: bool,
    /// "until the end of defending player's next turn" (Nuka-Nuke Launcher):
    /// the player whose next turn bounds a next-turn duration instead of the
    /// registration's controller. Resolved when the trigger is registered; the
    /// resolved player is also exposed to the delayed ability as the tagged
    /// player `DELAYED_DURATION_PLAYER_TAG`.
    #[cfg_attr(feature = "serde", serde(default))]
    pub duration_player: Option<PlayerFilter>,
    /// Authored intro word of the delayed trigger when it differs from the
    /// one implied by `one_shot`: "When that creature deals combat damage to
    /// a player this turn, ..." (Optimus Prime) triggers each time during
    /// its stated duration (CR 603.7c) yet is printed with "When".
    #[cfg_attr(feature = "serde", serde(default))]
    pub intro_surface: Option<crate::trigger_model::TriggerIntroSurface>,
    /// Register one persistent, source-free rule for this resolved player.
    /// The name is data identity: it never selects behavior.
    #[cfg_attr(feature = "serde", serde(default))]
    pub persistent_player_rule: Option<String>,
    #[cfg_attr(feature = "serde", serde(default))]
    pub intervening_if: Option<crate::Condition>,

}

/// Tagged-player key under which a delayed trigger exposes its resolved
/// `duration_player` to its trigger matcher and effects.
pub const DELAYED_DURATION_PLAYER_TAG: &str = "delayed_duration_player";

impl<E> ScheduleDelayedTriggerEffect<E> {
    pub fn new(
        trigger: DelayedTriggerSpec,
        effects: impl Into<Vec<E>>,
        one_shot: bool,
        target_choices: Vec<ChooseSpec>,
        controller: PlayerFilter,
    ) -> Self {
        Self {
            trigger,
            effects: effects.into(),
            object_reference_imports: Vec::new(),
            one_shot,
            start_next_turn: false,
            duration: DelayedTriggerDuration::Forever,
            until_end_of_turn: false,
            until_end_of_combat: false,
            leading_duration_surface: false,
            watch_ability_source: false,
            watch_all_object_targets: false,
            either_of_watched_objects: false,
            while_any_tagged_object_in_zone: None,
            source_collection_scope: None,
            target_choices,
            target_tag: None,
            target_filter: None,
            controller,
            prepayment: None,
            event_value_from_prior_prevention: false,
            duration_player: None,
            intro_surface: None,
            persistent_player_rule: None,
            intervening_if: None,
        }
    }

    pub fn with_duration_player(mut self, player: PlayerFilter) -> Self {
        self.duration_player = Some(player);
        self
    }

    pub fn with_intro_surface(
        mut self,
        intro: crate::trigger_model::TriggerIntroSurface,
    ) -> Self {
        self.intro_surface = Some(intro);
        self
    }

    pub fn from_tag(
        tag: crate::tag::TagKey,
        trigger: DelayedTriggerSpec,
        effects: impl Into<Vec<E>>,
        one_shot: bool,
        target_choices: Vec<ChooseSpec>,
        controller: PlayerFilter,
    ) -> Self {
        Self {
            target_tag: Some(tag),
            ..Self::new(trigger, effects, one_shot, target_choices, controller)
        }
    }

    pub fn with_target_filter(mut self, filter: ObjectFilter) -> Self {
        self.target_filter = Some(filter);
        self
    }

    pub fn starting_next_turn(mut self) -> Self {
        self.start_next_turn = true;
        self
    }

    pub fn unless_paid_before_trigger(
        mut self,
        player: PlayerFilter,
        cost: crate::cost_model::TotalCost<crate::cost_model::Cost<E>>,
    ) -> Self {
        self.prepayment = Some(DelayedTriggerPrepayment::new(player, cost));
        self
    }

    pub fn with_prior_prevention_event_value(mut self) -> Self {
        self.event_value_from_prior_prevention = true;
        self
    }

    pub fn until_end_of_turn(mut self) -> Self {
        self.duration = DelayedTriggerDuration::EndOfTurn;
        self.until_end_of_turn = true;
        self.until_end_of_combat = false;
        self
    }

    pub fn until_end_of_combat(mut self) -> Self {
        self.duration = DelayedTriggerDuration::EndOfCombat;
        self.until_end_of_combat = true;
        self.until_end_of_turn = false;
        self
    }

    pub fn until_controller_next_turn(mut self) -> Self {
        self.duration = DelayedTriggerDuration::UntilControllerNextTurn;
        self.until_end_of_turn = false;
        self.until_end_of_combat = false;
        self
    }

    pub fn until_controller_next_turn_end(mut self) -> Self {
        self.duration = DelayedTriggerDuration::UntilControllerNextTurnEnd;
        self.until_end_of_turn = false;
        self.until_end_of_combat = false;
        self
    }

    /// End the registration when the ability's source untaps or leaves.
    pub fn until_source_untaps(mut self) -> Self {
        self.duration = DelayedTriggerDuration::WhileSourceTapped;
        self.until_end_of_turn = false;
        self.until_end_of_combat = false;
        self
    }

    pub fn with_leading_duration_surface(mut self) -> Self {
        self.leading_duration_surface = true;
        self
    }

    pub fn with_either_of_watched_objects_surface(mut self) -> Self {
        self.either_of_watched_objects = true;
        self
    }

    pub fn while_any_tagged_object_in_zone(
        mut self,
        tag: impl Into<crate::tag::TagKey>,
        zone: crate::zone::Zone,
    ) -> Self {
        self.while_any_tagged_object_in_zone = Some((tag.into(), zone));
        self
    }

    pub fn watch_ability_source(mut self) -> Self {
        self.watch_ability_source = true;
        self
    }

    pub fn watch_all_object_targets(mut self) -> Self {
        self.watch_all_object_targets = true;
        self
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, Copy, PartialEq, Eq, TagKeyWalk)]
pub enum SetQuantifierSurface {
    All,
    Each,
    /// A plural pronoun referring to an already established object result.
    ///
    /// The result tag/filter remains the executable identity; this records
    /// only that Oracle authored the follow-up subject as `they`.
    They,
    /// A plural demonstrative reference to a previously established set.
    ///
    /// This is presentation-only, but unlike `Each` it also records that
    /// lowering must reuse the antecedent set rather than build a new set from
    /// the demonstrative noun alone.
    Those,
}

/// Oracle surface used when a type-changing effect preserves an object's
/// existing types. Both variants have the same rules meaning, but they render
/// differently and must remain distinguishable after lowering.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, Copy, PartialEq, Eq, TagKeyWalk)]
pub enum TypeRetentionSurface {
    InAdditionToOtherTypes,
    /// The effect adds the creature card type, but Oracle expresses the
    /// animation as a P/T plus creature subtype (for example, "a 1/1
    /// Spirit") without spelling out the `creature` noun.
    InAdditionToOtherTypesImplicitCreature,
    StillALand,
    /// Oracle names another retained card type inline (for example,
    /// "that's still a planeswalker"). The executable effect still adds its
    /// new types instead of replacing the object's existing types.
    StillACardType(CardType),
    /// Oracle restates a retained card type as its own sentence after the
    /// animation ("... becomes a 6/6 Nightmare God creature. It's still an
    /// enchantment."). Same rules meaning as [`Self::StillACardType`].
    StillACardTypeSentence(CardType),
    /// "It's still a Cave land." (Cavernous Maw): the retained land restated
    /// with one of its land subtypes. Same rules meaning as [`Self::StillALand`].
    StillASubtypedLand(crate::types::Subtype),
}

/// Oracle surface used to express the power and toughness portion of an
/// animation effect. Both forms create the same base-power/toughness layer,
/// but authored leading P/T ("a 4/4 Angel creature") must not be rewritten as
/// an explicit base-P/T clause ("an Angel creature with base power and
/// toughness 4/4").
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, Copy, PartialEq, Eq, TagKeyWalk)]
pub enum AnimationPtSurface {
    LeadingPowerToughness,
    ExplicitBasePowerToughness,
}

/// Oracle placement of an animation effect's duration. Absence retains the
/// legacy trailing-duration surface, while this marker preserves authored
/// leading durations such as "Until end of turn, target land becomes ...".
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, Copy, PartialEq, Eq, TagKeyWalk)]
pub enum AnimationDurationSurface {
    Leading,
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct ApplyContinuousEffect<
    Target,
    Modification,
    RuntimeModification,
    Condition = (),
    SourceType = (),
> {
    pub target: Target,
    pub target_spec: Option<ChooseSpec>,
    pub modification: Option<Modification>,
    pub additional_modifications: Vec<Modification>,
    pub runtime_modifications: Vec<RuntimeModification>,
    pub until: Until,
    pub condition: Option<Condition>,
    pub source_type: Option<SourceType>,
    pub source_reference_surface: Option<SourceReferenceSurface>,
    pub set_quantifier_surface: Option<SetQuantifierSurface>,
    pub type_retention_surface: Option<TypeRetentionSurface>,
    pub animation_pt_surface: Option<AnimationPtSurface>,
    pub animation_duration_surface: Option<AnimationDurationSurface>,
    pub lock_filter_at_resolution: bool,
    pub resolve_set_pt_values_at_resolution: bool,
    pub require_creature_target: bool,
    /// "If it doesn't have \"...,\" it gains that ability" (Musician): an
    /// object that already has every granted ability is skipped, so repeated
    /// resolutions never stack duplicate copies of the same ability.
    #[cfg_attr(feature = "serde", serde(default, skip_serializing_if = "std::ops::Not::not"))]
    pub grant_only_if_absent: bool,
}

impl<Target, Modification, RuntimeModification, Condition, SourceType>
    ApplyContinuousEffect<Target, Modification, RuntimeModification, Condition, SourceType>
{
    pub fn new(target: Target, modification: Modification, until: Until) -> Self {
        Self {
            target,
            target_spec: None,
            modification: Some(modification),
            additional_modifications: Vec::new(),
            runtime_modifications: Vec::new(),
            until,
            condition: None,
            source_type: None,
            source_reference_surface: None,
            set_quantifier_surface: None,
            type_retention_surface: None,
            animation_pt_surface: None,
            animation_duration_surface: None,
            lock_filter_at_resolution: false,
            resolve_set_pt_values_at_resolution: false,
            require_creature_target: false,
            grant_only_if_absent: false,
        }
    }

    pub fn new_runtime(target: Target, modification: RuntimeModification, until: Until) -> Self {
        Self {
            target,
            target_spec: None,
            modification: None,
            additional_modifications: Vec::new(),
            runtime_modifications: vec![modification],
            until,
            condition: None,
            source_type: None,
            source_reference_surface: None,
            set_quantifier_surface: None,
            type_retention_surface: None,
            animation_pt_surface: None,
            animation_duration_surface: None,
            lock_filter_at_resolution: false,
            resolve_set_pt_values_at_resolution: false,
            require_creature_target: false,
            grant_only_if_absent: false,
        }
    }

    pub fn with_spec(target_spec: ChooseSpec, modification: Modification, until: Until) -> Self
    where
        Target: From<ChooseSpec>,
    {
        Self {
            target: target_spec.clone().into(),
            target_spec: Some(target_spec),
            modification: Some(modification),
            additional_modifications: Vec::new(),
            runtime_modifications: Vec::new(),
            until,
            condition: None,
            source_type: None,
            source_reference_surface: None,
            set_quantifier_surface: None,
            type_retention_surface: None,
            animation_pt_surface: None,
            animation_duration_surface: None,
            lock_filter_at_resolution: false,
            resolve_set_pt_values_at_resolution: false,
            require_creature_target: false,
            grant_only_if_absent: false,
        }
    }

    pub fn with_spec_runtime(
        target_spec: ChooseSpec,
        modification: RuntimeModification,
        until: Until,
    ) -> Self
    where
        Target: From<ChooseSpec>,
    {
        Self {
            target: target_spec.clone().into(),
            target_spec: Some(target_spec),
            modification: None,
            additional_modifications: Vec::new(),
            runtime_modifications: vec![modification],
            until,
            condition: None,
            source_type: None,
            source_reference_surface: None,
            set_quantifier_surface: None,
            type_retention_surface: None,
            animation_pt_surface: None,
            animation_duration_surface: None,
            lock_filter_at_resolution: false,
            resolve_set_pt_values_at_resolution: false,
            require_creature_target: false,
            grant_only_if_absent: false,
        }
    }

    pub fn with_additional_modification(mut self, modification: Modification) -> Self {
        self.additional_modifications.push(modification);
        self
    }

    pub fn with_additional_runtime_modification(
        mut self,
        modification: RuntimeModification,
    ) -> Self {
        self.runtime_modifications.push(modification);
        self
    }

    pub fn with_condition(mut self, condition: Condition) -> Self {
        self.condition = Some(condition);
        self
    }

    pub fn with_source_type(mut self, source_type: SourceType) -> Self {
        self.source_type = Some(source_type);
        self
    }

    pub fn with_source_reference_surface(mut self, surface: SourceReferenceSurface) -> Self {
        self.source_reference_surface = Some(surface);
        self
    }

    pub fn with_set_quantifier_surface(mut self, surface: Option<SetQuantifierSurface>) -> Self {
        self.set_quantifier_surface = surface;
        self
    }

    pub fn with_type_retention_surface(mut self, surface: Option<TypeRetentionSurface>) -> Self {
        self.type_retention_surface = surface;
        self
    }

    pub fn with_animation_pt_surface(mut self, surface: Option<AnimationPtSurface>) -> Self {
        self.animation_pt_surface = surface;
        self
    }

    pub fn with_animation_duration_surface(
        mut self,
        surface: Option<AnimationDurationSurface>,
    ) -> Self {
        self.animation_duration_surface = surface;
        self
    }

    pub fn lock_filter_at_resolution(mut self) -> Self {
        self.lock_filter_at_resolution = true;
        self
    }

    pub fn resolve_set_pt_values_at_resolution(mut self) -> Self {
        self.resolve_set_pt_values_at_resolution = true;
        self
    }

    pub fn require_creature_target(mut self) -> Self {
        self.require_creature_target = true;
        self
    }

    pub fn grant_only_if_absent(mut self) -> Self {
        self.grant_only_if_absent = true;
        self
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq)]
#[expect(
    clippy::large_enum_variant,
    reason = "retarget restrictions preserve typed object filters inline"
)]
#[derive(TagKeyWalk)]
pub enum NewTargetRestriction {
    Player(PlayerFilter),
    Object(ObjectFilter),
    /// A new target may be a matching player or a matching object
    /// ("The new targets can't be you or a permanent you control"). Appended.
    PlayerOrObject {
        player: PlayerFilter,
        object: ObjectFilter,
    },
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, Copy, PartialEq, Eq, TagKeyWalk)]
pub enum SharedTypeConstraint {
    CardType,
    PermanentType,
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub enum ExchangeValueOperand {
    LifeTotal(crate::filter_model::PlayerFilter),
    Power(crate::target_model::ChooseSpec),
    Toughness(crate::target_model::ChooseSpec),
}

impl Default for ChoiceCount {
    fn default() -> Self {
        Self::exactly(1)
    }
}

impl ChoiceCount {
    /// Exactly N (the default for most effects).
    pub const fn exactly(n: usize) -> Self {
        Self {
            min: n,
            max: Some(n),
            dynamic_x: false,
            up_to_x: false,
            random: false,
            explicit_exactly: false,
        }
    }

    /// Any number (0 or more, unlimited).
    pub const fn any_number() -> Self {
        Self {
            min: 0,
            max: None,
            dynamic_x: false,
            up_to_x: false,
            random: false,
            explicit_exactly: false,
        }
    }

    /// At least N (N or more, unlimited).
    pub const fn at_least(n: usize) -> Self {
        Self {
            min: n,
            max: None,
            dynamic_x: false,
            up_to_x: false,
            random: false,
            explicit_exactly: false,
        }
    }

    /// Up to N (0 to N).
    pub const fn up_to(n: usize) -> Self {
        Self {
            min: 0,
            max: Some(n),
            dynamic_x: false,
            up_to_x: false,
            random: false,
            explicit_exactly: false,
        }
    }

    /// Dynamic X-target count (rendered as `X target ...`).
    pub const fn dynamic_x() -> Self {
        Self {
            min: 0,
            max: None,
            dynamic_x: true,
            up_to_x: false,
            random: false,
            explicit_exactly: false,
        }
    }

    /// Dynamic "up to X" count.
    pub const fn up_to_dynamic_x() -> Self {
        Self {
            min: 0,
            max: None,
            dynamic_x: true,
            up_to_x: true,
            random: false,
            explicit_exactly: false,
        }
    }

    /// Returns true if this is "any number" (min 0, no max).
    pub fn is_any_number(&self) -> bool {
        self.min == 0 && self.max.is_none() && !self.dynamic_x
    }

    /// Returns true if this is exactly 1.
    pub fn is_single(&self) -> bool {
        self.min == 1 && self.max == Some(1)
    }

    pub const fn is_dynamic_x(&self) -> bool {
        self.dynamic_x
    }

    pub const fn is_up_to_dynamic_x(&self) -> bool {
        self.dynamic_x && self.up_to_x
    }

    pub const fn is_random(&self) -> bool {
        self.random
    }

    pub fn at_random(mut self) -> Self {
        self.random = true;
        self
    }

    /// Preserve an explicitly authored `exactly` without changing the
    /// cardinality enforced by this choice.
    pub const fn with_explicit_exactly(mut self) -> Self {
        self.explicit_exactly = true;
        self
    }
}

impl From<usize> for ChoiceCount {
    fn from(value: usize) -> Self {
        ChoiceCount::exactly(value)
    }
}

impl From<i32> for ChoiceCount {
    fn from(value: i32) -> Self {
        if value <= 0 {
            ChoiceCount::exactly(0)
        } else {
            ChoiceCount::exactly(value as usize)
        }
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct DealDamageEffect {
    pub amount: Value,
    pub target: ChooseSpec,
    pub source_is_combat: bool,
    /// "The damage can't be prevented." rider on this damage.
    pub unpreventable: bool,
    /// "Excess damage is dealt to that creature's controller instead."
    #[cfg_attr(feature = "serde", serde(default))]
    pub excess_to_controller: Option<ExcessDamageRedirect>,
}

/// Damage beyond lethal dealt to a creature goes to its controller instead,
/// optionally only while `condition` holds as the damage is dealt.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct ExcessDamageRedirect {
    pub condition: Option<crate::value_model::Condition>,
}

impl DealDamageEffect {
    pub fn new(amount: impl Into<Value>, target: ChooseSpec) -> Self {
        Self {
            amount: amount.into(),
            target,
            source_is_combat: false,
            unpreventable: false,
            excess_to_controller: None,
        }
    }

    pub fn with_excess_to_controller(mut self, redirect: ExcessDamageRedirect) -> Self {
        self.excess_to_controller = Some(redirect);
        self
    }

    pub fn with_combat(mut self, is_combat: bool) -> Self {
        self.source_is_combat = is_combat;
        self
    }

    pub fn with_unpreventable(mut self, unpreventable: bool) -> Self {
        self.unpreventable = unpreventable;
        self
    }
}

/// Remove an exact amount, or all, of the damage marked on a permanent.
///
/// `amount == None` represents the CR 701.69a surface "damage ... is healed,"
/// which removes all marked damage from the permanent.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct HealDamageEffect {
    pub target: ChooseSpec,
    pub amount: Option<Value>,
}

impl HealDamageEffect {
    pub fn exact(target: ChooseSpec, amount: impl Into<Value>) -> Self {
        Self {
            target,
            amount: Some(amount.into()),
        }
    }

    pub fn all(target: ChooseSpec) -> Self {
        Self {
            target,
            amount: None,
        }
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct DrawCardsEffect {
    pub count: Value,
    pub player: PlayerFilter,
}

impl DrawCardsEffect {
    pub fn new(count: impl Into<Value>, player: PlayerFilter) -> Self {
        Self {
            count: count.into(),
            player,
        }
    }

    pub fn you(count: impl Into<Value>) -> Self {
        Self::new(count, PlayerFilter::You)
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, Eq, Default, TagKeyWalk)]
pub struct NoteLifeTotalEffect;

/// "Redistribute any number of players' life totals" (Reverse the Sands):
/// `chooser` picks any number of players, then gives each of them one of
/// those players' life totals. Each new total is a life gain or loss.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct RedistributeLifeTotalsEffect {
    pub chooser: PlayerFilter,
}

impl RedistributeLifeTotalsEffect {
    pub fn new(chooser: PlayerFilter) -> Self {
        Self { chooser }
    }
}

/// "put this creature into its owner's graveyard instead of onto the
/// battlefield" inside an as-enters program (Frankenstein's Monster): the
/// entering source goes to `destination` instead of entering (CR 614.1c).
/// Outside an entry program it does nothing.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct RedirectEnteringSourceEffect {
    pub destination: crate::zone::Zone,
}

impl RedirectEnteringSourceEffect {
    pub fn new(destination: crate::zone::Zone) -> Self {
        Self { destination }
    }
}

/// "Flip a coin. If you win the flip, you gain N life and target opponent
/// loses N life, and you decide whether to flip again. If you lose the flip,
/// you lose N life and that opponent gains N life, and that player decides
/// whether to flip again. Double the life stakes with each flip." (Game of
/// Chaos): the controller flips repeatedly; each flip moves the current stakes
/// of life between the two players, the flip's winner decides whether to flip
/// again, and the stakes double after every flip.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct CoinFlipLifeStakesEffect {
    pub opponent: ChooseSpec,
    pub initial_stakes: u32,
}

impl CoinFlipLifeStakesEffect {
    pub fn new(opponent: ChooseSpec, initial_stakes: u32) -> Self {
        Self { opponent, initial_stakes }
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct TargetOnlyEffect {
    pub target: ChooseSpec,
    /// The player who makes this target choice when Oracle assigns the choice
    /// to someone other than the spell or ability's controller.
    pub chooser: Option<PlayerFilter>,
    /// Whether this target declaration was an authored standalone clause
    /// (for example, "Choose target opponent.") rather than a synthetic
    /// prelude introduced by lowering so later effects can share a target.
    pub explicit_declaration: bool,
}

impl TargetOnlyEffect {
    pub fn new(target: ChooseSpec) -> Self {
        Self {
            target,
            chooser: None,
            explicit_declaration: false,
        }
    }

    pub fn explicit(target: ChooseSpec) -> Self {
        Self {
            target,
            chooser: None,
            explicit_declaration: true,
        }
    }

    pub fn with_chooser(mut self, chooser: PlayerFilter) -> Self {
        self.chooser = Some(chooser);
        self
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct TapEffect {
    pub target: ChooseSpec,
    /// Explicit actor of the instruction. Absent means the effect controller
    /// (or cost payer); it is independent from the recipient's controller.
    #[cfg_attr(feature = "serde", serde(default))]
    pub actor: Option<PlayerFilter>,
}

impl TapEffect {
    pub fn with_actor(mut self, actor: Option<PlayerFilter>) -> Self {
        self.actor = actor;
        self
    }

    pub fn with_spec(target: ChooseSpec) -> Self {
        Self {
            target,
            actor: None,
        }
    }

    pub fn target(target: ChooseSpec) -> Self {
        Self {
            target: ChooseSpec::target(target),
            actor: None,
        }
    }

    pub fn targets(target: ChooseSpec, count: ChoiceCount) -> Self {
        Self {
            target: ChooseSpec::target(target).with_count(count),
            actor: None,
        }
    }

    pub fn all(filter: ObjectFilter) -> Self {
        Self {
            target: ChooseSpec::all(filter),
            actor: None,
        }
    }

    pub fn source() -> Self {
        Self {
            target: ChooseSpec::Source,
            actor: None,
        }
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct UntapEffect {
    pub target: ChooseSpec,
    /// Explicit actor of the instruction. Absent means the effect controller
    /// (or cost payer); it is independent from the recipient's controller.
    #[cfg_attr(feature = "serde", serde(default))]
    pub actor: Option<PlayerFilter>,
}

impl UntapEffect {
    pub fn with_actor(mut self, actor: Option<PlayerFilter>) -> Self {
        self.actor = actor;
        self
    }

    pub fn with_spec(target: ChooseSpec) -> Self {
        Self {
            target,
            actor: None,
        }
    }

    pub fn target(target: ChooseSpec) -> Self {
        Self {
            target: ChooseSpec::target(target),
            actor: None,
        }
    }

    pub fn targets(target: ChooseSpec, count: ChoiceCount) -> Self {
        Self {
            target: ChooseSpec::target(target).with_count(count),
            actor: None,
        }
    }

    pub fn all(filter: ObjectFilter) -> Self {
        Self {
            target: ChooseSpec::all(filter),
            actor: None,
        }
    }
}

/// Place current objects into one persistent association. Group creation and
/// combat coordination are explicit data, independent of keyword identities.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug,Clone,PartialEq,TagKeyWalk)]
pub struct ObjectGroupAssignment {
    pub subjects: ChooseSpec,
    pub owner: Option<ChooseSpec>,
    pub combat_together: bool,
}
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug,Clone,PartialEq,TagKeyWalk)]
pub struct LinkObjectsToGroupEffect {
    /// All assignments in this instruction occur simultaneously.
    pub groups: Vec<ObjectGroupAssignment>,
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct PutCountersEffect {
    /// Only this placement is capped; other abilities may exceed the total.
    #[cfg_attr(
        feature = "serde",
        serde(default, skip_serializing_if = "Option::is_none")
    )]
    pub maximum_total: Option<u32>,
    #[cfg_attr(feature = "serde", serde(default))]
    pub completion_action: Option<crate::event_model::KeywordActionKind>,
    pub counter_type: crate::counter::CounterType,
    pub amount: Value,
    pub target: ChooseSpec,
    pub target_count: Option<ChoiceCount>,
    pub distributed: bool,
    /// "Distribute X +1/+1 counters among it and any number of commanders":
    /// objects that are always members of a distribution and each receive at
    /// least one of its counters, while the `target` recipients are optional.
    #[cfg_attr(
        feature = "serde",
        serde(default, skip_serializing_if = "Option::is_none")
    )]
    pub required_recipient: Option<ChooseSpec>,
    /// "put the same number and kind of counters on <target>" (Captain
    /// Marvel, Bold Plagiarist): at resolution the counter kind and amount
    /// come from the triggering counter-placement event; `counter_type` and
    /// `amount` are only the authored fallback. Appended with a serde default.
    #[cfg_attr(
        feature = "serde",
        serde(default, skip_serializing_if = "std::ops::Not::not")
    )]
    pub counter_kind_from_trigger: bool,
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct DoubleCountersEffect {
    pub counter_type: Option<crate::counter::CounterType>,
    pub target: ChooseSpec,
}

impl DoubleCountersEffect {
    pub fn new(counter_type: Option<crate::counter::CounterType>, target: ChooseSpec) -> Self {
        Self {
            counter_type,
            target,
        }
    }
}

impl PutCountersEffect {
    pub fn with_maximum_total(mut self, maximum: u32) -> Self {
        self.maximum_total = Some(maximum);
        self
    }

    pub fn with_completion_action(mut self, action: crate::event_model::KeywordActionKind) -> Self {
        self.completion_action = Some(action);
        self
    }

    pub fn new(
        counter_type: crate::counter::CounterType,
        amount: impl Into<Value>,
        target: ChooseSpec,
    ) -> Self {
        Self {
            maximum_total: None,
            completion_action: None,
            counter_type,
            amount: amount.into(),
            target,
            target_count: None,
            distributed: false,
            required_recipient: None,
            counter_kind_from_trigger: false,
        }
    }

    /// Take the counter kind and amount from the triggering counter event.
    pub fn with_counter_kind_from_trigger(mut self) -> Self {
        self.counter_kind_from_trigger = true;
        self
    }

    pub fn with_target_count(mut self, count: ChoiceCount) -> Self {
        self.target_count = Some(count);
        self
    }

    pub fn with_distributed(mut self, distributed: bool) -> Self {
        self.distributed = distributed;
        self
    }

    pub fn with_required_recipient(mut self, recipient: ChooseSpec) -> Self {
        self.required_recipient = Some(recipient);
        self
    }

    pub fn plus_one_counters(count: impl Into<Value>, target: ChooseSpec) -> Self {
        Self::new(crate::counter::CounterType::PlusOnePlusOne, count, target)
    }

    pub fn minus_one_counters(count: impl Into<Value>, target: ChooseSpec) -> Self {
        Self::new(crate::counter::CounterType::MinusOneMinusOne, count, target)
    }

    pub fn on_source(counter_type: crate::counter::CounterType, count: impl Into<Value>) -> Self {
        Self::new(counter_type, count, ChooseSpec::Source)
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct RemoveCountersEffect {
    pub counter_type: crate::counter::CounterType,
    pub count: Value,
    pub target: ChooseSpec,
}

impl RemoveCountersEffect {
    pub fn new(
        counter_type: crate::counter::CounterType,
        count: impl Into<Value>,
        target: ChooseSpec,
    ) -> Self {
        Self {
            counter_type,
            count: count.into(),
            target,
        }
    }

    pub fn plus_one_counters(count: impl Into<Value>, target: ChooseSpec) -> Self {
        Self::new(crate::counter::CounterType::PlusOnePlusOne, count, target)
    }

    pub fn minus_one_counters(count: impl Into<Value>, target: ChooseSpec) -> Self {
        Self::new(crate::counter::CounterType::MinusOneMinusOne, count, target)
    }
}

/// A gate on the counter's destination replacement, never on its legal target.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, Copy, PartialEq, Eq, TagKeyWalk)]
pub enum CounterExileGate {
    AnySpell,
    PermanentSpell,
}

/// Atomic ownership of "countered this way" → exact exile incarnation → free
/// permission. Price, recipient (the effect's controller), ordinary timing and
/// duration (only while this incarnation remains exiled) are intrinsic, not
/// independent tags that can accidentally bind another movement or stable card.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[cfg_attr(feature = "serde", serde(deny_unknown_fields))]
#[derive(Debug, Clone, Copy, PartialEq, Eq, TagKeyWalk)]
pub struct CounterExilePermission {
    pub gate: CounterExileGate,
    /// "Play" also permits a legal land face; "cast" never does.
    pub allow_land: bool,
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct CounterEffect {
    pub target: ChooseSpec,
    /// Absent on legacy ordinary counters. New payload meaning requires the
    /// current semantic/cache boundary; serde defaults are not admission.
    #[cfg_attr(feature = "serde", serde(default, skip_serializing_if = "Option::is_none"))]
    pub exile_permission: Option<CounterExilePermission>,
}

impl CounterEffect {
    pub fn new(target: ChooseSpec) -> Self {
        Self { target, exile_permission: None }
    }

    pub fn with_exile_permission(mut self, permission: CounterExilePermission) -> Self {
        self.exile_permission = Some(permission);
        self
    }

    /// The atomic rider consumes one explicit stack spell, never a source pool,
    /// stale tagged snapshot, plural selector, or ability. Exact object IDs are
    /// available to native callers; compiled text uses the single spell target.
    pub fn exile_permission_target_is_supported(&self) -> bool {
        if self.exile_permission.is_none() { return true; }
        let spec = match self.target.unhinted() {
            ChooseSpec::Target(inner) => inner.unhinted(),
            spec => spec,
        };
        match spec {
            ChooseSpec::SpecificObject(_) => true,
            // This cohort authors exactly "target spell". Admit that complete
            // vocabulary, not a partial field check: source flags, nested
            // any_of/not/tag relations and every other contextual dependency
            // must not smuggle in a different producer. SurfaceHinted wrappers
            // above are presentation-only and remain supported.
            ChooseSpec::Object(filter) => filter == &ObjectFilter::spell(),
            _ => false,
        }
    }

    pub fn any_spell() -> Self {
        Self::new(ChooseSpec::spell())
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default, TagKeyWalk)]
pub enum ConditionalSurface {
    #[default]
    LeadingIf,
    TrailingIf,
    TrailingUnless,
    /// "[if_false]. If [condition], [if_true] instead." — a self-replacement
    /// nested inside another branch (for example, an "If you do" result).
    Instead,
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct ConditionalEffect<E> {
    pub condition: crate::value_model::Condition,
    pub if_true: Vec<E>,
    pub if_false: Vec<E>,
    pub surface: ConditionalSurface,
    /// Internal continuation receipt: report the condition's selected branch
    /// before its effects run, independently of their success or state changes.
    #[cfg_attr(feature = "serde", serde(default))]
    pub capture_condition_result: bool,
    /// Authored ability word on the conditional instruction ("Fateful hour —
    /// If you have 5 or less life, ..."). Presentation only.
    #[cfg_attr(feature = "serde", serde(default))]
    pub presentation_label: Option<crate::PresentationLabel>,
}

impl<E> ConditionalEffect<E> {
    pub fn new(
        condition: crate::value_model::Condition,
        if_true: Vec<E>,
        if_false: Vec<E>,
    ) -> Self {
        Self {
            condition,
            if_true,
            if_false,
            surface: ConditionalSurface::LeadingIf,
            capture_condition_result: false,
            presentation_label: None,
        }
    }

    pub fn if_only(condition: crate::value_model::Condition, if_true: Vec<E>) -> Self {
        Self::new(condition, if_true, vec![])
    }

    /// A resolution-time condition printed after its effect as
    /// "... unless <condition>". The stored condition remains the executable
    /// gate for `if_true`, so it is the negation of the printed condition.
    pub fn trailing_unless(condition: crate::value_model::Condition, effects: Vec<E>) -> Self {
        Self {
            condition: crate::value_model::Condition::Not(Box::new(condition)),
            if_true: effects,
            if_false: vec![],
            surface: ConditionalSurface::TrailingUnless,
            capture_condition_result: false,
            presentation_label: None,
        }
    }

    /// A resolution-time condition authored after its effect as
    /// "... if <condition>".
    pub fn trailing_if(condition: crate::value_model::Condition, effects: Vec<E>) -> Self {
        Self {
            condition,
            if_true: effects,
            if_false: vec![],
            surface: ConditionalSurface::TrailingIf,
            capture_condition_result: false,
            presentation_label: None,
        }
    }

    pub fn with_condition_result(mut self, capture: bool) -> Self {
        self.capture_condition_result = capture;
        self
    }

    pub fn with_surface(mut self, surface: ConditionalSurface) -> Self {
        self.surface = surface;
        self
    }

    pub fn with_presentation_label(mut self, label: Option<crate::PresentationLabel>) -> Self {
        self.presentation_label = label;
        self
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct IfEffect<E> {
    pub condition: EffectId,
    pub predicate: EffectPredicate,
    pub then: Vec<E>,
    pub else_: Vec<E>,
    /// Evaluate this result predicate independently for every participant in
    /// the antecedent's `PlayerCounts` fact, binding that participant as the
    /// iterated player while executing the selected branch.
    pub per_player_result: bool,
    /// This prior-result branch was authored as a self-replacement of the
    /// default arm ("draw one; if ..., draw two instead"), rather than as an
    /// ordinary if/otherwise choice. Resolution semantics live in `then` and
    /// `else_`; this flag preserves the authored surface for rendering.
    pub prior_result_replacement_surface: bool,
}

impl<E> IfEffect<E> {
    pub fn new(
        condition: EffectId,
        predicate: EffectPredicate,
        then: Vec<E>,
        else_: Vec<E>,
    ) -> Self {
        Self {
            condition,
            predicate,
            then,
            else_,
            per_player_result: false,
            prior_result_replacement_surface: false,
        }
    }

    pub fn with_per_player_result(mut self, enabled: bool) -> Self {
        self.per_player_result = enabled;
        self
    }

    pub fn with_prior_result_replacement_surface(mut self, enabled: bool) -> Self {
        self.prior_result_replacement_surface = enabled;
        self
    }

    pub fn if_then(condition: EffectId, predicate: EffectPredicate, then: Vec<E>) -> Self {
        Self::new(condition, predicate, then, vec![])
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct WithIdEffect<E> {
    pub id: EffectId,
    pub effect: Box<E>,
}

impl<E> WithIdEffect<E> {
    pub fn new(id: EffectId, effect: E) -> Self {
        Self {
            id,
            effect: Box::new(effect),
        }
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct TaggedEffect<E> {
    pub tag: crate::tag::TagKey,
    pub effect: Box<E>,
    /// Record only the action's affected set, including an empty result.
    #[cfg_attr(feature = "serde", serde(default))]
    pub outcome_only: bool,
}

impl<E> TaggedEffect<E> {
    pub fn with_effect<T>(&self, effect: T) -> TaggedEffect<T> {
        TaggedEffect {
            tag: self.tag.clone(),
            effect: Box::new(effect),
            outcome_only: self.outcome_only,
        }
    }

    pub fn new(tag: impl Into<crate::tag::TagKey>, effect: E) -> Self {
        Self {
            tag: tag.into(),
            effect: Box::new(effect),
            outcome_only: false,
        }
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct EffectMode<E> {
    pub source_text: String,
    pub effects: Vec<E>,
}

/// A mode-selection range enabled by a later optional-cost announcement.
///
/// CR 601.4 allows an earlier mode choice to consider an optional cost that
/// will be chosen later in the same proposal (for example, kicker enabling
/// "choose any number instead").
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct ConditionalModeRange {
    pub required_optional_cost: crate::cost_model::OptionalCostRef,
    pub min_modes: Value,
    pub max_modes: Value,
}

impl ConditionalModeRange {
    pub fn new(
        required_optional_cost: impl Into<crate::cost_model::OptionalCostRef>,
        min_modes: impl Into<Value>,
        max_modes: impl Into<Value>,
    ) -> Self {
        Self {
            required_optional_cost: required_optional_cost.into(),
            min_modes: min_modes.into(),
            max_modes: max_modes.into(),
        }
    }
}

impl<E> EffectMode<E> {
    pub fn new(source_text: impl Into<String>, effects: Vec<E>) -> Self {
        Self {
            source_text: source_text.into(),
            effects,
        }
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct ChooseModeEffect<E> {
    /// Authored modal choice (CR 700.2), excluding implementation choices such as fabricate.
    #[cfg_attr(feature = "serde", serde(default))]
    pub faces_dilemma: bool,
    /// UI labels for inline alternatives. These do not turn an "A or B"
    /// instruction into authored modal text or affect its executable branches.
    #[cfg_attr(feature = "serde", serde(default, skip_serializing_if = "Vec::is_empty"))]
    pub decision_labels: Vec<String>,
    pub modes: Vec<EffectMode<E>>,
    /// Typed effects authored once in the modal header after the choice
    /// instruction. They resolve exactly once after modes are chosen and
    /// before any selected mode resolves.
    pub common_prefix_effects: Vec<E>,
    /// When present, this player makes the mode choice during resolution.
    /// Ordinary modal spells leave this unset and use their controller's
    /// casting-time mode selection.
    pub chooser: Option<PlayerFilter>,
    pub min: Value,
    pub max: Value,
    pub allow_repeat: bool,
    pub random: bool,
    pub choose_count: Value,
    pub min_choose_count: Value,
    pub allow_repeated_modes: bool,
    pub mode_point_costs: Vec<u32>,
    /// Whether the selected mode labels are mandatory additional costs paid
    /// during the spell-casting transaction (for example, Spree or Tiered).
    pub spree: bool,
    /// Whether this costed modal uses the Tiered “choose exactly one” surface.
    pub tiered: bool,
    /// Costed mode choice defined by prose, without Spree or Tiered identity.
    #[cfg_attr(feature = "serde", serde(default))]
    pub descriptive_mode_costs: bool,
    /// Additional mana cost associated with each mode. Ordinary modal effects
    /// leave this empty.
    pub mode_additional_mana_costs: Vec<ManaCost>,
    /// Number of trailing effects in every mode that were authored once as a
    /// shared sentence in the modal header. The effects remain inside each
    /// mode for target-scoped execution; this records only their common
    /// presentation boundary.
    pub common_suffix_effect_count: usize,
    pub disallow_previously_chosen_modes: bool,
    pub disallow_previously_chosen_modes_this_turn: bool,
    /// Each chosen mode must declare a player target different from every other chosen mode.
    pub distinct_player_targets_per_mode: bool,
    /// Alternate mode range that becomes legal if a later optional cost is announced.
    pub conditional_mode_range: Option<ConditionalModeRange>,
    /// Authored ability-word label for a modal spell. Triggered modal labels
    /// live on the enclosing triggered ability instead.
    pub presentation_label: Option<crate::ability_model::PresentationLabel>,
    /// This is a counters-else-token keyword action, endure (CR 701.63a) or
    /// fabricate (CR 702.123a): the first mode puts +1/+1 counters on the
    /// permanent, the second creates the token(s). If the permanent can't get
    /// counters (it left the battlefield or can't have counters put on it),
    /// the token mode is used.
    #[cfg_attr(feature = "serde", serde(default))]
    pub endure: bool,
    /// The players one of whom chooses the modes while the spell is cast
    /// ("An opponent chooses one —", CR 700.2, 601.2b). The caster picks which
    /// one when several are eligible; that player is the spell's chosen
    /// player, so its modes' "that player" names them.
    #[cfg_attr(feature = "serde", serde(default, skip_serializing_if = "Option::is_none"))]
    pub cast_chooser: Option<PlayerFilter>,
    /// "You may choose two" (CR 700.2): choosing no modes at all is also
    /// legal, in addition to the `min_choose_count..=choose_count` range.
    /// Choosing none removes a modal triggered ability (CR 603.3c).
    #[cfg_attr(feature = "serde", serde(default, skip_serializing_if = "std::ops::Not::not"))]
    pub optional_choice: bool,
    /// "{2}, {T}, Choose flying, first strike, trample, or shadow: ... the
    /// chosen ability ..." (Phyrexian Splicer): the modes are one instruction
    /// read once per keyword chosen while the ability is activated; these
    /// are the authored keywords, in mode order. Presentation only.
    #[cfg_attr(feature = "serde", serde(default, skip_serializing_if = "Vec::is_empty"))]
    pub cost_choice_keywords: Vec<String>,
    /// Casting choices owned by this modal instruction, including spliced text.
    #[cfg_attr(feature = "serde", serde(default, skip_serializing_if = "Option::is_none"))]
    pub announced_modes: Option<Vec<usize>>,
}

impl<E> ChooseModeEffect<E> {
    pub fn new(modes: Vec<EffectMode<E>>, min: Value, max: Value, allow_repeat: bool) -> Self {
        let choose_count = max.clone();
        let min_choose_count = min.clone();
        let mode_point_costs = vec![1; modes.len()];
        Self {
            faces_dilemma: false,
            decision_labels: Vec::new(),
            modes,
            common_prefix_effects: Vec::new(),
            chooser: None,
            min,
            max,
            allow_repeat,
            random: false,
            choose_count,
            min_choose_count,
            allow_repeated_modes: allow_repeat,
            mode_point_costs,
            spree: false,
            tiered: false,
            descriptive_mode_costs: false,
            mode_additional_mana_costs: Vec::new(),
            common_suffix_effect_count: 0,
            disallow_previously_chosen_modes: false,
            disallow_previously_chosen_modes_this_turn: false,
            distinct_player_targets_per_mode: false,
            conditional_mode_range: None,
            presentation_label: None,
            endure: false,
            cast_chooser: None,
            optional_choice: false,
            cost_choice_keywords: Vec::new(),
            announced_modes: None,
        }
    }

    pub fn decision_label(&self, index: usize) -> &str {
        self.decision_labels
            .get(index)
            .filter(|label| !label.trim().is_empty())
            .map(String::as_str)
            .unwrap_or_else(|| self.modes[index].source_text.as_str())
    }

    /// The modes are one instruction read per keyword chosen as a cost.
    pub fn with_cost_choice_keywords(mut self, keywords: Vec<String>) -> Self {
        self.cost_choice_keywords = keywords;
        self
    }

    /// "You may choose N": choosing no modes is also legal.
    pub fn with_optional_choice(mut self) -> Self {
        self.optional_choice = true;
        self
    }

    /// One of these players chooses the modes as the spell is cast.
    pub fn with_cast_chooser(mut self, chooser: PlayerFilter) -> Self {
        self.cast_chooser = Some(chooser);
        self
    }

    /// Mark this two-mode choice as the endure keyword action (CR 701.63a).
    pub fn as_endure(mut self) -> Self {
        self.endure = true;
        self
    }

    pub fn choose_one(modes: Vec<EffectMode<E>>) -> Self {
        Self::new(modes, Value::Fixed(1), Value::Fixed(1), false)
    }

    pub fn with_chooser(mut self, chooser: PlayerFilter) -> Self {
        self.chooser = Some(chooser);
        self
    }

    pub fn choose_exactly(count: impl Into<Value>, modes: Vec<EffectMode<E>>) -> Self {
        let count = count.into();
        Self::new(modes, count.clone(), count, false)
    }

    pub fn choose_up_to(
        max: impl Into<Value>,
        min: impl Into<Value>,
        modes: Vec<EffectMode<E>>,
    ) -> Self {
        Self::new(modes, min.into(), max.into(), false)
    }

    pub fn with_repeated_modes(mut self) -> Self {
        self.allow_repeat = true;
        self.allow_repeated_modes = true;
        self
    }

    pub fn with_random_mode_choice(mut self) -> Self {
        self.random = true;
        self
    }

    pub fn with_mode_point_costs(mut self, costs: Vec<u32>) -> Self {
        self.mode_point_costs = costs;
        self
    }

    /// A modal instruction whose selected modes have resolving payment costs,
    /// rather than additional costs of casting the enclosing spell.
    pub fn with_resolution_mana_costs(mut self, costs: Vec<ManaCost>) -> Self {
        self.spree = false;
        self.tiered = false;
        self.descriptive_mode_costs = true;
        self.mode_additional_mana_costs = costs;
        self
    }

    pub fn has_resolution_mana_costs(&self) -> bool {
        self.descriptive_mode_costs && !self.spree && !self.tiered
            && !self.mode_additional_mana_costs.is_empty()
    }

    pub fn with_spree_mana_costs(mut self, costs: Vec<ManaCost>) -> Self {
        self.spree = true;
        self.mode_additional_mana_costs = costs;
        self
    }

    pub fn with_tiered_mana_costs(mut self, costs: Vec<ManaCost>) -> Self {
        self.spree = true;
        self.tiered = true;
        self.min = Value::Fixed(1);
        self.max = Value::Fixed(1);
        self.min_choose_count = Value::Fixed(1);
        self.choose_count = Value::Fixed(1);
        self.allow_repeat = false;
        self.allow_repeated_modes = false;
        self.mode_additional_mana_costs = costs;
        self
    }

    pub fn with_common_suffix_effect_count(mut self, effect_count: usize) -> Self {
        self.common_suffix_effect_count = effect_count;
        self
    }

    pub fn with_common_prefix_effects(mut self, effects: Vec<E>) -> Self {
        self.common_prefix_effects = effects;
        self
    }

    pub fn with_previously_unchosen_modes_only(mut self) -> Self {
        self.disallow_previously_chosen_modes = true;
        self
    }

    pub fn with_previously_unchosen_modes_only_this_turn(mut self) -> Self {
        self.disallow_previously_chosen_modes = true;
        self.disallow_previously_chosen_modes_this_turn = true;
        self
    }

    pub fn with_distinct_player_targets_per_mode(mut self) -> Self {
        self.distinct_player_targets_per_mode = true;
        self
    }

    pub fn with_conditional_mode_range(mut self, range: ConditionalModeRange) -> Self {
        self.conditional_mode_range = Some(range);
        self
    }

    pub fn with_presentation_label(
        mut self,
        label: crate::ability_model::PresentationLabel,
    ) -> Self {
        self.presentation_label = Some(label);
        self
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct VillainousChoiceEffect<E> {
    pub player: PlayerFilter,
    pub player_surface: Option<String>,
    pub modes: Vec<EffectMode<E>>,
}

impl<E> VillainousChoiceEffect<E> {
    pub fn new(player: PlayerFilter, modes: Vec<EffectMode<E>>) -> Self {
        Self {
            player,
            player_surface: None,
            modes,
        }
    }

    pub fn with_player_surface(mut self, surface: impl Into<String>) -> Self {
        self.player_surface = Some(surface.into());
        self
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct HauntExileEffect<E> {
    pub haunt_effects: Vec<E>,
    pub haunt_choices: Vec<ChooseSpec>,
    #[cfg_attr(feature = "serde", serde(default))]
    pub descriptive: bool,
}

impl<E> HauntExileEffect<E> {
    pub fn new(haunt_effects: Vec<E>, haunt_choices: Vec<ChooseSpec>) -> Self {
        Self {
            haunt_effects,
            descriptive: false,
            haunt_choices,
        }
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct SearchLibrarySlot {
    pub filter: ObjectFilter,
    pub optional: bool,
}

/// Oracle-facing wording used to refer back to cards found by a library
/// search. This is presentation-only metadata; the searched objects are still
/// identified by the effect's typed tag.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default, TagKeyWalk)]
pub enum SearchResultReferenceSurface {
    #[default]
    ThatCard,
    TheCard,
    It,
    ThoseCards,
    Them,
}

impl SearchResultReferenceSurface {
    pub const fn as_str(self) -> &'static str {
        match self {
            Self::ThatCard => "that card",
            Self::TheCard => "the card",
            Self::It => "it",
            Self::ThoseCards => "those cards",
            Self::Them => "them",
        }
    }
}

impl SearchLibrarySlot {
    pub fn required(filter: ObjectFilter) -> Self {
        Self {
            filter,
            optional: false,
        }
    }

    pub fn optional(filter: ObjectFilter) -> Self {
        Self {
            filter,
            optional: true,
        }
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct SearchLibraryEffect {
    #[cfg_attr(feature = "serde", serde(default))]
    pub participant_tag: Option<crate::tag::TagKey>,
    pub filter: ObjectFilter,
    pub destination: crate::zone::Zone,
    pub chooser: PlayerFilter,
    pub player: PlayerFilter,
    pub reveal: bool,
    pub search_mode: SearchSelectionMode,
    pub library_position_from_top: Option<Value>,
    pub result_reference_surface: SearchResultReferenceSurface,
    /// "put it into your hand or graveyard" (Dina's Guidance): after the
    /// found card is revealed, the searching player chooses this zone or
    /// `destination` for it.
    #[cfg_attr(feature = "serde", serde(default, skip_serializing_if = "Option::is_none"))]
    pub alternative_destination: Option<crate::zone::Zone>,
}

impl SearchLibraryEffect {
    pub fn new(
        filter: ObjectFilter,
        destination: crate::zone::Zone,
        chooser: PlayerFilter,
        player: PlayerFilter,
        reveal: bool,
    ) -> Self {
        Self {
            participant_tag: None,
            filter,
            destination,
            chooser,
            player,
            reveal,
            search_mode: SearchSelectionMode::Exact,
            library_position_from_top: None,
            result_reference_surface: SearchResultReferenceSurface::ThatCard,
            alternative_destination: None,
        }
    }

    pub fn with_alternative_destination(mut self, zone: crate::zone::Zone) -> Self {
        self.alternative_destination = Some(zone);
        self
    }

    pub fn with_search_mode(mut self, search_mode: SearchSelectionMode) -> Self {
        self.search_mode = search_mode;
        self
    }

    pub fn with_library_position_from_top(mut self, position: Value) -> Self {
        self.library_position_from_top = Some(position);
        self
    }

    pub fn with_result_reference_surface(mut self, surface: SearchResultReferenceSurface) -> Self {
        self.result_reference_surface = surface;
        self
    }

    pub fn to_hand(filter: ObjectFilter, player: PlayerFilter, reveal: bool) -> Self {
        Self::new(
            filter,
            crate::zone::Zone::Hand,
            player.clone(),
            player,
            reveal,
        )
    }

    pub fn to_battlefield(filter: ObjectFilter, player: PlayerFilter, reveal: bool) -> Self {
        Self::new(
            filter,
            crate::zone::Zone::Battlefield,
            player.clone(),
            player,
            reveal,
        )
    }

    pub fn to_library_top(filter: ObjectFilter, player: PlayerFilter, reveal: bool) -> Self {
        Self::new(
            filter,
            crate::zone::Zone::Library,
            player.clone(),
            player,
            reveal,
        )
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct SearchLibrarySlotsEffect {
    pub slots: Vec<SearchLibrarySlot>,
    pub destination: crate::zone::Zone,
    pub chooser: PlayerFilter,
    pub player: PlayerFilter,
    pub reveal: bool,
    pub progress_tag: crate::tag::TagKey,
    /// Found cards put onto the battlefield enter tapped.
    #[cfg_attr(feature = "serde", serde(default, skip_serializing_if = "std::ops::Not::not"))]
    pub tapped: bool,
}

impl SearchLibrarySlotsEffect {
    pub fn new(
        slots: Vec<SearchLibrarySlot>,
        destination: crate::zone::Zone,
        chooser: PlayerFilter,
        player: PlayerFilter,
        reveal: bool,
        progress_tag: impl Into<crate::tag::TagKey>,
    ) -> Self {
        Self {
            slots,
            destination,
            chooser,
            player,
            reveal,
            progress_tag: progress_tag.into(),
            tapped: false,
        }
    }

    pub fn tapped(mut self, tapped: bool) -> Self {
        self.tapped = tapped;
        self
    }

    pub fn to_hand(
        slots: Vec<SearchLibrarySlot>,
        player: PlayerFilter,
        reveal: bool,
        progress_tag: impl Into<crate::tag::TagKey>,
    ) -> Self {
        Self::new(
            slots,
            crate::zone::Zone::Hand,
            player.clone(),
            player,
            reveal,
            progress_tag,
        )
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct LookAtHandEffect {
    pub target: ChooseSpec,
    pub reveal: bool,
}

impl LookAtHandEffect {
    pub fn new(target: ChooseSpec) -> Self {
        Self {
            target,
            reveal: false,
        }
    }

    pub fn reveal(target: ChooseSpec) -> Self {
        Self {
            target,
            reveal: true,
        }
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct LookAtObjectsEffect {
    pub filter: ObjectFilter,
    pub viewer: PlayerFilter,
    pub subject: PlayerFilter,
    /// Create a durable private entitlement without requiring an immediate look.
    #[cfg_attr(
        feature = "serde",
        serde(default, skip_serializing_if = "immediate_object_inspection")
    )]
    pub permit_while_exiled: bool,
}

#[cfg(feature = "serde")]
fn immediate_object_inspection(permit: &bool) -> bool {
    !*permit
}

impl LookAtObjectsEffect {
    pub fn new(filter: ObjectFilter, viewer: PlayerFilter, subject: PlayerFilter) -> Self {
        Self {
            filter,
            viewer,
            subject,
            permit_while_exiled: false,
        }
    }

    pub fn permit_while_exiled(mut self) -> Self {
        self.permit_while_exiled = true;
        self
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, Eq, TagKeyWalk)]
pub struct RevealTaggedEffect {
    pub tag: crate::tag::TagKey,
}

impl RevealTaggedEffect {
    pub fn new(tag: impl Into<crate::tag::TagKey>) -> Self {
        Self { tag: tag.into() }
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default, TagKeyWalk)]
pub enum RevealSourceFromHandDuration {
    #[default]
    Momentary,
    UntilUpkeepEndsOrLeavesHand,
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, Eq, Default, TagKeyWalk)]
pub struct RevealSourceFromHandEffect {
    pub duration: RevealSourceFromHandDuration,
    /// Captured activation-local permission; None means the actual hand.
    /// This is attached only to the announced cost, never to resolution effects.
    #[cfg_attr(feature = "serde", serde(default, skip_serializing_if = "Option::is_none"))]
    pub activation_source_zone: Option<Zone>,
}

impl RevealSourceFromHandEffect {
    pub fn new() -> Self {
        Self {
            duration: RevealSourceFromHandDuration::Momentary,
            activation_source_zone: None,
        }
    }

    pub fn until_upkeep_ends_or_leaves_hand() -> Self {
        Self {
            duration: RevealSourceFromHandDuration::UntilUpkeepEndsOrLeavesHand,
            activation_source_zone: None,
        }
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct RevealFromHandEffect {
    pub count: Value,
    pub card_type: Option<CardType>,
    pub color_filter: Option<ColorSet>,
}

impl RevealFromHandEffect {
    pub fn new(count: impl Into<Value>, card_type: Option<CardType>) -> Self {
        Self::with_color_filter(count, card_type, None)
    }

    pub fn with_color_filter(
        count: impl Into<Value>,
        card_type: Option<CardType>,
        color_filter: Option<ColorSet>,
    ) -> Self {
        Self {
            count: count.into(),
            card_type,
            color_filter,
        }
    }

    fn count_display(&self) -> String {
        match self.count {
            Value::Fixed(1) => "a".to_string(),
            Value::Fixed(count) => count.to_string(),
            Value::X => "X".to_string(),
            _ => format!("{:?}", self.count),
        }
    }

    fn color_display(&self) -> Option<&'static str> {
        let colors = self.color_filter?;
        if colors.count() != 1 {
            return None;
        }
        Color::ALL
            .iter()
            .find(|&&color| colors.contains(color))
            .map(|&color| color.name())
    }

    pub fn cost_display(&self) -> String {
        // "Reveal your hand" (Sasaya): every card in the payer's hand.
        if self.card_type.is_none()
            && self.color_filter.is_none()
            && matches!(self.count, Value::CardsInHand(PlayerFilter::You))
        {
            return "Reveal your hand".to_string();
        }
        let mut card_desc = String::new();
        if let Some(color) = self.color_display() {
            card_desc.push_str(color);
            card_desc.push(' ');
        }
        card_desc.push_str(self.card_type.map_or("card", |ct| ct.card_phrase()));

        if self.count == Value::Fixed(1) {
            format!("Reveal a {card_desc} from your hand")
        } else {
            format!(
                "Reveal {} {card_desc}s from your hand",
                self.count_display()
            )
        }
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct ChooseSpellCastHistoryEffect {
    pub chooser: PlayerFilter,
    pub cast_by: PlayerFilter,
    pub filter: ObjectFilter,
    pub tag: crate::tag::TagKey,
    pub description: String,
}

impl ChooseSpellCastHistoryEffect {
    pub fn new(
        chooser: PlayerFilter,
        cast_by: PlayerFilter,
        filter: ObjectFilter,
        tag: impl Into<crate::tag::TagKey>,
    ) -> Self {
        Self {
            chooser,
            cast_by,
            filter,
            tag: tag.into(),
            description: "Choose one of those spells".to_string(),
        }
    }

    pub fn with_description(mut self, description: impl Into<String>) -> Self {
        self.description = description.into();
        self
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct ScryEffect {
    pub count: Value,
    pub player: PlayerFilter,
}

impl ScryEffect {
    pub fn new(count: impl Into<Value>, player: PlayerFilter) -> Self {
        Self {
            count: count.into(),
            player,
        }
    }

    pub fn you(count: impl Into<Value>) -> Self {
        Self::new(count, PlayerFilter::You)
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct SurveilEffect {
    pub count: Value,
    pub player: PlayerFilter,
}

impl SurveilEffect {
    pub fn new(count: impl Into<Value>, player: PlayerFilter) -> Self {
        Self {
            count: count.into(),
            player,
        }
    }

    pub fn you(count: impl Into<Value>) -> Self {
        Self::new(count, PlayerFilter::You)
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct FatesealEffect {
    pub count: Value,
    pub player: PlayerFilter,
}

impl FatesealEffect {
    pub fn new(count: impl Into<Value>, player: PlayerFilter) -> Self {
        Self {
            count: count.into(),
            player,
        }
    }

    pub fn you(count: impl Into<Value>) -> Self {
        Self::new(count, PlayerFilter::You)
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct EachPlayerScryEffect {
    pub count: Value,
    pub player_filter: PlayerFilter,
}

impl EachPlayerScryEffect {
    pub fn new(count: impl Into<Value>, player_filter: PlayerFilter) -> Self {
        Self {
            count: count.into(),
            player_filter,
        }
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct CrewCostEffect {
    pub required_power: u32,
    /// Teamwork shares the selection, but never crew substitutions or events.
    #[cfg_attr(feature = "serde", serde(default))]
    pub teamwork: bool,
}

impl CrewCostEffect {
    pub fn new(required_power: u32) -> Self {
        Self {
            required_power,
            teamwork: false,
        }
    }

    pub fn teamwork(required_power: u32) -> Self {
        Self {
            required_power,
            teamwork: true,
        }
    }
}

/// Saddle N's cost (CR 702.171a): "Tap any number of other untapped
/// creatures you control with total power N or greater".
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct SaddleCostEffect {
    pub required_power: u32,
}

impl SaddleCostEffect {
    pub fn new(required_power: u32) -> Self {
        Self { required_power }
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, Default, TagKeyWalk)]
pub struct BecomeSaddledUntilEotEffect;

impl BecomeSaddledUntilEotEffect {
    pub fn new() -> Self {
        Self
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct MillEffect {
    pub count: Value,
    pub player: PlayerFilter,
}

impl MillEffect {
    pub fn new(count: impl Into<Value>, player: PlayerFilter) -> Self {
        Self {
            count: count.into(),
            player,
        }
    }

    pub fn you(count: impl Into<Value>) -> Self {
        Self::new(count, PlayerFilter::You)
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct ShuffleGraveyardIntoLibraryEffect {
    pub player: PlayerFilter,
    /// Preserve the longer authored "all cards from ... graveyard" surface.
    pub explicit_all_cards_from: bool,
}

impl ShuffleGraveyardIntoLibraryEffect {
    pub fn new(player: PlayerFilter) -> Self {
        Self {
            player,
            explicit_all_cards_from: false,
        }
    }

    pub fn with_all_cards_from_surface(player: PlayerFilter) -> Self {
        Self {
            player,
            explicit_all_cards_from: true,
        }
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct ShuffleHandAndGraveyardIntoLibraryEffect {
    pub player: PlayerFilter,
    /// Also move every battlefield permanent owned by that player.
    pub include_owned_permanents: bool,
}

impl ShuffleHandAndGraveyardIntoLibraryEffect {
    pub fn new(player: PlayerFilter) -> Self {
        Self {
            player,
            include_owned_permanents: false,
        }
    }

    pub fn including_owned_permanents(player: PlayerFilter) -> Self {
        Self {
            player,
            include_owned_permanents: true,
        }
    }
}

/// Oracle-facing cardinality for a zone move of cards linked to the source
/// that exiled them. The runtime selection remains a `ChooseSpec`; this only
/// preserves distinctions that an aggregate selection cannot recover.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, Eq, TagKeyWalk)]
pub enum ExiledWithSourceSubjectSurface {
    AllCards,
    EachCard,
    /// "The owner of each card exiled with this source puts that card on the
    /// bottom of their library."
    OwnerOfEachCard,
    OneCard,
    TheExiledCard,
    TheExiledCards,
    TheCards,
    /// A typed or qualified card noun whose semantic filter is already
    /// carried by the zone-move target (for example, "target creature card
    /// with mana value X" or "each creature card").
    Custom(String),
}

/// Oracle-facing reference to the object that exiled the moved cards.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, Eq, TagKeyWalk)]
pub enum ExiledWithSourceReferenceSurface {
    Source(SourceReferenceSurface),
    It,
    Omitted,
}

/// Oracle-facing agreement for an owner-relative zone destination.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, Copy, PartialEq, Eq, TagKeyWalk)]
pub enum ExiledWithSourceDestinationSurface {
    ContextualPlayer,
    ItsOwner,
    TheirOwner,
    TheirOwners,
}

/// Oracle-facing verb used for a zone move of cards linked to the source.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, Copy, PartialEq, Eq, TagKeyWalk)]
pub enum ExiledWithSourceMoveVerbSurface {
    Put,
    Return,
}

/// Presentation metadata for a `put ... exiled with ... into ...` clause.
/// Object identity, source linkage, and the destination zone continue to live
/// in the ordinary filter and zone-move fields.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, Eq, TagKeyWalk)]
pub struct ExiledWithSourceMoveSurface {
    pub verb: ExiledWithSourceMoveVerbSurface,
    pub subject: ExiledWithSourceSubjectSurface,
    pub source: ExiledWithSourceReferenceSurface,
    pub destination: ExiledWithSourceDestinationSurface,
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct ReturnToHandEffect {
    pub spec: ChooseSpec,
    /// Player explicitly presented as performing the return action. Runtime
    /// movement remains object-based; this preserves causative clauses such
    /// as "you may have that player return ...".
    pub actor_surface: Option<PlayerFilter>,
    /// Contextual player named by the oracle destination (for example,
    /// "your hand" or "their hand"). The zone change itself still follows
    /// the rules and moves the object to its owner's hand.
    pub destination_player_surface: Option<PlayerFilter>,
    pub exiled_with_source_surface: Option<ExiledWithSourceMoveSurface>,
    /// Oracle-facing set agreement for references whose rules target has
    /// already been lowered to a tag (for example, "return those creatures").
    pub set_quantifier_surface: Option<SetQuantifierSurface>,
    /// The corresponding oracle noun phrase when a tag no longer carries it.
    /// This is presentation metadata only; `spec` remains authoritative.
    pub set_reference_surface: Option<String>,
}

impl ReturnToHandEffect {
    pub fn with_spec(spec: ChooseSpec) -> Self {
        Self {
            spec,
            actor_surface: None,
            destination_player_surface: None,
            exiled_with_source_surface: None,
            set_quantifier_surface: None,
            set_reference_surface: None,
        }
    }

    pub fn target(spec: ChooseSpec) -> Self {
        Self {
            spec: ChooseSpec::target(spec),
            actor_surface: None,
            destination_player_surface: None,
            exiled_with_source_surface: None,
            set_quantifier_surface: None,
            set_reference_surface: None,
        }
    }

    pub fn targets(spec: ChooseSpec, count: ChoiceCount) -> Self {
        Self {
            spec: ChooseSpec::target(spec).with_count(count),
            actor_surface: None,
            destination_player_surface: None,
            exiled_with_source_surface: None,
            set_quantifier_surface: None,
            set_reference_surface: None,
        }
    }

    pub fn all(filter: ObjectFilter) -> Self {
        Self {
            spec: ChooseSpec::all(filter),
            actor_surface: None,
            destination_player_surface: None,
            exiled_with_source_surface: None,
            set_quantifier_surface: None,
            set_reference_surface: None,
        }
    }

    pub fn with_actor_surface(mut self, player: PlayerFilter) -> Self {
        self.actor_surface = Some(player);
        self
    }

    pub fn with_destination_player_surface(mut self, player: PlayerFilter) -> Self {
        self.destination_player_surface = Some(player);
        self
    }

    pub fn with_exiled_with_source_surface(mut self, surface: ExiledWithSourceMoveSurface) -> Self {
        self.exiled_with_source_surface = Some(surface);
        self
    }

    pub fn with_set_quantifier_surface(mut self, surface: Option<SetQuantifierSurface>) -> Self {
        self.set_quantifier_surface = surface;
        self
    }

    pub fn with_set_reference_surface(mut self, surface: Option<String>) -> Self {
        self.set_reference_surface = surface;
        self
    }

    pub fn creature() -> Self {
        Self::target(ChooseSpec::creature())
    }

    pub fn permanent() -> Self {
        Self::target(ChooseSpec::permanent())
    }

    pub fn creatures() -> Self {
        Self::all(ObjectFilter::creature())
    }

    pub fn nonland_permanents() -> Self {
        Self::all(ObjectFilter::nonland_permanent())
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct MoveToLibraryNthFromTopEffect {
    pub target: ChooseSpec,
    pub position: Value,
}

impl MoveToLibraryNthFromTopEffect {
    pub fn new(target: ChooseSpec, position: Value) -> Self {
        Self { target, position }
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct MoveToLibraryTopOrBottomChoiceEffect {
    pub target: ChooseSpec,
    /// `None` means each object's owner chooses, matching the common surface.
    pub chooser: Option<PlayerFilter>,
    /// Where the "top" option puts the object, counted from the top starting
    /// at 0 ("second from the top or on the bottom" is 1).
    #[cfg_attr(feature = "serde", serde(default))]
    pub top_position: u32,
}

impl MoveToLibraryTopOrBottomChoiceEffect {
    pub fn new(target: ChooseSpec) -> Self {
        Self {
            target,
            chooser: None,
            top_position: 0,
        }
    }

    pub fn with_top_position(mut self, top_position: u32) -> Self {
        self.top_position = top_position;
        self
    }

    pub fn with_chooser(mut self, chooser: PlayerFilter) -> Self {
        self.chooser = Some(chooser);
        self
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct ExchangeControlEffect {
    pub permanent1: ChooseSpec,
    pub permanent2: ChooseSpec,
    pub shared_type: Option<SharedTypeConstraint>,
    pub permanent1_reference_tag: Option<crate::tag::TagKey>,
}

impl ExchangeControlEffect {
    pub fn new(permanent1: ChooseSpec, permanent2: ChooseSpec) -> Self {
        Self {
            permanent1,
            permanent2,
            shared_type: None,
            permanent1_reference_tag: None,
        }
    }

    pub fn with_shared_type(mut self, constraint: SharedTypeConstraint) -> Self {
        self.shared_type = Some(constraint);
        self
    }

    pub fn with_permanent1_reference_tag(mut self, tag: impl Into<crate::tag::TagKey>) -> Self {
        self.permanent1_reference_tag = Some(tag.into());
        self
    }

    pub fn creatures() -> Self {
        Self::new(ChooseSpec::creature(), ChooseSpec::creature())
    }

    pub fn permanents() -> Self {
        Self::new(ChooseSpec::permanent(), ChooseSpec::permanent())
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct DirectionalAdjacentPlayerControlEffect {
    pub filter: ObjectFilter,
    pub left_option: String,
    pub right_option: String,
    /// "Each player gains control of all <filter> controlled by the next
    /// player in the chosen direction": every matching object moves at once
    /// instead of one object chosen by each player.
    #[cfg_attr(feature = "serde", serde(default))]
    pub all_matching: bool,
    /// "controlled by the player to their right" (Inniaz, the Gale Force):
    /// the direction is fixed by the text rather than read from a prior
    /// left/right choice.
    #[cfg_attr(feature = "serde", serde(default))]
    pub fixed_direction: Option<SeatingDirection>,
    /// "a nonland permanent of your choice": the effect's controller makes
    /// every player's choice instead of each player choosing their own.
    #[cfg_attr(feature = "serde", serde(default))]
    pub controller_chooses: bool,
}

/// A seating direction around the table (CR 101.4a).
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, Copy, PartialEq, Eq, TagKeyWalk)]
pub enum SeatingDirection {
    Left,
    Right,
}

impl DirectionalAdjacentPlayerControlEffect {
    pub fn new(
        filter: ObjectFilter,
        left_option: impl Into<String>,
        right_option: impl Into<String>,
    ) -> Self {
        Self {
            filter,
            left_option: left_option.into(),
            right_option: right_option.into(),
            all_matching: false,
            fixed_direction: None,
            controller_chooses: false,
        }
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, Copy, PartialEq, Eq, TagKeyWalk)]
pub enum BattlefieldController {
    Preserve,
    Owner,
    You,
}

/// Oracle wording used for a possessive player reference on a zone
/// destination. This is presentation-only; the associated player filter
/// remains the semantic destination antecedent.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, Copy, PartialEq, Eq, TagKeyWalk)]
pub enum DestinationPlayerReferenceSurface {
    Pronoun,
    ThatPlayer,
}

/// Oracle verb retained for a generic zone move.
///
/// `Canonical` lets compiled text choose the usual wording from the source and
/// destination zones. Parser-produced moves use `Put` or `Return` so a tagged
/// object does not silently change an oracle `put` into `return` (or vice
/// versa). This is presentation-only; zone-change execution is unchanged.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, Copy, PartialEq, Eq, TagKeyWalk)]
pub enum MoveToZoneVerbSurface {
    Canonical,
    Put,
    Return,
}

/// Oracle presentation retained for counters that are part of a one-shot
/// battlefield-entry event.
///
/// Every variant has the same executable meaning: the counters are supplied
/// to ETB replacement processing before the object changes zones. The surface
/// only records how the originating sentence related the entry condition to
/// the move.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, Copy, PartialEq, Eq, TagKeyWalk)]
pub enum BattlefieldEntryCounterSurface {
    /// "It enters with ..."
    Inline,
    /// "Each of them enters with ..."
    EachOfThemEnters,
    /// "If a creature enters this way, it enters with ..."
    IfObjectEntersThisWay,
    /// "If it enters as a creature, it enters with ..."
    IfItEntersAsObject,
    /// "It enters with ... if it's a creature."
    ItEntersIfObject,
    /// "If <condition>, that creature enters with ..."
    ThatObjectEntersIfCondition,
}

/// Counters supplied as part of a one-shot move onto the battlefield.
///
/// This is distinct from [`PutCountersEffect`]: these counters exist on the
/// enter event itself, so replacement effects such as Doubling Season see and
/// modify them at the correct time.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct BattlefieldEntryCounterSpec {
    pub counter_type: crate::counter::CounterType,
    pub amount: Value,
    /// A resolution-time gate known before the zone change (for example,
    /// whether green mana was spent to cast the resolving spell).
    pub condition: Option<crate::value_model::Condition>,
    /// Characteristics the entering object must have for this counter grant.
    pub object_filter: Option<ObjectFilter>,
    pub surface: BattlefieldEntryCounterSurface,
}

impl BattlefieldEntryCounterSpec {
    pub fn new(
        counter_type: crate::counter::CounterType,
        amount: impl Into<Value>,
        surface: BattlefieldEntryCounterSurface,
    ) -> Self {
        Self {
            counter_type,
            amount: amount.into(),
            condition: None,
            object_filter: None,
            surface,
        }
    }

    pub fn with_condition(mut self, condition: crate::value_model::Condition) -> Self {
        self.condition = Some(condition);
        self
    }

    pub fn for_matching_object(mut self, filter: ObjectFilter) -> Self {
        self.object_filter = Some(filter);
        self
    }
}

/// How a multi-card move to the top or bottom of a library is ordered.
///
/// The choosing player is explicit because the player performing the
/// instruction is not necessarily the controller of the effect (for example,
/// "that player puts the cards ... in any order").
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub enum LibraryPlacementOrder {
    Random,
    ChosenBy(PlayerFilter),
    /// CR 401.4: each owner orders cards entering their own library.
    Owners,
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, Copy, PartialEq, TagKeyWalk)]
pub enum BattlefieldEntryColorChange {
    Add(crate::color::ColorSet),
    Set(crate::color::ColorSet),
}

/// Type changes that apply while a permanent enters, before other entry
/// replacements inspect its characteristics. They persist for that incarnation.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, Default, PartialEq, TagKeyWalk)]
pub struct BattlefieldEntryTypeChanges {
    /// Color clauses from the same descriptive entry instruction, in order.
    #[cfg_attr(feature = "serde", serde(default, skip_serializing_if = "Vec::is_empty"))]
    pub color_changes: Vec<BattlefieldEntryColorChange>,
    /// Descriptive replacement types owned by this arrival (CR 611.2e).
    #[cfg_attr(feature = "serde", serde(default, skip_serializing_if = "Option::is_none"))]
    pub set_card_types: Option<Vec<crate::types::CardType>>,
    pub added_card_types: Vec<crate::types::CardType>,
    pub removed_subtype_families: Vec<crate::types::SubtypeFamily>,
    pub added_subtypes: Vec<crate::types::Subtype>,
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
#[cfg_attr(feature = "serde", serde(bound(serialize = "M: serde::Serialize", deserialize = "M: serde::Deserialize<'de>")))]
pub struct MoveToZoneEffect<M = ()> {
    /// Remember exactly one actual arrival as the source's persistent choice.
    #[cfg_attr(feature = "serde", serde(default))]
    pub remember_as_chosen_object: bool,
    /// Continuous modifications owned by this battlefield arrival (CR 611.2e).
    #[cfg_attr(feature = "serde", serde(default, skip_serializing_if = "Vec::is_empty"))]
    pub entry_modifications: Vec<M>,
    /// Resolution references retained by the actual arriving permanent for
    /// its granted abilities. References are not inherited on later blinks.
    #[cfg_attr(feature = "serde", serde(default, skip_serializing_if = "Vec::is_empty"))]
    pub retained_reference_tags: Vec<TagKey>,
    pub target: ChooseSpec,
    pub zone: crate::zone::Zone,
    pub to_top: bool,
    pub library_order: Option<LibraryPlacementOrder>,
    pub verb_surface: MoveToZoneVerbSurface,
    /// Whether the source text refers to the moved tagged result as a set
    /// (for example, "those cards" or "the exiled cards"). Tagged specs can
    /// resolve more than one object, but do not otherwise retain that surface.
    pub target_plural_surface: bool,
    /// Authored singular reference to a structurally tagged moved object.
    /// This is presentation-only: `target` remains the executable identity.
    pub target_reference_surface: Option<SearchResultReferenceSurface>,
    /// Authored provenance for a tagged-set complement disposition. This is
    /// presentation-only; the enclosing tagged iteration remains the
    /// executable definition of which objects move.
    pub remainder_surface: Option<LibraryRemainderSurface>,
    /// Explicit player who performs the oracle instruction. The rules engine
    /// still moves the same objects to the same zones; this preserves
    /// surfaces such as "that player puts" and "each player puts", and names
    /// who makes a counted pick out of an earlier collection ("that player
    /// puts one of them on top").
    pub actor_surface: Option<PlayerFilter>,
    /// Explicit contextual player named by the oracle destination (for
    /// example, "your graveyard" or "that player's hand"). Nonbattlefield
    /// zone changes still follow the rules and use the object's owner; this is
    /// retained only so compiled text can preserve an equivalent surface.
    pub destination_player_surface: Option<PlayerFilter>,
    pub destination_player_reference_surface: Option<DestinationPlayerReferenceSurface>,
    pub exiled_with_source_surface: Option<ExiledWithSourceMoveSurface>,
    pub battlefield_controller: BattlefieldController,
    /// Whether the oracle text explicitly named the battlefield controller.
    /// This affects presentation only; `battlefield_controller` remains the
    /// executable controller choice.
    pub controller_surface_explicit: bool,
    /// Counters that are part of this object's battlefield-entry event.
    pub enters_with_counters: Vec<BattlefieldEntryCounterSpec>,
    pub enters_tapped: bool,
    pub enters_attacking: bool,
    pub attack_target_mode: Option<MoveToZoneAttackTargetMode>,
    pub enters_face_down: bool,
    /// Whether a transforming double-faced card enters with its back face up.
    /// This is part of the zone-change instruction, not a later transform action.
    pub enters_transformed: bool,
    pub transfer_exiled_with_source_links: bool,
    /// One authored move can send disjoint captured groups to different zones.
    /// Membership is bound before the native batch prepares any replacement.
    #[cfg_attr(
        feature = "serde",
        serde(default, skip_serializing_if = "Vec::is_empty")
    )]
    pub tagged_destinations: Vec<(crate::tag::TagKey, crate::zone::Zone)>,
    /// "put ... onto the battlefield blocking that creature" (Aetherplasm):
    /// the attacker the entering creature blocks (CR 509.4; it was never
    /// declared as a blocker). Appended with a serde default.
    #[cfg_attr(feature = "serde", serde(default, skip_serializing_if = "Option::is_none"))]
    pub enters_blocking: Option<ChooseSpec>,
    /// "return ... to the battlefield as a non-Aura enchantment"
    /// (Takklemaggot): the entering object loses the Aura subtype as part of
    /// this entry, so it doesn't choose something to enchant (CR 303.4f) and
    /// isn't an unattached Aura afterwards (CR 704.5m). Appended with a serde
    /// default.
    #[cfg_attr(feature = "serde", serde(default, skip_serializing_if = "std::ops::Not::not"))]
    pub enters_as_non_aura: bool,
    /// "If a land enters this way, it enters tapped" (Silver Surfer, Cosmic
    /// Voyager): each moved object matching this filter (as it exists just
    /// before the move) enters the battlefield tapped, within the same
    /// simultaneous move. Appended with a serde default.
    #[cfg_attr(feature = "serde", serde(default, skip_serializing_if = "Option::is_none"))]
    pub enters_tapped_if: Option<ObjectFilter>,
    /// "return that exiled card to the battlefield ... with the noted number
    /// and kind of counters on it" (Tawnos's Coffin): each moved object
    /// enters with the counters its snapshot under this tag recorded (a
    /// `NoteCountersEffect` capture). Appended with a serde default.
    #[cfg_attr(feature = "serde", serde(default, skip_serializing_if = "Option::is_none"))]
    pub enters_with_noted_counters: Option<TagKey>,
    #[cfg_attr(feature = "serde", serde(default, skip_serializing_if = "Option::is_none"))]
    pub entry_type_changes: Option<BattlefieldEntryTypeChanges>,
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub enum MoveToZoneAttackTargetMode {
    PlayerOrPlaneswalkerControlledBy(PlayerFilter),
    /// "tapped and attacking that opponent" (Kaalia of the Vast): the named
    /// player itself (CR 508.4). Appended to preserve serialized ordinals.
    Player(PlayerFilter),
}

impl<M> MoveToZoneEffect<M> {
    pub fn try_map_entry_modifications<N, E>(self, mut map: impl FnMut(M) -> Result<N, E>) -> Result<MoveToZoneEffect<N>, E> {
        Ok(MoveToZoneEffect {
            entry_modifications: self.entry_modifications.into_iter().map(&mut map).collect::<Result<Vec<_>, _>>()?,
            remember_as_chosen_object: self.remember_as_chosen_object,
            retained_reference_tags: self.retained_reference_tags,
            target: self.target,
            zone: self.zone,
            to_top: self.to_top,
            library_order: self.library_order,
            verb_surface: self.verb_surface,
            target_plural_surface: self.target_plural_surface,
            target_reference_surface: self.target_reference_surface,
            remainder_surface: self.remainder_surface,
            actor_surface: self.actor_surface,
            destination_player_surface: self.destination_player_surface,
            destination_player_reference_surface: self.destination_player_reference_surface,
            exiled_with_source_surface: self.exiled_with_source_surface,
            battlefield_controller: self.battlefield_controller,
            controller_surface_explicit: self.controller_surface_explicit,
            enters_with_counters: self.enters_with_counters,
            enters_tapped: self.enters_tapped,
            enters_attacking: self.enters_attacking,
            attack_target_mode: self.attack_target_mode,
            enters_face_down: self.enters_face_down,
            enters_transformed: self.enters_transformed,
            transfer_exiled_with_source_links: self.transfer_exiled_with_source_links,
            tagged_destinations: self.tagged_destinations,
            enters_blocking: self.enters_blocking,
            enters_as_non_aura: self.enters_as_non_aura,
            enters_tapped_if: self.enters_tapped_if,
            enters_with_noted_counters: self.enters_with_noted_counters,
            entry_type_changes: self.entry_type_changes,
        })
    }
    pub fn new(target: ChooseSpec, zone: crate::zone::Zone, to_top: bool) -> Self {
        Self {
            entry_modifications: Vec::new(),
            entry_type_changes: None,
            remember_as_chosen_object: false,
            retained_reference_tags: Vec::new(),
            target,
            zone,
            tagged_destinations: Vec::new(),
            to_top,
            library_order: None,
            verb_surface: MoveToZoneVerbSurface::Canonical,
            target_plural_surface: false,
            target_reference_surface: None,
            remainder_surface: None,
            actor_surface: None,
            destination_player_surface: None,
            destination_player_reference_surface: None,
            exiled_with_source_surface: None,
            battlefield_controller: BattlefieldController::Preserve,
            controller_surface_explicit: false,
            enters_with_counters: Vec::new(),
            enters_tapped: false,
            enters_attacking: false,
            attack_target_mode: None,
            enters_face_down: false,
            enters_transformed: false,
            transfer_exiled_with_source_links: false,
            enters_blocking: None,
            enters_as_non_aura: false,
            enters_tapped_if: None,
            enters_with_noted_counters: None,
        }
    }

    /// Each moved object enters with the counters noted under `tag`.
    pub fn with_noted_counters(mut self, tag: impl Into<TagKey>) -> Self {
        self.enters_with_noted_counters = Some(tag.into());
        self
    }

    /// The entering object loses the Aura subtype as it enters.
    pub fn as_non_aura(mut self) -> Self {
        self.enters_as_non_aura = true;
        self
    }

    /// The entering creature blocks the attacker `attacker` names.
    pub fn blocking(mut self, attacker: ChooseSpec) -> Self {
        self.enters_blocking = Some(attacker);
        self
    }

    pub fn to_top_of_library(target: ChooseSpec) -> Self {
        Self::new(target, crate::zone::Zone::Library, true)
    }

    pub fn to_bottom_of_library(target: ChooseSpec) -> Self {
        Self::new(target, crate::zone::Zone::Library, false)
    }

    pub fn to_exile(target: ChooseSpec) -> Self {
        Self::new(target, crate::zone::Zone::Exile, false)
    }

    pub fn with_library_order(mut self, order: LibraryPlacementOrder) -> Self {
        self.library_order = Some(order);
        self
    }

    pub fn with_verb_surface(mut self, surface: MoveToZoneVerbSurface) -> Self {
        self.verb_surface = surface;
        self
    }

    pub fn with_target_plural_surface(mut self) -> Self {
        self.target_plural_surface = true;
        self
    }

    pub fn with_target_reference_surface(mut self, surface: SearchResultReferenceSurface) -> Self {
        self.target_reference_surface = Some(surface);
        self
    }

    pub fn with_remainder_surface(mut self, surface: LibraryRemainderSurface) -> Self {
        self.remainder_surface = Some(surface);
        self
    }

    pub fn with_actor_surface(mut self, actor: PlayerFilter) -> Self {
        self.actor_surface = Some(actor);
        self
    }

    pub fn with_exiled_with_source_surface(mut self, surface: ExiledWithSourceMoveSurface) -> Self {
        self.exiled_with_source_surface = Some(surface);
        self
    }

    pub fn with_destination_player_surface(mut self, player: PlayerFilter) -> Self {
        self.destination_player_surface = Some(player);
        self
    }

    pub fn with_destination_player_reference_surface(
        mut self,
        surface: DestinationPlayerReferenceSurface,
    ) -> Self {
        self.destination_player_reference_surface = Some(surface);
        self
    }

    pub fn to_graveyard(target: ChooseSpec) -> Self {
        Self::new(target, crate::zone::Zone::Graveyard, false)
    }

    pub fn under_owner_control(mut self) -> Self {
        self.battlefield_controller = BattlefieldController::Owner;
        self.controller_surface_explicit = true;
        self
    }

    pub fn transfer_exiled_with_source_links(mut self) -> Self {
        self.transfer_exiled_with_source_links = true;
        self
    }

    pub fn under_you_control(mut self) -> Self {
        self.battlefield_controller = BattlefieldController::You;
        self.controller_surface_explicit = true;
        self
    }

    pub fn with_entry_counter(mut self, counter: BattlefieldEntryCounterSpec) -> Self {
        self.enters_with_counters.push(counter);
        self
    }

    pub fn tapped(mut self) -> Self {
        self.enters_tapped = true;
        self
    }

    pub fn attacking(mut self) -> Self {
        self.enters_attacking = true;
        self
    }

    pub fn attack_target_mode(mut self, mode: MoveToZoneAttackTargetMode) -> Self {
        self.enters_attacking = true;
        self.attack_target_mode = Some(mode);
        self
    }

    pub fn attacking_player_or_planeswalker_controlled_by(self, player: PlayerFilter) -> Self {
        self.attack_target_mode(
            MoveToZoneAttackTargetMode::PlayerOrPlaneswalkerControlledBy(player),
        )
    }

    pub fn attacking_player_only(self, player: PlayerFilter) -> Self {
        self.attack_target_mode(MoveToZoneAttackTargetMode::Player(player))
    }

    pub fn face_down(mut self) -> Self {
        self.enters_face_down = true;
        self
    }

    pub fn transformed(mut self) -> Self {
        self.enters_transformed = true;
        self
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct ReturnAllToBattlefieldEffect {
    pub filter: ObjectFilter,
    pub tapped: bool,
    pub face_down: bool,
    pub battlefield_controller: BattlefieldController,
    /// Whether the oracle text explicitly named the battlefield controller.
    /// This affects presentation only; `battlefield_controller` remains the
    /// executable controller choice.
    pub controller_surface_explicit: bool,
    pub verb_surface: MoveToZoneVerbSurface,
    /// "Only creatures can be enchanted this way": each returned Aura may
    /// only choose an object matching this filter to enchant (CR 303.4f);
    /// one with no legal choice stays in its zone (CR 303.4i).
    #[cfg_attr(feature = "serde", serde(default, skip_serializing_if = "Option::is_none"))]
    pub aura_attachment_filter: Option<ObjectFilter>,
}

impl ReturnAllToBattlefieldEffect {
    pub fn new(filter: ObjectFilter, tapped: bool) -> Self {
        Self {
            filter,
            tapped,
            face_down: false,
            battlefield_controller: BattlefieldController::Owner,
            controller_surface_explicit: false,
            verb_surface: MoveToZoneVerbSurface::Return,
            aura_attachment_filter: None,
        }
    }

    pub fn with_aura_attachment_filter(mut self, filter: ObjectFilter) -> Self {
        self.aura_attachment_filter = Some(filter);
        self
    }

    pub fn under_owner_control(mut self) -> Self {
        self.battlefield_controller = BattlefieldController::Owner;
        self.controller_surface_explicit = true;
        self
    }

    pub fn under_you_control(mut self) -> Self {
        self.battlefield_controller = BattlefieldController::You;
        self.controller_surface_explicit = true;
        self
    }

    pub fn under_you_control_implicitly(mut self) -> Self {
        self.battlefield_controller = BattlefieldController::You;
        self.controller_surface_explicit = false;
        self
    }

    pub fn face_down(mut self) -> Self {
        self.face_down = true;
        self
    }

    pub fn with_verb_surface(mut self, surface: MoveToZoneVerbSurface) -> Self {
        self.verb_surface = surface;
        self
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct ExecuteWithSourceEffect<E> {
    pub source: ChooseSpec,
    pub effect: Box<E>,
}

impl<E> ExecuteWithSourceEffect<E> {
    pub fn new(source: ChooseSpec, effect: E) -> Self {
        Self {
            source,
            effect: Box::new(effect),
        }
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct RetainManaUntilEndOfTurnEffect {
    pub player: PlayerFilter,
    /// "you don't lose unspent red mana": only mana of this color is kept.
    #[cfg_attr(
        feature = "serde",
        serde(default, skip_serializing_if = "Option::is_none")
    )]
    pub color: Option<crate::color::Color>,
    /// "Until end of combat, you don't lose this mana as steps end." (Fire
    /// Lord Ozai): retention lasts only until end of combat.
    #[cfg_attr(
        feature = "serde",
        serde(default, skip_serializing_if = "std::ops::Not::not")
    )]
    pub until_end_of_combat: bool,
}

/// "Turn the exiled card face up." / "Turn it face up."
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct TurnFaceUpEffect {
    pub target: ChooseSpec,
}

impl TurnFaceUpEffect {
    pub fn new(target: ChooseSpec) -> Self {
        Self { target }
    }
}

/// Turn existing permanents face down without moving them or granting a
/// face-down casting/entry method. The default CR 708.2 characteristics apply.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct TurnFaceDownEffect {
    pub target: ChooseSpec,
}

impl TurnFaceDownEffect {
    pub fn new(target: ChooseSpec) -> Self {
        Self { target }
    }
}

/// "It becomes foretold. Its foretell cost is its mana cost reduced by {N}."
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct BecomeForetoldWithCostEffect {
    pub target: ChooseSpec,
    /// Generic-mana reduction applied to the card's mana cost to form its
    /// foretell cost.
    pub cost_reduction: u32,
}

impl BecomeForetoldWithCostEffect {
    pub fn new(target: ChooseSpec, cost_reduction: u32) -> Self {
        Self {
            target,
            cost_reduction,
        }
    }
}

impl RetainManaUntilEndOfTurnEffect {
    pub fn new(player: PlayerFilter) -> Self {
        Self {
            player,
            color: None,
            until_end_of_combat: false,
        }
    }

    pub fn with_color(mut self, color: Option<crate::color::Color>) -> Self {
        self.color = color;
        self
    }

    pub fn with_until_end_of_combat(mut self, until_end_of_combat: bool) -> Self {
        self.until_end_of_combat = until_end_of_combat;
        self
    }

    pub fn you() -> Self {
        Self::new(PlayerFilter::You)
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, Eq, TagKeyWalk)]
pub struct MeldEffect {
    pub result_name: String,
    pub enters_tapped: bool,
    pub enters_attacking: bool,
}

impl MeldEffect {
    pub fn new(result_name: impl Into<String>) -> Self {
        Self {
            result_name: result_name.into(),
            enters_tapped: false,
            enters_attacking: false,
        }
    }

    pub fn enters_tapped(mut self, enters_tapped: bool) -> Self {
        self.enters_tapped = enters_tapped;
        self
    }

    pub fn enters_attacking(mut self, enters_attacking: bool) -> Self {
        self.enters_attacking = enters_attacking;
        self
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct ReorderLibraryTopEffect {
    pub tag: crate::tag::TagKey,
    pub chooser: PlayerFilter,
}

impl ReorderLibraryTopEffect {
    pub fn new(tag: impl Into<crate::tag::TagKey>) -> Self {
        Self {
            tag: tag.into(),
            chooser: PlayerFilter::You,
        }
    }

    pub fn chosen_by(mut self, chooser: PlayerFilter) -> Self {
        self.chooser = chooser;
        self
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct ExertCostEffect {
    pub display_text: String,
    #[cfg_attr(feature = "serde", serde(default))]
    pub descriptive: bool,
}

impl ExertCostEffect {
    pub fn new(display_text: impl Into<String>) -> Self {
        Self {
            display_text: display_text.into(),
            descriptive: false,
        }
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct ForEachObject<E> {
    pub filter: ObjectFilter,
    pub effects: Vec<E>,
}

impl<E> ForEachObject<E> {
    pub fn new(filter: ObjectFilter, effects: Vec<E>) -> Self {
        Self { filter, effects }
    }
}

/// Runs a tagged producer once for each matching source object, retains the
/// source-to-result association, then runs a consumer once for each retained
/// pair after every producer iteration has completed.
///
/// This preserves two-phase Oracle instructions such as "for each ...,
/// create ..." followed by "each of those ... [acts on] a different one of
/// those ...". The explicit binding tags keep the consumer composable without
/// overloading the ordinary `__it__` iterator reference.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct ForEachObjectCorrelatedResultEffect<E> {
    pub filter: ObjectFilter,
    pub producer_effects: Vec<E>,
    pub result_tag: crate::tag::TagKey,
    pub source_binding_tag: crate::tag::TagKey,
    pub result_binding_tag: crate::tag::TagKey,
    pub consumer_effects: Vec<E>,
}

impl<E> ForEachObjectCorrelatedResultEffect<E> {
    pub fn new(
        filter: ObjectFilter,
        producer_effects: Vec<E>,
        result_tag: impl Into<crate::tag::TagKey>,
        source_binding_tag: impl Into<crate::tag::TagKey>,
        result_binding_tag: impl Into<crate::tag::TagKey>,
        consumer_effects: Vec<E>,
    ) -> Self {
        Self {
            filter,
            producer_effects,
            result_tag: result_tag.into(),
            source_binding_tag: source_binding_tag.into(),
            result_binding_tag: result_binding_tag.into(),
            consumer_effects,
        }
    }
}

/// Presentation of a one-shot cast from cards linked to the source.
/// Object membership and the legal count remain on ChooseObjectsEffect.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, Eq, TagKeyWalk)]
pub struct SourceLinkedCollectionCastSurface {
    pub source: SourceReferenceSurface,
    pub from_among: bool,
    pub may_cast: bool,
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct ChooseObjectsEffect {
    /// "and/or" permits a nonempty subset of the authored search zones.
    #[cfg_attr(feature = "serde", serde(default))]
    pub optional_search_zones: bool,
    #[cfg_attr(feature = "serde", serde(default))]
    pub search_participant_tag: Option<crate::tag::TagKey>,
    pub filter: ObjectFilter,
    pub count: ChoiceCount,
    pub count_value: Option<Value>,
    pub aggregate_constraint: Option<ChoiceAggregateConstraint>,
    /// Authored source noun for a choice from cards exiled with this source.
    /// Membership stays in the SourceExiled tag; this is presentation only.
    #[cfg_attr(feature = "serde", serde(default))]
    pub collection_source_surface: Option<SourceLinkedCollectionCastSurface>,
    pub chooser: PlayerFilter,
    pub zone: Option<crate::zone::Zone>,
    pub additional_zones: Vec<crate::zone::Zone>,
    pub tag: crate::tag::TagKey,
    pub description: String,
    pub is_search: bool,
    pub reveal: bool,
    /// Present a choice from a previously revealed pool without performing
    /// another rules reveal. Authored reveal clauses compose the Reveal owner.
    /// None occurs only in legacy serialized selections. It is unambiguous
    /// when reveal is false; public disclosure requires an explicit policy.
    #[cfg_attr(feature = "serde", serde(default))]
    pub reveal_is_presentation_only: Option<bool>,
    pub search_mode: SearchSelectionMode,
    /// Authored reference used by the reveal clause for the searched set.
    /// This is separate from `search_result_reference_surface` because Oracle
    /// may reveal "them" and later move "those cards", or vice versa.
    pub search_reveal_reference_surface: Option<SearchResultReferenceSurface>,
    /// Authored reference used by the action that consumes a search result.
    /// `None` preserves the generic number-aware pronoun for hand-built
    /// choose/move sequences.
    pub search_result_reference_surface: Option<SearchResultReferenceSurface>,
    /// Whether a plural move to the top of the searched library explicitly
    /// included the presentation-only tail "in any order".
    pub search_top_in_any_order_surface: Option<bool>,
    pub top_only: bool,
    pub bottom_only: bool,
    pub replace_tagged_objects: bool,
    /// Persist an exact singular choice on the source for authored references
    /// from a later ability ("the chosen creature", for example).
    pub remember_as_chosen_object: bool,
    /// Open selected hidden identities before replay without a rules reveal action.
    #[cfg_attr(feature = "serde", serde(default))]
    pub public_selection: bool,
}

impl ChooseObjectsEffect {
    pub fn new(
        filter: ObjectFilter,
        count: impl Into<ChoiceCount>,
        chooser: PlayerFilter,
        tag: impl Into<crate::tag::TagKey>,
    ) -> Self {
        Self {
            search_participant_tag: None,
            filter,
            count: count.into(),
            count_value: None,
            aggregate_constraint: None,
            collection_source_surface: None,
            chooser,
            zone: None,
            additional_zones: Vec::new(),
            tag: tag.into(),
            description: "Choose".to_string(),
            optional_search_zones: false,
            is_search: false,
            reveal: false,
            reveal_is_presentation_only: Some(false),
            search_mode: SearchSelectionMode::Exact,
            search_reveal_reference_surface: None,
            search_result_reference_surface: None,
            search_top_in_any_order_surface: None,
            top_only: false,
            bottom_only: false,
            replace_tagged_objects: false,
            remember_as_chosen_object: false,
            public_selection: false,
        }
    }

    pub fn remember_as_chosen_object(mut self) -> Self {
        self.remember_as_chosen_object = true;
        self
    }

    pub fn in_zone(mut self, zone: crate::zone::Zone) -> Self {
        self.zone = Some(zone);
        self.additional_zones.clear();
        self
    }

    pub fn in_zones(mut self, zones: Vec<crate::zone::Zone>) -> Self {
        let mut iter = zones.into_iter();
        if let Some(first) = iter.next() {
            self.zone = Some(first);
            self.additional_zones = iter.collect();
        } else {
            self.zone = None;
            self.additional_zones.clear();
        }
        self
    }

    pub fn with_description(mut self, description: impl Into<String>) -> Self {
        self.description = description.into();
        self
    }

    pub fn with_count_value(mut self, count_value: Value) -> Self {
        self.count_value = Some(count_value);
        self
    }

    pub fn with_count_value_opt(mut self, count_value: Option<Value>) -> Self {
        self.count_value = count_value;
        self
    }

    pub fn with_aggregate_constraint(mut self, constraint: ChoiceAggregateConstraint) -> Self {
        self.aggregate_constraint = Some(constraint);
        self
    }

    pub fn with_collection_source_surface(mut self, surface: SourceLinkedCollectionCastSurface) -> Self {
        self.collection_source_surface = Some(surface);
        self
    }

    pub fn as_search(mut self) -> Self {
        self.is_search = true;
        self.search_mode = SearchSelectionMode::Exact;
        self
    }

    pub fn as_optional_search(mut self) -> Self {
        self.is_search = true;
        self.search_mode = SearchSelectionMode::Optional;
        self
    }

    pub fn as_all_matching_search(mut self) -> Self {
        self.is_search = true;
        self.search_mode = SearchSelectionMode::AllMatching;
        self
    }

    pub fn with_search_result_reference_surface(
        mut self,
        surface: SearchResultReferenceSurface,
    ) -> Self {
        self.search_result_reference_surface = Some(surface);
        self
    }

    pub fn with_search_reveal_reference_surface(
        mut self,
        surface: Option<SearchResultReferenceSurface>,
    ) -> Self {
        self.search_reveal_reference_surface = surface;
        self
    }

    pub fn with_search_top_in_any_order_surface(mut self, explicit: bool) -> Self {
        self.search_top_in_any_order_surface = Some(explicit);
        self
    }

    pub fn reveal(mut self) -> Self {
        self.reveal = true;
        self.reveal_is_presentation_only = Some(false);
        self
    }

    /// Keep an already revealed pool public during selection. This does not
    /// create a second Reveal action or its observations.
    pub fn present_revealed_choices(mut self) -> Self {
        self.reveal = true;
        self.reveal_is_presentation_only = Some(true);
        self
    }

    pub fn top_only(mut self) -> Self {
        self.top_only = true;
        self.bottom_only = false;
        self
    }

    pub fn bottom_only(mut self) -> Self {
        self.bottom_only = true;
        self.top_only = false;
        self
    }

    pub fn replace_tagged_objects(mut self) -> Self {
        self.replace_tagged_objects = true;
        self
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct PopulateEffect {
    pub count: Value,
    pub enters_tapped: bool,
    pub enters_attacking: bool,
    pub has_haste: bool,
    pub sacrifice_at_next_end_step: bool,
    pub exile_at_next_end_step: bool,
    pub next_end_step_player: PlayerFilter,
    pub exile_at_end_of_combat: bool,
    pub sacrifice_at_end_of_combat: bool,
}

impl PopulateEffect {
    pub fn new(count: impl Into<Value>) -> Self {
        Self {
            count: count.into(),
            enters_tapped: false,
            enters_attacking: false,
            has_haste: false,
            sacrifice_at_next_end_step: false,
            exile_at_next_end_step: false,
            next_end_step_player: PlayerFilter::Any,
            exile_at_end_of_combat: false,
            sacrifice_at_end_of_combat: false,
        }
    }

    pub fn enters_tapped(mut self, value: bool) -> Self {
        self.enters_tapped = value;
        self
    }

    pub fn attacking(mut self, value: bool) -> Self {
        self.enters_attacking = value;
        self
    }

    pub fn haste(mut self, value: bool) -> Self {
        self.has_haste = value;
        self
    }

    pub fn sacrifice_at_next_end_step(mut self, value: bool) -> Self {
        self.sacrifice_at_next_end_step = value;
        self
    }

    pub fn exile_at_next_end_step(mut self, value: bool) -> Self {
        self.exile_at_next_end_step = value;
        self
    }

    pub fn next_end_step_player(mut self, player: PlayerFilter) -> Self {
        self.next_end_step_player = player;
        self
    }

    pub fn exile_at_end_of_combat(mut self, value: bool) -> Self {
        self.exile_at_end_of_combat = value;
        self
    }

    pub fn sacrifice_at_end_of_combat(mut self, value: bool) -> Self {
        self.sacrifice_at_end_of_combat = value;
        self
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct BecomeBasicLandTypeChoiceEffect {
    pub target: ChooseSpec,
    pub duration: Until,
    pub chooser: PlayerFilter,
    pub fixed_subtype: Option<crate::types::Subtype>,
    #[cfg_attr(feature = "serde", serde(default))]
    pub preserve_other_types: bool,
    /// Empty means the five basic land types; otherwise one of this exact set.
    #[cfg_attr(feature = "serde", serde(default))]
    pub allowed_subtypes: Vec<crate::types::Subtype>,
}

impl BecomeBasicLandTypeChoiceEffect {
    pub fn new(target: ChooseSpec, duration: Until) -> Self {
        Self {
            target,
            duration,
            chooser: PlayerFilter::You,
            fixed_subtype: None,
            preserve_other_types: false,
            allowed_subtypes: Vec::new(),
        }
    }

    pub fn fixed(target: ChooseSpec, subtype: crate::types::Subtype, duration: Until) -> Self {
        Self {
            target,
            duration,
            chooser: PlayerFilter::You,
            fixed_subtype: Some(subtype),
            preserve_other_types: false,
            allowed_subtypes: Vec::new(),
        }
    }

    pub fn with_options(
        mut self,
        allowed_subtypes: Vec<crate::types::Subtype>,
        preserve_other_types: bool,
    ) -> Self {
        self.allowed_subtypes = allowed_subtypes;
        self.preserve_other_types = preserve_other_types;
        self
    }

    pub fn with_chooser(mut self, chooser: PlayerFilter) -> Self {
        self.chooser = chooser;
        self
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct BecomeCreatureTypeChoiceEffect {
    /// Reuse the registering source's already chosen creature type. The
    /// executed modification snapshots that subtype rather than prompting.
    #[cfg_attr(feature = "serde", serde(default, skip_serializing_if = "std::ops::Not::not"))]
    pub use_source_chosen_type: bool,
    pub target: ChooseSpec,
    pub duration: Until,
    pub chooser: PlayerFilter,
    pub excluded_subtypes: Vec<crate::types::Subtype>,
    /// "becomes the creature type of your choice in addition to its other
    /// types" (Mistform Sliver): add the chosen type without removing the
    /// object's other creature types (CR 205.1b).
    #[cfg_attr(feature = "serde", serde(default, skip_serializing_if = "std::ops::Not::not"))]
    pub in_addition_to_other_types: bool,
}

impl BecomeCreatureTypeChoiceEffect {
    pub fn new(
        target: ChooseSpec,
        duration: Until,
        excluded_subtypes: Vec<crate::types::Subtype>,
    ) -> Self {
        Self {
            use_source_chosen_type: false,
            target,
            duration,
            chooser: PlayerFilter::You,
            excluded_subtypes,
            in_addition_to_other_types: false,
        }
    }

    pub fn with_chooser(mut self, chooser: PlayerFilter) -> Self {
        self.chooser = chooser;
        self
    }

    pub fn in_addition_to_other_types(mut self, in_addition: bool) -> Self {
        self.in_addition_to_other_types = in_addition;
        self
    }

    pub fn all_creature_types() -> Vec<crate::types::Subtype> {
        crate::types::Subtype::all_creature_types().to_vec()
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Clone, PartialEq, TagKeyWalk)]
pub struct BecomeColorChoiceEffect {
    pub target: ChooseSpec,
    pub duration: Until,
    pub chooser: PlayerFilter,
    pub allow_multiple: bool,
    /// "becomes that color" (Foraging Wickermaw): the color is the one
    /// completed by this exact earlier local color decision (a chosen color or
    /// the color of mana just added), so no new choice is made. Appended with
    /// a serde default; omitted from Debug when absent.
    #[cfg_attr(feature = "serde", serde(default, skip_serializing_if = "Option::is_none"))]
    pub color_from: Option<crate::value_model::ColorChoiceReference>,
}

impl std::fmt::Debug for BecomeColorChoiceEffect {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        let mut debug = f.debug_struct("BecomeColorChoiceEffect");
        debug
            .field("target", &self.target)
            .field("duration", &self.duration)
            .field("chooser", &self.chooser)
            .field("allow_multiple", &self.allow_multiple);
        if let Some(color_from) = &self.color_from {
            debug.field("color_from", color_from);
        }
        debug.finish()
    }
}

impl BecomeColorChoiceEffect {
    pub fn new(target: ChooseSpec, duration: Until) -> Self {
        Self {
            target,
            duration,
            chooser: PlayerFilter::You,
            allow_multiple: false,
            color_from: None,
        }
    }

    /// Use the color completed by an exact earlier local color decision.
    pub fn with_color_from(mut self, reference: crate::value_model::ColorChoiceReference) -> Self {
        self.color_from = Some(reference);
        self
    }

    pub fn with_chooser(mut self, chooser: PlayerFilter) -> Self {
        self.chooser = chooser;
        self
    }

    pub fn with_multiple_colors(mut self, allow_multiple: bool) -> Self {
        self.allow_multiple = allow_multiple;
        self
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct PayManaEffect {
    pub cost: crate::mana::ManaCost,
    pub player: ChooseSpec,
    /// An exact value for printed X, computed from game state rather than
    /// chosen by the paying player.
    pub x_value: Option<Value>,
    /// An inclusive upper bound for printed X. The paying player chooses X
    /// from the affordable values between zero and this resolved maximum.
    pub x_maximum: Option<Value>,
    /// Choose a new payment amount, independently of the enclosing spell's X.
    #[cfg_attr(feature = "serde", serde(default))]
    pub independent_x_choice: bool,
    /// "pay that spell's mana cost" (Ice Cave): the exact object whose current
    /// mana cost is paid in addition to `cost`. Colored, hybrid and Phyrexian
    /// symbols are preserved; an object with no mana cost makes the payment
    /// impossible (CR 118.6), and X on a spell is the value chosen for it.
    #[cfg_attr(feature = "serde", serde(default))]
    pub mana_cost_of: Option<Box<ChooseSpec>>,
}

impl PayManaEffect {
    pub fn new(cost: crate::mana::ManaCost, player: ChooseSpec) -> Self {
        Self {
            cost,
            player,
            x_value: None,
            x_maximum: None,
            independent_x_choice: false,
            mana_cost_of: None,
        }
    }

    pub fn with_mana_cost_of(mut self, object: ChooseSpec) -> Self {
        self.mana_cost_of = Some(Box::new(object));
        self
    }

    pub fn with_x_value(mut self, x_value: Value) -> Self {
        self.x_value = Some(x_value);
        self
    }

    pub fn with_independent_x_choice(mut self) -> Self {
        self.independent_x_choice = true;
        self
    }

    pub fn with_x_maximum(mut self, x_maximum: Value) -> Self {
        self.x_maximum = Some(x_maximum);
        self
    }
}

/// CR 701.71: choose a controlled Jace planeswalker token, creating the
/// predefined blue token only when none exists, then put N loyalty counters on it.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct EmpowerJaceEffect {
    pub amount: Value,
}

impl EmpowerJaceEffect {
    pub fn new(amount: impl Into<Value>) -> Self {
        Self {
            amount: amount.into(),
        }
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct CollectEvidenceEffect {
    pub amount: Value,
    #[cfg_attr(feature = "serde", serde(default))]
    pub ordinary_exile: bool,
}
impl CollectEvidenceEffect {
    pub fn exile_graveyard_cards_with_total_mana_value(amount: impl Into<Value>) -> Self {
        Self { amount: amount.into(), ordinary_exile: true }
    }
    pub fn new(amount: impl Into<Value>) -> Self {
        Self {
            amount: amount.into(),
            ordinary_exile: false,
        }
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct AmassEffect {
    pub subtype: Option<crate::types::Subtype>,
    pub amount: Value,
    #[cfg_attr(feature = "serde", serde(default))]
    pub descriptive: bool,
    /// The player who amasses ("Its controller amasses Goblins X", Azog,
    /// Moria's Ruin). None is the effect's controller. Appended.
    #[cfg_attr(
        feature = "serde",
        serde(default, skip_serializing_if = "Option::is_none")
    )]
    pub player: Option<PlayerFilter>,
}

impl AmassEffect {
    pub fn new(subtype: Option<crate::types::Subtype>, amount: impl Into<Value>) -> Self {
        Self {
            subtype,
            amount: amount.into(),
            descriptive: false,
            player: None,
        }
    }

    pub fn with_player(mut self, player: PlayerFilter) -> Self {
        self.player = Some(player);
        self
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct GrantNextSpellCostReductionEffect {
    pub player: PlayerFilter,
    pub filter: ObjectFilter,
    pub reduction: crate::mana::ManaCost,
    pub generic_reduction: Option<Value>,
    pub applies_to_all_matching_this_turn: bool,
    pub duration: Until,
    /// "... can be cast without paying its mana cost": the next matching
    /// spell may be cast for a zero-mana alternative cost instead of having
    /// its cost reduced.
    #[cfg_attr(feature = "serde", serde(default))]
    pub without_paying_mana_cost: bool,
    /// "... cost {N} more to cast": the registered generic amount is added
    /// to matching spells' costs instead of subtracted from them.
    #[cfg_attr(feature = "serde", serde(default))]
    pub increases_cost: bool,
    /// "Rather than pay the mana cost of the next spell you cast this turn,
    /// you may pay life equal to that spell's mana value." (Marshland
    /// Bloodcaster): with `without_paying_mana_cost`, the alternative cost is
    /// that life payment instead of nothing.
    #[cfg_attr(feature = "serde", serde(default, skip_serializing_if = "std::ops::Not::not"))]
    pub pay_life_equal_to_mana_value: bool,
}

impl GrantNextSpellCostReductionEffect {
    /// Turn the generic modifier into a cost increase ("... cost {N} more").
    pub fn increasing_cost(mut self) -> Self {
        self.increases_cost = true;
        self
    }

    pub fn next_matching_without_paying_mana_cost_this_turn(
        player: PlayerFilter,
        filter: ObjectFilter,
    ) -> Self {
        Self {
            without_paying_mana_cost: true,
            ..Self::new(player, filter, crate::mana::ManaCost::new())
        }
    }

    /// "Rather than pay the mana cost of the next spell you cast this turn,
    /// you may pay life equal to that spell's mana value."
    pub fn next_matching_for_life_equal_to_mana_value_this_turn(
        player: PlayerFilter,
        filter: ObjectFilter,
    ) -> Self {
        Self {
            pay_life_equal_to_mana_value: true,
            ..Self::next_matching_without_paying_mana_cost_this_turn(player, filter)
        }
    }

    pub fn new(
        player: PlayerFilter,
        filter: ObjectFilter,
        reduction: crate::mana::ManaCost,
    ) -> Self {
        Self {
            player,
            filter,
            reduction,
            generic_reduction: None,
            applies_to_all_matching_this_turn: false,
            duration: Until::EndOfTurn,
            without_paying_mana_cost: false,
            increases_cost: false,
            pay_life_equal_to_mana_value: false,
        }
    }

    pub fn all_matching_this_turn(
        player: PlayerFilter,
        filter: ObjectFilter,
        generic_reduction: impl Into<Value>,
    ) -> Self {
        Self {
            player,
            filter,
            reduction: crate::mana::ManaCost::new(),
            generic_reduction: Some(generic_reduction.into()),
            applies_to_all_matching_this_turn: true,
            duration: Until::EndOfTurn,
            without_paying_mana_cost: false,
            increases_cost: false,
            pay_life_equal_to_mana_value: false,
        }
    }

    pub fn next_matching_this_turn(
        player: PlayerFilter,
        filter: ObjectFilter,
        generic_reduction: impl Into<Value>,
    ) -> Self {
        Self {
            player,
            filter,
            reduction: crate::mana::ManaCost::new(),
            generic_reduction: Some(generic_reduction.into()),
            applies_to_all_matching_this_turn: false,
            duration: Until::EndOfTurn,
            without_paying_mana_cost: false,
            increases_cost: false,
            pay_life_equal_to_mana_value: false,
        }
    }

    pub fn all_matching_until(
        player: PlayerFilter,
        filter: ObjectFilter,
        generic_reduction: impl Into<Value>,
        duration: Until,
    ) -> Self {
        Self {
            player,
            filter,
            reduction: crate::mana::ManaCost::new(),
            generic_reduction: Some(generic_reduction.into()),
            applies_to_all_matching_this_turn: true,
            duration,
            without_paying_mana_cost: false,
            increases_cost: false,
            pay_life_equal_to_mana_value: false,
        }
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct GrantAbilitiesTargetEffect<A> {
    pub target: ChooseSpec,
    pub abilities: Vec<A>,
    pub duration: Until,
    /// Snapshot this object's activated abilities when the grant resolves.
    #[cfg_attr(feature = "serde", serde(default, skip_serializing_if = "Option::is_none"))]
    pub activated_from: Option<ChooseSpec>,
    /// "You may spend blue mana as though it were mana of any color to
    /// activate those abilities" (Grell Philosopher, CR 609.4b): mana of this
    /// color may pay any colored symbol in the copied activation costs, and
    /// only in those. Appended; absent in older artifacts.
    #[cfg_attr(feature = "serde", serde(default, skip_serializing_if = "Option::is_none"))]
    pub activated_from_symbol_as_any_color: Option<ManaSymbol>,
}

impl<A> GrantAbilitiesTargetEffect<A> {
    pub fn new(
        target: ChooseSpec,
        abilities: impl IntoIterator<Item = A>,
        duration: Until,
    ) -> Self {
        Self {
            target,
            abilities: abilities.into_iter().collect(),
            duration,
            activated_from: None,
            activated_from_symbol_as_any_color: None,
        }
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct ModifyPowerToughnessEffect {
    pub target: ChooseSpec,
    pub power: Value,
    pub toughness: Value,
    pub duration: Until,
}

impl ModifyPowerToughnessEffect {
    pub fn new(
        target: ChooseSpec,
        power: impl Into<Value>,
        toughness: impl Into<Value>,
        duration: Until,
    ) -> Self {
        Self {
            target,
            power: power.into(),
            toughness: toughness.into(),
            duration,
        }
    }

    pub fn pump(target: ChooseSpec, amount: impl Into<Value>, duration: Until) -> Self {
        let val = amount.into();
        Self::new(target, val.clone(), val, duration)
    }

    pub fn shrink(target: ChooseSpec, amount: i32, duration: Until) -> Self {
        Self::new(target, -amount, -amount, duration)
    }

    pub fn source(power: impl Into<Value>, toughness: impl Into<Value>, duration: Until) -> Self {
        Self::new(ChooseSpec::Source, power, toughness, duration)
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct FightEffect {
    pub creature1: ChooseSpec,
    pub creature2: ChooseSpec,
    pub mutual_surface: bool,
}

impl FightEffect {
    pub fn new(creature1: ChooseSpec, creature2: ChooseSpec) -> Self {
        Self {
            creature1,
            creature2,
            mutual_surface: false,
        }
    }

    pub fn with_mutual_surface(mut self) -> Self {
        self.mutual_surface = true;
        self
    }

    pub fn you_vs_opponent() -> Self {
        Self::new(ChooseSpec::creature(), ChooseSpec::creature())
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct ExploreEffect {
    pub target: ChooseSpec,
    #[cfg_attr(feature = "serde", serde(default))]
    pub descriptive: bool,
}

impl ExploreEffect {
    pub fn new(target: ChooseSpec) -> Self {
        Self { target, descriptive: false }
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct ManifestDreadEffect {
    pub player: PlayerFilter,
}

#[cfg(feature = "serde")]
impl<'de> serde::Deserialize<'de> for ManifestDreadEffect {
    fn deserialize<D: serde::Deserializer<'de>>(deserializer: D) -> Result<Self, D::Error> {
        #[derive(serde::Deserialize)]
        struct Payload {
            player: PlayerFilter,
        }
        let payload = Option::<Payload>::deserialize(deserializer)?;
        Ok(payload.map_or_else(Self::new, |payload| Self::for_player(payload.player)))
    }
}

impl Default for ManifestDreadEffect {
    fn default() -> Self {
        Self::new()
    }
}

impl ManifestDreadEffect {
    pub fn new() -> Self {
        Self {
            player: PlayerFilter::You,
        }
    }
    pub fn for_player(player: PlayerFilter) -> Self {
        Self { player }
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct ManifestTopCardOfLibraryEffect {
    pub player: PlayerFilter,
    /// Cloak uses the same face-down/top-card operation as manifest, but the
    /// resulting 2/2 creature also has ward {2}.
    pub cloak: bool,
    #[cfg_attr(feature = "serde", serde(default))]
    pub descriptive: bool,
}

/// An ordinary, optional exile-and-cast action for a described face-down card.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct DescribedFaceDownCastPermission {
    pub filter: ObjectFilter,
    pub require_printed_mana_cost: bool,
}

/// Put an arbitrary collection of cards onto the battlefield face down.
/// Entry provenance separately records manifest, cloak or a described operation.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct ManifestObjectsEffect {
    pub target: ChooseSpec,
    pub controller: PlayerFilter,
    pub cloak: bool,
    pub tapped: bool,
    pub shuffle: bool,
    #[cfg_attr(feature = "serde", serde(default))]
    pub descriptive: bool,
    /// Resolve control separately for every entering card.
    #[cfg_attr(feature = "serde", serde(default))]
    pub under_owner_control: bool,
    /// Described face-down entry without a printed-mana-cost special action.
    #[cfg_attr(feature = "serde", serde(default))]
    pub no_turn_up_permission: bool,
    #[cfg_attr(feature = "serde", serde(default))]
    pub exile_cast_permission: Option<DescribedFaceDownCastPermission>,
}

impl ManifestObjectsEffect {
    pub fn new(target: ChooseSpec, controller: PlayerFilter) -> Self {
        Self {
            descriptive: false,
            under_owner_control: false,
            no_turn_up_permission: false,
            exile_cast_permission: None,
            target,
            controller,
            cloak: false,
            tapped: false,
            shuffle: false,
        }
    }

    pub fn cloak(mut self) -> Self {
        self.cloak = true;
        self
    }

    pub fn tapped(mut self) -> Self {
        self.tapped = true;
        self
    }

    pub fn shuffled(mut self) -> Self {
        self.shuffle = true;
        self
    }
}

impl ManifestTopCardOfLibraryEffect {
    pub fn new(player: PlayerFilter) -> Self {
        Self {
            descriptive: false,
            player,
            cloak: false,
        }
    }

    pub fn cloak(player: PlayerFilter) -> Self {
        Self {
            descriptive: false,
            player,
            cloak: true,
        }
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, Default, TagKeyWalk)]
pub struct ManifestCardFromHandEffect;

impl ManifestCardFromHandEffect {
    pub fn new() -> Self {
        Self
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct SupportEffect {
    pub amount: u32,
    #[cfg_attr(feature = "serde", serde(default, skip_serializing_if = "Option::is_none"))]
    pub amount_value: Option<Value>,
}

impl SupportEffect {
    pub fn new(amount: u32) -> Self {
        Self { amount, amount_value: None }
    }

    pub fn with_value(value: Value) -> Self {
        if let Value::Fixed(amount) = &value
            && let Ok(amount) = u32::try_from(*amount)
        { return Self::new(amount); }
        Self { amount: 0, amount_value: Some(value) }
    }

    pub fn value(&self) -> Value {
        self.amount_value.clone().unwrap_or_else(|| self.amount.into())
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct AmplifyEffect {
    pub amount: u32,
    #[cfg_attr(feature = "serde", serde(default))]
    pub descriptive: bool,
}

impl AmplifyEffect {
    pub fn new(amount: u32) -> Self {
        Self { amount, descriptive: false }
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct DevourEffect {
    pub multiplier: u32,
    /// CR 702.82c "Devour [quality] N": the permanents that may be devoured.
    /// `None` is the plain keyword's "creatures".
    #[cfg_attr(
        feature = "serde",
        serde(default, skip_serializing_if = "Option::is_none")
    )]
    pub quality: Option<ObjectFilter>,
    /// "Devour X, where X is the number of creatures devoured this way"
    /// (Thromok the Insatiable): each devoured permanent is worth X counters,
    /// so the source gets the devoured count squared.
    #[cfg_attr(
        feature = "serde",
        serde(default, skip_serializing_if = "std::ops::Not::not")
    )]
    pub multiplier_is_devoured_count: bool,
}

impl DevourEffect {
    pub fn new(multiplier: u32) -> Self {
        Self {
            multiplier,
            quality: None,
            multiplier_is_devoured_count: false,
        }
    }

    pub fn with_quality(multiplier: u32, quality: ObjectFilter) -> Self {
        Self {
            multiplier,
            quality: Some(quality),
            multiplier_is_devoured_count: false,
        }
    }

    pub fn devoured_count_squared() -> Self {
        Self {
            multiplier: 1,
            quality: None,
            multiplier_is_devoured_count: true,
        }
    }

    /// The keyword's printed surface ("Devour 2", "Devour artifact 1",
    /// "Devour X, where X is the number of creatures devoured this way").
    pub fn keyword_text(&self) -> String {
        if self.multiplier_is_devoured_count {
            return "Devour X, where X is the number of creatures devoured this way".to_string();
        }
        let Some(quality) = &self.quality else {
            return format!("Devour {}", self.multiplier);
        };
        let word = if let Some(subtype) = quality.subtypes.first() {
            subtype.to_string()
        } else if let Some(card_type) = quality.card_types.first() {
            card_type.to_string().to_ascii_lowercase()
        } else {
            "permanent".to_string()
        };
        format!("Devour {word} {}", self.multiplier)
    }

    /// The +1/+1 counters the source gets for `devoured` permanents.
    pub fn counters_for(&self, devoured: u32) -> u32 {
        if self.multiplier_is_devoured_count {
            devoured.saturating_mul(devoured)
        } else {
            devoured.saturating_mul(self.multiplier)
        }
    }
}

/// "This ability still resolves if its target becomes illegal." (Gilded
/// Drake): a marker that suspends the CR 608.2b all-targets-illegal check
/// for the ability it appears in. It has no effect when executed.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, Default, TagKeyWalk)]
pub struct ResolvesDespiteIllegalTargetsEffect;

impl ResolvesDespiteIllegalTargetsEffect {
    pub fn new() -> Self {
        Self
    }
}

/// Miracle's linked trigger resolution: the drawn card's owner may cast it by
/// paying its miracle cost (CR 702.94a).
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, Default, TagKeyWalk)]
pub struct MayCastForMiracleCostEffect;

impl MayCastForMiracleCostEffect {
    pub fn new() -> Self {
        Self
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct ConniveEffect {
    pub target: ChooseSpec,
    pub count: Value,
    #[cfg_attr(feature = "serde", serde(default))]
    pub descriptive: bool,
}

impl ConniveEffect {
    pub fn new(target: ChooseSpec) -> Self {
        Self::new_with_count(target, Value::Fixed(1))
    }

    pub fn new_with_count(target: ChooseSpec, count: impl Into<Value>) -> Self {
        Self {
            target,
            count: count.into(),
            descriptive: false,
        }
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct DetainEffect {
    pub target: ChooseSpec,
}

impl DetainEffect {
    pub fn new(target: ChooseSpec) -> Self {
        Self { target }
    }
}

/// "The next time target creature adapts this turn, it adapts as though it
/// had no +1/+1 counters on it." (Biomancer's Familiar)
/// "Note the type of mana spent to pay this activation cost": records, on the
/// ability's source, the one type of mana in the activation payment.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, Default, TagKeyWalk)]
pub struct NoteActivationManaTypeEffect;

/// Remember the exact color-by-color payment of an activation on its source.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, Default, TagKeyWalk)]
pub struct NoteActivationManaPaymentEffect;

/// Choose and optionally cast a creature from hand face down, using the
/// resolving activation's retained physical mana payment as eligibility proof.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct CastFaceDownUsingActivationManaEffect {
    pub player: PlayerFilter,
    pub filter: ObjectFilter,
    pub turn_face_up_before_action: bool,
}

/// Register one extra-die/ignored-result replacement through the current turn.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct RegisterExtraDieReplacementEffect {
    pub player: ChooseSpec,
    pub chooser: PlayerFilter,
    pub additional: u32,
}


impl NoteActivationManaTypeEffect {
    pub fn new() -> Self {
        Self
    }
}

/// "Note one of its creature types that hasn't been noted for this
/// artifact": the triggering object's controller-chosen creature type, not yet
/// noted for the ability's source, is added to the source's noted set (Volo's
/// Journal).
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, Default, TagKeyWalk)]
pub struct NoteTriggeringCreatureTypeEffect;

impl NoteTriggeringCreatureTypeEffect {
    pub fn new() -> Self {
        Self
    }
}

/// "Note the number and kind of counters that were on that creature"
/// (Tawnos's Coffin): records `object` as it last existed, including its
/// counters, under `tag`. A later battlefield entry reads the noted counters
/// back through `MoveToZoneEffect::enters_with_noted_counters`.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct NoteCountersEffect {
    pub object: ChooseSpec,
    pub tag: crate::tag::TagKey,
}

impl NoteCountersEffect {
    pub fn new(object: ChooseSpec, tag: impl Into<crate::tag::TagKey>) -> Self {
        Self {
            object,
            tag: tag.into(),
        }
    }
}

/// When a resolution-registered replacement stops applying.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, Copy, PartialEq, Eq, TagKeyWalk)]
pub enum RegisteredReplacementExpiry {
    EndOfTurn,
    YourNextTurn,
    /// "until your next upkeep": no damage can be dealt between the start of
    /// that turn and its upkeep (no player gets priority during the untap
    /// step, CR 502.4), so the replacement ends as that turn begins.
    YourNextUpkeep,
}

impl RegisteredReplacementExpiry {
    pub fn apply_mode(self) -> ReplacementApplyMode {
        match self {
            Self::EndOfTurn => ReplacementApplyMode::UntilEndOfTurn,
            Self::YourNextTurn | Self::YourNextUpkeep => ReplacementApplyMode::UntilYourNextTurn,
        }
    }
}

/// "For each 1 damage that would be dealt to you until your next upkeep, you
/// remove an echo counter from this enchantment instead." (Soul Echo): a
/// resolution-registered replacement (CR 614.1a) of damage that would be
/// dealt to `player`, which removes that many `counter_type` counters from
/// `object` instead. `object` is fixed to the object it names on resolution.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct RegisterDamageCounterReplacementEffect {
    pub player: PlayerFilter,
    pub counter_type: CounterType,
    pub object: ChooseSpec,
    pub expiry: RegisteredReplacementExpiry,
}

impl RegisterDamageCounterReplacementEffect {
    pub fn new(
        player: PlayerFilter,
        counter_type: CounterType,
        object: ChooseSpec,
        expiry: RegisteredReplacementExpiry,
    ) -> Self {
        Self {
            player,
            counter_type,
            object,
            expiry,
        }
    }
}

/// "Add one mana of this artifact's last noted type".
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct AddManaOfNotedTypeEffect {
    #[cfg_attr(feature = "serde", serde(default))]
    pub use_noted_amount: bool,
    pub amount: Value,
    pub player: PlayerFilter,
}

impl AddManaOfNotedTypeEffect {
    pub fn new(amount: impl Into<Value>, player: PlayerFilter) -> Self {
        Self {
            use_noted_amount: false,
            amount: amount.into(),
            player,
        }
    }
}

/// "Choose 1, 2, or 3 at random": picks one of `choices` uniformly; the
/// outcome count is the chosen number ("that many").
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct ChooseNumberAtRandomEffect {
    pub choices: Vec<u32>,
}

impl ChooseNumberAtRandomEffect {
    pub fn new(choices: Vec<u32>) -> Self {
        Self { choices }
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct NextAdaptIgnoresCountersEffect {
    pub target: ChooseSpec,
}

impl NextAdaptIgnoresCountersEffect {
    pub fn new(target: ChooseSpec) -> Self {
        Self { target }
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct GoadEffect {
    pub target: ChooseSpec,
    pub duration: Until,
    /// The printed text spelled the requirement out ("attack each combat if
    /// able and attack a player other than you if able") rather than saying
    /// "goad" (Kardur, Doomscourge). Display only.
    #[cfg_attr(feature = "serde", serde(default))]
    pub spelled_out_requirement: bool,
}

impl GoadEffect {
    pub fn new(target: ChooseSpec) -> Self {
        Self::with_duration(target, Until::YourNextTurn)
    }

    pub fn with_duration(target: ChooseSpec, duration: Until) -> Self {
        Self {
            target,
            duration,
            spelled_out_requirement: false,
        }
    }

    pub fn spelled_out_requirement(mut self) -> Self {
        self.spelled_out_requirement = true;
        self
    }
}

/// "Target creature attacks <player> this turn if able" (CR 508.1d): a
/// requirement, for this turn only, that each affected creature attacks the
/// resolved player if able. It does not require the creature to attack at
/// all when it can't attack that player.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct MustAttackPlayerThisTurnEffect {
    pub target: ChooseSpec,
    pub player: ChooseSpec,
    /// "attacks during its controller's next combat phase if able" (Trench
    /// Behemoth): the requirement names no player and waits for the
    /// creature's controller's next combat phase; `player` is unused.
    #[cfg_attr(feature = "serde", serde(default))]
    pub controllers_next_combat: bool,
}

impl MustAttackPlayerThisTurnEffect {
    pub fn new(target: ChooseSpec, player: ChooseSpec) -> Self {
        Self {
            target,
            player,
            controllers_next_combat: false,
        }
    }

    pub fn with_controllers_next_combat(mut self, controllers_next_combat: bool) -> Self {
        self.controllers_next_combat = controllers_next_combat;
        self
    }
}

/// Mark an exiled card as plotted. This does not perform the plot special
/// action or emit its keyword-action event.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct BecomePlottedEffect {
    pub target: ChooseSpec,
}

impl BecomePlottedEffect {
    pub fn new(target: ChooseSpec) -> Self {
        Self { target }
    }
}

/// Mark an exiled card as foretold ("It becomes foretold.", The Foretold
/// Soldier). This does not perform the foretell special action.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct BecomeForetoldEffect {
    pub target: ChooseSpec,
    /// "Its foretell cost is its mana cost reduced by {N}." (Ethereal
    /// Valkyrie): the effect also gives the foretold card a foretell cost of
    /// its mana cost with N less generic mana (CR 702.143). `None` keeps the
    /// card's own foretell cost, if any.
    #[cfg_attr(feature = "serde", serde(default))]
    pub foretell_cost_reduction: Option<u32>,
}

impl BecomeForetoldEffect {
    pub fn new(target: ChooseSpec) -> Self {
        Self {
            target,
            foretell_cost_reduction: None,
        }
    }

    pub fn with_foretell_cost_reduction(mut self, reduction: Option<u32>) -> Self {
        self.foretell_cost_reduction = reduction;
        self
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct SuspectEffect {
    pub target: ChooseSpec,
}

impl SuspectEffect {
    pub fn new(target: ChooseSpec) -> Self {
        Self { target }
    }
}

/// The Prepared keyword action: the affected permanents become prepared.
///
/// Only a permanent whose card has a prepare spell (its second face) can become
/// prepared, and one that already is stays as it was rather than preparing a
/// second copy.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct PrepareEffect {
    pub target: ChooseSpec,
    /// "becomes unprepared": remove the prepared designation instead.
    #[cfg_attr(feature = "serde", serde(default, skip_serializing_if = "std::ops::Not::not"))]
    pub unprepare: bool,
}

impl PrepareEffect {
    pub fn new(target: ChooseSpec) -> Self {
        Self {
            target,
            unprepare: false,
        }
    }

    pub fn unprepare(target: ChooseSpec) -> Self {
        Self {
            target,
            unprepare: true,
        }
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct ClearSuspectedEffect {
    pub target: Option<ChooseSpec>,
}

impl ClearSuspectedEffect {
    pub fn new(target: ChooseSpec) -> Self {
        Self {
            target: Some(target),
        }
    }

    pub const fn all() -> Self {
        Self { target: None }
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct ClearGoadEffect {
    pub target: Option<ChooseSpec>,
}

impl ClearGoadEffect {
    pub fn new(target: ChooseSpec) -> Self {
        Self {
            target: Some(target),
        }
    }

    pub const fn all() -> Self {
        Self { target: None }
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, Default, TagKeyWalk)]
pub struct OpenAttractionEffect {
    pub reminder: bool,
}

impl OpenAttractionEffect {
    pub fn new() -> Self {
        Self { reminder: false }
    }

    pub fn with_reminder(mut self, reminder: bool) -> Self {
        self.reminder = reminder;
        self
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct AdaptEffect {
    pub amount: u32,
}

impl AdaptEffect {
    pub fn new(amount: u32) -> Self {
        Self { amount }
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct BackupEffect<A> {
    pub amount: u32,
    pub granted_abilities: Vec<A>,
    #[cfg_attr(feature = "serde", serde(default))]
    pub descriptive: bool,
}

impl<A> BackupEffect<A> {
    pub fn new(amount: u32, granted_abilities: Vec<A>) -> Self {
        Self {
            amount,
            descriptive: false,
            granted_abilities,
        }
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct BeholdEffect {
    pub subtype: Subtype,
    pub count: u32,
    pub chooser: PlayerFilter,
    #[cfg_attr(feature = "serde", serde(default))]
    pub descriptive: bool,
}

impl BeholdEffect {
    pub fn new(subtype: Subtype, count: u32, chooser: PlayerFilter) -> Self {
        Self {
            subtype,
            count,
            chooser,
            descriptive: false,
        }
    }

    pub fn you(subtype: Subtype, count: u32) -> Self {
        Self::new(subtype, count, PlayerFilter::You)
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, Copy, PartialEq, Eq, TagKeyWalk)]
pub enum ClashOpponentMode {
    AnyOpponent,
    TargetOpponent,
    DefendingPlayer,
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct ClashEffect {
    pub opponent_mode: ClashOpponentMode,
    #[cfg_attr(feature = "serde", serde(default))]
    pub descriptive: bool,
}

impl ClashEffect {
    pub fn new(opponent_mode: ClashOpponentMode) -> Self {
        Self { opponent_mode, descriptive: false }
    }

    pub fn against_any_opponent() -> Self {
        Self::new(ClashOpponentMode::AnyOpponent)
    }

    pub fn against_target_opponent() -> Self {
        Self::new(ClashOpponentMode::TargetOpponent)
    }

    pub fn against_defending_player() -> Self {
        Self::new(ClashOpponentMode::DefendingPlayer)
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct EarthbendEffect {
    pub target: ChooseSpec,
    /// Number of +1/+1 counters. Dynamic amounts ("earthbend X, where X is
    /// ...") are computed once as the instruction resolves (CR 107.3a).
    pub counters: Value,
    /// Awaken's land animation (CR 702.113a): the land also becomes an
    /// Elemental, and neither earthbend's return trigger nor its keyword
    /// action applies.
    #[cfg_attr(feature = "serde", serde(default))]
    pub awaken: bool,
    #[cfg_attr(feature = "serde", serde(default))]
    pub descriptive: bool,
}

impl EarthbendEffect {
    pub fn new(target: ChooseSpec, counters: impl Into<Value>) -> Self {
        Self {
            target,
            counters: counters.into(),
            awaken: false,
            descriptive: false,
        }
    }

    /// Awaken N: put N +1/+1 counters on target land you control, which
    /// becomes a 0/0 Elemental creature with haste (CR 702.113a).
    pub fn awaken(target: ChooseSpec, counters: impl Into<Value>) -> Self {
        Self {
            target,
            counters: counters.into(),
            awaken: true,
            descriptive: false,
        }
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct LocalRewriteEffect<E> {
    pub effect: Box<E>,
    pub zone_replacements: Vec<RegisterZoneReplacementEffect>,
}

impl<E> LocalRewriteEffect<E> {
    pub fn new(effect: E, zone_replacements: Vec<RegisterZoneReplacementEffect>) -> Self {
        Self {
            effect: Box::new(effect),
            zone_replacements,
        }
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, Copy, PartialEq, Eq, TagKeyWalk)]
pub enum TaggedLeavesAbilitySource {
    WatchedObject,
    CurrentSource,
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct ScheduleEffectsWhenTaggedLeavesEffect<E> {
    pub tag: crate::tag::TagKey,
    pub effects: Vec<E>,
    pub controller: PlayerFilter,
    pub ability_source: TaggedLeavesAbilitySource,
}

impl<E> ScheduleEffectsWhenTaggedLeavesEffect<E> {
    pub fn new(
        tag: impl Into<crate::tag::TagKey>,
        effects: Vec<E>,
        controller: PlayerFilter,
    ) -> Self {
        Self {
            tag: tag.into(),
            effects,
            controller,
            ability_source: TaggedLeavesAbilitySource::WatchedObject,
        }
    }

    pub fn with_current_source_as_ability_source(mut self) -> Self {
        self.ability_source = TaggedLeavesAbilitySource::CurrentSource;
        self
    }
}

/// Source-level placement of non-keyword abilities granted to a created token.
///
/// Token characteristics alone cannot distinguish `with "..."` from a later
/// `It has "..."` sentence, so the compiler carries that surface choice to the
/// renderer explicitly.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, Copy, PartialEq, Eq, TagKeyWalk)]
pub enum TokenAbilityPresentation {
    InlineWith,
    SeparateSentence,
    SeparateSentenceGain,
    /// The token had no intrinsic abilities before the authored `It has ...`
    /// sentence, so all grouped abilities belong to that single sentence.
    SeparateSentenceCombined,
    /// Gain-verb counterpart of `SeparateSentenceCombined`.
    SeparateSentenceGainCombined,
    InlineWithThenStandalone(usize),
    SeparateSentenceThenStandalone(usize),
    SeparateSentenceGainThenStandalone(usize),
    SeparateSentenceCombinedThenStandalone(usize),
    SeparateSentenceGainCombinedThenStandalone(usize),
    Standalone(usize),
}

impl TokenAbilityPresentation {
    /// Mark an authored post-create ability sentence as containing every
    /// ability currently present on an otherwise ability-free token.
    pub const fn combined_separate_sentence(self) -> Self {
        match self {
            Self::SeparateSentence => Self::SeparateSentenceCombined,
            Self::SeparateSentenceGain => Self::SeparateSentenceGainCombined,
            other => other,
        }
    }

    /// Record another authored ability sentence after the token-definition
    /// sentence. The count is presentation-only; all abilities remain on the
    /// token definition for execution.
    pub const fn with_added_standalone_tail(current: Option<Self>) -> Self {
        match current {
            Some(Self::InlineWith) => Self::InlineWithThenStandalone(1),
            Some(Self::SeparateSentence) => Self::SeparateSentenceThenStandalone(1),
            Some(Self::SeparateSentenceGain) => Self::SeparateSentenceGainThenStandalone(1),
            Some(Self::SeparateSentenceCombined) => Self::SeparateSentenceCombinedThenStandalone(1),
            Some(Self::SeparateSentenceGainCombined) => {
                Self::SeparateSentenceGainCombinedThenStandalone(1)
            }
            Some(Self::InlineWithThenStandalone(count)) => {
                Self::InlineWithThenStandalone(count + 1)
            }
            Some(Self::SeparateSentenceThenStandalone(count)) => {
                Self::SeparateSentenceThenStandalone(count + 1)
            }
            Some(Self::SeparateSentenceGainThenStandalone(count)) => {
                Self::SeparateSentenceGainThenStandalone(count + 1)
            }
            Some(Self::SeparateSentenceCombinedThenStandalone(count)) => {
                Self::SeparateSentenceCombinedThenStandalone(count + 1)
            }
            Some(Self::SeparateSentenceGainCombinedThenStandalone(count)) => {
                Self::SeparateSentenceGainCombinedThenStandalone(count + 1)
            }
            Some(Self::Standalone(count)) => Self::Standalone(count + 1),
            None => Self::Standalone(1),
        }
    }

    pub const fn standalone_tail_count(self) -> usize {
        match self {
            Self::InlineWithThenStandalone(count)
            | Self::SeparateSentenceThenStandalone(count)
            | Self::SeparateSentenceGainThenStandalone(count)
            | Self::SeparateSentenceCombinedThenStandalone(count)
            | Self::SeparateSentenceGainCombinedThenStandalone(count)
            | Self::Standalone(count) => count,
            Self::InlineWith
            | Self::SeparateSentence
            | Self::SeparateSentenceGain
            | Self::SeparateSentenceCombined
            | Self::SeparateSentenceGainCombined => 0,
        }
    }

    pub const fn grouped_presentation(self) -> Option<Self> {
        match self {
            Self::InlineWith | Self::InlineWithThenStandalone(_) => Some(Self::InlineWith),
            Self::SeparateSentence | Self::SeparateSentenceThenStandalone(_) => {
                Some(Self::SeparateSentence)
            }
            Self::SeparateSentenceGain | Self::SeparateSentenceGainThenStandalone(_) => {
                Some(Self::SeparateSentenceGain)
            }
            Self::SeparateSentenceCombined | Self::SeparateSentenceCombinedThenStandalone(_) => {
                Some(Self::SeparateSentenceCombined)
            }
            Self::SeparateSentenceGainCombined
            | Self::SeparateSentenceGainCombinedThenStandalone(_) => {
                Some(Self::SeparateSentenceGainCombined)
            }
            Self::Standalone(_) => None,
        }
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Clone, PartialEq, TagKeyWalk)]
pub struct CreateTokenEffect<D> {
    pub token: D,
    /// Authored word roles retained by the creating instruction. Historical
    /// absence is unknown evidence, not an implicit all-authored declaration.
    #[cfg_attr(
        feature = "serde",
        serde(default, skip_serializing_if = "Option::is_none")
    )]
    pub text_roles: Option<crate::TokenTextRoles>,
    /// Evaluated once at creation; these become the token's copiable base values.
    #[cfg_attr(feature = "serde", serde(default))]
    pub dynamic_power_toughness: Option<(Value, Value)>,
    pub count: Value,
    pub controller: PlayerFilter,
    pub controller_target: Option<ChooseSpec>,
    /// Apply the source permanent's chosen color to the token definition as
    /// the token is created.
    pub use_source_chosen_color: bool,
    /// Apply the source permanent's chosen creature type to the token
    /// definition as the token is created.
    pub use_source_chosen_creature_type: bool,
    /// Whether the authored text explicitly named `you` as the actor of the
    /// create action. This is presentation-only; `controller` remains the
    /// semantic source of truth for who creates and controls the token.
    pub actor_surface_explicit: bool,
    pub suppress_aura_attachment_choice: bool,
    pub ability_presentation: Option<TokenAbilityPresentation>,
    pub enters_tapped: bool,
    pub enters_attacking: bool,
    /// When present, each created token enters attacking this player (or a
    /// legal planeswalker they control, depending on the mode) instead of
    /// copying the originating attacker's target.
    pub attack_target_mode: Option<CopyAttackTargetMode>,
    /// "a token that's blocking <that creature>" (CR 509.1, 506.3e): each
    /// created token enters blocking this attacking creature.
    #[cfg_attr(feature = "serde", serde(default))]
    pub enters_blocking: Option<ChooseSpec>,
    pub exile_at_end_of_combat: bool,
    pub sacrifice_at_end_of_combat: bool,
    pub sacrifice_at_next_end_step: bool,
    pub exile_at_next_end_step: bool,
    pub next_end_step_player: PlayerFilter,
    /// The token's text refers to cards this resolution exiled with its
    /// source ("return the exiled card"): link those cards to each created
    /// token so its own abilities can find them (CR 607.2a).
    #[cfg_attr(feature = "serde", serde(default))]
    pub link_source_exiled_this_resolution: bool,
    /// A singular authored exile binds only its final exact result, including
    /// within a sequential foreach. Never fall back to an earlier surviving card.
    #[cfg_attr(feature = "serde", serde(default))]
    pub link_only_last_source_exiled: bool,
    /// Counters each created token enters the battlefield with ("a 0/0
    /// token with two +1/+1 counters on it", "The token enters with X
    /// +1/+1 counters on it"). They are part of the entry event (CR 122.6),
    /// not a later put.
    #[cfg_attr(
        feature = "serde",
        serde(default, skip_serializing_if = "Vec::is_empty")
    )]
    pub entry_counters: Vec<BattlefieldEntryCounterSpec>,
    /// "tokens ... that attack that opponent this turn if able" (CR
    /// 508.1d): each created token must attack this player this turn.
    #[cfg_attr(
        feature = "serde",
        serde(default, skip_serializing_if = "Option::is_none")
    )]
    pub must_attack_player_this_turn: Option<PlayerFilter>,
}

impl<D: std::fmt::Debug> std::fmt::Debug for CreateTokenEffect<D> {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        let mut debug = f.debug_struct("CreateTokenEffect");
        debug.field("token", &self.token);
        // Unstamped native trigger identities still hash effect Debug. Keep
        // absent historical evidence byte-identical to the old field order.
        if self.text_roles.is_some() {
            debug.field("text_roles", &self.text_roles);
        }
        if self.dynamic_power_toughness.is_some() {
            debug.field("dynamic_power_toughness", &self.dynamic_power_toughness);
        }
        debug
            .field("count", &self.count)
            .field("controller", &self.controller)
            .field("controller_target", &self.controller_target)
            .field("use_source_chosen_color", &self.use_source_chosen_color)
            .field(
                "use_source_chosen_creature_type",
                &self.use_source_chosen_creature_type,
            )
            .field("actor_surface_explicit", &self.actor_surface_explicit)
            .field(
                "suppress_aura_attachment_choice",
                &self.suppress_aura_attachment_choice,
            )
            .field("ability_presentation", &self.ability_presentation)
            .field("enters_tapped", &self.enters_tapped)
            .field("enters_attacking", &self.enters_attacking)
            .field("attack_target_mode", &self.attack_target_mode)
            .field("enters_blocking", &self.enters_blocking)
            .field("exile_at_end_of_combat", &self.exile_at_end_of_combat)
            .field(
                "sacrifice_at_end_of_combat",
                &self.sacrifice_at_end_of_combat,
            )
            .field(
                "sacrifice_at_next_end_step",
                &self.sacrifice_at_next_end_step,
            )
            .field("exile_at_next_end_step", &self.exile_at_next_end_step)
            .field("next_end_step_player", &self.next_end_step_player)
            .field(
                "link_source_exiled_this_resolution",
                &self.link_source_exiled_this_resolution,
            )
            .field("link_only_last_source_exiled", &self.link_only_last_source_exiled);
        // Absent entry counters keep the historical Debug bytes.
        if !self.entry_counters.is_empty() {
            debug.field("entry_counters", &self.entry_counters);
        }
        if self.must_attack_player_this_turn.is_some() {
            debug.field(
                "must_attack_player_this_turn",
                &self.must_attack_player_this_turn,
            );
        }
        debug.finish()
    }
}

impl<D> CreateTokenEffect<D> {
    pub fn new(token: D, count: impl Into<Value>, controller: PlayerFilter) -> Self {
        let count = count.into();
        let controller_target = match &controller {
            PlayerFilter::Target(filter) => {
                Some(ChooseSpec::target(ChooseSpec::Player((**filter).clone())))
            }
            _ => None,
        };
        Self {
            token,
            text_roles: None,
            dynamic_power_toughness: None,
            count,
            controller,
            controller_target,
            use_source_chosen_color: false,
            use_source_chosen_creature_type: false,
            actor_surface_explicit: false,
            suppress_aura_attachment_choice: false,
            ability_presentation: None,
            enters_tapped: false,
            enters_attacking: false,
            attack_target_mode: None,
            enters_blocking: None,
            exile_at_end_of_combat: false,
            sacrifice_at_end_of_combat: false,
            sacrifice_at_next_end_step: false,
            exile_at_next_end_step: false,
            next_end_step_player: PlayerFilter::Any,
            link_source_exiled_this_resolution: false,
            link_only_last_source_exiled: false,
            entry_counters: Vec::new(),
            must_attack_player_this_turn: None,
        }
    }

    pub fn with_entry_counter(mut self, counter: BattlefieldEntryCounterSpec) -> Self {
        self.entry_counters.push(counter);
        self
    }

    pub fn linking_source_exiled_this_resolution(mut self) -> Self {
        self.link_source_exiled_this_resolution = true;
        self
    }

    pub fn with_text_roles(mut self, roles: crate::TokenTextRoles) -> Self {
        self.text_roles = Some(roles);
        self
    }

    pub fn you(token: D, count: impl Into<Value>) -> Self {
        Self::new(token, count, PlayerFilter::You)
    }

    pub fn one(token: D) -> Self {
        Self::you(token, 1)
    }

    pub fn with_explicit_actor_surface(mut self) -> Self {
        self.actor_surface_explicit = true;
        self
    }

    pub fn with_source_chosen_color(mut self) -> Self {
        self.use_source_chosen_color = true;
        self
    }

    pub fn with_source_chosen_creature_type(mut self) -> Self {
        self.use_source_chosen_creature_type = true;
        self
    }

    pub fn tapped(mut self) -> Self {
        self.enters_tapped = true;
        self
    }

    pub fn attacking(mut self) -> Self {
        self.enters_attacking = true;
        self
    }

    pub fn attack_target_mode(mut self, mode: CopyAttackTargetMode) -> Self {
        self.enters_attacking = true;
        self.attack_target_mode = Some(mode);
        self
    }

    pub fn attacking_player(mut self, player: PlayerFilter) -> Self {
        self.enters_attacking = true;
        self.attack_target_mode = Some(CopyAttackTargetMode::Player(player));
        self
    }

    pub fn attacking_player_or_planeswalker_controlled_by(mut self, player: PlayerFilter) -> Self {
        self.enters_attacking = true;
        self.attack_target_mode = Some(CopyAttackTargetMode::PlayerOrPlaneswalkerControlledBy(
            player,
        ));
        self
    }

    pub fn blocking(mut self, attacker: ChooseSpec) -> Self {
        self.enters_blocking = Some(attacker);
        self
    }

    pub fn suppress_aura_attachment_choice(mut self) -> Self {
        self.suppress_aura_attachment_choice = true;
        self
    }

    pub fn with_ability_presentation(mut self, presentation: TokenAbilityPresentation) -> Self {
        self.ability_presentation = Some(presentation);
        self
    }

    pub fn exile_at_end_of_combat(mut self) -> Self {
        self.exile_at_end_of_combat = true;
        self
    }

    pub fn sacrifice_at_end_of_combat(mut self) -> Self {
        self.sacrifice_at_end_of_combat = true;
        self
    }

    pub fn sacrifice_at_next_end_step(mut self) -> Self {
        self.sacrifice_at_next_end_step = true;
        self
    }

    pub fn exile_at_next_end_step(mut self) -> Self {
        self.exile_at_next_end_step = true;
        self
    }

    pub fn next_end_step_player(mut self, player: PlayerFilter) -> Self {
        self.next_end_step_player = player;
        self
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct IncubateEffect {
    pub amount: Value,
    pub count: Value,
    pub controller: PlayerFilter,
    #[cfg_attr(feature = "serde", serde(default))]
    pub descriptive: bool,
    pub controller_target: Option<ChooseSpec>,
}

impl IncubateEffect {
    pub fn new(
        amount: impl Into<Value>,
        count: impl Into<Value>,
        controller: PlayerFilter,
    ) -> Self {
        let controller_target = match &controller {
            PlayerFilter::Target(filter) => {
                Some(ChooseSpec::target(ChooseSpec::Player((**filter).clone())))
            }
            _ => None,
        };
        Self {
            descriptive: false,
            amount: amount.into(),
            count: count.into(),
            controller,
            controller_target,
        }
    }

    pub fn as_described(mut self, descriptive: bool) -> Self {
        self.descriptive = descriptive;
        self
    }

    pub fn you(amount: impl Into<Value>, count: impl Into<Value>) -> Self {
        Self::new(amount, count, PlayerFilter::You)
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub enum CopyPtAdjustment {
    HalfRoundUp,
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub enum CopyAttackTargetMode {
    Player(PlayerFilter),
    PlayerOrPlaneswalkerControlledBy(PlayerFilter),
}

/// Authored anaphor used by a sentence that follows a token-copy action.
///
/// `They` is grammatical-role aware: renderers use `they` as a subject and
/// `them` as an object. Keeping this typed lets the semantic model continue to
/// fold token follow-ups into the copy effect without losing their surface.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, Copy, PartialEq, Eq, TagKeyWalk)]
pub enum TokenCopyReferenceSurface {
    It,
    They,
    ThatToken,
    ThoseTokens,
    TheToken,
    TheTokens,
    TokenCreatedThisWay,
    TokensCreatedThisWay,
}

impl TokenCopyReferenceSurface {
    pub fn is_plural(self) -> bool {
        matches!(
            self,
            Self::They | Self::ThoseTokens | Self::TheTokens | Self::TokensCreatedThisWay
        )
    }
}

/// The keyword action that created a token. This is history, not a copiable characteristic.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, Copy, PartialEq, Eq, TagKeyWalk)]
pub enum TokenCreationMethod { Embalm, Eternalize }

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct CreateTokenCopyEffect<A> {
    #[cfg_attr(feature = "serde", serde(default))]
    pub creation_method: Option<TokenCreationMethod>,
    pub target: ChooseSpec,
    pub count: Value,
    pub controller: PlayerFilter,
    pub enters_tapped: bool,
    pub has_haste: bool,
    /// `None` means haste was authored as an inline copy exception. `Some`
    /// records the subject of a separate post-create haste sentence.
    pub haste_followup_reference_surface: Option<TokenCopyReferenceSurface>,
    pub enters_attacking: bool,
    /// The entry state was authored as a separate token-followup sentence.
    pub entry_tapped_attacking_followup: bool,
    pub attack_target_mode: Option<CopyAttackTargetMode>,
    /// A requirement to attack the resolved player this turn, without entering attacking.
    #[cfg_attr(feature = "serde", serde(default))]
    pub must_attack_player_this_turn: Option<PlayerFilter>,
    pub exile_at_end_of_combat: bool,
    pub exile_at_end_of_combat_reference_surface: Option<TokenCopyReferenceSurface>,
    /// "except it has haste and loses soulbond" (Mirage Phalanx): the copy is
    /// created without the soulbond pairing ability.
    pub loses_soulbond: bool,
    /// Remove only authored ability groups with these designations from the
    /// token's copiable values, including their independent identity markers.
    #[cfg_attr(feature = "serde", serde(default, skip_serializing_if = "Vec::is_empty"))]
    pub removed_ability_designations: Vec<String>,
    /// Ordinary layer-six loss starts before entry; it does not erase copied
    /// rules text and expires according to its authored duration.
    #[cfg_attr(feature = "serde", serde(default, skip_serializing_if = "Option::is_none"))]
    pub ability_loss_until: Option<Until>,
    pub sacrifice_at_next_end_step: bool,
    pub sacrifice_at_next_end_step_reference_surface: Option<TokenCopyReferenceSurface>,
    /// Original quoted copiable ability text when the cleanup instruction was
    /// granted to the token as part of the copy exception.
    pub sacrifice_at_next_end_step_ability_text: Option<String>,
    pub exile_at_next_end_step: bool,
    pub exile_at_next_end_step_reference_surface: Option<TokenCopyReferenceSurface>,
    pub next_end_step_player: PlayerFilter,
    pub pt_adjustment: Option<CopyPtAdjustment>,
    pub clear_mana_cost: bool,
    pub added_card_types: Vec<CardType>,
    pub added_subtypes: Vec<Subtype>,
    pub removed_supertypes: Vec<Supertype>,
    /// CR 707.9b copy exception "except it's legendary": added supertypes.
    #[cfg_attr(feature = "serde", serde(default))]
    pub added_supertypes: Vec<Supertype>,
    /// CR 707.9b copy exception "except its name is X" / "named X".
    #[cfg_attr(feature = "serde", serde(default))]
    pub set_name: Option<String>,
    pub set_base_power_toughness: Option<(i32, i32)>,
    /// Dynamic copiable base power/toughness values evaluated as the token is
    /// created. This is distinct from a later continuous-effect modification:
    /// the resolved values are part of the token's copy exception.
    pub set_base_power_toughness_value: Option<(Value, Value)>,
    /// Explicit starting loyalty authored as part of the copy exception.
    /// This replaces both the copied base loyalty and the initial loyalty
    /// counters on the created token.
    pub starting_loyalty: Option<u32>,
    pub set_colors: Option<ColorSet>,
    /// CR 707.9b: "... black Zombie in addition to its other colors and
    /// types": colors added to the copied colors (not replacing them).
    #[cfg_attr(
        feature = "serde",
        serde(default, skip_serializing_if = "color_set_is_empty")
    )]
    pub added_colors: ColorSet,
    pub set_card_types: Option<Vec<CardType>>,
    pub set_subtypes: Option<Vec<Subtype>>,
    /// A replacement creature-type list preserves unrelated subtype families.
    #[cfg_attr(feature = "serde", serde(default))]
    pub preserve_noncreature_subtypes: bool,
    pub granted_static_abilities: Vec<A>,
    /// Counters each created token enters the battlefield with ("The token
    /// enters with half that many +1/+1 counters on it, rounded down"). They
    /// are part of the entry event (CR 122.6), not a later put.
    #[cfg_attr(
        feature = "serde",
        serde(default, skip_serializing_if = "Vec::is_empty")
    )]
    pub entry_counters: Vec<BattlefieldEntryCounterSpec>,
    /// CR 509.4: the attacking creature each copy enters blocking ("a token
    /// that's a copy of that creature and that's blocking that creature").
    #[cfg_attr(feature = "serde", serde(default, skip_serializing_if = "Option::is_none"))]
    pub enters_blocking: Option<ChooseSpec>,
    /// "a token that's a copy of that Aura attached to that creature": a
    /// following attach instruction places the copy, so an Aura copy's
    /// controller doesn't choose what it enchants as it enters.
    #[cfg_attr(feature = "serde", serde(default))]
    pub suppress_aura_attachment_choice: bool,
}

#[cfg(feature = "serde")]
fn color_set_is_empty(colors: &ColorSet) -> bool {
    colors.is_empty()
}

impl<A> CreateTokenCopyEffect<A> {
    pub fn created_by(mut self, method: TokenCreationMethod) -> Self {
        self.creation_method = Some(method);
        self
    }

    pub fn new(target: ChooseSpec, count: impl Into<Value>, controller: PlayerFilter) -> Self {
        Self {
            creation_method: None,
            target,
            count: count.into(),
            controller,
            enters_tapped: false,
            has_haste: false,
            haste_followup_reference_surface: None,
            enters_attacking: false,
            entry_tapped_attacking_followup: false,
            attack_target_mode: None,
            must_attack_player_this_turn: None,
            exile_at_end_of_combat: false,
            exile_at_end_of_combat_reference_surface: None,
            loses_soulbond: false,
            removed_ability_designations: Vec::new(),
            ability_loss_until: None,
            sacrifice_at_next_end_step: false,
            sacrifice_at_next_end_step_reference_surface: None,
            sacrifice_at_next_end_step_ability_text: None,
            exile_at_next_end_step: false,
            exile_at_next_end_step_reference_surface: None,
            next_end_step_player: PlayerFilter::Any,
            pt_adjustment: None,
            clear_mana_cost: false,
            added_card_types: Vec::new(),
            added_subtypes: Vec::new(),
            removed_supertypes: Vec::new(),
            added_supertypes: Vec::new(),
            set_name: None,
            set_base_power_toughness: None,
            set_base_power_toughness_value: None,
            starting_loyalty: None,
            set_colors: None,
            added_colors: ColorSet::new(),
            set_card_types: None,
            set_subtypes: None,
            preserve_noncreature_subtypes: false,
            granted_static_abilities: Vec::new(),
            entry_counters: Vec::new(),
            enters_blocking: None,
            suppress_aura_attachment_choice: false,
        }
    }

    pub fn one(target: ChooseSpec) -> Self {
        Self::new(target, 1, PlayerFilter::You)
    }

    pub fn with_haste(target: ChooseSpec) -> Self {
        let mut effect = Self::one(target);
        effect.has_haste = true;
        effect
    }

    pub fn tapped(target: ChooseSpec) -> Self {
        let mut effect = Self::one(target);
        effect.enters_tapped = true;
        effect
    }

    pub fn kiki_jiki_style(target: ChooseSpec) -> Self {
        let mut effect = Self::one(target);
        effect.has_haste = true;
        effect.exile_at_end_of_combat = true;
        effect
    }

    pub fn enters_tapped(mut self, value: bool) -> Self {
        self.enters_tapped = value;
        self
    }

    pub fn haste(mut self, value: bool) -> Self {
        self.has_haste = value;
        self
    }

    pub fn haste_followup_reference_surface(
        mut self,
        surface: Option<TokenCopyReferenceSurface>,
    ) -> Self {
        self.haste_followup_reference_surface = surface;
        self
    }

    pub fn attacking(mut self, value: bool) -> Self {
        self.enters_attacking = value;
        if !value {
            self.attack_target_mode = None;
        }
        self
    }

    pub fn attack_target_mode(mut self, mode: CopyAttackTargetMode) -> Self {
        self.enters_attacking = true;
        self.attack_target_mode = Some(mode);
        self
    }

    pub fn attacking_player_or_planeswalker_controlled_by(mut self, player: PlayerFilter) -> Self {
        self.enters_attacking = true;
        self.attack_target_mode = Some(CopyAttackTargetMode::PlayerOrPlaneswalkerControlledBy(
            player,
        ));
        self
    }

    pub fn attacking_player(mut self, player: PlayerFilter) -> Self {
        self.enters_attacking = true;
        self.attack_target_mode = Some(CopyAttackTargetMode::Player(player));
        self
    }

    pub fn exile_at_eoc(mut self, value: bool) -> Self {
        self.exile_at_end_of_combat = value;
        self
    }

    pub fn exile_at_end_of_combat_reference_surface(
        mut self,
        surface: Option<TokenCopyReferenceSurface>,
    ) -> Self {
        self.exile_at_end_of_combat_reference_surface = surface;
        self
    }

    pub fn loses_soulbond(mut self, value: bool) -> Self {
        self.loses_soulbond = value;
        self
    }

    pub fn sacrifice_at_next_end_step(mut self, value: bool) -> Self {
        self.sacrifice_at_next_end_step = value;
        self
    }

    pub fn sacrifice_at_next_end_step_reference_surface(
        mut self,
        surface: Option<TokenCopyReferenceSurface>,
    ) -> Self {
        self.sacrifice_at_next_end_step_reference_surface = surface;
        self
    }

    pub fn sacrifice_at_next_end_step_ability_text(mut self, text: Option<String>) -> Self {
        self.sacrifice_at_next_end_step_ability_text = text;
        self
    }

    pub fn exile_at_next_end_step(mut self, value: bool) -> Self {
        self.exile_at_next_end_step = value;
        self
    }

    pub fn exile_at_next_end_step_reference_surface(
        mut self,
        surface: Option<TokenCopyReferenceSurface>,
    ) -> Self {
        self.exile_at_next_end_step_reference_surface = surface;
        self
    }

    pub fn next_end_step_player(mut self, player: PlayerFilter) -> Self {
        self.next_end_step_player = player;
        self
    }

    pub fn half_power_toughness_round_up(mut self) -> Self {
        self.pt_adjustment = Some(CopyPtAdjustment::HalfRoundUp);
        self
    }

    pub fn without_mana_cost(mut self) -> Self {
        self.clear_mana_cost = true;
        self
    }

    pub fn added_card_type(mut self, card_type: CardType) -> Self {
        if !self.added_card_types.contains(&card_type) {
            self.added_card_types.push(card_type);
        }
        self
    }

    pub fn added_subtype(mut self, subtype: Subtype) -> Self {
        if !self.added_subtypes.contains(&subtype) {
            self.added_subtypes.push(subtype);
        }
        self
    }

    pub fn removed_supertype(mut self, supertype: Supertype) -> Self {
        if !self.removed_supertypes.contains(&supertype) {
            self.removed_supertypes.push(supertype);
        }
        self
    }

    pub fn set_base_power_toughness(mut self, power: i32, toughness: i32) -> Self {
        self.set_base_power_toughness = Some((power, toughness));
        self.set_base_power_toughness_value = None;
        self
    }

    pub fn set_base_power_toughness_value(
        mut self,
        power: impl Into<Value>,
        toughness: impl Into<Value>,
    ) -> Self {
        self.set_base_power_toughness = None;
        self.set_base_power_toughness_value = Some((power.into(), toughness.into()));
        self
    }

    pub fn starting_loyalty(mut self, loyalty: u32) -> Self {
        self.starting_loyalty = Some(loyalty);
        self
    }

    pub fn set_colors(mut self, colors: ColorSet) -> Self {
        self.set_colors = Some(colors);
        self
    }

    pub fn added_colors(mut self, colors: ColorSet) -> Self {
        self.added_colors = self.added_colors.union(colors);
        self
    }

    pub fn set_card_types(mut self, card_types: Vec<CardType>) -> Self {
        self.set_card_types = Some(card_types);
        self
    }

    pub fn set_creature_subtypes(mut self, subtypes: Vec<Subtype>) -> Self {
        self.set_subtypes = Some(subtypes);
        self.preserve_noncreature_subtypes = true;
        self
    }

    pub fn set_subtypes(mut self, subtypes: Vec<Subtype>) -> Self {
        self.set_subtypes = Some(subtypes);
        self.preserve_noncreature_subtypes = false;
        self
    }

    pub fn grant_static_ability(mut self, ability: A) -> Self {
        self.granted_static_abilities.push(ability);
        self
    }

    pub fn with_entry_counter(mut self, counter: BattlefieldEntryCounterSpec) -> Self {
        self.entry_counters.push(counter);
        self
    }
}

/// The event that owns a one-shot next-spell grant. Timing permissions do
/// not add the flash keyword to the chosen object.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq, TagKeyWalk)]
pub enum NextSpellGrantMode {
    #[default]
    Ability,
    CastTiming,
    PlayTiming,
    /// Noncopiable static rider attached to the chosen spell incarnation.
    IncarnationAbility,
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct GrantNextSpellAbilityEffect<A> {
    /// Apply independently to every matching cast before the turn expires.
    #[cfg_attr(feature = "serde", serde(default))]
    pub repeat_for_turn: bool,
    pub player: PlayerFilter,
    pub filter: ObjectFilter,
    pub ability: A,
    #[cfg_attr(feature = "serde", serde(default))]
    pub mode: NextSpellGrantMode,
}

impl<A> GrantNextSpellAbilityEffect<A> {
    pub fn new(player: PlayerFilter, filter: ObjectFilter, ability: A) -> Self {
        Self {
            player,
            filter,
            ability,
            mode: NextSpellGrantMode::Ability,
            repeat_for_turn: false,
        }
    }

    pub fn with_repeat_for_turn(mut self, repeat: bool) -> Self { self.repeat_for_turn=repeat; self }

    pub fn with_mode(mut self, mode: NextSpellGrantMode) -> Self {
        self.mode = mode;
        self
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Clone, PartialEq, TagKeyWalk)]
pub struct RetargetStackObjectEffect {
    pub target: ChooseSpec,
    pub mode: RetargetMode,
    pub chooser: PlayerFilter,
    pub require_change: bool,
    pub new_target_restriction: Option<NewTargetRestriction>,
    /// The authored back-reference named a plural set of spell or ability
    /// copies ("the copies") rather than one copy.
    ///
    /// The target tag preserves identity but cannot preserve this surface:
    /// one delayed copy instruction may produce copies over several trigger
    /// events even when its per-event copy count is one.
    pub copy_reference_plural: bool,
    /// "Changing targets this way doesn't trigger abilities of permanents
    /// named <this card>" (Psychic Battle): the targets this change chooses
    /// don't trigger abilities of sources with the resolving source's name.
    /// Appended with a serde default; omitted from Debug when false.
    #[cfg_attr(feature = "serde", serde(default, skip_serializing_if = "std::ops::Not::not"))]
    pub doesnt_trigger_same_named_sources: bool,
    /// "reselect the targets at random" (Chef's Kiss, Grip of Chaos): each
    /// target slot is refilled uniformly at random from its legal targets
    /// (after `new_target_restriction`) instead of by the chooser. Appended
    /// with a serde default; omitted from Debug when false.
    #[cfg_attr(feature = "serde", serde(default, skip_serializing_if = "std::ops::Not::not"))]
    pub random_targets: bool,
}

impl std::fmt::Debug for RetargetStackObjectEffect {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        let mut debug = f.debug_struct("RetargetStackObjectEffect");
        debug
            .field("target", &self.target)
            .field("mode", &self.mode)
            .field("chooser", &self.chooser)
            .field("require_change", &self.require_change)
            .field("new_target_restriction", &self.new_target_restriction)
            .field("copy_reference_plural", &self.copy_reference_plural);
        if self.doesnt_trigger_same_named_sources {
            debug.field(
                "doesnt_trigger_same_named_sources",
                &self.doesnt_trigger_same_named_sources,
            );
        }
        if self.random_targets {
            debug.field("random_targets", &self.random_targets);
        }
        debug.finish()
    }
}

impl RetargetStackObjectEffect {
    pub fn new(target: ChooseSpec) -> Self {
        Self {
            target,
            mode: RetargetMode::All,
            chooser: PlayerFilter::You,
            require_change: false,
            new_target_restriction: None,
            copy_reference_plural: false,
            doesnt_trigger_same_named_sources: false,
            random_targets: false,
        }
    }

    /// Reselect every target at random from the legal targets.
    pub fn at_random(mut self) -> Self {
        self.random_targets = true;
        self
    }

    pub fn without_triggering_same_named_sources(mut self) -> Self {
        self.doesnt_trigger_same_named_sources = true;
        self
    }

    pub fn with_mode(mut self, mode: RetargetMode) -> Self {
        self.mode = mode;
        self
    }

    pub fn with_chooser(mut self, chooser: PlayerFilter) -> Self {
        self.chooser = chooser;
        self
    }

    pub fn require_change(mut self) -> Self {
        self.require_change = true;
        self
    }

    pub fn with_restriction(mut self, restriction: NewTargetRestriction) -> Self {
        self.new_target_restriction = Some(restriction);
        self
    }

    pub fn with_plural_copy_reference(mut self) -> Self {
        self.copy_reference_plural = true;
        self
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Clone, PartialEq, TagKeyWalk)]
pub struct ExileEffect {
    pub spec: ChooseSpec,
    pub face_down: bool,
    /// Looking at an object in its earlier zone does not by itself authorize
    /// inspecting this face-down exile incarnation. New paired hand-exile
    /// producers use explicit static entitlements rather than chooser memory.
    #[cfg_attr(
        feature = "serde",
        serde(default, skip_serializing_if = "exile_keeps_prior_zone_viewers")
    )]
    pub exclude_prior_zone_viewers: bool,
    /// The exiled card grants the source permanent's current controller
    /// permission to look at it (for example, CR 702.75a Hideaway).
    #[cfg_attr(feature = "serde", serde(default))]
    pub source_controller_may_look: bool,
    /// Preserve an authored instruction to turn an already face-down object
    /// face up as it is exiled. Exile's rules semantics already expose the
    /// card; this flag retains only the explicit action surface.
    pub turn_face_up: bool,
    /// Retain exact original exile arrivals on the source before added actions.
    #[cfg_attr(feature = "serde", serde(default))]
    pub remember_on_source: bool,
    /// The player who performs this exile when the instruction names one
    /// ("that player exiles ..."). `None` is the instruction's controller.
    /// Recorded per exiled card as its exiler for its source link.
    #[cfg_attr(feature = "serde", serde(default, skip_serializing_if = "Option::is_none"))]
    pub actor: Option<PlayerFilter>,
}

impl std::fmt::Debug for ExileEffect {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        let mut debug = f.debug_struct("ExileEffect");
        debug
            .field("spec", &self.spec)
            .field("face_down", &self.face_down)
            .field("exclude_prior_zone_viewers", &self.exclude_prior_zone_viewers)
            .field("source_controller_may_look", &self.source_controller_may_look)
            .field("turn_face_up", &self.turn_face_up)
            .field("remember_on_source", &self.remember_on_source);
        // Unstamped native trigger identities still hash effect Debug. Keep
        // an absent actor byte-identical to the historical field list.
        if let Some(actor) = &self.actor {
            debug.field("actor", actor);
        }
        debug.finish()
    }
}

#[cfg(feature = "serde")]
fn exile_keeps_prior_zone_viewers(exclude: &bool) -> bool {
    !*exclude
}

impl ExileEffect {
    pub fn with_spec(spec: ChooseSpec) -> Self {
        Self {
            spec,
            face_down: false,
            exclude_prior_zone_viewers: false,
            source_controller_may_look: false,
            turn_face_up: false,
            remember_on_source: false,
            actor: None,
        }
    }

    /// "<player> exiles ...": the named player performs the exile.
    pub fn with_actor(mut self, actor: PlayerFilter) -> Self {
        self.actor = Some(actor);
        self
    }

    pub fn with_face_down(mut self, face_down: bool) -> Self {
        self.face_down = face_down;
        self
    }

    pub fn with_source_controller_look(mut self) -> Self {
        self.source_controller_may_look = true;
        self
    }

    pub fn turn_face_up(mut self) -> Self {
        self.turn_face_up = true;
        self
    }

    pub fn target(spec: ChooseSpec) -> Self {
        Self::with_spec(ChooseSpec::target(spec))
    }

    pub fn targets(spec: ChooseSpec, count: ChoiceCount) -> Self {
        Self::with_spec(ChooseSpec::target(spec).with_count(count))
    }

    pub fn all(filter: ObjectFilter) -> Self {
        Self::with_spec(ChooseSpec::all(filter))
    }

    pub fn creature() -> Self {
        Self::target(ChooseSpec::creature())
    }

    pub fn permanent() -> Self {
        Self::target(ChooseSpec::permanent())
    }

    pub fn any_number(target: ChooseSpec) -> Self {
        Self::targets(target, ChoiceCount::any_number())
    }

    pub fn specific(object_id: crate::ids::ObjectId) -> Self {
        Self::with_spec(ChooseSpec::SpecificObject(object_id))
    }

    pub fn creatures() -> Self {
        Self::all(ObjectFilter::creature())
    }

    pub fn nonland_permanents() -> Self {
        Self::all(ObjectFilter::nonland_permanent())
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Clone, PartialEq, TagKeyWalk)]
pub struct TagMatchingObjectsEffect {
    pub filter: ObjectFilter,
    pub zone: Option<crate::zone::Zone>,
    pub additional_zones: Vec<crate::zone::Zone>,
    pub tag: crate::tag::TagKey,
    /// When nonempty, build the output from these existing tagged snapshots
    /// instead of rescanning the current game zones. This is used for unions
    /// of objects that were actually affected by preceding effects, including
    /// objects that have since changed zones.
    pub source_tags: Vec<crate::tag::TagKey>,
    /// Remove every current candidate whose physical card was captured by
    /// one of these tags. This is for complements such as "the other cards":
    /// a redirected zone move can leave the selected card in the pool under
    /// a new object ID, but it remains the selected physical card.
    #[cfg_attr(feature = "serde", serde(default))]
    pub excluded_stable_card_tags: Vec<crate::tag::TagKey>,
    /// Apply `filter` to the captured snapshots before retaining the union.
    /// Legacy unions use the filter only as descriptive provenance.
    #[cfg_attr(feature = "serde", serde(default))]
    pub filter_source_snapshots: bool,
}

impl std::fmt::Debug for TagMatchingObjectsEffect {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        let mut debug = f.debug_struct("TagMatchingObjectsEffect");
        debug
            .field("filter", &self.filter)
            .field("zone", &self.zone)
            .field("additional_zones", &self.additional_zones)
            .field("tag", &self.tag);
        if !self.source_tags.is_empty() {
            debug.field("source_tags", &self.source_tags);
        }
        if !self.excluded_stable_card_tags.is_empty() {
            debug.field("excluded_stable_card_tags", &self.excluded_stable_card_tags);
        }
        if self.filter_source_snapshots {
            debug.field("filter_source_snapshots", &true);
        }
        debug.finish()
    }
}

impl TagMatchingObjectsEffect {
    pub fn new(filter: ObjectFilter, tag: impl Into<crate::tag::TagKey>) -> Self {
        Self {
            filter,
            zone: None,
            additional_zones: Vec::new(),
            tag: tag.into(),
            source_tags: Vec::new(),
            excluded_stable_card_tags: Vec::new(),
            filter_source_snapshots: false,
        }
    }

    pub fn excluding_stable_cards_tagged(
        mut self,
        tag: impl Into<crate::tag::TagKey>,
    ) -> Self {
        let tag = tag.into();
        if !self.excluded_stable_card_tags.contains(&tag) {
            self.excluded_stable_card_tags.push(tag);
        }
        self
    }

    /// Use the union of existing tagged snapshots as this capture's source.
    /// The filter and zones remain descriptive metadata for later consumers
    /// and compiled-text rendering.
    pub fn from_tagged_sources(
        mut self,
        source_tags: impl IntoIterator<Item = crate::tag::TagKey>,
    ) -> Self {
        self.source_tags = source_tags.into_iter().collect();
        self
    }

    pub fn from_filtered_tagged_sources(
        mut self,
        source_tags: impl IntoIterator<Item = crate::tag::TagKey>,
    ) -> Self {
        self.source_tags = source_tags.into_iter().collect();
        self.filter_source_snapshots = true;
        self
    }

    pub fn in_zone(mut self, zone: crate::zone::Zone) -> Self {
        self.zone = Some(zone);
        self.additional_zones.clear();
        self
    }

    pub fn in_zones(mut self, zones: Vec<crate::zone::Zone>) -> Self {
        let mut iter = zones.into_iter();
        if let Some(first) = iter.next() {
            self.zone = Some(first);
            self.additional_zones = iter.collect();
        } else {
            self.zone = None;
            self.additional_zones.clear();
        }
        self
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct SacrificeTargetEffect {
    pub target: ChooseSpec,
    /// The player who sacrifices, when the text names one. CR 701.21a: a
    /// player can sacrifice only a permanent they control, so "sacrifice it"
    /// does nothing once another player controls it. `None` keeps the legacy
    /// meaning (the object's controller sacrifices it).
    #[cfg_attr(feature = "serde", serde(default))]
    pub player: Option<PlayerFilter>,
}

impl SacrificeTargetEffect {
    pub fn new(target: ChooseSpec) -> Self {
        Self {
            target,
            player: None,
        }
    }

    pub fn with_player(mut self, player: PlayerFilter) -> Self {
        self.player = Some(player);
        self
    }

    pub fn source() -> Self {
        Self::new(ChooseSpec::Source)
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct ExileTaggedWhenSourceLeavesEffect {
    pub tag: crate::tag::TagKey,
    pub controller: PlayerFilter,
}

impl ExileTaggedWhenSourceLeavesEffect {
    pub fn new(tag: impl Into<crate::tag::TagKey>, controller: PlayerFilter) -> Self {
        Self {
            tag: tag.into(),
            controller,
        }
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, Copy, PartialEq, Eq, TagKeyWalk)]
pub enum ExileUntilDuration {
    SourceLeavesBattlefield,
    /// Return the exiled object the next time a player who is an opponent of
    /// the effect's controller becomes the monarch.
    OpponentBecomesMonarch,
    NextEndStep,
    EndOfCombat,
    /// The source may start on the stack. Normal resolution preserves exile;
    /// any other stack exit, or its resulting permanent's exit, ends it.
    SourceLeavesStackOrBattlefield,
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct ExileUntilEffect {
    /// Definition-local ownership of a printed permanent spell's exile cost
    /// (CR 607.2q). Ordinary ability admission supplies its own acquisition.
    #[cfg_attr(feature = "serde", serde(default, skip_serializing_if = "Option::is_none"))]
    pub cost_linked_exile_pair: Option<crate::LinkedExilePair>,
    pub spec: ChooseSpec,
    pub duration: ExileUntilDuration,
    /// A separately targeted permanent whose departure ends the duration.
    /// `None` keeps the traditional ability-source watcher.
    pub leave_watcher: Option<ChooseSpec>,
    pub return_zone: crate::zone::Zone,
    pub face_down: bool,
    /// Preserve the older two-sentence Oracle surface that explicitly says
    /// to return the exiled card when the source leaves the battlefield.
    pub explicit_return_surface: bool,
}

impl ExileUntilEffect {
    pub fn new(spec: ChooseSpec, duration: ExileUntilDuration) -> Self {
        Self {
            cost_linked_exile_pair: None,
            spec,
            duration,
            leave_watcher: None,
            return_zone: crate::zone::Zone::Battlefield,
            face_down: false,
            explicit_return_surface: false,
        }
    }

    pub fn with_face_down(mut self, face_down: bool) -> Self {
        self.face_down = face_down;
        self
    }

    pub fn with_leave_watcher(mut self, watcher: ChooseSpec) -> Self {
        self.leave_watcher = Some(watcher);
        self
    }

    pub fn with_explicit_return_surface(mut self, explicit: bool) -> Self {
        self.explicit_return_surface = explicit;
        self
    }

    pub fn source_leaves(spec: ChooseSpec) -> Self {
        Self::new(spec, ExileUntilDuration::SourceLeavesBattlefield)
    }
}

/// Authored presentation of a spell-copy amount whose executable value is
/// stored independently in [`CopySpellEffect::count`].
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, Copy, PartialEq, Eq, TagKeyWalk)]
pub enum CopyCountSurface {
    OncePlusAdditionalPerOpponentWhoCopiedThisWay,
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct CopySpellEffect {
    pub target: ChooseSpec,
    /// The kind named by an authored stack-object back-reference.
    ///
    /// Tagged references intentionally carry identity only, so a phrase such
    /// as "that spell", "that ability", or "that spell or ability" needs
    /// separate typed provenance for compiled-text rendering.
    pub target_reference_kind: Option<StackObjectKind>,
    /// Whether the authored target back-reference was the pronoun `it`.
    ///
    /// Reference resolution may replace the pronoun's internal tag with the
    /// triggering stack-object tag. This independent surface bit preserves
    /// the authored wording without weakening that semantic identity.
    pub target_reference_pronoun: bool,
    pub count: Value,
    pub count_surface: Option<CopyCountSurface>,
    pub copier: PlayerFilter,
    pub removed_supertypes: Vec<Supertype>,
    /// Colors set as part of the copy effect's copiable values.
    pub set_colors: Option<ColorSet>,
    /// Card types added as part of the copy effect's copiable values.
    pub added_card_types: Vec<CardType>,
    /// Subtypes added as part of the copy effect's copiable values.
    pub added_subtypes: Vec<Subtype>,
    /// Base power/toughness set as part of the copy effect's copiable values.
    pub set_base_power_toughness: Option<(i32, i32)>,
    /// Starting loyalty is part of the copy's copiable values, not a counter action.
    #[cfg_attr(feature = "serde", serde(default, skip_serializing_if = "Option::is_none"))]
    pub set_base_loyalty: Option<Value>,
}

impl CopySpellEffect {
    fn target_stack_kind(target: &ChooseSpec) -> Option<StackObjectKind> {
        match target {
            ChooseSpec::SurfaceHinted { spec, .. }
            | ChooseSpec::Target(spec)
            | ChooseSpec::WithCount(spec, _)
            | ChooseSpec::WithCountValue(spec, _, _) => Self::target_stack_kind(spec),
            ChooseSpec::Object(filter) | ChooseSpec::All(filter) => filter.stack_kind,
            _ => None,
        }
    }

    pub fn new(target: ChooseSpec, count: impl Into<Value>) -> Self {
        Self::new_for_player(target, count, PlayerFilter::You)
    }

    pub fn new_for_player(
        target: ChooseSpec,
        count: impl Into<Value>,
        copier: PlayerFilter,
    ) -> Self {
        // A bare stack-object filter in a copy instruction is the target of
        // that instruction. Identity references (source/tagged/iterated) and
        // set-valued `All` specs remain non-targeting, as required by copy
        // triggers and bulk-copy effects.
        let target = if matches!(target.base(), ChooseSpec::Object(filter) if filter.stack_kind.is_some())
        {
            ChooseSpec::target(target)
        } else {
            target
        };
        let target_reference_kind = Self::target_stack_kind(&target);
        Self {
            target,
            target_reference_kind,
            target_reference_pronoun: false,
            count: count.into(),
            count_surface: None,
            copier,
            removed_supertypes: Vec::new(),
            set_colors: None,
            added_card_types: Vec::new(),
            added_subtypes: Vec::new(),
            set_base_power_toughness: None,
            set_base_loyalty: None,
        }
    }

    pub fn single(target: ChooseSpec) -> Self {
        Self::new(target, 1)
    }

    pub fn removed_supertype(mut self, supertype: Supertype) -> Self {
        if !self.removed_supertypes.contains(&supertype) {
            self.removed_supertypes.push(supertype);
        }
        self
    }

    pub fn with_removed_supertypes(mut self, supertypes: Vec<Supertype>) -> Self {
        for supertype in supertypes {
            self = self.removed_supertype(supertype);
        }
        self
    }

    pub fn with_set_colors(mut self, colors: Option<ColorSet>) -> Self {
        self.set_colors = colors;
        self
    }

    pub fn with_added_card_types(mut self, card_types: Vec<CardType>) -> Self {
        for card_type in card_types {
            if !self.added_card_types.contains(&card_type) {
                self.added_card_types.push(card_type);
            }
        }
        self
    }

    pub fn with_added_subtypes(mut self, subtypes: Vec<Subtype>) -> Self {
        for subtype in subtypes {
            if !self.added_subtypes.contains(&subtype) {
                self.added_subtypes.push(subtype);
            }
        }
        self
    }

    pub fn with_set_base_power_toughness(mut self, value: Option<(i32, i32)>) -> Self {
        self.set_base_power_toughness = value;
        self
    }

    pub fn with_set_base_loyalty(mut self, loyalty: impl Into<Value>) -> Self {
        self.set_base_loyalty = Some(loyalty.into());
        self
    }

    pub fn has_characteristic_modifiers(&self) -> bool {
        self.set_colors.is_some()
            || !self.added_card_types.is_empty()
            || !self.added_subtypes.is_empty()
            || self.set_base_power_toughness.is_some()
            || self.set_base_loyalty.is_some()
    }

    pub fn with_count_surface(mut self, surface: CopyCountSurface) -> Self {
        self.count_surface = Some(surface);
        self
    }

    pub fn with_target_reference_kind(mut self, kind: StackObjectKind) -> Self {
        self.target_reference_kind = Some(kind);
        self
    }

    pub fn with_optional_target_reference_kind(mut self, kind: Option<StackObjectKind>) -> Self {
        if let Some(kind) = kind {
            self.target_reference_kind = Some(kind);
        }
        self
    }

    pub fn with_target_reference_pronoun(mut self, pronoun: bool) -> Self {
        self.target_reference_pronoun = pronoun;
        self
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct CopySpellForEachTargetEffect {
    pub target: ChooseSpec,
    pub object_filter: Option<ObjectFilter>,
    pub player_filter: Option<PlayerFilter>,
    pub copier: PlayerFilter,
    pub exclude_current_targets: bool,
    pub removed_supertypes: Vec<Supertype>,
    /// Authored kind of the copied stack-object back-reference ("copy that
    /// ability", "copy that spell or ability"). Runtime identity comes from
    /// `target`; this keeps the printed noun.
    #[cfg_attr(feature = "serde", serde(default, skip_serializing_if = "Option::is_none"))]
    pub target_reference_kind: Option<crate::filter_model::StackObjectKind>,
}

impl CopySpellForEachTargetEffect {
    pub fn new(target: ChooseSpec) -> Self {
        Self {
            target,
            object_filter: None,
            player_filter: None,
            copier: PlayerFilter::You,
            exclude_current_targets: false,
            removed_supertypes: Vec::new(),
            target_reference_kind: None,
        }
    }

    pub fn with_target_reference_kind(
        mut self,
        kind: Option<crate::filter_model::StackObjectKind>,
    ) -> Self {
        self.target_reference_kind = kind;
        self
    }

    pub fn with_object_filter(mut self, filter: ObjectFilter) -> Self {
        self.object_filter = Some(filter);
        self
    }

    pub fn with_player_filter(mut self, filter: PlayerFilter) -> Self {
        self.player_filter = Some(filter);
        self
    }

    pub fn with_copier(mut self, copier: PlayerFilter) -> Self {
        self.copier = copier;
        self
    }

    pub fn exclude_current_targets(mut self, exclude: bool) -> Self {
        self.exclude_current_targets = exclude;
        self
    }

    pub fn removed_supertype(mut self, supertype: Supertype) -> Self {
        if !self.removed_supertypes.contains(&supertype) {
            self.removed_supertypes.push(supertype);
        }
        self
    }

    pub fn with_removed_supertypes(mut self, supertypes: Vec<Supertype>) -> Self {
        for supertype in supertypes {
            self = self.removed_supertype(supertype);
        }
        self
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[cfg_attr(feature = "serde", serde(from = "VariableCasualtyCopyPayload"))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct VariableCasualtyPlaneswalkerCopyEffect {
    pub cost_ref: crate::OptionalCostRef,
}

// The old compatibility payload was a unit value. Fresh builders bind the
// exact printed optional-cost instance; old unit payloads keep the generic ref.
#[cfg(feature = "serde")]
#[derive(serde::Deserialize)]
#[serde(untagged)]
enum VariableCasualtyCopyPayload {
    Bound { cost_ref: crate::OptionalCostRef },
    Legacy(()),
}

#[cfg(feature = "serde")]
impl From<VariableCasualtyCopyPayload> for VariableCasualtyPlaneswalkerCopyEffect {
    fn from(payload: VariableCasualtyCopyPayload) -> Self {
        match payload {
            VariableCasualtyCopyPayload::Bound { cost_ref } => Self { cost_ref },
            VariableCasualtyCopyPayload::Legacy(()) => Self::new(),
        }
    }
}

impl VariableCasualtyPlaneswalkerCopyEffect {
    pub fn new() -> Self {
        Self { cost_ref: crate::OptionalCostRef::from("Casualty") }
    }

    pub fn with_cost_ref(mut self, cost_ref: crate::OptionalCostRef) -> Self {
        self.cost_ref = cost_ref;
        self
    }
}

impl Default for VariableCasualtyPlaneswalkerCopyEffect {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct VoteOption<E> {
    pub name: String,
    pub effects_per_vote: Vec<E>,
}

impl<E> VoteOption<E> {
    pub fn new(name: impl Into<String>, effects_per_vote: Vec<E>) -> Self {
        Self {
            name: name.into(),
            effects_per_vote,
        }
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq)]
#[expect(
    clippy::large_enum_variant,
    reason = "vote choices preserve typed object filters inline"
)]
#[derive(TagKeyWalk)]
pub enum VoteChoice<E> {
    NamedOptions(Vec<VoteOption<E>>),
    Objects {
        filter: ObjectFilter,
        count: ChoiceCount,
    },
    Players {
        filter: PlayerFilter,
        exclude_voter: bool,
    },
}

/// Authored instructions following one vote, in their original order.
/// Voter-dependent instructions retain vote occurrences (including extra
/// votes); other instructions compose ordinary effect programs.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub enum VotePayload<E> {
    ForEachVote { option: String, effects: Vec<E> },
    Effects(Vec<E>),
}

impl<E> VotePayload<E> {
    pub fn effects(&self) -> &[E] {
        match self {
            Self::ForEachVote { effects, .. } | Self::Effects(effects) => effects,
        }
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct VoteEffect<E> {
    /// Ordered named-vote payload program, replacing option-local bodies.
    /// Empty for older artifacts and manually authored option-local payloads.
    #[cfg_attr(feature = "serde", serde(default = "Vec::new"))]
    pub payloads: Vec<VotePayload<E>>,
    pub choice: VoteChoice<E>,
    pub controller_extra_votes: u32,
    pub controller_optional_extra_votes: u32,
    pub secret: bool,
    /// Whether the vote starts with the effect's controller before proceeding
    /// in turn order. This is executable vote-order semantics, not merely a
    /// rendering hint.
    pub starting_with_controller: bool,
}

impl<E> VoteEffect<E> {
    pub fn new(options: Vec<VoteOption<E>>, controller_extra_votes: u32) -> Self {
        Self {
            payloads: Vec::new(),
            choice: VoteChoice::NamedOptions(options),
            controller_extra_votes,
            controller_optional_extra_votes: 0,
            secret: false,
            starting_with_controller: false,
        }
    }

    pub fn with_optional_extra(
        options: Vec<VoteOption<E>>,
        controller_extra_votes: u32,
        controller_optional_extra_votes: u32,
    ) -> Self {
        Self {
            payloads: Vec::new(),
            choice: VoteChoice::NamedOptions(options),
            controller_extra_votes,
            controller_optional_extra_votes,
            secret: false,
            starting_with_controller: false,
        }
    }

    pub fn named(
        options: Vec<VoteOption<E>>,
        controller_extra_votes: u32,
        controller_optional_extra_votes: u32,
    ) -> Self {
        Self::with_optional_extra(
            options,
            controller_extra_votes,
            controller_optional_extra_votes,
        )
    }

    pub fn vote_objects(
        filter: ObjectFilter,
        count: ChoiceCount,
        controller_extra_votes: u32,
    ) -> Self {
        Self {
            payloads: Vec::new(),
            choice: VoteChoice::Objects { filter, count },
            controller_extra_votes,
            controller_optional_extra_votes: 0,
            secret: false,
            starting_with_controller: false,
        }
    }

    pub fn objects(
        filter: ObjectFilter,
        count: ChoiceCount,
        controller_extra_votes: u32,
        controller_optional_extra_votes: u32,
    ) -> Self {
        Self::vote_objects_with_optional_extra(
            filter,
            count,
            controller_extra_votes,
            controller_optional_extra_votes,
        )
    }

    pub fn vote_objects_with_optional_extra(
        filter: ObjectFilter,
        count: ChoiceCount,
        controller_extra_votes: u32,
        controller_optional_extra_votes: u32,
    ) -> Self {
        Self {
            payloads: Vec::new(),
            choice: VoteChoice::Objects { filter, count },
            controller_extra_votes,
            controller_optional_extra_votes,
            secret: false,
            starting_with_controller: false,
        }
    }

    pub fn vote_players(
        filter: PlayerFilter,
        exclude_voter: bool,
        controller_extra_votes: u32,
    ) -> Self {
        Self::vote_players_with_optional_extra(filter, exclude_voter, controller_extra_votes, 0)
    }

    pub fn vote_players_with_optional_extra(
        filter: PlayerFilter,
        exclude_voter: bool,
        controller_extra_votes: u32,
        controller_optional_extra_votes: u32,
    ) -> Self {
        Self {
            payloads: Vec::new(),
            choice: VoteChoice::Players {
                filter,
                exclude_voter,
            },
            controller_extra_votes,
            controller_optional_extra_votes,
            secret: false,
            starting_with_controller: false,
        }
    }

    pub fn basic(options: Vec<VoteOption<E>>) -> Self {
        Self::new(options, 0)
    }

    pub fn councils_dilemma(options: Vec<VoteOption<E>>) -> Self {
        Self::with_optional_extra(options, 0, 1).starting_with_controller(true)
    }

    pub fn with_payloads(mut self, payloads: Vec<VotePayload<E>>) -> Self {
        self.payloads = payloads;
        self
    }

    pub fn with_secret(mut self, secret: bool) -> Self {
        self.secret = secret;
        self
    }

    pub fn starting_with_controller(mut self, starting_with_controller: bool) -> Self {
        self.starting_with_controller = starting_with_controller;
        self
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct SecretObjectChoice {
    /// Objects each participant may choose. Relative player filters such as
    /// `IteratedPlayer` are evaluated for that participant.
    pub filter: ObjectFilter,
    /// Number of objects each participant chooses.
    pub count: ChoiceCount,
    /// Shared result-set tag populated only after every participant has made
    /// their hidden selection.
    pub tag: TagKey,
    /// Whether the authored procedure immediately reveals the selections.
    pub reveal_after_choice: bool,
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct SecretChoiceEffect {
    pub options: Vec<String>,
    pub participants: Vec<PlayerFilter>,
    pub participant_target: Option<ChooseSpec>,
    pub object_choice: Option<SecretObjectChoice>,
}

impl SecretChoiceEffect {
    pub fn new(options: Vec<String>, participants: Vec<PlayerFilter>) -> Self {
        let participant_target = participants.iter().find_map(|participant| {
            if let PlayerFilter::Target(inner) = participant {
                Some(ChooseSpec::target(ChooseSpec::Player((**inner).clone())))
            } else {
                None
            }
        });
        Self {
            options,
            participants,
            participant_target,
            object_choice: None,
        }
    }

    pub fn new_objects(participants: Vec<PlayerFilter>, object_choice: SecretObjectChoice) -> Self {
        let participant_target = participants.iter().find_map(|participant| {
            if let PlayerFilter::Target(inner) = participant {
                Some(ChooseSpec::target(ChooseSpec::Player((**inner).clone())))
            } else {
                None
            }
        });
        Self {
            options: Vec::new(),
            participants,
            participant_target,
            object_choice: Some(object_choice),
        }
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct GrantTaggedSpellFreeCastUntilEndOfTurnEffect {
    pub tag: crate::tag::TagKey,
    pub player: PlayerFilter,
    pub duration: GrantPlayTaggedDuration,
    pub while_on_top_of_library: bool,
    pub zone: Option<crate::zone::Zone>,
}

impl GrantTaggedSpellFreeCastUntilEndOfTurnEffect {
    pub fn new(tag: impl Into<crate::tag::TagKey>, player: PlayerFilter) -> Self {
        Self {
            tag: tag.into(),
            player,
            duration: GrantPlayTaggedDuration::UntilEndOfTurn,
            while_on_top_of_library: false,
            zone: Some(crate::zone::Zone::Exile),
        }
    }

    pub fn while_on_top_of_library(mut self) -> Self {
        self.while_on_top_of_library = true;
        self
    }

    pub fn for_as_long_as_exiled(mut self) -> Self {
        self.duration = GrantPlayTaggedDuration::ForAsLongAsExiled;
        self
    }

    pub fn from_current_zone(mut self) -> Self {
        self.zone = None;
        self
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct GrantTaggedSpellLifeCostByManaValueEffect {
    pub tag: crate::tag::TagKey,
    pub player: PlayerFilter,
}

impl GrantTaggedSpellLifeCostByManaValueEffect {
    pub fn new(tag: impl Into<crate::tag::TagKey>, player: PlayerFilter) -> Self {
        Self {
            tag: tag.into(),
            player,
        }
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub enum MayCastMatchingSpellPayment {
    WithoutPayingManaCost,
    AlternativeCost(AlternativeCastKind),
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct MayCastMatchingSpellWithoutPayingManaCostEffect {
    pub player: PlayerFilter,
    pub zone_owner: PlayerFilter,
    pub filter: ObjectFilter,
    pub zone: crate::Zone,
    pub payment: MayCastMatchingSpellPayment,
}

impl MayCastMatchingSpellWithoutPayingManaCostEffect {
    pub fn new(player: PlayerFilter, filter: ObjectFilter, zone: crate::Zone) -> Self {
        Self {
            zone_owner: player.clone(),
            player,
            filter,
            zone,
            payment: MayCastMatchingSpellPayment::WithoutPayingManaCost,
        }
    }

    pub fn with_zone_owner(mut self, owner: PlayerFilter) -> Self {
        self.zone_owner = owner;
        self
    }

    pub fn with_alternative_cost(mut self, kind: AlternativeCastKind) -> Self {
        self.payment = MayCastMatchingSpellPayment::AlternativeCost(kind);
        self
    }
}

/// A numeric choice made while an instruction resolves. `None` is an
/// unbounded authored choice, separate from the host response representation.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct ChooseNumberEffect {
    pub chooser: PlayerFilter,
    pub min: u32,
    pub max: Option<u32>,
    /// This number is the count for an immediate "draw up to N cards" action.
    /// Static draw prohibitions bound the choice itself (CR 121.2b).
    #[cfg_attr(feature = "serde", serde(default, skip_serializing_if = "std::ops::Not::not"))]
    pub draw_count_choice: bool,
    /// Source-owned entry/reselection choices survive this resolution. Local
    /// numeric producers remain bound by their exact execution effect id.
    #[cfg_attr(
        feature = "serde",
        serde(default, skip_serializing_if = "number_choice_is_local")
    )]
    pub source_owned: bool,
}
fn number_choice_is_local(source_owned: &bool) -> bool {
    !*source_owned
}
impl ChooseNumberEffect {
    pub fn new(chooser: PlayerFilter, min: u32, max: u32) -> Self {
        Self {
            chooser,
            min,
            max: Some(max),
            draw_count_choice: false,
            source_owned: false,
        }
    }
    pub fn unbounded(chooser: PlayerFilter) -> Self {
        Self {
            chooser,
            min: 0,
            max: None,
            draw_count_choice: false,
            source_owned: false,
        }
    }
    pub fn with_source_retention(mut self) -> Self {
        self.source_owned = true;
        self
    }
    pub fn for_draw_count(mut self) -> Self {
        self.draw_count_choice = true;
        self
    }
}

#[cfg(all(test, feature = "serde"))]
mod choose_number_draw_count_serde_tests {
    use super::*;

    #[test]
    fn old_number_choices_default_to_unconstrained_and_typed_draw_choices_roundtrip() {
        let ordinary = ChooseNumberEffect::new(PlayerFilter::You, 0, 2);
        let old = serde_json::to_value(&ordinary).unwrap();
        assert!(old.get("draw_count_choice").is_none());
        let restored: ChooseNumberEffect = serde_json::from_value(old).unwrap();
        assert!(!restored.draw_count_choice);
        let draw = ordinary.for_draw_count();
        let encoded = serde_json::to_value(&draw).unwrap();
        assert_eq!(encoded["draw_count_choice"], true);
        assert_eq!(serde_json::from_value::<ChooseNumberEffect>(encoded).unwrap(), draw);
    }
}

/// One CR702.60 reveal/cast/remainder resolution transaction.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct RippleEffect {
    pub amount: u32,
}

/// An object-state transition that ends one application of a named status.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, TagKeyWalk)]
pub enum CustomStatusExpiryEvent { TurnsFaceUp, PhasesIn }

/// A noncopiable permanent designation, independent of a keyword action.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, Eq, TagKeyWalk)]
pub enum PermanentDesignation {
    Harnessed,
    /// Named state on one explicitly named zone incarnation. Moving the card
    /// creates a new incarnation and ends this state, just like battlefield statuses.
    CustomStatusInZone { name: String, zone: crate::zone::Zone, present: bool,
        /// This exact zone incarnation lends its designation to the spell it
        /// becomes, independently of the permission used to cast it.
        #[cfg_attr(feature = "serde", serde(default))]
        carry_to_stack: bool },
    /// Named, noncopiable state on this battlefield incarnation.
    CustomStatus { name: String, until_end_of_turn: bool },
    CustomStatusUntilEvent { name: String, event: CustomStatusExpiryEvent },
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct GrantExileControllerInspectionEffect {
    pub target: ChooseSpec,
    pub sources: ChooseSpec,
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct SetPermanentDesignationEffect {
    pub target: ChooseSpec,
    pub designation: PermanentDesignation,
}

/// A status-gated alternative to the complete printed activation cost. Each
/// ability owns its own per-turn use allowance, independent of normal payments.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct GrantActivationCostAlternativeEffect {
    pub target: ChooseSpec,
    pub status: String,
    pub replacement_cost: ManaCost,
    pub max_uses_per_ability_each_turn: u32,
    pub nonloyalty_only: bool,
}

/// Merge two selected battlefield permanents into the host's existing object.
/// Physical components retain their individual owners; no zone change occurs.
#[cfg_attr(feature="serde",derive(serde::Serialize,serde::Deserialize))]
#[derive(Debug,Clone,PartialEq,TagKeyWalk)]
pub struct MergePermanentsEffect {
    pub incoming:ObjectFilter,
    pub host:ObjectFilter,
    pub choose_top:bool,
    pub transfer_counters:bool,
    pub transfer_attachments:bool,
}


/// Create tokens from the source physical card's retained back-face definition.
/// No copiable front-face ability can manufacture a missing linked back face.
#[cfg_attr(feature="serde",derive(serde::Serialize,serde::Deserialize))]
#[derive(Debug,Clone,PartialEq,TagKeyWalk)]
pub struct CreateLinkedFaceTokenEffect {
    pub required_subtype: Subtype,
    pub attached_to: ChooseSpec,
}

/// Record exact object membership owned by one exact source incarnation.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct RecordSourceCollectionEffect {
    pub target: ChooseSpec,
    pub source_tag: Option<crate::tag::TagKey>,
    pub name: String,
    pub source_zone: Option<crate::zone::Zone>,
    pub member_zone: crate::zone::Zone,
}

/// Pure binding of one instruction's original movement arrivals. Added
/// replacement programs and later reincarnations cannot enter this packet.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct RememberOriginalMovementArrivalsEffect {
    pub from: EffectId,
    pub zone: crate::zone::Zone,
    pub tag: crate::tag::TagKey,
}

/// Associate actual exiled physical cards with an exact battlefield host.
/// Exiling, choosing, and optionality are separate ordinary instructions.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct LinkExiledCardsEffect {
    pub cards: ChooseSpec,
    pub host: ChooseSpec,
    pub relationship: String,
}

/// A simultaneous heterogeneous counter placement. Used by replacements that
/// change individual counters' kinds while retaining their original producer.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct PutCounterBatchEffect {
    pub target: ChooseSpec,
    pub counters: Vec<(crate::CounterType,u32)>,
    #[cfg_attr(feature = "serde", serde(default))]
    pub use_replaced_event_cause: bool,
}
