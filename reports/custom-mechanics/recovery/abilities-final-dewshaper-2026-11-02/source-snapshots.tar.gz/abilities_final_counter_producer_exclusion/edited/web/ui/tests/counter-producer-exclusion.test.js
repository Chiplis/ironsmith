import test from 'node:test';
import assert from 'node:assert/strict';
import {expandCustomKeywordPredicates,mentionsCustomKeywordPredicate} from '../src/lib/custom-keyword-predicates.js';
test('producer exclusions bind only the supplied exact keyword outside quoted programs',()=>{
 const def={keyword:'siphon'};
 const raw='If an effect you control other than a siphon ability would put a counter on a permanent, you may put a flying, vigilance, or stun counter on that permanent instead.';
 assert.equal(expandCustomKeywordPredicates(raw,[def]),raw.replace('a siphon ability','an ability designated "siphon"'));
 assert.equal(mentionsCustomKeywordPredicate(raw,def),true);
 assert.equal(expandCustomKeywordPredicates(raw,[]),raw);
 const quoted=`Create a token with "${raw}".`;
 assert.equal(expandCustomKeywordPredicates(quoted,[def]),quoted);
 assert.equal(mentionsCustomKeywordPredicate(quoted,def),false);
 assert.equal(expandCustomKeywordPredicates(raw.replace('siphon ability','siphoning ability'),[def]),raw.replace('siphon ability','siphoning ability'));
});
