# Dewshaper counter replacement foundation — HOLD for entry integration

This packet is **not a complete Dewshaper certification or a request to waive entry coverage**. It supplies the battlefield counter-placement half and the generic static/source reader. The entry-counter consumer and exact producer receipt integration are being authored separately.

Source: frozen raw MSEM corpus, exact physical key `Dewshaper Matriarch_TPW`: “If an effect you control other than a siphon ability would put a counter on a permanent, you may put a flying, vigilance, or stun counter on that permanent instead.” Original source fields are unchanged. The exact source is in the whole14 input packet `9cd4c197ba267dfabf62fa7921f2c5db36243248be2489b290ad58651efeb50b`.

The supplied Siphon rule is a static generic-mana payment substitution. Its actual counter payment is a Cost event. Dewshaper explicitly requires an effect, so this payment is excluded by ordinary cause type before any class comparison. An ordinary effect originating from a card that currently has Siphon remains eligible. The additional exact class exclusion reads the immutable `EventCause.resolving_ability_designations` receipt; it never queries current source keywords or guesses class from the counter operation.

A replacement controller allocates how many of the nominal counters become each allowed kind; the remainder retains the original kind. These count allocations represent independent choices for indistinguishable counters without imposing a one-kind-per-event restriction. The replacement yields one heterogeneous continuation. It freezes every proposed counter original through the existing simultaneous prepared-placement owner before any commit. It uses the original event cause/provenance and inherited application keys, so the same replacement cannot repeatedly rewrite its own outputs (local CR 614.1, 614.5, 616.1; `.codex_rules_20260227.txt`).

The native tests compile the exact source independently through native and serialized artifact routes. They cover mixed and declined allocations, an opponent's permanent with replacement-controller choices, exact/near producer names, departed producer identity, an ordinary effect from a current Siphon card, and a real Siphon spell's counter payment. Grammar and frontend tests cover the complete literal-bound reader, supplied vocabulary, quote opacity, unknown names and trailing-clause rejection. **None has been executed by this worker.**

## Explicit remaining entry work

CR 122.6 and 614.16 require effect-produced enters-with counters as well. Existing entry programs stage counter changes, then the outer entry event aggregates same-kind totals. The pre-existing matcher refuses cause-filtered entry proposals, so merely adding the new cause predicate would silently miss a real source case. The related transport packet `tokens-entry-counter-producer-transport/entry-counter-producer-transport.patch` (`dc3f25677a5d15cb4347b0d6073d71a36578ffb00b78be5b5b62ecfbadc8b7f0`) captures exact successful authored causes through context, entry execution, choices and ETB event, with a checked totals validator. Consumer/acquisition/modifier integration remains required before complete-source status.

Also explicit: an already-on-battlefield heterogeneous proposal with a pre-existing whole-proposal `maximum_count` reports incomplete rather than multiplying a shared cap across branches. Current permanent proposals do not create that cap; player cap events are outside this permanent-only reader. This is not a neutral or guessed result.

## Integration and evidence

Use `base` and `edited` for a three-way scratch integration, preserve current root additions, and append new enum variants after current prefixes. New typed fields/payload/effect require the root's effective schema binding refresh; old format descriptors must remain immutable. The generic frontend source adapter requires root materialization of `msem-final-owner-complete-inventory.json` from the supplied source declaration index before the native source tests run.

New target: `custom_counter_producer_exclusion`. Frontend test: `web/ui/tests/counter-producer-exclusion.test.js`. Grammar unit: `counter_producer_exclusion_tests::producer_exclusion_is_complete_literal_bound_and_not_a_source_keyword_filter`.

Static `git apply --check` passed. Independent grant_frontend review cleared the inspected battlefield cause/allocation/continuation/prepared-placement/application-key path, with the entry omission explicitly blocking full source completeness. No tests, builds, probes, materialization, or live edits were performed.
