//! Replacement effect system.
//!
//! Replacement effects modify or replace events as they happen.
//! Per MTG rule 614, they use "instead" or "as [event]" or "skip".

use crate::ability::Ability;
use crate::effect::{Effect, Value};
use crate::events::cards::matchers::WouldDrawCardMatcher;
use crate::events::damage::matchers::{DamageFromSourceMatcher, DamageToPlayerMatcher};
use crate::events::life::matchers::WouldGainLifeMatcher;
use crate::events::permanents::matchers::ThisWouldBeDestroyedMatcher;
use crate::events::zones::matchers::{
    ThisWouldDieMatcher, ThisWouldEnterBattlefieldMatcher, WouldChangeZoneMatcher,
    WouldEnterBattlefieldMatcher,
};
use crate::events::{ReplacementMatcher, ReplacementPriority};
use crate::ids::{ObjectId, PlayerId};
use crate::object::CounterType;
use crate::static_abilities::StaticAbilityInstanceId;
use crate::target::ChooseSpec;
use crate::target::{ObjectFilter, PlayerFilter};
use crate::types::{CardType, Subtype, Supertype};
use crate::zone::Zone;
use ironsmith_core::AdditionalTokenKind;

/// A replacement effect that modifies events.
#[derive(Debug, Clone)]
pub struct ReplacementEffect {
    /// Unique identifier for this effect
    pub id: ReplacementEffectId,

    /// Identity of a persistent manager registration. Static/ephemeral
    /// effects leave this unset because their transient IDs can change.
    registration_id: Option<ReplacementEffectId>,

    /// The source that created this effect
    pub source: ObjectId,

    /// The controller of this effect
    pub controller: PlayerId,

    /// What happens instead
    pub replacement: ReplacementAction,

    /// Optional explicit priority bucket override per CR 616.1.
    pub priority_override: Option<ReplacementPriority>,

    /// Trait-based matcher for checking if this effect applies.
    pub matcher: Option<Box<dyn ReplacementMatcher>>,

    /// Stable identity of the static ability that generated this effect.
    /// Resolution-created effects leave this unset.
    pub static_ability_instance: Option<StaticAbilityInstanceId>,
    /// Stable originating occurrence plus generated branch, when produced
    /// from an object's abilities. Controller and mutable payload are not identity.
    pub ability_origin: Option<ReplacementAbilityOrigin>,

    /// Whether the affected player may decline this replacement effect.
    /// Optional effects are expanded into an explicit no-op CR 616 choice
    /// carrying the declined effect's stable application key.
    pub optional: bool,
    /// The replacement's controller chooses whether to apply it after the
    /// affected player has selected its place in replacement ordering.
    pub optional_by_controller: bool,
}

#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub struct ReplacementAbilityOrigin {
    pub ability: crate::continuous::AbilityOrigin,
    pub printed_face: Option<crate::ids::CardId>,
    pub branch: usize,
}


/// Unique identifier for a replacement effect.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
#[cfg_attr(feature = "serialization", derive(serde::Serialize, serde::Deserialize))]
pub struct ReplacementEffectId(pub u64);

impl ReplacementEffectId {
    pub fn new(id: u64) -> Self {
        Self(id)
    }
}

/// Stable identity for a replacement effect across static-effect regeneration.
///
/// Static ability replacement effects are cleared and re-added during game-state
/// refreshes, which gives them fresh transient IDs. Event processing still needs
/// to recognize the same replacement effect for CR 614.5, especially when a
/// replacement creates nested events that move objects and refresh state.
#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub enum ReplacementEffectKey {
    /// Separate resolutions remain separate even when their source and text match.
    Registered(ReplacementEffectId),
    /// The same ability occurrence survives regeneration and mutable bindings.
    Ability { source: ObjectId, origin: ReplacementAbilityOrigin },
    /// Regenerated and event-local effects retain their structural identity.
    Regenerated {
        source: ObjectId,
        controller: PlayerId,
        static_ability_instance: Option<StaticAbilityInstanceId>,
        matcher: Option<String>,
        replacement: String,
    },
}


impl ReplacementEffect {
    pub fn with_ability_origin(mut self, ability: crate::continuous::AbilityOrigin,
        printed_face: Option<crate::ids::CardId>, branch: usize) -> Self {
        let origin = ReplacementAbilityOrigin { ability, printed_face, branch };
        // Accepting/declining and copy alternatives retain one parent identity,
        // even when the decline carrier was constructed before origin binding.
        if let ReplacementAction::DeclineOptional(key) = &mut self.replacement {
            *key = ReplacementEffectKey::Ability { source: self.source, origin: origin.clone() };
        }
        self.ability_origin = Some(origin);
        self
    }
    pub fn application_key(&self) -> ReplacementEffectKey {
        // Accepting and declining are two choices for the same effect, not
        // independent opportunities to replace the event.
        if let ReplacementAction::DeclineOptional(key) = &self.replacement {
            return key.clone();
        }
        if let ReplacementAction::TokenCreationTemplates { choice_parent: Some(key), .. } = &self.replacement {
            return key.clone();
        }
        if let Some(id) = self.registration_id {
            return ReplacementEffectKey::Registered(id);
        }
        if let Some(origin) = &self.ability_origin {
            return ReplacementEffectKey::Ability { source: self.source, origin: origin.clone() };
        }
        ReplacementEffectKey::Regenerated {
            source: self.source,
            controller: self.controller,
            static_ability_instance: self.static_ability_instance,
            matcher: self.matcher.as_ref().map(|matcher| matcher.display()),
            replacement: format!("{:?}", self.replacement),
        }
    }
}

/// What happens instead when a replacement triggers.
#[derive(Debug, Clone, PartialEq)]
pub enum ReplacementAction {
    /// Prevent the event entirely
    Prevent,

    /// Prevent an entire damage event and emit the CR 615.13 application event.
    PreventDamage,

    /// Prevent up to the specified amount of damage and emit the CR 615.13 event.
    PreventDamageAmount(u32),

    /// Prevent half of the damage (rounded up or down) and emit the CR 615.13 event.
    PreventHalfDamage { round_up: bool },

    /// Prevent one point of damage for each matching counter available on this
    /// replacement effect's source, then remove exactly that many counters.
    PreventDamageByRemovingSourceCounters { counter_type: CounterType },

    /// Prevent the damage, then perform the prevention effect's additional part.
    ///
    /// The additional part still happens with an amount of zero when the damage
    /// can't be prevented (CR 615.12), while CR 615.13 is emitted only when the
    /// application actually prevents damage.
    PreventDamageThen(Vec<Effect>),

    /// Apply one prevention shield to a matching damage event.
    ///
    /// Damage processing exposes live shields as ordinary CR 616 candidates;
    /// this action consumes only the shield the affected player chooses.
    PreventWithShield {
        shield_id: crate::prevention::PreventionShieldId,
        /// Batch-level CR 615.7 allocation cap for this source event.
        max_amount: Option<u32>,
    },

    /// Apply the event but modified
    Modify(EventModification),

    /// Do something different instead
    Instead(Vec<Effect>),

    /// Redirect to a different target.
    /// Use `which` to specify which target to redirect for multi-target events.
    Redirect {
        target: RedirectTarget,
        /// Which target to redirect (default: First).
        which: RedirectWhich,
    },

    /// Redirect up to a fixed amount of damage to a different target.
    ///
    /// This is used by effects like:
    /// "The next 1 damage that would be dealt to this creature this turn is dealt to target creature instead."
    ///
    /// If the event's damage amount is larger than `amount`, only `amount` is redirected and
    /// the remainder stays on the original target.
    RedirectDamageAmount {
        target: RedirectTarget,
        /// Which redirectable target to rewrite (default: First).
        which: RedirectWhich,
        /// Maximum damage to redirect from a single matching event.
        amount: u32,
    },

    /// Redirect only damage beyond the current recipient's lethal threshold.
    /// Computed when this replacement is selected, after earlier modifications.
    RedirectExcessDamage { target: RedirectTarget, which: RedirectWhich },

    /// Change the zone an object would go to
    ChangeDestination(Zone),

    /// Exile a discarded card through its Madness replacement (CR 702.35a).
    /// The discard event retains this provenance for the linked trigger.
    DiscardWithMadness,

    /// The replacement's controller draws instead of the event's player
    /// ("that player skips that draw and you draw a card", Notion Thief).
    RedirectDrawToController,

    /// Move the object to a replacement zone and put counters on it.
    MoveToZoneWithCounters {
        zone: Zone,
        counters: Vec<(CounterType, u32)>,
    },

    /// Move the object to a replacement zone (keeping the replaced event's
    /// provenance, e.g. a discard stays a discard), then execute follow-up
    /// effects from the replacement source. The moved object is tagged under
    /// [`crate::tag::ZONE_REPLACEMENT_OBJECT_TAG`] for the follow-ups ("reveal
    /// it and shuffle it into its owner's library instead").
    MoveToZoneThen {
        zone: Zone,
        effects: Vec<Effect>,
    },

    /// Exile the object and record it as exiled with the replacement source.
    ExileWithSourceLink,

    /// Exile the object, record it as exiled with the replacement source, then
    /// execute follow-up effects from that source.
    ExileWithSourceLinkThen(Vec<Effect>),

    /// Exile the object with counters, record it as exiled with the replacement
    /// source, then execute follow-up effects from that source.
    ExileWithSourceLinkCountersThen {
        counters: Vec<(CounterType, u32)>,
        effects: Vec<Effect>,
    },

    /// Enter with the prospective printed number specified by an intrinsic rule.
    EnterWithIntrinsicStartingCounters(ironsmith_core::IntrinsicStartingCounter),

    /// Enter with additional counters
    EnterWithCounters {
        counter_type: CounterType,
        counter_kinds_from: Option<ChooseSpec>,
        count: Value,
        /// Selects `count` when true and `otherwise_count` when false. The
        /// condition is evaluated with the entering object as its source.
        count_condition: Option<crate::ConditionExpr>,
        otherwise_count: Option<Value>,
        added_subtypes: Vec<Subtype>,
        added_abilities: Vec<Ability>,
    },

    /// Enter with the controller's choice of one counter type.
    EnterWithCounterChoice {
        counter_types: Vec<CounterType>,
        count: Value,
        /// Number of different kinds chosen; each gets `count` counters.
        kinds: u32,
    },

    /// As this enters, an opponent may put counters on it and mark a keyword paid.
    Tribute {
        counter_type: CounterType,
        count: u32,
        paid_label: String,
    },

    /// Enter tapped
    EnterTapped,

    /// Enter untapped
    EnterUntapped,

    /// Enter under the specified player's control.
    EnterUnderControl(PlayerId),

    /// The affected permanent controller chooses its entering controller.
    EnterUnderChosenControl {
        players: crate::target::PlayerFilter,
    },

    /// Enter as a copy of something
    EnterAsCopy {
        source: ObjectId,
        enters_tapped: bool,
        copy_duration: Option<crate::effect::Until>,
        linked_exile_objects: Vec<ObjectId>,
        additional_counters: Vec<(CounterType, u32)>,
        name_override: Option<String>,
        added_colors: crate::color::ColorSet,
        added_card_types: Vec<CardType>,
        removes_other_card_types: bool,
        added_supertypes: Vec<Supertype>,
        removed_supertypes: Vec<Supertype>,
        added_subtypes: Vec<Subtype>,
        added_abilities: Vec<Ability>,
        set_base_power_toughness: Option<(i32, i32)>,
        /// What else happens once this copy is chosen.
        copy_followups: Vec<ironsmith_core::EnterAsCopyFollowup>,
    },

    /// Enter with permanent characteristic changes.
    EnterWithCharacteristics {
        face_down: bool,
        added_card_types: Vec<CardType>,
        added_subtypes: Vec<Subtype>,
        set_base_power_toughness: Option<(i32, i32)>,
    },

    /// Double the effect (e.g., double damage, double counters)
    Double,

    /// Double counters of the matching type on counter-placement events.
    DoubleCounters {
        counter_type: Option<CounterType>,
    },

    /// Halve (rounded down) counters of the matching type on counter-placement
    /// events ("they put half that many ... instead, rounded down").
    HalveCounters {
        counter_type: Option<CounterType>,
    },

    /// Add extra counters of the matching type to counter-placement events
    /// ("that many plus one ... counters are put on it instead").
    AddCountersToPlacement {
        counter_type: Option<CounterType>,
        additional: i64,
    },

    /// Replace one player-counter event with a fixed amount and establish a
    /// turn-scoped prohibition on additional counters of that type.
    SetPlayerCountersAndLockForTurn {
        counter_type: CounterType,
        amount: u32,
    },

    /// Execute a selected as-enters program, then reconsider the pending entry.
    AsEntersProgram(crate::resolution::ResolutionProgram),

    /// Add an additional effect
    Additionally(Vec<Effect>),

    /// Heal all damage already marked on the damage event's recipient, then
    /// let that same damage event happen ("instead that damage is dealt, but
    /// all other damage already dealt to him is healed").
    HealRecipientThenProceed,

    /// Explicitly decline one optional replacement for this event.
    DeclineOptional(ReplacementEffectKey),

    /// Add separately defined tokens to a token-creation event.
    AddTokens {
        token: AdditionalTokenKind,
        count: u32,
    },

    /// Add one separately defined token per token being created ("those
    /// tokens plus that many 1/1 green Squirrel creature tokens", Chatterfang).
    AddTokensPerCreated { token: AdditionalTokenKind },

    /// Add one of each listed token kind other than the kind being created
    /// ("If you would create a Clue, Food, or Treasure token, instead create
    /// one of each", Academy Manufactor).
    AddTokensOfOtherKinds { kinds: Vec<AdditionalTokenKind> },

    /// Replace the mana produced by a matching mana event.
    ReplaceMana(Vec<crate::mana::ManaSymbol>),

    /// Replace the produced mana with exactly these symbols, changing the
    /// amount as well as the type ("produces {C} instead of any other type
    /// and amount", Damping Sphere).
    ReplaceManaExact(Vec<crate::mana::ManaSymbol>),

    /// Skip (for "skip your draw step" etc.)
    Skip,

    /// Interactive: Discard a card matching filter, or redirect to a different zone.
    ///
    /// Used by Mox Diamond: "If Mox Diamond would enter the battlefield, you may discard
    /// a land card instead. If you do, put Mox Diamond onto the battlefield. If you don't,
    /// put it into its owner's graveyard."
    ///
    /// When this applies:
    /// 1. Check if controller has any cards in hand matching the filter
    /// 2. If no matching cards, automatically redirect to redirect_zone
    /// 3. If matching cards exist, prompt the player to choose one or decline
    /// 4. If player discards a matching card, the permanent enters the battlefield
    /// 5. If player declines, the permanent goes to redirect_zone instead
    InteractiveDiscardOrRedirect {
        /// Filter for cards that can be discarded to satisfy the replacement.
        filter: ObjectFilter,
        /// Where the permanent goes if no card is discarded.
        redirect_zone: Zone,
    },

    /// Interactive: Sacrifice an exact number of matching controlled
    /// permanents, or redirect the entering permanent to another zone.
    InteractiveSacrificeOrRedirect {
        filter: ObjectFilter,
        count: u32,
        redirect_zone: Zone,
    },

    /// Interactive: Pay life or enter tapped.
    ///
    /// Used by shock lands (Godless Shrine, etc.): "As ~ enters the battlefield,
    /// you may pay 2 life. If you don't, it enters the battlefield tapped."
    ///
    /// When this applies:
    /// 1. Prompt the player if they want to pay life_cost life
    /// 2. If player pays, the permanent enters untapped
    /// 3. If player declines (or can't pay), the permanent enters tapped
    InteractivePayLifeOrEnterTapped {
        /// The amount of life to pay.
        life_cost: u32,
    },

    /// Interactive: Reveal a matching card from hand or enter tapped.
    ///
    /// Used by the SOI shadow lands and STX snarls: "As this land enters, you
    /// may reveal a Plains or Island card from your hand. If you don't, this
    /// land enters tapped."
    ///
    /// When this applies:
    /// 1. If the controller has no matching card in hand, the permanent enters tapped
    /// 2. Otherwise prompt the controller to reveal one matching card
    /// 3. If they reveal, the permanent enters untapped; if they decline, tapped
    InteractiveRevealCardOrEnterTapped {
        /// The hand card that may be revealed.
        filter: crate::target::ObjectFilter,
    },

    /// Interactive: Choose alternate destination for a zone-changing event.
    ///
    /// Used by Library of Leng: "If an effect causes you to discard a card,
    /// you may put it on top of your library instead of into your graveyard."
    ///
    /// When this applies:
    /// 1. Prompt the player with the choice of destinations
    /// 2. If player chooses the alternate destination, modify the event
    /// 3. If player declines, the event proceeds with its original destination
    ///
    /// This is a generic version that could work for various "instead of X, you may Y"
    /// effects involving zone changes.
    InteractiveChooseDestination {
        /// The destinations the player can choose from.
        /// The first destination is typically the default (original destination).
        destinations: Vec<Zone>,
        /// Description for the choice prompt.
        description: String,
    },
    /// General typed damage prevention; append to preserve wire variant ordinals.
    PreventDamageByRule(ironsmith_core::StaticDamagePreventionAmount),
    /// Additional actions refer to the proposed damage even when prevention is
    /// prohibited. Append rather than reinterpreting existing actual-amount actions.
    PreventDamageThenFromProposedAmount(Vec<Effect>),
    /// Complete creation templates modify groups inside the same event.
    TokenCreationTemplates { templates: Vec<Effect>, mode: ironsmith_core::TokenCreationTemplateMode, choose_one: bool, choice_parent: Option<ReplacementEffectKey> },
    RewriteMana { input: ironsmith_core::ManaRewriteInput, output: ironsmith_core::ManaRewriteOutput,
        quantity: ironsmith_core::ManaRewriteQuantity },
    ConvertUnspentMana(crate::mana::ManaSymbol),
}


/// How to modify an event.
#[derive(Debug, Clone, PartialEq)]
#[cfg_attr(feature = "serialization", derive(serde::Serialize, serde::Deserialize))]
pub enum EventModification {
    /// Multiply by a factor (e.g., double strike)
    Multiply(u32),

    /// Add to the value
    Add(i32),

    /// Subtract from the value (minimum 0)
    Subtract(u32),

    /// Set to a specific value
    SetTo(u32),

    /// Set to a dynamic value if the event amount is lower.
    SetToAtLeast(crate::effect::Value),

    /// Reduce to zero (prevent)
    ReduceToZero,

    /// Evaluate a signed bonus using the replacement source and controller.
    /// Appended to preserve the existing fixed Add schema.
    AddDynamic(crate::effect::Value),

    /// "half that damage, rounded down" (Ghosts of the Innocent): halve the
    /// proposed amount. Appended to preserve the existing schema.
    Halve { round_up: bool },

    /// "instead all but one of those counters are removed" (Deification): a
    /// counter removal is reduced so one counter of its kind remains on its
    /// target. Other events are unchanged. Appended to preserve the schema.
    LeaveOneCounter,
}

/// Where to redirect an effect.
#[derive(Debug, Clone, PartialEq)]
#[cfg_attr(feature = "serialization", derive(serde::Serialize, serde::Deserialize))]
pub enum RedirectTarget {
    /// Redirect to this permanent's controller
    ToController,

    /// Redirect to a specific player
    ToPlayer(PlayerId),

    /// Redirect to a specific object
    ToObject(ObjectId),

    /// Redirect to the source of the effect
    ToSource,

    /// Redirect to the controller of the event source.
    ToSourceController,
    /// Current object attached to the permanent bearing the replacement.
    ToAttachedPermanent(ObjectId),
    /// Current controller of the selected original recipient.
    ToRecipientController,
}

/// Which target to redirect in a multi-target event.
///
/// For events like `MoveCounters` that have multiple redirectable targets
/// (e.g., "source" and "destination"), this specifies which one to redirect.
#[derive(Debug, Clone, PartialEq, Default)]
#[cfg_attr(feature = "serialization", derive(serde::Serialize, serde::Deserialize))]
pub enum RedirectWhich {
    /// Redirect the first (or only) redirectable target.
    /// This is the default behavior.
    #[default]
    First,

    /// Redirect the Nth target (0-indexed).
    Index(usize),

    /// Redirect targets matching this description.
    /// The description is matched against `RedirectableTarget::description`.
    /// E.g., "counter source" or "counter destination" for MoveCounters.
    ByDescription(String),
}

/// Source type for replacement effects - distinguishes between static abilities
/// and resolution-based effects.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
#[cfg_attr(feature = "serialization", derive(serde::Serialize, serde::Deserialize))]
pub enum ReplacementEffectSource {
    /// Effect from a static ability (regenerated each state refresh)
    StaticAbility,
    /// Effect from a resolved spell/ability (persists until removed)
    Resolution,
}

/// Shared builder for zone-change replacement effects.
#[derive(Debug, Clone, PartialEq)]
pub struct ZoneReplacementSpec {
    pub filter: ObjectFilter,
    pub from_zone: Option<Zone>,
    pub to_zone: Option<Zone>,
    pub excluded_to_zones: Vec<Zone>,
    pub replacement_zone: Zone,
    pub follow_up_effects: Vec<Effect>,
}

impl ZoneReplacementSpec {
    pub fn new(filter: ObjectFilter, replacement_zone: Zone) -> Self {
        Self {
            filter,
            from_zone: None,
            to_zone: None,
            excluded_to_zones: Vec::new(),
            replacement_zone,
            follow_up_effects: Vec::new(),
        }
    }

    /// Share the same redirect semantics with selected casting instructions.
    pub fn from_redirect(filter: ObjectFilter, spec: &ironsmith_core::ZoneChangeRedirectSpec) -> Self {
        Self {
            filter, from_zone: Some(spec.from_zone), to_zone: spec.to_zone,
            excluded_to_zones: spec.excluded_to_zones.clone(),
            replacement_zone: spec.destination, follow_up_effects: Vec::new(),
        }
    }

    pub fn from_zone(mut self, zone: Zone) -> Self {
        self.from_zone = Some(zone);
        self
    }

    pub fn to_zone(mut self, zone: Zone) -> Self {
        self.to_zone = Some(zone);
        self
    }

    pub fn with_follow_up_effects(mut self, effects: Vec<Effect>) -> Self {
        self.follow_up_effects = effects;
        self
    }

    pub fn build(self, source: ObjectId, controller: PlayerId) -> ReplacementEffect {
        let replacement = if self.follow_up_effects.is_empty() {
            ReplacementAction::ChangeDestination(self.replacement_zone)
        } else {
            let move_effect = if self.replacement_zone == Zone::Exile {
                Effect::new(crate::effects::ExileEffect::with_spec(ChooseSpec::Source))
            } else {
                Effect::move_to_zone(ChooseSpec::Source, self.replacement_zone, true)
            };
            let mut effects = vec![move_effect];
            effects.extend(self.follow_up_effects);
            ReplacementAction::Instead(effects)
        };

        ReplacementEffect::with_matcher(
            source,
            controller,
            WouldChangeZoneMatcher::new(self.filter, self.from_zone, self.to_zone).excluding_destinations(self.excluded_to_zones),
            replacement,
        )
    }
}

/// A replacement effect temporarily taken out of a [`ReplacementEffectManager`].
#[derive(Debug, Clone)]
pub struct SuspendedReplacementEffect {
    index: usize,
    effect: ReplacementEffect,
    source: Option<ReplacementEffectSource>,
    one_shot: bool,
    batch_one_shot: bool,
    pending_batch_one_shot: bool,
    until_end_of_turn: bool,
}

/// The card a stack replacement waits for (see
/// `ReplacementEffectManager::followed_objects`).
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct FollowedReplacementObject {
    /// The current incarnation the replacement refers to.
    pub object: ObjectId,
    pub from_zone: Option<Zone>,
    pub to_zone: Option<Zone>,
    /// Whether that incarnation is the spell on the stack. A card not yet
    /// cast at cleanup loses the replacement with the other one-shots (the
    /// permission to cast it was "this turn"); its spell keeps it.
    pub on_stack: bool,
}

/// Manages all replacement effects in the game.
#[derive(Debug, Clone, Default)]
pub struct ReplacementEffectManager {
    /// All active replacement effects
    effects: Vec<ReplacementEffect>,

    /// Source type for each effect (by ID)
    effect_sources: std::collections::HashMap<u64, ReplacementEffectSource>,

    /// One-shot effects that are consumed after a single use (e.g., regeneration shields).
    /// These are removed after being applied once.
    one_shot_effects: std::collections::HashSet<ReplacementEffectId>,

    /// One-shot entry replacements that apply to every matching member of one
    /// simultaneous ETB batch, then are consumed together after proposals for
    /// that batch have been prepared.
    batch_one_shot_effects: std::collections::HashSet<ReplacementEffectId>,

    /// Batch-scoped one-shots applied by at least one proposal in the current
    /// ETB batch. These remain live while sibling proposals are evaluated.
    pending_batch_one_shot_effects: std::collections::HashSet<ReplacementEffectId>,

    /// Replacements for the next complete damage occurrence, including every
    /// simultaneous assignment and every fragment produced by a redirection.
    next_damage_occurrence_effects: std::collections::HashSet<ReplacementEffectId>,

    /// Used registrations remain available to siblings in their own occurrence,
    /// but not to a new damage instruction executed by a replacement payload.
    damage_occurrence_frames: Vec<std::collections::HashSet<ReplacementEffectId>>,

    /// Temporary replacement effects that expire during cleanup.
    until_end_of_turn_effects: std::collections::HashSet<ReplacementEffectId>,

    /// Resolved replacements ending at a player's actual next turn start.
    until_next_turn_effects:
        std::collections::HashMap<ReplacementEffectId, (PlayerId, u32, Option<u32>)>,

    /// One-shot stack replacements created for a card that was not yet a
    /// spell ("You may cast that card this turn. If that spell would be put
    /// into a graveyard, ..."). Each follows its card's next zone change:
    /// onto the stack it rebinds to the new spell object; anywhere else the
    /// card is a new object the effect no longer refers to (CR 400.7) and the
    /// replacement ends.
    followed_objects: std::collections::HashMap<ReplacementEffectId, FollowedReplacementObject>,

    /// Static-ability effects in force when a simultaneous event began. A
    /// source leaving the battlefield partway through committing that event
    /// still replaces the event's other parts (CR 614.1, 616.1).
    simultaneous_static_pins: Option<Vec<ReplacementEffect>>,
    /// Attachment relationships when the simultaneous event began. Keeping
    /// an effect alive also requires its source's pre-event relationship.
    simultaneous_source_attachments: std::collections::HashMap<ObjectId, Option<crate::object::AttachmentTarget>>,

    /// Next effect ID to assign
    next_id: u64,
}

impl ReplacementEffectManager {
    /// Create a new empty manager.
    pub fn new() -> Self {
        Self::default()
    }

    /// Snapshot active replacement effects.
    pub fn effects(&self) -> &[ReplacementEffect] {
        &self.effects
    }

    /// Snapshot effect sources in deterministic order.
    pub fn effect_sources_snapshot(&self) -> Vec<(u64, ReplacementEffectSource)> {
        let mut entries: Vec<(u64, ReplacementEffectSource)> = self
            .effect_sources
            .iter()
            .map(|(id, source)| (*id, *source))
            .collect();
        entries.sort_by_key(|(id, _)| *id);
        entries
    }

    /// Snapshot one-shot effect ids in deterministic order.
    pub fn one_shot_effects_snapshot(&self) -> Vec<u64> {
        let mut entries: Vec<u64> = self
            .one_shot_effects
            .iter()
            .chain(&self.batch_one_shot_effects)
            .chain(&self.next_damage_occurrence_effects)
            .map(|id| id.0)
            .collect();
        entries.sort();
        entries
    }

    /// Snapshot cleanup-scoped effect ids in deterministic order.
    pub fn until_end_of_turn_effects_snapshot(&self) -> Vec<u64> {
        let mut entries: Vec<u64> = self
            .until_end_of_turn_effects
            .iter()
            .map(|id| id.0)
            .collect();
        entries.sort();
        entries
    }

    /// Get the next effect id (for deterministic state hashing).
    pub fn next_id(&self) -> u64 {
        self.next_id
    }

    /// Add a new replacement effect.
    pub fn add_effect(&mut self, effect: ReplacementEffect) -> ReplacementEffectId {
        self.register_effect(effect, true)
    }

    fn register_effect(
        &mut self,
        mut effect: ReplacementEffect,
        persistent: bool,
    ) -> ReplacementEffectId {
        let id = ReplacementEffectId::new(self.next_id);
        self.next_id += 1;
        effect.id = id;
        effect.registration_id = persistent.then_some(id);
        self.effects.push(effect);
        id
    }

    /// Remove an effect by ID.
    pub fn remove_effect(&mut self, id: ReplacementEffectId) {
        self.effects.retain(|e| e.id != id);
        self.effect_sources.remove(&id.0);
        self.one_shot_effects.remove(&id);
        self.batch_one_shot_effects.remove(&id);
        self.pending_batch_one_shot_effects.remove(&id);
        self.next_damage_occurrence_effects.remove(&id);
        for frame in &mut self.damage_occurrence_frames {
            frame.remove(&id);
        }
        self.until_end_of_turn_effects.remove(&id);
        self.until_next_turn_effects.remove(&id);
        self.followed_objects.remove(&id);
    }

    /// Add a one-shot stack replacement for a card that is not yet a spell;
    /// it applies to that card's spell once it is cast (see
    /// `followed_objects`). The effect's matcher is rebound when it moves.
    pub fn add_followed_one_shot_effect(
        &mut self,
        effect: ReplacementEffect,
        followed: FollowedReplacementObject,
    ) -> ReplacementEffectId {
        let id = self.add_one_shot_effect(effect);
        self.followed_objects.insert(id, followed);
        id
    }

    /// The followed card `old` became `new` in `new_zone` (CR 400.7). A move
    /// onto the stack rebinds the replacement to that spell; any other move
    /// (including the spell leaving the stack unreplaced) ends it.
    pub fn rebind_followed_object(&mut self, old: ObjectId, new: ObjectId, new_zone: Zone) {
        let affected: Vec<_> = self
            .followed_objects
            .iter()
            .filter(|(_, followed)| followed.object == old)
            .map(|(id, followed)| (*id, *followed))
            .collect();
        for (id, followed) in affected {
            if new_zone == Zone::Stack && !followed.on_stack {
                if let Some(effect) = self.effects.iter_mut().find(|effect| effect.id == id) {
                    effect.matcher = Some(Box::new(
                        crate::events::zones::matchers::WouldChangeZoneMatcher::new(
                            crate::target::ObjectFilter::specific(new),
                            followed.from_zone,
                            followed.to_zone,
                        ),
                    ));
                }
                self.followed_objects.insert(
                    id,
                    FollowedReplacementObject {
                        object: new,
                        on_stack: true,
                        ..followed
                    },
                );
            } else {
                self.remove_effect(id);
            }
        }
    }

    /// The followed-card registration of an effect, if any.
    pub fn followed_object(&self, id: ReplacementEffectId) -> Option<FollowedReplacementObject> {
        self.followed_objects.get(&id).copied()
    }

    /// Remove all effects from a specific source.
    pub fn remove_effects_from_source(&mut self, source: ObjectId) {
        let ids: Vec<_> = self.effects.iter()
            .filter(|effect| effect.source == source)
            .map(|effect| effect.id)
            .collect();
        for id in ids {
            self.remove_effect(id);
        }
    }

    /// Take the regeneration shields protecting `source` out of play for one
    /// destruction that can't be regenerated (CR 701.19c). Pass the result to
    /// [`Self::restore_suspended_effects`] if the permanent survives: the
    /// shields weren't used up.
    pub fn suspend_regeneration_shields_from_source(
        &mut self,
        source: ObjectId,
    ) -> Vec<SuspendedReplacementEffect> {
        let mut suspended = Vec::new();
        let mut index = 0;
        while index < self.effects.len() {
            let effect = &self.effects[index];
            let id = effect.id;
            let is_shield = effect.source == source
                && effect
                    .matcher
                    .as_ref()
                    .is_some_and(|matcher| matcher.is_regeneration_shield())
                && (self.one_shot_effects.contains(&id) || self.batch_one_shot_effects.contains(&id));
            if !is_shield {
                index += 1;
                continue;
            }
            let effect = self.effects.remove(index);
            suspended.push(SuspendedReplacementEffect {
                index: index + suspended.len(),
                effect,
                source: self.effect_sources.remove(&id.0),
                one_shot: self.one_shot_effects.remove(&id),
                batch_one_shot: self.batch_one_shot_effects.remove(&id),
                pending_batch_one_shot: self.pending_batch_one_shot_effects.remove(&id),
                until_end_of_turn: self.until_end_of_turn_effects.remove(&id),
            });
        }
        suspended
    }

    /// Put effects taken out by [`Self::suspend_regeneration_shields_from_source`]
    /// back in their original order and with their original identities.
    pub fn restore_suspended_effects(&mut self, suspended: Vec<SuspendedReplacementEffect>) {
        for entry in suspended {
            let id = entry.effect.id;
            let index = entry.index.min(self.effects.len());
            self.effects.insert(index, entry.effect);
            if let Some(source) = entry.source {
                self.effect_sources.insert(id.0, source);
            }
            if entry.one_shot {
                self.one_shot_effects.insert(id);
            }
            if entry.batch_one_shot {
                self.batch_one_shot_effects.insert(id);
            }
            if entry.pending_batch_one_shot {
                self.pending_batch_one_shot_effects.insert(id);
            }
            if entry.until_end_of_turn {
                self.until_end_of_turn_effects.insert(id);
            }
        }
    }

    /// Remove all one-shot effects from a specific source.
    ///
    /// Primarily used to ignore regeneration shields for "can't be regenerated"
    /// destroy effects.
    /// Remove the regeneration shields protecting `source` (CR 701.19c).
    /// Other one-shot replacements sourced from the object are unaffected.
    pub fn remove_regeneration_shields_from_source(&mut self, source: ObjectId) {
        let ids: Vec<_> = self
            .effects
            .iter()
            .filter(|e| {
                e.source == source
                    && e.matcher
                        .as_ref()
                        .is_some_and(|matcher| matcher.is_regeneration_shield())
                    && (self.one_shot_effects.contains(&e.id)
                        || self.batch_one_shot_effects.contains(&e.id))
            })
            .map(|e| e.id)
            .collect();
        for id in ids {
            self.remove_effect(id);
        }
    }

    pub fn remove_one_shot_effects_from_source(&mut self, source: ObjectId) {
        let ids: Vec<_> = self
            .effects
            .iter()
            .filter(|e| {
                e.source == source
                    && self.is_one_shot(e.id)
            })
            .map(|e| e.id)
            .collect();
        for id in ids {
            self.remove_effect(id);
        }
    }

    /// Get all effects that might apply to a damage event.
    /// All effects are returned and filtered at runtime via matches_event().
    pub fn get_damage_replacements(&self) -> Vec<&ReplacementEffect> {
        self.effects
            .iter()
            .filter(|e| e.matcher.is_some())
            .collect()
    }

    /// Get all effects that might apply to a zone change.
    /// All effects are returned and filtered at runtime via matches_event().
    pub fn get_zone_change_replacements(&self) -> Vec<&ReplacementEffect> {
        self.effects
            .iter()
            .filter(|e| e.matcher.is_some())
            .collect()
    }

    /// Get all effects that might apply to drawing cards.
    /// All effects are returned and filtered at runtime via matches_event().
    pub fn get_draw_replacements(&self) -> Vec<&ReplacementEffect> {
        self.effects
            .iter()
            .filter(|e| e.matcher.is_some())
            .collect()
    }

    /// Get a replacement effect by its ID.
    pub fn get_effect(&self, id: ReplacementEffectId) -> Option<&ReplacementEffect> {
        self.effects.iter().find(|e| e.id == id)
    }

    /// Add a replacement effect from a static ability.
    ///
    /// These effects are regenerated each state refresh, so they are tracked
    /// separately from resolution-based effects.
    pub fn add_static_ability_effect(&mut self, effect: ReplacementEffect) -> ReplacementEffectId {
        let id = self.register_effect(effect, false);
        self.effect_sources
            .insert(id.0, ReplacementEffectSource::StaticAbility);
        id
    }

    /// Add a replacement effect from a resolved spell/ability.
    pub fn add_resolution_effect(&mut self, effect: ReplacementEffect) -> ReplacementEffectId {
        let id = self.add_effect(effect);
        self.effect_sources
            .insert(id.0, ReplacementEffectSource::Resolution);
        id
    }

    /// Static-ability effects pinned for the simultaneous event in progress.
    pub fn simultaneous_static_pins(&self) -> Option<&[ReplacementEffect]> {
        self.simultaneous_static_pins.as_deref()
    }

    pub fn set_simultaneous_static_pins(
        &mut self,
        pins: Option<Vec<ReplacementEffect>>,
        attachments: std::collections::HashMap<ObjectId, Option<crate::object::AttachmentTarget>>,
    ) {
        self.simultaneous_static_pins = pins;
        self.simultaneous_source_attachments = attachments;
    }

    pub(crate) fn simultaneous_source_attachment(&self, source: ObjectId) -> Option<Option<crate::object::AttachmentTarget>> {
        self.simultaneous_source_attachments.get(&source).copied()
    }

    /// Currently registered effects generated by static abilities.
    pub fn static_ability_effects(&self) -> impl Iterator<Item = &ReplacementEffect> {
        self.effects.iter().filter(|effect| {
            self.effect_sources.get(&effect.id.0) == Some(&ReplacementEffectSource::StaticAbility)
        })
    }

    /// Clear all effects from static abilities.
    ///
    /// Called before regenerating static ability effects during state refresh.
    pub fn clear_static_ability_effects(&mut self) {
        let static_ids: Vec<ReplacementEffectId> = self
            .effects
            .iter()
            .filter(|e| {
                self.effect_sources
                    .get(&e.id.0)
                    .map(|s| *s == ReplacementEffectSource::StaticAbility)
                    .unwrap_or(false)
            })
            .map(|e| e.id)
            .collect();

        for id in static_ids {
            self.remove_effect(id);
        }
    }

    /// Get discard replacement effects that might apply.
    /// All effects are returned and filtered at runtime via matches_event().
    pub fn get_discard_replacements(&self) -> Vec<&ReplacementEffect> {
        self.effects
            .iter()
            .filter(|e| e.matcher.is_some())
            .collect()
    }

    // =========================================================================
    // One-Shot Effect Management
    // =========================================================================

    /// Add a one-shot replacement effect that will be consumed after use.
    ///
    /// One-shot effects are used for things like regeneration shields, which
    /// replace destruction once and then are removed. The effect is registered
    /// and tracked separately from static ability effects.
    ///
    /// Returns the ID of the added effect.
    pub fn add_one_shot_effect(&mut self, effect: ReplacementEffect) -> ReplacementEffectId {
        let id = self.add_effect(effect);
        self.one_shot_effects.insert(id);
        id
    }

    /// Add an entry replacement consumed after the next simultaneous ETB
    /// batch containing at least one matching object. Cleanup clears an
    /// unused effect just like an ordinary turn-scoped one-shot.
    pub fn add_batch_one_shot_effect(&mut self, effect: ReplacementEffect) -> ReplacementEffectId {
        let id = self.add_effect(effect);
        self.batch_one_shot_effects.insert(id);
        id
    }

    /// Add a turn-scoped replacement for the next damage occurrence in which
    /// it applies. Damage processing owns the occurrence boundary; ETB batches
    /// and ordinary one-shot replacements retain their independent lifetimes.
    pub fn add_next_damage_occurrence_effect(
        &mut self,
        effect: ReplacementEffect,
    ) -> ReplacementEffectId {
        let id = self.add_resolution_effect(effect);
        self.next_damage_occurrence_effects.insert(id);
        id
    }

    pub(crate) fn begin_damage_occurrence(&mut self) {
        self.damage_occurrence_frames.push(Default::default());
    }

    pub(crate) fn finish_damage_occurrence(&mut self) {
        if let Some(used) = self.damage_occurrence_frames.pop() {
            for id in used {
                self.remove_effect(id);
            }
        }
    }

    pub(crate) fn available_in_damage_occurrence(&self, id: ReplacementEffectId) -> bool {
        let ancestors = self.damage_occurrence_frames.len().saturating_sub(1);
        !self.damage_occurrence_frames[..ancestors]
            .iter()
            .any(|frame| frame.contains(&id))
    }

    /// Add a replacement effect that lasts until cleanup.
    pub fn add_until_end_of_turn_effect(
        &mut self,
        effect: ReplacementEffect,
    ) -> ReplacementEffectId {
        let id = self.add_effect(effect);
        self.until_end_of_turn_effects.insert(id);
        id
    }

    /// Keep a resolved replacement live across any intervening or skipped turns.
    pub fn add_until_next_turn_effect(
        &mut self,
        effect: ReplacementEffect,
        player: PlayerId,
        created_turn: u32,
    ) -> ReplacementEffectId {
        let id = self.add_resolution_effect(effect);
        self.until_next_turn_effects
            .insert(id, (player, created_turn, None));
        id
    }

    pub fn prepare_for_departing_player(&mut self, player: PlayerId, boundary: u32) {
        for (duration_player, _, departure_boundary) in self.until_next_turn_effects.values_mut() {
            if *duration_player == player {
                *departure_boundary = Some(boundary);
            }
        }
    }

    /// Called after the next active players are chosen and before their turn begins.
    pub fn expire_at_turn_start(&mut self, turn: u32, active_players: &[PlayerId]) {
        let expired: Vec<_> = self
            .until_next_turn_effects
            .iter()
            .filter_map(|(id, (player, created_turn, departure_boundary))| {
                let expired = departure_boundary.map_or(
                    turn > *created_turn && active_players.contains(player),
                    |boundary| turn >= boundary,
                );
                expired.then_some(*id)
            })
            .collect();
        for id in expired {
            self.remove_effect(id);
        }
    }

    /// Mark a one-shot effect as used and remove it.
    ///
    /// Returns true if the effect was found and removed, false if it wasn't
    /// a one-shot effect or didn't exist.
    /// Consume `redirected` damage from a one-shot "the next N damage ...
    /// is dealt to ... instead" redirection shield. The shield stays until
    /// all N damage has been redirected; it is removed once exhausted.
    /// Returns false when `id` is not such a shield (callers then consume it
    /// normally).
    pub fn consume_redirect_damage_amount(
        &mut self,
        id: ReplacementEffectId,
        redirected: u32,
    ) -> bool {
        if !self.one_shot_effects.contains(&id) {
            return false;
        }
        let Some(effect) = self.effects.iter_mut().find(|effect| effect.id == id) else {
            return false;
        };
        let ReplacementAction::RedirectDamageAmount { amount, .. } = &mut effect.replacement
        else {
            return false;
        };
        if redirected < *amount {
            *amount -= redirected;
            return true;
        }
        self.mark_effect_used(id)
    }

    pub fn mark_effect_used(&mut self, id: ReplacementEffectId) -> bool {
        if self.next_damage_occurrence_effects.contains(&id) {
            if let Some(frame) = self.damage_occurrence_frames.last_mut() {
                frame.insert(id);
            } else {
                // A direct, non-batched event is one complete occurrence.
                self.remove_effect(id);
            }
            return true;
        }
        if self.batch_one_shot_effects.contains(&id) {
            self.pending_batch_one_shot_effects.insert(id);
            return true;
        }
        if self.one_shot_effects.remove(&id) {
            self.remove_effect(id);
            true
        } else {
            false
        }
    }

    /// Check if an effect is a one-shot effect.
    pub fn is_one_shot(&self, id: ReplacementEffectId) -> bool {
        self.one_shot_effects.contains(&id)
            || self.batch_one_shot_effects.contains(&id)
            || self.next_damage_occurrence_effects.contains(&id)
    }

    /// Consume every batch-scoped one-shot applied while preparing the current
    /// simultaneous ETB event. Called only after all sibling proposals have
    /// had a chance to see the same replacement.
    pub fn consume_pending_batch_one_shot_effects(&mut self) {
        let used: Vec<_> = self.pending_batch_one_shot_effects.drain().collect();
        for id in used {
            self.remove_effect(id);
        }
    }

    /// Clear all one-shot effects (e.g., at end of turn).
    pub fn clear_one_shot_effects(&mut self) {
        // A followed replacement whose card is already a spell on the stack
        // still applies to that spell after this turn ends.
        let kept: std::collections::HashSet<ReplacementEffectId> = self
            .followed_objects
            .iter()
            .filter(|(_, followed)| followed.on_stack)
            .map(|(id, _)| *id)
            .collect();
        let one_shot_ids: Vec<_> = self
            .one_shot_effects
            .iter()
            .chain(&self.batch_one_shot_effects)
            .chain(&self.next_damage_occurrence_effects)
            .copied()
            .filter(|id| !kept.contains(id))
            .collect();
        for id in one_shot_ids {
            self.remove_effect(id);
        }
        self.one_shot_effects.retain(|id| kept.contains(id));
        self.batch_one_shot_effects.clear();
        self.pending_batch_one_shot_effects.clear();
        self.next_damage_occurrence_effects.clear();
    }

    /// Clear all replacement effects that expire during cleanup.
    pub fn clear_until_end_of_turn_effects(&mut self) {
        let ids: Vec<_> = self.until_end_of_turn_effects.iter().copied().collect();
        for id in ids {
            self.remove_effect(id);
        }
        self.until_end_of_turn_effects.clear();
    }

    /// Get the count of one-shot effects from a specific source.
    ///
    /// This is useful for checking how many regeneration shields a creature has.
    pub fn count_one_shot_effects_from_source(&self, source: ObjectId) -> u32 {
        self.effects
            .iter()
            .filter(|e| {
                e.source == source
                    && self.is_one_shot(e.id)
            })
            .count() as u32
    }
}

impl ReplacementEffect {
    /// Create a new replacement effect using a trait-based matcher.
    pub fn with_matcher<M: ReplacementMatcher + 'static>(
        source: ObjectId,
        controller: PlayerId,
        matcher: M,
        replacement: ReplacementAction,
    ) -> Self {
        Self {
            id: ReplacementEffectId(0),
            registration_id: None,
            source,
            controller,
            replacement,
            priority_override: None,
            matcher: Some(Box::new(matcher)),
            static_ability_instance: None,
            ability_origin: None,
            optional: false,
            optional_by_controller: false,
        }
    }

    /// Create a new replacement effect using a boxed trait-based matcher.
    pub fn with_boxed_matcher(
        source: ObjectId,
        controller: PlayerId,
        matcher: Box<dyn ReplacementMatcher>,
        replacement: ReplacementAction,
    ) -> Self {
        Self {
            id: ReplacementEffectId(0),
            registration_id: None,
            source,
            controller,
            replacement,
            priority_override: None,
            matcher: Some(matcher),
            static_ability_instance: None,
            ability_origin: None,
            optional: false,
            optional_by_controller: false,
        }
    }

    /// Set a trait-based matcher on this effect.
    pub fn with_trait_matcher<M: ReplacementMatcher + 'static>(mut self, matcher: M) -> Self {
        self.matcher = Some(Box::new(matcher));
        self
    }

    /// Override the natural priority bucket used when applying this effect.
    pub fn with_priority_override(mut self, priority: ReplacementPriority) -> Self {
        self.priority_override = Some(priority);
        self
    }

    pub fn optional(mut self) -> Self {
        self.optional = true;
        self
    }

    pub fn with_controller_option(mut self, optional: bool) -> Self {
        self.optional_by_controller = optional;
        self
    }

    /// Choices within one token replacement share its application identity.
    /// Register the alternatives with separate selectable IDs, but accepting
    /// either consumes the same CR 614.5 opportunity as declining it.
    pub fn token_template_alternatives(&self) -> Vec<Self> {
        let ReplacementAction::TokenCreationTemplates { templates, mode, choose_one: true, .. } = &self.replacement else {
            return vec![self.clone()];
        };
        let parent = self.application_key();
        templates.iter().map(|template| {
            let mut alternative = self.clone();
            alternative.replacement = ReplacementAction::TokenCreationTemplates {
                templates: vec![template.clone()], mode: *mode, choose_one: false,
                choice_parent: Some(parent.clone()),
            };
            alternative
        }).collect()
    }

    /// "choose a creature other than Esix and create that many tokens that
    /// are copies of that creature" (Esix, Fractal Bloom): a copy template
    /// naming a filter of permanents, rather than one fixed permanent, is a
    /// choice among the matching permanents made as the replacement applies
    /// (CR 616.1, 707.2). Offer one alternative per candidate; like a
    /// choose-one template list, every alternative shares this effect's
    /// application identity, so accepting any of them (or declining) uses the
    /// same CR 614.5 opportunity. A unique or absent match stays as is.
    pub fn token_copy_choice_alternatives(
        &self,
        game: &crate::game_state::GameState,
    ) -> Vec<Self> {
        use crate::filter::ObjectFilterExt as _;
        let ReplacementAction::TokenCreationTemplates {
            templates,
            mode,
            choose_one: false,
            choice_parent,
        } = &self.replacement
        else {
            return vec![self.clone()];
        };
        let Some((index, copy, filter)) = templates.iter().enumerate().find_map(|(index, template)| {
            let copy = template.downcast_ref::<crate::effects::CreateTokenCopyEffect>()?;
            match copy.target.base() {
                crate::target::ChooseSpec::Object(filter) => Some((index, copy, filter)),
                _ => None,
            }
        }) else {
            return vec![self.clone()];
        };
        let filter_ctx = game.filter_context_for(self.controller, Some(self.source));
        let candidates: Vec<ObjectId> = game
            .battlefield
            .iter()
            .copied()
            .filter(|id| {
                game.object(*id)
                    .is_some_and(|object| filter.matches(object, &filter_ctx, game))
            })
            .collect();
        if candidates.len() <= 1 {
            return vec![self.clone()];
        }
        let parent = choice_parent
            .clone()
            .unwrap_or_else(|| self.application_key());
        candidates
            .into_iter()
            .map(|candidate| {
                let mut chosen = copy.clone();
                chosen.target = crate::target::ChooseSpec::SpecificObject(candidate);
                let mut chosen_templates = templates.clone();
                chosen_templates[index] = Effect::new(chosen);
                let mut alternative = self.clone();
                alternative.replacement = ReplacementAction::TokenCreationTemplates {
                    templates: chosen_templates,
                    mode: *mode,
                    choose_one: false,
                    choice_parent: Some(parent.clone()),
                };
                alternative
            })
            .collect()
    }

    /// Build the alternative for declining this same effect. For persistent
    /// effects, derive this from the registered effect so it carries the
    /// registration identity rather than the pre-registration fingerprint.
    pub fn optional_decline_effect(&self) -> Option<Self> {
        self.optional.then(|| Self {
            id: ReplacementEffectId(0),
            registration_id: None,
            source: self.source,
            controller: self.controller,
            replacement: ReplacementAction::DeclineOptional(self.application_key()),
            priority_override: self.priority_override,
            matcher: self.matcher.as_ref().map(|matcher| matcher.clone_box()),
            static_ability_instance: self.static_ability_instance,
            ability_origin: self.ability_origin.clone(),
            optional: false,
            optional_by_controller: false,
        })
    }

    /// Create a damage prevention effect.
    pub fn prevent_damage(source: ObjectId, controller: PlayerId, amount: u32) -> Self {
        Self::with_matcher(
            source,
            controller,
            DamageToPlayerMatcher::to_you(),
            ReplacementAction::PreventDamageAmount(amount),
        )
    }

    /// Create a "can't gain life" effect.
    pub fn cant_gain_life(source: ObjectId, controller: PlayerId) -> Self {
        Self::with_matcher(
            source,
            controller,
            WouldGainLifeMatcher::any_player(),
            ReplacementAction::Prevent,
        )
    }

    /// Create an "enters tapped" effect.
    pub fn enters_tapped(source: ObjectId, controller: PlayerId, filter: ObjectFilter) -> Self {
        Self::with_matcher(
            source,
            controller,
            WouldEnterBattlefieldMatcher::new(filter),
            ReplacementAction::EnterTapped,
        )
    }

    /// Create a "this enters with N counters" effect.
    pub fn enters_with_counters(
        source: ObjectId,
        controller: PlayerId,
        counter_type: CounterType,
        count: Value,
    ) -> Self {
        Self::with_matcher(
            source,
            controller,
            ThisWouldEnterBattlefieldMatcher,
            ReplacementAction::EnterWithCounters {
                counter_kinds_from: None,
                counter_type,
                count,
                count_condition: None,
                otherwise_count: None,
                added_subtypes: Vec::new(),
                added_abilities: Vec::new(),
            },
        )
    }

    /// Create a "if this would die, exile it instead" effect.
    pub fn exile_instead_of_dying(source: ObjectId, controller: PlayerId) -> Self {
        Self::with_matcher(
            source,
            controller,
            ThisWouldDieMatcher,
            ReplacementAction::ChangeDestination(Zone::Exile),
        )
    }

    /// Create a "double damage" effect.
    pub fn double_damage(
        source: ObjectId,
        controller: PlayerId,
        from_filter: ObjectFilter,
    ) -> Self {
        Self::with_matcher(
            source,
            controller,
            DamageFromSourceMatcher::new(from_filter),
            ReplacementAction::Double,
        )
    }

    /// Create a "skip draw step" effect.
    pub fn skip_draw(source: ObjectId, controller: PlayerId, player: PlayerFilter) -> Self {
        Self::with_matcher(
            source,
            controller,
            WouldDrawCardMatcher::new(player),
            ReplacementAction::Skip,
        )
    }

    // Note: "Can't lose the game" (Platinum Angel) is implemented via CantEffects,
    // not as a replacement effect. See game_state.rs CantEffects::can_lose_game().

    /// Create an indestructible effect.
    pub fn indestructible(source: ObjectId, controller: PlayerId) -> Self {
        Self::with_matcher(
            source,
            controller,
            ThisWouldBeDestroyedMatcher,
            ReplacementAction::Prevent,
        )
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn damage_occurrence_clone_preserves_identity_and_isolates_nested_and_entry_lifetimes() {
        let source = ObjectId::from_raw(73);
        let player = PlayerId::from_index(0);
        let mut manager = ReplacementEffectManager::new();
        let effect = ReplacementEffect::with_matcher(
            source, player, DamageToPlayerMatcher::to_you(), ReplacementAction::Double,
        );
        let damage = manager.add_next_damage_occurrence_effect(effect.clone());
        let entry = manager.add_batch_one_shot_effect(effect.clone());
        manager.mark_effect_used(entry);
        let unused = manager.add_next_damage_occurrence_effect(effect);
        manager.begin_damage_occurrence();
        manager.mark_effect_used(damage);
        let key = manager.get_effect(damage).unwrap().application_key();
        let mut restored = manager.clone();
        assert_eq!(restored.get_effect(damage).unwrap().application_key(), key);
        assert!(restored.available_in_damage_occurrence(damage));
        restored.begin_damage_occurrence();
        assert!(!restored.available_in_damage_occurrence(damage));
        assert!(restored.available_in_damage_occurrence(unused));
        restored.finish_damage_occurrence();
        assert!(restored.available_in_damage_occurrence(damage));
        restored.finish_damage_occurrence();
        assert!(restored.get_effect(damage).is_none());
        assert!(restored.get_effect(entry).is_some());
        assert!(restored.get_effect(unused).is_some());
        assert!(manager.get_effect(damage).is_some(), "clone leaves the checkpoint intact");
        restored.consume_pending_batch_one_shot_effects();
        assert!(restored.get_effect(entry).is_none());
        assert!(restored.get_effect(unused).is_some());
        restored.clear_one_shot_effects();
        assert!(restored.get_effect(unused).is_none());
        assert!(restored.one_shot_effects_snapshot().is_empty());
        assert!(restored.effect_sources_snapshot().is_empty());
    }

    fn registered_lifetime_fixture() -> (ReplacementEffectManager, [ReplacementEffectId; 5]) {
        let source = ObjectId::from_raw(71);
        let player = PlayerId::from_index(1);
        let mut manager = ReplacementEffectManager::new();
        let effect = ReplacementEffect::with_matcher(source, player, WouldGainLifeMatcher::you(), ReplacementAction::Double);
        let gap = manager.add_resolution_effect(effect.clone()); manager.remove_effect(gap);
        manager.add_static_ability_effect(effect.clone());
        let persistent = manager.add_resolution_effect(effect.clone());
        let one = manager.add_one_shot_effect(effect.clone());
        let batch = manager.add_batch_one_shot_effect(effect.clone());
        manager.mark_effect_used(batch);
        let cleanup = manager.add_until_end_of_turn_effect(effect.clone());
        let turn = manager.add_until_next_turn_effect(effect, player, 4);
        manager.prepare_for_departing_player(player, 9);
        (manager, [persistent, one, batch, cleanup, turn])
    }

    fn complete_descriptor_fixture() -> ReplacementEffect {
        let mut effect = ReplacementEffect::with_matcher(
            ObjectId::from_raw(173), PlayerId::from_index(1),
            WouldGainLifeMatcher::you(), ReplacementAction::Double,
        ).with_ability_origin(crate::continuous::AbilityOrigin::Printed(4), Some(crate::ids::CardId::new()), 7);
        effect.id = ReplacementEffectId(29);
        effect.registration_id = Some(ReplacementEffectId(29));
        effect.priority_override = Some(ReplacementPriority::SelfReplacement);
        effect.static_ability_instance = Some(crate::static_abilities::StaticAbility::enters_tapped_ability().instance_id());
        effect.optional = true;
        effect
    }

    #[test]
    fn native_clone_preserves_complete_replacement_descriptor() {
        let original = complete_descriptor_fixture();
        let mapped = original.clone();
        assert_eq!(mapped.id, original.id);
        assert_eq!(mapped.registration_id, original.registration_id);
        assert_eq!(mapped.source, original.source);
        assert_eq!(mapped.controller, original.controller);
        assert_eq!(mapped.replacement, original.replacement);
        assert_eq!(mapped.priority_override, original.priority_override);
        assert_eq!(mapped.static_ability_instance, original.static_ability_instance);
        assert_eq!(mapped.ability_origin, original.ability_origin);
        assert_eq!(mapped.optional, original.optional);
        assert_eq!(mapped.application_key(), original.application_key());
        assert_eq!(mapped.matcher.as_ref().unwrap().as_ref().downcast_ref::<WouldGainLifeMatcher>().unwrap().player_filter,
            original.matcher.as_ref().unwrap().as_ref().downcast_ref::<WouldGainLifeMatcher>().unwrap().player_filter);
        let mut absent = original;
        absent.matcher = None; absent.static_ability_instance = None; absent.ability_origin = None;
        let mapped = absent.clone();
        assert!(mapped.matcher.is_none());
        assert!(mapped.static_ability_instance.is_none());
        assert!(mapped.ability_origin.is_none());
    }

    #[test]
    fn native_clone_preserves_replacement_consumption_expiry_and_identity() {
        let (original, ids) = registered_lifetime_fixture();
        let keys = original.effects().iter().map(ReplacementEffect::application_key).collect::<Vec<_>>();
        let mut restored = original.clone();
        assert_eq!(restored.effects().iter().map(ReplacementEffect::application_key).collect::<Vec<_>>(), keys);
        assert_eq!(restored.next_id(), original.next_id());
        assert!(restored.mark_effect_used(ids[1]));
        restored.consume_pending_batch_one_shot_effects();
        assert!(restored.get_effect(ids[1]).is_none());
        assert!(restored.get_effect(ids[2]).is_none());
        restored.clear_until_end_of_turn_effects();
        assert!(restored.get_effect(ids[3]).is_none());
        restored.expire_at_turn_start(8, &[PlayerId::from_index(0)]);
        assert!(restored.get_effect(ids[4]).is_some());
        restored.expire_at_turn_start(9, &[PlayerId::from_index(0)]);
        assert!(restored.get_effect(ids[4]).is_none(), "departed player's actual next-turn boundary retained");
        assert!(restored.get_effect(ids[0]).is_some());
        let next = restored.add_resolution_effect(original.get_effect(ids[0]).unwrap().clone());
        assert_eq!(next.0, original.next_id());
    }

    #[test]
    fn native_clone_executes_each_replacement_instead_body() {
        use crate::effects::{EffectExecutor, ExecutionContext};
        let mut game = crate::tests::test_helpers::setup_two_player_game();
        let alice = PlayerId::from_index(0); let bob = PlayerId::from_index(1);
        let source = game.new_object_id();
        let body = Effect::gain_life_player(3, ChooseSpec::Player(PlayerFilter::Opponent));
        let mut original = ReplacementEffectManager::new();
        let id = original.add_until_end_of_turn_effect(ReplacementEffect::with_matcher(
            source, bob, WouldGainLifeMatcher::you(), ReplacementAction::Instead(vec![body.clone(), body]),
        ));
        assert_eq!(original.effects()[0].application_key(), ReplacementEffectKey::Registered(id));
        game.effect_store.replacement_effects = original.clone();
        let effect = crate::effects::GainLifeEffect::new(2, ChooseSpec::Player(PlayerFilter::You));
        let mut context = ExecutionContext::new_default(source, bob);
        let outcome = effect.execute(&mut game, &mut context).unwrap();
        assert_eq!(game.player(bob).unwrap().life, 20, "do not also commit the original gain");
        assert_eq!(game.player(alice).unwrap().life, 26, "both bodies use the captured Bob controller");
        let gains = outcome.events.iter().filter_map(|event|
            event.downcast::<crate::events::LifeGainEvent>()
        ).collect::<Vec<_>>();
        assert_eq!(gains.len(), 2);
        assert!(gains.iter().all(|event| event.player == alice && event.amount == 3));
        game.effect_store.replacement_effects.clear_until_end_of_turn_effects();
        effect.execute(&mut game, &mut context).unwrap();
        assert_eq!(game.player(bob).unwrap().life, 22, "retained replacement expires normally");
        assert_eq!(game.player(alice).unwrap().life, 26);
    }

    #[test]
    fn native_clone_executes_replacement_captured_controller() {
        use crate::effects::{EffectExecutor, ExecutionContext};
        let mut game = crate::tests::test_helpers::setup_two_player_game();
        let alice = PlayerId::from_index(0); let bob = PlayerId::from_index(1);
        let source = game.new_object_id();
        let mut original = ReplacementEffectManager::new();
        original.add_until_next_turn_effect(ReplacementEffect::with_matcher(
            source, bob, WouldGainLifeMatcher::you(), ReplacementAction::Double,
        ), bob, 4);
        game.effect_store.replacement_effects = original.clone();
        let effect = crate::effects::GainLifeEffect::new(2, ChooseSpec::Player(PlayerFilter::You));
        let mut bob_ctx = ExecutionContext::new_default(source, bob);
        effect.execute(&mut game, &mut bob_ctx).unwrap();
        assert_eq!(game.player(bob).unwrap().life, 24);
        let mut alice_ctx = ExecutionContext::new_default(source, alice);
        effect.execute(&mut game, &mut alice_ctx).unwrap();
        assert_eq!(game.player(alice).unwrap().life, 22);
        game.effect_store.replacement_effects.expire_at_turn_start(5, &[alice]);
        effect.execute(&mut game, &mut bob_ctx).unwrap();
        assert_eq!(game.player(bob).unwrap().life, 28);
        game.effect_store.replacement_effects.expire_at_turn_start(6, &[bob]);
        effect.execute(&mut game, &mut bob_ctx).unwrap();
        assert_eq!(game.player(bob).unwrap().life, 30);
    }



    #[test]
    fn source_removal_clears_lifetime_state_without_touching_other_registrations() {
        let mut manager = ReplacementEffectManager::new();
        let player = PlayerId::from_index(0);
        let removed_source = ObjectId::from_raw(71);
        let kept_source = ObjectId::from_raw(72);
        let register = |manager: &mut ReplacementEffectManager, source| {
            let effect = ReplacementEffect::with_matcher(
                source, player, WouldGainLifeMatcher::you(), ReplacementAction::Double,
            );
            let static_id = manager.add_static_ability_effect(effect.clone());
            let resolution = manager.add_resolution_effect(effect.clone());
            let one_shot = manager.add_one_shot_effect(effect.clone());
            let batch = manager.add_batch_one_shot_effect(effect.clone());
            assert!(manager.mark_effect_used(batch));
            let cleanup = manager.add_until_end_of_turn_effect(effect.clone());
            let next_turn = manager.add_until_next_turn_effect(effect, player, 4);
            [static_id, resolution, one_shot, batch, cleanup, next_turn]
        };
        let removed = register(&mut manager, removed_source);
        let kept = register(&mut manager, kept_source);
        manager.prepare_for_departing_player(player, 9);
        let next_id = manager.next_id();
        manager.remove_effects_from_source(removed_source);
        for id in removed {
            assert!(manager.get_effect(id).is_none());
            assert!(!manager.effect_sources.contains_key(&id.0), "removed source provenance retained");
            assert!(!manager.one_shot_effects.contains(&id), "removed one-shot retained");
            assert!(!manager.batch_one_shot_effects.contains(&id), "removed batch one-shot retained");
            assert!(!manager.pending_batch_one_shot_effects.contains(&id), "removed pending consumption retained");
            assert!(!manager.until_end_of_turn_effects.contains(&id), "removed cleanup scope retained");
            assert!(!manager.until_next_turn_effects.contains_key(&id), "removed next-turn anchor retained");
        }
        assert_eq!(manager.next_id(), next_id);
        assert_eq!(manager.effects().iter().map(|effect| effect.id).collect::<Vec<_>>(), kept);
        assert_eq!(manager.effect_sources.get(&kept[0].0), Some(&ReplacementEffectSource::StaticAbility));
        assert_eq!(manager.effect_sources.get(&kept[1].0), Some(&ReplacementEffectSource::Resolution));
        assert_eq!(manager.until_next_turn_effects.get(&kept[5]), Some(&(player, 4, Some(9))));
        assert!(manager.is_one_shot(kept[2]));
        assert!(manager.is_one_shot(kept[3]));
        manager.remove_effects_from_source(removed_source);
        manager.consume_pending_batch_one_shot_effects();
        assert!(manager.get_effect(kept[3]).is_none());
        assert!(manager.mark_effect_used(kept[2]));
        manager.clear_until_end_of_turn_effects();
        assert!(manager.get_effect(kept[4]).is_none());
        manager.expire_at_turn_start(8, &[player]);
        assert!(manager.get_effect(kept[5]).is_some());
        manager.expire_at_turn_start(9, &[]);
        assert!(manager.get_effect(kept[5]).is_none());
        manager.clear_static_ability_effects();
        assert_eq!(manager.effects().iter().map(|effect| effect.id).collect::<Vec<_>>(), vec![kept[1]]);
        let replacement = manager.add_resolution_effect(ReplacementEffect::with_matcher(
            removed_source, player, WouldGainLifeMatcher::you(), ReplacementAction::Double,
        ));
        assert_eq!(replacement.0, next_id);
        assert!(!manager.is_one_shot(replacement));
    }


    #[test]
    fn registration_identity_distinguishes_instances_and_survives_payload_changes() {
        let mut manager = ReplacementEffectManager::new();
        let effect = ReplacementEffect::with_matcher(
            ObjectId::from_raw(1),
            PlayerId::from_index(0),
            WouldGainLifeMatcher::you(),
            ReplacementAction::Double,
        );
        let first = manager.add_resolution_effect(effect.clone());
        let second = manager.add_resolution_effect(effect.clone());
        let key = manager.get_effect(first).unwrap().application_key();
        assert_ne!(key, manager.get_effect(second).unwrap().application_key());
        let mut changed = manager.get_effect(first).unwrap().clone();
        changed.replacement = ReplacementAction::Prevent;
        assert_eq!(key, changed.application_key());

        let static_id = manager.add_static_ability_effect(effect.clone());
        let static_key = manager.get_effect(static_id).unwrap().application_key();
        manager.clear_static_ability_effects();
        let regenerated_id = manager.add_static_ability_effect(effect);
        assert_ne!(static_id, regenerated_id);
        assert_eq!(
            static_key,
            manager
                .get_effect(regenerated_id)
                .unwrap()
                .application_key()
        );
        assert_eq!(key, manager.get_effect(first).unwrap().application_key());
    }

    #[test]
    fn optional_alternatives_share_only_their_own_registered_parent_identity() {
        let mut manager = ReplacementEffectManager::new();
        let effect = ReplacementEffect::with_matcher(
            ObjectId::from_raw(1), PlayerId::from_index(0),
            WouldGainLifeMatcher::you(), ReplacementAction::Double,
        ).optional();
        let first = manager.add_resolution_effect(effect.clone());
        let second = manager.add_resolution_effect(effect);
        let decline = manager.get_effect(first).unwrap().optional_decline_effect().unwrap();
        let declined = manager.add_resolution_effect(decline);
        assert_eq!(manager.get_effect(first).unwrap().application_key(), manager.get_effect(declined).unwrap().application_key());
        assert_ne!(manager.get_effect(second).unwrap().application_key(), manager.get_effect(declined).unwrap().application_key());
    }

    /// CR 701.19c: "can't be regenerated" removes regeneration shields only,
    /// not other one-shot replacements sourced from the same permanent.
    #[test]
    fn removing_regeneration_shields_keeps_other_one_shot_effects() {
        let source = ObjectId::from_raw(7);
        let controller = PlayerId::from_index(0);
        let mut manager = ReplacementEffectManager::new();
        let shield = manager.add_one_shot_effect(ReplacementEffect::with_matcher(
            source,
            controller,
            crate::events::permanents::matchers::RegenerationShieldMatcher::new(source),
            ReplacementAction::Instead(Vec::new()),
        ));
        let other = manager.add_one_shot_effect(ReplacementEffect::with_matcher(
            source,
            controller,
            crate::events::permanents::matchers::ThisWouldBeDestroyedMatcher,
            ReplacementAction::Instead(Vec::new()),
        ));
        manager.remove_regeneration_shields_from_source(source);
        assert!(manager.get_effect(shield).is_none(), "regeneration shield removed");
        assert!(manager.get_effect(other).is_some(), "unrelated replacement kept");
    }

    #[test]
    fn test_damage_prevention() {
        let effect =
            ReplacementEffect::prevent_damage(ObjectId::from_raw(1), PlayerId::from_index(0), 3);

        assert!(
            effect.matcher.is_some(),
            "prevent_damage should use trait-based matcher"
        );
        assert!(matches!(
            effect.replacement,
            ReplacementAction::PreventDamageAmount(3)
        ));
    }

    #[test]
    fn test_enters_with_counters() {
        let effect = ReplacementEffect::enters_with_counters(
            ObjectId::from_raw(1),
            PlayerId::from_index(0),
            CounterType::PlusOnePlusOne,
            Value::Fixed(3),
        );

        assert_eq!(effect.priority_override, None);
        assert!(
            effect.matcher.is_some(),
            "enters_with_counters should use trait-based matcher"
        );
        assert!(matches!(
            effect.replacement,
            ReplacementAction::EnterWithCounters { .. }
        ));
    }

    #[test]
    fn test_exile_instead_of_dying() {
        let effect = ReplacementEffect::exile_instead_of_dying(
            ObjectId::from_raw(1),
            PlayerId::from_index(0),
        );

        assert_eq!(effect.priority_override, None);
        assert!(
            effect.matcher.is_some(),
            "exile_instead_of_dying should use trait-based matcher"
        );
        assert!(matches!(
            effect.replacement,
            ReplacementAction::ChangeDestination(Zone::Exile)
        ));
    }

    #[test]
    fn test_replacement_manager() {
        let mut manager = ReplacementEffectManager::new();

        let effect1 =
            ReplacementEffect::prevent_damage(ObjectId::from_raw(1), PlayerId::from_index(0), 3);
        let effect2 = ReplacementEffect::enters_with_counters(
            ObjectId::from_raw(2),
            PlayerId::from_index(0),
            CounterType::PlusOnePlusOne,
            Value::Fixed(2),
        );

        let id1 = manager.add_effect(effect1);
        let id2 = manager.add_effect(effect2);

        // Effects are tracked
        assert_eq!(manager.effects().len(), 2);

        // Both effects have matchers (used by the new trait-based system)
        assert!(manager.effects().iter().all(|e| e.matcher.is_some()));

        // Remove one effect
        manager.remove_effect(id1);
        assert_eq!(manager.effects().len(), 1);
        assert_eq!(manager.effects()[0].id, id2);
    }

    #[test]
    fn test_priority_override() {
        let effect = ReplacementEffect::with_matcher(
            ObjectId::from_raw(1),
            PlayerId::from_index(0),
            ThisWouldEnterBattlefieldMatcher,
            ReplacementAction::EnterTapped,
        )
        .with_priority_override(ReplacementPriority::CopyEffect);

        assert_eq!(
            effect.priority_override,
            Some(ReplacementPriority::CopyEffect)
        );
    }
}

#[cfg(test)]
mod ability_origin_identity_tests {
    use super::*;
    #[test]
    fn originating_occurrences_survive_controller_payload_and_optional_changes() {
        let source=ObjectId::from_raw(90100); let alice=PlayerId::from_index(0);
        let ability=crate::static_abilities::StaticAbility::double_life_change_replacement(
            PlayerFilter::You, false, "Double life gain");
        let first=ability.generate_replacement_effect(source, alice).unwrap()
            .with_ability_origin(crate::continuous::AbilityOrigin::Printed(0), None, 0);
        let second=ability.generate_replacement_effect(source, alice).unwrap()
            .with_ability_origin(crate::continuous::AbilityOrigin::Printed(1), None, 0);
        assert_ne!(first.application_key(), second.application_key(), "cloned static values are distinct originating slots");
        let mut changed=first.clone(); changed.controller=PlayerId::from_index(1);
        changed.replacement=ReplacementAction::Prevent;
        assert_eq!(changed.application_key(), first.application_key());
        let decline=first.clone().optional().optional_decline_effect().unwrap();
        assert_eq!(decline.application_key(), first.application_key());
        let sibling=first.clone().with_ability_origin(crate::continuous::AbilityOrigin::Printed(0), None, 1);
        assert_ne!(sibling.application_key(), first.application_key(), "generated siblings retain branch identity");
    }
}

// Pure production rewrites are exposed independently of event matching. This
// does not assert that a replacement matches, or that it is safe to reorder.
impl ReplacementAction {
    pub fn needs_mana_color_choice(&self) -> bool {
        matches!(self, Self::RewriteMana { output: ironsmith_core::ManaRewriteOutput::ChooseColor | ironsmith_core::ManaRewriteOutput::ByBasicLandType(_), .. })
    }
    pub fn mana_transformation_with_color(&self, color: Option<crate::mana::ManaSymbol>)
        -> Option<crate::events::mana::ManaTransformation<'_>> {
        if let Self::RewriteMana { input, output: ironsmith_core::ManaRewriteOutput::ChooseColor | ironsmith_core::ManaRewriteOutput::ByBasicLandType(_), quantity } = self {
            let symbol = color.filter(|symbol| ironsmith_core::ManaRewriteInput::Colored.matches(*symbol))?;
            Some(crate::events::mana::ManaTransformation::Rewrite { input: *input, symbol, quantity: *quantity })
        } else if color.is_none() { self.mana_transformation() } else { None }
    }

    pub fn mana_transformation(&self) -> Option<crate::events::mana::ManaTransformation<'_>> {
        use crate::events::mana::ManaTransformation;
        match self {
            Self::RewriteMana { input, output: ironsmith_core::ManaRewriteOutput::Symbol(symbol), quantity } =>
                Some(ManaTransformation::Rewrite { input: *input, symbol: *symbol, quantity: *quantity }),
            Self::ReplaceMana(symbols) => Some(ManaTransformation::ReplaceTypes(symbols)),
            Self::ReplaceManaExact(symbols) => Some(ManaTransformation::ReplaceExact(symbols)),
            Self::Modify(EventModification::Multiply(factor)) => Some(ManaTransformation::Multiply(*factor)),
            _ => None,
        }
    }
}

