use super::{StaticAbility, StaticAbilityId, StaticAbilityKind, ThisSpellCostCondition};
use crate::continuous::ContinuousEffect;
use crate::game_state::GameState;
use crate::ids::{ObjectId, PlayerId};
use crate::replacement::ReplacementEffect;
use ironsmith_core::ConditionConjunction;
use std::fmt;

pub type CompiledStaticAbility = ironsmith_core::StaticAbility<
    crate::triggers::Trigger,
    crate::effect::Effect,
    crate::costs::Cost,
    ThisSpellCostCondition,
>;

type CompiledAbilityModel = ironsmith_core::Ability<
    CompiledStaticAbility,
    crate::triggers::Trigger,
    crate::effect::Effect,
    crate::costs::Cost,
>;

type CompiledGrantSpec = ironsmith_core::GrantSpec<
    CompiledStaticAbility,
    crate::effect::Effect,
    crate::costs::Cost,
    ThisSpellCostCondition,
>;

#[derive(Clone)]
pub struct StaticAbilityModelInterpreter {
    model: CompiledStaticAbility,
    leaf_static_ability: Option<StaticAbility>,
    granted_inline_ability: Option<crate::ability::Ability>,
    granted_inline_condition: Option<crate::ConditionExpr>,
    source_granted_inline_abilities: Vec<crate::ability::Ability>,
    enter_as_copy_spec: Option<super::EnterAsCopyAsEntersSpec>,
    level_abilities: Option<Vec<crate::ability::LevelAbility>>,
    equipment_grant_abilities: Option<Vec<StaticAbility>>,
    grant_spec: Option<crate::grant::GrantSpec>,
    cost_reduction: Option<super::CostReduction>,
    activated_ability_cost_reduction: Option<super::ActivatedAbilityCostReduction>,
    activated_ability_cost_increase: Option<super::ActivatedAbilityCostIncrease>,
    cost_increase: Option<super::CostIncrease>,
    cost_increase_life: Option<super::CostIncreaseLife>,
    activate_abilities_as_though_haste: Option<super::ActivateAbilitiesAsThoughHaste>,
    cost_reduction_mana_cost: Option<super::CostReductionManaCost>,
    cost_increase_mana_cost: Option<super::CostIncreaseManaCost>,
    cost_increase_mana_cost_per_additional_target:
        Option<super::CostIncreaseManaCostPerAdditionalTarget>,
    this_spell_cost_reduction: Option<super::ThisSpellCostReduction>,
    this_spell_cost_reduction_mana_cost: Option<super::ThisSpellCostReductionManaCost>,
}

impl fmt::Debug for StaticAbilityModelInterpreter {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let payload = self.payload_debug_summary();
        f.debug_struct("StaticAbilityModelInterpreter")
            .field("id", &self.model.id)
            .field("label", &self.model.label)
            .field("payload", &payload)
            .finish_non_exhaustive()
    }
}

impl StaticAbilityModelInterpreter {
    fn ability_model_debug_summary(ability: &CompiledAbilityModel) -> String {
        match &ability.kind {
            ironsmith_core::AbilityKind::Static(static_ability) => format!(
                "Static({})",
                Self::static_model_debug_summary(static_ability)
            ),
            ironsmith_core::AbilityKind::Triggered(triggered) => format!(
                "TriggeredAbility {{ trigger: {:?}, effects: {:?}, choices: {:?}, intervening_if: {:?} }}",
                triggered.trigger, triggered.effects, triggered.choices, triggered.intervening_if
            ),
            ironsmith_core::AbilityKind::Activated(activated) => format!(
                "ActivatedAbility {{ mana_cost: {:?}, effects: {:?}, choices: {:?}, timing: {:?} }}",
                activated.mana_cost, activated.effects, activated.choices, activated.timing
            ),
        }
    }

    fn static_model_debug_summary(ability: &CompiledStaticAbility) -> String {
        match &ability.payload {
            ironsmith_core::StaticAbilityPayload::SoulbondSharedObjectAbility(granted) => format!(
                "SoulbondSharedObjectAbility({})",
                Self::ability_model_debug_summary(granted)
            ),
            ironsmith_core::StaticAbilityPayload::SoulbondSharedAbility(granted) => format!(
                "SoulbondSharedAbility({})",
                Self::static_model_debug_summary(granted)
            ),
            payload => format!(
                "StaticAbility {{ id: {:?}, label: {:?}, payload: {:?} }}",
                ability.id, ability.label, payload
            ),
        }
    }

    fn payload_debug_summary(&self) -> String {
        match self.payload() {
            ironsmith_core::StaticAbilityPayload::SoulbondSharedObjectAbility(ability) => format!(
                "SoulbondSharedObjectAbility({})",
                Self::ability_model_debug_summary(ability)
            ),
            ironsmith_core::StaticAbilityPayload::SoulbondSharedAbility(ability) => format!(
                "SoulbondSharedAbility({})",
                Self::static_model_debug_summary(ability)
            ),
            ironsmith_core::StaticAbilityPayload::ThisSpellCastRestriction { kind, display } => {
                format!(
                    "ThisSpellCastRestriction {{ kind: {:?}, display: {:?} }}",
                    Self::this_spell_cast_restriction_from_model(kind),
                    display
                )
            }
            ironsmith_core::StaticAbilityPayload::ThisSpellXMaximum { maximum, display, definition } => {
                if let Some(definition) = definition {
                    format!("ThisSpellXMaximum {{ maximum: {maximum:?}, display: {display:?}, definition: {definition:?} }}")
                } else {
                    format!("ThisSpellXMaximum {{ maximum: {maximum:?}, display: {display:?} }}")
                }
            }
            ironsmith_core::StaticAbilityPayload::ThisSpellXMinimum { minimum, display } => {
                format!("ThisSpellXMinimum {{ minimum: {minimum:?}, display: {display:?} }}")
            }
            ironsmith_core::StaticAbilityPayload::DieRollResultAdjustment(spec) => {
                format!("DieRollResultAdjustment {{ spec: {spec:?} }}")
            }
            payload => format!("{payload:?}"),
        }
    }

    pub fn new(model: CompiledStaticAbility) -> Self {
        let leaf_static_ability = Self::cached_leaf_static_ability(&model);
        // The leaf already materializes carried abilities. Reuse its shared
        // runtime handles: independently converting the same child for each
        // cache doubles work at every nested grant level.
        let granted_inline_ability = Self::model_has_inline_ability(&model)
            .then(|| {
                leaf_static_ability
                    .as_ref()
                    .and_then(StaticAbility::granted_inline_ability)
                    .cloned()
            })
            .flatten();
        let granted_inline_condition = Self::cached_granted_inline_condition(&model);
        let source_granted_inline_abilities = if Self::model_has_source_grants(&model) {
            leaf_static_ability
                .as_ref()
                .map(|leaf| {
                    leaf.source_granted_inline_abilities()
                        .into_iter()
                        .cloned()
                        .collect()
                })
                .unwrap_or_default()
        } else {
            Vec::new()
        };
        let enter_as_copy_spec = Self::cached_enter_as_copy_spec(&model);
        let level_abilities = Self::cached_level_abilities(&model);
        let equipment_grant_abilities = Self::cached_equipment_grant_abilities(&model);
        let grant_spec = Self::cached_grant_spec(&model);
        let cost_reduction = Self::cached_cost_reduction(&model);
        let activated_ability_cost_reduction =
            Self::cached_activated_ability_cost_reduction(&model);
        let activated_ability_cost_increase = Self::cached_activated_ability_cost_increase(&model);
        let cost_increase = Self::cached_cost_increase(&model);
        let cost_increase_life = Self::cached_cost_increase_life(&model);
        let activate_abilities_as_though_haste =
            Self::cached_activate_abilities_as_though_haste(&model);
        let cost_reduction_mana_cost = Self::cached_cost_reduction_mana_cost(&model);
        let cost_increase_mana_cost = Self::cached_cost_increase_mana_cost(&model);
        let cost_increase_mana_cost_per_additional_target =
            Self::cached_cost_increase_mana_cost_per_additional_target(&model);
        let this_spell_cost_reduction = Self::cached_this_spell_cost_reduction(&model);
        let this_spell_cost_reduction_mana_cost =
            Self::cached_this_spell_cost_reduction_mana_cost(&model);
        Self {
            model,
            leaf_static_ability,
            granted_inline_ability,
            granted_inline_condition,
            source_granted_inline_abilities,
            enter_as_copy_spec,
            level_abilities,
            equipment_grant_abilities,
            grant_spec,
            cost_reduction,
            activated_ability_cost_reduction,
            activated_ability_cost_increase,
            cost_increase,
            cost_increase_life,
            activate_abilities_as_though_haste,
            cost_reduction_mana_cost,
            cost_increase_mana_cost,
            cost_increase_mana_cost_per_additional_target,
            this_spell_cost_reduction,
            this_spell_cost_reduction_mana_cost,
        }
    }

    fn payload(
        &self,
    ) -> &ironsmith_core::StaticAbilityPayload<
        crate::triggers::Trigger,
        crate::effect::Effect,
        crate::costs::Cost,
        ThisSpellCostCondition,
    > {
        &self.model.payload
    }

    fn attack_cost_condition_from_model(
        condition: &ironsmith_core::AttackCostCondition,
    ) -> super::AttackCostCondition {
        match condition {
            ironsmith_core::AttackCostCondition::SacrificePermanents { filter, count } => {
                super::AttackCostCondition::SacrificePermanents {
                    filter: filter.clone(),
                    count: *count,
                }
            }
            ironsmith_core::AttackCostCondition::ReturnPermanentsToOwnersHand { filter, count } => {
                super::AttackCostCondition::ReturnPermanentsToOwnersHand {
                    filter: filter.clone(),
                    count: *count,
                }
            }
            ironsmith_core::AttackCostCondition::PayGenericPerSourceCounter {
                counter_type,
                amount_per_counter,
            } => super::AttackCostCondition::PayGenericPerSourceCounter {
                counter_type: *counter_type,
                amount_per_counter: *amount_per_counter,
            },
        }
    }

    fn attacking_group_condition_from_model(
        condition: &ironsmith_core::AttackingGroupAttackCondition,
    ) -> super::AttackingGroupAttackCondition {
        match condition {
            ironsmith_core::AttackingGroupAttackCondition::AtLeastNOtherCreaturesAttack(count) => {
                super::AttackingGroupAttackCondition::AtLeastNOtherCreaturesAttack(*count)
            }
            ironsmith_core::AttackingGroupAttackCondition::BlackOrGreenCreatureAlsoAttacks => {
                super::AttackingGroupAttackCondition::BlackOrGreenCreatureAlsoAttacks
            }
            ironsmith_core::AttackingGroupAttackCondition::CreatureWithGreaterPowerAlsoAttacks => {
                super::AttackingGroupAttackCondition::CreatureWithGreaterPowerAlsoAttacks
            }
            ironsmith_core::AttackingGroupAttackCondition::AtLeastNOtherCreaturesBlock(count) => {
                super::AttackingGroupAttackCondition::AtLeastNOtherCreaturesBlock(*count)
            }
            ironsmith_core::AttackingGroupAttackCondition::CreatureWithGreaterPowerAlsoBlocks => {
                super::AttackingGroupAttackCondition::CreatureWithGreaterPowerAlsoBlocks
            }
        }
    }

    fn defending_player_condition_from_model(
        condition: &ironsmith_core::DefendingPlayerAttackCondition,
    ) -> super::DefendingPlayerAttackCondition {
        match condition {
            ironsmith_core::DefendingPlayerAttackCondition::Controls(filter) => {
                super::DefendingPlayerAttackCondition::Controls(filter.clone())
            }
            ironsmith_core::DefendingPlayerAttackCondition::ControlsEnchantmentOrEnchantedPermanent => {
                super::DefendingPlayerAttackCondition::ControlsEnchantmentOrEnchantedPermanent
            }
            ironsmith_core::DefendingPlayerAttackCondition::HasCardsInGraveyardOrMore(count) => {
                super::DefendingPlayerAttackCondition::HasCardsInGraveyardOrMore(*count)
            }
            ironsmith_core::DefendingPlayerAttackCondition::IsMonarch => {
                super::DefendingPlayerAttackCondition::IsMonarch
            }
            ironsmith_core::DefendingPlayerAttackCondition::IsPoisoned => {
                super::DefendingPlayerAttackCondition::IsPoisoned
            }
        }
    }

    fn cant_attack_unless_condition_from_model(
        condition: &ironsmith_core::CantAttackUnlessConditionSpec,
    ) -> super::CantAttackUnlessConditionSpec {
        match condition {
            ironsmith_core::CantAttackUnlessConditionSpec::AttackCost(cost) => {
                super::CantAttackUnlessConditionSpec::AttackCost(
                    Self::attack_cost_condition_from_model(cost),
                )
            }
            ironsmith_core::CantAttackUnlessConditionSpec::AttackingGroupCondition(condition) => {
                super::CantAttackUnlessConditionSpec::AttackingGroupCondition(
                    Self::attacking_group_condition_from_model(condition),
                )
            }
            ironsmith_core::CantAttackUnlessConditionSpec::BattlefieldCountAtLeast {
                filter,
                count,
            } => super::CantAttackUnlessConditionSpec::BattlefieldCountAtLeast {
                filter: filter.clone(),
                count: *count,
            },
            ironsmith_core::CantAttackUnlessConditionSpec::ControllerControlsMoreThanDefendingPlayer(filter) => {
                super::CantAttackUnlessConditionSpec::ControllerControlsMoreThanDefendingPlayer(
                    filter.clone(),
                )
            }
            ironsmith_core::CantAttackUnlessConditionSpec::ControllerGraveyardHasCardsAtLeast(count) => {
                super::CantAttackUnlessConditionSpec::ControllerGraveyardHasCardsAtLeast(*count)
            }
            ironsmith_core::CantAttackUnlessConditionSpec::DefendingPlayerCondition(condition) => {
                super::CantAttackUnlessConditionSpec::DefendingPlayerCondition(
                    Self::defending_player_condition_from_model(condition),
                )
            }
            ironsmith_core::CantAttackUnlessConditionSpec::OpponentWasDealtDamageThisTurn => {
                super::CantAttackUnlessConditionSpec::OpponentWasDealtDamageThisTurn
            }
            ironsmith_core::CantAttackUnlessConditionSpec::SourceCondition(condition) => {
                super::CantAttackUnlessConditionSpec::SourceCondition(condition.clone())
            }
        }
    }

    fn is_simple_keyword_id(id: StaticAbilityId) -> bool {
        id.is_keyword()
    }

    fn core_landwalk_to_runtime(
        kind: ironsmith_core::LandwalkKind,
    ) -> crate::static_abilities::LandwalkKind {
        match kind {
            ironsmith_core::LandwalkKind::Subtype { subtype, snow } => {
                crate::static_abilities::LandwalkKind::Subtype { subtype, snow }
            }
            ironsmith_core::LandwalkKind::AnyLand => crate::static_abilities::LandwalkKind::AnyLand,
            ironsmith_core::LandwalkKind::NonbasicLand => {
                crate::static_abilities::LandwalkKind::NonbasicLand
            }
            ironsmith_core::LandwalkKind::ArtifactLand => {
                crate::static_abilities::LandwalkKind::ArtifactLand
            }
            ironsmith_core::LandwalkKind::LegendaryLand => {
                crate::static_abilities::LandwalkKind::LegendaryLand
            }
            ironsmith_core::LandwalkKind::SnowLand => {
                crate::static_abilities::LandwalkKind::SnowLand
            }
            ironsmith_core::LandwalkKind::ChosenType { snow } => {
                crate::static_abilities::LandwalkKind::ChosenType { snow }
            }
            ironsmith_core::LandwalkKind::SacrificedLandTypes => {
                crate::static_abilities::LandwalkKind::SacrificedLandTypes
            }
        }
    }

    pub fn ability_from_model(ability: &CompiledAbilityModel) -> crate::ability::Ability {
        let kind = match &ability.kind {
            ironsmith_core::AbilityKind::Static(static_ability) => {
                crate::ability::AbilityKind::Static(StaticAbility::from_model(
                    static_ability.clone(),
                ))
            }
            ironsmith_core::AbilityKind::Triggered(triggered) => {
                crate::ability::AbilityKind::Triggered(triggered.clone())
            }
            ironsmith_core::AbilityKind::Activated(activated) => {
                crate::ability::AbilityKind::Activated(activated.clone())
            }
        };
        crate::ability::Ability {
            kind,
            designations: ability.designations.clone(),
            functional_zones: ability.functional_zones.clone(),
        }
    }

    fn static_ability_from_ability_model(ability: &CompiledAbilityModel) -> Option<StaticAbility> {
        match &ability.kind {
            ironsmith_core::AbilityKind::Static(static_ability) => {
                Some(StaticAbility::from_model(static_ability.clone()))
            }
            _ => None,
        }
    }

    fn grant_spec_from_model(spec: &CompiledGrantSpec) -> crate::grant::GrantSpec {
        let grantable = match &spec.grantable {
            ironsmith_core::Grantable::Ability(static_ability) => {
                crate::grant::Grantable::Ability(StaticAbility::from_model(static_ability.clone()))
            }
            ironsmith_core::Grantable::AlternativeCast(method) => {
                crate::grant::Grantable::AlternativeCast(method.clone())
            }
            ironsmith_core::Grantable::DerivedAlternativeCast(spec) => {
                crate::grant::Grantable::DerivedAlternativeCast(spec.clone())
            }
            ironsmith_core::Grantable::PlayFrom => crate::grant::Grantable::PlayFrom,
            ironsmith_core::Grantable::AlternativePrice { costs, origin } => {
                crate::grant::Grantable::AlternativePrice {
                    costs: costs.clone(),
                    origin: *origin,
                }
            }
        };
        crate::grant::GrantSpec {
            grantable,
            filter: spec.filter.clone(),
            zone: spec.zone,
            additional_zones: spec.additional_zones.clone(),
            beneficiary: spec.beneficiary.clone(),
            usage_limit: spec.usage_limit,
            max_plays: spec.max_plays,
            cast_this_way_filter: spec.cast_this_way_filter.clone(),
            on_use_effects: spec.on_use_effects.clone(),
            requires_linked_exile_pair: spec.requires_linked_exile_pair,
            land_play_companion: spec.land_play_companion,
            may_look_at_linked_exile: spec.may_look_at_linked_exile,
            cast_mana_spend_mode: spec.cast_mana_spend_mode,
            linked_exile_pair: spec.linked_exile_pair,
            linked_exile_class_level: spec.linked_exile_class_level,
            source_exiled_surface: spec.source_exiled_surface.clone(),
            filtered_zone_surface: spec.filtered_zone_surface.clone(),
            top_card_only: spec.top_card_only,
            instant_timing: spec.instant_timing,
            may_look_at_top: spec.may_look_at_top,
            cast_this_way_grants: spec
                .cast_this_way_grants
                .iter()
                .cloned()
                .map(StaticAbility::from_model)
                .collect(),
            permanent_this_way_grants: spec
                .permanent_this_way_grants
                .iter()
                .cloned()
                .map(StaticAbility::from_model)
                .collect(),
        }
    }

    fn model_has_inline_ability(model: &CompiledStaticAbility) -> bool {
        match &model.payload {
            ironsmith_core::StaticAbilityPayload::AttachedAbilityGrant(_)
            | ironsmith_core::StaticAbilityPayload::SoulbondSharedObjectAbility(_) => true,
            ironsmith_core::StaticAbilityPayload::Conditional { ability, .. } => {
                Self::model_has_inline_ability(ability)
            }
            _ => false,
        }
    }

    fn cached_granted_inline_condition(
        model: &CompiledStaticAbility,
    ) -> Option<crate::ConditionExpr> {
        match &model.payload {
            ironsmith_core::StaticAbilityPayload::GrantObjectAbilityForFilter(grant) => {
                grant.condition.clone()
            }
            ironsmith_core::StaticAbilityPayload::Conditional { ability, condition, .. }
                if Self::model_has_inline_ability(ability)
                    || Self::model_has_source_grants(ability) =>
            {
                Some(match Self::cached_granted_inline_condition(ability) {
                    Some(inner) => inner.and(condition.clone()),
                    None => condition.clone(),
                })
            }
            _ => None,
        }
    }

    fn model_has_source_grants(model: &CompiledStaticAbility) -> bool {
        match &model.payload {
            ironsmith_core::StaticAbilityPayload::GrantObjectAbilityForFilter(grant) => {
                grant.filter.source
            }
            ironsmith_core::StaticAbilityPayload::Conditional { ability, .. } => {
                Self::model_has_source_grants(ability)
            }
            _ => false,
        }
    }

    fn cached_enter_as_copy_spec(
        model: &CompiledStaticAbility,
    ) -> Option<super::EnterAsCopyAsEntersSpec> {
        match &model.payload {
            ironsmith_core::StaticAbilityPayload::EnterAsCopyAsEnters { spec, .. } => {
                Some(super::EnterAsCopyAsEntersSpec {
                    filter: spec.filter.clone(),
                    affected_filter: spec.affected_filter.clone(),
                    may: spec.may,
                    enters_tapped_if_chosen: spec.enters_tapped_if_chosen,
                    copy_duration: spec.copy_duration.clone(),
                    linked_exile_pair: spec.linked_exile_pair.map(|pair| {
                        super::EnterAsCopyLinkedExilePairSpec {
                            counter_type: pair.counter_type,
                        }
                    }),
                    copy_source_self: spec.copy_source_self,
                    copy_source_enchanted: spec.copy_source_enchanted,
                    name_override: spec.name_override.clone(),
                    added_colors: spec.added_colors,
                    added_card_types: spec.added_card_types.clone(),
                    removes_other_card_types: spec.removes_other_card_types,
                    added_supertypes: spec.added_supertypes.clone(),
                    removed_supertypes: spec.removed_supertypes.clone(),
                    added_subtypes: spec.added_subtypes.clone(),
                    added_abilities: spec
                        .added_abilities
                        .iter()
                        .map(Self::ability_from_model)
                        .collect(),
                    set_base_power_toughness: spec.set_base_power_toughness,
                    additional_counters: spec.additional_counters.clone(),
                    additional_x_counters: spec.additional_x_counters.clone(),
                    keep_other_source_abilities: spec.keep_other_source_abilities,
                    additional_counters_source_filter: spec
                        .additional_counters_source_filter
                        .clone(),
                    conditional_additional_counters: spec.conditional_additional_counters.clone(),
                    added_abilities_source_filter: spec.added_abilities_source_filter.clone(),
                    set_base_power_toughness_from_self: spec.set_base_power_toughness_from_self,
                    copy_followups: spec.copy_followups.clone(),
                })
            }
            ironsmith_core::StaticAbilityPayload::Conditional { ability, .. } => {
                Self::cached_enter_as_copy_spec(ability)
            }
            _ => None,
        }
    }

    fn cached_level_abilities(
        model: &CompiledStaticAbility,
    ) -> Option<Vec<crate::ability::LevelAbility>> {
        match &model.payload {
            ironsmith_core::StaticAbilityPayload::LevelAbility(level) => {
                Some(vec![crate::ability::LevelAbility {
                    min_level: level.min_level,
                    max_level: level.max_level,
                    power_toughness: level.power_toughness,
                    abilities: level
                        .abilities
                        .iter()
                        .cloned()
                        .map(StaticAbility::from_model)
                        .collect(),
                }])
            }
            ironsmith_core::StaticAbilityPayload::Conditional { ability, .. } => {
                Self::cached_level_abilities(ability)
            }
            _ => None,
        }
    }

    fn cached_equipment_grant_abilities(
        model: &CompiledStaticAbility,
    ) -> Option<Vec<StaticAbility>> {
        match &model.payload {
            ironsmith_core::StaticAbilityPayload::EquipmentGrant(abilities) => Some(
                abilities
                    .iter()
                    .cloned()
                    .map(StaticAbility::from_model)
                    .collect(),
            ),
            ironsmith_core::StaticAbilityPayload::Conditional { ability, .. } => {
                Self::cached_equipment_grant_abilities(ability)
            }
            _ => None,
        }
    }

    fn cached_grant_spec(model: &CompiledStaticAbility) -> Option<crate::grant::GrantSpec> {
        match &model.payload {
            ironsmith_core::StaticAbilityPayload::Grants(spec) => {
                Some(Self::grant_spec_from_model(spec))
            }
            ironsmith_core::StaticAbilityPayload::Conditional { ability, .. } => {
                Self::cached_grant_spec(ability)
            }
            _ => None,
        }
    }

    fn cached_cost_reduction(model: &CompiledStaticAbility) -> Option<super::CostReduction> {
        match &model.payload {
            ironsmith_core::StaticAbilityPayload::CostReduction(reduction) => {
                let mut parsed =
                    super::CostReduction::new(reduction.filter.clone(), reduction.amount.clone());
                if let Some(condition) = reduction.condition.clone() {
                    parsed = parsed.with_condition(condition);
                }
                if reduction.per_target {
                    parsed = parsed.with_per_target();
                }
                if let Some(intersection) = reduction.characteristic_intersection.clone() {
                    parsed = parsed.with_characteristic_intersection(intersection);
                }
                Some(parsed)
            }
            ironsmith_core::StaticAbilityPayload::Conditional { ability, condition, .. } => {
                Self::cached_cost_reduction(ability)
                    .map(|reduction| reduction.with_condition(condition.clone()))
            }
            _ => None,
        }
    }

    fn activation_cost_condition(
        condition: &ironsmith_core::ActivatedAbilityCostCondition,
    ) -> super::ActivatedAbilityCostCondition {
        use super::ActivatedAbilityCostCondition as Runtime;
        use ironsmith_core::ActivatedAbilityCostCondition as Model;
        match condition {
            Model::TargetsExactly { count, filter } => Runtime::TargetsExactly {
                count: *count,
                filter: filter.clone(),
            },
            Model::EquipAbility { targeting } => Runtime::EquipAbility {
                targeting: targeting.clone(),
            },
            Model::ThisAbility { ability_index } => Runtime::ThisAbility {
                ability_index: *ability_index,
            },
            Model::Keyword(keyword) => Runtime::Keyword(*keyword),
            Model::NonManaAbility => Runtime::NonManaAbility,
            Model::ManaAbility => Runtime::ManaAbility,
            Model::FirstActivationOfMatchingSourceThisTurn { filter } => {
                Runtime::FirstActivationOfMatchingSourceThisTurn { filter: filter.clone() }
            }
            Model::FirstTargetingActivationDuringYourTurn { filter } => {
                Runtime::FirstTargetingActivationDuringYourTurn { filter: filter.clone() }
            }
            Model::LoyaltyAbility => Runtime::LoyaltyAbility,
            Model::Activator(player) => Runtime::Activator(player.clone()),
            Model::FirstKeywordAbilityThisTurn {
                keyword,
                during_your_turn,
            } => Runtime::FirstKeywordAbilityThisTurn {
                keyword: *keyword,
                during_your_turn: *during_your_turn,
            },
            Model::All(conditions) => Runtime::All(
                conditions
                    .iter()
                    .map(Self::activation_cost_condition)
                    .collect(),
            ),
        }
    }

    fn cached_activated_ability_cost_reduction(
        model: &CompiledStaticAbility,
    ) -> Option<super::ActivatedAbilityCostReduction> {
        match &model.payload {
            ironsmith_core::StaticAbilityPayload::ActivatedAbilityCostReduction {
                optional,
                filter,
                reduction,
                replacement_mana_cost,
                display,
                condition,
                per_matching_objects,
                per_basic_land_types_among,
                multiplier,
                minimum_total_mana,
                reduction_mana,
            } => {
                // An unbound exact-symbol reduction ("This ability costs
                // {1}{U} less" with no ability to fold into) can still reduce
                // generic mana by its mana value; lowering normally folds it.
                let reduction = &reduction.saturating_add(
                    reduction_mana.as_ref().map_or(0, |cost| cost.mana_value()),
                );
                let mut converted = if let Some(replacement_mana_cost) = replacement_mana_cost {
                    super::ActivatedAbilityCostReduction::replacement_mana_cost(
                        filter.clone(),
                        replacement_mana_cost.clone(),
                        display.clone().unwrap_or_else(|| {
                            format!(
                                "You may pay {} rather than pay activated ability costs of {}",
                                replacement_mana_cost.to_oracle(),
                                filter.description()
                            )
                        }),
                    )
                } else {
                    let mut reduction_model =
                        super::ActivatedAbilityCostReduction::new(filter.clone(), *reduction);
                    if let Some(display) = display {
                        reduction_model = reduction_model.with_display(display.clone());
                    }
                    reduction_model
                };
                if let Some(minimum) = minimum_total_mana {
                    converted = converted.with_minimum_total_mana(*minimum);
                }
                converted.optional = *optional;
                converted.multiplier = multiplier.clone();
                if let Some(per_matching_objects) = per_matching_objects {
                    converted = converted.with_per_matching_objects(per_matching_objects.clone());
                }
                if let Some(per_basic_land_types_among) = per_basic_land_types_among {
                    converted = converted
                        .with_per_basic_land_types_among(per_basic_land_types_among.clone());
                }
                if let Some(condition) = condition {
                    converted =
                        converted.with_condition(Self::activation_cost_condition(condition));
                }
                Some(converted)
            }
            ironsmith_core::StaticAbilityPayload::Conditional { ability, condition, .. } => {
                Self::cached_activated_ability_cost_reduction(ability)
                    .map(|reduction| reduction.with_static_condition(condition.clone()))
            }
            _ => None,
        }
    }

    fn cached_activated_ability_cost_increase(
        model: &CompiledStaticAbility,
    ) -> Option<super::ActivatedAbilityCostIncrease> {
        match &model.payload {
            ironsmith_core::StaticAbilityPayload::ActivatedAbilityCostIncrease {
                filter,
                increase,
                activator,
                non_mana_only,
                condition,
                ability_condition,
                display,
            } => {
                let mut parsed = if let Some(activator) = activator.clone() {
                    super::ActivatedAbilityCostIncrease::for_activator(
                        activator,
                        increase.clone(),
                        *non_mana_only,
                    )
                } else {
                    let mut increase_model =
                        super::ActivatedAbilityCostIncrease::new(filter.clone(), increase.clone());
                    increase_model.non_mana_only = *non_mana_only;
                    increase_model
                };
                parsed.ability_condition = ability_condition
                    .as_ref()
                    .map(Self::activation_cost_condition);
                parsed.display = display.clone();
                if let Some(condition) = condition.clone() {
                    parsed = parsed.with_condition(condition);
                }
                Some(parsed)
            }
            ironsmith_core::StaticAbilityPayload::Conditional { ability, condition, .. } => {
                Self::cached_activated_ability_cost_increase(ability)
                    .map(|increase| increase.with_condition(condition.clone()))
            }
            _ => None,
        }
    }

    fn cached_activate_abilities_as_though_haste(
        model: &CompiledStaticAbility,
    ) -> Option<super::ActivateAbilitiesAsThoughHaste> {
        match &model.payload {
            ironsmith_core::StaticAbilityPayload::ActivateAbilitiesAsThoughHaste {
                filter,
                display,
            } => Some(super::ActivateAbilitiesAsThoughHaste::new(
                filter.clone(),
                display.clone(),
            )),
            _ => None,
        }
    }

    fn cached_cost_increase_life(model: &CompiledStaticAbility) -> Option<super::CostIncreaseLife> {
        match &model.payload {
            ironsmith_core::StaticAbilityPayload::CostIncreaseLife {
                filter,
                amount,
                display,
            } => Some(super::CostIncreaseLife::new(
                filter.clone(),
                *amount,
                display.clone(),
            )),
            _ => None,
        }
    }

    fn cached_cost_increase(model: &CompiledStaticAbility) -> Option<super::CostIncrease> {
        match &model.payload {
            ironsmith_core::StaticAbilityPayload::CostIncrease(increase) => {
                let mut parsed =
                    super::CostIncrease::new(increase.filter.clone(), increase.amount.clone());
                if let Some(condition) = increase.condition.clone() {
                    parsed = parsed.with_condition(condition);
                }
                if increase.per_target {
                    parsed = parsed.with_per_target();
                }
                Some(parsed)
            }
            ironsmith_core::StaticAbilityPayload::Conditional { ability, condition, .. } => {
                Self::cached_cost_increase(ability)
                    .map(|increase| increase.with_condition(condition.clone()))
            }
            _ => None,
        }
    }

    fn cached_cost_reduction_mana_cost(
        model: &CompiledStaticAbility,
    ) -> Option<super::CostReductionManaCost> {
        match &model.payload {
            ironsmith_core::StaticAbilityPayload::CostReductionManaCost(reduction) => {
                let mut runtime = super::CostReductionManaCost::new(
                    reduction.filter.clone(),
                    reduction.cost.clone(),
                );
                runtime.optional_life_additional_cost =
                    reduction.optional_life_additional_cost.clone();
                runtime.colored_only = reduction.colored_only;
                runtime.repetitions = reduction.repetitions.clone();
                if let Some(condition) = reduction.condition.clone() {
                    runtime = runtime.with_condition(condition);
                }
                if reduction.per_target {
                    runtime = runtime.with_per_target();
                }
                Some(runtime)
            }
            ironsmith_core::StaticAbilityPayload::Conditional { ability, condition, .. } => {
                Self::cached_cost_reduction_mana_cost(ability)
                    .map(|reduction| reduction.with_condition(condition.clone()))
            }
            _ => None,
        }
    }

    fn cached_cost_increase_mana_cost(
        model: &CompiledStaticAbility,
    ) -> Option<super::CostIncreaseManaCost> {
        match &model.payload {
            ironsmith_core::StaticAbilityPayload::CostIncreaseManaCost(increase) => {
                let mut runtime = super::CostIncreaseManaCost::new(
                    increase.filter.clone(),
                    increase.cost.clone(),
                );
                if let Some(condition) = increase.condition.clone() {
                    runtime = runtime.with_condition(condition);
                }
                if increase.per_target {
                    runtime = runtime.with_per_target();
                }
                Some(runtime)
            }
            ironsmith_core::StaticAbilityPayload::Conditional { ability, condition, .. } => {
                Self::cached_cost_increase_mana_cost(ability)
                    .map(|increase| increase.with_condition(condition.clone()))
            }
            _ => None,
        }
    }

    fn cached_cost_increase_mana_cost_per_additional_target(
        model: &CompiledStaticAbility,
    ) -> Option<super::CostIncreaseManaCostPerAdditionalTarget> {
        match &model.payload {
            ironsmith_core::StaticAbilityPayload::CostIncreaseManaCostPerTargetBeyondFirst(
                cost,
            ) => Some(super::CostIncreaseManaCostPerAdditionalTarget::new(
                cost.clone(),
            )),
            ironsmith_core::StaticAbilityPayload::Conditional { ability, .. } => {
                Self::cached_cost_increase_mana_cost_per_additional_target(ability)
            }
            _ => None,
        }
    }

    fn cached_this_spell_cost_reduction(
        model: &CompiledStaticAbility,
    ) -> Option<super::ThisSpellCostReduction> {
        match &model.payload {
            ironsmith_core::StaticAbilityPayload::ThisSpellCostReduction(reduction) => {
                Some(super::ThisSpellCostReduction::new(
                    reduction.amount.clone(),
                    reduction.condition.clone(),
                ))
                .map(|runtime| {
                    let runtime = if let Some(filter) = &reduction.affinity_filter {
                        runtime.with_affinity_filter(filter.clone())
                    } else {
                        runtime
                    };
                    if let Some(kind) = reduction.alternative_cast {
                        runtime.with_alternative_cast(kind)
                    } else {
                        runtime
                    }
                })
            }
            ironsmith_core::StaticAbilityPayload::Conditional { ability, .. } => {
                Self::cached_this_spell_cost_reduction(ability)
            }
            _ => None,
        }
    }

    fn cached_this_spell_cost_reduction_mana_cost(
        model: &CompiledStaticAbility,
    ) -> Option<super::ThisSpellCostReductionManaCost> {
        match &model.payload {
            ironsmith_core::StaticAbilityPayload::ThisSpellCostReductionManaCost(reduction) => {
                Some(
                    super::ThisSpellCostReductionManaCost::new(
                        reduction.cost.clone(),
                        reduction.condition.clone(),
                    )
                    .with_repetitions(reduction.repetitions.clone())
                    .with_colored_only(reduction.colored_only),
                )
            }
            ironsmith_core::StaticAbilityPayload::ThisSpellCastRestriction { .. } => None,
            ironsmith_core::StaticAbilityPayload::Conditional { ability, .. } => {
                Self::cached_this_spell_cost_reduction_mana_cost(ability)
            }
            _ => None,
        }
    }

    fn this_spell_cast_restriction_from_model(
        kind: &ironsmith_core::ThisSpellCastRestrictionKind,
    ) -> super::ThisSpellCastRestrictionKind {
        if let Some(condition) = &kind.condition {
            return super::ThisSpellCastRestrictionKind {
                timing: kind.timing,
                condition: Some(super::ThisSpellCastCondition::Condition(condition.clone())),
            };
        }
        if let Some(timing) = kind.timing {
            return super::ThisSpellCastRestrictionKind::timing(timing);
        }
        match kind.label.as_str() {
            "during declare attackers step" => {
                super::ThisSpellCastRestrictionKind::during_declare_attackers_step()
            }
            "during declare attackers step if you were attacked" => {
                super::ThisSpellCastRestrictionKind::during_declare_attackers_step_if_you_were_attacked_this_step()
            }
            "during combat" => super::ThisSpellCastRestrictionKind::during_combat(),
            "during combat before blockers" => {
                super::ThisSpellCastRestrictionKind::during_combat_before_blockers_are_declared()
            }
            "during combat after blockers" => {
                super::ThisSpellCastRestrictionKind::during_combat_after_blockers_are_declared()
            }
            "during combat on your turn before blockers" => {
                super::ThisSpellCastRestrictionKind::during_combat_on_your_turn_before_blockers_are_declared()
            }
            "during combat on opponents turn" => {
                super::ThisSpellCastRestrictionKind::during_combat_on_opponents_turn()
            }
            "before attackers are declared" => {
                super::ThisSpellCastRestrictionKind::before_attackers_are_declared()
            }
            "before combat damage step" => {
                super::ThisSpellCastRestrictionKind::before_combat_damage_step()
            }
            "during opponents upkeep" => {
                super::ThisSpellCastRestrictionKind::during_opponents_upkeep()
            }
            "during opponents turn after upkeep" => {
                super::ThisSpellCastRestrictionKind::during_opponents_turn_after_upkeep()
            }
            "during your end step" => super::ThisSpellCastRestrictionKind::during_your_end_step(),
            "if you cast another spell this turn" => {
                super::ThisSpellCastRestrictionKind::if_you_cast_another_spell_this_turn()
            }
            "if you cast another green spell this turn" => {
                super::ThisSpellCastRestrictionKind::if_you_cast_another_green_spell_this_turn()
            }
            "if opponent cast creature spell this turn" => {
                super::ThisSpellCastRestrictionKind::if_opponent_cast_creature_spell_this_turn()
            }
            "if creature is attacking you" => {
                super::ThisSpellCastRestrictionKind::if_creature_is_attacking_you()
            }
            "if creature died this turn" => {
                super::ThisSpellCastRestrictionKind::if_creature_died_this_turn()
            }
            "after combat" => super::ThisSpellCastRestrictionKind::after_combat(),
            "if you control snow land" => {
                super::ThisSpellCastRestrictionKind::if_you_control_snow_land()
            }
            "if you control fewer creatures than each opponent" => {
                super::ThisSpellCastRestrictionKind::if_you_control_fewer_creatures_than_each_opponent()
            }
            label => {
                if let Some(name) = label.strip_prefix("if no permanents named ") {
                    return super::ThisSpellCastRestrictionKind::if_no_permanents_named_on_battlefield(
                        name.to_string(),
                    );
                }
                if let Some(rest) = label.strip_prefix("if you control ")
                    && let Some((count, subtype_name)) = rest.split_once("+ ")
                    && let Ok(count) = count.parse::<u32>()
                    && let Some(subtype) = crate::types::Subtype::all_creature_types()
                        .iter()
                        .copied()
                        .find(|subtype| subtype.display_name() == subtype_name)
                {
                    return super::ThisSpellCastRestrictionKind::if_you_control_subtype_or_more(
                        subtype, count,
                    );
                }
                super::ThisSpellCastRestrictionKind::condition(
                    super::ThisSpellCastCondition::YouControlAtLeast {
                        filter: crate::target::ObjectFilter::default(),
                        count: u32::MAX,
                    },
                )
            }
        }
    }

    fn leaf_static_ability(&self) -> Option<&StaticAbility> {
        self.leaf_static_ability.as_ref()
    }

    fn cached_leaf_static_ability(model: &CompiledStaticAbility) -> Option<StaticAbility> {
        if matches!(&model.payload, ironsmith_core::StaticAbilityPayload::None)
            && let Ok(ability) =
                StaticAbility::from_compiler_model_parts(model.id, model.label.clone())
        {
            return Some(ability);
        }

        Some(match &model.payload {
            ironsmith_core::StaticAbilityPayload::PhaseBoundaryPlayerAction { .. }
            | ironsmith_core::StaticAbilityPayload::TriggerEventProjection { .. }
            | ironsmith_core::StaticAbilityPayload::GenericManaTapPaymentProhibition { .. }
            | ironsmith_core::StaticAbilityPayload::GenericManaTapPayment { .. }
            | ironsmith_core::StaticAbilityPayload::CustomKeywordIdentity { .. }
            | ironsmith_core::StaticAbilityPayload::CanBeBlockedAsThoughBlockersWereUntapped(_)
            | ironsmith_core::StaticAbilityPayload::AdditionalSpellTargets { .. } => return None,
            ironsmith_core::StaticAbilityPayload::Enchant(_)
            | ironsmith_core::StaticAbilityPayload::FlashIfTargetsMatching(_)
            | ironsmith_core::StaticAbilityPayload::FlashIfCastChoice(_)
            | ironsmith_core::StaticAbilityPayload::CastTargetRestriction { .. } => return None,
            ironsmith_core::StaticAbilityPayload::CommanderTaxLifeSubstitution { .. } => {
                return None;
            }
            ironsmith_core::StaticAbilityPayload::SelfSubjectSurface { .. } => {
                StaticAbility::from_compiler_model_parts(model.id, model.label.clone()).ok()?
            }
            ironsmith_core::StaticAbilityPayload::SourceLineKeywordGroup { keyword_count } => {
                StaticAbility::source_line_keyword_group(*keyword_count)
            }
            ironsmith_core::StaticAbilityPayload::DeckConstructionCopyLimit { maximum } => {
                StaticAbility::new(super::DeckConstructionRuleText::with_copy_limit(
                    model.label.clone(),
                    *maximum,
                ))
            }
            ironsmith_core::StaticAbilityPayload::DeckConstructionColorChoice { count } => {
                StaticAbility::new(super::DeckConstructionRuleText::with_color_choices(
                    model.label.clone(),
                    *count,
                ))
            }
            ironsmith_core::StaticAbilityPayload::ActivateAbilitiesAsThoughZone { .. }
            | ironsmith_core::StaticAbilityPayload::NamedActionPaymentAlternative { .. }
            | ironsmith_core::StaticAbilityPayload::NamedActionTokenAbilityGrant { .. }
            | ironsmith_core::StaticAbilityPayload::OptionalCostPaymentAlternative { .. } => return None,
            // A fragment manager retains its typed program; it is not a
            // presentation keyword marker with a different semantic identity.
            ironsmith_core::StaticAbilityPayload::OptionalTextFragments(_) => return None,
            ironsmith_core::StaticAbilityPayload::KeywordMarkerMechanic { mechanic } => {
                StaticAbility::new(super::KeywordMarker::typed(
                    model.label.clone(),
                    Some(mechanic.clone()),
                ))
            }
            ironsmith_core::StaticAbilityPayload::Toxic { amount } => StaticAbility::toxic(*amount),
            ironsmith_core::StaticAbilityPayload::DraftRule { rule } => {
                StaticAbility::new(super::DraftRuleText::typed(model.label.clone(), *rule))
            }
            ironsmith_core::StaticAbilityPayload::MustAttackDraftNotedPlayers { card_name } => {
                StaticAbility::must_attack_draft_noted_players(card_name.clone())
            }
            ironsmith_core::StaticAbilityPayload::CommanderPairing {
                partner_with,
                group,
                choose_background,
            } => {
                if let Some(name) = partner_with {
                    StaticAbility::partner_with(name)
                } else if *choose_background {
                    StaticAbility::new(super::PartnerVariant::typed(
                        super::CommanderPairing::ChooseBackground,
                        model.label.clone(),
                    ))
                } else if let Some(group) = group {
                    StaticAbility::new(super::PartnerVariant::typed(
                        super::CommanderPairing::Group(group.clone()),
                        model.label.clone(),
                    ))
                } else {
                    StaticAbility::partner()
                }
            }
            ironsmith_core::StaticAbilityPayload::OpponentDiscardThisToBattlefieldWithCounters {
                counter_type,
                count,
            } => StaticAbility::opponent_effect_discard_this_to_battlefield_with_counters_replacement(
                *counter_type,
                *count,
            ),
            ironsmith_core::StaticAbilityPayload::SourceLineStaticGroup { member_count } => {
                StaticAbility::source_line_static_group(*member_count)
            }
            ironsmith_core::StaticAbilityPayload::CountersRemainAcrossZoneChanges {
                excluded_destinations,
                display,
            } => StaticAbility::counters_remain_across_zone_changes(
                excluded_destinations.clone(),
                display.clone(),
            ),
            ironsmith_core::StaticAbilityPayload::LegendRuleDoesntApplyToController { filter } => {
                if model.id == Some(StaticAbilityId::LegendRuleDoesntApplyToControllerTokens) {
                    StaticAbility::legend_rule_doesnt_apply_to_tokens_you_control()
                } else if model.id == Some(StaticAbilityId::LegendRuleDoesntApplyToMatching) {
                    StaticAbility::legend_rule_doesnt_apply_to_matching(
                        filter.clone(),
                        model.label.clone(),
                    )
                } else {
                    StaticAbility::legend_rule_doesnt_apply_to_controller_matching(filter.clone())
                }
            }
            ironsmith_core::StaticAbilityPayload::GoadMatching { filter } => StaticAbility::new(super::combat::GoadMatching { filter: filter.clone() }),
            ironsmith_core::StaticAbilityPayload::ConditionalAttackRequirement { trigger, required } => {
                StaticAbility::new(super::combat::ConditionalAttackRequirement {
                    trigger: trigger.clone(),
                    required: required.clone(),
                })
            }
            ironsmith_core::StaticAbilityPayload::Anthem(anthem) => {
                let mut converted = match &anthem.filter {
                    Some(filter) => crate::static_abilities::Anthem::new(filter.clone(), 0, 0)
                        .with_values(anthem.power.clone(), anthem.toughness.clone()),
                    None => crate::static_abilities::Anthem::for_source(0, 0)
                        .with_values(anthem.power.clone(), anthem.toughness.clone()),
                }
                .with_count_uses_where_x(anthem.count_uses_where_x)
                .with_additional_surface(anthem.additional_surface)
                .with_set_quantifier_surface(anthem.set_quantifier_surface);
                if let Some(surface) = anthem.replacement_surface {
                    converted = converted
                        .with_replacement_surface(surface.power, surface.toughness);
                }
                if let Some(condition) = &anthem.condition {
                    converted = converted.with_condition(condition.clone());
                }
                StaticAbility::new(converted)
            }
            ironsmith_core::StaticAbilityPayload::AttachedAbilityGrant(grant) => {
                let mut converted = crate::static_abilities::AttachedAbilityGrant::new(
                    Self::ability_from_model(&grant.ability),
                    grant.display.clone(),
                )
                .with_additional_abilities(
                    grant
                        .additional_abilities
                        .iter()
                        .map(Self::ability_from_model)
                        .collect(),
                )
                .with_protection_attachment_exception(
                    grant.protection_does_not_remove_controlled_attachments,
                );
                if let Some(condition) = &grant.condition {
                    converted = converted.with_condition(condition.clone());
                }
                StaticAbility::new(converted)
            }
            ironsmith_core::StaticAbilityPayload::AttachedChosenLandwalkGrant(grant) => {
                StaticAbility::attached_chosen_landwalk_grant(grant.display.clone(), grant.snow)
            }
            ironsmith_core::StaticAbilityPayload::PlayersSkipUpkeep { player } => {
                StaticAbility::players_skip_upkeep_for(player.clone())
            }
            ironsmith_core::StaticAbilityPayload::PlayerSkipsDrawStep { player } => {
                StaticAbility::player_skips_draw_step(player.clone())
            }
            ironsmith_core::StaticAbilityPayload::PlayersSkipUntapStep { player } => {
                StaticAbility::players_skip_untap_steps(player.clone())
            }
            ironsmith_core::StaticAbilityPayload::PlayersSkipExtraTurns { player } => {
                StaticAbility::players_skip_extra_turns(player.clone())
            }
            ironsmith_core::StaticAbilityPayload::ConditionalSpellKeyword(spec) => {
                StaticAbility::conditional_spell_keyword(*spec)
            }
            ironsmith_core::StaticAbilityPayload::Splice(spec) => {
                StaticAbility::splice(spec.clone())
            }
            ironsmith_core::StaticAbilityPayload::Escalate(spec) => {
                StaticAbility::escalate(spec.clone())
            }
            ironsmith_core::StaticAbilityPayload::BandsWithOther(filter) => {
                StaticAbility::bands_with_other(filter.clone(), model.label.clone())
            }
            ironsmith_core::StaticAbilityPayload::Dredge(amount) => {
                StaticAbility::dredge(*amount)
            }
            ironsmith_core::StaticAbilityPayload::CounterLimit {
                counter_type,
                maximum,
                display,
            } => StaticAbility::counter_limit_rule(*counter_type, *maximum, display.clone()),
            ironsmith_core::StaticAbilityPayload::Conditional { ability, condition, .. } => {
                // The retained model keeps each authored label. Native leaf
                // setters receive the complete executable conjunction once,
                // so an outer designation cannot replace an inner predicate.
                let mut leaf = ability.as_ref();
                let mut combined = condition.clone();
                while let ironsmith_core::StaticAbilityPayload::Conditional {
                    ability: inner, condition: inner_condition, ..
                } = &leaf.payload {
                    combined = inner_condition.clone().and(combined);
                    leaf = inner.as_ref();
                }
                let converted = StaticAbility::from_model(leaf.clone());
                // Combat-damage assignment changes a game rule, so its
                // condition reads the receiver's completed characteristics
                // when damage is assigned. A layer-6 self-grant would test
                // intermediate P/T and publish an unconditional duplicate.
                if matches!(converted.id(),
                    StaticAbilityId::ThisCreatureAssignsCombatDamageUsingToughness
                        | StaticAbilityId::CreaturesAssignCombatDamageUsingToughness
                        | StaticAbilityId::CreaturesYouControlAssignCombatDamageUsingToughness
                        | StaticAbilityId::KeywordMarker
                ) {
                    return Some(converted);
                }
                // A rule-modifying leaf ("This ability costs {2} less to
                // activate if you have one or fewer cards in hand") carries
                // the condition natively when it supports one.
                // A rule-modifying leaf without a native condition ("As long
                // as Mirri is tapped, no more than one creature can attack you
                // each combat") must still function only while its condition
                // holds (CR 604.2): it falls through to the conditional source
                // grant below rather than becoming unconditional.
                converted.with_condition(combined.clone()).unwrap_or_else(|| {
                    StaticAbility::new(
                        crate::static_abilities::GrantAbility::source(converted)
                            .with_condition(combined),
                    )
                })
            }
            ironsmith_core::StaticAbilityPayload::GrantObjectAbilityForFilter(grant) => {
                let mut converted = crate::static_abilities::GrantObjectAbilityForFilter::new(
                    grant.filter.clone(),
                    Self::ability_from_model(&grant.ability),
                    grant.display.clone(),
                )
                .with_additional_abilities(
                    grant
                        .additional_abilities
                        .iter()
                        .map(Self::ability_from_model)
                        .collect(),
                )
                .with_set_quantifier_surface(grant.set_quantifier_surface);
                converted.derived_ability_display = grant.derived_ability_display;
                if let Some(condition) = &grant.condition {
                    converted = converted.with_condition(condition.clone());
                }
                StaticAbility::new(converted)
            }
            ironsmith_core::StaticAbilityPayload::CopyActivatedAbilities(copy) => {
                let mut converted =
                    crate::static_abilities::CopyActivatedAbilities::new(copy.filter.clone())
                        .with_exclude_source_name(copy.exclude_source_name)
                        .with_exclude_source_id(copy.exclude_source_id)
                        .with_display(copy.display.clone());
                if let Some(counter) = copy.counter {
                    converted = converted.with_counter(counter);
                }
                if copy.only_loyalty {
                    converted = converted.with_only_loyalty();
                }
                if copy.force_once_each_turn {
                    converted = converted.with_once_each_turn();
                }
                // CR 605.1a: mana abilities are excluded from the copy.
                converted.include_mana = !copy.exclude_mana_abilities;
                converted.exclude_loyalty = copy.exclude_loyalty_abilities;
                converted.excluded_ability_designations = copy.excluded_ability_designations.clone();
                StaticAbility::copy_activated_abilities(converted)
            }
            ironsmith_core::StaticAbilityPayload::CopyStaticAbilityVariants(copy) => {
                let mut converted = crate::static_abilities::CopyStaticAbilityVariants::new(
                    copy.filter.clone(),
                    copy.selectors.clone(),
                    copy.display.clone(),
                )
                .with_exclude_source_id(copy.exclude_source_id);
                converted.excluded_ability_designations = copy.excluded_ability_designations.clone();
                converted.copy_all = copy.copy_all;
                StaticAbility::copy_static_ability_variants(converted)
            }
            ironsmith_core::StaticAbilityPayload::CopyTriggeredAbilities(copy) => {
                let mut converted =
                    crate::static_abilities::CopyTriggeredAbilities::new(copy.filter.clone())
                        .with_exclude_source_name(copy.exclude_source_name)
                        .with_display(copy.display.clone());
                converted.excluded_ability_designations = copy.excluded_ability_designations.clone();
                StaticAbility::copy_triggered_abilities(converted)
            }
            ironsmith_core::StaticAbilityPayload::LevelAbility(level) => {
                StaticAbility::with_level_abilities(vec![crate::ability::LevelAbility {
                    min_level: level.min_level,
                    max_level: level.max_level,
                    power_toughness: level.power_toughness,
                    abilities: level
                        .abilities
                        .iter()
                        .cloned()
                        .map(StaticAbility::from_model)
                        .collect(),
                }])
            }
            ironsmith_core::StaticAbilityPayload::Protection(from) => {
                StaticAbility::new(super::protection::Protection { from: from.clone(), descriptive: model.id.is_none().then(|| model.label.clone()) })
            }
            ironsmith_core::StaticAbilityPayload::PreventAllCombatDamageToPermanentsMatching(
                filter,
            ) => StaticAbility::prevent_all_combat_damage_to_permanents_matching(filter.clone()),
            ironsmith_core::StaticAbilityPayload::PreventAllCombatDamageToAndByPermanentsMatching(
                filter,
            ) => StaticAbility::prevent_all_combat_damage_to_and_by_permanents_matching(
                filter.clone(),
            ),
            ironsmith_core::StaticAbilityPayload::PreventAllDamageToPermanentsMatching(filter) => {
                StaticAbility::prevent_all_damage_to_permanents_matching(filter.clone())
            }
            ironsmith_core::StaticAbilityPayload::PreventAllNoncombatDamageToPermanentsMatching(
                filter,
            ) => StaticAbility::prevent_all_noncombat_damage_to_permanents_matching(filter.clone()),
            ironsmith_core::StaticAbilityPayload::PreventAllDamageToSelfFromSourcesMatching(spec) => {
                StaticAbility::prevent_all_damage_to_self_from_sources_matching(spec.clone())
            }
            ironsmith_core::StaticAbilityPayload::HexproofFrom(filter) => {
                StaticAbility::hexproof_from(filter.clone())
            }
            ironsmith_core::StaticAbilityPayload::RuleRestriction {
                restriction,
                additional_restrictions,
                display,
            } => StaticAbility::restrictions(
                std::iter::once(restriction.clone())
                    .chain(additional_restrictions.iter().cloned())
                    .collect(),
                display.clone(),
            ),
            ironsmith_core::StaticAbilityPayload::PregameAction {
                kind,
                text,
                effects,
            } => {
                StaticAbility::pregame_action_with_effects(
                    kind.clone(),
                    text.clone(),
                    effects.clone(),
                )
            }
            ironsmith_core::StaticAbilityPayload::Ward(cost) => StaticAbility::ward(cost.clone()),
            ironsmith_core::StaticAbilityPayload::Morph(cost)
            | ironsmith_core::StaticAbilityPayload::Disguise(cost)
            | ironsmith_core::StaticAbilityPayload::Megamorph(cost) if model.id.is_none() => {
                StaticAbility::new(super::misc::DefinedFaceDown {
                    cost: cost.clone(),
                    ward: matches!(&model.payload, ironsmith_core::StaticAbilityPayload::Disguise(_)),
                    counter: matches!(&model.payload, ironsmith_core::StaticAbilityPayload::Megamorph(_)),
                    text: model.label.clone(),
                })
            }
            ironsmith_core::StaticAbilityPayload::Morph(cost) => StaticAbility::morph(cost.clone()),
            ironsmith_core::StaticAbilityPayload::Disguise(cost) => {
                StaticAbility::disguise(cost.clone())
            }
            ironsmith_core::StaticAbilityPayload::Megamorph(cost) => {
                StaticAbility::megamorph(cost.clone())
            }
            ironsmith_core::StaticAbilityPayload::CanBlockAdditionalCreatureEachCombat(count) => {
                StaticAbility::can_block_additional_creature_each_combat(*count)
            }
            ironsmith_core::StaticAbilityPayload::CanBlockAdditionalForEach { additional, filter } => {
                StaticAbility::can_block_additional_for_each(*additional, filter.clone())
            }
            ironsmith_core::StaticAbilityPayload::CanBlockAsThoughReachForSubtype(subtype) => {
                StaticAbility::can_block_subtype_as_though_reach(*subtype)
            }
            ironsmith_core::StaticAbilityPayload::CanBlockAsThoughNoShadow => {
                StaticAbility::can_block_as_though_no_shadow()
            }
            ironsmith_core::StaticAbilityPayload::CanBlockAsThoughUntapped => {
                StaticAbility::can_block_as_though_untapped()
            }
            ironsmith_core::StaticAbilityPayload::CanBlockAsThoughNoLandwalk => {
                StaticAbility::can_block_as_though_no_landwalk()
            }
            ironsmith_core::StaticAbilityPayload::CanAttackPlayersWhoAttackedControllerLastTurnAsThoughNoDefender => {
                StaticAbility::can_attack_players_who_attacked_controller_last_turn_as_though_no_defender()
            }
            ironsmith_core::StaticAbilityPayload::BlockingAsThoughNoLandwalk(spec) => {
                StaticAbility::blocking_as_though_no_landwalk(spec.clone())
            }
            ironsmith_core::StaticAbilityPayload::TargetingAsThoughNoAbility(spec) => {
                StaticAbility::targeting_as_though_no_ability(spec.clone())
            }
            ironsmith_core::StaticAbilityPayload::CantBeBlockedByMoreThan(count) => {
                StaticAbility::cant_be_blocked_by_more_than(*count)
            }
            ironsmith_core::StaticAbilityPayload::CantBeBlockedExceptByNOrMore(count) => {
                StaticAbility::cant_be_blocked_except_by_n_or_more(*count)
            }
            ironsmith_core::StaticAbilityPayload::CantBeBlockedByPowerOrLess(power) => {
                StaticAbility::cant_be_blocked_by_power_or_less(*power)
            }
            ironsmith_core::StaticAbilityPayload::CantBeBlockedByPowerOrGreater(power) => {
                StaticAbility::cant_be_blocked_by_power_or_greater(*power)
            }
            ironsmith_core::StaticAbilityPayload::CantBeBlockedAsLongAsDefendingPlayerControlsCardTypes(card_types) => {
                if card_types.len() == 1 {
                    StaticAbility::cant_be_blocked_as_long_as_defending_player_controls_card_type(
                        card_types[0],
                    )
                } else {
                    StaticAbility::cant_be_blocked_as_long_as_defending_player_controls_card_types(
                        card_types.clone(),
                    )
                }
            }
            ironsmith_core::StaticAbilityPayload::CantAttackUnlessCondition {
                condition,
                display,
            } => StaticAbility::cant_attack_unless_condition(
                Self::cant_attack_unless_condition_from_model(condition),
                display.clone(),
            ),
            ironsmith_core::StaticAbilityPayload::AttackCost {
                attackers,
                covers_planeswalkers,
                cost,
                display,
                planeswalkers_only,
            } => StaticAbility::new(
                super::AttackCost::new(
                    attackers.clone(),
                    *covers_planeswalkers,
                    cost.clone(),
                    display.clone(),
                )
                .with_planeswalkers_only(*planeswalkers_only),
            ),
            ironsmith_core::StaticAbilityPayload::BlockCost {
                blockers,
                blocker_is_attached_to_source,
                attackers,
                cost,
                display,
                also_attack_cost,
                attack_only,
            } => {
                let block_cost = if *blocker_is_attached_to_source {
                    super::BlockCost::attached(
                        blockers.clone(),
                        attackers.clone(),
                        cost.clone(),
                        display.clone(),
                    )
                } else {
                    super::BlockCost::new(
                        blockers.clone(),
                        attackers.clone(),
                        cost.clone(),
                        display.clone(),
                    )
                };
                StaticAbility::new(
                    block_cost
                        .also_attacking(*also_attack_cost)
                        .attack_only(*attack_only),
                )
            }
            ironsmith_core::StaticAbilityPayload::MayChooseNotToUntapDuringUntapStep(subject) => {
                StaticAbility::may_choose_not_to_untap_during_untap_step(subject.clone())
            }
            ironsmith_core::StaticAbilityPayload::UntapStepLimit {
                player,
                filter,
                max,
                display,
            } => StaticAbility::untap_step_limit(
                player.clone(),
                filter.clone(),
                *max,
                display.clone(),
            ),
            ironsmith_core::StaticAbilityPayload::UntapStepChosenCardTypeOnly {
                player,
                card_types,
                display,
            } => StaticAbility::untap_step_chosen_card_type_only(
                player.clone(),
                card_types.clone(),
                display.clone(),
            ),
            ironsmith_core::StaticAbilityPayload::PreventAllDamageToYou => {
                StaticAbility::prevent_all_damage_to_you()
            }
            ironsmith_core::StaticAbilityPayload::PlayerProtectionFrom {
                player,
                source_filter,
                display,
            } => StaticAbility::player_protection_from(
                player.clone(),
                source_filter.clone(),
                display.clone(),
            ),
            ironsmith_core::StaticAbilityPayload::OpponentsMustTargetFlagbearers => {
                StaticAbility::opponents_must_target_flagbearers()
            }
            ironsmith_core::StaticAbilityPayload::SearchLimitedToTopCards {
                searcher,
                count,
                display,
            } => StaticAbility::search_limited_to_top_cards(
                searcher.clone(),
                *count,
                display.clone(),
            ),
            ironsmith_core::StaticAbilityPayload::UntapDuringEachOtherPlayersUntapStep {
                filter,
                display,
                opponents_only: false,
            } => StaticAbility::untap_during_each_other_players_untap_step(
                filter.clone(),
                display.clone(),
            ),
            ironsmith_core::StaticAbilityPayload::UntapDuringEachOtherPlayersUntapStep {
                filter,
                display,
                opponents_only: true,
            } => StaticAbility::untap_during_each_opponents_untap_step(
                filter.clone(),
                display.clone(),
            ),
            ironsmith_core::StaticAbilityPayload::EchoCostAlternative { display, .. } => {
                StaticAbility::new(super::misc::EchoCostAlternative::new(display.clone()))
            }
            ironsmith_core::StaticAbilityPayload::FirstEquipCostAlternative(display) => {
                StaticAbility::first_equip_cost_alternative(display.clone())
            }
            ironsmith_core::StaticAbilityPayload::ControlAttachedPermanent(display) => {
                StaticAbility::control_attached_permanent(display.clone())
            }
            ironsmith_core::StaticAbilityPayload::SetColors { filter, colors, exclude_from_color_identity } => {
                let mut ability = super::continuous::SetColorsForFilter::new(filter.clone(), *colors);
                ability.exclude_from_color_identity = *exclude_from_color_identity;
                StaticAbility::new(ability)
            }
            ironsmith_core::StaticAbilityPayload::AddColors { filter, colors } => {
                StaticAbility::add_colors(filter.clone(), *colors)
            }
            ironsmith_core::StaticAbilityPayload::SetName { filter, name } => {
                StaticAbility::set_name(filter.clone(), name.clone())
            }
            ironsmith_core::StaticAbilityPayload::CountAsCardNamedForSpellEffect {
                spell_name,
                counted_name,
            } => StaticAbility::count_as_card_named_for_spell_effect(
                spell_name.clone(),
                counted_name.clone(),
            ),
            ironsmith_core::StaticAbilityPayload::AddSupertypes { filter, supertypes } => {
                StaticAbility::add_supertypes(filter.clone(), supertypes.clone())
            }
            ironsmith_core::StaticAbilityPayload::RemoveSupertypes { filter, supertypes } => {
                StaticAbility::remove_supertypes(filter.clone(), supertypes.clone())
            }
            ironsmith_core::StaticAbilityPayload::MaxCreaturesCanAttackEachCombat(maximum) => {
                StaticAbility::max_attackers_each_combat(*maximum)
            }
            ironsmith_core::StaticAbilityPayload::MaxCreaturesCanAttackYouEachCombat(maximum) => {
                StaticAbility::max_attackers_can_attack_you_each_combat(*maximum)
            }
            ironsmith_core::StaticAbilityPayload::MaxCreaturesCanAttackSourceEachCombat(maximum) => {
                StaticAbility::max_attackers_can_attack_source_each_combat(*maximum)
            }
            ironsmith_core::StaticAbilityPayload::MaxCreaturesCanBlockEachCombat(maximum) => {
                StaticAbility::max_blockers_each_combat(*maximum)
            }
            ironsmith_core::StaticAbilityPayload::ChooseBasicLandTypeAsEnters(display) => {
                StaticAbility::choose_basic_land_type_as_enters(display.clone())
            }
            ironsmith_core::StaticAbilityPayload::ChooseLandTypeAsEnters(display) => {
                StaticAbility::choose_land_type_as_enters(display.clone())
            }
            ironsmith_core::StaticAbilityPayload::EnchantedLandIsChosenType(display) => {
                StaticAbility::enchanted_land_is_chosen_type(display.clone())
            }
            ironsmith_core::StaticAbilityPayload::AttachedIsCopyOfChosenObject(display) => {
                StaticAbility::attached_is_copy_of_chosen_object(display.clone())
            }
            ironsmith_core::StaticAbilityPayload::AttachedIsCopyOfSource { retain_original_types } => {
                StaticAbility::new(super::AttachedIsCopyOfSource::new(*retain_original_types))
            }
            ironsmith_core::StaticAbilityPayload::SourceLandIsChosenType(display) => {
                StaticAbility::source_land_is_chosen_type(display.clone())
            }
            ironsmith_core::StaticAbilityPayload::ChooseBasicLandTypesAsEnters {
                display,
                ..
            } => StaticAbility::choose_basic_land_type_as_enters(display.clone()),
            ironsmith_core::StaticAbilityPayload::FirstChosenLandTypeBecomesSecond {
                filter,
                display,
            } => StaticAbility::first_chosen_land_type_becomes_second(
                filter.clone(),
                display.clone(),
            ),
            ironsmith_core::StaticAbilityPayload::AddChosenCreatureType {
                filter,
                display,
                replace_existing,
            } => {
                if *replace_existing {
                    StaticAbility::set_chosen_creature_type(filter.clone(), display.clone())
                } else {
                    StaticAbility::add_chosen_creature_type(filter.clone(), display.clone())
                }
            }
            ironsmith_core::StaticAbilityPayload::SourceHasAbilityStickerAbilitiesOf {
                filter,
                display,
            } => StaticAbility::source_has_ability_sticker_abilities_of(
                filter.clone(),
                display.clone(),
            ),
            ironsmith_core::StaticAbilityPayload::AddChosenBasicLandType { filter, display } => {
                StaticAbility::add_chosen_basic_land_type(filter.clone(), display.clone())
            }
            ironsmith_core::StaticAbilityPayload::AddChosenColor { filter, display } => {
                StaticAbility::add_chosen_color(filter.clone(), display.clone())
            }
            ironsmith_core::StaticAbilityPayload::SetChosenColor { filter, display } => {
                StaticAbility::set_chosen_color(filter.clone(), display.clone())
            }
            ironsmith_core::StaticAbilityPayload::NoMaximumHandSizeFor(player) => StaticAbility::no_maximum_hand_size_for(player.clone()),
            ironsmith_core::StaticAbilityPayload::MaximumHandSizeFromSourceCounters { player, counter_type } =>
                StaticAbility::maximum_hand_size_from_source_counters(player.clone(), *counter_type),
            ironsmith_core::StaticAbilityPayload::SetMaximumHandSize { player, amount } => {
                StaticAbility::set_maximum_hand_size(player.clone(), *amount)
            }
            ironsmith_core::StaticAbilityPayload::ReduceMaximumHandSize { player, by } => {
                StaticAbility::reduce_maximum_hand_size(player.clone(), *by)
            }
            ironsmith_core::StaticAbilityPayload::IncreaseMaximumHandSize { player, by } => {
                StaticAbility::increase_maximum_hand_size(player.clone(), *by)
            }
            ironsmith_core::StaticAbilityPayload::MaximumHandSizeSevenMinusYourGraveyardCardTypes {
                player,
                min_card_types,
            } => StaticAbility::max_hand_size_seven_minus_your_graveyard_card_types(
                player.clone(),
                *min_card_types,
            ),
            ironsmith_core::StaticAbilityPayload::DuplicateMatchingTriggeredAbilities {
                source_filter,
                event_matcher,
                count,
                display,
            } => StaticAbility::duplicate_matching_triggered_abilities(
                source_filter.clone(),
                event_matcher.clone(),
                *count as usize,
                display.clone(),
            ),
            ironsmith_core::StaticAbilityPayload::SuppressMatchingTriggeredAbilities {
                source_filter,
                event_matcher,
                display,
            } => StaticAbility::suppress_matching_triggered_abilities(
                source_filter.clone(),
                event_matcher.clone(),
                display.clone(),
            ),
            ironsmith_core::StaticAbilityPayload::ExertAttack {
                only_if_not_exerted_this_turn,
                linked_trigger,
                display,
            } => StaticAbility::exert_attack(
                *only_if_not_exerted_this_turn,
                linked_trigger.clone(),
                display.clone(),
            ),
            ironsmith_core::StaticAbilityPayload::EnlistAttack {
                linked_trigger,
                display,
            } => {
                let mut ability = super::combat::EnlistAttack::new(linked_trigger.clone(), display.clone());
                ability.descriptive = model.id.is_none();
                StaticAbility::new(ability)
            },
            ironsmith_core::StaticAbilityPayload::EquipmentGrant(abilities) => {
                StaticAbility::equipment_grant(
                    abilities
                        .iter()
                        .cloned()
                        .map(StaticAbility::from_model)
                        .collect(),
                )
            }
            ironsmith_core::StaticAbilityPayload::SoulbondSharedPowerToughness {
                power,
                toughness,
            } => StaticAbility::soulbond_shared_power_toughness(*power, *toughness),
            ironsmith_core::StaticAbilityPayload::SoulbondSharedAbility(ability) => {
                StaticAbility::soulbond_shared_ability(StaticAbility::from_model(
                    (**ability).clone(),
                ))
            }
            ironsmith_core::StaticAbilityPayload::SoulbondSharedObjectAbility(ability) => {
                StaticAbility::soulbond_shared_object_ability(Self::ability_from_model(ability))
            }
            ironsmith_core::StaticAbilityPayload::RemoveAbilityForFilter {
                filter,
                ability,
                mode,
            } => {
                StaticAbility::remove_ability_with_mode(
                    filter.clone(),
                    StaticAbility::from_model((**ability).clone()),
                    *mode,
                )
            }
            ironsmith_core::StaticAbilityPayload::RemoveObjectAbilitiesForFilter {
                filter,
                abilities,
                display,
                mode,
            } => StaticAbility::remove_object_abilities_with_mode(
                filter.clone(),
                abilities.iter().map(Self::ability_from_model).collect(),
                display.clone(),
                *mode,
            ),
            ironsmith_core::StaticAbilityPayload::RemoveAllAbilities(filter) => {
                StaticAbility::remove_all_abilities(filter.clone())
            }
            ironsmith_core::StaticAbilityPayload::RemoveAllAbilitiesExceptMana(filter) => {
                StaticAbility::remove_all_abilities_except_mana(filter.clone())
            }
            ironsmith_core::StaticAbilityPayload::SetBasePowerToughness {
                filter,
                power,
                toughness,
            } => StaticAbility::set_base_power_toughness(filter.clone(), *power, *toughness),
            ironsmith_core::StaticAbilityPayload::SetBasePowerToughnessValue {
                filter,
                power,
                toughness,
            } => StaticAbility::set_base_power_toughness_value(
                filter.clone(),
                power.clone(),
                toughness.clone(),
            ),
            ironsmith_core::StaticAbilityPayload::SetBasePower { filter, power } => {
                StaticAbility::set_base_power(filter.clone(), *power)
            }
            ironsmith_core::StaticAbilityPayload::SetBaseToughness { filter, toughness } => {
                StaticAbility::set_base_toughness(filter.clone(), *toughness)
            }
            ironsmith_core::StaticAbilityPayload::SourceCharacteristicsOfLastExiledCreatureCard {
                filter,
                retained_subtypes,
            } => StaticAbility::source_characteristics_of_last_exiled_creature_card(
                filter.clone(),
                retained_subtypes.clone(),
            ),
            ironsmith_core::StaticAbilityPayload::SourceHasFullTextOfTopGraveyardCard {
                filter,
                abilities,
                ability_labels,
                display,
            } => StaticAbility::source_has_full_text_of_top_graveyard_card(
                filter.clone(),
                abilities.iter().map(Self::ability_from_model).collect(),
                ability_labels.clone(),
                display.clone(),
            ),
            ironsmith_core::StaticAbilityPayload::AddCardTypes { filter, card_types } => {
                StaticAbility::add_card_types(filter.clone(), card_types.clone())
            }
            ironsmith_core::StaticAbilityPayload::RemoveCardTypes {
                filter,
                card_types,
                condition,
            } => {
                let ability = StaticAbility::remove_card_types(filter.clone(), card_types.clone());
                if let Some(condition) = condition {
                    ability.with_condition(condition.clone()).unwrap_or(ability)
                } else {
                    ability
                }
            }
            ironsmith_core::StaticAbilityPayload::SetCardTypes { filter, card_types } => {
                StaticAbility::set_card_types(filter.clone(), card_types.clone())
            }
            ironsmith_core::StaticAbilityPayload::AddSubtypes { filter, subtypes } => {
                StaticAbility::add_subtypes(filter.clone(), subtypes.clone())
            }
            ironsmith_core::StaticAbilityPayload::AddAllSubtypesOfFamily { filter, family } => {
                StaticAbility::add_all_subtypes_of_family(filter.clone(), *family)
            }
            ironsmith_core::StaticAbilityPayload::SetLandSubtypes { filter, subtypes } => {
                StaticAbility::set_land_subtypes(filter.clone(), subtypes.clone())
            }
            ironsmith_core::StaticAbilityPayload::SetCreatureSubtypes { filter, subtypes } => {
                StaticAbility::set_creature_subtypes(filter.clone(), subtypes.clone())
            }
            ironsmith_core::StaticAbilityPayload::MakeColorless(filter) => {
                StaticAbility::make_colorless(filter.clone())
            }
            ironsmith_core::StaticAbilityPayload::CostIncreasePerTargetBeyondFirst(amount) => {
                StaticAbility::cost_increase_per_target_beyond_first(*amount)
            }
            ironsmith_core::StaticAbilityPayload::ThisSpellCastRestriction { kind, display } => {
                StaticAbility::this_spell_cast_restriction(
                    Self::this_spell_cast_restriction_from_model(kind),
                    display.clone(),
                )
            }
            ironsmith_core::StaticAbilityPayload::ThisSpellXMaximum { maximum, display, .. } => {
                StaticAbility::this_spell_x_maximum(maximum.clone(), display.clone())
            }
            ironsmith_core::StaticAbilityPayload::ThisSpellXMinimum { minimum, display } => {
                StaticAbility::this_spell_x_minimum(minimum.clone(), display.clone())
            }
            ironsmith_core::StaticAbilityPayload::DieRollResultAdjustment(spec) => {
                if spec.reroll {
                    StaticAbility::die_roll_reroll(
                        spec.player.clone(),
                        spec.mana_cost.clone().unwrap_or_default(),
                        spec.once_each_turn,
                        spec.display.clone(),
                    )
                } else if spec.exchange_with_source_base_pt {
                    StaticAbility::die_roll_result_exchange_with_source_base_pt(
                        spec.player.clone(),
                        spec.sides,
                        spec.display.clone(),
                    )
                } else if let Some(counter_type) = spec.source_counter_cost {
                    StaticAbility::die_roll_result_adjustment_removing_source_counter(
                        spec.player.clone(),
                        counter_type,
                        spec.amount,
                        spec.once_each_turn,
                        spec.display.clone(),
                    )
                } else {
                    StaticAbility::die_roll_result_adjustment(
                        spec.player.clone(),
                        spec.life_cost,
                        spec.amount,
                        spec.once_each_turn,
                        spec.display.clone(),
                    )
                }
            }
            ironsmith_core::StaticAbilityPayload::MinimumSpellTotalMana(amount) => {
                StaticAbility::minimum_spell_total_mana(*amount)
            }
            ironsmith_core::StaticAbilityPayload::BuybackCostReduction(amount) => {
                StaticAbility::buyback_cost_reduction(*amount)
            }
            ironsmith_core::StaticAbilityPayload::ChooseColorAsEnters {
                excluded,
                display,
                count,
            } => {
                if *count > 1 {
                    StaticAbility::choose_colors_as_enters(*count, display.clone())
                } else {
                    StaticAbility::choose_color_as_enters(*excluded, display.clone())
                }
            }
            ironsmith_core::StaticAbilityPayload::ChoosePlayerAsEnters {
                filter,
                display,
                count,
            } => {
                if *count > 1 {
                    StaticAbility::choose_players_as_enters(filter.clone(), *count, display.clone())
                } else {
                    StaticAbility::choose_player_as_enters_matching(filter.clone(), display.clone())
                }
            }
            ironsmith_core::StaticAbilityPayload::NoteLifeTotalAsEnters(display) => {
                StaticAbility::note_life_total_as_enters(display.clone())
            }
            ironsmith_core::StaticAbilityPayload::DiscardHandAsEnters(display) => {
                StaticAbility::discard_hand_as_enters(display.clone())
            }
            ironsmith_core::StaticAbilityPayload::RevealFromHandAsEnters {
                filter,
                count,
                optional,
                display,
            } => StaticAbility::reveal_from_hand_as_enters(
                filter.clone(),
                *count,
                *optional,
                display.clone(),
            ),
            ironsmith_core::StaticAbilityPayload::ChooseCardNameAsEnters {
                display,
                reveal_opponents_hands,
                require_nonland_from_revealed_opponents,
                opponent_also_chooses,
                exclude_basic_land_names,
            } => StaticAbility::choose_card_name_as_enters_with_spec(
                display.clone(),
                super::ChooseCardNameAsEntersSpec {
                    reveal_opponents_hands: *reveal_opponents_hands,
                    require_nonland_from_revealed_opponents: *require_nonland_from_revealed_opponents,
                    opponent_also_chooses: *opponent_also_chooses,
                    exclude_basic_land_names: *exclude_basic_land_names,
                },
            ),
            ironsmith_core::StaticAbilityPayload::ChooseCreatureTypeAsEnters(display) => {
                StaticAbility::choose_creature_type_as_enters(display.clone())
            }
            ironsmith_core::StaticAbilityPayload::ChooseNamedOptionAsEnters {
                options,
                display,
                at_random,
                each_player,
            } => {
                if *each_player {
                    StaticAbility::each_player_chooses_named_option_as_enters(
                        options.clone(),
                        display.clone(),
                    )
                } else if *at_random {
                    StaticAbility::choose_named_option_at_random_as_enters(
                        options.clone(),
                        display.clone(),
                    )
                } else {
                    StaticAbility::choose_named_option_as_enters(options.clone(), display.clone())
                }
            }
            ironsmith_core::StaticAbilityPayload::ChoosePowerToughnessAsEntersOrTurnsFaceUp {
                options,
                display,
                at_random: false,
            } => StaticAbility::choose_power_toughness_options_as_enters_or_turns_face_up(
                options
                    .iter()
                    .map(|option| {
                        super::PowerToughnessChoiceOption {
                            power: option.power,
                            toughness: option.toughness,
                            card_types: option.card_types.clone(),
                            added_subtypes: option.added_subtypes.clone(),
                            abilities: option.abilities.iter().cloned().map(StaticAbility::from_model).collect(),
                        }
                    })
                    .collect(),
                display.clone(),
            ),
            ironsmith_core::StaticAbilityPayload::EnterAsCopyAsEnters { spec, display } => {
                StaticAbility::with_enter_as_copy_as_enters(
                    super::EnterAsCopyAsEntersSpec {
                        filter: spec.filter.clone(),
                        affected_filter: spec.affected_filter.clone(),
                        may: spec.may,
                        enters_tapped_if_chosen: spec.enters_tapped_if_chosen,
                        copy_duration: spec.copy_duration.clone(),
                        linked_exile_pair: spec.linked_exile_pair.map(|pair| {
                            super::EnterAsCopyLinkedExilePairSpec {
                                counter_type: pair.counter_type,
                            }
                        }),
                        copy_source_self: spec.copy_source_self,
                        copy_source_enchanted: spec.copy_source_enchanted,
                        name_override: spec.name_override.clone(),
                        added_colors: spec.added_colors,
                        added_card_types: spec.added_card_types.clone(),
                    removes_other_card_types: spec.removes_other_card_types,
                        added_supertypes: spec.added_supertypes.clone(),
                        removed_supertypes: spec.removed_supertypes.clone(),
                        added_subtypes: spec.added_subtypes.clone(),
                        added_abilities: spec
                            .added_abilities
                            .iter()
                            .map(Self::ability_from_model)
                            .collect(),
                        set_base_power_toughness: spec.set_base_power_toughness,
                        additional_counters: spec.additional_counters.clone(),
                        additional_x_counters: spec.additional_x_counters.clone(),
                        keep_other_source_abilities: spec.keep_other_source_abilities,
                        additional_counters_source_filter: spec.additional_counters_source_filter.clone(),
                        conditional_additional_counters: spec.conditional_additional_counters.clone(),
                        added_abilities_source_filter: spec.added_abilities_source_filter.clone(),
                        set_base_power_toughness_from_self: spec
                            .set_base_power_toughness_from_self,
                        copy_followups: spec.copy_followups.clone(),
                    },
                    display.clone(),
                )
            }
            ironsmith_core::StaticAbilityPayload::DoubleDamageFromSourcesYouControlOfChosenType(
                display,
            ) => StaticAbility::double_damage_from_sources_you_control_of_chosen_type(
                display.clone(),
            ),
            ironsmith_core::StaticAbilityPayload::RedirectDamageToSourceController {
                source_filter,
                target_player_filter,
                display,
            } => StaticAbility::redirect_damage_to_source_controller(
                source_filter.clone(),
                target_player_filter.clone(),
                display.clone(),
            ),
            ironsmith_core::StaticAbilityPayload::AdditionalLandPlays(count) => {
                StaticAbility::additional_land_plays(*count)
            }
            ironsmith_core::StaticAbilityPayload::RevealFirstCardYouDrawEachTurn {
                optional,
                your_turns_only,
                linked_reveal_pair,
            } => {
                let mut reveal = super::misc::RevealFirstCardYouDrawEachTurn::new(*optional, *your_turns_only);
                reveal.linked_reveal_pair = *linked_reveal_pair;
                StaticAbility::new(reveal)
            },
            ironsmith_core::StaticAbilityPayload::ExileToCounteredExileInsteadOfGraveyard {
                player,
                counter_type,
            } => StaticAbility::exile_to_countered_exile_instead_of_graveyard(
                player.clone(),
                *counter_type,
            ),
            ironsmith_core::StaticAbilityPayload::ExileToExileInsteadOfGraveyard {
                filter,
                graveyard_owner,
                exclude_cycled,
                link_to_source,
            } => {
                let mut replacement = if *exclude_cycled {
                    super::misc::ExileToExileInsteadOfGraveyard::unless_cycled(
                        filter.clone(),
                        graveyard_owner.clone(),
                    )
                } else {
                    super::misc::ExileToExileInsteadOfGraveyard::new(
                        filter.clone(),
                        graveyard_owner.clone(),
                    )
                };
                replacement.link_to_source = *link_to_source;
                StaticAbility::new(replacement)
            }
            ironsmith_core::StaticAbilityPayload::ExileWouldDieInstead {
                filter,
                damaged_by,
                damager_filter,
                damager_filter_surface,
                exile_with_counters,
                follow_up_effects,
            } => {
                if let Some(damager_filter) = damager_filter {
                    StaticAbility::exile_would_die_instead_with_damage_filter_surface(
                        filter.clone(),
                        damager_filter.clone(),
                        damager_filter_surface.clone(),
                    )
                } else {
                    StaticAbility::exile_would_die_instead_with_damage_source_counters_and_follow_up(
                        filter.clone(),
                        *damaged_by,
                        exile_with_counters.clone(),
                        follow_up_effects.clone(),
                    )
                }
            }
            ironsmith_core::StaticAbilityPayload::ModifyDamageAmountReplacement {
                source_filter, target_player_filter, target_object_filter,
                delta, dynamic_delta, noncombat_only, display,
            } => {
                let mut native = super::ModifyDamageAmountReplacement::new(
                    source_filter.clone(), target_player_filter.clone(),
                    target_object_filter.clone(), *delta, display.clone(),
                ).with_noncombat_only(*noncombat_only);
                if let Some(value) = dynamic_delta {
                    native = native.with_dynamic_delta(value.clone());
                }
                StaticAbility::new(native)
            },
            ironsmith_core::StaticAbilityPayload::MinimumDamageAmountReplacement {
                source_filter,
                target_player_filter,
                target_object_filter,
                floor,
                noncombat_only,
                display,
            } => StaticAbility::minimum_damage_amount_replacement(
                source_filter.clone(),
                target_player_filter.clone(),
                target_object_filter.clone(),
                floor.clone(),
                *noncombat_only,
                display.clone(),
            ),
            ironsmith_core::StaticAbilityPayload::DoubleDamageAmountReplacement {
                source_filter,
                target_player_filter,
                target_object_filter,
                factor,
                combat_only,
                noncombat_only,
                display,
            } => {
                let mut replacement = crate::static_abilities::DoubleDamageAmountReplacement::new(
                    source_filter.clone(),
                    target_player_filter.clone(),
                    target_object_filter.clone(),
                    *factor,
                    *combat_only,
                    display.clone(),
                );
                if *noncombat_only {
                    replacement = replacement.noncombat_only();
                }
                StaticAbility::new(replacement)
            }
            ironsmith_core::StaticAbilityPayload::DrawReplacementWithEffects {
                drawer,
                except_first_of_draw_step,
                replacement_effects,
                display,
                cycling_source,
            } => StaticAbility::draw_replacement_with_effects_and_cycling_source(
                drawer.clone(),
                *except_first_of_draw_step,
                replacement_effects.clone(),
                display.clone(),
                cycling_source.clone(),
            ),
            ironsmith_core::StaticAbilityPayload::PreventMatchingDamageWithFollowUp(spec) => {
                StaticAbility::prevent_matching_damage_with_follow_up(spec.clone())
            }
            ironsmith_core::StaticAbilityPayload::EventReplacementWithEffects {
                event,
                replacement_effects,
                display,
                optional,
            } => StaticAbility::new(
                super::EventReplacementWithEffects::new(
                    event.clone(),
                    replacement_effects.clone(),
                    display.clone(),
                )
                .with_optional(*optional),
            ),
            ironsmith_core::StaticAbilityPayload::EventAmountReplacement {
                event,
                modifier,
                optional,
                display,
            } => StaticAbility::new(super::EventAmountReplacement::new(
                event.clone(),
                *modifier,
                *optional,
                display.clone(),
            )),
            ironsmith_core::StaticAbilityPayload::RedirectMatchingDamage(spec) => {
                StaticAbility::redirect_matching_damage(spec.clone())
            }
            ironsmith_core::StaticAbilityPayload::PreventMatchingDamage(spec) => {
                StaticAbility::prevent_matching_damage(spec.clone())
            }
            ironsmith_core::StaticAbilityPayload::PreventHalfDamageReplacement {
                source_filter,
                target_player_filter,
                target_object_filter,
                round_up,
                display,
            } => StaticAbility::prevent_half_damage_replacement(
                source_filter.clone(),
                target_player_filter.clone(),
                target_object_filter.clone(),
                *round_up,
                display.clone(),
            ),
            ironsmith_core::StaticAbilityPayload::DoubleCountersReplacement {
                filter,
                player_filter,
                counter_type,
                actor,
                includes_permanents,
                halve,
                effect_only,
                display,
            } => StaticAbility::new(super::DoubleCountersReplacement {
                filter: filter.clone(),
                player_filter: player_filter.clone(),
                counter_type: *counter_type,
                actor: actor.clone(),
                includes_permanents: *includes_permanents,
                halve: *halve,
                effect_only: *effect_only,
                display: display.clone(),
            }),
            ironsmith_core::StaticAbilityPayload::ActorCountersAddition { filter, player_filter, actor, counter_type, additional, display } =>
                StaticAbility::actor_counters_addition_replacement(filter.clone(), player_filter.clone(), actor.clone(), *counter_type, *additional, display.clone()),
            ironsmith_core::StaticAbilityPayload::AddCountersPlacementReplacement {
                filter,
                player_filter,
                counter_type,
                additional,
                cause,
                display,
            } => match (player_filter, cause) {
                (Some(player_filter), _) => StaticAbility::add_player_counters_placement_replacement(
                    player_filter.clone(),
                    *counter_type,
                    *additional,
                    display.clone(),
                ),
                (None, Some(cause)) => StaticAbility::add_caused_counters_placement_replacement(
                    filter.clone(),
                    *counter_type,
                    *additional,
                    cause.clone(),
                    display.clone(),
                ),
                (None, None) => StaticAbility::add_counters_placement_replacement(
                    filter.clone(),
                    *counter_type,
                    *additional,
                    display.clone(),
                ),
            },
            ironsmith_core::StaticAbilityPayload::PlayerCounterPerTurnLimitReplacement {
                player_filter,
                counter_type,
                maximum,
                display,
            } => StaticAbility::player_counter_per_turn_limit_replacement(
                player_filter.clone(),
                *counter_type,
                *maximum,
                display.clone(),
            ),
            ironsmith_core::StaticAbilityPayload::DoubleTokenCreationReplacement {
                controller,
                display,
            } => StaticAbility::double_token_creation_replacement(
                controller.clone(),
                display.clone(),
            ),
            ironsmith_core::StaticAbilityPayload::AddTokenCreationReplacement {
                controller,
                token_filter,
                additional_token,
                additional,
                per_created,
                display,
            } => {
                if *per_created {
                    StaticAbility::add_token_per_created_replacement(
                        controller.clone(),
                        token_filter.clone(),
                        *additional_token,
                        display.clone(),
                    )
                } else {
                    StaticAbility::add_token_creation_replacement(
                        controller.clone(),
                        token_filter.clone(),
                        *additional_token,
                        *additional,
                        display.clone(),
                    )
                }
            }
            ironsmith_core::StaticAbilityPayload::NamedActionReplacement { label, source_filter, performer_filter, object_requirement, replacement_effects, optional, display } =>
                StaticAbility::new(super::misc::NamedActionReplacement { label: label.clone(), source_filter: source_filter.clone(), performer_filter: performer_filter.clone(), object_requirement:object_requirement.clone(), replacement_effects: replacement_effects.clone(), optional: *optional, display: display.clone() }),
            ironsmith_core::StaticAbilityPayload::KeywordActionReplacement {
                action,
                source_filter,
                performer_filter,
                replacement_effects,
                optional,
                display,
            } => StaticAbility::keyword_action_replacement_with_performer(
                *action,
                source_filter.clone(),
                performer_filter.clone(),
                replacement_effects.clone(),
                *optional,
                display.clone(),
            ),
            ironsmith_core::StaticAbilityPayload::DrawExtraCardsReplacement {
                extra,
                except_first_of_draw_step,
                per_instruction,
                display,
            } => StaticAbility::draw_extra_cards_replacement_with_options(
                *extra,
                *except_first_of_draw_step,
                *per_instruction,
                display.clone(),
            ),
            ironsmith_core::StaticAbilityPayload::ConditionalDrawReplacement {
                condition,
                replacement_effects,
                optional,
                display,
                except_first_of_draw_step,
            } => StaticAbility::conditional_draw_replacement_with_draw_step_exception(
                condition.clone(),
                replacement_effects.clone(),
                *optional,
                *except_first_of_draw_step,
                display.clone(),
            ),
            ironsmith_core::StaticAbilityPayload::LoseGameReplacement {
                replacement_effects,
                optional,
                display,
            } => StaticAbility::lose_game_replacement(
                replacement_effects.clone(),
                *optional,
                display.clone(),
            ),
            ironsmith_core::StaticAbilityPayload::DrawReplacementRevealTopMatchingToHandRestBottom {
                count,
                filter,
                order,
                display,
            } => StaticAbility::draw_replacement_reveal_top_matching_to_hand_rest_bottom(
                *count,
                filter.clone(),
                *order,
                display.clone(),
            ),
            ironsmith_core::StaticAbilityPayload::CharacteristicDefiningPt {
                power,
                toughness,
            } => StaticAbility::characteristic_defining_pt(power.clone(), toughness.clone()),
            ironsmith_core::StaticAbilityPayload::DiscardOrRedirectReplacement {
                filter,
                redirect_zone,
            } => StaticAbility::discard_or_redirect_replacement(filter.clone(), *redirect_zone),
            ironsmith_core::StaticAbilityPayload::SacrificeOrRedirectReplacement {
                filter,
                count,
                redirect_zone,
            } => StaticAbility::sacrifice_or_redirect_replacement(
                filter.clone(),
                *count,
                *redirect_zone,
            ),
            ironsmith_core::StaticAbilityPayload::PayLifeOrEnterTapped(value) => {
                StaticAbility::pay_life_or_enter_tapped(*value)
            }
            ironsmith_core::StaticAbilityPayload::RevealCardOrEnterTapped {
                filter,
                subject,
                tail_subject,
            } => StaticAbility::reveal_card_or_enter_tapped(
                filter.clone(),
                subject.clone(),
                tail_subject.clone(),
            ),
            ironsmith_core::StaticAbilityPayload::RedirectWouldEnter {
                filter,
                not_cast,
                destination,
                display,
                or_no_mana_spent,
            } => StaticAbility::new(
                super::misc::RedirectWouldEnterReplacement::new(
                    filter.clone(),
                    *not_cast,
                    *destination,
                    display.clone(),
                )
                .with_or_no_mana_spent(*or_no_mana_spent),
            ),
            ironsmith_core::StaticAbilityPayload::ConvertUnspentMana { player, symbol } =>
                StaticAbility::new(super::misc::ConvertUnspentMana { player: player.clone(), symbol: *symbol }),
            ironsmith_core::StaticAbilityPayload::ManaProductionRewrite { rule, display } =>
                StaticAbility::mana_production_rewrite(rule.clone(), display.clone()),
            ironsmith_core::StaticAbilityPayload::ManaProductionReplacement {
                source_filter,
                minimum_amount,
                replacement_mana,
                display,
            } => StaticAbility::mana_production_replacement(
                source_filter.clone(),
                *minimum_amount,
                replacement_mana.clone(),
                display.clone(),
            ),
            ironsmith_core::StaticAbilityPayload::ManaProductionMultiplierReplacement {
                source_filter,
                factor,
                display,
            } => StaticAbility::mana_production_multiplier_replacement(
                source_filter.clone(),
                *factor,
                display.clone(),
            ),
            ironsmith_core::StaticAbilityPayload::CreateOneOfEachTokenReplacement { kinds, display } => {
                StaticAbility::create_one_of_each_token_replacement(kinds.clone(), display.clone())
            }
            ironsmith_core::StaticAbilityPayload::RedirectDrawReplacement {
                drawer,
                except_first_of_draw_step,
                display,
            } => StaticAbility::redirect_draw_replacement(
                drawer.clone(),
                *except_first_of_draw_step,
                display.clone(),
            ),
            ironsmith_core::StaticAbilityPayload::MultiplyTokenCreationReplacement {
                controller,
                token_filter,
                factor,
                display,
            } => StaticAbility::multiply_token_creation_replacement(
                controller.clone(),
                token_filter.clone(),
                *factor,
                display.clone(),
            ),
            ironsmith_core::StaticAbilityPayload::TokenCreationTemplates { controller, token_filter, templates, mode, choose_one, optional, display } => {
                StaticAbility::token_creation_templates(controller.clone(), token_filter.clone(), templates.clone(), *mode, *choose_one, *optional, display.clone())
            }
            ironsmith_core::StaticAbilityPayload::AddLifeGainReplacement { player, additional, display } =>
                StaticAbility::add_life_gain_replacement(player.clone(), *additional, display.clone()),
            ironsmith_core::StaticAbilityPayload::DoubleLifeChangeReplacement {
                player,
                loss,
                display,
            } => StaticAbility::double_life_change_replacement(
                player.clone(),
                *loss,
                display.clone(),
            ),
            ironsmith_core::StaticAbilityPayload::ManaSpendPermission {
                permission,
                display,
            } => StaticAbility::mana_spend_permission(permission.clone(), display.clone()),
            ironsmith_core::StaticAbilityPayload::Landwalk(kind) => match kind {
                ironsmith_core::LandwalkKind::Subtype {
                    subtype,
                    snow: false,
                } => StaticAbility::landwalk(*subtype),
                ironsmith_core::LandwalkKind::Subtype {
                    subtype,
                    snow: true,
                } => StaticAbility::snow_landwalk(*subtype),
                ironsmith_core::LandwalkKind::AnyLand => StaticAbility::any_landwalk(),
                ironsmith_core::LandwalkKind::NonbasicLand => StaticAbility::nonbasic_landwalk(),
                ironsmith_core::LandwalkKind::ArtifactLand => StaticAbility::artifact_landwalk(),
                ironsmith_core::LandwalkKind::LegendaryLand => StaticAbility::legendary_landwalk(),
                ironsmith_core::LandwalkKind::SnowLand => StaticAbility::snow_any_landwalk(),
                ironsmith_core::LandwalkKind::ChosenType { snow } => {
                    StaticAbility::chosen_type_landwalk(*snow)
                }
                ironsmith_core::LandwalkKind::SacrificedLandTypes => {
                    StaticAbility::sacrificed_land_types_landwalk()
                }
            },
            ironsmith_core::StaticAbilityPayload::Bloodthirst(amount) => {
                StaticAbility::bloodthirst(*amount)
            }
            ironsmith_core::StaticAbilityPayload::Tribute(amount) => StaticAbility::tribute(*amount),
            ironsmith_core::StaticAbilityPayload::PreventDamageToSelfRemoveCounter {
                counter_type,
                amount,
                follow_up,
                one_damage_per_counter,
                surface,
            } => {
                if *one_damage_per_counter {
                    StaticAbility::prevent_one_damage_to_self_per_removed_counter(*counter_type)
                } else {
                    StaticAbility::new(
                        crate::static_abilities::PreventDamageToSelfRemoveCounter::new_with_follow_up(
                            *counter_type,
                            amount.clone(),
                            *follow_up,
                        )
                        .with_surface(*surface),
                    )
                }
            }
            ironsmith_core::StaticAbilityPayload::PreventDamageToSelfPutCountersInstead {
                counter_type,
                display,
            } => StaticAbility::prevent_damage_to_self_put_counters_instead(
                *counter_type,
                display.clone(),
            ),
            ironsmith_core::StaticAbilityPayload::HealDamageBeforeDamageToSelf { display } => {
                StaticAbility::heal_damage_before_damage_to_self(display.clone())
            }
            ironsmith_core::StaticAbilityPayload::PreventConstrainedDamageToSelfPutCountersInstead {
                counter_type,
                display,
                source_filter,
                combat_only,
            } => StaticAbility::prevent_constrained_damage_to_self_put_counters_instead(
                *counter_type,
                display.clone(),
                source_filter.clone(),
                *combat_only,
            ),
            ironsmith_core::StaticAbilityPayload::PreventDamageToYouFromSourceFilter {
                amount,
                source_filter,
                display,
            } => StaticAbility::prevent_damage_to_you_from_source_filter(
                *amount,
                source_filter.clone(),
                display.clone(),
            ),
            ironsmith_core::StaticAbilityPayload::DamagePreventionWithFollowUp {
                source_filter, target_filter, combat_only, recipient_tag, effects,
            } => StaticAbility::new(super::misc::DamagePreventionWithFollowUp {
                source_filter: source_filter.clone(),
                target_filter: target_filter.clone(),
                combat_only: *combat_only,
                effects: std::iter::once(crate::effect::Effect::tag_triggering_damage_target(recipient_tag.clone())).chain(effects.iter().cloned()).collect(),
            }),
            ironsmith_core::StaticAbilityPayload::ReplaceDamageWithCountersInstead {
                counter_type,
                display,
                source_filter,
                target_filter,
                combat_only,
            } => StaticAbility::replace_damage_with_counters_instead(
                *counter_type,
                source_filter.clone(),
                target_filter.clone(),
                *combat_only,
                display.clone(),
            ),
            ironsmith_core::StaticAbilityPayload::CantAttackYouUnlessControllerPaysPerAttacker(
                amount,
            ) => StaticAbility::cant_attack_you_unless_controller_pays_per_attacker(*amount),
            ironsmith_core::StaticAbilityPayload::CantAttackYouOrPlaneswalkersUnlessControllerPaysPerAttacker(
                amount,
            ) => StaticAbility::cant_attack_you_or_planeswalkers_unless_controller_pays_per_attacker(
                *amount,
            ),
            ironsmith_core::StaticAbilityPayload::CantAttackYouUnlessControllerPaysPerAttackerBasicLandTypesAmongLandsYouControl => {
                StaticAbility::cant_attack_you_unless_controller_pays_per_attacker_basic_land_types_among_lands_you_control()
            }
            ironsmith_core::StaticAbilityPayload::Grants(spec) => {
                StaticAbility::grants(Self::grant_spec_from_model(spec))
            }
            ironsmith_core::StaticAbilityPayload::EntersTappedUnlessCondition {
                condition,
                display,
            } => StaticAbility::enters_tapped_unless_condition(condition.clone(), display.clone()),
            ironsmith_core::StaticAbilityPayload::EntersWithCountersIfCondition {
                counter,
                count,
                condition,
                display,
                added_abilities,
            } => StaticAbility::enters_with_counters_and_abilities_if_condition(
                *counter,
                count.clone(),
                condition.clone(),
                display.clone(),
                added_abilities
                    .iter()
                    .map(Self::ability_from_model)
                    .collect(),
            ),
            ironsmith_core::StaticAbilityPayload::IntrinsicStartingCounters(rule) => StaticAbility::intrinsic_starting_counters(*rule),
            ironsmith_core::StaticAbilityPayload::EntersWithCountersValue { counter, count } => {
                StaticAbility::enters_with_counters_value(*counter, count.clone())
            }
            ironsmith_core::StaticAbilityPayload::EntersWithCounterChoice {
                counter_types,
                count,
                kinds,
                condition,
                display,
            } => {
                let mut choice =
                    super::misc::EntersWithCounterChoice::new(counter_types.clone(), count.clone())
                        .with_kinds(*kinds);
                if let Some(condition) = condition {
                    choice = choice.with_condition(condition.clone(), display.clone());
                }
                StaticAbility::new(choice)
            }
            ironsmith_core::StaticAbilityPayload::EntersUnderChosenControl(players) => {
                StaticAbility::new(super::misc::EntersUnderChosenControl(players.clone()))
            }
            ironsmith_core::StaticAbilityPayload::EntersTappedForFilter(filter) => {
                StaticAbility::enters_tapped_for_filter(filter.clone())
            }
            ironsmith_core::StaticAbilityPayload::EntersUntappedForFilter(filter) => {
                StaticAbility::enters_untapped_for_filter(filter.clone())
            }
            ironsmith_core::StaticAbilityPayload::EntersWithCountersAndSubtypesForFilter {
                filter, counter, counter_kinds_from, count, count_condition, otherwise_count, subtypes,
            } => {
                let mut native = super::EnterWithCountersForFilter::new(filter.clone(), *counter, count.clone())
                    .with_added_subtypes(subtypes.clone());
                if let (Some(condition), Some(otherwise)) = (count_condition, otherwise_count) {
                    native = native.with_count_if_otherwise(condition.clone(), otherwise.clone());
                }
                if let Some(source) = counter_kinds_from { native = native.with_counter_kinds_from(source.clone()); }
                StaticAbility::new(native)
            },
            ironsmith_core::StaticAbilityPayload::EntersWithCharacteristicsForFilter {
                face_down,
                filter,
                card_types,
                subtypes,
                power,
                toughness,
            } => if *face_down { StaticAbility::new(crate::static_abilities::misc::EnterWithCharacteristicsForFilter::face_down(filter.clone())) } else { StaticAbility::enters_with_characteristics_for_filter(
                filter.clone(),
                card_types.clone(),
                subtypes.clone(),
                *power,
                *toughness,
            ) },
            _ => return None,
        })
    }
}

impl StaticAbility {
    pub fn additional_spell_targets_spec(&self) -> Option<(&crate::target::ObjectFilter,u32)> {
        match &self.compiled_model()?.payload {
            ironsmith_core::StaticAbilityPayload::AdditionalSpellTargets { filter, amount } => Some((filter,*amount)),
            _ => None,
        }
    }
    pub fn enchant(filter: crate::object::AuraAttachmentFilter) -> Self {
        Self::from_model(CompiledStaticAbility::enchant(filter))
    }

    /// A keyword granted to matching spells as they are cast (CR 601.2b).
    pub fn grant_spell_keyword(
        filter: crate::target::ObjectFilter,
        keyword: ironsmith_core::GrantedSpellKeyword<crate::costs::Cost>,
        set_quantifier_surface: Option<ironsmith_core::SetQuantifierSurface>,
        display: impl Into<String>,
    ) -> Self {
        Self::from_model(CompiledStaticAbility::grant_spell_keyword(
            filter,
            keyword,
            set_quantifier_surface,
            display,
        ))
    }

    pub fn enchant_filter(&self) -> Option<&crate::object::AuraAttachmentFilter> {
        match &self.compiled_model()?.payload {
            ironsmith_core::StaticAbilityPayload::Enchant(filter) => Some(filter),
            _ => None,
        }
    }

    pub fn from_model(model: CompiledStaticAbility) -> Self {
        // Native debug builds retain large enum temporaries in materialization
        // frames. Grow before entering those frames for deeply nested models.
        crate::perf::maybe_grow(8 * 1024 * 1024, 64 * 1024 * 1024, || {
            Self::new(StaticAbilityModelInterpreter::new(model))
        })
    }
}

impl StaticAbilityKind for StaticAbilityModelInterpreter {
    fn id(&self) -> StaticAbilityId {
        if let Some(ability) = self.leaf_static_ability() {
            return ability.id();
        }
        self.model.id.unwrap_or(StaticAbilityId::RuleFallbackText)
    }

    fn compiled_model(&self) -> Option<&CompiledStaticAbility> {
        Some(&self.model)
    }

    fn black_mana_may_be_paid_with_life(&self) -> bool {
        self.leaf_static_ability()
            .is_some_and(StaticAbility::black_mana_may_be_paid_with_life)
    }

    fn cant_be_countered(&self) -> bool {
        self.leaf_static_ability()
            .is_some_and(StaticAbility::cant_be_countered)
    }

    fn bands_with_other_filter(&self) -> Option<&crate::target::ObjectFilter> {
        self.leaf_static_ability()?.bands_with_other_filter()
    }

    fn can_attack_with_attacking_group(
        &self,
        game: &GameState,
        source: ObjectId,
        controller: PlayerId,
        attacking_creatures: &[ObjectId],
    ) -> Option<bool> {
        self.leaf_static_ability()?.can_attack_with_attacking_group(
            game,
            source,
            controller,
            attacking_creatures,
        )
    }

    fn can_block_with_blocking_group(
        &self,
        game: &GameState,
        source: ObjectId,
        blocking_creatures: &[ObjectId],
    ) -> Option<bool> {
        self.leaf_static_ability()?
            .can_block_with_blocking_group(game, source, blocking_creatures)
    }

    fn can_pay_attack_cost(
        &self,
        game: &GameState,
        source: ObjectId,
        controller: PlayerId,
    ) -> Option<bool> {
        self.leaf_static_ability()?
            .can_pay_attack_cost(game, source, controller)
    }

    fn generic_attack_mana_cost_for_source(
        &self,
        game: &GameState,
        source: ObjectId,
        controller: PlayerId,
    ) -> Option<u32> {
        self.leaf_static_ability()?
            .generic_attack_mana_cost_for_source(game, source, controller)
    }

    fn required_defending_player_card_type_for_unblockable(
        &self,
    ) -> Option<crate::types::CardType> {
        self.leaf_static_ability()?
            .required_defending_player_card_type_for_unblockable()
    }

    fn required_defending_player_card_types_for_unblockable(
        &self,
    ) -> Option<Vec<crate::types::CardType>> {
        self.leaf_static_ability()?
            .required_defending_player_card_types_for_unblockable()
    }

    fn max_creatures_can_attack_each_combat(&self) -> Option<usize> {
        self.leaf_static_ability()?
            .max_creatures_can_attack_each_combat()
    }

    fn max_creatures_can_attack_you_each_combat(&self) -> Option<usize> {
        self.leaf_static_ability()?
            .max_creatures_can_attack_you_each_combat()
    }

    fn max_creatures_can_block_each_combat(&self) -> Option<usize> {
        self.leaf_static_ability()?
            .max_creatures_can_block_each_combat()
    }

    fn intrinsic_starting_counter_rule(&self) -> Option<ironsmith_core::IntrinsicStartingCounter> {
        self.leaf_static_ability()?
            .intrinsic_starting_counter_rule()
    }

    fn deck_copy_limit(&self) -> Option<Option<u32>> {
        self.leaf_static_ability().and_then(StaticAbility::deck_copy_limit)
    }

    fn toxic_amount(&self) -> Option<u32> {
        self.leaf_static_ability().and_then(StaticAbility::toxic_amount)
    }

    fn deck_color_choice_count(&self) -> Option<u32> {
        self.leaf_static_ability()
            .and_then(StaticAbility::deck_color_choice_count)
    }

    fn keyword_marker_mechanic(&self) -> Option<ironsmith_core::KeywordMarkerMechanic> {
        self.leaf_static_ability()
            .and_then(StaticAbility::keyword_marker_mechanic)
    }

    fn draft_rule(&self) -> Option<ironsmith_core::DraftRule> {
        self.leaf_static_ability().and_then(StaticAbility::draft_rule)
    }

    fn must_attack_draft_noted_card_name(&self) -> Option<String> {
        self.leaf_static_ability()
            .and_then(StaticAbility::must_attack_draft_noted_card_name)
    }

    fn commander_pairing(&self) -> Option<super::CommanderPairing> {
        self.leaf_static_ability()
            .and_then(StaticAbility::commander_pairing)
    }

    fn dungeon_entry_quality(&self) -> Option<&str> {
        // CR 701.49d: a compiled "venture into [quality]" restriction.
        if let Some(quality) = self
            .leaf_static_ability()
            .and_then(|ability| ability.dungeon_entry_quality())
        {
            return Some(quality);
        }
        (self.model.id == Some(StaticAbilityId::DungeonEntryRestriction))
            .then_some(self.model.label.as_str())
    }

    fn exile_would_die_instead_spec(
        &self,
    ) -> Option<(
        &crate::target::ObjectFilter,
        Option<ironsmith_core::DamagedBySource>,
        Option<&crate::target::ObjectFilter>,
        &[(crate::object::CounterType, u32)],
        &[crate::effect::Effect],
    )> {
        let ironsmith_core::StaticAbilityPayload::ExileWouldDieInstead {
            filter,
            damaged_by,
            damager_filter,
            damager_filter_surface: _,
            exile_with_counters,
            follow_up_effects,
        } = &self.model.payload
        else {
            return None;
        };
        Some((
            filter,
            *damaged_by,
            damager_filter.as_ref(),
            exile_with_counters,
            follow_up_effects,
        ))
    }

    fn prefers_card_name_subject(&self) -> bool {
        // A generic condition wrapper can lower a leaf ability through a
        // `GrantAbility::source` fallback when that leaf has no native
        // conditional form. That runtime fallback preserves behavior, but it
        // does not carry presentation preferences such as an authored
        // source-name subject. Read that preference from the wrapped typed
        // model before consulting the executable leaf.
        if let ironsmith_core::StaticAbilityPayload::Conditional { ability, .. } =
            &self.model.payload
        {
            return StaticAbility::from_model((**ability).clone()).prefers_card_name_subject();
        }
        self.leaf_static_ability()
            .is_some_and(StaticAbility::prefers_card_name_subject)
    }

    fn authored_line_surface(&self) -> Option<String> {
        ((self.model.id == Some(StaticAbilityId::SetCardTypes)
            && self.model.label != "set card types")
            || (self.model.id == Some(StaticAbilityId::Flash)
                && !self.model.label.eq_ignore_ascii_case("flash"))
            || (self.model.id == Some(StaticAbilityId::Menace)
                && !self.model.label.eq_ignore_ascii_case("menace")))
        .then(|| self.model.label.clone())
    }

    fn display(&self) -> String {
        if let ironsmith_core::StaticAbilityPayload::CustomKeywordIdentity { name } = self.payload() {
            return name.clone();
        }
        if let ironsmith_core::StaticAbilityPayload::ShuffleIntoOwnersLibraryInstead {
            to_zone,
            reveal,
        } = &self.model.payload
        {
            return super::misc::self_shuffle_into_library_display(*to_zone, *reveal);
        }
        if let ironsmith_core::StaticAbilityPayload::RedirectZoneChange {
            filter,
            from_zone: Some(crate::zone::Zone::Battlefield),
            to_zone: None,
            destination: crate::zone::Zone::Exile,
        } = &self.model.payload
        {
            return format!(
                "If {} would leave the battlefield, exile it instead of putting it anywhere else.",
                filter.description(),
            );
        }
        if self.model.label == "Aftermath" {
            return "Aftermath".to_string();
        }
        // CR 601.2b: the typed grant reads as "<spells> have <keyword>".
        if let ironsmith_core::StaticAbilityPayload::GrantSpellKeyword {
            filter,
            keyword,
            set_quantifier_surface,
        } = &self.model.payload
        {
            if keyword.kind == ironsmith_core::GrantedSpellKeywordKind::AnyAmountOfManaForEntryCounters {
                let mut subject_filter = filter.clone();
                subject_filter.cast_by = None;
                return format!(
                    "As an additional cost to cast {}, you may pay any amount of mana. If you do, that creature enters with that many additional +1/+1 counters on it.",
                    super::cost_modifiers::describe_spell_filter(&subject_filter)
                );
            }
            let (mut subject, singular) =
                super::continuous::grant_subject_with_set_quantifier(filter, *set_quantifier_surface);
            // "Each spell you cast that's exactly three colors" (Threefold
            // Signal): keep the exact color count when the subject text omits it.
            if let Some(crate::filter::Comparison::Equal(count @ 3..=5)) = filter.color_count
                && !subject.contains("color")
            {
                let count_word = ["three", "four", "five"][(count - 3) as usize];
                let relation = if singular { "that's" } else { "that are" };
                subject = format!("{subject} {relation} exactly {count_word} colors");
            }
            // "The first spell you cast from anywhere other than your hand
            // each turn has demonstrate." (The Twelfth Doctor)
            if filter.excluded_cast_origin_zone == Some(crate::zone::Zone::Hand)
                && !subject.contains("other than your hand")
            {
                subject = match subject.split_once(" each turn") {
                    Some((head, tail)) => {
                        format!("{head} from anywhere other than your hand each turn{tail}")
                    }
                    None => format!("{subject} from anywhere other than your hand"),
                };
            }
            // "Creature spells you cast gain offspring {2} as you cast them."
            if keyword.kind == ironsmith_core::GrantedSpellKeywordKind::Offspring && !singular {
                return format!("{subject} gain {} as you cast them.", keyword.display());
            }
            let verb = if singular { "has" } else { "have" };
            return format!("{subject} {verb} {}.", keyword.display());
        }
        if let ironsmith_core::StaticAbilityPayload::Conditional { ability, .. } =
            &self.model.payload
            && self.model.label != ability.label
        {
            let body = StaticAbility::from_model((**ability).clone()).display();
            return format!("{} — {body}", self.model.label);
        }
        // A conditional leaf with no continuous effect keeps its native
        // display unconditioned; the gate is still part of the ability.
        if let ironsmith_core::StaticAbilityPayload::Conditional { condition, .. } =
            &self.model.payload
            && let Some(leaf) = self.leaf_static_ability()
            && !leaf.may_generate_continuous_effects()
        {
            let body = leaf.display();
            let body = body.trim_end_matches('.');
            let condition = super::continuous::describe_static_condition(condition);
            if leaf.id() == StaticAbilityId::EntersTapped
                && let Some(rest) = condition.strip_prefix("as long as ")
            {
                let mut chars = body.chars();
                let lowered = chars
                    .next()
                    .map(|first| first.to_lowercase().chain(chars).collect::<String>())
                    .unwrap_or_default();
                return format!("If {rest}, {lowered}");
            }
            // "You may cast this card from your graveyard if a non-Zombie
            // creature died this turn. If you do, ..." (Undead Sprinter): the
            // gate qualifies the permission, not the trailing rider.
            if let Some(rest) = condition.strip_prefix("as long as ")
                && let Some((permission, rider)) =
                    body.split_once("You may cast this card from your graveyard")
                && permission.is_empty()
            {
                return format!(
                    "You may cast this card from your graveyard if {rest}{rider}."
                );
            }
            return format!("{body} {condition}");
        }
        if let Some(ability) = self.leaf_static_ability() {
            return ability.display();
        }
        if let Some(reduction) = &self.this_spell_cost_reduction {
            return reduction.display();
        }
        if let Some(reduction) = &self.this_spell_cost_reduction_mana_cost {
            return reduction.display();
        }
        if let Some(reduction) = &self.cost_reduction {
            return reduction.display();
        }
        if let Some(reduction) = &self.cost_reduction_mana_cost {
            return reduction.display();
        }
        if let Some(increase) = &self.cost_increase {
            return increase.display();
        }
        if let Some(increase) = &self.cost_increase_mana_cost {
            return increase.display();
        }
        if let Some(increase) = &self.cost_increase_mana_cost_per_additional_target {
            return increase.display();
        }
        if let Some(reduction) = &self.activated_ability_cost_reduction {
            return reduction.display();
        }
        if let Some(increase) = &self.activated_ability_cost_increase {
            return increase.display();
        }
        // No structural display handles this model: its label is all that
        // describes it, so an audit reports the gap instead of the label. A
        // payload-free model's behavior is fixed by its id, which is read.
        if ironsmith_core::semantic_audit::semantic_audit_active()
            && matches!(self.model.payload, ironsmith_core::StaticAbilityPayload::None)
            && let Some(id) = self.model.id
        {
            return ironsmith_core::semantic_audit::humanize_variant(&id);
        }
        ironsmith_core::semantic_audit::retained("StaticModel", &self.model.label, &self.model.payload)
    }

    fn life_total_note_as_enters(
        &self,
    ) -> Option<crate::static_abilities::NoteLifeTotalAsEntersSpec> {
        self.leaf_static_ability()?.life_total_note_as_enters()
    }

    fn rule_restriction_parts(
        &self,
    ) -> Option<(
        &crate::effect::Restriction,
        &str,
        Option<&crate::ConditionExpr>,
    )> {
        self.leaf_static_ability()?.rule_restriction_parts()
    }

    fn with_static_condition(&self, condition: crate::ConditionExpr) -> Option<StaticAbility> {
        if let Some(reduction) = &self.activated_ability_cost_reduction {
            return Some(StaticAbility::new(
                reduction.clone().with_static_condition(condition),
            ));
        }
        if let Some(increase) = &self.activated_ability_cost_increase {
            return Some(StaticAbility::new(
                increase.clone().with_condition(condition),
            ));
        }
        if let Some(reduction) = &self.cost_reduction {
            return Some(StaticAbility::new(
                reduction.clone().with_condition(condition),
            ));
        }
        if let Some(reduction) = &self.cost_reduction_mana_cost {
            return Some(StaticAbility::new(
                reduction.clone().with_condition(condition),
            ));
        }
        if let Some(increase) = &self.cost_increase {
            return Some(StaticAbility::new(
                increase.clone().with_condition(condition),
            ));
        }
        if let Some(increase) = &self.cost_increase_mana_cost {
            return Some(StaticAbility::new(
                increase.clone().with_condition(condition),
            ));
        }
        self.leaf_static_ability()?.with_condition(condition)
    }

    fn labeled_static_condition(&self) -> Option<(String, StaticAbility, crate::ConditionExpr)> {
        let ironsmith_core::StaticAbilityPayload::Conditional { ability, condition, .. } =
            &self.model.payload
        else {
            return None;
        };
        (self.model.label != ability.label).then(|| {
            (
                self.model.label.clone(),
                StaticAbility::from_model((**ability).clone()),
                condition.clone(),
            )
        })
    }

    fn may_generate_continuous_effects(&self) -> bool {
        if self.enter_as_copy_spec.is_some()
            && matches!(
                &self.model.payload,
                ironsmith_core::StaticAbilityPayload::Conditional { .. }
            )
        {
            return false;
        }
        self.leaf_static_ability()
            .is_some_and(StaticAbility::may_generate_continuous_effects)
    }

    fn validate_mana_scalar_ranges(
        &self,
        game: &GameState,
        source: ObjectId,
        controller: PlayerId,
    ) -> Result<bool, crate::static_ability_processor::StaticEffectDiscoveryError> {
        self.leaf_static_ability()
            .map(|ability| ability.validate_mana_scalar_ranges(game, source, controller))
            .unwrap_or(Ok(false))
    }

    fn generate_effects(
        &self,
        source: ObjectId,
        controller: PlayerId,
        game: &GameState,
    ) -> Vec<ContinuousEffect> {
        if let ironsmith_core::StaticAbilityPayload::AddSubtypesAndGrantAbilities { filter, subtypes, abilities, .. } = &self.model.payload {
            let target = crate::continuous::EffectTarget::Filter(filter.clone());
            let mut effects = vec![ContinuousEffect::new(source, controller, target.clone(),
                crate::continuous::Modification::AddSubtypes(subtypes.clone()))
                .with_source_type(crate::continuous::EffectSourceType::StaticAbility)];
            effects.extend(abilities.iter().map(|ability| ContinuousEffect::new(source, controller, target.clone(),
                crate::continuous::Modification::AddAbilityGeneric(Self::ability_from_model(ability)))
                .with_source_type(crate::continuous::EffectSourceType::StaticAbility)));
            return effects;
        }

        // Entry-copy conditions belong to the replacement occurrence. Turning
        // them into a layer-6 self-grant would duplicate that occurrence when
        // true, while the cached outer copy specification also remains visible.
        if self.enter_as_copy_spec.is_some()
            && matches!(
                &self.model.payload,
                ironsmith_core::StaticAbilityPayload::Conditional { .. }
            )
        {
            return Vec::new();
        }
        self.leaf_static_ability()
            .map(|ability| ability.generate_effects(source, controller, game))
            .unwrap_or_default()
    }

    fn apply_restrictions(&self, game: &mut GameState, source: ObjectId, controller: PlayerId) {
        if let ironsmith_core::StaticAbilityPayload::Conditional { ability, condition, .. } =
            &self.model.payload
        {
            let mut inner = ability.as_ref();
            while let ironsmith_core::StaticAbilityPayload::Conditional { ability, .. } =
                &inner.payload
            {
                inner = ability;
            }
            if matches!(
                &inner.payload,
                ironsmith_core::StaticAbilityPayload::RuleRestriction {
                    restriction: crate::effect::Restriction::Block(_)
                        | crate::effect::Restriction::BeBlocked(_),
                    additional_restrictions,
                    ..
                } if additional_restrictions.is_empty()
            ) {
                // Block and be-blocked conditions need combat participants;
                // evaluating them in a source-only frame loses the defender.
                if let Some(leaf) = self.leaf_static_ability() {
                    leaf.apply_restrictions(game, source, controller);
                }
                return;
            }
            if super::continuous::static_condition_is_active(condition, game, source, controller) {
                StaticAbility::from_model(ability.as_ref().clone())
                    .apply_restrictions(game, source, controller);
            }
            return;
        }
        if let Some(ability) = self.leaf_static_ability() {
            ability.apply_restrictions(game, source, controller);
        }
    }

    fn materialize_resolution_values(
        &self,
        game: &GameState,
        ctx: &mut crate::effects::ExecutionContext<'_>,
    ) -> Result<Option<StaticAbility>, crate::effects::ExecutionError> {
        match self.leaf_static_ability() {
            Some(ability) => ability.materialize_resolution_values(game, ctx),
            None => Ok(None),
        }
    }

    fn can_attack_specific_defender(
        &self,
        game: &GameState,
        source: ObjectId,
        controller: PlayerId,
        defending_player: PlayerId,
    ) -> Option<bool> {
        self.leaf_static_ability()?.can_attack_specific_defender(
            game,
            source,
            controller,
            defending_player,
        )
    }

    fn affects_untap(&self) -> bool {
        self.leaf_static_ability()
            .is_some_and(|ability| ability.affects_untap())
    }

    fn additional_votes_while_voting(&self) -> u32 {
        self.leaf_static_ability()
            .map_or(0, StaticAbility::additional_votes_while_voting)
    }

    fn optional_additional_votes_while_voting(&self) -> u32 {
        self.leaf_static_ability()
            .map_or(0, StaticAbility::optional_additional_votes_while_voting)
    }

    fn additional_villainous_choices_for_opponents(&self) -> u32 {
        self.leaf_static_ability()
            .map_or(0, StaticAbility::additional_villainous_choices_for_opponents)
    }

    fn untap_during_each_other_players_untap_step_filter(
        &self,
    ) -> Option<&crate::target::ObjectFilter> {
        self.leaf_static_ability()?
            .untap_during_each_other_players_untap_step_filter()
    }

    fn untap_during_other_players_untap_step_opponents_only(&self) -> bool {
        self.leaf_static_ability()
            .is_some_and(StaticAbility::untap_during_other_players_untap_step_opponents_only)
    }

    fn untap_step_limit(
        &self,
    ) -> Option<(
        &crate::target::PlayerFilter,
        &crate::target::ObjectFilter,
        u32,
    )> {
        self.leaf_static_ability()?.untap_step_limit_spec()
    }

    fn search_top_card_limit(&self) -> Option<(&crate::target::PlayerFilter, u32)> {
        self.leaf_static_ability()?.search_top_card_limit_spec()
    }

    fn untap_step_chosen_card_types(
        &self,
    ) -> Option<(&crate::target::PlayerFilter, &[crate::types::CardType])> {
        self.leaf_static_ability()?.untap_step_chosen_card_types_spec()
    }

    fn generate_replacement_effect(
        &self,
        source: ObjectId,
        controller: PlayerId,
    ) -> Option<ReplacementEffect> {
        if let ironsmith_core::StaticAbilityPayload::DamageBetweenChosenPlayers { factor, .. } = &self.model.payload {
            return Some(ReplacementEffect::with_matcher(source, controller,
                super::misc::replacements_and_rules::ChosenPlayersDamageMatcher { ability_source: source },
                crate::replacement::ReplacementAction::Modify(crate::replacement::EventModification::Multiply(*factor))));
        }

        if let ironsmith_core::StaticAbilityPayload::ShuffleIntoOwnersLibraryInstead {
            to_zone,
            reveal,
        } = &self.model.payload
        {
            return Some(super::misc::self_shuffle_into_library_replacement(
                source, controller, *to_zone, *reveal,
            ));
        }
        if let ironsmith_core::StaticAbilityPayload::RedirectZoneChange {
            filter,
            from_zone,
            to_zone,
            destination,
        } = &self.model.payload
        {
            return Some(ReplacementEffect::with_matcher(
                source,
                controller,
                crate::events::zones::matchers::WouldChangeZoneMatcher::new(
                    filter.clone(),
                    *from_zone,
                    *to_zone,
                ),
                crate::replacement::ReplacementAction::ChangeDestination(*destination),
            ));
        }
        self.leaf_static_ability()?
            .generate_replacement_effect(source, controller)
    }

    fn is_active(&self, game: &GameState, source: ObjectId) -> bool {
        // Native restrictions own contextual predicates, including the
        // opposing attacker. Evaluating them in a source-only frame first
        // discards a valid conditional block restriction before pair checks.
        if self.id() == StaticAbilityId::RuleRestriction
            && let Some(ability) = self.leaf_static_ability()
        {
            return ability.is_active(game, source);
        }
        if let ironsmith_core::StaticAbilityPayload::Conditional { condition, .. } =
            &self.model.payload
        {
            let Some(object) = game.object(source) else {
                return false;
            };
            if !super::continuous::static_condition_is_active(
                condition,
                game,
                source,
                game.controller_of(object),
            ) {
                return false;
            }
        }
        if let Some(reduction) = &self.activated_ability_cost_reduction {
            return reduction.is_active(game, source);
        }
        if let Some(increase) = &self.activated_ability_cost_increase {
            return increase.is_active(game, source);
        }
        if let Some(reduction) = &self.cost_reduction {
            return reduction.is_active(game, source);
        }
        if let Some(reduction) = &self.cost_reduction_mana_cost {
            return reduction.is_active(game, source);
        }
        if let Some(increase) = &self.cost_increase {
            return increase.is_active(game, source);
        }
        if let Some(increase) = &self.cost_increase_mana_cost {
            return increase.is_active(game, source);
        }
        self.leaf_static_ability()
            .map(|ability| ability.is_active(game, source))
            .unwrap_or(true)
    }

    fn skips_upkeep_for_player(
        &self,
        game: &GameState,
        source: ObjectId,
        controller: PlayerId,
        player: PlayerId,
    ) -> bool {
        self.leaf_static_ability().is_some_and(|ability| {
            ability.skips_upkeep_for_player(game, source, controller, player)
        })
    }

    fn skips_draw_step_for_player(
        &self,
        game: &GameState,
        source: ObjectId,
        controller: PlayerId,
        player: PlayerId,
    ) -> bool {
        self.leaf_static_ability().is_some_and(|ability| {
            ability.skips_draw_step_for_player(game, source, controller, player)
        })
    }

    fn skips_untap_step_for_player(
        &self,
        game: &GameState,
        source: ObjectId,
        controller: PlayerId,
        player: PlayerId,
    ) -> bool {
        self.leaf_static_ability().is_some_and(|ability| {
            ability.skips_untap_step_for_player(game, source, controller, player)
        })
    }

    fn skips_extra_turn_for_player(
        &self,
        game: &GameState,
        source: ObjectId,
        controller: PlayerId,
        player: PlayerId,
    ) -> bool {
        self.leaf_static_ability().is_some_and(|ability| {
            ability.skips_extra_turn_for_player(game, source, controller, player)
        })
    }

    fn is_keyword(&self) -> bool {
        matches!(self.payload(), ironsmith_core::StaticAbilityPayload::CustomKeywordIdentity { .. })
            || Self::is_simple_keyword_id(self.id())
    }

    fn grants_evasion(&self) -> bool {
        matches!(
            self.id(),
            StaticAbilityId::Flying
                | StaticAbilityId::Shadow
                | StaticAbilityId::Horsemanship
                | StaticAbilityId::Fear
                | StaticAbilityId::Intimidate
                | StaticAbilityId::Skulk
                | StaticAbilityId::Landwalk
                | StaticAbilityId::Unblockable
        )
    }

    fn is_unblockable(&self) -> bool {
        self.id() == StaticAbilityId::Unblockable
    }

    fn landwalk_kind(&self) -> Option<crate::static_abilities::LandwalkKind> {
        match self.payload() {
            ironsmith_core::StaticAbilityPayload::Landwalk(kind) => {
                Some(Self::core_landwalk_to_runtime(*kind))
            }
            _ => None,
        }
    }

    fn additional_blockable_attackers_for_source(
        &self,
        game: &GameState,
        source: ObjectId,
    ) -> Option<usize> {
        self.leaf_static_ability()
            .and_then(|ability| ability.additional_blockable_attackers_for_source(game, source))
            .or_else(|| self.additional_blockable_attackers())
    }

    fn additional_blockable_attackers(&self) -> Option<usize> {
        match self.payload() {
            ironsmith_core::StaticAbilityPayload::CanBlockAdditionalCreatureEachCombat(count) => {
                Some(*count)
            }
            _ => None,
        }
    }

    fn cant_be_blocked_by_power_or_less(&self) -> Option<i32> {
        self.leaf_static_ability()?
            .blocked_by_power_or_less_threshold()
    }

    fn cant_be_blocked_by_power_or_greater(&self) -> Option<i32> {
        self.leaf_static_ability()?
            .blocked_by_power_or_greater_threshold()
    }

    fn can_block_as_though_reach_subtype(&self) -> Option<crate::types::Subtype> {
        match self.payload() {
            ironsmith_core::StaticAbilityPayload::CanBlockAsThoughReachForSubtype(subtype) => {
                Some(*subtype)
            }
            _ => self
                .leaf_static_ability()
                .and_then(|ability| ability.can_block_as_though_reach_subtype()),
        }
    }

    fn blocks_as_though_no_shadow(&self) -> bool {
        match self.payload() {
            ironsmith_core::StaticAbilityPayload::CanBlockAsThoughNoShadow => true,
            _ => self
                .leaf_static_ability()
                .is_some_and(|ability| ability.blocks_as_though_no_shadow()),
        }
    }

    fn has_first_strike(&self) -> bool {
        matches!(
            self.id(),
            StaticAbilityId::FirstStrike | StaticAbilityId::DoubleStrike
        )
    }

    fn has_double_strike(&self) -> bool {
        self.id() == StaticAbilityId::DoubleStrike
    }

    fn has_deathtouch(&self) -> bool {
        self.id() == StaticAbilityId::Deathtouch
    }

    fn has_lifelink(&self) -> bool {
        self.id() == StaticAbilityId::Lifelink
    }

    fn has_trample(&self) -> bool {
        self.id() == StaticAbilityId::Trample
    }

    fn has_vigilance(&self) -> bool {
        self.id() == StaticAbilityId::Vigilance
    }

    fn has_haste(&self) -> bool {
        self.id() == StaticAbilityId::Haste
    }

    fn has_flash(&self) -> bool {
        self.id() == StaticAbilityId::Flash
            && !matches!(
                self.payload(),
                ironsmith_core::StaticAbilityPayload::Conditional { .. }
                    | ironsmith_core::StaticAbilityPayload::FlashIfTargetsMatching(_)
                    | ironsmith_core::StaticAbilityPayload::FlashIfCastChoice(_)
            )
    }

    fn conditional_flash_condition(&self) -> Option<&ironsmith_core::Condition> {
        match self.payload() {
            ironsmith_core::StaticAbilityPayload::Conditional { ability, condition, .. }
                if ability.id == Some(StaticAbilityId::Flash) =>
            {
                Some(condition)
            }
            _ => None,
        }
    }

    fn defined_face_down_ward(&self) -> Option<bool> { self.leaf_static_ability()?.defined_face_down_ward() }
    fn turn_face_up_adds_counter(&self) -> bool { self.leaf_static_ability().is_some_and(|a| a.turn_face_up_adds_counter()) }

    fn turn_face_up_cost(&self) -> Option<&crate::cost::TotalCost> {
        self.leaf_static_ability()?.turn_face_up_cost()
    }

    fn is_megamorph(&self) -> bool {
        self.leaf_static_ability()
            .is_some_and(|ability| ability.is_megamorph())
    }

    fn is_disguise(&self) -> bool {
        self.leaf_static_ability()
            .is_some_and(|ability| ability.is_disguise())
    }

    fn forbids_paying_life_for_cast_or_activate(&self) -> bool {
        self.leaf_static_ability()
            .is_some_and(|ability| ability.forbids_paying_life_for_cast_or_activate())
    }

    fn forbids_sacrificing_nonland_for_cast_or_activate(&self) -> bool {
        self.leaf_static_ability()
            .is_some_and(|ability| ability.forbids_sacrificing_nonland_for_cast_or_activate())
    }

    fn optional_attack_cost_prompt(
        &self,
        game: &GameState,
        source: ObjectId,
        controller: PlayerId,
        attacking_creatures: &[ObjectId],
    ) -> Option<crate::decisions::context::DecisionContext> {
        self.leaf_static_ability()?.optional_attack_cost_prompt(
            game,
            source,
            controller,
            attacking_creatures,
        )
    }

    fn pay_optional_attack_cost(
        &self,
        game: &mut GameState,
        source: ObjectId,
        controller: PlayerId,
        attacking_creatures: &[ObjectId],
        trigger_queue: &mut crate::triggers::TriggerQueue,
        decision_maker: &mut dyn crate::decision::DecisionMaker,
    ) -> Option<Result<(), String>> {
        self.leaf_static_ability()?.pay_optional_attack_cost(
            game,
            source,
            controller,
            attacking_creatures,
            trigger_queue,
            decision_maker,
        )
    }

    fn block_cost_for_declaration(
        &self,
        game: &GameState,
        ability_source: ObjectId,
        ability_controller: PlayerId,
        blocker: ObjectId,
        attacker: ObjectId,
    ) -> Option<crate::cost::TotalCost> {
        self.leaf_static_ability()?.block_cost_for_declaration(
            game,
            ability_source,
            ability_controller,
            blocker,
            attacker,
        )
    }

    fn attack_cost_for_declaration(
        &self,
        game: &GameState,
        source: ObjectId,
        controller: PlayerId,
        attacker: ObjectId,
        target: super::AttackTaxTargetKind,
    ) -> Option<crate::cost::TotalCost> {
        self.leaf_static_ability()?
            .attack_cost_for_declaration(game, source, controller, attacker, target)
    }
    fn self_attack_cost_for_declaration(
        &self,
        game: &GameState,
        source: ObjectId,
        controller: PlayerId,
        attacker: ObjectId,
    ) -> Option<crate::cost::TotalCost> {
        self.leaf_static_ability()?
            .self_attack_cost_for_declaration(game, source, controller, attacker)
    }
    fn attack_cost_model(&self) -> Option<&super::AttackCost> {
        self.leaf_static_ability()?.attack_cost_model()
    }

    fn block_cost_model(&self) -> Option<&super::BlockCost> {
        self.leaf_static_ability()?.block_cost_model()
    }

    fn has_reach(&self) -> bool {
        self.id() == StaticAbilityId::Reach
    }

    fn has_defender(&self) -> bool {
        self.id() == StaticAbilityId::Defender
    }

    fn has_indestructible(&self) -> bool {
        self.id() == StaticAbilityId::Indestructible
    }

    fn has_hexproof(&self) -> bool {
        self.id() == StaticAbilityId::Hexproof
    }

    fn hexproof_from_filter(&self) -> Option<&crate::target::ObjectFilter> {
        match self.payload() {
            ironsmith_core::StaticAbilityPayload::HexproofFrom(filter) => Some(filter),
            _ => self.leaf_static_ability()?.hexproof_from_filter(),
        }
    }

    fn goads_matching(&self) -> Option<&crate::target::ObjectFilter> {
        match self.payload() {
            ironsmith_core::StaticAbilityPayload::GoadMatching { filter } => Some(filter),
            _ => self.leaf_static_ability()?.goads_matching(),
        }
    }

    fn conditional_attack_requirement(
        &self,
    ) -> Option<(&crate::target::ObjectFilter, &crate::target::ObjectFilter)> {
        match self.payload() {
            ironsmith_core::StaticAbilityPayload::ConditionalAttackRequirement {
                trigger,
                required,
            } => Some((trigger, required)),
            _ => self.leaf_static_ability()?.conditional_attack_requirement(),
        }
    }

    fn legend_rule_exemption_filter(&self) -> Option<&crate::target::ObjectFilter> {
        match self.payload() {
            ironsmith_core::StaticAbilityPayload::LegendRuleDoesntApplyToController { filter } => {
                Some(filter)
            }
            _ => self.leaf_static_ability()?.legend_rule_exemption_filter(),
        }
    }

    fn has_shroud(&self) -> bool {
        self.id() == StaticAbilityId::Shroud
    }

    fn is_changeling(&self) -> bool {
        self.id() == StaticAbilityId::Changeling
    }

    fn has_menace(&self) -> bool {
        self.id() == StaticAbilityId::Menace
    }

    fn minimum_blockers(&self) -> Option<usize> {
        match self.payload() {
            ironsmith_core::StaticAbilityPayload::CantBeBlockedExceptByNOrMore(count) => {
                Some(*count)
            }
            _ if self.id() == StaticAbilityId::Menace => Some(2),
            _ => None,
        }
    }

    fn maximum_blockers(&self) -> Option<usize> {
        match self.payload() {
            ironsmith_core::StaticAbilityPayload::CantBeBlockedByMoreThan(count) => Some(*count),
            _ => None,
        }
    }

    fn counter_limit(&self) -> Option<(crate::object::CounterType, u32)> {
        match self.payload() {
            ironsmith_core::StaticAbilityPayload::CounterLimit {
                counter_type,
                maximum,
                ..
            } => Some((*counter_type, *maximum)),
            _ => self.leaf_static_ability()?.counter_limit(),
        }
    }

    fn has_flying(&self) -> bool {
        self.id() == StaticAbilityId::Flying
    }

    fn has_protection(&self) -> bool {
        matches!(
            self.payload(),
            ironsmith_core::StaticAbilityPayload::Protection(_)
        )
    }

    fn protection_from(&self) -> Option<&crate::ability::ProtectionFrom> {
        match self.payload() {
            ironsmith_core::StaticAbilityPayload::Protection(from) => Some(from),
            _ => None,
        }
    }

    fn ward_cost(&self) -> Option<&crate::cost::TotalCost> {
        match self.payload() {
            ironsmith_core::StaticAbilityPayload::Ward(cost) => Some(cost),
            _ => None,
        }
    }

    fn granted_inline_ability(&self) -> Option<&crate::ability::Ability> {
        self.granted_inline_ability.as_ref()
    }

    fn granted_inline_condition(&self) -> Option<&crate::ConditionExpr> {
        self.granted_inline_condition.as_ref()
    }

    fn source_granted_inline_abilities(&self) -> Vec<&crate::ability::Ability> {
        self.source_granted_inline_abilities.iter().collect()
    }

    fn enter_as_copy_as_enters(&self) -> Option<&super::EnterAsCopyAsEntersSpec> {
        self.enter_as_copy_spec.as_ref()
    }

    fn minimum_total_spell_mana(&self) -> Option<u32> {
        match self.payload() {
            ironsmith_core::StaticAbilityPayload::MinimumSpellTotalMana(amount) => Some(*amount),
            _ => None,
        }
    }

    fn foretell_special_action_modifier(&self) -> Option<(u32, bool)> {
        match self.payload() {
            ironsmith_core::StaticAbilityPayload::ForetellSpecialActionModifier {
                generic_reduction,
                any_players_turn,
                plot: false,
                ..
            } => Some((*generic_reduction, *any_players_turn)),
            _ => None,
        }
    }

    fn plot_special_action_reduction(&self) -> Option<u32> {
        match self.payload() {
            ironsmith_core::StaticAbilityPayload::ForetellSpecialActionModifier {
                generic_reduction,
                plot: true,
                ..
            } => Some(*generic_reduction),
            _ => None,
        }
    }

    fn foretell_special_action_first_each_turn(&self) -> bool {
        matches!(
            self.payload(),
            ironsmith_core::StaticAbilityPayload::ForetellSpecialActionModifier {
                first_each_turn: true,
                ..
            }
        )
    }

    fn buyback_cost_reduction_amount(&self) -> Option<u32> {
        match self.payload() {
            ironsmith_core::StaticAbilityPayload::BuybackCostReduction(amount) => Some(*amount),
            _ => None,
        }
    }

    fn color_choice_as_enters(&self) -> Option<super::ChooseColorAsEntersSpec> {
        let ironsmith_core::StaticAbilityPayload::ChooseColorAsEnters {
            excluded, count, ..
        } = self.payload()
        else {
            return None;
        };
        Some(super::ChooseColorAsEntersSpec {
            excluded: *excluded,
            count: (*count).max(1),
        })
    }

    fn player_choice_as_enters(&self) -> Option<super::ChoosePlayerAsEntersSpec> {
        let ironsmith_core::StaticAbilityPayload::ChoosePlayerAsEnters { filter, count, .. } =
            self.payload()
        else {
            return None;
        };
        Some(super::ChoosePlayerAsEntersSpec {
            filter: filter.clone(),
            count: (*count).max(1),
        })
    }

    fn reveal_from_hand_as_enters(&self) -> Option<super::RevealFromHandAsEntersSpec> {
        let ironsmith_core::StaticAbilityPayload::RevealFromHandAsEnters {
            filter,
            count,
            optional,
            ..
        } = self.payload()
        else {
            return None;
        };
        Some(super::RevealFromHandAsEntersSpec {
            filter: filter.clone(),
            count: *count,
            optional: *optional,
        })
    }

    fn card_name_choice_as_enters(&self) -> Option<super::ChooseCardNameAsEntersSpec> {
        let ironsmith_core::StaticAbilityPayload::ChooseCardNameAsEnters {
            reveal_opponents_hands,
            require_nonland_from_revealed_opponents,
            opponent_also_chooses,
            exclude_basic_land_names,
            ..
        } = self.payload()
        else {
            return None;
        };
        Some(super::ChooseCardNameAsEntersSpec {
            reveal_opponents_hands: *reveal_opponents_hands,
            require_nonland_from_revealed_opponents: *require_nonland_from_revealed_opponents,
            opponent_also_chooses: *opponent_also_chooses,
            exclude_basic_land_names: *exclude_basic_land_names,
        })
    }

    fn basic_land_type_choice_as_enters(&self) -> Option<super::ChooseBasicLandTypeAsEntersSpec> {
        matches!(
            self.payload(),
            ironsmith_core::StaticAbilityPayload::ChooseBasicLandTypeAsEnters(_)
                | ironsmith_core::StaticAbilityPayload::ChooseBasicLandTypesAsEnters { .. }
        )
        .then_some(super::ChooseBasicLandTypeAsEntersSpec)
    }

    fn basic_land_type_choice_count_as_enters(&self) -> u32 {
        match self.payload() {
            ironsmith_core::StaticAbilityPayload::ChooseBasicLandTypeAsEnters(_) => 1,
            ironsmith_core::StaticAbilityPayload::ChooseBasicLandTypesAsEnters { count, .. } => {
                *count
            }
            _ => 0,
        }
    }

    fn land_type_choice_as_enters(&self) -> Option<super::ChooseLandTypeAsEntersSpec> {
        matches!(
            self.payload(),
            ironsmith_core::StaticAbilityPayload::ChooseLandTypeAsEnters(_)
        )
        .then_some(super::ChooseLandTypeAsEntersSpec)
    }

    fn creature_type_choice_as_enters(&self) -> Option<super::ChooseCreatureTypeAsEntersSpec> {
        matches!(
            self.payload(),
            ironsmith_core::StaticAbilityPayload::ChooseCreatureTypeAsEnters(_)
        )
        .then_some(super::ChooseCreatureTypeAsEntersSpec)
    }

    fn named_option_choice_as_enters(&self) -> Option<super::ChooseNamedOptionAsEntersSpec> {
        match self.payload() {
            ironsmith_core::StaticAbilityPayload::ChooseNamedOptionAsEnters {
                options,
                at_random,
                each_player,
                ..
            } => Some(super::ChooseNamedOptionAsEntersSpec {
                options: options.clone(),
                at_random: *at_random,
                each_player: *each_player,
            }),
            _ => None,
        }
    }

    fn power_toughness_choice_as_enters_or_turns_face_up(
        &self,
    ) -> Option<super::ChoosePowerToughnessAsEntersOrTurnsFaceUpSpec> {
        if let Some(ability) = self.leaf_static_ability() {
            return ability.power_toughness_choice_as_enters_or_turns_face_up();
        }
        match self.payload() {
            ironsmith_core::StaticAbilityPayload::ChoosePowerToughnessAsEntersOrTurnsFaceUp {
                options,
                at_random,
                ..
            } => Some(super::ChoosePowerToughnessAsEntersOrTurnsFaceUpSpec {
                at_random: *at_random,
                options: options
                    .iter()
                    .map(|option| {
                        super::PowerToughnessChoiceOption {
                            power: option.power,
                            toughness: option.toughness,
                            card_types: option.card_types.clone(),
                            added_subtypes: option.added_subtypes.clone(),
                            abilities: option.abilities.iter().cloned().map(StaticAbility::from_model).collect(),
                        }
                    })
                    .collect(),
            }),
            _ => None,
        }
    }

    fn pregame_action_kind(&self) -> Option<super::PregameActionKind> {
        match self.payload() {
            ironsmith_core::StaticAbilityPayload::PregameAction { kind, .. } => Some(kind.clone()),
            _ => None,
        }
    }

    fn pregame_action_effects(&self) -> Option<&[crate::effect::Effect]> {
        match self.payload() {
            ironsmith_core::StaticAbilityPayload::PregameAction { effects, .. } => Some(effects),
            _ => None,
        }
    }

    fn companion_deck_condition(&self) -> Option<&super::CompanionDeckCondition> {
        match self.payload() {
            ironsmith_core::StaticAbilityPayload::Companion(condition) => Some(condition),
            _ => None,
        }
    }

    fn reveal_drawn_card_spec(&self) -> Option<super::RevealDrawnCardSpec> {
        match self.payload() {
            ironsmith_core::StaticAbilityPayload::RevealCardsDrawn { player } => Some(super::RevealDrawnCardSpec {
                player: Some(player.clone()), card_number: 0, optional: false, your_turns_only: false, linked_reveal_pair: None,
            }),
            ironsmith_core::StaticAbilityPayload::RevealFirstCardYouDrawEachTurn {
                optional,
                your_turns_only,
                linked_reveal_pair,
            } => Some(super::RevealDrawnCardSpec {
                player: None,
                card_number: 1,
                optional: *optional,
                your_turns_only: *your_turns_only,
                linked_reveal_pair: *linked_reveal_pair,
            }),
            _ => None,
        }
    }

    fn count_as_card_named_for_spell_effect_spec(
        &self,
    ) -> Option<super::CountAsCardNamedForSpellEffectSpec> {
        match self.payload() {
            ironsmith_core::StaticAbilityPayload::CountAsCardNamedForSpellEffect {
                spell_name,
                counted_name,
            } => Some(super::CountAsCardNamedForSpellEffectSpec {
                spell_name: spell_name.clone(),
                counted_name: counted_name.clone(),
            }),
            _ => None,
        }
    }

    fn die_roll_result_adjustment_spec(&self) -> Option<super::DieRollResultAdjustmentSpec> {
        match self.payload() {
            ironsmith_core::StaticAbilityPayload::DieRollResultAdjustment(spec) => {
                Some(super::DieRollResultAdjustmentSpec {
                    player: spec.player.clone(),
                    life_cost: spec.life_cost,
                    mana_cost: spec.mana_cost.clone(),
                    amount: spec.amount,
                    reroll: spec.reroll,
                    once_each_turn: spec.once_each_turn,
                    source_counter_cost: spec.source_counter_cost,
                    exchange_with_source_base_pt: spec.exchange_with_source_base_pt,
                    sides: spec.sides,
                })
            }
            _ => None,
        }
    }

    fn cost_increase_per_additional_target(&self) -> Option<u32> {
        match self.payload() {
            ironsmith_core::StaticAbilityPayload::CostIncreasePerTargetBeyondFirst(amount) => {
                Some(*amount)
            }
            _ => None,
        }
    }

    fn cost_increase_mana_cost_per_additional_target(&self) -> Option<&crate::mana::ManaCost> {
        self.cost_increase_mana_cost_per_additional_target
            .as_ref()
            .map(|increase| &increase.cost)
    }

    fn additional_life_cost_per_target(&self) -> Option<u32> {
        match self.payload() {
            ironsmith_core::StaticAbilityPayload::AdditionalLifeCostPerTarget(amount) => {
                Some(*amount)
            }
            _ => None,
        }
    }

    fn is_anthem(&self) -> bool {
        matches!(
            self.payload(),
            ironsmith_core::StaticAbilityPayload::Anthem(_)
        )
    }

    fn anthem_payload(&self) -> Option<&ironsmith_core::Anthem> {
        match self.payload() {
            ironsmith_core::StaticAbilityPayload::Anthem(anthem) => Some(anthem),
            _ => None,
        }
    }

    fn grants_abilities(&self) -> bool {
        matches!(
            self.payload(),
            ironsmith_core::StaticAbilityPayload::GrantObjectAbilityForFilter(_)
                | ironsmith_core::StaticAbilityPayload::AttachedAbilityGrant(_)
        )
    }

    fn color_choice_as_becomes_attached(&self) -> Option<super::ChooseColorAsBecomesAttachedSpec> {
        matches!(
            self.model.id,
            Some(StaticAbilityId::ChooseColorAsBecomesAttached)
        )
        .then_some(super::ChooseColorAsBecomesAttachedSpec)
    }

    fn creature_card_name_and_type_choice_as_becomes_attached(&self) -> bool {
        self.model.id == Some(StaticAbilityId::ChooseCreatureCardNameAndTypeAsBecomesAttached)
    }

    fn craft_material_choice_as_becomes_attached(&self) -> bool {
        self.model.id == Some(StaticAbilityId::ChooseCraftMaterialAsBecomesAttached)
    }

    fn modifies_costs(&self) -> bool {
        self.cost_reduction.is_some()
            || self.activated_ability_cost_reduction.is_some()
            || self.activated_ability_cost_increase.is_some()
            || self.cost_increase.is_some()
            || self.cost_reduction_mana_cost.is_some()
            || self.cost_increase_mana_cost.is_some()
            || self.cost_increase_mana_cost_per_additional_target.is_some()
            || self.this_spell_cost_reduction.is_some()
            || self.this_spell_cost_reduction_mana_cost.is_some()
            || self.cost_increase_per_additional_target().is_some()
            || self.additional_life_cost_per_target().is_some()
            || self.minimum_total_spell_mana().is_some()
            || self.buyback_cost_reduction_amount().is_some()
            || self.foretell_special_action_modifier().is_some()
            || self.plot_special_action_reduction().is_some()
    }

    fn this_spell_cost_reduction(&self) -> Option<&super::ThisSpellCostReduction> {
        self.this_spell_cost_reduction.as_ref()
    }

    fn this_spell_cost_reduction_mana_cost(
        &self,
    ) -> Option<&super::ThisSpellCostReductionManaCost> {
        self.this_spell_cost_reduction_mana_cost.as_ref()
    }

    fn cost_reduction(&self) -> Option<&super::CostReduction> {
        self.cost_reduction.as_ref()
    }

    fn activated_ability_cost_reduction(&self) -> Option<&super::ActivatedAbilityCostReduction> {
        self.activated_ability_cost_reduction.as_ref()
    }

    fn activated_ability_cost_increase(&self) -> Option<&super::ActivatedAbilityCostIncrease> {
        self.activated_ability_cost_increase.as_ref()
    }

    fn cost_increase(&self) -> Option<&super::CostIncrease> {
        self.cost_increase.as_ref()
    }

    fn cost_increase_life(&self) -> Option<&super::CostIncreaseLife> {
        self.cost_increase_life.as_ref()
    }

    fn activate_abilities_as_though_haste(&self) -> Option<&super::ActivateAbilitiesAsThoughHaste> {
        self.activate_abilities_as_though_haste.as_ref()
    }

    fn cost_reduction_mana_cost(&self) -> Option<&super::CostReductionManaCost> {
        self.cost_reduction_mana_cost.as_ref()
    }

    fn cost_increase_mana_cost(&self) -> Option<&super::CostIncreaseManaCost> {
        self.cost_increase_mana_cost.as_ref()
    }

    fn level_abilities(&self) -> Option<&[crate::ability::LevelAbility]> {
        self.level_abilities.as_deref()
    }

    fn equipment_grant_abilities(&self) -> Option<&[StaticAbility]> {
        self.equipment_grant_abilities.as_deref()
    }

    fn grant_spec(&self) -> Option<crate::grant::GrantSpec> {
        self.grant_spec.clone()
    }

    fn conditional_spell_keyword_spec(&self) -> Option<super::ConditionalSpellKeywordSpec> {
        self.leaf_static_ability()?.conditional_spell_keyword_spec()
    }

    fn splice_spec(&self) -> Option<&super::SpliceSpec<crate::costs::Cost>> {
        self.leaf_static_ability()?.splice_spec()
    }

    fn escalate_spec(&self) -> Option<&super::EscalateSpec<crate::costs::Cost>> {
        self.leaf_static_ability()?.escalate_spec()
    }

    fn trigger_duplication_spec(&self) -> Option<super::TriggerDuplicationSpec> {
        self.leaf_static_ability()?.trigger_duplication_spec()
    }

    fn trigger_suppression_spec(&self) -> Option<super::TriggerSuppressionSpec> {
        self.leaf_static_ability()?.trigger_suppression_spec()
    }

    fn this_spell_cast_restriction_kind(&self) -> Option<super::ThisSpellCastRestrictionKind> {
        self.leaf_static_ability()?
            .this_spell_cast_restriction_kind()
    }

    fn this_spell_x_maximum_value(&self) -> Option<crate::effect::Value> {
        self.leaf_static_ability()?.this_spell_x_maximum_value()
    }

    fn this_spell_x_definition_value(&self) -> Option<crate::effect::Value> {
        match &self.model.payload {
            ironsmith_core::StaticAbilityPayload::ThisSpellXMaximum { definition, .. } => definition.clone(),
            _ => None,
        }
    }

    fn this_spell_x_minimum_value(&self) -> Option<crate::effect::Value> {
        self.leaf_static_ability()?.this_spell_x_minimum_value()
    }

    fn generic_attack_tax_per_attacker_against_you(
        &self,
        game: &GameState,
        source: ObjectId,
        controller: PlayerId,
    ) -> Option<u32> {
        self.leaf_static_ability()?
            .generic_attack_tax_per_attacker_against_you(game, source, controller)
    }

    fn generic_attack_tax_applies_to(&self, target: super::AttackTaxTargetKind) -> bool {
        self.leaf_static_ability()
            .is_some_and(|ability| ability.generic_attack_tax_applies_to(target))
    }

    fn enters_tapped(&self) -> bool {
        matches!(
            self.payload(),
            ironsmith_core::StaticAbilityPayload::PayLifeOrEnterTapped(_)
                | ironsmith_core::StaticAbilityPayload::RevealCardOrEnterTapped { .. }
                | ironsmith_core::StaticAbilityPayload::EntersTappedForFilter(_)
        )
    }

    fn is_devoid(&self) -> bool {
        match self.payload() {
            ironsmith_core::StaticAbilityPayload::MakeColorless(filter) => {
                filter == &crate::target::ObjectFilter::source()
            }
            _ => false,
        }
    }

    fn has_affinity(&self) -> bool {
        matches!(
            self.id(),
            StaticAbilityId::Affinity | StaticAbilityId::AffinityForArtifacts
        )
    }

    fn has_delve(&self) -> bool {
        self.id() == StaticAbilityId::Delve
            || self.leaf_static_ability().is_some_and(|ability| ability.has_delve())
    }

    fn has_convoke(&self) -> bool {
        self.id() == StaticAbilityId::Convoke
            || self.leaf_static_ability().is_some_and(|ability| ability.has_convoke())
    }

    fn has_improvise(&self) -> bool {
        self.id() == StaticAbilityId::Improvise
            || self.leaf_static_ability().is_some_and(|ability| ability.has_improvise())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn conditional_model_preserves_leaf_card_name_subject_preference() {
        let named_value = crate::effect::Value::Fixed(3)
            .with_surface_hint(ironsmith_core::ValueSurfaceHint::SourceNameSubject);
        let modeled =
            CompiledStaticAbility::characteristic_defining_pt(named_value.clone(), named_value)
                .with_condition(ironsmith_core::Condition::YourTurn);
        let ability = StaticAbility::from_model(modeled);

        assert!(ability.prefers_card_name_subject());
    }

    #[test]
    fn modeled_vote_modifiers_delegate_leaf_runtime_behavior() {
        let optional =
            StaticAbility::from_model(CompiledStaticAbility::vote_additional_time_while_voting());
        assert_eq!(optional.optional_additional_votes_while_voting(), 1);
        assert_eq!(optional.additional_votes_while_voting(), 0);

        let mandatory =
            StaticAbility::from_model(CompiledStaticAbility::vote_additional_vote_while_voting());
        assert_eq!(mandatory.additional_votes_while_voting(), 1);
        assert_eq!(mandatory.optional_additional_votes_while_voting(), 0);
    }
}

#[cfg(test)]
#[path = "model_interpreter_integration_tests.rs"]
mod integration_tests;
