//! Special actions in MTG that don't use the stack.
//!
//! Special actions include playing lands, turning face-down creatures face up,
//! suspending/foretelling cards, and activating mana abilities.

mod payment;
mod intrinsic_action;
pub use intrinsic_action::{intrinsic_action_cost_display, intrinsic_action_label};
mod face_down_cast;
pub(crate) use face_down_cast::register_face_down_exile_cast_action;
pub(crate) use payment::pay_resolution_cost_with_outputs;
use payment::{
    SpecialActionPayment, check_special_action_payment, pay_special_action_payment_with_x,
    special_action_payment_max_x,
};

use crate::ability::ActivatedAbilityRuntimeExt as _;
use crate::cost::CostPaymentError;
use crate::costs::{CostContext, CostPaymentResult};
use crate::decision::DecisionMaker;
use crate::decisions::make_decision;
use crate::decisions::specs::ChooseObjectsSpec;
use crate::decisions::{DisplayOption, specs::ChoiceSpec};
use crate::effects::ExecutionContext;
use crate::events::cause::EventCause;
use crate::events::other::KeywordActionEvent;
use crate::events::permanents::SacrificeEvent;
use crate::events::processing::EventOutcome;
use crate::filter::ObjectFilterExt as _;
use crate::filter::{FilterContext, ObjectFilter};
use crate::game_state::{GameState, Phase, Step};
use crate::ids::{ObjectId, PlayerId};
use crate::mana::{ManaCost, ManaSymbol};
use crate::snapshot::ObjectSnapshot;
use crate::triggers::TriggerEvent;
use crate::types::CardType;
use crate::zone::Zone;

#[derive(Debug, Clone, PartialEq)]
struct TurnFaceUpSpec {
    method: TurnFaceUpMethod,
    cost: crate::cost::TotalCost,
    description: &'static str,
    megamorph: bool,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum TurnFaceUpMethod {
    TurnFaceUpAbility,
    DisguiseAbility,
    MegamorphAbility,
    PrintedManaCost,
    DefinedAbility,
}

impl TurnFaceUpMethod {
    pub(crate) fn payment_reason(self) -> crate::costs::PaymentReason {
        use ironsmith_core::ManaTurnFaceUpMethod as Method;
        if self == Self::DefinedAbility { return crate::costs::PaymentReason::TurnFaceUp; }
        crate::costs::PaymentReason::TurnFaceUpWithMethod(match self {
            Self::TurnFaceUpAbility => Method::Morph,
            Self::MegamorphAbility => Method::Megamorph,
            Self::DisguiseAbility => Method::Disguise,
            Self::PrintedManaCost => Method::PrintedManaCost,
            Self::DefinedAbility => unreachable!(),
        })
    }

    pub fn description(self) -> &'static str {
        match self {
            Self::TurnFaceUpAbility => "turn-face-up cost",
            Self::DisguiseAbility => "disguise cost",
            Self::MegamorphAbility => "megamorph cost",
            Self::PrintedManaCost => "mana cost",
            Self::DefinedAbility => "defined turn-face-up cost",
        }
    }
}

fn turn_face_up_specs(
    game: &GameState,
    object: &crate::object::Object,
) -> Result<Vec<TurnFaceUpSpec>, crate::static_ability_processor::StaticEffectDiscoveryError> {
    let mut specs = Vec::new();
    // CR 702.37e asks what the morph cost would be if this permanent were
    // face up. Apply all layers to that hypothetical object, including
    // ability removal/grants and copy effects, rather than reading printed
    // abilities from the face-down restore record.
    if let Some(face_up) = game.hypothetical_face_up(object.id)?
        && let Some(characteristics) = face_up.calculated_characteristics(object.id)
    {
        append_turn_face_up_specs_from_abilities(&mut specs, &characteristics.abilities);
    }

    if game.has_printed_cost_turn_face_up_permission(object.id)
        && let Some(restore) = object.face_down_cast_state.as_ref()
        && restore.card_types.contains(&CardType::Creature)
        && let Some(cost) = restore.mana_cost.as_ref().map(|cost| cost.to_owned_value())
    {
        specs.push(TurnFaceUpSpec {
            method: TurnFaceUpMethod::PrintedManaCost,
            cost: crate::cost::TotalCost::mana(cost),
            description: TurnFaceUpMethod::PrintedManaCost.description(),
            megamorph: false,
        });
    }

    Ok(specs)
}

fn append_turn_face_up_specs_from_abilities(
    specs: &mut Vec<TurnFaceUpSpec>,
    abilities: &[crate::ability::Ability],
) {
    for ability in abilities {
        if !ability.functions_in(&Zone::Battlefield) {
            continue;
        }
        let crate::ability::AbilityKind::Static(static_ability) = &ability.kind else {
            continue;
        };
        let Some(cost) = static_ability.turn_face_up_cost() else {
            continue;
        };
        let candidate = TurnFaceUpSpec {
            method: if static_ability.defined_face_down_ward().is_some() {
                TurnFaceUpMethod::DefinedAbility
            } else if static_ability.is_disguise() {
                TurnFaceUpMethod::DisguiseAbility
            } else if static_ability.is_megamorph() {
                TurnFaceUpMethod::MegamorphAbility
            } else {
                TurnFaceUpMethod::TurnFaceUpAbility
            },
            cost: cost.clone(),
            description: if static_ability.defined_face_down_ward().is_some() {
                TurnFaceUpMethod::DefinedAbility.description()
            } else if static_ability.is_disguise() {
                TurnFaceUpMethod::DisguiseAbility.description()
            } else if static_ability.is_megamorph() {
                TurnFaceUpMethod::MegamorphAbility.description()
            } else {
                TurnFaceUpMethod::TurnFaceUpAbility.description()
            },
            megamorph: static_ability.turn_face_up_adds_counter(),
        };
        specs.push(candidate);
    }
}

pub(crate) fn available_turn_face_up_methods(
    game: &GameState,
    permanent_id: ObjectId,
) -> Result<Vec<TurnFaceUpMethod>, crate::static_ability_processor::StaticEffectDiscoveryError> {
    let Some(object) = game.object(permanent_id) else {
        return Ok(Vec::new());
    };
    Ok(turn_face_up_specs(game, object)?
        .into_iter()
        .map(|spec| spec.method)
        .collect())
}

pub fn turn_face_up_cost_display(
    game: &GameState,
    permanent_id: ObjectId,
    method: TurnFaceUpMethod,
) -> Result<Option<String>, crate::static_ability_processor::StaticEffectDiscoveryError> {
    let checked = game.continuous_query_snapshot()?;
    let game = &checked;
    let Some(object) = game.object(permanent_id) else {
        return Ok(None);
    };
    let Some(spec) = turn_face_up_spec(game, object, method)? else {
        return Ok(None);
    };
    let controller = game.controller_of(object);
    Ok(Some(
        adjusted_turn_face_up_cost(game, controller, permanent_id, &spec).display(),
    ))
}

pub fn room_unlock_cost_display(
    game: &GameState,
    room_id: ObjectId,
    door: RoomDoor,
) -> Option<String> {
    let room = game.object(room_id)?;
    let controller = game.controller_of(room);
    adjusted_room_unlock_cost(game, controller, room_id, door)
        .ok()
        .map(|cost| cost.display())
}

/// Name of the half a door unlock applies to, for action labels.
pub fn room_door_name(game: &GameState, room_id: ObjectId, door: RoomDoor) -> Option<String> {
    match door {
        RoomDoor::Current => game.object(room_id).map(|room| room.name.to_string()),
        RoomDoor::Linked => room_locked_door_definition(game, room_id).map(|def| def.card.name),
    }
}

/// The doors of a Room that are currently locked.
pub fn locked_room_doors(game: &GameState, room_id: ObjectId) -> Vec<RoomDoor> {
    if !game.room_has_locked_door(room_id) {
        return Vec::new();
    }
    if game.room_has_no_unlocked_door(room_id) {
        vec![RoomDoor::Current, RoomDoor::Linked]
    } else {
        vec![RoomDoor::Linked]
    }
}

/// Oracle rendering of the mana cost paid to ignore a source-wide static
/// effect until end of turn, for the [`SpecialAction::IgnoreSourceEffect`] label.
pub fn ignore_source_effect_cost_display(
    game: &GameState,
    source_id: ObjectId,
    ability_index: usize,
) -> Option<String> {
    let ability = game.object(source_id)?.abilities.get(ability_index)?;
    let crate::ability::AbilityKind::Static(static_ability) = &ability.kind else {
        return None;
    };
    match &static_ability.compiled_model()?.payload {
        ironsmith_core::StaticAbilityPayload::AnyPlayerMayPayManaToIgnoreSourceEffectUntilEndOfTurn {
            cost,
            ..
        } => Some(cost.to_oracle()),
        ironsmith_core::StaticAbilityPayload::PlayerMaySacrificePermanentToIgnoreSourceEffectUntilEndOfTurn {
            ..
        } => Some("Sacrifice a permanent".to_string()),
        _ => None,
    }
}

fn room_locked_door_definition(
    game: &GameState,
    room_id: ObjectId,
) -> Option<crate::cards::CardDefinition> {
    let room = game.object(room_id)?;
    game.linked_face_definition_by_name_or_id(room.other_face_name.as_deref(), room.other_face)
}

fn room_unlock_cost(
    game: &GameState,
    room_id: ObjectId,
    door: RoomDoor,
) -> Option<crate::cost::TotalCost> {
    if !locked_room_doors(game, room_id).contains(&door) {
        return None;
    }
    // CR 709.5e: the unlock cost is the mana cost of the locked half.
    if door == RoomDoor::Current {
        return game
            .object(room_id)?
            .mana_cost
            .as_deref()
            .cloned()
            .map(crate::cost::TotalCost::mana);
    }
    let locked_door = room_locked_door_definition(game, room_id)?;
    locked_door.card.mana_cost.map(crate::cost::TotalCost::mana)
}

fn turn_face_up_spec(
    game: &GameState,
    object: &crate::object::Object,
    method: TurnFaceUpMethod,
) -> Result<Option<TurnFaceUpSpec>, crate::static_ability_processor::StaticEffectDiscoveryError> {
    Ok(turn_face_up_specs(game, object)?
        .into_iter()
        .find(|spec| spec.method == method))
}

/// Total generic increase from "All morph costs cost {N} more." statics
/// (Exiled Doomsayer) on the battlefield, regardless of controller.
fn morph_cost_increase(game: &GameState) -> u32 {
    let mut total = 0u32;
    for id in game.battlefield.iter().copied() {
        if game.is_phased_out(id) {
            continue;
        }
        let Some(characteristics) = game.current_characteristics(id) else {
            continue;
        };
        for ability in characteristics.static_abilities.iter() {
            if let Some(model) = ability.compiled_model()
                && let ironsmith_core::StaticAbilityPayload::MorphCostIncrease { generic_increase } =
                    &model.payload
            {
                total = total.saturating_add(*generic_increase);
            }
        }
    }
    total
}

/// Total generic reduction from "Unlock costs you pay cost {N} less."
/// statics (Inquisitive Glimmer) controlled by `player` (CR 709.5c).
fn unlock_cost_reduction(game: &GameState, player: PlayerId) -> u32 {
    let mut total = 0u32;
    for id in game.battlefield.iter().copied() {
        if game.is_phased_out(id) || game.controller_of_id(id) != Some(player) {
            continue;
        }
        let Some(characteristics) = game.current_characteristics(id) else {
            continue;
        };
        for ability in characteristics.static_abilities.iter() {
            if let Some(model) = ability.compiled_model()
                && let ironsmith_core::StaticAbilityPayload::UnlockCostReduction {
                    generic_reduction,
                } = &model.payload
            {
                total = total.saturating_add(*generic_reduction);
            }
        }
    }
    total
}

/// Removes up to `reduction` generic mana from the first mana component of a
/// special-action cost (each branch of a choice of costs separately).
fn reduce_total_cost_generic(
    total_cost: &crate::cost::TotalCost,
    reduction: u32,
) -> crate::cost::TotalCost {
    match total_cost.kind() {
        ironsmith_core::TotalCostKind::All(costs) => {
            let mut applied = false;
            crate::cost::TotalCost::from_costs(
                costs
                    .iter()
                    .map(|cost| match cost.mana_cost_ref() {
                        Some(mana_cost) if !applied => {
                            applied = true;
                            crate::costs::Cost::mana(mana_cost.reduce_generic(reduction))
                        }
                        _ => cost.clone(),
                    })
                    .collect(),
            )
        }
        ironsmith_core::TotalCostKind::OneOf(branches) => crate::cost::TotalCost::one_of(
            branches
                .iter()
                .map(|branch| reduce_total_cost_generic(branch, reduction))
                .collect(),
        ),
    }
}

/// Adds `increase` generic mana to a turn-face-up cost: to its mana
/// component when it has one, otherwise as an extra mana component
/// (a non-mana morph cost still costs {N} more).
fn increase_total_cost_generic(
    total_cost: &crate::cost::TotalCost,
    increase: u32,
) -> crate::cost::TotalCost {
    match total_cost.kind() {
        ironsmith_core::TotalCostKind::All(costs) => {
            let mut applied = false;
            let mut adjusted: Vec<crate::costs::Cost> = costs
                .iter()
                .map(|cost| match cost.mana_cost_ref() {
                    Some(mana_cost) if !applied => {
                        applied = true;
                        crate::costs::Cost::mana(mana_cost.add_generic(increase))
                    }
                    _ => cost.clone(),
                })
                .collect();
            if !applied {
                adjusted.push(crate::costs::Cost::mana(
                    crate::mana::ManaCost::from_symbols(Vec::new()).add_generic(increase),
                ));
            }
            crate::cost::TotalCost::from_costs(adjusted)
        }
        ironsmith_core::TotalCostKind::OneOf(branches) => crate::cost::TotalCost::one_of(
            branches
                .iter()
                .map(|branch| increase_total_cost_generic(branch, increase))
                .collect(),
        ),
    }
}

fn adjusted_turn_face_up_cost(
    game: &GameState,
    player: PlayerId,
    permanent_id: ObjectId,
    spec: &TurnFaceUpSpec,
) -> crate::cost::TotalCost {
    let morph_increase = if matches!(
        spec.method,
        TurnFaceUpMethod::TurnFaceUpAbility | TurnFaceUpMethod::MegamorphAbility
    ) {
        morph_cost_increase(game)
    } else {
        0
    };
    let increased;
    let base_cost = if morph_increase > 0 {
        increased = increase_total_cost_generic(&spec.cost, morph_increase);
        &increased
    } else {
        &spec.cost
    };
    // Turning a permanent face up is a special action (CR 116.2b, 702.168d):
    // the permanent's own "this spell costs less" statics don't apply to its
    // disguise/morph cost — only effects that modify that action's cost do.
    adjust_total_cost_mana_components_for_reason(
        game,
        player,
        permanent_id,
        base_cost,
        spec.method.payment_reason(),
    )
}

fn foretell_cost(object: &crate::object::Object) -> Option<crate::mana::ManaCost> {
    object
        .alternative_casts
        .iter()
        .find_map(|method| match method {
            crate::alternative_cast::AlternativeCastingMethod::Foretell { cost } => {
                Some(cost.clone())
            }
            method if method.prepares_face_down() => method.mana_cost().cloned(),
            _ => None,
        })
}

/// A foretell cost granted to a card in `player`'s hand ("Each nonland card
/// in your hand without foretell has foretell. Its foretell cost is ...",
/// Dream Devourer), when the card has none of its own.
fn granted_hand_foretell_cost(
    game: &GameState,
    player: PlayerId,
    card_id: ObjectId,
) -> Option<crate::mana::ManaCost> {
    game.effect_store
        .grant_registry
        .granted_alternative_casts_for_card(game, card_id, Zone::Hand, player)
        .into_iter()
        .find_map(|granted| match granted.method {
            crate::alternative_cast::AlternativeCastingMethod::Foretell { cost } => Some(cost),
            _ => None,
        })
}

fn plot_cost(object: &crate::object::Object) -> Option<crate::mana::ManaCost> {
    object
        .alternative_casts
        .iter()
        .find_map(|method| method.plot_cost().cloned())
}

/// The card's plot cost: printed, or granted in its current zone ("The top
/// card of your library has plot. The plot cost is equal to its mana cost.",
/// Fblthp, Lost on the Range).
fn plot_cost_for(
    game: &GameState,
    player: PlayerId,
    object: &crate::object::Object,
) -> Option<crate::mana::ManaCost> {
    plot_cost(object).or_else(|| {
        game.effect_store
            .grant_registry
            .granted_alternative_casts_for_card(game, object.id, object.zone, player)
            .into_iter()
            .find_map(|granted| granted.method.plot_cost().cloned())
    })
}

/// CR 702.170a with Fblthp, Lost on the Range: the top card of `player`'s
/// own library may be plotted when it is nonland and a permanent they
/// control lets them plot nonland cards from the top of their library.
fn plots_from_top_of_library(
    game: &GameState,
    player: PlayerId,
    object: &crate::object::Object,
) -> bool {
    object.zone == Zone::Library
        && object.owner == player
        && game
            .player(player)
            .is_some_and(|state| state.library.last() == Some(&object.id))
        && !object.is_land()
        && game.player_may_plot_nonland_from_top_of_library(player)
}

/// The plot special action's cost (CR 702.170a): the card's plot cost,
/// reduced by "Plotting cards from your hand costs {N} less" statics of
/// permanents the plotting player controls.
fn plot_special_action_cost(
    game: &GameState,
    player: PlayerId,
    card_id: ObjectId,
) -> Result<crate::mana::ManaCost, ActionError> {
    let object = game.object(card_id).ok_or(ActionError::ObjectNotFound)?;
    let cost = plot_cost_for(game, player, object).ok_or(ActionError::NoSuchAbility)?;
    // "Plotting cards from your hand costs {N} less" reads only hand plots.
    if object.zone != Zone::Hand || object.alternative_casts.iter().any(|method| method.exile_preparation().is_some()) {
        return Ok(cost);
    }
    let checked =
        game.continuous_query_snapshot()
            .map_err(|error| ActionError::ExecutionFailure {
                source: card_id,
                error: crate::effects::ExecutionError::ContinuousDiscovery(error),
            })?;
    let mut reduction = 0u32;
    for source in checked.battlefield.iter().copied() {
        if checked.is_phased_out(source) {
            continue;
        }
        let Some(object) = checked.object(source) else {
            continue;
        };
        if checked.controller_of(object) != player {
            continue;
        }
        let Some(abilities) = checked.current_abilities(source) else {
            continue;
        };
        for ability in abilities {
            if !ability.functions_in(&Zone::Battlefield) {
                continue;
            }
            if let crate::ability::AbilityKind::Static(rule) = &ability.kind
                && let Some(amount) = rule.plot_special_action_reduction()
            {
                reduction = reduction.saturating_add(amount);
            }
        }
    }
    Ok(cost.reduce_generic(reduction))
}

fn suspend_spec(
    object: &crate::object::Object,
) -> Option<(ironsmith_core::SuspendTime, crate::mana::ManaCost)> {
    object.alternative_casts.iter().find_map(|method| {
        method
            .suspend_spec()
            .map(|(time, cost)| (time, cost.clone()))
    })
}

/// The keyword a timed-exile special action is announced as: Suspend, or the
/// custom keyword whose definition described it ("Forge 4—{B}{B}").
pub fn suspend_action_keyword(game: &GameState, card_id: ObjectId) -> String {
    let custom = game.object(card_id).and_then(|object| {
        object.alternative_casts.iter().find(|method| method.suspend_spec().is_some())
    }).filter(|method| {
        matches!(method, crate::alternative_cast::AlternativeCastingMethod::FromZone { .. })
            && !method.name().eq_ignore_ascii_case(ironsmith_core::definition_model::GENERIC_TIMED_EXILE_NAME)
    }).map(|method| method.name());
    let Some(keyword) = custom else { return "Suspend".to_string() };
    let mut letters = keyword.chars();
    letters.next().map_or_else(String::new, |first| first.to_uppercase().chain(letters).collect())
}

fn adjust_total_cost_mana_components_for_reason(
    game: &GameState,
    payer: PlayerId,
    source: ObjectId,
    total_cost: &crate::cost::TotalCost,
    reason: crate::costs::PaymentReason,
) -> crate::cost::TotalCost {
    match total_cost.kind() {
        ironsmith_core::TotalCostKind::All(costs) => crate::cost::TotalCost::from_costs(
            costs
                .iter()
                .map(|cost| {
                    if let Some(mana_cost) = cost.mana_cost_ref() {
                        crate::costs::Cost::mana(game.adjust_mana_cost_for_payment_reason(
                            payer,
                            Some(source),
                            mana_cost,
                            reason,
                        ))
                    } else {
                        cost.clone()
                    }
                })
                .collect(),
        ),
        ironsmith_core::TotalCostKind::OneOf(branches) => crate::cost::TotalCost::one_of(
            branches
                .iter()
                .map(|branch| {
                    adjust_total_cost_mana_components_for_reason(
                        game, payer, source, branch, reason,
                    )
                })
                .collect(),
        ),
    }
}

fn has_sorcery_speed_special_action_timing(
    game: &GameState,
    player: PlayerId,
) -> Result<(), ActionError> {
    if !game.is_active_player(player) {
        return Err(ActionError::NotActivePlayer);
    }
    if !game.team_has_priority(player) {
        return Err(ActionError::NotYourPriority);
    }
    if !matches!(game.turn.phase, Phase::FirstMain | Phase::NextMain) {
        return Err(ActionError::WrongPhase {
            required: Phase::FirstMain,
            actual: game.turn.phase,
        });
    }
    if !game.stack_is_empty() {
        return Err(ActionError::StackNotEmpty);
    }
    Ok(())
}

/// Which door of a Room an unlock applies to. A Room is represented as its
/// current half plus a linked other half.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Default)]
pub enum RoomDoor {
    /// The linked other half (the only locked door once one is unlocked).
    #[default]
    Linked,
    /// The permanent's current half; locked only when the Room entered with
    /// neither door unlocked (CR 709.5d).
    Current,
}

/// A special action that can be performed without using the stack.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum SpecialAction {
    /// Play a land from hand to the battlefield.
    PlayLand { card_id: ObjectId },

    /// Play a land//land modal double-faced card as its back face
    /// (CR 712.12).
    PlayLandBackFace { card_id: ObjectId },

    /// Turn a face-down permanent face up via a turn-face-up special action.
    TurnFaceUp {
        permanent_id: ObjectId,
        method: TurnFaceUpMethod,
    },

    /// Suspend a card from hand (pay suspend cost, exile with time counters).
    Suspend { card_id: ObjectId },

    /// Foretell a card from hand (exile face-down, can cast later for foretell cost).
    Foretell { card_id: ObjectId },

    /// Plot a card from hand (exile it face up as a sorcery, cast on a later turn).
    Plot { card_id: ObjectId },

    /// Activate a mana ability (doesn't use the stack).
    ActivateManaAbility {
        permanent_id: ObjectId,
        ability_index: usize,
    },

    /// Unlock a locked door of a split Room permanent (CR 709.5e).
    UnlockRoomDoor { room_id: ObjectId, door: RoomDoor },

    /// Roll the planar die during the Planechase variant (CR 901.9).
    RollPlanarDie,

    /// Reveal a controlled hidden/double-agenda conspiracy (CR 702.106c).
    TurnConspiracyFaceUp { conspiracy_id: ObjectId },

    /// Pay {3} to put the chosen companion into its owner's hand (CR 116.2g).
    Companion { card_id: ObjectId },

    /// Sacrifice a permanent so the controller of the object attached to this
    /// source ignores the source's static effect until end of turn.
    IgnoreAttachedRestriction {
        source_id: ObjectId,
        ability_index: usize,
    },

    /// Pay a typed mana cost so this player ignores a source-wide static
    /// effect until end of turn.
    IgnoreSourceEffect {
        source_id: ObjectId,
        ability_index: usize,
    },

    /// Pay a pending delayed-trigger cost before its matching event occurs.
    PayDelayedTrigger { delayed_trigger_index: usize },

    /// Pay for and perform a repeatable effect granted through end of turn.
    PerformRepeatableManaPaymentAction { action_index: usize },

    /// Discard a card from hand whose own static ability allows it "any time
    /// you could cast an instant" (Circling Vultures; CR 116.2).
    DiscardFromHand { card_id: ObjectId },
    /// A source's static permission, paid and executed without an ability stack object.
    PerformIntrinsicAction { source_id: ObjectId, ability_index: usize },
}

/// Errors that can occur when attempting to perform a special action.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum ActionError {
    /// An effect performed as part of this action failed.
    ExecutionFailure {
        source: ObjectId,
        error: crate::effects::ExecutionError,
    },
    /// The player cancelled payment; the action transaction has been restored.
    Cancelled,
    /// You don't have priority.
    NotYourPriority,

    /// Wrong phase for this action.
    WrongPhase { required: Phase, actual: Phase },

    /// Wrong step for this action.
    WrongStep {
        required: Option<Step>,
        actual: Option<Step>,
    },

    /// The stack must be empty for this action.
    StackNotEmpty,

    /// Already played maximum lands this turn.
    AlreadyPlayedLand,

    /// The object is not a land.
    NotALand,

    /// Cannot pay the cost.
    CantPayCost,

    /// Creature has summoning sickness (rule 302.6).
    SummoningSickness,

    /// Invalid target for this action.
    InvalidTarget,

    /// The object is not in the expected zone.
    WrongZone { expected: Zone, actual: Zone },

    /// The object doesn't have the required ability.
    NoSuchAbility,

    /// The permanent is not face-down.
    NotFaceDown,

    /// Object not found.
    ObjectNotFound,

    /// Player not found.
    PlayerNotFound,

    /// Cannot perform action during this step.
    InvalidTiming,

    /// Not the active player.
    NotActivePlayer,

    /// A continuous or resolved prohibition prevents this land play.
    LandPlayProhibited,
}

impl std::fmt::Display for ActionError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            ActionError::ExecutionFailure { source, error } => {
                write!(f, "Effect for object {} failed: {error}", source.0)
            }
            ActionError::Cancelled => f.write_str("Action cancelled"),
            ActionError::NotYourPriority => f.write_str("You do not have priority"),
            ActionError::WrongPhase { required, actual } => {
                write!(f, "Wrong phase: need {required}, currently in {actual}")
            }
            ActionError::WrongStep { required, actual } => match (required, actual) {
                (Some(required), Some(actual)) => {
                    write!(f, "Wrong step: need {required}, currently in {actual}")
                }
                (Some(required), None) => write!(f, "Wrong step: need {required}"),
                (None, Some(actual)) => write!(f, "Wrong step: currently in {actual}"),
                (None, None) => f.write_str("Wrong step"),
            },
            ActionError::StackNotEmpty => f.write_str("The stack must be empty"),
            ActionError::AlreadyPlayedLand => {
                f.write_str("You have already played a land this turn")
            }
            ActionError::NotALand => f.write_str("That object is not a land"),
            ActionError::CantPayCost => f.write_str("You cannot pay that cost"),
            ActionError::SummoningSickness => f.write_str("That creature has summoning sickness"),
            ActionError::InvalidTarget => f.write_str("Invalid target for this action"),
            ActionError::WrongZone { expected, actual } => {
                write!(f, "Wrong zone: need {expected}, found {actual}")
            }
            ActionError::NoSuchAbility => {
                f.write_str("That object does not have the required ability")
            }
            ActionError::NotFaceDown => f.write_str("That permanent is not face down"),
            ActionError::ObjectNotFound => f.write_str("Object not found"),
            ActionError::PlayerNotFound => f.write_str("Player not found"),
            ActionError::InvalidTiming => {
                f.write_str("You cannot perform that action at this time")
            }
            ActionError::NotActivePlayer => f.write_str("You are not the active player"),
            ActionError::LandPlayProhibited => {
                f.write_str("An active rule prevents playing that land")
            }
        }
    }
}

impl std::error::Error for ActionError {
    fn source(&self) -> Option<&(dyn std::error::Error + 'static)> {
        match self {
            Self::ExecutionFailure { error, .. } => Some(error),
            _ => None,
        }
    }
}

/// Check if a special action can be performed.
pub fn can_perform(
    action: &SpecialAction,
    game: &GameState,
    player: PlayerId,
    decision_maker: &mut impl crate::decision::DecisionMaker,
) -> Result<(), ActionError> {
    if let SpecialAction::ActivateManaAbility {
        permanent_id,
        ability_index,
    } = action
    {
        return can_activate_mana_ability(
            game,
            player,
            *permanent_id,
            *ability_index,
            decision_maker,
        );
    }
    can_perform_check(action, game, player)
}

/// Check if a special action can be performed (for query/legality checks).
///
/// This variant doesn't require a decision_maker because it only checks
/// if costs CAN be paid, not actually paying them. Used by functions like
/// `compute_legal_actions` that need to enumerate possible actions.
pub fn can_perform_check(
    action: &SpecialAction,
    game: &GameState,
    player: PlayerId,
) -> Result<(), ActionError> {
    match action {
        SpecialAction::PlayLand { card_id } => can_play_land(game, player, *card_id, false),
        SpecialAction::PlayLandBackFace { card_id } => can_play_land(game, player, *card_id, true),
        SpecialAction::TurnFaceUp {
            permanent_id,
            method,
        } => validate_turn_face_up_with_method(game, player, *permanent_id, *method),
        SpecialAction::Suspend { card_id } => can_suspend(game, player, *card_id),
        SpecialAction::Foretell { card_id } => can_foretell(game, player, *card_id),
        SpecialAction::Plot { card_id } => can_plot(game, player, *card_id),
        SpecialAction::ActivateManaAbility {
            permanent_id,
            ability_index,
        } => can_activate_mana_ability_check(game, player, *permanent_id, *ability_index),
        SpecialAction::UnlockRoomDoor { room_id, door } => {
            can_unlock_room_door(game, player, *room_id, *door)
        }
        SpecialAction::RollPlanarDie => can_roll_planar_die(game, player),
        SpecialAction::TurnConspiracyFaceUp { conspiracy_id } => {
            can_turn_conspiracy_face_up(game, player, *conspiracy_id)
        }
        SpecialAction::Companion { card_id } => can_take_companion_action(game, player, *card_id),
        SpecialAction::IgnoreAttachedRestriction {
            source_id,
            ability_index,
        } => can_ignore_attached_restriction(game, player, *source_id, *ability_index),
        SpecialAction::IgnoreSourceEffect {
            source_id,
            ability_index,
        } => can_ignore_source_effect(game, player, *source_id, *ability_index),
        SpecialAction::PayDelayedTrigger {
            delayed_trigger_index,
        } => can_pay_delayed_trigger(game, player, *delayed_trigger_index),
        SpecialAction::PerformRepeatableManaPaymentAction { action_index } => {
            can_perform_repeatable_mana_payment_action(game, player, *action_index)
        }
        SpecialAction::DiscardFromHand { card_id } => {
            can_discard_from_hand_special_action(game, player, *card_id)
        }
        SpecialAction::PerformIntrinsicAction { source_id, ability_index } =>
            intrinsic_action::validate(game, player, *source_id, *ability_index).map(|_| ()) ,
    }?;
    if let Some(payment) = action.payment_spec(game, player)? {
        check_special_action_payment(game, player, &payment)?;
    }
    Ok(())
}

/// Perform a special action.
pub fn perform(
    action: SpecialAction,
    game: &mut GameState,
    player: PlayerId,
    decision_maker: &mut impl crate::decision::DecisionMaker,
) -> Result<(), ActionError> {
    perform_with_mana_activation_outputs(action, game, player, decision_maker).map(|_| ())
}

/// Retain the actual mana completion through the existing special-action
/// admission and checkpoint policy. Other special actions remain terminal
/// scalar paths and do not fabricate a mana completion.
pub(crate) fn perform_with_mana_activation_outputs(
    action: SpecialAction,
    game: &mut GameState,
    player: PlayerId,
    decision_maker: &mut impl crate::decision::DecisionMaker,
) -> Result<Option<CompletedManaActivation>, ActionError> {
    can_perform(&action, game, player, &mut *decision_maker)?;
    // Freeze the exact static permission before mana abilities/payment can
    // change its current array index or the source's abilities.
    let intrinsic = match &action {
        SpecialAction::PerformIntrinsicAction { source_id, ability_index } =>
            Some((*source_id, intrinsic_action::validate(game, player, *source_id, *ability_index)?)),
        _ => None,
    };
    let checkpoint = game.clone();
    let restore_on_pending = matches!(
        &action,
        SpecialAction::TurnFaceUp { .. }
            | SpecialAction::Suspend { .. }
            | SpecialAction::PerformIntrinsicAction { .. }
            | SpecialAction::PlayLand { .. }
            | SpecialAction::PlayLandBackFace { .. }
    );
    let mut announced_x = None;
    if let Some(payment) = action.payment_spec(game, player)? {
        // X is announced once before payment. Morph retains it on the face-up
        // object; suspend uses it for this action's initial time counters,
        // independently of any later cast of the exiled card.
        if matches!(
            action,
            SpecialAction::TurnFaceUp { .. } | SpecialAction::Suspend { .. }
                | SpecialAction::PerformIntrinsicAction { .. }
        ) && let Some(max_x) = special_action_payment_max_x(game, player, &payment)
        {
            let min_x = if let SpecialAction::Suspend { card_id } = &action {
                game.object(*card_id)
                    .and_then(suspend_spec)
                    .and_then(|(time, _)| time.minimum_x())
                    .unwrap_or(0)
            } else {
                0
            };
            if max_x < min_x {
                return Err(ActionError::CantPayCost);
            }
            let mut ctx = crate::decisions::context::NumberContext::x_value_with_min(
                player,
                payment.source,
                min_x,
                max_x,
            );
            let chosen = decision_maker.decide_number(game, &ctx);
            let chosen = if matches!(action, SpecialAction::Suspend { .. }) {
                chosen
            } else {
                chosen.min(max_x)
            };
            if decision_maker.awaiting_choice() {
                return Ok(None);
            }
            if chosen < min_x || chosen > max_x {
                return Err(ActionError::InvalidTarget);
            }
            announced_x = Some(chosen);
        }
        if let Err(error) = pay_special_action_payment_with_x(
            game,
            player,
            &payment,
            None,
            announced_x,
            decision_maker,
        ) {
            if !decision_maker.awaiting_choice() || restore_on_pending {
                *game = checkpoint;
            }
            if restore_on_pending && decision_maker.awaiting_choice() {
                return Ok(None);
            }
            return Err(error);
        }
        if decision_maker.awaiting_choice() {
            if restore_on_pending {
                *game = checkpoint;
            }
            return Ok(None);
        }
    }
    if let SpecialAction::TurnFaceUp { permanent_id, .. } = &action
        && let Some(object) = game.object_mut(*permanent_id)
    {
        // The X paid to turn it face up, or 0 when no X was paid (CR 107.3m).
        object.x_value = Some(announced_x.unwrap_or(0));
    }
    let result = if let Some((source, spec)) = intrinsic {
        intrinsic_action::perform_prepared_action(game, player, source, spec, announced_x, decision_maker).map(|_| None)
    } else { finish_special_action_with_mana_activation_outputs(
        action,
        game,
        player,
        announced_x,
        decision_maker,
    ) };
    if (result.is_err() && !decision_maker.awaiting_choice())
        || (restore_on_pending && decision_maker.awaiting_choice())
    {
        *game = checkpoint;
    }
    if restore_on_pending && decision_maker.awaiting_choice() {
        return Ok(None);
    }
    result
}

fn finish_special_action_with_mana_activation_outputs(
    action: SpecialAction,
    game: &mut GameState,
    player: PlayerId,
    announced_x: Option<u32>,
    decision_maker: &mut impl crate::decision::DecisionMaker,
) -> Result<Option<CompletedManaActivation>, ActionError> {
    match action {
        SpecialAction::PlayLand { card_id } => {
            perform_play_land(game, player, card_id, false, decision_maker)
        }
        SpecialAction::PlayLandBackFace { card_id } => {
            perform_play_land(game, player, card_id, true, decision_maker)
        }
        SpecialAction::TurnFaceUp {
            permanent_id,
            method,
        } => finish_turn_face_up(game, player, permanent_id, method, &mut *decision_maker),
        SpecialAction::Suspend { card_id } => {
            perform_suspend(game, player, card_id, announced_x, decision_maker)
        }
        SpecialAction::Foretell { card_id } => perform_foretell(game, player, card_id),
        SpecialAction::Plot { card_id } => perform_plot(game, player, card_id),
        SpecialAction::ActivateManaAbility {
            permanent_id,
            ability_index,
        } => {
            return perform_activate_mana_ability_restricted_colors_with_outputs(
                game,
                player,
                permanent_id,
                ability_index,
                None,
                &mut *decision_maker,
            )
            .map(Some);
        }
        SpecialAction::UnlockRoomDoor { room_id, door } => {
            perform_unlock_room_door(game, player, room_id, door, &mut *decision_maker)
        }
        SpecialAction::RollPlanarDie => perform_roll_planar_die(game, player, decision_maker),
        SpecialAction::TurnConspiracyFaceUp { conspiracy_id } => game
            .turn_conspiracy_face_up(player, conspiracy_id)
            .map_err(|_| ActionError::InvalidTarget),
        SpecialAction::Companion { card_id } => perform_companion_action(game, player, card_id),
        SpecialAction::IgnoreAttachedRestriction {
            source_id,
            ability_index,
        } => perform_ignore_attached_restriction(
            game,
            player,
            source_id,
            ability_index,
            decision_maker,
        ),
        SpecialAction::IgnoreSourceEffect {
            source_id,
            ability_index,
        } => perform_ignore_source_effect(game, player, source_id, ability_index, decision_maker),
        SpecialAction::PayDelayedTrigger {
            delayed_trigger_index,
        } => perform_pay_delayed_trigger(game, player, delayed_trigger_index, decision_maker),
        SpecialAction::PerformRepeatableManaPaymentAction { action_index } => {
            perform_repeatable_mana_payment_action(game, player, action_index, decision_maker)
        }
        SpecialAction::DiscardFromHand { card_id } => {
            perform_discard_from_hand_special_action(game, player, card_id, decision_maker)
        }
        SpecialAction::PerformIntrinsicAction { source_id, ability_index } =>
            intrinsic_action::perform_action(game, player, source_id, ability_index, decision_maker),
    }
    .map(|_| None)
}

fn repeatable_mana_payment_action(
    game: &GameState,
    player: PlayerId,
    action_index: usize,
) -> Result<&crate::game_state::RepeatableManaPaymentAction, ActionError> {
    if !game.team_has_priority(player) {
        return Err(ActionError::NotYourPriority);
    }
    let action = game
        .effect_store
        .repeatable_mana_payment_actions
        .get(action_index)
        .ok_or(ActionError::InvalidTarget)?;
    let acting_player = if action.restrictions.source_controller_acts {
        game.controller_of_id(action.source)
    } else { Some(action.player) };
    if acting_player != Some(player)
        || action.is_expired(game.turn.turn_number)
        || !action.end_effect_offer_is_live(game)
    {
        return Err(ActionError::InvalidTiming);
    }
    let restrictions = &action.restrictions;
    if let Some(permission) = &restrictions.face_down_exile_cast {
        if !face_down_cast::can_exile_cast(game, player, action.source, permission)? {
            return Err(ActionError::InvalidTiming);
        }
    }
    if restrictions.remaining_uses == Some(0) {
        return Err(ActionError::InvalidTiming);
    }
    if restrictions.sorcery_speed {
        has_sorcery_speed_special_action_timing(game, player)?;
    }
    if let Some(zone) = restrictions.source_zone {
        if !game.object(action.source).is_some_and(|object| {
            object.zone == zone && game.controller_of(object) == if restrictions.source_controller_acts { player } else { action.controller }
        }) {
            return Err(ActionError::InvalidTiming);
        }
    }
    if restrictions.source_attacking
        && !game.combat.as_ref().is_some_and(|combat| {
            crate::combat_state::is_attacking(combat, action.source)
        })
    {
        return Err(ActionError::InvalidTiming);
    }
    Ok(action)
}

fn can_perform_repeatable_mana_payment_action(
    game: &GameState,
    player: PlayerId,
    action_index: usize,
) -> Result<(), ActionError> {
    repeatable_mana_payment_action(game, player, action_index)?;
    Ok(())
}

fn perform_repeatable_mana_payment_action(
    game: &mut GameState,
    player: PlayerId,
    action_index: usize,
    decision_maker: &mut impl crate::decision::DecisionMaker,
) -> Result<(), ActionError> {
    let action = repeatable_mana_payment_action(game, player, action_index)?.clone();
    // Payment has already committed. Consume the permission before running
    // instructions, including instructions that can suspend for a choice.
    if let Some(uses) = game.effect_store.repeatable_mana_payment_actions[action_index]
        .restrictions.remaining_uses.as_mut()
    {
        *uses -= 1;
    }

    if let Some(permission) = &action.restrictions.face_down_exile_cast {
        return face_down_cast::perform_exile_cast(game, player, action.source, permission, decision_maker);
    }

    // CR 116.2c: "pay [cost] to end this effect" ends the linked continuous
    // effects at once (no stack) and uses up the offer.
    if !action.ends_continuous_effects.is_empty() {
        for id in &action.ends_continuous_effects {
            game.effect_store.continuous_effects.remove_effect(*id);
        }
        game.effect_store
            .repeatable_mana_payment_actions
            .remove(action_index);
        game.refresh_continuous_state()
            .map_err(|error| ActionError::ExecutionFailure {
                source: action.source,
                error: crate::effects::ExecutionError::ContinuousDiscovery(error),
            })?;
        return Ok(());
    }

    let mut ctx = ExecutionContext::new(action.source, action.controller, decision_maker)
        .with_targets(action.targets)
        .with_tagged_objects(action.tagged_objects);
    ctx.tagged_players = action.tagged_players;
    // "If you do, [effects]" happens right away, without the stack. Like a
    // resolving ability's instructions, each one's events trigger abilities
    // as they happen (CR 603.2); those abilities wait for the next priority.
    crate::effects::with_per_event_trigger_matching(game, true, |game| {
        let mut reported = Vec::new();
        for (index, effect) in action.effects.iter().enumerate() {
            let outcome =
                crate::effects::execute_effect(game, effect, &mut ctx).map_err(|error| {
                    ActionError::ExecutionFailure {
                        source: action.source,
                        error,
                    }
                })?;
            reported.extend(outcome.events);
            if ctx.decision_maker.awaiting_choice() {
                return Ok(());
            }
            if crate::effects::match_triggers_at_instruction_boundary(
                game,
                &mut ctx,
                action.effects.get(index + 1),
                reported.iter(),
            )
            .map_err(|error| ActionError::ExecutionFailure {
                source: action.source,
                error,
            })? {
                reported.clear();
            }
        }
        crate::effects::retain_unmatched_outcome_events(game, &mut reported);
        for event in reported {
            game.queue_trigger_event(ctx.provenance, event);
        }
        Ok(())
    })
}

fn delayed_trigger_prepayment(
    game: &GameState,
    delayed_trigger_index: usize,
) -> Result<&crate::triggers::PendingDelayedTriggerPayment, ActionError> {
    game.effect_store
        .delayed_triggers
        .get(delayed_trigger_index)
        .and_then(|delayed| delayed.prepayment.as_ref())
        .ok_or(ActionError::InvalidTarget)
}

fn can_pay_delayed_trigger(
    game: &GameState,
    player: PlayerId,
    delayed_trigger_index: usize,
) -> Result<(), ActionError> {
    if !game.team_has_priority(player) {
        return Err(ActionError::NotYourPriority);
    }
    let payment = delayed_trigger_prepayment(game, delayed_trigger_index)?;
    if payment.player != player {
        return Err(ActionError::InvalidTarget);
    }
    Ok(())
}

fn perform_pay_delayed_trigger(
    game: &mut GameState,
    player: PlayerId,
    delayed_trigger_index: usize,
    _decision_maker: &mut impl crate::decision::DecisionMaker,
) -> Result<(), ActionError> {
    can_pay_delayed_trigger(game, player, delayed_trigger_index)?;

    game.effect_store
        .delayed_triggers
        .remove(delayed_trigger_index);
    Ok(())
}

fn ignore_source_effect_mana_cost(
    game: &GameState,
    source_id: ObjectId,
    ability_index: usize,
) -> Result<crate::mana::ManaCost, ActionError> {
    let source = game.object(source_id).ok_or(ActionError::ObjectNotFound)?;
    if source.zone != Zone::Battlefield {
        return Err(ActionError::WrongZone {
            expected: Zone::Battlefield,
            actual: source.zone,
        });
    }
    if game.is_phased_out(source_id) {
        return Err(ActionError::NoSuchAbility);
    }
    // CR 116.2d: read the source's current abilities (grants and losses).
    let abilities = game
        .current_abilities(source_id)
        .unwrap_or_else(|| source.abilities_vec());
    let ability = abilities
        .get(ability_index)
        .ok_or(ActionError::NoSuchAbility)?;
    let crate::ability::AbilityKind::Static(static_ability) = &ability.kind else {
        return Err(ActionError::NoSuchAbility);
    };
    if !ability.functions_in(&Zone::Battlefield)
        || static_ability.id()
            != crate::static_abilities::StaticAbilityId::AnyPlayerMayPayManaToIgnoreSourceEffectUntilEndOfTurn
        || !static_ability.is_active(game, source_id)
    {
        return Err(ActionError::NoSuchAbility);
    }
    let model = static_ability
        .compiled_model()
        .ok_or(ActionError::NoSuchAbility)?;
    let ironsmith_core::StaticAbilityPayload::AnyPlayerMayPayManaToIgnoreSourceEffectUntilEndOfTurn {
        cost,
        ..
    } = &model.payload
    else {
        return Err(ActionError::NoSuchAbility);
    };
    Ok(cost.clone())
}

/// The player filter of an active "that player may sacrifice a permanent ...
/// to ignore this effect until end of turn" permission (Damping Engine).
fn sacrifice_to_ignore_source_effect_player(
    game: &GameState,
    source_id: ObjectId,
    ability_index: usize,
) -> Result<crate::target::PlayerFilter, ActionError> {
    let source = game.object(source_id).ok_or(ActionError::ObjectNotFound)?;
    if source.zone != Zone::Battlefield {
        return Err(ActionError::WrongZone {
            expected: Zone::Battlefield,
            actual: source.zone,
        });
    }
    if game.is_phased_out(source_id) {
        return Err(ActionError::NoSuchAbility);
    }
    // CR 116.2d: read the source's current abilities (grants and losses).
    let abilities = game
        .current_abilities(source_id)
        .unwrap_or_else(|| source.abilities_vec());
    let ability = abilities
        .get(ability_index)
        .ok_or(ActionError::NoSuchAbility)?;
    let crate::ability::AbilityKind::Static(static_ability) = &ability.kind else {
        return Err(ActionError::NoSuchAbility);
    };
    if !ability.functions_in(&Zone::Battlefield)
        || static_ability.id()
            != crate::static_abilities::StaticAbilityId::PlayerMaySacrificePermanentToIgnoreSourceEffectUntilEndOfTurn
        || !static_ability.is_active(game, source_id)
    {
        return Err(ActionError::NoSuchAbility);
    }
    let model = static_ability
        .compiled_model()
        .ok_or(ActionError::NoSuchAbility)?;
    let ironsmith_core::StaticAbilityPayload::PlayerMaySacrificePermanentToIgnoreSourceEffectUntilEndOfTurn {
        player,
        ..
    } = &model.payload
    else {
        return Err(ActionError::NoSuchAbility);
    };
    Ok(player.clone())
}

/// The cost of an ignore-this-effect special action: the stated mana, or a
/// permanent the acting player sacrifices.
fn ignore_source_effect_total_cost(
    game: &GameState,
    source_id: ObjectId,
    ability_index: usize,
) -> Result<crate::cost::TotalCost, ActionError> {
    if sacrifice_to_ignore_source_effect_player(game, source_id, ability_index).is_ok() {
        return Ok(ignore_attached_restriction_cost());
    }
    Ok(crate::cost::TotalCost::mana(ignore_source_effect_mana_cost(
        game,
        source_id,
        ability_index,
    )?))
}

fn can_ignore_source_effect(
    game: &GameState,
    player: PlayerId,
    source_id: ObjectId,
    ability_index: usize,
) -> Result<(), ActionError> {
    if !game.team_has_priority(player) {
        return Err(ActionError::NotYourPriority);
    }
    if game.player_ignores_source_static_effect_this_turn(source_id, player) {
        return Err(ActionError::InvalidTiming);
    }
    if let Ok(eligible) = sacrifice_to_ignore_source_effect_player(game, source_id, ability_index)
    {
        // Only the player the restriction names ("That player") may act.
        let controller = game.controller_of_id(source_id).unwrap_or(player);
        let filter_ctx = game.filter_context_for_combat(controller, Some(source_id), None, None);
        if !crate::filter::player_filter_matches_game(&eligible, player, game, &filter_ctx) {
            return Err(ActionError::InvalidTarget);
        }
        return Ok(());
    }
    ignore_source_effect_mana_cost(game, source_id, ability_index)?;
    Ok(())
}

fn perform_ignore_source_effect(
    game: &mut GameState,
    player: PlayerId,
    source_id: ObjectId,
    _ability_index: usize,
    _decision_maker: &mut impl crate::decision::DecisionMaker,
) -> Result<(), ActionError> {
    // Eligibility was checked before costs, which may sacrifice the attached
    // object or the source itself. Do not reject a successfully paid action.

    game.player_ignores_source_static_effect_until_end_of_turn(source_id, player);
    game.update_cant_effects();
    Ok(())
}

fn ignore_attached_restriction_cost() -> crate::cost::TotalCost {
    crate::cost::TotalCost::from_cost(crate::costs::Cost::sacrifice(
        ObjectFilter::permanent().controlled_by(crate::target::PlayerFilter::You),
    ))
}

/// The authored cost of an attached-object ignore permission ("exile three
/// cards from their graveyard", Lost in Thought), when it has one.
fn authored_ignore_attached_restriction_cost(
    game: &GameState,
    source_id: ObjectId,
    ability_index: usize,
) -> Option<crate::cost::TotalCost> {
    let ability = game.object(source_id)?.abilities.get(ability_index)?;
    let crate::ability::AbilityKind::Static(static_ability) = &ability.kind else {
        return None;
    };
    match &static_ability.compiled_model()?.payload {
        ironsmith_core::StaticAbilityPayload::AttachedControllerMayPayCostToIgnoreSourceEffectUntilEndOfTurn {
            cost,
            ..
        } => Some(cost.clone()),
        _ => None,
    }
}

/// The cost of [`SpecialAction::IgnoreAttachedRestriction`]: the authored
/// cost, or a sacrificed permanent for the original wording.
pub(crate) fn ignore_attached_restriction_total_cost(
    game: &GameState,
    source_id: ObjectId,
    ability_index: usize,
) -> crate::cost::TotalCost {
    authored_ignore_attached_restriction_cost(game, source_id, ability_index)
        .unwrap_or_else(ignore_attached_restriction_cost)
}

/// Oracle rendering of the cost paid to ignore an attached restriction, for
/// the [`SpecialAction::IgnoreAttachedRestriction`] label.
pub fn ignore_attached_restriction_cost_display(
    game: &GameState,
    source_id: ObjectId,
    ability_index: usize,
) -> String {
    authored_ignore_attached_restriction_cost(game, source_id, ability_index)
        .map(|cost| cost.display())
        .unwrap_or_else(|| "Sacrifice a permanent".to_string())
}

fn can_ignore_attached_restriction(
    game: &GameState,
    player: PlayerId,
    source_id: ObjectId,
    ability_index: usize,
) -> Result<(), ActionError> {
    if !game.team_has_priority(player) {
        return Err(ActionError::NotYourPriority);
    }
    if game.player_ignores_attached_static_restrictions_this_turn(source_id, player) {
        return Err(ActionError::InvalidTiming);
    }

    let source = game.object(source_id).ok_or(ActionError::ObjectNotFound)?;
    if source.zone != Zone::Battlefield {
        return Err(ActionError::WrongZone {
            expected: Zone::Battlefield,
            actual: source.zone,
        });
    }
    // CR 702.26b: a phased-out Aura is treated as though it doesn't exist.
    if game.is_phased_out(source_id) {
        return Err(ActionError::NoSuchAbility);
    }
    let ability = source
        .abilities
        .get(ability_index)
        .ok_or(ActionError::NoSuchAbility)?;
    let crate::ability::AbilityKind::Static(static_ability) = &ability.kind else {
        return Err(ActionError::NoSuchAbility);
    };
    if !ability.functions_in(&Zone::Battlefield)
        || !matches!(
            static_ability.id(),
            crate::static_abilities::StaticAbilityId::AttachedControllerMaySacrificePermanentToIgnoreSourceEffectUntilEndOfTurn
                | crate::static_abilities::StaticAbilityId::AttachedControllerMayPayCostToIgnoreSourceEffectUntilEndOfTurn
        )
        || !static_ability.is_active(game, source_id)
    {
        return Err(ActionError::NoSuchAbility);
    }

    let Some(crate::object::AttachmentTarget::Object(attached_id)) = source.attached_to else {
        return Err(ActionError::InvalidTarget);
    };
    if game.object(attached_id).is_none_or(|attached| {
        attached.zone != Zone::Battlefield || game.controller_of(attached) != player
    }) {
        return Err(ActionError::InvalidTarget);
    }

    Ok(())
}

fn perform_ignore_attached_restriction(
    game: &mut GameState,
    player: PlayerId,
    source_id: ObjectId,
    _ability_index: usize,
    _decision_maker: &mut impl crate::decision::DecisionMaker,
) -> Result<(), ActionError> {
    // Eligibility was checked before costs, which may sacrifice the attached
    // object or the source itself. Do not reject a successfully paid action.

    game.player_ignores_attached_static_restrictions_until_end_of_turn(source_id, player);
    game.update_cant_effects();
    Ok(())
}

/// Whether this card's own text lets its owner discard it as a special action.
pub(crate) fn has_discard_from_hand_special_action(game: &GameState, card_id: ObjectId) -> bool {
    game.object(card_id).is_some_and(|object| {
        object.abilities_vec().iter().any(|ability| {
            matches!(
                &ability.kind,
                crate::ability::AbilityKind::Static(static_ability)
                    if static_ability.id()
                        == crate::static_abilities::StaticAbilityId::MayDiscardSourceAnyTimeYouCouldCastInstant
            )
        })
    })
}

fn can_discard_from_hand_special_action(
    game: &GameState,
    player: PlayerId,
    card_id: ObjectId,
) -> Result<(), ActionError> {
    // "Any time you could cast an instant": whenever its owner has priority.
    if !game.team_has_priority(player) {
        return Err(ActionError::NotYourPriority);
    }
    let card = game.object(card_id).ok_or(ActionError::ObjectNotFound)?;
    if card.zone != Zone::Hand {
        return Err(ActionError::WrongZone {
            expected: Zone::Hand,
            actual: card.zone,
        });
    }
    if card.owner != player {
        return Err(ActionError::InvalidTarget);
    }
    if !has_discard_from_hand_special_action(game, card_id) {
        return Err(ActionError::NoSuchAbility);
    }
    Ok(())
}

fn perform_discard_from_hand_special_action(
    game: &mut GameState,
    player: PlayerId,
    card_id: ObjectId,
    decision_maker: &mut impl crate::decision::DecisionMaker,
) -> Result<(), ActionError> {
    let effect = crate::effect::Effect::discard_source_as_cost();
    let cause = EventCause::from_special_action(Some(card_id), player);
    let mut ctx = ExecutionContext::new(card_id, player, decision_maker).with_cause(cause);
    // The discard happens immediately, without the stack; its events trigger
    // abilities that wait for the next priority (CR 116.2, 603.2).
    crate::effects::with_per_event_trigger_matching(game, true, |game| {
        let outcome = crate::effects::execute_effect(game, &effect, &mut ctx).map_err(|error| {
            ActionError::ExecutionFailure {
                source: card_id,
                error,
            }
        })?;
        let mut reported = Vec::new();
        reported.extend(outcome.events);
        if ctx.decision_maker.awaiting_choice() {
            return Ok(());
        }
        if crate::effects::match_triggers_at_instruction_boundary(
            game,
            &mut ctx,
            None::<&crate::effect::Effect>,
            reported.iter(),
        )
        .map_err(|error| ActionError::ExecutionFailure {
            source: card_id,
            error,
        })? {
            reported.clear();
        }
        crate::effects::retain_unmatched_outcome_events(game, &mut reported);
        for event in reported {
            game.queue_trigger_event(ctx.provenance, event);
        }
        Ok(())
    })
}

fn companion_action_cost() -> ManaCost {
    ManaCost::from_symbols(vec![ManaSymbol::Generic(3)])
}

fn can_take_companion_action(
    game: &GameState,
    player: PlayerId,
    card_id: ObjectId,
) -> Result<(), ActionError> {
    has_sorcery_speed_special_action_timing(game, player)?;
    let player_state = game.player(player).ok_or(ActionError::PlayerNotFound)?;
    if player_state.companion != Some(card_id) || player_state.companion_special_action_used {
        return Err(ActionError::InvalidTarget);
    }
    let companion = game.object(card_id).ok_or(ActionError::ObjectNotFound)?;
    if companion.owner != player {
        return Err(ActionError::InvalidTarget);
    }
    if companion.zone != Zone::OutsideGame {
        return Err(ActionError::WrongZone {
            expected: Zone::OutsideGame,
            actual: companion.zone,
        });
    }
    Ok(())
}

fn perform_companion_action(
    game: &mut GameState,
    player: PlayerId,
    card_id: ObjectId,
) -> Result<(), ActionError> {
    // Stage payment and movement together so an unexpected movement failure
    // cannot spend mana or consume the once-per-game action.
    let mut staged = game.clone();
    let new_id = staged
        .move_object(
            card_id,
            Zone::Hand,
            EventCause::from_special_action(Some(card_id), player),
        )
        .ok_or(ActionError::InvalidTarget)?;
    let player_state = staged
        .player_mut(player)
        .ok_or(ActionError::PlayerNotFound)?;
    player_state.companion = Some(new_id);
    player_state.companion_special_action_used = true;
    *game = staged;
    Ok(())
}

fn can_turn_conspiracy_face_up(
    game: &GameState,
    player: PlayerId,
    conspiracy_id: ObjectId,
) -> Result<(), ActionError> {
    if !game.team_has_priority(player) {
        return Err(ActionError::NotYourPriority);
    }
    let object = game
        .object(conspiracy_id)
        .ok_or(ActionError::ObjectNotFound)?;
    if object.zone != Zone::Command {
        return Err(ActionError::WrongZone {
            expected: Zone::Command,
            actual: object.zone,
        });
    }
    if object.owner != player || !game.is_face_down_conspiracy(conspiracy_id) {
        return Err(ActionError::InvalidTarget);
    }
    Ok(())
}

fn planar_die_cost(amount: u32) -> crate::mana::ManaCost {
    let mut remaining = amount;
    let mut symbols = Vec::new();
    while remaining > 0 {
        let chunk = remaining.min(u8::MAX as u32) as u8;
        symbols.push(crate::mana::ManaSymbol::Generic(chunk));
        remaining -= u32::from(chunk);
    }
    crate::mana::ManaCost::from_symbols(symbols)
}

fn can_roll_planar_die(game: &GameState, player: PlayerId) -> Result<(), ActionError> {
    has_sorcery_speed_special_action_timing(game, player)?;
    // CR 901.12d: in Two-Headed Giant each member of the active team may roll.
    if game.planar_controller_acting_for(player).is_none()
        || game.face_up_planar_objects().is_empty()
    {
        return Err(ActionError::InvalidTiming);
    }
    game.planar_die_roll_cost(player)
        .ok_or(ActionError::InvalidTiming)?;
    game.turn_store
        .turn_history
        .check_completed_die_roll_capacity(player, 1)
        .map_err(|error| ActionError::ExecutionFailure {
            source: ObjectId::from_raw(0),
            error,
        })?;
    Ok(())
}

fn perform_roll_planar_die(game: &mut GameState, player: PlayerId, decision_maker: &mut impl crate::decision::DecisionMaker) -> Result<(), ActionError> {
    game.roll_planar_die_with_decision_maker(player, true, decision_maker)
        .map(|_| ())
        .map_err(|error| match error {
            crate::effects::ExecutionError::Impossible(_) => ActionError::InvalidTiming,
            error => ActionError::ExecutionFailure {
                source: ObjectId::from_raw(0),
                error,
            },
        })
}

// === Play Land ===

/// Land permission filters inspect the face being played. A card the player
/// may inspect in exile is still physically face down until the actual play;
/// expose its characteristics only in this isolated legality query.
pub(crate) fn land_play_query_snapshot(
    game: &GameState,
    player: PlayerId,
    card: ObjectId,
) -> Result<GameState, crate::static_ability_processor::StaticEffectDiscoveryError> {
    if game.object(card).is_some_and(|object| object.zone == Zone::Exile)
        && game.is_face_down(card)
        && game.can_player_look_at_face_down_exiled_card(card, player)
        && let Some(query) = game.hypothetical_face_up(card)?
    {
        return Ok(query);
    }
    game.continuous_query_snapshot()
}

fn can_play_land(
    game: &GameState,
    player: PlayerId,
    card_id: ObjectId,
    back_face: bool,
) -> Result<(), ActionError> {
    // Direct special-action validation must preserve failed discovery, just as
    // the checked legal-action enumerator does; unknown is not "prohibited".
    let checked =
        land_play_query_snapshot(game, player, card_id)
            .map_err(|error| ActionError::ExecutionFailure {
                source: card_id,
                error: crate::effects::ExecutionError::ContinuousDiscovery(error),
            })?;
    let game = &checked;
    if crate::alternative_cast::blind_play::requires_opening(game, card_id, player) {
        return Err(ActionError::ExecutionFailure {
            source: card_id,
            error: crate::effects::ExecutionError::Impossible(
                "Open this exiled card before announcing a land play".into(),
            ),
        });
    }
    // Must be the active player
    if !game.is_active_player(player) {
        return Err(ActionError::NotActivePlayer);
    }

    // Must have priority (or be in a main phase where you would have priority)
    if !game.team_has_priority(player) {
        return Err(ActionError::NotYourPriority);
    }

    // Check player can still play lands
    let player_data = game.player(player).ok_or(ActionError::PlayerNotFound)?;
    if !player_data.can_play_land() {
        return Err(ActionError::AlreadyPlayedLand);
    }

    // CR 712.12: evaluate the chosen face in an isolated query. Merely passing
    // a cloned Object to a live filter lets characteristic lookup by ObjectId
    // silently read the unchosen front face again.
    let object = game.object(card_id).ok_or(ActionError::ObjectNotFound)?;
    let land_face = crate::decision::land_play_face_definition(game, object, back_face)
        .map_err(|()| ActionError::NotALand)?;
    let proposed_game;
    let game = if let Some(definition) = land_face {
        let mut branch = game.clone();
        branch
            .object_mut(card_id)
            .ok_or(ActionError::ObjectNotFound)?
            .apply_definition_face(&definition);
        branch
            .refresh_continuous_state()
            .map_err(|error| ActionError::ExecutionFailure {
                source: card_id,
                error: crate::effects::ExecutionError::ContinuousDiscovery(error),
            })?;
        proposed_game = branch;
        &proposed_game
    } else {
        game
    };
    let object = game.object(card_id).ok_or(ActionError::ObjectNotFound)?;
    let timing_permission = game.next_play_timing_allows(player, object, true);
    let is_main_phase = game.turn.phase == Phase::FirstMain || game.turn.phase == Phase::NextMain;
    if !is_main_phase && !timing_permission {
        return Err(ActionError::WrongPhase {
            required: Phase::FirstMain,
            actual: game.turn.phase,
        });
    }
    if !game.stack_is_empty() && !timing_permission {
        return Err(ActionError::StackNotEmpty);
    }
    if crate::effects::zones::land_play_restriction_applies(game, player, card_id).map_err(
        |error| ActionError::ExecutionFailure {
            source: card_id,
            error,
        },
    )? {
        return Err(ActionError::LandPlayProhibited);
    }
    let permission_view = crate::derived_view::DerivedGameView::new(game);
    // Only your own hand is a natural land-play origin; another player's hand
    // needs a permission (Sen Triplets) like any other zone.
    let can_play_from_zone = (object.zone == Zone::Hand && object.owner == player)
        || (object.zone == Zone::Exile && game.adventure_exiled_player(card_id) == Some(player))
        || permission_view
            .granted_play_from_for_card(card_id, object.zone, player)
            .iter()
            .any(|grant| {
                crate::grant_registry::grant_usage_limit_allows(
                    game,
                    player,
                    grant.permission_identity.as_ref(),
                    grant.usage_limit,
                )
            });
    if !can_play_from_zone {
        return Err(ActionError::WrongZone {
            expected: Zone::Hand,
            actual: object.zone,
        });
    }

    // CR 116.2a: a land in another player's hand was admitted above only by
    // an explicit permission for that origin (Sen Triplets).
    Ok(())
}

/// A selected land permission, captured before entry replacements can remove
/// its provider. Both the direct special-action and priority owners use this.
#[derive(Debug, Clone, Default)]
pub(crate) struct LandPlayPermissionReceipt {
    shared: Option<crate::grant_registry::SharedGrantUsageId>,
    identity: Option<crate::grant_registry::GrantPermissionIdentity>,
    completion: Option<crate::grant_registry::GrantUseCompletion>,
    permanent_grants: Vec<crate::static_abilities::StaticAbility>,
    original_land: Option<ObjectId>,
    pub enters_tapped: bool,
}
impl LandPlayPermissionReceipt {
    /// The exact grant selected for this land play, if any.
    pub(crate) fn identity(&self) -> Option<&crate::grant_registry::GrantPermissionIdentity> {
        self.identity.as_ref()
    }

    pub(crate) fn reserve(
        &self,
        game: &mut GameState,
        player: PlayerId,
    ) -> Result<(), crate::effects::ExecutionError> {
        if let Some(shared) = self.shared {
            if !game
                .effect_store
                .grant_registry
                .consume_shared_usage(shared)
            {
                return Err(crate::effects::ExecutionError::InternalError(
                    "selected land permission budget disappeared".into(),
                ));
            }
        }
        if let Some(identity) = &self.identity {
            game.turn_store
                .grant_cast_uses_this_turn
                .insert((player, identity.clone()));
        }
        if let Some(card) = self.original_land {
            game.stage_land_permission_grants(card, self.permanent_grants.clone());
        }
        Ok(())
    }
    pub(crate) fn complete(self, game: &mut GameState) {
        if let Some(completion) = self.completion {
            completion.complete(game);
        }
    }
}
pub(crate) fn opened_land_play_permission(
    game: &GameState,
    player: PlayerId,
    card: ObjectId,
    permission: &crate::alternative_cast::GrantSelection,
) -> Result<LandPlayPermissionReceipt, crate::effects::ExecutionError> {
    let grant = crate::alternative_cast::blind_play::resolve(game, card, player, permission)?;
    Ok(LandPlayPermissionReceipt {
        shared: grant.shared_usage_id,
        identity: grant.permission_identity,
        completion: crate::grant_registry::GrantUseCompletion::capture(
            game,
            grant.source.source_id(),
            player,
            grant.on_use_effects,
        ),
        permanent_grants: grant.permanent_this_way_grants,
        original_land: Some(card),
        enters_tapped: grant.play_from_constraints.lands_enter_tapped,
    })
}

pub(crate) fn choose_land_play_permission(
    game: &GameState,
    player: PlayerId,
    card: ObjectId,
    decision_maker: &mut impl DecisionMaker,
) -> Result<LandPlayPermissionReceipt, crate::effects::ExecutionError> {
    let checked = land_play_query_snapshot(game, player, card)
        .map_err(crate::effects::ExecutionError::ContinuousDiscovery)?;
    let object = checked
        .object(card)
        .ok_or(crate::effects::ExecutionError::ObjectNotFound(card))?;
    let intrinsic = object.zone == Zone::Hand
        || (object.zone == Zone::Exile && checked.adventure_exiled_player(card) == Some(player));
    let mut choices = if intrinsic { vec![None] } else { Vec::new() };
    choices.extend(
        checked
            .effect_store
            .grant_registry
            .get_grants_for_card(&checked, card, object.zone, player)
            .into_iter()
            .filter(|grant| {
                matches!(grant.grantable, crate::grant::Grantable::PlayFrom)
                    && crate::grant_registry::grant_usage_limit_allows(
                        &checked,
                        player,
                        grant.permission_identity.as_ref(),
                        grant.usage_limit,
                    )
            })
            .map(Some),
    );
    if choices.is_empty() {
        return Err(crate::effects::ExecutionError::Impossible(
            "no land-play permission for the chosen face".into(),
        ));
    }
    let chosen = if choices.len() == 1 {
        0
    } else {
        let options = choices
            .iter()
            .enumerate()
            .map(|(index, grant)| {
                let description = match grant {
                    None => "Use the ordinary land-play permission".to_string(),
                    Some(grant) => {
                        let source = checked
                            .object(grant.source.source_id())
                            .map_or("resolved permission", |object| object.name.as_ref());
                        format!(
                            "Use {source} permission{}{}",
                            if grant.usage_limit.is_some() {
                                " (uses its turn allowance)"
                            } else {
                                ""
                            },
                            if grant.on_use_effects.is_empty() {
                                ""
                            } else {
                                " (triggers its follow-up)"
                            }
                        )
                    }
                };
                crate::decisions::context::SelectableOption::new(index, description)
            })
            .collect();
        let selection = decision_maker.decide_options(
            game,
            &crate::decisions::context::SelectOptionsContext::new(
                player,
                Some(card),
                "Choose the permission used to play this land",
                options,
                1,
                1,
            ),
        );
        if decision_maker.awaiting_choice() {
            return Ok(LandPlayPermissionReceipt::default());
        }
        if selection.len() != 1 || selection[0] >= choices.len() {
            return Err(crate::effects::ExecutionError::InvalidTarget);
        }
        selection[0]
    };
    let Some(grant) = choices.swap_remove(chosen) else {
        return Ok(LandPlayPermissionReceipt::default());
    };
    Ok(LandPlayPermissionReceipt {
        shared: grant.shared_usage_id,
        identity: grant.permission_identity,
        completion: crate::grant_registry::GrantUseCompletion::capture(
            &checked,
            grant.source.source_id(),
            player,
            grant.on_use_effects,
        ),
        permanent_grants: grant.permanent_this_way_grants,
        original_land: Some(card),
        enters_tapped: grant.play_from_constraints.lands_enter_tapped,
    })
}

/// Turn a card about to be played as a land to the face chosen for the land
/// play (CR 712.12), before it moves so the face's entry replacements apply.
pub(crate) fn apply_land_play_face(game: &mut GameState, card_id: ObjectId, back_face: bool) -> Option<crate::cards::CardDefinition> {
    if let Some(Ok(Some(land_def))) = game
        .object(card_id)
        .map(|object| crate::decision::land_play_face_definition(game, object, back_face))
        && let Some(object) = game.object_mut(card_id)
    {
        object.apply_definition_face(&land_def);
        // CR 712.8f: a modal DFC played as its land back face has only that
        // face's characteristics, so no front-face mana value carries over.
        object.linked_face_mana_cost = None;
        return Some(land_def);
    }
    None
}

pub(crate) use crate::effects::zones::{LandPlayObservationKind, LandPlayObservationTiming};

/// Root callers adapt their publication policy to the ordinary land action owner.
pub(crate) fn execute_land_play_with_observer(
    game: &mut GameState,
    player: PlayerId,
    card_id: ObjectId,
    back_face: bool,
    opened_permission: Option<&crate::alternative_cast::GrantSelection>,
    timing: LandPlayObservationTiming,
    decision_maker: &mut impl crate::decision::DecisionMaker,
    mut observe: impl FnMut(
        &mut GameState,
        &mut dyn crate::decision::DecisionMaker,
        ObjectId,
        LandPlayObservationKind,
        TriggerEvent,
    ) -> Result<(), crate::effects::ExecutionError>,
) -> Result<(), crate::effects::ExecutionError> {
    let cause = EventCause::from_special_action(Some(card_id), player);
    let mut execution = ExecutionContext::new(card_id, player, decision_maker).with_cause(cause);
    let _outcome = crate::effects::zones::execute_land_play_program(
        game,
        &mut execution,
        card_id,
        player,
        crate::effects::zones::LandPlayAuthorization::SelectedPermission {
            back_face,
            opened_permission: opened_permission.cloned(),
        },
        timing,
        |game, execution, object, kind, event| {
            observe(game, execution.decision_maker, object, kind, event)
        },
    )?;
    if execution.decision_maker.awaiting_choice() {
        return Ok(());
    }
    Ok(())
}

fn perform_play_land(
    game: &mut GameState,
    player: PlayerId,
    card_id: ObjectId,
    back_face: bool,
    decision_maker: &mut impl crate::decision::DecisionMaker,
) -> Result<(), ActionError> {
    execute_land_play_with_observer(
        game,
        player,
        card_id,
        back_face,
        None,
        LandPlayObservationTiming::AfterHistory,
        decision_maker,
        |game, _, _, _, event| {
            game.queue_trigger_event(event.provenance(), event);
            Ok(())
        },
    )
    .map_err(|error| ActionError::ExecutionFailure {
        source: card_id,
        error,
    })
}

// === Turn Face Up ===

#[cfg(test)]
fn can_turn_face_up(
    game: &GameState,
    player: PlayerId,
    permanent_id: ObjectId,
) -> Result<(), ActionError> {
    let object = validate_turn_face_up_common(game, player, permanent_id)?;
    let specs =
        turn_face_up_specs(game, object).map_err(|error| ActionError::ExecutionFailure {
            source: permanent_id,
            error: crate::effects::ExecutionError::ContinuousDiscovery(error),
        })?;
    if specs.is_empty() {
        return Err(ActionError::NoSuchAbility);
    }
    let mut last_error = ActionError::CantPayCost;
    for spec in &specs {
        match can_pay_turn_face_up_spec(game, player, permanent_id, spec) {
            Ok(()) => return Ok(()),
            Err(err) => last_error = err,
        }
    }
    Err(last_error)
}

fn validate_turn_face_up_common(
    game: &GameState,
    player: PlayerId,
    permanent_id: ObjectId,
) -> Result<&crate::object::Object, ActionError> {
    // Must have priority to take a special action.
    if !game.team_has_priority(player) {
        return Err(ActionError::NotYourPriority);
    }

    // Check the permanent exists and is on the battlefield
    let object = game
        .object(permanent_id)
        .ok_or(ActionError::ObjectNotFound)?;
    if object.zone != Zone::Battlefield {
        return Err(ActionError::WrongZone {
            expected: Zone::Battlefield,
            actual: object.zone,
        });
    }

    if game.is_phased_out(permanent_id) {
        return Err(ActionError::InvalidTarget);
    }

    // Check the permanent is face-down
    if !game.is_face_down(permanent_id) {
        return Err(ActionError::NotFaceDown);
    }

    // Check the player controls the permanent
    if game.controller_of(object) != player {
        return Err(ActionError::InvalidTarget);
    }

    Ok(object)
}

fn can_pay_turn_face_up_spec(
    game: &GameState,
    player: PlayerId,
    permanent_id: ObjectId,
    spec: &TurnFaceUpSpec,
) -> Result<(), ActionError> {
    check_special_action_payment(
        game,
        player,
        &SpecialActionPayment {
            source: permanent_id,
            cost: adjusted_turn_face_up_cost(game, player, permanent_id, spec),
            reason: spec.method.payment_reason(),
        },
    )
}

fn validate_turn_face_up_with_method(
    game: &GameState,
    player: PlayerId,
    permanent_id: ObjectId,
    method: TurnFaceUpMethod,
) -> Result<(), ActionError> {
    let checked =
        game.continuous_query_snapshot()
            .map_err(|error| ActionError::ExecutionFailure {
                source: permanent_id,
                error: crate::effects::ExecutionError::ContinuousDiscovery(error),
            })?;
    let game = &checked;
    let object = validate_turn_face_up_common(game, player, permanent_id)?;
    if !game.can_turn_face_up_permanent(permanent_id) {
        return Err(ActionError::NoSuchAbility);
    }
    let Some(_spec) =
        turn_face_up_spec(game, object, method).map_err(|error| ActionError::ExecutionFailure {
            source: permanent_id,
            error: crate::effects::ExecutionError::ContinuousDiscovery(error),
        })?
    else {
        return Err(ActionError::NoSuchAbility);
    };
    Ok(())
}

fn finish_turn_face_up(
    game: &mut GameState,
    player: PlayerId,
    permanent_id: ObjectId,
    method: TurnFaceUpMethod,
    decision_maker: &mut impl crate::decision::DecisionMaker,
) -> Result<(), ActionError> {
    game.refresh_continuous_state()
        .map_err(|error| ActionError::ExecutionFailure {
            source: permanent_id,
            error: crate::effects::ExecutionError::ContinuousDiscovery(error),
        })?;
    validate_turn_face_up_common(game, player, permanent_id)?;
    if !game.can_turn_face_up_permanent(permanent_id) {
        return Err(ActionError::NoSuchAbility);
    }
    let spec = game
        .object(permanent_id)
        .ok_or(ActionError::ObjectNotFound)
        .and_then(|object| {
            turn_face_up_spec(game, object, method)
                .map_err(|error| ActionError::ExecutionFailure {
                    source: permanent_id,
                    error: crate::effects::ExecutionError::ContinuousDiscovery(error),
                })?
                .ok_or(ActionError::NoSuchAbility)
        })?;

    // Pay the morph/megamorph turn-face-up cost.
    let action_provenance = game.provenance_graph_mut().alloc_root(
        crate::provenance::ProvenanceNodeKind::EffectExecution {
            source: permanent_id,
            controller: player,
        },
    );

    let (turned, observations) = crate::effects::with_action_observations(game, |game| {
        let transition = crate::effects::permanents::turn_face_up_with_choices(
            game,
            permanent_id,
            crate::effects::permanents::FaceUpChoiceController::Actor(player),
            decision_maker,
        )?;
        if transition.is_none() {
            return Ok(false);
        }
        if decision_maker.awaiting_choice() {
            return Ok(true);
        }

        // CR 702.37b: megamorph puts a +1/+1 counter on the permanent; that is an
        // ordinary counter placement, so counter replacements apply and a
        // counter-placed event fires (CR 122.6, 614.1).
        if spec.megamorph && game.object(permanent_id).is_some() {
            let outcome = {
                let cause = crate::events::cause::EventCause::from_special_action(
                    Some(permanent_id),
                    player,
                );
                let event = crate::events::Event::put_counters(
                    permanent_id,
                    crate::object::CounterType::PlusOnePlusOne,
                    1,
                    cause.clone(),
                )
                .with_provenance(action_provenance);
                let mut ctx =
                    crate::effects::ExecutionContext::new(permanent_id, player, decision_maker)
                        .with_cause(cause);
                ctx.provenance = action_provenance;
                crate::effects::counters::execute_object_counter_placement(game, &mut ctx, event)
            }?;
            if decision_maker.awaiting_choice() {
                return Ok(true);
            }
            for event in outcome.events {
                game.queue_trigger_event(action_provenance, event);
            }
        }

        Ok(true)
    })
    .map_err(|error| ActionError::ExecutionFailure {
        source: permanent_id,
        error,
    })?;
    if !turned {
        return Err(ActionError::NoSuchAbility);
    }
    if decision_maker.awaiting_choice() {
        return Ok(());
    }

    if let Some(stable_id) = game.object(permanent_id).map(|o| o.stable_id) {
        game.record_ui_effect_event(
            "turned_face_up",
            Some(player),
            None,
            vec![stable_id],
            None,
            None,
        );
    }

    let event_provenance = game
        .alloc_child_event_provenance(action_provenance, crate::events::EventKind::TurnedFaceUp);
    let mut completed = vec![TriggerEvent::new_with_provenance(
        crate::events::TurnedFaceUpEvent::new(permanent_id, player),
        event_provenance,
    )];
    crate::effects::observe_lifecycle_completions_with_observations(
        game,
        &mut completed,
        &observations,
    )
    .map_err(|error| ActionError::ExecutionFailure {
        source: permanent_id,
        error,
    })?;
    for event in completed {
        game.queue_trigger_event(action_provenance, event);
    }

    Ok(())
}

// === Unlock Room Door ===

fn validate_unlock_room_door_common(
    game: &GameState,
    player: PlayerId,
    room_id: ObjectId,
) -> Result<(), ActionError> {
    has_sorcery_speed_special_action_timing(game, player)?;

    let room = game.object(room_id).ok_or(ActionError::ObjectNotFound)?;
    if room.zone != Zone::Battlefield {
        return Err(ActionError::WrongZone {
            expected: Zone::Battlefield,
            actual: room.zone,
        });
    }
    if game.controller_of(room) != player {
        return Err(ActionError::InvalidTarget);
    }
    if !game.room_has_locked_door(room_id) {
        return Err(ActionError::NoSuchAbility);
    }
    Ok(())
}

fn adjusted_room_unlock_cost(
    game: &GameState,
    player: PlayerId,
    room_id: ObjectId,
    door: RoomDoor,
) -> Result<crate::cost::TotalCost, ActionError> {
    let cost = room_unlock_cost(game, room_id, door).ok_or(ActionError::NoSuchAbility)?;
    let reduction = unlock_cost_reduction(game, player);
    let cost = if reduction > 0 {
        reduce_total_cost_generic(&cost, reduction)
    } else {
        cost
    };
    Ok(adjust_total_cost_mana_components_for_reason(
        game,
        player,
        room_id,
        &cost,
        crate::costs::PaymentReason::UnlockDoor,
    ))
}

fn can_unlock_room_door(
    game: &GameState,
    player: PlayerId,
    room_id: ObjectId,
    door: RoomDoor,
) -> Result<(), ActionError> {
    validate_unlock_room_door_common(game, player, room_id)?;
    adjusted_room_unlock_cost(game, player, room_id, door)?;
    Ok(())
}

/// Apply the Room state transition shared by the paid special action and
/// resolution-time effects that instruct a player to unlock a door.
pub(crate) fn apply_room_door_unlock(
    game: &mut GameState,
    room_id: ObjectId,
    door: RoomDoor,
) -> bool {
    if !locked_room_doors(game, room_id).contains(&door) {
        return false;
    }
    // CR 709.5d-e: with neither door unlocked, unlocking one gives only that
    // half its designation. The Room's current half becomes the unlocked one
    // (switching to the linked half first if that door was chosen).
    if game.room_has_no_unlocked_door(room_id) {
        if door == RoomDoor::Linked && !game.switch_room_to_linked_half(room_id) {
            return false;
        }
        return game.unlock_room_first_door(room_id);
    }
    let Some(locked_door) = room_locked_door_definition(game, room_id) else {
        return false;
    };
    let Some(room) = game.object_mut(room_id) else {
        return false;
    };
    room.apply_fused_split_spell_overlay(&locked_door);
    game.mark_room_fully_unlocked(room_id);
    true
}

/// The doors of a Room that are currently unlocked (CR 709.5c: only an
/// unlocked door can be locked).
pub fn unlocked_room_doors(game: &GameState, room_id: ObjectId) -> Vec<RoomDoor> {
    let is_room = game.object(room_id).is_some_and(|room| {
        room.zone == crate::zone::Zone::Battlefield
            && room.linked_face_layout == crate::card::LinkedFaceLayout::Split
    }) && room_locked_door_definition(game, room_id)
        .is_some_and(|def| def.card.subtypes.contains(&crate::types::Subtype::Room))
        && game.current_has_subtype(room_id, crate::types::Subtype::Room);
    if !is_room || game.room_has_no_unlocked_door(room_id) {
        return Vec::new();
    }
    if game.is_room_fully_unlocked(room_id) {
        vec![RoomDoor::Current, RoomDoor::Linked]
    } else {
        vec![RoomDoor::Current]
    }
}

/// CR 709.5c: lock an unlocked door of a Room. Locking is not a special
/// action and has no cost; it happens only as an effect instructs.
pub(crate) fn apply_room_door_lock(game: &mut GameState, room_id: ObjectId, door: RoomDoor) -> bool {
    if !unlocked_room_doors(game, room_id).contains(&door) {
        return false;
    }
    if game.is_room_fully_unlocked(room_id) {
        return game.lock_door_of_fully_unlocked_room(room_id, door == RoomDoor::Current);
    }
    game.lock_room_only_unlocked_door(room_id)
}

/// Unlock a Room door and build the resulting keyword-action events.
///
/// CR 709.5h: "when you unlock this door" triggers only for the door that got
/// its designation, so a second-door event records that door's triggered
/// abilities. CR 709.5i: unlocking the second door fully unlocks the Room.
pub(crate) fn unlock_room_door_with_events(
    game: &mut GameState,
    player: PlayerId,
    room_id: ObjectId,
    door: RoomDoor,
) -> Option<Vec<KeywordActionEvent>> {
    let second_door = !game.room_has_no_unlocked_door(room_id);
    let door_triggers = second_door.then(|| {
        room_locked_door_definition(game, room_id)
            .map(|definition| {
                definition
                    .abilities
                    .iter()
                    .filter_map(|ability| match &ability.kind {
                        crate::ability::AbilityKind::Triggered(triggered) => {
                            Some(crate::triggers::compute_trigger_identity(triggered))
                        }
                        _ => None,
                    })
                    .collect::<Vec<_>>()
            })
            .unwrap_or_default()
    });
    let abilities_before = game.object(room_id).map(|room| room.abilities.len());
    if !apply_room_door_unlock(game, room_id, door) {
        return None;
    }
    let abilities_after = game.object(room_id).map(|room| room.abilities.len());
    let mut unlock = KeywordActionEvent::new(
        crate::events::KeywordActionKind::UnlockDoor,
        player,
        room_id,
        1,
    );
    if let Some(door_triggers) = door_triggers {
        unlock = unlock.with_unlocked_door_triggers(door_triggers);
        if let (Some(before), Some(after)) = (abilities_before, abilities_after) {
            unlock = unlock.with_unlocked_door_ability_range(before..after);
        }
    }
    let mut events = vec![unlock];
    if second_door {
        events.push(KeywordActionEvent::new(
            crate::events::KeywordActionKind::FullyUnlockRoom,
            player,
            room_id,
            1,
        ));
    }
    Some(events)
}

fn perform_unlock_room_door(
    game: &mut GameState,
    player: PlayerId,
    room_id: ObjectId,
    door: RoomDoor,
    _decision_maker: &mut impl crate::decision::DecisionMaker,
) -> Result<(), ActionError> {
    validate_unlock_room_door_common(game, player, room_id)?;

    let action_provenance = game.provenance_graph_mut().alloc_root(
        crate::provenance::ProvenanceNodeKind::EffectExecution {
            source: room_id,
            controller: player,
        },
    );

    let Some(events) = unlock_room_door_with_events(game, player, room_id, door) else {
        return Err(ActionError::NoSuchAbility);
    };

    for event in events {
        let event_provenance = game.alloc_child_event_provenance(
            action_provenance,
            crate::events::EventKind::KeywordAction,
        );
        game.queue_trigger_event(
            action_provenance,
            TriggerEvent::new_with_provenance(event, event_provenance),
        );
    }
    Ok(())
}

// === Suspend ===

fn can_suspend(game: &GameState, player: PlayerId, card_id: ObjectId) -> Result<(), ActionError> {
    // Must have priority
    if !game.team_has_priority(player) {
        return Err(ActionError::NotYourPriority);
    }

    // Check the card exists and is in hand
    let object = game.object(card_id).ok_or(ActionError::ObjectNotFound)?;
    if object.zone != Zone::Hand {
        return Err(ActionError::WrongZone {
            expected: Zone::Hand,
            actual: object.zone,
        });
    }

    // Check the player owns the card
    if object.owner != player {
        return Err(ActionError::InvalidTarget);
    }

    let Some((time, cost)) = suspend_spec(object) else {
        return Err(ActionError::NoSuchAbility);
    };
    if let Some(minimum) = time.minimum_x() {
        let cost = crate::mana::ManaCost::from_pips(GameState::expanded_payment_pips(
            &cost, minimum, false,
        ));
        check_special_action_payment(
            game,
            player,
            &SpecialActionPayment {
                source: card_id,
                cost: crate::cost::TotalCost::mana(cost),
                reason: crate::costs::PaymentReason::Other,
            },
        )?;
    }

    if !crate::decision::can_begin_to_cast_from_hand_for_suspend(game, player, object) {
        return Err(ActionError::InvalidTiming);
    }

    Ok(())
}

fn perform_suspend(
    game: &mut GameState,
    player: PlayerId,
    card_id: ObjectId,
    announced_x: Option<u32>,
    decision_maker: &mut impl crate::decision::DecisionMaker,
) -> Result<(), ActionError> {
    let (time, counter_type) = {
        let object = game.object(card_id).ok_or(ActionError::ObjectNotFound)?;
        let (time, _cost) = suspend_spec(object).ok_or(ActionError::NoSuchAbility)?;
        let counter_type = object.alternative_casts.iter()
            .find(|method| method.suspend_spec().is_some())
            .map(|method| method.timed_exile_counter())
            .unwrap_or(crate::object::CounterType::Time);
        (time, counter_type)
    };
    let time = time
        .resolve(announced_x)
        .ok_or(ActionError::InvalidTarget)?;

    // Move to exile
    let new_id = game
        .move_object(
            card_id,
            Zone::Exile,
            crate::events::cause::EventCause::from_special_action(Some(card_id), player),
        )
        .ok_or(ActionError::ObjectNotFound)?;
    let action_provenance = game.provenance_graph_mut().alloc_root(
        crate::provenance::ProvenanceNodeKind::EffectExecution {
            source: new_id,
            controller: player,
        },
    );
    let cause = crate::events::cause::EventCause::from_special_action(Some(new_id), player);
    let event = crate::events::Event::put_counters(
        new_id,
        counter_type,
        time,
        cause.clone(),
    )
    .with_provenance(action_provenance);
    let outcome = {
        let mut ctx =
            crate::effects::ExecutionContext::new(new_id, player, decision_maker).with_cause(cause);
        ctx.provenance = action_provenance;
        crate::effects::counters::execute_object_counter_placement(game, &mut ctx, event)
    }
    .map_err(|error| ActionError::ExecutionFailure {
        source: card_id,
        error,
    })?;
    if decision_maker.awaiting_choice() {
        return Ok(());
    }
    for event in outcome.events {
        game.queue_trigger_event(action_provenance, event);
    }
    Ok(())
}

// === Foretell ===

/// One checked quote for live special-action pricing and timing. Current
/// control and layer-applied abilities matter; phased-out objects do not exist
/// for this query. Ordinary spell reductions do not affect this special action.
fn foretell_special_action_quote(
    game: &GameState,
    player: PlayerId,
    card_id: ObjectId,
) -> Result<(crate::mana::ManaCost, bool), ActionError> {
    if let Some(price) = game.object(card_id).and_then(|object| object.alternative_casts.iter().find_map(|method| match method.exile_preparation() {
        Some(ironsmith_core::alternative_cast_model::ExilePreparation::FaceDown { price }) => Some(price.clone()), _ => None,
    })) { return Ok((price, false)); }
    let checked =
        game.continuous_query_snapshot()
            .map_err(|error| ActionError::ExecutionFailure {
                source: card_id,
                error: crate::effects::ExecutionError::ContinuousDiscovery(error),
            })?;
    let mut reduction = 0u32;
    let mut any_turn = false;
    for source in checked.battlefield.iter().copied() {
        if checked.is_phased_out(source) {
            continue;
        }
        let Some(object) = checked.object(source) else {
            return Err(ActionError::ExecutionFailure {
                source,
                error: crate::effects::ExecutionError::IncompleteEvidence(
                    "battlefield foretell provider is unavailable".into(),
                ),
            });
        };
        if checked.controller_of(object) != player {
            continue;
        }
        let abilities =
            checked
                .current_abilities(source)
                .ok_or_else(|| ActionError::ExecutionFailure {
                    source,
                    error: crate::effects::ExecutionError::IncompleteEvidence(
                        "foretell provider abilities are unavailable".into(),
                    ),
                })?;
        for ability in abilities {
            if !ability.functions_in(&Zone::Battlefield) {
                continue;
            }
            if let crate::ability::AbilityKind::Static(rule) = &ability.kind
                && let Some((amount, timing)) = rule.foretell_special_action_modifier()
                && !(rule.foretell_special_action_first_each_turn()
                    && game.has_foretold_this_turn(player))
            {
                reduction = reduction.saturating_add(amount);
                any_turn |= timing;
            }
        }
    }
    Ok((
        crate::mana::ManaCost::new()
            .add_generic(2)
            .reduce_generic(reduction),
        any_turn,
    ))
}

fn can_foretell(game: &GameState, player: PlayerId, card_id: ObjectId) -> Result<(), ActionError> {
    // A live special-action modifier can expand the ordinary turn restriction.
    if !game.is_active_player(player) && !foretell_special_action_quote(game, player, card_id)?.1 {
        return Err(ActionError::NotActivePlayer);
    }

    // Must have priority
    if !game.team_has_priority(player) {
        return Err(ActionError::NotYourPriority);
    }

    // Check the card exists and is in hand
    let object = game.object(card_id).ok_or(ActionError::ObjectNotFound)?;
    if object.zone != Zone::Hand {
        return Err(ActionError::WrongZone {
            expected: Zone::Hand,
            actual: object.zone,
        });
    }

    // Check the player owns the card
    if object.owner != player {
        return Err(ActionError::InvalidTarget);
    }

    // The explicit action is a public foretell claim. Peers holding only a
    // committed placeholder validate its keyword when the card is opened.
    if foretell_cost(object).is_none()
        && !game.is_hidden_card_placeholder(card_id)
        && granted_hand_foretell_cost(game, player, card_id).is_none()
    {
        return Err(ActionError::NoSuchAbility);
    }

    // CR 702.143a: a player may foretell any number of cards during their turn.
    Ok(())
}

fn perform_foretell(
    game: &mut GameState,
    player: PlayerId,
    card_id: ObjectId,
) -> Result<(), ActionError> {
    let descriptive = game.object(card_id).is_some_and(|object| object.alternative_casts.iter().any(|method| method.exile_preparation().is_some()));
    // A granted foretell cost is fixed as the card is foretold: the card
    // keeps it in exile even if the granting permanent leaves (CR 702.143).
    let granted_cost = match game.object(card_id) {
        Some(object) if foretell_cost(object).is_none() => {
            granted_hand_foretell_cost(game, player, card_id)
        }
        _ => None,
    };
    // Move to exile face-down
    let new_id = game
        .move_object(
            card_id,
            Zone::Exile,
            crate::events::cause::EventCause::from_special_action(Some(card_id), player),
        )
        .ok_or(ActionError::ObjectNotFound)?;

    // Mark as face-down (foretold)
    game.set_face_down(new_id);
    game.grant_face_down_exile_view(new_id, player);
    game.set_foretold(new_id);
    if descriptive { game.mark_descriptive_exile_preparation(new_id); }
    if !descriptive { game.record_foretell_action(player); }
    if let Some(cost) = granted_cost
        && let Some(object) = game.object_mut(new_id)
    {
        object
            .alternative_casts
            .push(crate::alternative_cast::AlternativeCastingMethod::Foretell { cost });
    }

    if descriptive { return Ok(()); }
    // "Whenever you foretell a card" (CR 702.143a): the special action is the
    // keyword action that triggers.
    let action_provenance = game.provenance_graph_mut().alloc_root(
        crate::provenance::ProvenanceNodeKind::EffectExecution {
            source: new_id,
            controller: player,
        },
    );
    let event_provenance = game
        .alloc_child_event_provenance(action_provenance, crate::events::EventKind::KeywordAction);
    game.queue_trigger_event(
        action_provenance,
        TriggerEvent::new_with_provenance(
            KeywordActionEvent::new(crate::events::KeywordActionKind::Foretell, player, new_id, 1),
            event_provenance,
        ),
    );

    Ok(())
}

// === Plot ===

fn can_plot(game: &GameState, player: PlayerId, card_id: ObjectId) -> Result<(), ActionError> {
    has_sorcery_speed_special_action_timing(game, player)?;

    let object = game.object(card_id).ok_or(ActionError::ObjectNotFound)?;
    if object.zone != Zone::Hand && !plots_from_top_of_library(game, player, object) {
        return Err(ActionError::WrongZone {
            expected: Zone::Hand,
            actual: object.zone,
        });
    }
    if object.owner != player {
        return Err(ActionError::InvalidTarget);
    }

    let Some(_cost) = plot_cost_for(game, player, object) else {
        return Err(ActionError::NoSuchAbility);
    };

    Ok(())
}

fn perform_plot(
    game: &mut GameState,
    player: PlayerId,
    card_id: ObjectId,
) -> Result<(), ActionError> {
    let descriptive = game.object(card_id).is_some_and(|object| object.alternative_casts.iter().any(|method| method.exile_preparation().is_some()));
    let action_provenance = game.provenance_graph_mut().alloc_root(
        crate::provenance::ProvenanceNodeKind::EffectExecution {
            source: card_id,
            controller: player,
        },
    );

    let new_id = game
        .move_object(
            card_id,
            Zone::Exile,
            crate::events::cause::EventCause::from_special_action(Some(card_id), player),
        )
        .ok_or(ActionError::ObjectNotFound)?;
    game.set_plotted(new_id, player);
    if descriptive { game.mark_descriptive_exile_preparation(new_id); }
    if descriptive { return Ok(()); }
    let event_provenance = game
        .alloc_child_event_provenance(action_provenance, crate::events::EventKind::KeywordAction);
    game.queue_trigger_event(
        action_provenance,
        TriggerEvent::new_with_provenance(
            KeywordActionEvent::new(crate::events::KeywordActionKind::Plot, player, new_id, 1),
            event_provenance,
        ),
    );
    Ok(())
}

// === Activate Mana Ability ===

/// Convert a CostPaymentError to an ActionError.
fn cost_error_to_action_error(err: CostPaymentError, source: ObjectId) -> ActionError {
    match err {
        CostPaymentError::SourceNotFound => ActionError::ObjectNotFound,
        CostPaymentError::PlayerNotFound => ActionError::PlayerNotFound,
        CostPaymentError::AlreadyTapped => ActionError::CantPayCost,
        CostPaymentError::SummoningSickness => ActionError::SummoningSickness,
        CostPaymentError::AlreadyUntapped => ActionError::CantPayCost,
        CostPaymentError::Cancelled => ActionError::Cancelled,
        CostPaymentError::InsufficientMana => ActionError::CantPayCost,
        CostPaymentError::InsufficientLife => ActionError::CantPayCost,
        CostPaymentError::SourceNotOnBattlefield => ActionError::CantPayCost,
        CostPaymentError::NoValidSacrificeTarget => ActionError::CantPayCost,
        CostPaymentError::NotEnoughLegalModes => ActionError::CantPayCost,
        CostPaymentError::NotEnoughObjects => ActionError::CantPayCost,
        CostPaymentError::InsufficientCardsInHand => ActionError::CantPayCost,
        CostPaymentError::InsufficientCounters => ActionError::CantPayCost,
        CostPaymentError::InsufficientEnergy => ActionError::CantPayCost,
        CostPaymentError::InsufficientCardsToExile => ActionError::CantPayCost,
        CostPaymentError::InsufficientCardsInGraveyard => ActionError::CantPayCost,
        CostPaymentError::NoValidReturnTarget => ActionError::CantPayCost,
        CostPaymentError::InsufficientCardsToReveal => ActionError::CantPayCost,
        CostPaymentError::ExecutionFailed(error) => ActionError::ExecutionFailure { source, error },
        CostPaymentError::Other(_) => ActionError::CantPayCost,
    }
}

/// "Activate only as an instant" (Lion's Eye Diamond): the ability can be
/// activated only when its controller could cast an instant, which is while
/// holding priority and never in the middle of casting a spell, activating an
/// ability or paying a cost (CR 602.5d, 605.3a).
pub(crate) fn activation_restricted_to_instant_timing(
    activated: &crate::ability::ActivatedAbility,
) -> bool {
    fn condition_requires_instant_timing(condition: &crate::ConditionExpr) -> bool {
        match condition {
            // An explicit any-time timing condition is only ever authored by
            // "Activate only as an instant"; definitions compiled before the
            // typed `AsInstant` timing existed carry it in this form.
            crate::ConditionExpr::ActivationTiming(
                crate::ability::ActivationTiming::AsInstant
                | crate::ability::ActivationTiming::AnyTime,
            ) => true,
            crate::ConditionExpr::And(left, right) => {
                condition_requires_instant_timing(left) || condition_requires_instant_timing(right)
            }
            _ => false,
        }
    }
    activated.timing == crate::ability::ActivationTiming::AsInstant
        || activated
            .activation_condition
            .as_ref()
            .is_some_and(condition_requires_instant_timing)
        || activated
            .activation_restrictions
            .iter()
            .any(condition_requires_instant_timing)
}

fn can_activate_mana_ability_with_cost_checks(
    game: &GameState,
    player: PlayerId,
    permanent_id: ObjectId,
    ability_index: usize,
    mut check_costs: impl FnMut(&crate::ability::ActivatedAbility) -> Result<(), ActionError>,
) -> Result<(), ActionError> {
    let object = game
        .object(permanent_id)
        .ok_or(ActionError::ObjectNotFound)?;

    // Rule restriction: activated abilities of this permanent can't be
    // activated, or this player can't activate abilities at all (CR 602.5).
    if !game.can_activate_abilities_of(permanent_id) || !game.can_activate_abilities(player) {
        return Err(ActionError::CantPayCost);
    }

    // Check the ability exists and is a mana ability
    let ability = game
        .current_ability(permanent_id, ability_index)
        .ok_or(ActionError::NoSuchAbility)?;

    let prepared = crate::activation_zone_permissions::prepare_occurrence(game, permanent_id, ability_index, &ability);
    let ability = prepared.as_ref().unwrap_or(&ability);
    // Check the ability functions in this zone
    if !ability.functions_in(&object.zone) {
        return Err(ActionError::WrongZone {
            expected: Zone::Battlefield,
            actual: object.zone,
        });
    }

    // Check if the cost can be paid
    let crate::ability::AbilityKind::Activated(mana_ability) = &ability.kind else {
        return Err(ActionError::NoSuchAbility);
    };
    if game.controller_of(object) != player
        && !mana_ability.allows_any_player_to_activate()
        && !game.may_tap_uncontrolled_land_for_mana(player, permanent_id, mana_ability)
    {
        return Err(ActionError::InvalidTarget);
    }
    if !mana_ability.is_runtime_mana_ability(game, permanent_id, player) {
        return Err(ActionError::NoSuchAbility);
    }
    let view = crate::derived_view::DerivedGameView::new(game);
    if !crate::decision::exhaust_activation_allows(
        game,
        player,
        permanent_id,
        ability_index,
        mana_ability,
        &view,
    ) {
        return Err(ActionError::CantPayCost);
    }
    if !crate::decision::activation_timing_allows(
        game,
        player,
        permanent_id,
        ability_index,
        mana_ability,
        &view,
        &mana_ability.timing,
    ) {
        return Err(ActionError::CantPayCost);
    }
    if mana_ability.has_tap_cost() && !game.can_activate_tap_abilities_of(permanent_id)
        && !crate::decision::ActivationCostAbility::at(game, player, permanent_id, ability_index)
            .is_some_and(|facts| crate::activation_cost_alternatives::has_available_alternative(game, permanent_id, facts, &mana_ability.mana_cost)) {
        return Err(ActionError::CantPayCost);
    }
    check_costs(mana_ability)?;

    // Check activation condition if present
    if let Some(condition) = &mana_ability.activation_condition
        && !check_mana_ability_condition(game, player, permanent_id, ability_index, condition)
    {
        return Err(ActionError::CantPayCost);
    }

    Ok(())
}

fn can_activate_mana_ability(
    game: &GameState,
    player: PlayerId,
    permanent_id: ObjectId,
    ability_index: usize,
    decision_maker: &mut impl crate::decision::DecisionMaker,
) -> Result<(), ActionError> {
    can_activate_mana_ability_with_cost_checks(
        game,
        player,
        permanent_id,
        ability_index,
        |mana_ability| {
            let total_cost = crate::decision::calculate_effective_activation_total_cost_for_ability(
                game,
                player,
                permanent_id,
                &mana_ability.mana_cost,
                &[],
                crate::decision::ActivationCostAbility::at(game, player, permanent_id, ability_index),
            );
            let view = crate::derived_view::DerivedGameView::new(game);
            let mut execution = ExecutionContext::new(permanent_id, player, decision_maker);
            can_potentially_pay_total_cost_in_context_with_view(
                game,
                player,
                permanent_id,
                &total_cost,
                mana_ability.payment_reason(game, permanent_id, player),
                &mut execution,
                &view,
            )
            .map_err(|error| cost_error_to_action_error(error, permanent_id))?;
            Ok(())
        },
    )
}

/// Check if a mana ability can be activated (for query/legality checks).
///
/// This variant doesn't require a decision_maker because it only checks costs.
pub(crate) fn can_activate_mana_ability_check(
    game: &GameState,
    player: PlayerId,
    permanent_id: ObjectId,
    ability_index: usize,
) -> Result<(), ActionError> {
    let view = crate::derived_view::DerivedGameView::new(game);
    let ability = game
        .current_ability(permanent_id, ability_index)
        .ok_or(ActionError::NoSuchAbility)?;
    can_activate_mana_ability_check_with_view(
        game,
        player,
        permanent_id,
        ability_index,
        &ability,
        &view,
        None,
    )
}

thread_local! {
    /// Mana abilities whose activation-cost payability is currently being
    /// checked. Checking whether a mana cost is payable enumerates available
    /// mana sources, which re-checks each source's own activation cost — a
    /// mana ability with a mana cost (Blood Celebrant's "{B}, Pay 1 life:
    /// Add one mana of any color") would recurse through itself forever.
    /// Re-entry for an ability already on the check stack is treated as
    /// unpayable: a source can't fund its own activation.
    static IN_PROGRESS_MANA_ABILITY_COST_CHECKS: std::cell::RefCell<
        std::collections::HashSet<(ObjectId, usize)>,
    > = std::cell::RefCell::new(std::collections::HashSet::new());
}

struct ManaAbilityCostCheckGuard(ObjectId, usize);

impl ManaAbilityCostCheckGuard {
    fn enter(permanent_id: ObjectId, ability_index: usize) -> Option<Self> {
        // Release the RefCell borrow before constructing the guard: an eager
        // `then_some(Self(..))` would build and immediately drop a guard on
        // the re-entry path, and its Drop re-borrows the same RefCell.
        let inserted = IN_PROGRESS_MANA_ABILITY_COST_CHECKS
            .with(|checks| checks.borrow_mut().insert((permanent_id, ability_index)));
        inserted.then(|| Self(permanent_id, ability_index))
    }
}

impl Drop for ManaAbilityCostCheckGuard {
    fn drop(&mut self) {
        IN_PROGRESS_MANA_ABILITY_COST_CHECKS.with(|checks| {
            checks.borrow_mut().remove(&(self.0, self.1));
        });
    }
}

pub(crate) fn can_activate_mana_ability_check_with_view(
    game: &GameState,
    player: PlayerId,
    permanent_id: ObjectId,
    ability_index: usize,
    ability: &crate::ability::Ability,
    view: &crate::derived_view::DerivedGameView<'_>,
    perf_ctx: Option<&crate::decision::BattlefieldAbilityContext>,
) -> Result<(), ActionError> {
    can_activate_mana_ability_check_for_payment_with_view(
        game,
        player,
        permanent_id,
        ability_index,
        ability,
        view,
        perf_ctx,
        None,
    )
}

pub(crate) fn can_activate_mana_ability_check_for_payment_with_view(
    game: &GameState,
    player: PlayerId,
    permanent_id: ObjectId,
    ability_index: usize,
    ability: &crate::ability::Ability,
    view: &crate::derived_view::DerivedGameView<'_>,
    perf_ctx: Option<&crate::decision::BattlefieldAbilityContext>,
    payment: Option<&crate::mana_payment::ManaPaymentRequest>,
) -> Result<(), ActionError> {
    let prepared = crate::activation_zone_permissions::prepare_occurrence(game, permanent_id, ability_index, ability);
    let ability = prepared.as_ref().unwrap_or(ability);
    let object = game
        .object(permanent_id)
        .ok_or(ActionError::ObjectNotFound)?;

    if game.has_active_mana_ability_on(permanent_id) {
        let locked = view.calculated_characteristics_arc(permanent_id)
            .and_then(|chars| chars.abilities.origin(ability_index).cloned())
            .is_none_or(|origin| game.mana_ability_occurrence_is_active(permanent_id, &origin));
        if locked { return Err(ActionError::CantPayCost); }
    }

    let precheck_started_at = crate::perf::PerfTimer::start();
    if !game.can_activate_abilities_of(permanent_id) || !game.can_activate_abilities(player) {
        if let Some(perf_ctx) = perf_ctx {
            perf_ctx.add_precheck_ms(precheck_started_at.elapsed_ms());
        }
        return Err(ActionError::CantPayCost);
    }

    let crate::ability::AbilityKind::Activated(mana_ability) = &ability.kind else {
        return Err(ActionError::NoSuchAbility);
    };
    if game.controller_of(object) != player
        && !mana_ability.allows_any_player_to_activate()
        && !game.may_tap_uncontrolled_land_for_mana(player, permanent_id, mana_ability)
    {
        return Err(ActionError::InvalidTarget);
    }
    if !mana_ability.is_runtime_mana_ability(game, permanent_id, player) {
        if let Some(perf_ctx) = perf_ctx {
            perf_ctx.add_precheck_ms(precheck_started_at.elapsed_ms());
        }
        return Err(ActionError::NoSuchAbility);
    }

    if !crate::decision::exhaust_activation_allows(
        game,
        player,
        permanent_id,
        ability_index,
        mana_ability,
        view,
    ) {
        return Err(ActionError::CantPayCost);
    }
    if !crate::decision::activation_timing_allows(
        game,
        player,
        permanent_id,
        ability_index,
        mana_ability,
        view,
        &mana_ability.timing,
    ) {
        if let Some(perf_ctx) = perf_ctx {
            perf_ctx.add_precheck_ms(precheck_started_at.elapsed_ms());
        }
        return Err(ActionError::CantPayCost);
    }

    if !ability.functions_in(&object.zone) {
        if let Some(perf_ctx) = perf_ctx {
            perf_ctx.add_precheck_ms(precheck_started_at.elapsed_ms());
        }
        return Err(ActionError::WrongZone {
            expected: Zone::Battlefield,
            actual: object.zone,
        });
    }

    if mana_ability.has_tap_cost() && !game.can_activate_tap_abilities_of(permanent_id)
        && !crate::decision::ActivationCostAbility::at(game, player, permanent_id, ability_index)
            .is_some_and(|facts| crate::activation_cost_alternatives::has_available_alternative(game, permanent_id, facts, &mana_ability.mana_cost)) {
        if let Some(perf_ctx) = perf_ctx {
            perf_ctx.add_precheck_ms(precheck_started_at.elapsed_ms());
        }
        return Err(ActionError::CantPayCost);
    }

    if let Some(perf_ctx) = perf_ctx {
        perf_ctx.add_precheck_ms(precheck_started_at.elapsed_ms());
    }

    let Some(_cost_check_guard) = ManaAbilityCostCheckGuard::enter(permanent_id, ability_index)
    else {
        return Err(ActionError::CantPayCost);
    };

    let has_activation_cost_modifiers = perf_ctx
        .map(crate::decision::BattlefieldAbilityContext::has_activation_cost_modifiers)
        .unwrap_or_else(|| view.has_activated_ability_cost_modifiers())
        || !game.effect_store.activation_cost_alternatives.is_empty();
    let cost_started_at = crate::perf::PerfTimer::start();
    let total_cost = if has_activation_cost_modifiers {
        crate::decision::calculate_effective_activation_total_cost_with_view(
            game,
            player,
            permanent_id,
            &mana_ability.mana_cost,
            &[],
            crate::decision::ActivationCostAbility::at(game, player, permanent_id, ability_index),
            view,
        )
    } else {
        mana_ability.mana_cost.clone()
    };
    if let Some(perf_ctx) = perf_ctx {
        perf_ctx.add_cost_build_ms(cost_started_at.elapsed_ms());
    }
    let affordability_started_at = crate::perf::PerfTimer::start();
    let mut decision_maker = crate::decision::SelectFirstDecisionMaker;
    let mut execution = ExecutionContext::new(permanent_id, player, &mut decision_maker);
    can_pay_total_cost_in_context_with_funding(
        game,
        player,
        permanent_id,
        &total_cost,
        mana_ability.payment_reason(game, permanent_id, player),
        &mut execution,
        CostQueryFunding::PotentialMana(view, payment),
    )
    .map_err(|error| cost_error_to_action_error(error, permanent_id))?;
    if let Some(perf_ctx) = perf_ctx {
        perf_ctx.add_affordability_ms(affordability_started_at.elapsed_ms());
    }

    if let Some(condition) = &mana_ability.activation_condition
        && !check_mana_ability_condition(game, player, permanent_id, ability_index, condition)
    {
        return Err(ActionError::CantPayCost);
    }

    Ok(())
}

/// Check if a mana ability's activation condition is met.
fn check_mana_ability_condition(
    game: &GameState,
    player: PlayerId,
    source: ObjectId,
    ability_index: usize,
    condition: &crate::ConditionExpr,
) -> bool {
    let eval_ctx = crate::condition_eval::ExternalEvaluationContext {
        controller: player,
        source,
        defending_player: None,
        attacking_player: None,
        filter_source: Some(source),
        iterated_player: None,
        triggering_event: None,
        trigger_identity: None,
        ability_index: Some(ability_index),
        options: crate::condition_eval::ExternalEvaluationOptions::default(),
    };
    crate::condition_eval::evaluate_condition_external(game, condition, &eval_ctx)
}

pub(crate) fn mana_production_provenance_for_activation_cost(
    cost: &crate::cost::TotalCost,
) -> crate::events::mana::ManaProductionProvenance {
    fn cost_taps_source(cost: &crate::cost::TotalCost) -> bool {
        match cost.kind() {
            ironsmith_core::TotalCostKind::All(costs) => {
                costs.iter().any(|cost| cost.requires_tap())
            }
            ironsmith_core::TotalCostKind::OneOf(branches) => {
                !branches.is_empty() && branches.iter().all(cost_taps_source)
            }
        }
    }

    if cost_taps_source(cost) {
        crate::events::mana::ManaProductionProvenance::TappedSourceForMana
    } else {
        crate::events::mana::ManaProductionProvenance::ManaAbility
    }
}

pub fn perform_activate_mana_ability(
    game: &mut GameState,
    player: PlayerId,
    permanent_id: ObjectId,
    ability_index: usize,
    decision_maker: &mut dyn crate::decision::DecisionMaker,
) -> Result<(), ActionError> {
    perform_activate_mana_ability_restricted_colors(
        game,
        player,
        permanent_id,
        ability_index,
        None,
        decision_maker,
    )
}

pub fn perform_activate_mana_ability_restricted_colors(
    game: &mut GameState,
    player: PlayerId,
    permanent_id: ObjectId,
    ability_index: usize,
    mana_color_restriction: Option<Vec<crate::color::Color>>,
    decision_maker: &mut dyn crate::decision::DecisionMaker,
) -> Result<(), ActionError> {
    perform_activate_mana_ability_restricted_colors_with_outputs(
        game,
        player,
        permanent_id,
        ability_index,
        mana_color_restriction,
        decision_maker,
    )
    .map(|_| ())
}

/// Queue the original native event projection once and preserve the actual
/// prepared notification and payment/production children for its caller.
pub(crate) fn perform_activate_mana_ability_restricted_colors_with_outputs(
    game: &mut GameState,
    player: PlayerId,
    permanent_id: ObjectId,
    ability_index: usize,
    mana_color_restriction: Option<Vec<crate::color::Color>>,
    decision_maker: &mut dyn crate::decision::DecisionMaker,
) -> Result<CompletedManaActivation, ActionError> {
    let mut completed = perform_mana_ability_with_payment_outputs(
        game,
        player,
        permanent_id,
        ability_index,
        mana_color_restriction,
        None,
        Vec::new(),
        decision_maker,
    )?;
    // This is the same projection queued by the scalar facade. Cost-owned
    // events remain in their actual packets and are not emitted again.
    for event in completed.events.drain(..) {
        game.queue_trigger_event(event.provenance(), event);
    }
    Ok(completed)
}

pub(crate) fn perform_activate_mana_ability_restricted_colors_with_events(
    game: &mut GameState,
    player: PlayerId,
    permanent_id: ObjectId,
    ability_index: usize,
    mana_color_restriction: Option<Vec<crate::color::Color>>,
    decision_maker: &mut dyn crate::decision::DecisionMaker,
) -> Result<Vec<crate::triggers::TriggerEvent>, ActionError> {
    perform_mana_ability_with_payment_mode(
        game,
        player,
        permanent_id,
        ability_index,
        mana_color_restriction,
        None,
        Vec::new(),
        decision_maker,
    )
}

/// Select an original alternative branch, announce X, then determine its
/// total exactly once. Both root/pending and planner/direct mana owners use
/// this procedure before flattening components or paying any resource.
pub(crate) fn prepare_mana_activation_cost(
    game: &GameState,
    player: PlayerId,
    source: ObjectId,
    ability_index: usize,
    activated: &crate::ability::ActivatedAbility,
    decision_maker: &mut dyn DecisionMaker,
) -> Result<Option<(crate::cost::TotalCost, Option<u32>)>, ActionError> {
    let prepared = crate::activation_zone_permissions::prepare(game, source, ability_index, activated);
    let activated = prepared.as_ref().unwrap_or(activated);
    let mut facts = crate::decision::ActivationCostAbility::of(game, player, source, activated);
    facts.ability_index = Some(ability_index);
    let mut original = crate::activation_cost_alternatives::unpriced_cost(game, source, facts, &activated.mana_cost, &crate::derived_view::DerivedGameView::new(game));
    while let Some(branches) = original.as_one_of() {
        let priced: Vec<_> = branches
            .iter()
            .map(|branch| {
                crate::decision::calculate_effective_activation_selected_branch_cost(
                    game,
                    player,
                    source,
                    branch,
                    &[],
                    Some(facts),
                )
            })
            .collect();
        let mut payable = Vec::new();
        for (index, price) in priced.iter().enumerate() {
            if crate::cost::prospective_references::activation_branch_preflight_checked(
                game,
                source,
                ability_index,
                player,
                None,
                price,
            )
            .map_err(|error| ActionError::ExecutionFailure { source, error })?
            {
                payable.push(index);
            }
        }
        let selected =
            choose_payable_branch(game, player, source, &priced, &payable, decision_maker);
        if decision_maker.awaiting_choice() {
            return Ok(None);
        }
        let selected = selected
            .map_err(|error| cost_error_to_action_error(error, source))?
            .ok_or(ActionError::CantPayCost)?;
        original = branches[selected].clone();
    }
    let mut announced_x = None;
    if let Some(maximum) =
        crate::decision::maximum_x_for_activation_cost(game, player, source, &original, &[], facts)
            .map_err(|error| ActionError::ExecutionFailure { source, error })?
    {
        let minimum = activated.activation_x_minimum();
        if maximum < minimum {
            return Err(ActionError::CantPayCost);
        }
        let mut context = crate::decisions::context::NumberContext::x_value_with_min(
            player, source, minimum, maximum,
        );
        let chosen = decision_maker.decide_number(game, &context);
        if decision_maker.awaiting_choice() {
            return Ok(None);
        }
        if chosen < minimum || chosen > maximum {
            return Err(ActionError::InvalidTarget);
        }
        announced_x = Some(chosen);
        original = crate::decision::activation_cost_with_locked_x(&original, chosen);
    }
    let priced = crate::decision::calculate_effective_activation_selected_branch_cost(
        game,
        player,
        source,
        &original,
        &[],
        Some(facts),
    );
    Ok(Some((priced, announced_x)))
}

/// Native activation receipts keep full completed children alongside only
/// the events its callers still need to queue. Payment events already owned
/// by costs must not be emitted a second time through this projection.
#[derive(Default)]
pub(crate) struct CompletedManaActivation {
    /// Captured effective acquisition and exact pre-cost source; no notification
    /// occurrence is allocated until the caller reaches its publication boundary.
    pub activation_notification: Option<crate::events::AbilityActivatedEvent>,
    pub events: Vec<TriggerEvent>,
    pub outputs: Vec<crate::effects::CompletedEffectOutputs>,
}

pub(crate) fn perform_mana_ability_with_payment_mode(
    game: &mut GameState,
    player: PlayerId,
    permanent_id: ObjectId,
    ability_index: usize,
    mana_color_restriction: Option<Vec<crate::color::Color>>,
    interactive_mana_exclusions: Option<Vec<ObjectId>>,
    reserved_tap_sources: Vec<ObjectId>,
    decision_maker: &mut dyn DecisionMaker,
) -> Result<Vec<TriggerEvent>, ActionError> {
    perform_mana_ability_with_payment_outputs(
        game,
        player,
        permanent_id,
        ability_index,
        mana_color_restriction,
        interactive_mana_exclusions,
        reserved_tap_sources,
        decision_maker,
    )
    .map(|completed| completed.events)
}

pub(crate) fn perform_mana_ability_with_payment_outputs(
    game: &mut GameState,
    player: PlayerId,
    permanent_id: ObjectId,
    ability_index: usize,
    mana_color_restriction: Option<Vec<crate::color::Color>>,
    interactive_mana_exclusions: Option<Vec<ObjectId>>,
    reserved_tap_sources: Vec<ObjectId>,
    decision_maker: &mut dyn DecisionMaker,
) -> Result<CompletedManaActivation, ActionError> {
    perform_mana_ability_with_cost_policy(game, player, permanent_id, ability_index,
        mana_color_restriction, interactive_mana_exclusions, reserved_tap_sources, false, decision_maker)
}

/// Use the ordinary immediate mana-activation consumer with every cost waived.
/// The caller has already checked the selected occurrence's non-cost legality.
pub(crate) fn perform_mana_ability_without_activation_costs(
    game: &mut GameState, player: PlayerId, source: ObjectId, ability_index: usize,
    decision_maker: &mut dyn DecisionMaker,
) -> Result<CompletedManaActivation, ActionError> {
    perform_mana_ability_with_cost_policy(game, player, source, ability_index,
        None, None, Vec::new(), true, decision_maker)
}

fn perform_mana_ability_with_cost_policy(
    game: &mut GameState, player: PlayerId, permanent_id: ObjectId, ability_index: usize,
    mana_color_restriction: Option<Vec<crate::color::Color>>,
    interactive_mana_exclusions: Option<Vec<ObjectId>>, reserved_tap_sources: Vec<ObjectId>,
    waive_all_costs: bool, decision_maker: &mut dyn DecisionMaker,
) -> Result<CompletedManaActivation, ActionError> {
    let mut transaction_ctx =
        crate::effects::ExecutionContext::new(permanent_id, player, decision_maker);
    let mut active_guard = None;
    let result = crate::effects::composition::execute_transaction(
        game,
        &mut transaction_ctx,
        CompletedManaActivation::default,
        |game, ctx| {
            let decision_maker = &mut *ctx.decision_maker;
            use crate::effects::ExecutionContext;

            // Get the mana ability details
            let source_snapshot = {
                let object = game
                    .object(permanent_id)
                    .ok_or(ActionError::ObjectNotFound)?;
                crate::snapshot::ObjectSnapshot::from_object_with_calculated_characteristics(
                    object, game,
                )
            };
            let ability = game
                .current_ability(permanent_id, ability_index)
                .ok_or(ActionError::NoSuchAbility)?;

            if let crate::ability::AbilityKind::Activated(mana_ability) = &ability.kind
                && mana_ability.is_runtime_mana_ability(game, permanent_id, player)
            {
                let announced_origin = source_snapshot.ability_origins.as_ref()
                    .and_then(|origins| origins.get(ability_index).cloned())
                    .ok_or_else(|| ActionError::ExecutionFailure { source: permanent_id,
                        error: crate::effects::ExecutionError::IncompleteEvidence("mana activation has no acquired ability identity".into()) })?;
                let visibility_provenance = game.provenance_graph_mut().alloc_root(
                    crate::provenance::ProvenanceNodeKind::EffectExecution { source: permanent_id, controller: player },
                );
                if !game.begin_mana_activation_guard(visibility_provenance, permanent_id, announced_origin) {
                    return Err(ActionError::CantPayCost);
                }
                active_guard = Some(visibility_provenance);
                let proposed_cost = if waive_all_costs {
                    // CR 107.3b: X in an activation cost which is not paid is zero.
                    Some((crate::cost::TotalCost::free(), mana_ability.mana_cost.mana_cost().filter(|cost| cost.has_x()).map(|_| 0)))
                } else { prepare_mana_activation_cost(
                    game, player, permanent_id, ability_index, mana_ability, decision_maker,
                )? };
                let Some((total_cost, announced_x)) = proposed_cost else {
                    return Ok(CompletedManaActivation::default());
                };
                let mana_production_provenance =
                    mana_production_provenance_for_activation_cost(&total_cost);
                let effects = mana_ability.effects.clone();
                let linked_exile_owner = crate::linked_exile::LinkedExileOwner::capture(
                    permanent_id,
                    effects.linked_exile_pair,
                    source_snapshot
                        .ability_origins
                        .as_ref()
                        .and_then(|origins| origins.get(ability_index)),
                );
                let source_number_owner = crate::linked_exile::LinkedExileOwner::capture(
                    permanent_id,
                    effects.source_number_pair,
                    source_snapshot
                        .ability_origins
                        .as_ref()
                        .and_then(|origins| origins.get(ability_index)),
                );
                crate::linked_exile::validate_program_owner(
                    effects.linked_exile_pair,
                    linked_exile_owner.as_ref(),
                )
                .map_err(|error| ActionError::ExecutionFailure {
                    source: permanent_id,
                    error,
                })?;
                let mana = mana_ability.mana_output.clone().unwrap_or_default();
                let mut mana_usage_restrictions = mana_ability.mana_usage_restrictions.clone();
                // Mana from a land tapped under "you may tap lands you don't
                // control for mana" keeps that permission's restrictions.
                if game.controller_of_id(permanent_id) != Some(player)
                    && !mana_ability.allows_any_player_to_activate()
                    && game.may_tap_uncontrolled_land_for_mana(player, permanent_id, mana_ability)
                {
                    mana_usage_restrictions
                        .extend(game.uncontrolled_land_mana_restrictions(player));
                }
                let source_chosen_creature_type = game.chosen_creature_type(permanent_id);
                let mut completion = CompletedManaActivation::default();

                let view = crate::derived_view::DerivedGameView::new(game);
                if !crate::decision::exhaust_activation_allows(
                    game,
                    player,
                    permanent_id,
                    ability_index,
                    mana_ability,
                    &view,
                ) {
                    return Err(ActionError::CantPayCost);
                }
                game.begin_exhaust_activation(permanent_id, ability_index);

                game.begin_library_top_announcement(
                    crate::game_state::LibraryTopAnnouncement::Activation(visibility_provenance),
                );
                // Pay mana costs from TotalCost (for abilities like Blood Celebrant that cost {B})
                let payment_reason = mana_ability.payment_reason(game, permanent_id, player);
                let mut cost_ctx = CostContext::new(permanent_id, player, decision_maker)
                    .with_reason(payment_reason)
                    .with_provenance(visibility_provenance);
                cost_ctx.source_snapshot = Some(source_snapshot.clone());
                cost_ctx.x_value = announced_x;
                cost_ctx.interactive_mana_exclusions = interactive_mana_exclusions;
                cost_ctx.reserved_tap_sources = reserved_tap_sources;
                // CR 118.13a/602.2b: a mana-versus-life or hybrid choice is
                // announced before any cost is paid, so mana components with
                // a choice of symbols are paid ahead of the others.
                let total_cost = mana_choice_costs_first(total_cost);
                let paid_cost =
                    pay_total_cost_without_preflight_with_outputs(game, &total_cost, &mut cost_ctx)
                        .map_err(|error| cost_error_to_action_error(error, permanent_id))?;
                let x_value_from_costs = paid_cost.summary.x_value;
                let cost_effect_outcomes = cost_ctx.effect_outcomes.clone();
                let cost_tags = cost_ctx.tagged_objects.clone();
                drop(cost_ctx);
                if decision_maker.awaiting_choice() {
                    return Ok(CompletedManaActivation::default());
                }

                completion.activation_notification = Some(
                    crate::events::AbilityActivatedEvent::from_completed_payment(
                        permanent_id,
                        player,
                        true,
                        Some(ability.clone()),
                        Some(source_snapshot.clone()),
                        announced_x,
                        x_value_from_costs,
                        visibility_provenance,
                        payment_reason,
                        &paid_cost.outputs,
                    )
                    .map_err(|error| ActionError::ExecutionFailure {
                        source: permanent_id,
                        error,
                    })?,
                );
                completion.outputs.extend(paid_cost.outputs);
                game.finish_library_top_announcement(
                    crate::game_state::LibraryTopAnnouncement::Activation(visibility_provenance),
                );
                let activation_origin = source_snapshot
                    .ability_origins
                    .as_ref()
                    .and_then(|origins| origins.get(ability_index).cloned());
                game.record_ability_activation_with_payment(
                    permanent_id,
                    ability_index,
                    activation_origin.clone(),
                    effects.activation_definition,
                    completion.activation_notification.as_ref().and_then(|event|event.mana_spend_evidence.as_ref()),
                );
                // Use the same resolved-event owner as mana-producing effects.
                let mut mana_ctx =
                    ExecutionContext::new(permanent_id, player, &mut *decision_maker)
                        .with_activation_origin(activation_origin.clone())
                        .with_activation_definition(effects.activation_definition)
                        .with_ability_index(ability_index)
                        .with_linked_exile_owner(linked_exile_owner.clone())
                        .with_source_number_owner(source_number_owner.clone())
                        .with_mana_color_restriction(mana_color_restriction.clone())
                        .with_mana_usage_restrictions(mana_usage_restrictions.clone())
                        .with_mana_source_chosen_creature_type(source_chosen_creature_type)
                        .with_mana_production_provenance(mana_production_provenance)
                        .with_source_snapshot(source_snapshot.clone())
                        .with_tagged_objects(cost_tags.clone())
                        .with_effect_outcomes(cost_effect_outcomes.clone());
                // CR 107.3j/107.3g: a mana ability whose X is not defined by
                // its cost or its own text uses zero.
                mana_ctx = mana_ctx.with_x(x_value_from_costs.unwrap_or(0));
                let outputs = crate::effects::EffectExecutor::execute_with_outputs(
                    &crate::effects::AddManaEffect::new(
                        mana,
                        crate::target::PlayerFilter::Specific(player),
                    ),
                    game,
                    &mut mana_ctx,
                )
                .map_err(|error| ActionError::ExecutionFailure {
                    source: permanent_id,
                    error,
                })?;
                if mana_ctx.decision_maker.awaiting_choice() {
                    return Ok(CompletedManaActivation::default());
                }
                drop(mana_ctx);
                completion
                    .events
                    .extend(outputs.outcome.events.iter().cloned());
                completion.outputs.push(outputs);

                // Execute additional effects if present (for complex mana abilities like Ancient Tomb)
                if !effects.is_empty() {
                    let mut effect_ctx =
                        ExecutionContext::new(permanent_id, player, decision_maker)
                            .with_activation_origin(activation_origin.clone())
                            .with_activation_definition(effects.activation_definition)
                            .with_ability_index(ability_index)
                            .with_linked_exile_owner(linked_exile_owner.clone())
                            .with_source_number_owner(source_number_owner.clone())
                            .with_mana_color_restriction(mana_color_restriction.clone())
                            .with_mana_usage_restrictions(mana_usage_restrictions)
                            .with_mana_source_chosen_creature_type(source_chosen_creature_type)
                            .with_mana_production_provenance(mana_production_provenance)
                            .with_source_snapshot(source_snapshot.clone())
                            .with_tagged_objects(cost_tags.clone())
                            .with_effect_outcomes(cost_effect_outcomes.clone());
                    effect_ctx = effect_ctx.with_x(x_value_from_costs.unwrap_or(0));
                    let program_outputs =
                        crate::game_loop::execute_resolution_program_with_outputs_typed(
                            game,
                            &mut effect_ctx,
                            player,
                            permanent_id,
                            &effects,
                            None,
                            &[],
                        )
                        .map_err(|error| {
                            ActionError::ExecutionFailure {
                                source: permanent_id,
                                error,
                            }
                        })?;
                    if effect_ctx.decision_maker.awaiting_choice() {
                        return Ok(CompletedManaActivation::default());
                    }
                    completion.events.extend(program_outputs.events);
                    completion.outputs.extend(program_outputs.outputs);
                }

                // CR 106.12a: one activation with a tap cost is one
                // tapped-for-mana occurrence, however many production
                // instructions it has.
                let mut tap_occurrence_seen = false;
                for event in completion.events.iter_mut() {
                    let Some(added) = event.downcast::<crate::events::ManaAddedEvent>() else {
                        continue;
                    };
                    if added.source != permanent_id
                        || added.mana.is_empty()
                        || added.provenance
                            != crate::events::mana::ManaProductionProvenance::TappedSourceForMana
                    {
                        continue;
                    }
                    if tap_occurrence_seen {
                        let mut continued = added.clone();
                        continued.tap_occurrence_continuation = true;
                        *event = event.with_inner_event(continued);
                    }
                    tap_occurrence_seen = true;
                }
                game.record_land_mana_activation(permanent_id, player, Some(&source_snapshot));
                Ok(completion)
            } else {
                Err(ActionError::NoSuchAbility)
            }
        },
    );
    if let Some(announcement) = active_guard { game.end_mana_activation_guard(announcement); }
    result
}

fn mana_choice_costs_first(total_cost: crate::cost::TotalCost) -> crate::cost::TotalCost {
    let ironsmith_core::TotalCostKind::All(costs) = total_cost.kind() else {
        return total_cost;
    };
    let has_choice = |cost: &crate::costs::Cost| {
        cost.mana_cost_ref()
            .is_some_and(|mana| mana.pips().iter().any(|pip| pip.len() > 1))
    };
    let Some(first_choice) = costs.iter().position(has_choice) else {
        return total_cost;
    };
    if costs[..first_choice].iter().all(|cost| cost.is_mana_cost()) {
        return total_cost;
    }
    let (mut ordered, rest): (Vec<_>, Vec<_>) =
        costs.iter().cloned().partition(|cost| has_choice(cost));
    ordered.extend(rest);
    crate::cost::TotalCost::from_costs(ordered)
}

/// Pay a single cost component, resolving any required choices via decision specs.
///
/// This is shared between special-actions and game-loop mana-ability paths so
/// choice-based costs (discard/sacrifice/exile from hand) follow one path.
pub(crate) fn pay_cost_component_with_choice(
    game: &mut GameState,
    cost: &crate::costs::Cost,
    ctx: &mut CostContext,
) -> Result<(), CostPaymentError> {
    pay_cost_component_with_choice_with_outputs(game, cost, ctx).map(|_| ())
}

pub(crate) fn pay_cost_component_with_choice_with_outputs(
    game: &mut GameState,
    cost: &crate::costs::Cost,
    ctx: &mut CostContext,
) -> Result<Vec<crate::effects::CompletedEffectOutputs>, CostPaymentError> {
    if !game
        .player(ctx.payer)
        .is_some_and(|player| player.is_in_game())
    {
        return Err(CostPaymentError::Other(
            "a player who left the game cannot pay costs".to_string(),
        ));
    }
    game.validate_cost_for_payment_reason(ctx.payer, ctx.source, cost, ctx.reason)?;
    cost.with_payment_action_scope(game, |game| match cost.pay_with_outputs(game, ctx) {
        Ok(receipt) => match receipt.result {
            CostPaymentResult::Paid => Ok(receipt.outputs.into_iter().collect()),
            CostPaymentResult::NeedsChoice(_) => resolve_cost_choice_with_outputs(game, cost, ctx)
                .map(|outputs| {
                    let mut retained: Vec<_> = receipt.outputs.into_iter().collect();
                    retained.extend(outputs);
                    retained
                }),
        },
        Err(error) => Err(error),
    })
}

#[derive(Debug, Clone, Copy, Default)]
pub(crate) struct CostPaymentSummary {
    pub x_value: Option<u32>,
}

/// Pay a full TotalCost using the normal choice-aware cost-payment path.
///
/// This preflights the whole cost before paying and restores the game state if
/// a later component fails after an earlier component has already been paid.
pub(crate) fn pay_total_cost_with_choice(
    game: &mut GameState,
    payer: PlayerId,
    source: ObjectId,
    cost: &crate::cost::TotalCost,
    reason: crate::costs::PaymentReason,
    decision_maker: &mut dyn DecisionMaker,
) -> Result<(), CostPaymentError> {
    crate::cost::can_pay_cost_with_reason(game, source, payer, cost, reason)?;

    let checkpoint = game.clone();
    let provenance = game.provenance_graph_mut().alloc_root(
        crate::provenance::ProvenanceNodeKind::EffectExecution {
            source,
            controller: payer,
        },
    );
    let mut cost_ctx = CostContext::new(source, payer, decision_maker)
        .with_reason(reason)
        .with_provenance(provenance);

    let result = pay_total_cost_branch_without_execution_context(game, cost, &mut cost_ctx);
    let pending = cost_ctx.decision_maker.awaiting_choice()
        && !matches!(&result, Err(CostPaymentError::ExecutionFailed(_)));
    if result.is_err() || pending {
        game.restore_execution_checkpoint(checkpoint, pending);
    }
    if pending { Ok(()) } else { result.map(|_| ()) }
}

/// Actual child packets paid by the native total-cost interpreter. Pending
/// interactive funding may retain a completed prefix; awaiting_choice remains
/// authoritative and this receipt does not acknowledge full payment.
pub(crate) struct CompletedCostPayment {
    pub summary: CostPaymentSummary,
    pub outputs: Vec<crate::effects::CompletedEffectOutputs>,
}

pub(crate) fn pay_total_cost_without_preflight_with_choice(
    game: &mut GameState,
    cost: &crate::cost::TotalCost,
    cost_ctx: &mut CostContext<'_>,
) -> Result<CostPaymentSummary, CostPaymentError> {
    pay_total_cost_without_preflight_with_outputs(game, cost, cost_ctx).map(|paid| paid.summary)
}

pub(crate) fn pay_total_cost_without_preflight_with_outputs(
    game: &mut GameState,
    cost: &crate::cost::TotalCost,
    cost_ctx: &mut CostContext<'_>,
) -> Result<CompletedCostPayment, CostPaymentError> {
    let checkpoint = game.clone();
    let mut context = cost_ctx.checkpoint();
    let result = pay_total_cost_branch_without_execution_context(game, cost, cost_ctx);
    let pending = cost_ctx.decision_maker.awaiting_choice()
        && !matches!(&result, Err(CostPaymentError::ExecutionFailed(_)));
    // Interactive mana funding deliberately exposes its completed prefix;
    // its enclosing replay owns restoring the full action before an answer.
    if cost_ctx.interactive_mana_exclusions.is_some() && pending {
        return result.map(|outputs| CompletedCostPayment {
            summary: CostPaymentSummary {
                x_value: cost_ctx.x_value,
            },
            outputs,
        });
    }
    if result.is_err() || pending {
        game.restore_execution_checkpoint(checkpoint, pending);
        context.restore(cost_ctx);
    }
    if pending {
        Ok(CompletedCostPayment {
            summary: CostPaymentSummary {
                x_value: cost_ctx.x_value,
            },
            outputs: Vec::new(),
        })
    } else {
        result.map(|outputs| CompletedCostPayment {
            summary: CostPaymentSummary {
                x_value: cost_ctx.x_value,
            },
            outputs,
        })
    }
}

pub(crate) fn can_pay_total_cost_with_reason_in_context(
    game: &GameState,
    payer: PlayerId,
    source: ObjectId,
    cost: &crate::cost::TotalCost,
    reason: crate::costs::PaymentReason,
    execution_ctx: &mut ExecutionContext<'_>,
) -> Result<(), CostPaymentError> {
    can_pay_total_cost_in_context_with_funding(
        game,
        payer,
        source,
        cost,
        reason,
        execution_ctx,
        CostQueryFunding::Available,
    )
}

/// Check only the non-mana parts while discovering potential mana sources.
/// This is a partial feasibility query: it assumes funding rather than proving
/// or acknowledging payment, and never recursively discovers mana sources.
pub(crate) fn can_pay_non_mana_parts_of_cost_in_context(
    game: &GameState,
    payer: PlayerId,
    source: ObjectId,
    cost: &crate::cost::TotalCost,
    reason: crate::costs::PaymentReason,
    execution_ctx: &mut ExecutionContext<'_>,
) -> Result<(), CostPaymentError> {
    can_pay_total_cost_in_context_with_funding(
        game,
        payer,
        source,
        cost,
        reason,
        execution_ctx,
        CostQueryFunding::NonManaOnly,
    )
}

/// Potential full-cost feasibility after the declaration adapter has priced
/// applicable modifiers. Funding and every non-mana instruction share the
/// ordinary dependency-aware query; no payment is acknowledged here.
pub(crate) fn can_potentially_pay_total_cost_in_context_with_view(
    game: &GameState,
    payer: PlayerId,
    source: ObjectId,
    cost: &crate::cost::TotalCost,
    reason: crate::costs::PaymentReason,
    execution_ctx: &mut ExecutionContext<'_>,
    view: &crate::derived_view::DerivedGameView<'_>,
) -> Result<(), CostPaymentError> {
    can_pay_total_cost_in_context_with_funding(
        game,
        payer,
        source,
        cost,
        reason,
        execution_ctx,
        CostQueryFunding::PotentialMana(view, None),
    )
}

/// Preliminary feasibility while declaration-specific mana modifiers remain
/// pending. Resolve nominal mana inputs and validate their payment restrictions,
/// deferring funding alone; the priced total must still pass its final query.
pub(crate) fn can_pay_cost_before_mana_funding_in_context(
    game: &GameState,
    payer: PlayerId,
    source: ObjectId,
    cost: &crate::cost::TotalCost,
    reason: crate::costs::PaymentReason,
    execution_ctx: &mut ExecutionContext<'_>,
) -> Result<(), CostPaymentError> {
    can_pay_total_cost_in_context_with_funding(
        game,
        payer,
        source,
        cost,
        reason,
        execution_ctx,
        CostQueryFunding::DeferredMana,
    )
}

/// Affordability policy of this query, distinct from executing payment.
/// Potential mana still validates every non-mana component and retains the
/// same speculative choices, ordering and alternative branch isolation.
#[derive(Clone, Copy)]
enum CostQueryFunding<'view, 'game> {
    Available,
    NonManaOnly,
    DeferredMana,
    PotentialMana(
        &'view crate::derived_view::DerivedGameView<'game>,
        Option<&'view crate::mana_payment::ManaPaymentRequest>,
    ),
}

fn can_pay_total_cost_in_context_with_funding(
    game: &GameState,
    payer: PlayerId,
    source: ObjectId,
    cost: &crate::cost::TotalCost,
    reason: crate::costs::PaymentReason,
    execution_ctx: &mut ExecutionContext<'_>,
    funding: CostQueryFunding<'_, '_>,
) -> Result<(), CostPaymentError> {
    let result = execution_ctx.with_query_scope(|execution_ctx| {
        check_total_cost_in_query_scope(game, payer, source, cost, reason, execution_ctx, funding)
    });
    if let Err(CostPaymentError::ExecutionFailed(error)) = &result {
        game.record_token_resource_failure(error);
    }
    result
}

fn check_total_cost_in_query_scope(
    game: &GameState,
    payer: PlayerId,
    source: ObjectId,
    cost: &crate::cost::TotalCost,
    reason: crate::costs::PaymentReason,
    execution_ctx: &mut ExecutionContext<'_>,
    funding: CostQueryFunding<'_, '_>,
) -> Result<(), CostPaymentError> {
    if !game.player(payer).is_some_and(|player| player.is_in_game()) {
        return Err(CostPaymentError::Other(
            "a player who left the game cannot pay costs".to_string(),
        ));
    }
    match cost.kind() {
        ironsmith_core::TotalCostKind::All(costs) => {
            // Reject an impossible source tap before asking how to fund an
            // earlier mana component. That query reserves this source untapped;
            // when it is already tapped, repeatable producers can otherwise
            // grow an endless search that can never satisfy the reservation.
            // Check each All branch separately so a cost without a tap symbol
            // in OneOf remains available.
            if game.is_tapped(source) && costs.iter().any(|cost| cost.requires_tap()) {
                return Err(CostPaymentError::AlreadyTapped);
            }
            let mut cumulative_mana=crate::mana::ManaCost::new();
            let mut speculative_tagged_objects = execution_ctx.tagged_objects.clone();
            let mut discard_slots = Vec::new();
            // Each exile-chosen material slot consumes distinct objects: one
            // object can't be exiled for two slots (Craft slot lists, CR
            // 702.167a). Feasibility is a matching over all such slots, not a
            // per-slot candidate count.
            let mut exile_choice_slots: Vec<Vec<ObjectId>> = Vec::new();
            for (index, component) in costs.iter().enumerate() {
                // Potential-source discovery must not resolve or fund mana
                // components: either can recursively ask for this same set.
                // Retain the authored order of every non-mana instruction.
                if matches!(funding, CostQueryFunding::NonManaOnly) && component.is_mana_cost() {
                    continue;
                }
                // Resolve the next cost against preceding speculative choices,
                // while the outer query scope prevents publishing them live.
                execution_ctx.tagged_objects = speculative_tagged_objects.clone();
                let adjusted_component = resolve_and_adjust_component_in_context(
                    game,
                    payer,
                    source,
                    component,
                    reason,
                    execution_ctx,
                )?;
                // Dynamic amount resolution can also establish source-linked
                // snapshot bindings used by following cost instructions.
                speculative_tagged_objects = execution_ctx.tagged_objects.clone();
                game.validate_cost_for_payment_reason(payer, source, &adjusted_component, reason)?;
                let mut cost_ctx =
                    CostContext::from_execution_context(source, payer, reason, execution_ctx);
                cost_ctx.tagged_objects = speculative_tagged_objects.clone();
                if costs.iter().any(|cost| cost.requires_tap()) {
                    cost_ctx.reserved_tap_sources.push(source);
                }
                // Components share one payer's mana resources. Resolve in
                // authored order (for preceding choice references), but test
                // their accumulated mana obligation, never the same pool twice.
                let cumulative_component=adjusted_component.mana_cost_ref().map(|mana|{
                    cumulative_mana=cumulative_mana.combined_with(mana);
                    crate::costs::Cost::mana(cumulative_mana.clone())
                });
                let funding_component=cumulative_component.as_ref().unwrap_or(&adjusted_component);
                match funding {
                    CostQueryFunding::DeferredMana if adjusted_component.is_mana_cost() => {}
                    CostQueryFunding::PotentialMana(view, payment)
                        if adjusted_component.is_mana_cost() =>
                    {
                        funding_component.0.can_potentially_pay_with_query(
                            game,
                            &cost_ctx,
                            &crate::costs::PotentialManaQuery { view, payment },
                        )?;
                    }
                    _ => funding_component.0.can_pay(game, &cost_ctx)?,
                }
                if let crate::costs::CostProcessingMode::DiscardCards { count, filter } =
                    adjusted_component.processing_mode()
                {
                    let candidates =
                        crate::costs::legal_discard_cost_cards_in_context(game, &cost_ctx, &filter);
                    if candidates.len() < count as usize {
                        return Err(CostPaymentError::InsufficientCardsInHand);
                    }
                    discard_slots.extend(std::iter::repeat_n(candidates, count as usize));
                }

                // Pure capture preludes derive the same immutable selection
                // partitions as payment, without executing physical actions.
                if let Some(cost) = adjusted_component.effect_ref()
                    .and_then(|effect| effect.0.as_cost_executable())
                {
                    cost.preview_payment_bindings(game, execution_ctx)
                        .map_err(CostPaymentError::ExecutionFailed)?;
                    speculative_tagged_objects = execution_ctx.tagged_objects.clone();
                }

                // Some multi-object costs are represented as a choice that tags the
                // selected objects followed by an effect that consumes that tag. A
                // component-at-a-time preflight cannot execute the choice, but the
                // consumer still needs a representative tag set in order to validate.
                // Build one legal set without prompting; actual payment makes the
                // player's choice normally and remains atomic.
                if let Some(next) = costs.get(index + 1)
                    && let Some((tag, snapshots, candidates, required)) = preflight_tagged_choice_in_context(
                        game,
                        payer,
                        source,
                        component,
                        next,
                        reason,
                        execution_ctx,
                        &speculative_tagged_objects,
                        crate::cost::tagged_choice_pair_at(costs, index).is_some_and(|choice| {
                            crate::cost::cost_choice_reserves_source_state(choice, next, costs)
                        }),
                    )?
                {
                    if next
                        .effect_ref()
                        .is_some_and(|effect| effect.downcast_ref::<crate::effects::ExileEffect>().is_some())
                    {
                        exile_choice_slots.extend(std::iter::repeat_n(candidates, required));
                    }
                    speculative_tagged_objects.insert(tag, snapshots);
                }
            }
            if !crate::costs::distinct_discard_assignment_exists(&exile_choice_slots) {
                return Err(CostPaymentError::Other(
                    "no distinct assignment of objects to the exile cost slots".into(),
                ));
            }
            if crate::costs::distinct_discard_assignment_exists(&discard_slots) {
                Ok(())
            } else {
                Err(CostPaymentError::InsufficientCardsInHand)
            }
        }
        ironsmith_core::TotalCostKind::OneOf(branches) => {
            for branch in branches {
                match can_pay_total_cost_in_context_with_funding(
                    game,
                    payer,
                    source,
                    branch,
                    reason,
                    execution_ctx,
                    funding,
                ) {
                    Ok(()) => return Ok(()),
                    Err(error @ CostPaymentError::ExecutionFailed(_)) => return Err(error),
                    Err(_) => {}
                }
            }
            Err(CostPaymentError::Other(
                "no payable alternative cost branch".into(),
            ))
        }
    }
}

fn preflight_tagged_choice_in_context(
    game: &GameState,
    payer: PlayerId,
    source: ObjectId,
    choice_component: &crate::costs::Cost,
    consumer_component: &crate::costs::Cost,
    reason: crate::costs::PaymentReason,
    execution_ctx: &ExecutionContext<'_>,
    tagged_objects: &std::collections::HashMap<crate::tag::TagKey, Vec<ObjectSnapshot>>,
    source_state_reserved: bool,
) -> Result<
    Option<(crate::tag::TagKey, Vec<ObjectSnapshot>, Vec<ObjectId>, usize)>,
    CostPaymentError,
> {
    let Some(choice) = crate::cost::cost_object_choice(choice_component)
    else {
        return Ok(None);
    };
    // Before X is announced, an X-relative characteristic on the choice
    // cannot make it unpayable (see `with_unbound_x_relaxed`).
    let relaxed_choice;
    let choice = if execution_ctx.x_value.is_none()
        && let Some(relaxed) =
            crate::effects::composition::choose_objects::with_unbound_x_relaxed(choice)
    {
        relaxed_choice = relaxed;
        &relaxed_choice
    } else {
        choice
    };
    // Any consumer that pays with exactly the chosen objects (exile, return,
    // move, unattach, ...) needs the same representative selection.
    if crate::cost::cost_consumed_choice_tag(consumer_component).as_ref() != Some(&choice.tag) {
        return Ok(None);
    }

    let required = crate::effects::composition::choose_objects::minimum_selection_cost_count(
        choice, game, execution_ctx,
    ).map_err(CostPaymentError::ExecutionFailed)?;

    let mut filter_ctx = execution_ctx
        .filter_context(game)
        .with_tagged_objects(tagged_objects);
    let payer_filter_ctx = game.filter_context_for(payer, Some(source));
    filter_ctx.you = payer_filter_ctx.you;
    filter_ctx.opponents = payer_filter_ctx.opponents;
    filter_ctx.teammates = payer_filter_ctx.teammates;
    filter_ctx.players_in_range = payer_filter_ctx.players_in_range;
    filter_ctx.your_commanders = payer_filter_ctx.your_commanders;

    let mut query_decision_maker = crate::decision::SelectFirstDecisionMaker;
    let mut candidate_query = ExecutionContext::new(source, payer, &mut query_decision_maker);
    crate::effects::ExecutionContextCheckpoint::capture(execution_ctx)
        .restore(&mut candidate_query);
    candidate_query.source = source;
    candidate_query.controller = payer;
    candidate_query.tagged_objects = tagged_objects.clone();
    candidate_query.mana.payment_reason = Some(reason);
    candidate_query.cause =
        crate::costs::payment_event_cause(source, payer, reason, Some(&execution_ctx.cause));
    let consumer = consumer_component
        .effect_ref()
        .and_then(|effect| effect.0.as_cost_executable());
    let mut candidates = Vec::new();
    let mut visit = |id: ObjectId| {
        if !candidates.contains(&id)
            && game.object(id).is_some_and(|object| {
                ((!choice.filter.other && !source_state_reserved) || id != source)
                    && choice.filter.matches(object, &filter_ctx, game)
                    && consumer
                        .and_then(|cost| {
                            cost.cost_choice_candidate_is_eligible(
                                game,
                                &mut candidate_query,
                                reason,
                                &choice.tag,
                                id,
                            )
                        })
                        .unwrap_or(true)
            })
        {
            candidates.push(id);
        }
    };
    if let Ok(zones) = crate::effects::composition::choose_objects::search_zones(choice) {
        for zone in zones {
            let mut zone_filter = choice.filter.clone();
            zone_filter.zone = Some(zone);
            crate::object_query::for_each_candidate_id_for_filter(game, &zone_filter, &mut visit);
        }
    } else {
        crate::object_query::for_each_candidate_id_for_filter(game, &choice.filter, &mut visit);
    }

    if choice.filter.single_graveyard && choice.filter.zone.or(choice.zone) == Some(Zone::Graveyard)
    {
        let mut owner_groups: Vec<(PlayerId, Vec<ObjectId>)> = Vec::new();
        for id in candidates {
            let Some(owner) = game.object(id).map(|object| object.owner) else {
                continue;
            };
            if let Some((_, ids)) = owner_groups
                .iter_mut()
                .find(|(group_owner, _)| *group_owner == owner)
            {
                ids.push(id);
            } else {
                owner_groups.push((owner, vec![id]));
            }
        }
        candidates = owner_groups
            .into_iter()
            .find_map(|(_, ids)| (ids.len() >= required).then_some(ids))
            .unwrap_or_default();
    }

    if crate::effects::composition::selection_relations::has_relations(&choice.filter) {
        candidates.retain(|id| {
            !execution_ctx
                .replacement
                .entry_reserved_objects
                .contains(id)
        });
        candidates = crate::effects::composition::selection_relations::find_group(
            game,
            &choice.filter,
            &candidates,
            required,
            true,
        )
        .ok_or_else(|| {
            CostPaymentError::Other("no legal group for tagged cost selection".into())
        })?;
    }

    let all_candidates = candidates.clone();
    // Independent color representatives form a transversal matroid: greedily
    // extending an independent set finds a legal set whenever one exists.
    // Candidate order alone can otherwise pick two mono-white objects before
    // an available blue object and publish an impossible prospective payment.
    if choice.aggregate_constraint.as_ref().is_some_and(|constraint|
        constraint.metric == crate::effect::ChoiceAggregateMetric::DistinctColorRepresentatives)
    {
        let mut masks = Vec::new();
        candidates.retain(|id| {
            let mask = crate::targeting::aggregate_object_value(
                game, *id, crate::effect::ChoiceAggregateMetric::DistinctColorRepresentatives) as u32;
            masks.push(mask);
            if crate::targeting::card_type_slot_matching_size(&masks) == masks.len() {
                true
            } else {
                masks.pop();
                false
            }
        });
    }
    let snapshots = candidates
        .into_iter()
        .take(required)
        .filter_map(|id| {
            game.object(id)
                .map(|object| ObjectSnapshot::from_object(object, game))
        })
        .collect::<Vec<_>>();
    if snapshots.len() < required {
        return Err(CostPaymentError::Other(
            "not enough objects available for tagged exile cost".to_string(),
        ));
    }
    Ok(Some((choice.tag.clone(), snapshots, all_candidates, required)))
}

pub(crate) fn pay_total_cost_with_choice_in_context(
    game: &mut GameState,
    payer: PlayerId,
    source: ObjectId,
    cost: &crate::cost::TotalCost,
    reason: crate::costs::PaymentReason,
    execution_ctx: &mut ExecutionContext<'_>,
) -> Result<(), CostPaymentError> {
    pay_total_cost_with_choice_in_context_with_outputs(
        game,
        payer,
        source,
        cost,
        reason,
        execution_ctx,
    )
    .map(|_| ())
}

/// Resolution payments can activate mana abilities after accepting the offer.
/// Validate non-mana obligations now, but leave funding to the interactive
/// payment owner. Other callers retain their existing funding preflight.
pub(crate) fn can_begin_total_cost_payment_in_context(
    game: &GameState,
    payer: PlayerId,
    source: ObjectId,
    cost: &crate::cost::TotalCost,
    reason: crate::costs::PaymentReason,
    execution_ctx: &mut ExecutionContext<'_>,
) -> Result<(), CostPaymentError> {
    can_pay_total_cost_in_context_with_funding(
        game,
        payer,
        source,
        cost,
        reason,
        execution_ctx,
        if reason == crate::costs::PaymentReason::Effect {
            CostQueryFunding::DeferredMana
        } else {
            CostQueryFunding::Available
        },
    )
}

pub(crate) fn pay_total_cost_with_choice_in_context_with_outputs(
    game: &mut GameState,
    payer: PlayerId,
    source: ObjectId,
    cost: &crate::cost::TotalCost,
    reason: crate::costs::PaymentReason,
    execution_ctx: &mut ExecutionContext<'_>,
) -> Result<Vec<crate::effects::CompletedEffectOutputs>, CostPaymentError> {
    crate::effects::composition::execute_transaction(
        game,
        execution_ctx,
        Vec::new,
        |game, execution_ctx| {
            can_begin_total_cost_payment_in_context(
                game,
                payer,
                source,
                cost,
                reason,
                execution_ctx,
            )?;
            let result = pay_total_cost_branch_in_context_with_outputs(
                game,
                payer,
                source,
                cost,
                reason,
                execution_ctx.provenance,
                execution_ctx,
            );
            // Cost adapters can report a pending mana choice as a payment error.
            // The transaction owns suspension; retain its decision and return only
            // the neutral pending result while restoring every original binding.
            if execution_ctx.decision_maker.awaiting_choice()
                && !matches!(&result, Err(CostPaymentError::ExecutionFailed(_)))
            {
                Ok(Vec::new())
            } else {
                result
            }
        },
    )
}

fn pay_total_cost_branch_without_execution_context(
    game: &mut GameState,
    cost: &crate::cost::TotalCost,
    cost_ctx: &mut CostContext<'_>,
) -> Result<Vec<crate::effects::CompletedEffectOutputs>, CostPaymentError> {
    match cost.kind() {
        ironsmith_core::TotalCostKind::All(costs) => {
            let mut outputs = Vec::new();
            let mut idx = 0usize;
            while idx < costs.len() {
                if let Some(choose) = costs[idx]
                    .effect_ref()
                    .and_then(|effect| effect.downcast_ref::<crate::effects::ChooseObjectsEffect>())
                    && let Some(next) = costs.get(idx + 1)
                    && let Some(step) = crate::game_loop::choose_tagged_cost_step(choose, next)
                {
                    outputs.extend(pay_activation_cost_step_without_execution_context(
                        game, &step, cost_ctx,
                    )?);
                    if cost_ctx.decision_maker.awaiting_choice() {
                        return Ok(outputs);
                    }
                    idx += 2;
                    continue;
                }

                let reserved = cost_ctx.reserved_tap_sources.clone();
                if costs[idx + 1..].iter().any(|cost| cost.requires_tap()) {
                    cost_ctx.reserved_tap_sources.push(cost_ctx.source);
                }
                let result = pay_component_without_execution_context_with_outputs(
                    game,
                    &costs[idx],
                    cost_ctx,
                );
                cost_ctx.reserved_tap_sources = reserved;
                outputs.extend(result?);
                if cost_ctx.decision_maker.awaiting_choice() {
                    return Ok(outputs);
                }
                idx += 1;
            }
            Ok(outputs)
        }
        ironsmith_core::TotalCostKind::OneOf(branches) => {
            let mut payable = Vec::new();
            for (index, branch) in branches.iter().enumerate() {
                let result = if cost_ctx.interactive_mana_exclusions.is_some()
                    && !cost_ctx.reason.is_mana_ability()
                {
                    payment::check_special_action_payment_with_snapshot(
                        game,
                        cost_ctx.payer,
                        &SpecialActionPayment {
                            source: cost_ctx.source,
                            cost: branch.clone(),
                            reason: cost_ctx.reason,
                        },
                        cost_ctx.source_snapshot.clone(),
                    )
                    .map_err(|error| match error {
                        ActionError::ExecutionFailure { error, .. } => {
                            CostPaymentError::ExecutionFailed(error)
                        }
                        error => CostPaymentError::Other(error.to_string()),
                    })
                } else {
                    cost_ctx.with_execution_context(|execution| {
                        can_pay_total_cost_with_reason_in_context(
                            game,
                            cost_ctx.payer,
                            cost_ctx.source,
                            branch,
                            cost_ctx.reason,
                            execution,
                        )
                    })
                };
                match result {
                    Ok(()) => payable.push(index),
                    Err(error @ CostPaymentError::ExecutionFailed(_)) => return Err(error),
                    Err(_) => {}
                }
            }
            let Some(branch_index) = choose_payable_branch(
                game,
                cost_ctx.payer,
                cost_ctx.source,
                branches,
                &payable,
                cost_ctx.decision_maker,
            )?
            else {
                return Err(CostPaymentError::Other(
                    "no payable alternative cost branch".to_string(),
                ));
            };
            pay_total_cost_branch_without_execution_context(game, &branches[branch_index], cost_ctx)
        }
    }
}

fn pay_activation_cost_step_without_execution_context(
    game: &mut GameState,
    step: &crate::game_loop::ActivationCostStep,
    cost_ctx: &mut CostContext<'_>,
) -> Result<Vec<crate::effects::CompletedEffectOutputs>, CostPaymentError> {
    match step {
        crate::game_loop::ActivationCostStep::Cost(cost) => {
            pay_component_without_execution_context_with_outputs(game, cost, cost_ctx)
        }
        crate::game_loop::ActivationCostStep::Sacrifice {
            cost,
            filter,
            choice_tag,
            ..
        } => {
            let candidates = legal_sacrifice_targets(
                game,
                cost_ctx.payer,
                cost_ctx.source,
                filter,
                cost_ctx.reason,
                &cost_ctx.event_cause(),
            );
            let Some(target_id) = choose_single_cost_object(
                game,
                cost_ctx,
                format!("Choose {} to sacrifice", describe_permanent_filter(filter)),
                candidates,
                crate::decisions::context::SelectionRevealPolicy::None,
            ) else {
                return Err(CostPaymentError::NoValidSacrificeTarget);
            };
            pay_selected_cost_without_execution_context(
                game,
                cost,
                target_id,
                choice_tag.as_ref(),
                cost_ctx,
            )
        }
        crate::game_loop::ActivationCostStep::CardChoice(choice) => {
            pay_activation_card_choice_without_execution_context(game, choice, cost_ctx)
        }
    }
}

/// Physical identities of the hand cards an exile-from-hand cost is about
/// to exile (each becomes a new exiled object, CR 400.7).
fn cost_exiled_from_hand_identities(
    game: &GameState,
    cards: &[ObjectId],
) -> Vec<crate::ids::StableId> {
    cards
        .iter()
        .filter_map(|id| game.object(*id).map(|object| object.stable_id))
        .collect()
}

/// "Exile a card from your hand: ... the card exiled this way" (Holistic
/// Wisdom): publish the exiled incarnations to the ability being activated
/// under the cost-exile tag (CR 602.2, 608.2h last-known characteristics).
fn publish_cost_exiled_from_hand(
    game: &GameState,
    ctx: &mut CostContext<'_>,
    stable_ids: &[crate::ids::StableId],
) {
    let snapshots: Vec<ObjectSnapshot> = stable_ids
        .iter()
        .filter_map(|stable_id| game.find_object_by_stable_id(*stable_id))
        .filter_map(|id| game.object(id))
        .filter(|object| object.zone == crate::zone::Zone::Exile)
        .map(|object| ObjectSnapshot::from_object(object, game))
        .collect();
    if snapshots.is_empty() {
        return;
    }
    ctx.tagged_objects
        .entry(crate::tag::TagKey::from(ironsmith_core::tag::COST_EXILED_FROM_HAND_TAG))
        .or_default()
        .extend(snapshots);
}

fn pay_activation_card_choice_without_execution_context(
    game: &mut GameState,
    choice: &crate::game_loop::ActivationCardCostChoice,
    cost_ctx: &mut CostContext<'_>,
) -> Result<Vec<crate::effects::CompletedEffectOutputs>, CostPaymentError> {
    match choice {
        crate::game_loop::ActivationCardCostChoice::Discard {
            cost,
            filter,
            description,
        } => {
            let candidates =
                crate::costs::legal_discard_cost_cards_in_context(game, cost_ctx, filter);
            let Some(target_id) = choose_single_cost_object(
                game,
                cost_ctx,
                format!("Choose a card to discard: {description}"),
                candidates,
                crate::game_loop::card_cost_choice_reveal_policy(choice),
            ) else {
                return Err(CostPaymentError::InsufficientCardsInHand);
            };
            pay_selected_cost_without_execution_context(game, cost, target_id, None, cost_ctx)
        }
        crate::game_loop::ActivationCardCostChoice::ExileFromHand {
            cost,
            color_filter,
            description,
        } => {
            let candidates =
                legal_exile_cards(game, cost_ctx.payer, cost_ctx.source, *color_filter);
            let Some(target_id) = choose_single_cost_object(
                game,
                cost_ctx,
                format!("Choose a card to exile: {description}"),
                candidates,
                crate::game_loop::card_cost_choice_reveal_policy(choice),
            ) else {
                return Err(CostPaymentError::InsufficientCardsToExile);
            };
            let stable_ids = cost_exiled_from_hand_identities(game, &[target_id]);
            let outputs =
                pay_selected_cost_without_execution_context(game, cost, target_id, None, cost_ctx)?;
            publish_cost_exiled_from_hand(game, cost_ctx, &stable_ids);
            Ok(outputs)
        }
        crate::game_loop::ActivationCardCostChoice::ExileFromGraveyard {
            cost,
            card_type,
            description,
            ..
        } => {
            let candidates = legal_exile_from_graveyard_cards(game, cost_ctx.payer, *card_type);
            let Some(target_id) = choose_single_cost_object(
                game,
                cost_ctx,
                format!("Choose a card to exile from your graveyard: {description}"),
                candidates,
                crate::game_loop::card_cost_choice_reveal_policy(choice),
            ) else {
                return Err(CostPaymentError::InsufficientCardsInGraveyard);
            };
            pay_selected_cost_without_execution_context(game, cost, target_id, None, cost_ctx)
        }
        crate::game_loop::ActivationCardCostChoice::ExileChosenObject {
            cost,
            filter,
            zone,
            top_only,
            description,
            choice_tag,
        } => {
            let candidates = legal_cost_choice_objects(
                game,
                cost_ctx.payer,
                cost_ctx.source,
                filter,
                *zone,
                *top_only,
            );
            let Some(target_id) = choose_single_cost_object(
                game,
                cost_ctx,
                format!("Choose an object to exile: {description}"),
                candidates,
                crate::game_loop::card_cost_choice_reveal_policy(choice),
            ) else {
                return Err(CostPaymentError::InsufficientCardsToExile);
            };
            pay_selected_cost_without_execution_context(
                game,
                cost,
                target_id,
                Some(choice_tag),
                cost_ctx,
            )
        }
        crate::game_loop::ActivationCardCostChoice::RevealFromHand { cost, .. } => {
            resolve_cost_choice_with_outputs(game, cost, cost_ctx)
        }
        crate::game_loop::ActivationCardCostChoice::ReturnToHand {
            cost,
            filter,
            description,
            choice_tag,
        } => {
            let candidates = legal_return_targets(game, cost_ctx.payer, cost_ctx.source, filter);
            let Some(target_id) = choose_single_cost_object(
                game,
                cost_ctx,
                format!("Choose a permanent to return: {description}"),
                candidates,
                crate::game_loop::card_cost_choice_reveal_policy(choice),
            ) else {
                return Err(CostPaymentError::NoValidReturnTarget);
            };
            pay_selected_cost_without_execution_context(
                game,
                cost,
                target_id,
                choice_tag.as_ref(),
                cost_ctx,
            )
        }
        crate::game_loop::ActivationCardCostChoice::MoveChosenObjectToZone {
            cost,
            filter,
            source_zone,
            destination_zone,
            description,
            choice_tag,
        } => {
            let candidates = legal_cost_choice_objects(
                game,
                cost_ctx.payer,
                cost_ctx.source,
                filter,
                *source_zone,
                false,
            );
            let Some(target_id) = choose_single_cost_object(
                game,
                cost_ctx,
                format!("Choose an object to move to {destination_zone}: {description}"),
                candidates,
                crate::game_loop::card_cost_choice_reveal_policy(choice),
            ) else {
                return Err(CostPaymentError::Other(
                    "no legal object for move-to-zone cost".to_string(),
                ));
            };
            pay_selected_cost_without_execution_context(
                game,
                cost,
                target_id,
                Some(choice_tag),
                cost_ctx,
            )
        }
    }
}

/// A cost choice among cards that may include hidden hand cards: always
/// asked (peers offer placeholders, so their candidate lists differ from the
/// owner's), and a card the payment makes public is opened on every peer
/// before the answer replays (see `game_state::hidden_hand_choices`).
fn hidden_hand_cost_choice_spec(
    game: &GameState,
    spec: ChooseObjectsSpec,
    candidates: &[ObjectId],
    reveal_policy: crate::decisions::context::SelectionRevealPolicy,
) -> ChooseObjectsSpec {
    if !candidates
        .iter()
        .any(|id| game.hidden_identity_is_private(*id))
    {
        return spec;
    }
    let spec = spec.require_explicit_choice();
    if reveal_policy == crate::decisions::context::SelectionRevealPolicy::Public {
        spec.with_selection_reveal_policy(reveal_policy)
    } else {
        spec
    }
}

/// Hidden-hand placeholders among `ids` that stay payable for `filter` (see
/// `GameState::hidden_hand_payable_placeholders`).
fn hand_cost_placeholders(
    game: &GameState,
    payer: PlayerId,
    source: ObjectId,
    filter: &ObjectFilter,
    ids: &[ObjectId],
) -> Vec<ObjectId> {
    let mut ctx = game.filter_context_for(payer, Some(source));
    game.hidden_hand_payable_placeholders(filter, &ctx, ids.iter().copied())
        .into_iter()
        .filter(|id| *id != source)
        .collect()
}

fn choose_single_cost_object(
    game: &mut GameState,
    cost_ctx: &mut CostContext<'_>,
    prompt: String,
    candidates: Vec<ObjectId>,
    reveal_policy: crate::decisions::context::SelectionRevealPolicy,
) -> Option<ObjectId> {
    if candidates.is_empty() {
        return None;
    }
    let spec = hidden_hand_cost_choice_spec(
        game,
        ChooseObjectsSpec::new(cost_ctx.source, prompt, candidates.clone(), 1, Some(1)),
        &candidates,
        reveal_policy,
    );
    let chosen: Vec<ObjectId> = make_decision(
        game,
        cost_ctx.decision_maker,
        cost_ctx.payer,
        Some(cost_ctx.source),
        spec,
    );
    normalize_selection(chosen, &candidates, 1).first().copied()
}

fn pay_selected_cost_without_execution_context(
    game: &mut GameState,
    cost: &crate::costs::Cost,
    chosen_id: ObjectId,
    choice_tag: Option<&crate::tag::TagKey>,
    cost_ctx: &mut CostContext<'_>,
) -> Result<Vec<crate::effects::CompletedEffectOutputs>, CostPaymentError> {
    let source = cost_ctx.source;
    let payer = cost_ctx.payer;
    let reason = cost_ctx.reason;
    let provenance = cost_ctx.provenance;
    let x_value = cost_ctx.x_value;
    let mut tagged_objects = cost_ctx.tagged_objects.clone();
    let effective_choice_tag = choice_tag
        .cloned()
        .or_else(|| match cost.processing_mode() {
            crate::costs::CostProcessingMode::ExileFromHand { .. }
            | crate::costs::CostProcessingMode::ExileFromGraveyard { .. }
            | crate::costs::CostProcessingMode::ExileObjects { .. } => {
                Some(crate::tag::TagKey::from("exile_cost"))
            }
            _ => None,
        });

    if let Some(tag) = effective_choice_tag.as_ref()
        && let Some(snapshot) = game
            .object(chosen_id)
            .map(|obj| ObjectSnapshot::from_object(obj, game))
    {
        tagged_objects
            .entry(tag.clone())
            .or_default()
            .push(snapshot);
    }

    game.validate_cost_for_payment_reason(payer, source, cost, reason)?;

    let (paid_x_value, paid_tags, paid_outcomes, paid_inputs, completed_sacrifice, outputs) = {
        let requesting_effect_cause = cost_ctx.requesting_effect_cause.clone();
        let mut selected_ctx = CostContext::new(source, payer, &mut *cost_ctx.decision_maker)
            .with_reason(reason)
            .with_pre_chosen_cards(vec![chosen_id])
            .with_provenance(provenance);
        selected_ctx.source_snapshot = cost_ctx.source_snapshot.clone();
        selected_ctx.prospective_cost_payment = cost_ctx.prospective_cost_payment;
        selected_ctx.replacement = cost_ctx.replacement.clone();
        selected_ctx.requesting_effect_cause = requesting_effect_cause;
        selected_ctx.x_value = x_value;
        selected_ctx.tagged_objects = tagged_objects;
        selected_ctx.announced_targets = cost_ctx.announced_targets.clone();
        selected_ctx.effect_outcomes = cost_ctx.effect_outcomes.clone();
        selected_ctx.execution_inputs = cost_ctx.execution_inputs.clone();
        selected_ctx.reserved_tap_sources = cost_ctx.reserved_tap_sources.clone();
        selected_ctx.interactive_mana_exclusions = cost_ctx.interactive_mana_exclusions.clone();

        let receipt = cost.pay_with_outputs(game, &mut selected_ctx)?;
        match receipt.result {
            CostPaymentResult::Paid if selected_ctx.decision_maker.awaiting_choice() => {
                return Ok(receipt.outputs.into_iter().collect());
            }
            CostPaymentResult::Paid => (
                selected_ctx.x_value,
                selected_ctx.tagged_objects,
                selected_ctx.effect_outcomes,
                selected_ctx.execution_inputs,
                selected_ctx.completed_sacrifice,
                receipt.outputs.into_iter().collect(),
            ),
            CostPaymentResult::NeedsChoice(_) => {
                return Err(CostPaymentError::Other(
                    "Cost still needed a choice after preselection".to_string(),
                ));
            }
        }
    };

    cost_ctx.x_value = paid_x_value;
    cost_ctx.tagged_objects = paid_tags;
    cost_ctx.effect_outcomes = paid_outcomes;
    cost_ctx.execution_inputs = paid_inputs;
    cost_ctx.completed_sacrifice = completed_sacrifice;
    Ok(outputs)
}

fn pay_total_cost_branch_in_context_with_outputs(
    game: &mut GameState,
    payer: PlayerId,
    source: ObjectId,
    cost: &crate::cost::TotalCost,
    reason: crate::costs::PaymentReason,
    provenance: crate::provenance::ProvNodeId,
    execution_ctx: &mut ExecutionContext<'_>,
) -> Result<Vec<crate::effects::CompletedEffectOutputs>, CostPaymentError> {
    match cost.kind() {
        ironsmith_core::TotalCostKind::All(costs) => {
            let mut outputs = Vec::new();
            for (index, component) in costs.iter().enumerate() {
                outputs.extend(pay_component_in_context_with_outputs(
                    game,
                    payer,
                    source,
                    component,
                    reason,
                    provenance,
                    execution_ctx,
                    if costs[index + 1..].iter().any(|cost| cost.requires_tap()) {
                        vec![source]
                    } else {
                        Vec::new()
                    },
                )?);
                if execution_ctx.decision_maker.awaiting_choice() {
                    return Ok(Vec::new());
                }
            }
            Ok(outputs)
        }
        ironsmith_core::TotalCostKind::OneOf(branches) => {
            let mut payable = Vec::new();
            for (index, branch) in branches.iter().enumerate() {
                match can_begin_total_cost_payment_in_context(
                    game,
                    payer,
                    source,
                    branch,
                    reason,
                    execution_ctx,
                ) {
                    Ok(()) => payable.push(index),
                    Err(error @ CostPaymentError::ExecutionFailed(_)) => return Err(error),
                    Err(_) => {}
                }
            }
            let Some(branch_index) = choose_payable_branch(
                game,
                payer,
                source,
                branches,
                &payable,
                execution_ctx.decision_maker,
            )?
            else {
                return Err(CostPaymentError::Other(
                    "no payable alternative cost branch".to_string(),
                ));
            };
            pay_total_cost_branch_in_context_with_outputs(
                game,
                payer,
                source,
                &branches[branch_index],
                reason,
                provenance,
                execution_ctx,
            )
        }
    }
}

fn choose_payable_branch(
    game: &GameState,
    payer: PlayerId,
    source: ObjectId,
    branches: &[crate::cost::TotalCost],
    payable: &[usize],
    decision_maker: &mut dyn DecisionMaker,
) -> Result<Option<usize>, CostPaymentError> {
    if payable.is_empty() {
        return Ok(None);
    }
    if payable.len() == 1 {
        return Ok(Some(payable[0]));
    }

    let options = payable
        .iter()
        .map(|index| DisplayOption::new(*index, branches[*index].display()))
        .collect();
    let selected = make_decision(
        game,
        decision_maker,
        payer,
        Some(source),
        ChoiceSpec::single(source, options),
    );
    let Some(index) = selected.first().copied() else {
        return Err(CostPaymentError::Other(
            "no alternative cost branch was selected".to_string(),
        ));
    };
    if payable.contains(&index) {
        Ok(Some(index))
    } else {
        Err(CostPaymentError::Other(
            "selected alternative cost branch is not payable".to_string(),
        ))
    }
}

fn pay_component_without_execution_context_with_outputs(
    game: &mut GameState,
    component: &crate::costs::Cost,
    cost_ctx: &mut CostContext<'_>,
) -> Result<Vec<crate::effects::CompletedEffectOutputs>, CostPaymentError> {
    if let Some(mana_cost) = component.mana_cost_ref() {
        let adjusted_cost = game.adjust_mana_cost_for_payment_reason(
            cost_ctx.payer,
            Some(cost_ctx.source),
            mana_cost,
            cost_ctx.reason,
        );
        let execution = cost_ctx.capture_execution_context();
        if cost_ctx.interactive_mana_exclusions.is_some()
            || adjusted_cost.has_waterbend_obligation()
            || cost_ctx.reason == crate::costs::PaymentReason::Effect
        {
            adjusted_cost
                .waterbend_capacity_checked(cost_ctx.x_value.unwrap_or(0))
                .ok_or_else(|| {
                    CostPaymentError::ExecutionFailed(
                        crate::effects::ExecutionError::IncompleteEvidence(
                            "Waterbend payment quantity overflows".into(),
                        ),
                    )
                })?;
            let adjusted_cost =
                adjusted_cost.bind_x_payment_if_unbound(cost_ctx.x_value.unwrap_or(0));
            let adjusted_cost = adjusted_cost.with_pips(GameState::expanded_payment_pips(
                &adjusted_cost,
                cost_ctx.x_value.unwrap_or(0),
                false,
            ));
            return crate::mana_payment::pay_mana_interactively_in_context_with_outputs(
                game,
                cost_ctx.payer,
                cost_ctx.source,
                adjusted_cost,
                cost_ctx.reason,
                cost_ctx
                    .interactive_mana_exclusions
                    .clone()
                    .unwrap_or_default(),
                cost_ctx.reserved_tap_sources.clone(),
                cost_ctx.decision_maker,
                Some(&execution),
            );
        }
        return crate::costs::pay_mana_cost_with_choices_and_outputs(
            game,
            cost_ctx.payer,
            Some(cost_ctx.source),
            &adjusted_cost,
            cost_ctx.x_value.unwrap_or(0),
            cost_ctx.reason,
            cost_ctx.decision_maker,
            Some(&execution),
        );
    }
    if let Some(dynamic_mana) = component.dynamic_mana_cost_ref() {
        let mut execution = ExecutionContext::new_default(cost_ctx.source, cost_ctx.payer)
            .with_tagged_objects(cost_ctx.tagged_objects.clone());
        execution.source_snapshot = cost_ctx.source_snapshot.clone();
        execution.replacement = cost_ctx.replacement.clone();
        execution.x_value = cost_ctx.x_value;
        execution.effect_outcomes = cost_ctx.effect_outcomes.clone();
        let resolved = resolve_dynamic_mana_cost(game, dynamic_mana, &mut execution)?;
        return pay_component_without_execution_context_with_outputs(
            game,
            &crate::costs::Cost::mana(resolved),
            cost_ctx,
        );
    }
    pay_cost_component_with_choice_with_outputs(game, component, cost_ctx)
}

fn pay_component_in_context_with_outputs(
    game: &mut GameState,
    payer: PlayerId,
    source: ObjectId,
    component: &crate::costs::Cost,
    reason: crate::costs::PaymentReason,
    provenance: crate::provenance::ProvNodeId,
    execution_ctx: &mut ExecutionContext<'_>,
    reserved_tap_sources: Vec<ObjectId>,
) -> Result<Vec<crate::effects::CompletedEffectOutputs>, CostPaymentError> {
    if let Some(dynamic_mana) = component.dynamic_mana_cost_ref() {
        let resolved = resolve_dynamic_mana_cost(game, dynamic_mana, execution_ctx)?;
        let adjusted_cost =
            game.adjust_mana_cost_for_payment_reason(payer, Some(source), &resolved, reason);
        let execution = crate::effects::ExecutionContextCheckpoint::capture(execution_ctx);
        if adjusted_cost.has_waterbend_obligation() || reason == crate::costs::PaymentReason::Effect {
            return crate::mana_payment::pay_mana_interactively_in_context_with_outputs(
                game,
                payer,
                source,
                adjusted_cost,
                reason,
                Vec::new(),
                reserved_tap_sources,
                execution_ctx.decision_maker,
                Some(&execution),
            );
        }
        return crate::costs::pay_mana_cost_with_choices_and_outputs(
            game,
            payer,
            Some(source),
            &adjusted_cost,
            execution_ctx.x_value.unwrap_or(0),
            reason,
            execution_ctx.decision_maker,
            Some(&execution),
        );
    }
    let mut cost_ctx = CostContext::from_execution_context(source, payer, reason, execution_ctx)
        .with_provenance(provenance);
    cost_ctx.reserved_tap_sources = reserved_tap_sources;
    let result =
        pay_component_without_execution_context_with_outputs(game, component, &mut cost_ctx);
    let tags = std::mem::take(&mut cost_ctx.tagged_objects);
    let outcomes = std::mem::take(&mut cost_ctx.effect_outcomes);
    let x_value = cost_ctx.x_value;
    let inputs = cost_ctx.execution_inputs.take();
    drop(cost_ctx);
    if let Some(inputs) = inputs {
        inputs.restore_ref(execution_ctx);
    }
    execution_ctx.tagged_objects = tags;
    execution_ctx.effect_outcomes = outcomes;
    execution_ctx.x_value = x_value;
    result
}

fn resolve_and_adjust_component_in_context(
    game: &GameState,
    payer: PlayerId,
    source: ObjectId,
    component: &crate::costs::Cost,
    reason: crate::costs::PaymentReason,
    execution_ctx: &mut ExecutionContext<'_>,
) -> Result<crate::costs::Cost, CostPaymentError> {
    if let Some(dynamic_mana) = component.dynamic_mana_cost_ref() {
        // This is a feasibility query before announcement. Like a plain {X}
        // component, an unbound authored dynamic base can be considered at 0;
        // execution still requires the explicit announced X.
        let previous_x = execution_ctx.x_value;
        if previous_x.is_none() && dynamic_mana.base.has_x() && dynamic_mana.x_value.is_none() {
            execution_ctx.x_value = Some(0);
        }
        let resolved = resolve_dynamic_mana_cost(game, dynamic_mana, execution_ctx);
        execution_ctx.x_value = previous_x;
        let resolved = resolved?;
        return Ok(crate::costs::Cost::mana(
            game.adjust_mana_cost_for_payment_reason(payer, Some(source), &resolved, reason),
        ));
    }
    crate::cost::adjusted_component_for_check(game, payer, source, component, reason)
}

pub(crate) fn resolve_dynamic_mana_cost(
    game: &GameState,
    dynamic_mana: &ironsmith_core::DynamicManaCost,
    execution_ctx: &mut ExecutionContext<'_>,
) -> Result<ManaCost, CostPaymentError> {
    let source_exiled = game
        .get_exiled_with_source_links(execution_ctx.source)
        .iter()
        .filter_map(|id| {
            game.object(*id).map(|object| {
                ObjectSnapshot::from_object_with_calculated_characteristics(object, game)
            })
        })
        .collect::<Vec<_>>();
    execution_ctx.set_tagged_objects(crate::tag::SOURCE_EXILED_TAG, source_exiled);

    let referenced_mana = if let Some(spec) = dynamic_mana.mana_cost_of.as_deref() {
        if dynamic_mana.source_mana_cost {
            return Err(CostPaymentError::Other(
                "ambiguous referenced mana cost".into(),
            ));
        }
        let objects = match spec.base() {
            crate::target::ChooseSpec::Object(filter) | crate::target::ChooseSpec::All(filter) => {
                let mut context = execution_ctx.filter_context(game);
                let zone = filter.zone.unwrap_or(Zone::Battlefield);
                game.objects_in_zone(zone)
                    .into_iter()
                    .filter(|id| {
                        game.object(*id)
                            .is_some_and(|object| filter.matches(object, &context, game))
                    })
                    .collect()
            }
            _ => crate::effects::helpers::resolve_objects_from_spec(game, spec, execution_ctx)
                .map_err(CostPaymentError::ExecutionFailed)?,
        };
        let [id] = objects.as_slice() else {
            return Err(CostPaymentError::Other(
                "mana cost needs one exact referenced object".into(),
            ));
        };
        let object = game
            .object(*id)
            .ok_or_else(|| CostPaymentError::Other("mana-cost object has departed".into()))?;
        if let crate::target::ChooseSpec::Tagged(tag) = spec.base() {
            if execution_ctx
                .tagged_objects
                .get(tag)
                .is_none_or(|snapshots| snapshots.len() != 1 || snapshots[0].object_id != *id)
            {
                return Err(CostPaymentError::Other(
                    "mana-cost reference changed incarnation".into(),
                ));
            }
        }
        let cost = crate::filter::object_current_mana_cost(game, *id).ok_or_else(|| {
            CostPaymentError::Other("referenced object has no payable mana cost".into())
        })?;
        // CR 107.3g: X on an object outside the stack is zero. It is not
        // a new variable announced for this ability.
        Some((
            cost,
            if object.zone == Zone::Stack {
                object.x_value.unwrap_or(0)
            } else {
                0
            },
        ))
    } else {
        None
    };
    let base = if let Some((cost, _)) = &referenced_mana {
        cost.clone()
    } else if dynamic_mana.source_mana_cost {
        // A current missing mana cost is not an older printed cost. Only
        // an unavailable (departed/phased) source uses exact retained LKI.
        let current = game
            .try_current_characteristics(execution_ctx.source)
            .map_err(|error| {
                CostPaymentError::ExecutionFailed(
                    crate::effects::ExecutionError::ContinuousDiscovery(error),
                )
            })?;
        let cost =
            if let Some(characteristics) = current {
                characteristics.mana_cost
            } else {
                let snapshot =
                    execution_ctx
                        .source_snapshot
                        .as_ref()
                        .filter(|snapshot| snapshot.object_id == execution_ctx.source)
                        .ok_or_else(|| {
                            CostPaymentError::ExecutionFailed(
                    crate::effects::ExecutionError::IncompleteEvidence(
                        "source mana-cost payment requires exact retained source identity".into()))
                        })?;
                snapshot.mana_cost.clone()
            };
        cost.ok_or_else(|| {
            CostPaymentError::Other(
                "ability source has no mana cost to use as a dynamic cost".to_string(),
            )
        })?
    } else {
        dynamic_mana.base.clone()
    };

    let x_value = if let Some((_, x)) = referenced_mana {
        x
    } else if let Some(value) = dynamic_mana.x_value.as_ref() {
        resolve_dynamic_u32(game, value, execution_ctx)?
    } else if dynamic_mana.source_mana_cost
        && game
            .object(execution_ctx.source)
            .map(|object| object.zone)
            .or_else(|| {
                execution_ctx
                    .source_snapshot
                    .as_ref()
                    .map(|snapshot| snapshot.zone)
            })
            != Some(Zone::Stack)
    {
        // X in a permanent's mana cost is zero, not a new trigger choice.
        0
    } else if base.has_x() {
        execution_ctx.x_value.ok_or_else(|| {
            CostPaymentError::Other("dynamic X mana cost has no X value".to_string())
        })?
    } else {
        0
    };
    let additional_generic = dynamic_mana
        .additional_generic
        .as_ref()
        .map(|value| resolve_dynamic_u32(game, value, execution_ctx))
        .transpose()?
        .unwrap_or(0);
    let multiplier = dynamic_mana
        .multiplier
        .as_ref()
        .map(|value| resolve_dynamic_u32(game, value, execution_ctx))
        .transpose()?
        .unwrap_or(1);

    let mut expanded =
        expand_dynamic_mana_base(&base, x_value, multiplier).add_generic(additional_generic);
    if dynamic_mana.generic_reduction > 0 {
        expanded = expanded.reduce_generic(dynamic_mana.generic_reduction);
    }
    let Some(condition) = dynamic_mana.source_mana_cost_reduction_condition.as_deref() else {
        return Ok(expanded);
    };
    let applies =
        crate::condition_eval::evaluate_condition_resolution(game, condition, execution_ctx)
            .map_err(CostPaymentError::ExecutionFailed)?;
    if !applies {
        return Ok(expanded);
    }
    // A source with no mana cost contributes no reduction (CR 702.193b).
    let reduction = game
        .current_characteristics(execution_ctx.source)
        .and_then(|characteristics| characteristics.mana_cost)
        .unwrap_or_default();
    let options = expanded.reduced_by_mana_cost_options(&reduction);
    if options.len() == 1 {
        return Ok(options[0].clone());
    }
    use crate::decisions::context::{SelectOptionsContext, SelectableOption};
    let choice = SelectOptionsContext::new(
        execution_ctx.controller,
        Some(execution_ctx.source),
        "Choose mana cost after reduction",
        options
            .iter()
            .enumerate()
            .map(|(index, cost)| SelectableOption::new(index, cost.to_oracle()))
            .collect(),
        1,
        1,
    );
    let selected = execution_ctx.decision_maker.decide_options(game, &choice);
    if execution_ctx.decision_maker.awaiting_choice() {
        return Err(CostPaymentError::Other(
            "awaiting mana reduction payment choice".into(),
        ));
    }
    match selected.as_slice() {
        [index] => options
            .get(*index)
            .cloned()
            .ok_or_else(|| CostPaymentError::Other("invalid mana reduction choice".into())),
        _ => Err(CostPaymentError::Other(
            "mana reduction requires one payment choice".into(),
        )),
    }
}

fn resolve_dynamic_u32(
    game: &GameState,
    value: &crate::effect::Value,
    execution_ctx: &mut ExecutionContext<'_>,
) -> Result<u32, CostPaymentError> {
    crate::effects::helpers::resolve_value(game, value, execution_ctx)
        .map(|value| value.max(0) as u32)
        .map_err(CostPaymentError::ExecutionFailed)
}

fn expand_dynamic_mana_base(base: &ManaCost, x_value: u32, multiplier: u32) -> ManaCost {
    let mut pips = Vec::new();
    let mut generic_to_add = 0;
    for _ in 0..multiplier {
        for pip in base.pips() {
            if pip.len() == 1 && matches!(pip[0], ManaSymbol::X) {
                generic_to_add += x_value;
                continue;
            }
            pips.push(
                pip.iter()
                    .map(|symbol| match symbol {
                        ManaSymbol::X => ManaSymbol::Generic(x_value.min(u8::MAX as u32) as u8),
                        other => *other,
                    })
                    .collect(),
            );
        }
    }
    base.with_pips(pips).add_generic(generic_to_add)
}

fn resolve_cost_choice(
    game: &mut GameState,
    cost: &crate::costs::Cost,
    ctx: &mut CostContext,
) -> Result<(), CostPaymentError> {
    resolve_cost_choice_with_outputs(game, cost, ctx).map(|_| ())
}

fn resolve_cost_choice_with_outputs(
    game: &mut GameState,
    cost: &crate::costs::Cost,
    ctx: &mut CostContext,
) -> Result<Vec<crate::effects::CompletedEffectOutputs>, CostPaymentError> {
    use crate::costs::CostProcessingMode;

    match cost.processing_mode() {
        CostProcessingMode::SacrificeTarget { filter } => {
            let checkpoint = game.clone();
            let payment =
                (|| -> Result<Vec<crate::effects::CompletedEffectOutputs>, CostPaymentError> {
                    let candidates = legal_sacrifice_targets(
                        game,
                        ctx.payer,
                        ctx.source,
                        &filter,
                        ctx.reason,
                        &ctx.event_cause(),
                    );
                    if candidates.is_empty() {
                        return Err(CostPaymentError::NoValidSacrificeTarget);
                    }

                    let spec = ChooseObjectsSpec::new(
                        ctx.source,
                        format!("Choose {} to sacrifice", describe_permanent_filter(&filter)),
                        candidates.clone(),
                        1,
                        Some(1),
                    );
                    let chosen: Vec<ObjectId> =
                        make_decision(game, ctx.decision_maker, ctx.payer, Some(ctx.source), spec);
                    if ctx.decision_maker.awaiting_choice() {
                        return Err(CostPaymentError::Other(
                            "awaiting sacrifice cost target".into(),
                        ));
                    }
                    let Some(target_id) =
                        normalize_selection(chosen, &candidates, 1).first().copied()
                    else {
                        return Err(CostPaymentError::NoValidSacrificeTarget);
                    };

                    let cause = ctx.event_cause();
                    // Legality precedes starting payment. Once a legal sacrifice cost
                    // starts, its replacement/prevention does not make it unpaid (118.11).
                    if !game.can_be_sacrificed_with_cause(target_id, &cause) {
                        return Err(CostPaymentError::NoValidSacrificeTarget);
                    }
                    let snapshot = game.object(target_id).map(|object| {
                        ObjectSnapshot::from_object_with_calculated_characteristics(object, game)
                    });
                    let sacrificing_player = snapshot
                        .as_ref()
                        .map(|snapshot| snapshot.controller)
                        .or(Some(ctx.payer));
                    let source_snapshot = ctx.source_snapshot.clone().or_else(|| {
                        game.object(ctx.source).map(|object| {
                            ObjectSnapshot::from_object_with_calculated_characteristics(
                                object, game,
                            )
                        })
                    });
                    let mut execution =
                        ExecutionContext::new(ctx.source, ctx.payer, &mut *ctx.decision_maker)
                            .with_cause(cause.clone())
                            .with_provenance(ctx.provenance)
                            .with_tagged_objects(ctx.tagged_objects.clone());
                    execution.effect_outcomes = ctx.effect_outcomes.clone();
                    execution.announced_targets = Some(
                        ctx.announced_targets
                            .iter()
                            .map(|target| match target {
                                crate::game_state::Target::Object(id) => {
                                    crate::effects::ResolvedTarget::Object(*id)
                                }
                                crate::game_state::Target::Player(id) => {
                                    crate::effects::ResolvedTarget::Player(*id)
                                }
                            })
                            .collect(),
                    );
                    execution.source_snapshot = source_snapshot;
                    execution.replacement = ctx.replacement.clone();
                    execution.x_value = ctx.x_value;
                    let additional = execution.additional_replacement_effects_snapshot();
                    let receipt =
                    crate::effects::zones::apply_zone_change_with_context_and_additional_effects(
                        game,
                        target_id,
                        Zone::Battlefield,
                        Zone::Graveyard,
                        cause,
                        &mut execution,
                        &additional,
                    )
                    .map_err(CostPaymentError::ExecutionFailed)?;
                    if execution.decision_maker.awaiting_choice() {
                        return Err(CostPaymentError::Other(
                            "awaiting sacrifice cost replacement".into(),
                        ));
                    }
                    let performed = matches!(&receipt.original, EventOutcome::Proceed(_));
                    if performed {
                        let provenance = game.alloc_child_event_provenance(
                            ctx.provenance,
                            crate::events::EventKind::Sacrifice,
                        );
                        game.queue_trigger_event(
                            ctx.provenance,
                            TriggerEvent::new_with_provenance(
                                SacrificeEvent::new(target_id, Some(ctx.source))
                                    .with_snapshot(snapshot, sacrificing_player),
                                provenance,
                            ),
                        );
                    }
                    let mut outputs =
                        crate::effects::zones::finish_zone_change_receipts_with_outputs(
                            game,
                            &mut execution,
                            crate::effect::EffectOutcome::count(i32::from(performed)),
                            vec![(target_id, receipt)],
                        )
                        .map_err(CostPaymentError::ExecutionFailed)?;
                    if execution.decision_maker.awaiting_choice() {
                        return Err(CostPaymentError::Other(
                            "awaiting sacrifice cost added program".into(),
                        ));
                    }
                    let mut reported = outputs.outcome.events.clone();
                    crate::effects::retain_unmatched_outcome_events(game, &mut reported);
                    for event in reported {
                        game.queue_trigger_event(event.provenance(), event);
                    }
                    outputs.synchronize_observations();
                    Ok(vec![outputs])
                })();
            if payment.is_err() || ctx.decision_maker.awaiting_choice() {
                *game = checkpoint;
            }
            payment
        }
        CostProcessingMode::DiscardCards { count, filter } => {
            let checkpoint = game.clone();
            let result = (|| {
                let candidates =
                    crate::costs::legal_discard_cost_cards_in_context(game, ctx, &filter);
                let required = (count as usize).min(candidates.len());
                if required < count as usize {
                    return Err(CostPaymentError::InsufficientCardsInHand);
                }
                if required == 0 {
                    return Ok(Vec::new());
                }

                let spec = ChooseObjectsSpec::new(
                    ctx.source,
                    format!(
                        "Choose {} card{} to discard",
                        required,
                        if required == 1 { "" } else { "s" }
                    ),
                    candidates.clone(),
                    required,
                    Some(required),
                )
                // Discarded hidden cards are opened publicly before the answer is
                // replayed, so every peer applies Madness and discard triggers to
                // the same identities (see `game_state::hidden_hand_choices`).
                .with_selection_reveal_policy(
                    crate::decisions::context::SelectionRevealPolicy::Public,
                );
                let chosen: Vec<ObjectId> =
                    make_decision(game, ctx.decision_maker, ctx.payer, Some(ctx.source), spec);
                if ctx.decision_maker.awaiting_choice() {
                    return Err(CostPaymentError::Other(
                        "awaiting discard cost selection".into(),
                    ));
                }
                let to_discard = normalize_selection(chosen, &candidates, required);

                if to_discard.len() != required {
                    return Err(CostPaymentError::InsufficientCardsInHand);
                }

                let cause = ctx.event_cause();
                let mut execution =
                    ExecutionContext::new(ctx.source, ctx.payer, &mut *ctx.decision_maker)
                        .with_cause(cause)
                        .with_provenance(ctx.provenance);
                execution.source_snapshot = ctx.source_snapshot.clone();
                execution.replacement = ctx.replacement.clone();
                execution.x_value = ctx.x_value;
                let Some(prepared) = crate::effects::cards::prepare_selected_discard_batch(
                    game,
                    &mut execution,
                    ctx.payer,
                    to_discard,
                    None,
                    true,
                )
                .map_err(CostPaymentError::ExecutionFailed)?
                else {
                    return Err(CostPaymentError::Other(
                        "awaiting discard cost replacement".into(),
                    ));
                };
                let committed = crate::effects::cards::commit_selected_discard_batch(
                    game,
                    &mut execution,
                    prepared,
                )
                .map_err(CostPaymentError::ExecutionFailed)?;
                if execution.decision_maker.awaiting_choice() {
                    return Err(CostPaymentError::Other(
                        "awaiting discard cost replacement".into(),
                    ));
                }
                // A legal started payment remains paid when its action is changed
                // or prevented; the shared packet reports actual original discards.
                let Some(originals) = committed
                    .prepare_completion_with_outputs(game, &mut execution)
                    .map_err(CostPaymentError::ExecutionFailed)?
                else {
                    return Err(CostPaymentError::Other(
                        "awaiting discard cost replacement".into(),
                    ));
                };
                let mut outputs = originals
                    .complete_added_programs_with_outputs(game, &mut execution)
                    .map_err(CostPaymentError::ExecutionFailed)?;
                if execution.decision_maker.awaiting_choice() {
                    return Err(CostPaymentError::Other(
                        "awaiting discard cost added program".into(),
                    ));
                }
                let mut reported = outputs.outcome.events.clone();
                crate::effects::retain_unmatched_outcome_events(game, &mut reported);
                for event in reported {
                    game.queue_trigger_event(event.provenance(), event);
                }
                outputs.synchronize_observations();
                Ok(vec![outputs])
            })();
            if result.is_err() || ctx.decision_maker.awaiting_choice() {
                *game = checkpoint;
            }
            result
        }
        CostProcessingMode::ExileFromHand {
            count,
            color_filter,
        } => {
            let candidates = legal_exile_cards(game, ctx.payer, ctx.source, color_filter);
            let required = count as usize;
            if candidates.len() < required {
                return Err(CostPaymentError::InsufficientCardsToExile);
            }

            let spec = hidden_hand_cost_choice_spec(
                game,
                ChooseObjectsSpec::new(
                    ctx.source,
                    format!(
                        "Choose {} card{} to exile from your hand",
                        required,
                        if required == 1 { "" } else { "s" }
                    ),
                    candidates.clone(),
                    required,
                    Some(required),
                ),
                &candidates,
                crate::decisions::context::SelectionRevealPolicy::Public,
            );
            let chosen: Vec<ObjectId> =
                make_decision(game, ctx.decision_maker, ctx.payer, Some(ctx.source), spec);
            let to_exile = normalize_selection(chosen, &candidates, required);
            if to_exile.len() != required {
                return Err(CostPaymentError::InsufficientCardsToExile);
            }

            let stable_ids = cost_exiled_from_hand_identities(game, &to_exile);
            ctx.pre_chosen_cards.extend(to_exile);
            let receipt = cost.pay_with_outputs(game, ctx)?;
            match receipt.result {
                CostPaymentResult::Paid => {
                    publish_cost_exiled_from_hand(game, ctx, &stable_ids);
                    Ok(receipt.outputs.into_iter().collect())
                }
                CostPaymentResult::NeedsChoice(_) => Err(CostPaymentError::Other(
                    "Exile-from-hand cost still needs choice after preselection".to_string(),
                )),
            }
        }
        CostProcessingMode::ExileFromGraveyard { count, card_type } => {
            let candidates = legal_exile_from_graveyard_cards(game, ctx.payer, card_type);
            let required = count as usize;
            if candidates.len() < required {
                return Err(CostPaymentError::InsufficientCardsInGraveyard);
            }

            let spec = ChooseObjectsSpec::new(
                ctx.source,
                format!(
                    "Choose {} card{} to exile from your graveyard",
                    required,
                    if required == 1 { "" } else { "s" }
                ),
                candidates.clone(),
                required,
                Some(required),
            );
            let chosen: Vec<ObjectId> =
                make_decision(game, ctx.decision_maker, ctx.payer, Some(ctx.source), spec);
            let to_exile = normalize_selection(chosen, &candidates, required);
            if to_exile.len() != required {
                return Err(CostPaymentError::InsufficientCardsInGraveyard);
            }

            ctx.pre_chosen_cards.extend(to_exile);
            let receipt = cost.pay_with_outputs(game, ctx)?;
            match receipt.result {
                CostPaymentResult::Paid => Ok(receipt.outputs.into_iter().collect()),
                CostPaymentResult::NeedsChoice(_) => Err(CostPaymentError::Other(
                    "Exile-from-graveyard cost still needs choice after preselection".to_string(),
                )),
            }
        }
        CostProcessingMode::ExileObjects {
            count,
            filter,
            zone,
        } => {
            let candidates = legal_exile_objects(game, ctx.payer, ctx.source, &filter, zone);
            let required = count as usize;
            if candidates.len() < required {
                return Err(CostPaymentError::InsufficientCardsToExile);
            }

            let spec = hidden_hand_cost_choice_spec(
                game,
                ChooseObjectsSpec::new(
                    ctx.source,
                    format!(
                        "Choose {} object{} to exile",
                        required,
                        if required == 1 { "" } else { "s" }
                    ),
                    candidates.clone(),
                    required,
                    Some(required),
                ),
                &candidates,
                crate::decisions::context::SelectionRevealPolicy::Public,
            );
            let chosen: Vec<ObjectId> =
                make_decision(game, ctx.decision_maker, ctx.payer, Some(ctx.source), spec);
            let to_exile = normalize_selection(chosen, &candidates, required);
            if to_exile.len() != required {
                return Err(CostPaymentError::InsufficientCardsToExile);
            }

            ctx.pre_chosen_cards.extend(to_exile);
            let receipt = cost.pay_with_outputs(game, ctx)?;
            match receipt.result {
                CostPaymentResult::Paid => Ok(receipt.outputs.into_iter().collect()),
                CostPaymentResult::NeedsChoice(_) => Err(CostPaymentError::Other(
                    "Exile-object cost still needs choice after preselection".to_string(),
                )),
            }
        }
        CostProcessingMode::RevealFromHand {
            count,
            card_type,
            color_filter,
        } => {
            let candidates =
                legal_reveal_cards(game, ctx.payer, ctx.source, card_type, color_filter);
            let required = resolve_cost_count(&count, ctx.x_value) as usize;
            if candidates.len() < required {
                return Err(CostPaymentError::InsufficientCardsToReveal);
            }

            let spec = hidden_hand_cost_choice_spec(
                game,
                ChooseObjectsSpec::new(
                    ctx.source,
                    format!(
                        "Choose {} card{} to reveal from your hand",
                        required,
                        if required == 1 { "" } else { "s" }
                    ),
                    candidates.clone(),
                    required,
                    Some(required),
                ),
                &candidates,
                crate::decisions::context::SelectionRevealPolicy::Public,
            );
            let chosen: Vec<ObjectId> =
                make_decision(game, ctx.decision_maker, ctx.payer, Some(ctx.source), spec);
            if ctx.decision_maker.awaiting_choice() {
                return Ok(Vec::new());
            }
            if !crate::effects::cards::is_exact_reveal_selection(&chosen, &candidates, required) {
                return Err(CostPaymentError::InsufficientCardsToReveal);
            }

            ctx.pre_chosen_cards.extend(chosen);
            let receipt = cost.pay_with_outputs(game, ctx)?;
            match receipt.result {
                CostPaymentResult::Paid => Ok(receipt.outputs.into_iter().collect()),
                CostPaymentResult::NeedsChoice(_) => Err(CostPaymentError::Other(
                    "Reveal cost still needs choice after preselection".to_string(),
                )),
            }
        }
        CostProcessingMode::ReturnToHandTarget { filter } => {
            let candidates = legal_return_targets(game, ctx.payer, ctx.source, &filter);
            if candidates.is_empty() {
                return Err(CostPaymentError::NoValidReturnTarget);
            }
            let spec = ChooseObjectsSpec::new(
                ctx.source,
                format!(
                    "Choose {} to return to hand",
                    describe_permanent_filter(&filter)
                ),
                candidates.clone(),
                1,
                Some(1),
            );
            let chosen: Vec<ObjectId> =
                make_decision(game, ctx.decision_maker, ctx.payer, Some(ctx.source), spec);
            let Some(target) = normalize_selection(chosen, &candidates, 1).first().copied() else {
                return Err(CostPaymentError::NoValidReturnTarget);
            };

            ctx.pre_chosen_cards.push(target);
            let receipt = cost.pay_with_outputs(game, ctx)?;
            match receipt.result {
                CostPaymentResult::Paid => Ok(receipt.outputs.into_iter().collect()),
                CostPaymentResult::NeedsChoice(_) => Err(CostPaymentError::Other(
                    "Return-to-hand cost still needs choice after preselection".to_string(),
                )),
            }
        }
        CostProcessingMode::ManaPayment { .. }
        | CostProcessingMode::Immediate
        | CostProcessingMode::InlineWithTriggers => Err(CostPaymentError::Other(
            "Cost unexpectedly requested choice in non-choice mode".to_string(),
        )),
    }
}

fn legal_sacrifice_targets(
    game: &GameState,
    payer: PlayerId,
    source: ObjectId,
    filter: &ObjectFilter,
    reason: crate::costs::PaymentReason,
    cause: &crate::events::cause::EventCause,
) -> Vec<ObjectId> {
    let mut ctx = FilterContext {
        you: Some(payer),
        source: Some(source),
        ..Default::default()
    };
    game.battlefield
        .iter()
        .copied()
        .filter(|&id| {
            game.object(id).is_some_and(|obj| {
                filter.matches(obj, &ctx, game)
                    && game.can_be_sacrificed_with_cause(id, cause)
                    && (!reason.is_cast_or_ability_payment()
                        || !game.player_cant_sacrifice_object_to_cast_or_activate(payer, id))
            })
        })
        .collect()
}

fn legal_discard_cards(
    game: &GameState,
    player: PlayerId,
    source: ObjectId,
    filter: &crate::filter::ObjectFilter,
) -> Vec<ObjectId> {
    crate::costs::legal_discard_cost_cards(game, player, source, filter)
}

fn legal_exile_cards(
    game: &GameState,
    payer: PlayerId,
    source: ObjectId,
    color_filter: Option<crate::color::ColorSet>,
) -> Vec<ObjectId> {
    let placeholders = color_filter.map_or_else(Vec::new, |colors| {
        let hand = game
            .player(payer)
            .map_or_else(Vec::new, |p| p.hand.to_vec());
        hand_cost_placeholders(
            game,
            payer,
            source,
            &ObjectFilter::default()
                .in_zone(Zone::Hand)
                .with_colors(colors),
            &hand,
        )
    });
    game.player(payer)
        .map(|p| {
            p.hand
                .iter()
                .copied()
                .filter(|&card_id| {
                    if placeholders.contains(&card_id) {
                        return true;
                    }
                    if card_id == source {
                        return false;
                    }
                    if let Some(required) = color_filter {
                        return game.object(card_id).is_some_and(|obj| {
                            let colors = obj.colors();
                            !colors.intersection(required).is_empty()
                        });
                    }
                    true
                })
                .collect()
        })
        .unwrap_or_default()
}

fn legal_exile_from_graveyard_cards(
    game: &GameState,
    payer: PlayerId,
    card_type: Option<crate::types::CardType>,
) -> Vec<ObjectId> {
    game.player(payer)
        .map(|p| {
            p.graveyard
                .iter()
                .copied()
                .filter(|&card_id| {
                    if let Some(ct) = card_type {
                        return game
                            .object(card_id)
                            .is_some_and(|obj| obj.has_card_type(ct));
                    }
                    true
                })
                .collect()
        })
        .unwrap_or_default()
}

fn legal_exile_objects(
    game: &GameState,
    payer: PlayerId,
    source: ObjectId,
    filter: &ObjectFilter,
    zone: Zone,
) -> Vec<ObjectId> {
    let ids: Vec<ObjectId> = match zone {
        Zone::Battlefield => game.battlefield.to_vec(),
        Zone::Hand => game
            .player(payer)
            .map(|p| p.hand.to_vec())
            .unwrap_or_default(),
        Zone::Graveyard => game
            .player(payer)
            .map(|p| p.graveyard.to_vec())
            .unwrap_or_default(),
        Zone::Exile => game.exile.to_vec(),
        _ => Vec::new(),
    };
    let mut ctx = game.filter_context_for(payer, Some(source));
    let placeholders = if zone == Zone::Hand {
        hand_cost_placeholders(game, payer, source, filter, &ids)
    } else {
        Vec::new()
    };
    ids.into_iter()
        .filter(|&id| {
            placeholders.contains(&id)
                || game.object(id).is_some_and(|obj| {
                    if filter.other && obj.id == source {
                        return false;
                    }
                    filter.matches(obj, &ctx, game)
                })
        })
        .collect()
}

fn legal_reveal_cards(
    game: &GameState,
    payer: PlayerId,
    source: ObjectId,
    card_type: Option<crate::types::CardType>,
    color_filter: Option<crate::color::ColorSet>,
) -> Vec<ObjectId> {
    crate::effects::cards::legal_reveal_from_hand_cards(
        game,
        payer,
        source,
        card_type,
        color_filter,
    )
}

fn resolve_cost_count(count: &crate::effect::Value, x_value: Option<u32>) -> u32 {
    match count {
        crate::effect::Value::Fixed(count) => (*count).max(0) as u32,
        crate::effect::Value::X => x_value.unwrap_or(0),
        _ => 0,
    }
}

fn legal_return_targets(
    game: &GameState,
    payer: PlayerId,
    source: ObjectId,
    filter: &ObjectFilter,
) -> Vec<ObjectId> {
    let mut ctx = FilterContext {
        you: Some(payer),
        source: Some(source),
        ..Default::default()
    };
    game.battlefield
        .iter()
        .copied()
        .filter(|&id| {
            game.object(id)
                .is_some_and(|obj| filter.matches(obj, &ctx, game))
        })
        .collect()
}

fn legal_cost_choice_objects(
    game: &GameState,
    payer: PlayerId,
    source: ObjectId,
    filter: &ObjectFilter,
    zone: Zone,
    top_only: bool,
) -> Vec<ObjectId> {
    let mut ctx = game.filter_context_for(payer, Some(source));

    let ids: Vec<ObjectId> = match zone {
        Zone::Battlefield => game.battlefield.to_vec(),
        Zone::Hand => game
            .player(payer)
            .map(|p| p.hand.to_vec())
            .unwrap_or_default(),
        Zone::Graveyard => game.player(payer).map_or_else(Vec::new, |p| {
            if top_only {
                p.graveyard.iter().rev().copied().collect()
            } else {
                p.graveyard.to_vec()
            }
        }),
        Zone::Exile => game.exile.to_vec(),
        _ => Vec::new(),
    };

    let placeholders = if zone == Zone::Hand {
        hand_cost_placeholders(game, payer, source, filter, &ids)
    } else {
        Vec::new()
    };
    let mut candidates = ids
        .into_iter()
        .filter(|&id| {
            placeholders.contains(&id)
                || game.object(id).is_some_and(|obj| {
                    if filter.other && obj.id == source {
                        return false;
                    }
                    filter.matches(obj, &ctx, game)
                })
        })
        .collect::<Vec<_>>();
    if top_only {
        candidates.truncate(1);
    }
    candidates
}

fn normalize_selection(
    chosen: Vec<ObjectId>,
    candidates: &[ObjectId],
    required: usize,
) -> Vec<ObjectId> {
    let mut selected = Vec::with_capacity(required);

    for id in chosen {
        if selected.len() == required {
            break;
        }
        if candidates.contains(&id) && !selected.contains(&id) {
            selected.push(id);
        }
    }

    if selected.len() < required {
        for &id in candidates {
            if selected.len() == required {
                break;
            }
            if !selected.contains(&id) {
                selected.push(id);
            }
        }
    }

    selected
}

fn describe_permanent_filter(filter: &ObjectFilter) -> String {
    let mut parts: Vec<String> = Vec::new();

    if filter.other {
        parts.push("another".to_string());
    }
    if filter.nontoken {
        parts.push("nontoken".to_string());
    }
    if filter.token {
        parts.push("token".to_string());
    }
    if !filter.card_types.is_empty() {
        let types = filter
            .card_types
            .iter()
            .map(|t| t.name().to_string())
            .collect::<Vec<_>>()
            .join(" or ");
        parts.push(types);
    } else {
        parts.push("permanent".to_string());
    }

    parts.join(" ")
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::ability::Ability;
    use crate::card::{CardBuilder, PowerToughness};
    #[cfg(ironsmith_runtime_parser_tests)]
    use crate::cards::definitions::blood_celebrant;
    use crate::decision::SelectFirstDecisionMaker;
    use crate::game_state::Phase;
    use crate::grant::Grantable;
    use crate::ids::{CardId, PlayerId};
    use crate::mana::{ManaCost, ManaSymbol};
    use crate::static_abilities::StaticAbility;
    use crate::types::CardType;
    use crate::zone::Zone;

    #[test]
    fn tapped_mana_filter_rejects_funding_but_preserves_cost_alternatives() {
        let mana_ability = |cost, output| {
            let mut ability = Ability::mana(crate::cost::TotalCost::free(), output);
            let crate::ability::AbilityKind::Activated(activated) = &mut ability.kind else {
                unreachable!();
            };
            activated.mana_cost = cost;
            ability
        };
        let alice = PlayerId::from_index(0);
        let mut game = setup_game();
        let producer = CardBuilder::new(CardId::new(), "Repeatable producer")
            .card_types(vec![CardType::Artifact])
            .build();
        let producer = game.create_object_from_card(&producer, alice, Zone::Battlefield);
        game.object_mut(producer)
            .unwrap()
            .abilities_mut()
            .push(mana_ability(
                crate::cost::TotalCost::free(),
                vec![ManaSymbol::Blue],
            ));
        let filter = CardBuilder::new(CardId::new(), "Tapped filter")
            .card_types(vec![CardType::Artifact])
            .build();
        let filter = game.create_object_from_card(&filter, alice, Zone::Battlefield);
        let tap_branch = crate::cost::TotalCost::from_costs(vec![
            crate::costs::Cost::mana(ManaCost::new().add_generic(1)),
            crate::costs::Cost::tap(),
        ]);
        game.object_mut(filter).unwrap().abilities_mut().push(
            mana_ability(tap_branch.clone(), vec![ManaSymbol::Green]),
        );
        game.tap(filter);
        assert!(matches!(
            can_activate_mana_ability_check(&game, alice, filter, 0),
            Err(ActionError::CantPayCost)
        ));
        let alternatives = crate::cost::TotalCost::one_of(vec![
            tap_branch,
            crate::cost::TotalCost::free(),
        ]);
        let view = crate::derived_view::DerivedGameView::new(&game);
        let mut dm = SelectFirstDecisionMaker;
        let mut ctx = ExecutionContext::new(filter, alice, &mut dm);
        assert!(can_pay_total_cost_in_context_with_funding(
            &game,
            alice,
            filter,
            &alternatives,
            crate::costs::PaymentReason::Effect,
            &mut ctx,
            CostQueryFunding::PotentialMana(&view, None),
        ).is_ok());
        assert!(game.is_tapped(filter));
        assert_eq!(game.player(alice).unwrap().mana_pool.total(), 0);
        game.untap(filter);
        assert!(can_activate_mana_ability_check(&game, alice, filter, 0).is_ok());
        assert_eq!(game.player(alice).unwrap().mana_pool.total(), 0);
    }

    #[test]
    fn sacrifice_protection_blocks_opponent_requested_costs_but_allows_own_costs() {
        use crate::costs::PaymentReason;
        use crate::events::cause::{
            CauseFilter, CauseType, CauseTypeFilter, ControllerFilter, EventCause,
        };
        use crate::filter::ObjectFilter;
        let alice = PlayerId::from_index(0);
        let bob = PlayerId::from_index(1);
        for candidates in [1, 2] {
            for source_cost in [false, true] {
                for reason in [PaymentReason::Effect, PaymentReason::CastSpell] {
                    for cause_controller in [alice, bob] {
                        let mut game = setup_game();
                        let source_card = CardBuilder::new(CardId::new(), "Protected permanent")
                            .card_types(vec![CardType::Artifact])
                            .build();
                        let source =
                            game.create_object_from_card(&source_card, alice, Zone::Battlefield);
                        game.object_mut(source).unwrap().abilities_mut().push(
                            Ability::static_ability(StaticAbility::restriction(
                                crate::effect::Restriction::BeSacrificedByCause {
                                    filter: ObjectFilter::permanent()
                                        .controlled_by(crate::target::PlayerFilter::You),
                                    cause: CauseFilter {
                                        cause_type: Some(CauseTypeFilter::OneOf(vec![
                                            CauseType::Effect,
                                            CauseType::Cost,
                                        ])),
                                        source_filter: None,
                                        controller_filter: Some(ControllerFilter::Opponent),
                                        ability_kind: None,
                                    },
                                },
                                String::new(),
                            )),
                        );
                        for _ in 0..candidates {
                            let creature = CardBuilder::new(CardId::new(), "Payment creature")
                                .card_types(vec![CardType::Creature])
                                .power_toughness(PowerToughness::fixed(2, 2))
                                .build();
                            game.create_object_from_card(&creature, alice, Zone::Battlefield);
                        }
                        game.update_cant_effects();
                        let mut ctx = ExecutionContext::new_default(source, cause_controller)
                            .with_cause(EventCause::from_effect(source, cause_controller));
                        let cost = crate::cost::TotalCost::from_cost(if source_cost {
                            crate::costs::Cost::sacrifice_self()
                        } else {
                            crate::costs::Cost::sacrifice(ObjectFilter::creature())
                        });
                        let result = pay_total_cost_with_choice_in_context(
                            &mut game, alice, source, &cost, reason, &mut ctx,
                        );
                        let blocked = reason == PaymentReason::Effect && cause_controller == bob;
                        assert_eq!(
                            result.is_err(),
                            blocked,
                            "{reason:?}, source={source_cost}, controller={cause_controller:?}, choices={candidates}: {result:?}"
                        );
                        assert_eq!(
                            game.player(alice).unwrap().graveyard.len(),
                            usize::from(!blocked)
                        );
                    }
                }
            }
        }
    }

    #[test]
    fn sacrifice_payment_retains_requesting_effect_controller() {
        use crate::costs::PaymentReason;
        use crate::events::cause::{CauseType, EventCause};
        use crate::filter::ObjectFilter;
        for candidates in [1, 2] {
            for reason in [PaymentReason::Effect, PaymentReason::CastSpell] {
                let mut game = setup_game();
                let alice = PlayerId::from_index(0);
                let bob = PlayerId::from_index(1);
                let source_card = CardBuilder::new(CardId::new(), "Requesting permanent")
                    .card_types(vec![CardType::Artifact])
                    .build();
                let source = game.create_object_from_card(&source_card, alice, Zone::Battlefield);
                let creature = CardBuilder::new(CardId::new(), "Payment creature")
                    .card_types(vec![CardType::Creature])
                    .power_toughness(PowerToughness::fixed(2, 2))
                    .build();
                for _ in 0..candidates {
                    game.create_object_from_card(&creature, alice, Zone::Battlefield);
                }
                // The ability was controlled by Bob even though its source is now Alice's.
                let mut ctx = ExecutionContext::new_default(source, bob)
                    .with_cause(EventCause::from_effect(source, bob));
                let cost = crate::cost::TotalCost::from_cost(crate::costs::Cost::sacrifice(
                    ObjectFilter::creature(),
                ));
                pay_total_cost_with_choice_in_context(
                    &mut game, alice, source, &cost, reason, &mut ctx,
                )
                .unwrap();
                assert_eq!(game.player(alice).unwrap().graveyard.len(), 1);
                let moves = game
                    .effect_store
                    .pending_trigger_events
                    .iter()
                    .filter_map(|event| event.downcast::<crate::events::ZoneChangeEvent>())
                    .filter(|event| event.to == Zone::Graveyard)
                    .collect::<Vec<_>>();
                assert_eq!(moves.len(), 1);
                assert_eq!(moves[0].cause.cause_type, CauseType::Cost);
                assert_eq!(moves[0].cause.source, Some(source));
                assert_eq!(
                    moves[0].cause.source_controller,
                    Some(if reason == PaymentReason::Effect {
                        bob
                    } else {
                        alice
                    }),
                    "{reason:?}, candidates={candidates}"
                );
            }
        }
    }

    fn setup_game() -> GameState {
        crate::tests::test_helpers::setup_two_player_game()
    }

    fn add_payment_replacement_permanent(
        game: &mut GameState,
        controller: PlayerId,
        name: &str,
        ability: StaticAbility,
    ) {
        let source = CardBuilder::new(CardId::new(), name)
            .card_types(vec![CardType::Creature])
            .power_toughness(PowerToughness::fixed(2, 2))
            .build();
        let source_id = game.create_object_from_card(&source, controller, Zone::Battlefield);
        game.object_mut(source_id)
            .expect("static-ability source should exist")
            .abilities_mut()
            .push(Ability::static_ability(ability));
    }

    #[test]
    fn attached_controller_can_sacrifice_to_ignore_source_static_effects_for_turn() {
        let mut game = setup_game();
        let alice = PlayerId::from_index(0);
        let bob = PlayerId::from_index(1);
        game.turn.priority_player = Some(bob);

        let sacrifice_card = CardBuilder::new(CardId::new(), "Restriction Test Fodder")
            .card_types(vec![CardType::Creature])
            .power_toughness(PowerToughness::fixed(2, 2))
            .build();
        game.create_object_from_card(&sacrifice_card, bob, Zone::Battlefield);
        let creature_card = CardBuilder::new(CardId::new(), "Restriction Test Creature")
            .card_types(vec![CardType::Creature])
            .power_toughness(PowerToughness::fixed(2, 2))
            .build();
        let attached_id = game.create_object_from_card(&creature_card, bob, Zone::Battlefield);
        let alice_attached_id =
            game.create_object_from_card(&creature_card, alice, Zone::Battlefield);

        let aura_card = CardBuilder::new(CardId::new(), "Ignore Restriction Test Aura")
            .card_types(vec![CardType::Enchantment])
            .build();
        let aura_id = game.create_object_from_card(&aura_card, alice, Zone::Battlefield);
        let marker_model: crate::static_abilities::CompiledStaticAbility =
            ironsmith_core::StaticAbility::attached_controller_may_sacrifice_permanent_to_ignore_source_effect_until_end_of_turn(
                "That creature's controller may sacrifice a permanent of their choice for that player to ignore this effect until end of turn",
            );
        let marker = StaticAbility::from_model(marker_model);
        let restriction_model: crate::static_abilities::CompiledStaticAbility =
            ironsmith_core::StaticAbility::restriction(
                crate::effect::Restriction::attack_or_block(ObjectFilter::creature().match_tagged(
                    "enchanted",
                    crate::target::TaggedOpbjectRelation::IsTaggedObject,
                )),
                "enchanted creature can't attack or block",
            );
        let restricted_effect = StaticAbility::from_model(restriction_model);
        let unrelated_effect = StaticAbility::flying();
        {
            let aura = game.object_mut(aura_id).expect("test Aura should exist");
            aura.abilities_mut()
                .push(Ability::static_ability(restricted_effect.clone()));
            aura.abilities_mut()
                .push(Ability::static_ability(unrelated_effect.clone()));
            aura.abilities_mut()
                .push(Ability::static_ability(marker.clone()));
        }
        assert!(game.attach_object_to_target(
            aura_id,
            crate::object::AttachmentTarget::Object(attached_id),
        ));

        let action = SpecialAction::IgnoreAttachedRestriction {
            source_id: aura_id,
            ability_index: 2,
        };
        assert!(can_perform_check(&action, &game, bob).is_ok());
        assert!(restricted_effect.is_active(&game, aura_id));

        let mut decision_maker = SelectFirstDecisionMaker;
        perform(action.clone(), &mut game, bob, &mut decision_maker)
            .expect("attached creature's controller should pay the special-action cost");
        assert!(
            game.player(bob).is_some_and(|player| {
                player.graveyard.iter().any(|id| {
                    game.object(*id)
                        .is_some_and(|object| object.name.as_str() == "Restriction Test Fodder")
                })
            }),
            "the selected fodder should be sacrificed as the action's cost"
        );
        assert!(game.player_ignores_attached_static_restrictions_this_turn(aura_id, bob));
        assert!(!restricted_effect.is_active(&game, aura_id));
        assert!(
            unrelated_effect.is_active(&game, aura_id),
            "ignoring this restriction must not disable unrelated static abilities"
        );
        assert!(game.attach_object_to_target(
            aura_id,
            crate::object::AttachmentTarget::Object(alice_attached_id),
        ));
        assert!(
            restricted_effect.is_active(&game, aura_id),
            "one player's payment must not let a later controller ignore the restriction"
        );
        assert!(game.attach_object_to_target(
            aura_id,
            crate::object::AttachmentTarget::Object(attached_id),
        ));
        assert!(!restricted_effect.is_active(&game, aura_id));
        assert!(
            can_perform_check(&action, &game, bob).is_err(),
            "the already-ignored source should not offer a redundant action"
        );

        game.turn_store.turn_history.clear_for_new_turn();
        assert!(restricted_effect.is_active(&game, aura_id));
    }

    #[test]
    fn any_player_can_pay_to_ignore_only_their_share_of_a_source_search_restriction() {
        let mut game = setup_game();
        let alice = PlayerId::from_index(0);
        let bob = PlayerId::from_index(1);
        game.turn.priority_player = Some(bob);

        let source_card = CardBuilder::new(CardId::new(), "Search Restriction Probe")
            .card_types(vec![CardType::Creature])
            .power_toughness(PowerToughness::fixed(2, 2))
            .build();
        let source_id = game.create_object_from_card(&source_card, alice, Zone::Battlefield);
        let permission_model: crate::static_abilities::CompiledStaticAbility =
            ironsmith_core::StaticAbility::any_player_may_pay_mana_to_ignore_source_effect_until_end_of_turn(
                ManaCost::from_symbols(vec![ManaSymbol::Generic(2)]),
                "Any player may pay {2} for that player to ignore this effect until end of turn",
            );
        {
            let source = game.object_mut(source_id).expect("source should exist");
            source
                .abilities_mut()
                .push(Ability::static_ability(StaticAbility::players_cant_search()));
            source
                .abilities_mut()
                .push(Ability::static_ability(StaticAbility::from_model(
                    permission_model,
                )));
        }
        game.update_cant_effects();
        assert!(!game.can_search_library(alice));
        assert!(!game.can_search_library(bob));

        game.player_mut(bob)
            .expect("bob exists")
            .mana_pool
            .add(ManaSymbol::Blue, 2);
        let action = SpecialAction::IgnoreSourceEffect {
            source_id,
            ability_index: 1,
        };
        assert!(can_perform_check(&action, &game, bob).is_ok());
        let mut decision_maker = SelectFirstDecisionMaker;
        perform(action.clone(), &mut game, bob, &mut decision_maker)
            .expect("bob should be able to pay the source-scoped special-action cost");

        assert!(!game.can_search_library(alice));
        assert!(game.can_search_library(bob));
        assert!(game.player_ignores_source_static_effect_this_turn(source_id, bob));
        assert!(can_perform_check(&action, &game, bob).is_err());

        game.turn_store.turn_history.clear_for_new_turn();
        game.update_cant_effects();
        assert!(!game.can_search_library(alice));
        assert!(!game.can_search_library(bob));
    }

    #[test]
    fn turn_face_up_can_still_use_krrik_life_under_yasharn() {
        let mut game = setup_game();
        let alice = PlayerId::from_index(0);

        game.turn.phase = Phase::FirstMain;
        game.turn.step = None;
        game.turn.active_player = alice;
        game.turn.priority_player = Some(alice);

        add_payment_replacement_permanent(
            &mut game,
            alice,
            "Krrik Morph Helper",
            StaticAbility::krrik_black_mana_may_be_paid_with_life(),
        );
        add_payment_replacement_permanent(
            &mut game,
            alice,
            "Yasharn Morph Helper",
            StaticAbility::cant_pay_life_or_sacrifice_nonland_for_cast_or_activate(),
        );

        let morph_card = CardBuilder::new(CardId::new(), "Morph Life Probe")
            .card_types(vec![CardType::Creature])
            .power_toughness(PowerToughness::fixed(2, 2))
            .build();
        let morph_id = game.create_object_from_card(&morph_card, alice, Zone::Battlefield);
        game.object_mut(morph_id)
            .expect("morph permanent should exist")
            .abilities_mut()
            .push(Ability::static_ability(StaticAbility::morph(
                crate::cost::TotalCost::mana(ManaCost::from_symbols(vec![ManaSymbol::Black])),
            )));
        game.set_face_down(morph_id);

        assert!(
            can_turn_face_up(&game, alice, morph_id).is_ok(),
            "Yasharn should not stop Krrik life payment for special actions"
        );

        let mut dm = SelectFirstDecisionMaker;
        perform_turn_face_up(
            &mut game,
            alice,
            morph_id,
            TurnFaceUpMethod::TurnFaceUpAbility,
            &mut dm,
        )
        .expect("turning face up should succeed");

        assert!(!game.is_face_down(morph_id));
        assert_eq!(game.player(alice).expect("alice exists").life, 18);
    }

    #[test]
    fn disguise_overlay_grants_ward_and_ignores_own_spell_cost_reduction() {
        let mut game = setup_game();
        let alice = PlayerId::from_index(0);

        game.turn.phase = Phase::FirstMain;
        game.turn.step = None;
        game.turn.active_player = alice;
        game.turn.priority_player = Some(alice);

        let disguise_card = CardBuilder::new(CardId::new(), "Disguised Codebreaker Probe")
            .mana_cost(ManaCost::from_symbols(vec![
                ManaSymbol::Generic(1),
                ManaSymbol::Red,
            ]))
            .card_types(vec![CardType::Creature])
            .power_toughness(PowerToughness::fixed(2, 1))
            .build();
        let permanent_id = game.create_object_from_card(&disguise_card, alice, Zone::Battlefield);

        let mut graveyard_filter = ObjectFilter::instant_or_sorcery();
        graveyard_filter.zone = Some(Zone::Graveyard);
        graveyard_filter.stack_kind = None;
        graveyard_filter.owner = Some(crate::filter::PlayerFilter::You);

        let abilities = game
            .object_mut(permanent_id)
            .expect("disguise permanent should exist")
            .abilities_mut();
        abilities.push(Ability::static_ability(StaticAbility::disguise(
            crate::cost::TotalCost::mana(ManaCost::from_symbols(vec![
                ManaSymbol::Generic(5),
                ManaSymbol::Red,
            ])),
        )));
        abilities.push(Ability::static_ability(StaticAbility::new(
            crate::static_abilities::ThisSpellCostReduction::new(
                crate::effect::Value::Count(graveyard_filter),
                crate::static_abilities::ThisSpellCostCondition::Always,
            ),
        )));

        for index in 0..3 {
            let card = CardBuilder::new(CardId::new(), format!("Bolt {index}"))
                .card_types(vec![CardType::Instant])
                .build();
            game.create_object_from_card(&card, alice, Zone::Graveyard);
        }

        game.object_mut(permanent_id)
            .expect("disguise permanent should exist")
            .apply_face_down_cast_overlay_with_disguise_ward(true);
        game.set_face_down(permanent_id);

        let object = game
            .object(permanent_id)
            .expect("face-down permanent should exist");
        assert!(
            !object.abilities.iter().any(|ability| {
                matches!(
                    &ability.kind,
                    crate::ability::AbilityKind::Static(static_ability)
                        if static_ability.is_disguise()
                )
            }),
            "the public face-down object must not expose its hidden disguise ability"
        );
        assert!(
            object
                .face_down_cast_state
                .as_ref()
                .unwrap()
                .abilities
                .iter()
                .any(|ability| {
                    matches!(
                        &ability.kind,
                        crate::ability::AbilityKind::Static(static_ability)
                            if static_ability.is_disguise()
                    )
                }),
            "the face-up view retains the disguise payment permission"
        );
        assert!(object.abilities.iter().any(|ability| {
            matches!(
                &ability.kind,
                crate::ability::AbilityKind::Static(static_ability)
                    if static_ability.ward_cost().is_some()
            )
        }));
        assert_eq!(
            turn_face_up_cost_display(&game, permanent_id, TurnFaceUpMethod::DisguiseAbility)
                .expect("fixture has complete replacement state")
                .as_deref(),
            Some("{5}{R}"),
            "a \"this spell costs less\" static must not reduce the disguise cost (CR 702.168d)"
        );

        game.player_mut(alice)
            .expect("alice exists")
            .mana_pool
            .add(ManaSymbol::Red, 3);

        assert!(
            can_turn_face_up_with_method(
                &game,
                alice,
                permanent_id,
                TurnFaceUpMethod::DisguiseAbility,
            )
            .is_err(),
            "{{2}}{{R}} worth of mana must not pay the unreduced {{5}}{{R}} disguise cost"
        );

        game.player_mut(alice)
            .expect("alice exists")
            .mana_pool
            .add(ManaSymbol::Red, 3);

        assert!(
            can_turn_face_up_with_method(
                &game,
                alice,
                permanent_id,
                TurnFaceUpMethod::DisguiseAbility,
            )
            .is_ok(),
            "six mana pays the full {{5}}{{R}} disguise cost"
        );

        let mut dm = SelectFirstDecisionMaker;
        perform_turn_face_up(
            &mut game,
            alice,
            permanent_id,
            TurnFaceUpMethod::DisguiseAbility,
            &mut dm,
        )
        .expect("turning a disguised permanent face up should succeed");

        assert!(!game.is_face_down(permanent_id));
        assert_eq!(
            game.object(permanent_id)
                .expect("face-up permanent should exist")
                .name,
            "Disguised Codebreaker Probe"
        );
    }

    #[test]
    fn manifested_creature_can_turn_face_up_for_mana_cost() {
        let mut game = setup_game();
        let alice = PlayerId::from_index(0);

        game.turn.phase = Phase::FirstMain;
        game.turn.step = None;
        game.turn.active_player = alice;
        game.turn.priority_player = Some(alice);

        let card = CardBuilder::new(CardId::new(), "Manifested Bear")
            .mana_cost(ManaCost::from_symbols(vec![ManaSymbol::Green]))
            .card_types(vec![CardType::Creature])
            .power_toughness(PowerToughness::fixed(3, 3))
            .build();
        let permanent_id = game.create_object_from_card(&card, alice, Zone::Battlefield);
        game.object_mut(permanent_id)
            .expect("manifested permanent should exist")
            .apply_face_down_cast_overlay();
        game.set_face_down(permanent_id);
        game.set_manifested(permanent_id);
        game.player_mut(alice)
            .expect("alice exists")
            .mana_pool
            .add(ManaSymbol::Green, 1);

        assert!(
            can_turn_face_up(&game, alice, permanent_id).is_ok(),
            "manifested creature should be turnable face up for its mana cost"
        );

        let mut dm = SelectFirstDecisionMaker;
        perform_turn_face_up(
            &mut game,
            alice,
            permanent_id,
            TurnFaceUpMethod::PrintedManaCost,
            &mut dm,
        )
        .expect("turning manifested creature face up should succeed");

        assert!(!game.is_face_down(permanent_id));
        assert!(!game.is_manifested(permanent_id));
        let object = game
            .object(permanent_id)
            .expect("face-up creature should exist");
        assert_eq!(object.name, "Manifested Bear");
        assert_eq!(game.calculated_power(permanent_id), Some(3));
        assert_eq!(game.calculated_toughness(permanent_id), Some(3));
    }

    #[test]
    fn manifested_noncreature_cant_turn_face_up_for_mana_cost() {
        let mut game = setup_game();
        let alice = PlayerId::from_index(0);

        game.turn.phase = Phase::FirstMain;
        game.turn.step = None;
        game.turn.active_player = alice;
        game.turn.priority_player = Some(alice);

        let card = CardBuilder::new(CardId::new(), "Manifested Spell")
            .mana_cost(ManaCost::from_symbols(vec![ManaSymbol::Blue]))
            .card_types(vec![CardType::Sorcery])
            .build();
        let permanent_id = game.create_object_from_card(&card, alice, Zone::Battlefield);
        game.object_mut(permanent_id)
            .expect("manifested permanent should exist")
            .apply_face_down_cast_overlay();
        game.set_face_down(permanent_id);
        game.set_manifested(permanent_id);
        game.player_mut(alice)
            .expect("alice exists")
            .mana_pool
            .add(ManaSymbol::Blue, 1);

        let error = can_turn_face_up(&game, alice, permanent_id)
            .expect_err("manifested noncreature should not be turnable face up");
        assert_eq!(error, ActionError::NoSuchAbility);
    }

    #[test]
    fn manifested_megamorph_creature_can_use_mana_cost_or_megamorph_cost() {
        let mut game = setup_game();
        let alice = PlayerId::from_index(0);

        game.turn.phase = Phase::FirstMain;
        game.turn.step = None;
        game.turn.active_player = alice;
        game.turn.priority_player = Some(alice);

        let card = CardBuilder::new(CardId::new(), "Manifested Adept")
            .mana_cost(ManaCost::from_symbols(vec![ManaSymbol::Green]))
            .card_types(vec![CardType::Creature])
            .power_toughness(PowerToughness::fixed(2, 2))
            .build();

        let mana_cost_id = game.create_object_from_card(&card, alice, Zone::Battlefield);
        game.object_mut(mana_cost_id)
            .expect("manifested permanent should exist")
            .abilities_mut()
            .push(crate::ability::Ability::static_ability(
                crate::static_abilities::StaticAbility::megamorph(
                    ManaCost::from_symbols(vec![ManaSymbol::Generic(3), ManaSymbol::Green]).into(),
                ),
            ));
        game.object_mut(mana_cost_id)
            .expect("manifested permanent should exist")
            .apply_face_down_cast_overlay();
        game.set_face_down(mana_cost_id);
        game.set_manifested(mana_cost_id);

        let megamorph_id = game.create_object_from_card(&card, alice, Zone::Battlefield);
        game.object_mut(megamorph_id)
            .expect("manifested permanent should exist")
            .abilities_mut()
            .push(crate::ability::Ability::static_ability(
                crate::static_abilities::StaticAbility::megamorph(
                    ManaCost::from_symbols(vec![ManaSymbol::Generic(3), ManaSymbol::Green]).into(),
                ),
            ));
        game.object_mut(megamorph_id)
            .expect("manifested permanent should exist")
            .apply_face_down_cast_overlay();
        game.set_face_down(megamorph_id);
        game.set_manifested(megamorph_id);

        let alice_player = game.player_mut(alice).expect("alice exists");
        alice_player.mana_pool.add(ManaSymbol::Green, 5);

        assert!(
            can_turn_face_up_with_method(
                &game,
                alice,
                mana_cost_id,
                TurnFaceUpMethod::PrintedManaCost,
            )
            .is_ok(),
            "manifested creature should be turnable face up for its mana cost"
        );
        assert!(
            can_turn_face_up_with_method(
                &game,
                alice,
                mana_cost_id,
                TurnFaceUpMethod::MegamorphAbility,
            )
            .is_ok(),
            "manifested creature should also be turnable face up for its megamorph cost"
        );

        let mut dm = SelectFirstDecisionMaker;
        perform_turn_face_up(
            &mut game,
            alice,
            mana_cost_id,
            TurnFaceUpMethod::PrintedManaCost,
            &mut dm,
        )
        .expect("turning manifested creature face up for its mana cost should succeed");
        perform_turn_face_up(
            &mut game,
            alice,
            megamorph_id,
            TurnFaceUpMethod::MegamorphAbility,
            &mut dm,
        )
        .expect("turning manifested creature face up for its megamorph cost should succeed");

        assert_eq!(
            game.counter_count(mana_cost_id, crate::object::CounterType::PlusOnePlusOne),
            0,
            "turning face up for mana cost should not add a megamorph counter"
        );
        assert_eq!(
            game.counter_count(megamorph_id, crate::object::CounterType::PlusOnePlusOne),
            1,
            "turning face up for megamorph should add a +1/+1 counter"
        );
    }

    #[test]
    fn turn_face_up_can_pay_life_morph_cost() {
        let mut game = setup_game();
        let alice = PlayerId::from_index(0);

        game.turn.phase = Phase::FirstMain;
        game.turn.step = None;
        game.turn.active_player = alice;
        game.turn.priority_player = Some(alice);

        let morph_card = CardBuilder::new(CardId::new(), "Morph Life Cutthroat")
            .card_types(vec![CardType::Creature])
            .power_toughness(PowerToughness::fixed(3, 4))
            .build();
        let morph_id = game.create_object_from_card(&morph_card, alice, Zone::Battlefield);
        game.object_mut(morph_id)
            .expect("morph permanent should exist")
            .abilities_mut()
            .push(Ability::static_ability(StaticAbility::morph(
                crate::cost::TotalCost::from_cost(crate::costs::Cost::life(5)),
            )));
        game.set_face_down(morph_id);

        assert!(
            can_turn_face_up(&game, alice, morph_id).is_ok(),
            "face-down creature with a life-based morph cost should be turnable face up"
        );

        let life_before = game.player(alice).expect("alice exists").life;
        let mut dm = SelectFirstDecisionMaker;
        perform_turn_face_up(
            &mut game,
            alice,
            morph_id,
            TurnFaceUpMethod::TurnFaceUpAbility,
            &mut dm,
        )
        .expect("turning face up for a life-based morph cost should succeed");

        assert!(!game.is_face_down(morph_id));
        assert_eq!(
            game.player(alice).expect("alice exists").life,
            life_before - 5,
            "turning face up for a life-based morph cost should pay the stated life"
        );
    }

    #[test]
    #[cfg(ironsmith_runtime_parser_tests)]
    fn krrik_can_pay_black_mana_ability_cost_with_life() {
        let mut game = setup_game();
        let alice = PlayerId::from_index(0);

        add_payment_replacement_permanent(
            &mut game,
            alice,
            "Krrik Mana Helper",
            StaticAbility::krrik_black_mana_may_be_paid_with_life(),
        );

        let celebrant_id =
            game.create_object_from_definition(&blood_celebrant(), alice, Zone::Battlefield);
        let ability_index = game
            .object(celebrant_id)
            .and_then(|object| {
                object
                    .abilities
                    .iter()
                    .position(|ability| ability.is_mana_ability())
            })
            .expect("blood celebrant should have a mana ability");

        assert!(can_activate_mana_ability_check(&game, alice, celebrant_id, ability_index).is_ok());

        let mut dm = SelectFirstDecisionMaker;
        perform_activate_mana_ability(&mut game, alice, celebrant_id, ability_index, &mut dm)
            .expect("mana ability should resolve");

        let player = game.player(alice).expect("alice exists");
        assert_eq!(
            player.life, 17,
            "should pay 2 life for {{B}} and 1 life for the ability"
        );
        assert_eq!(player.mana_pool.total(), 1);
    }

    #[test]
    #[cfg(ironsmith_runtime_parser_tests)]
    fn yasharn_blocks_blood_celebrant_mana_ability() {
        let mut game = setup_game();
        let alice = PlayerId::from_index(0);

        add_payment_replacement_permanent(
            &mut game,
            alice,
            "Yasharn Mana Helper",
            StaticAbility::cant_pay_life_or_sacrifice_nonland_for_cast_or_activate(),
        );

        let celebrant_id =
            game.create_object_from_definition(&blood_celebrant(), alice, Zone::Battlefield);
        let ability_index = game
            .object(celebrant_id)
            .and_then(|object| {
                object
                    .abilities
                    .iter()
                    .position(|ability| ability.is_mana_ability())
            })
            .expect("blood celebrant should have a mana ability");

        assert_eq!(
            can_activate_mana_ability_check(&game, alice, celebrant_id, ability_index),
            Err(ActionError::CantPayCost)
        );
    }

    #[test]
    fn play_land_from_graveyard_grant_moves_land_to_battlefield_and_uses_land_play() {
        let mut game = setup_game();
        let alice = PlayerId::from_index(0);

        game.turn.phase = Phase::FirstMain;
        game.turn.step = None;
        game.turn.active_player = alice;
        game.turn.priority_player = Some(alice);

        let land = CardBuilder::new(CardId::from_raw(71_021), "Dakmor Salvage")
            .card_types(vec![CardType::Land])
            .build();
        let land_id = game.create_object_from_card(&land, alice, Zone::Graveyard);

        let source_id = game.new_object_id();
        game.effect_store
            .grant_registry
            .grant_to_filter_until_end_of_turn(
                crate::target::ObjectFilter::default().with_type(CardType::Land),
                Zone::Graveyard,
                alice,
                Grantable::play_from(),
                source_id,
                game.turn.turn_number,
            );

        let action = SpecialAction::PlayLand { card_id: land_id };
        assert!(
            can_perform_check(&action, &game, alice).is_ok(),
            "granted graveyard land should be legal to play"
        );

        let mut dm = SelectFirstDecisionMaker;
        perform(action, &mut game, alice, &mut dm).expect("playing land from graveyard succeeds");

        let played_land = game
            .battlefield
            .iter()
            .find_map(|&id| game.object(id).filter(|obj| obj.name == "Dakmor Salvage"))
            .expect("played land should be on the battlefield");
        assert_eq!(game.controller_of(played_land), alice);
        assert_eq!(played_land.zone, Zone::Battlefield);
        assert!(
            !game
                .player(alice)
                .expect("alice should exist")
                .can_play_land(),
            "playing a granted graveyard land should consume the turn's land play"
        );
    }
}

#[cfg(test)]
fn perform_turn_face_up(
    game: &mut GameState,
    player: PlayerId,
    permanent_id: ObjectId,
    method: TurnFaceUpMethod,
    decision_maker: &mut impl DecisionMaker,
) -> Result<(), ActionError> {
    perform(
        SpecialAction::TurnFaceUp {
            permanent_id,
            method,
        },
        game,
        player,
        decision_maker,
    )
}

#[cfg(test)]
fn can_turn_face_up_with_method(
    game: &GameState,
    player: PlayerId,
    permanent_id: ObjectId,
    method: TurnFaceUpMethod,
) -> Result<(), ActionError> {
    can_perform_check(
        &SpecialAction::TurnFaceUp {
            permanent_id,
            method,
        },
        game,
        player,
    )
}

#[cfg(test)]
mod phyrexian_component_choice_tests {
    use super::*;
    struct ChooseLife {
        prompts: usize,
    }
    impl DecisionMaker for ChooseLife {
        fn decide_options(
            &mut self,
            _game: &GameState,
            ctx: &crate::decisions::context::SelectOptionsContext,
        ) -> Vec<usize> {
            self.prompts += 1;
            vec![
                ctx.options
                    .iter()
                    .find(|o| o.description == "Pay 2 life")
                    .expect("life must be offered")
                    .index,
            ]
        }
    }
    #[test]
    fn phyrexian_component_choices_preserve_mana_and_remaining_pip_affordability() {
        use crate::mana::{ManaCost, ManaSymbol};
        for (life, pips, expected_life, expected_white) in [(20, 1, 18, 1), (3, 2, 1, 0)] {
            let mut game = GameState::new(vec!["Alice".into(), "Bob".into()], 20);
            let alice = game.players[0].id;
            game.player_mut(alice).unwrap().life = life;
            game.player_mut(alice)
                .unwrap()
                .mana_pool
                .add(ManaSymbol::White, 1);
            let card = crate::card::CardBuilder::new(crate::ids::CardId::new(), "Cost source")
                .card_types(vec![crate::types::CardType::Artifact])
                .build();
            let source = game.create_object_from_card(&card, alice, crate::zone::Zone::Battlefield);
            let cost = crate::cost::TotalCost::mana(ManaCost::from_pips(vec![
                vec![
                    ManaSymbol::White,
                    ManaSymbol::Life(2)
                ];
                pips
            ]));
            let mut dm = ChooseLife { prompts: 0 };
            pay_total_cost_with_choice(
                &mut game,
                alice,
                source,
                &cost,
                crate::costs::PaymentReason::Other,
                &mut dm,
            )
            .unwrap();
            assert_eq!(dm.prompts, 1, "a forced final pip needs no second choice");
            assert_eq!(game.player(alice).unwrap().life, expected_life);
            assert_eq!(game.player(alice).unwrap().mana_pool.white, expected_white);
        }
    }
}

#[cfg(test)]
mod replacement_counter_face_up_tests {
    use super::*;
    use crate::card::{CardBuilder, PowerToughness};
    use crate::ids::CardId;
    use crate::object::CounterType;
    use crate::static_abilities::StaticAbility;
    use crate::types::CardType;

    #[derive(Default)]
    struct Answers {
        pause: bool,
        pending: bool,
        calls: usize,
    }
    impl crate::decision::DecisionMaker for Answers {
        fn awaiting_choice(&self) -> bool {
            self.pending
        }
        fn decide_boolean(
            &mut self,
            _: &GameState,
            _: &crate::decisions::context::BooleanContext,
        ) -> bool {
            assert!(!self.pending, "continued past a pending counter payload");
            self.calls += 1;
            self.pending = self.pause;
            !self.pause
        }
    }

    fn check_counter_application(mode: usize) {
        let mut game = crate::tests::test_helpers::setup_two_player_game();
        let alice = PlayerId::from_index(0);
        let bob = PlayerId::from_index(1);
        game.turn.active_player = alice;
        game.turn.priority_player = Some(alice);
        game.turn.phase = Phase::FirstMain;
        game.turn.step = None;
        let card = CardBuilder::new(CardId::new(), "Face-up counter recipient")
            .card_types(vec![CardType::Creature])
            .power_toughness(PowerToughness::fixed(2, 2))
            .build();
        let permanent = game.create_object_from_card(&card, alice, Zone::Battlefield);
        game.object_mut(permanent).unwrap().abilities_mut().push(
            crate::ability::Ability::static_ability(StaticAbility::megamorph(
                ManaCost::from_symbols(vec![ManaSymbol::Green]).into(),
            )),
        );
        game.object_mut(permanent)
            .unwrap()
            .apply_face_down_cast_overlay();
        game.set_face_down(permanent);
        game.set_manifested(permanent);
        let redirected = game.create_object_from_card(&card, bob, Zone::Battlefield);
        let source = game.create_object_from_card(
            &CardBuilder::new(CardId::new(), "Counter replacement")
                .card_types(vec![CardType::Enchantment])
                .build(),
            alice,
            Zone::Battlefield,
        );
        let mut replacement = StaticAbility::double_counters_replacement(
            crate::target::ObjectFilter::creature(),
            Some(CounterType::PlusOnePlusOne),
            "Replace face-up counter".into(),
        )
        .generate_replacement_effect(source, alice)
        .unwrap();
        replacement.replacement = match mode {
            0 => crate::replacement::ReplacementAction::Redirect {
                target: crate::replacement::RedirectTarget::ToObject(redirected),
                which: crate::replacement::RedirectWhich::First,
            },
            1 => crate::replacement::ReplacementAction::Instead(vec![
                crate::effect::Effect::gain_life(2),
            ]),
            2 => crate::replacement::ReplacementAction::Instead(vec![
                crate::effect::Effect::gain_life(2),
                crate::effect::Effect::gain_life(crate::effect::Value::X),
            ]),
            _ => crate::replacement::ReplacementAction::Instead(vec![
                crate::effect::Effect::gain_life(2),
                crate::effect::Effect::may(vec![crate::effect::Effect::gain_life(1)]),
                crate::effect::Effect::may(vec![crate::effect::Effect::gain_life(3)]),
            ]),
        };
        let one_shot = game
            .effect_store
            .replacement_effects
            .add_one_shot_effect(replacement);
        game.player_mut(alice)
            .unwrap()
            .mana_pool
            .add(ManaSymbol::Green, 1);
        let action = SpecialAction::TurnFaceUp {
            permanent_id: permanent,
            method: TurnFaceUpMethod::MegamorphAbility,
        };
        let mut dm = Answers {
            pause: mode == 3,
            ..Default::default()
        };
        let result = perform(action.clone(), &mut game, alice, &mut dm);
        assert_eq!(result.is_err(), mode == 2);
        assert_eq!(
            game.counter_count(permanent, CounterType::PlusOnePlusOne),
            0
        );
        if mode >= 2 {
            assert_eq!(dm.pending, mode == 3);
            assert!(game.is_face_down(permanent));
            assert_eq!(game.player(alice).unwrap().life, 20);
            assert_eq!(game.player(alice).unwrap().mana_pool.total(), 1);
            assert!(
                game.effect_store
                    .replacement_effects
                    .get_effect(one_shot)
                    .is_some()
            );
            assert!(game.take_pending_trigger_events().is_empty());
            if mode == 2 {
                return;
            }
            assert_eq!(dm.calls, 1);
            let mut dm = Answers::default();
            perform(action, &mut game, alice, &mut dm).unwrap();
            assert_eq!(dm.calls, 2);
            assert_eq!(game.player(alice).unwrap().life, 26);
        } else if mode == 1 {
            assert_eq!(game.player(alice).unwrap().life, 22);
        } else {
            assert_eq!(
                game.counter_count(redirected, CounterType::PlusOnePlusOne),
                1
            );
        }
        assert!(!game.is_face_down(permanent));
        assert_eq!(game.player(alice).unwrap().mana_pool.total(), 0);
        assert!(
            game.effect_store
                .replacement_effects
                .get_effect(one_shot)
                .is_none()
        );
        let events = game.take_pending_trigger_events();
        assert_eq!(
            events
                .iter()
                .filter(|event| event.kind() == crate::events::EventKind::TurnedFaceUp)
                .count(),
            1
        );
        if mode == 0 {
            let marker = events
                .iter()
                .filter_map(|event| event.downcast::<crate::events::MarkersChangedEvent>())
                .next()
                .unwrap();
            assert_eq!(
                marker.location,
                crate::marker::MarkerLocation::Object(redirected)
            );
            assert_eq!(marker.source, Some(permanent));
            assert_eq!(marker.source_controller, Some(alice));
        } else {
            assert_eq!(
                events
                    .iter()
                    .filter(|event| event.kind() == crate::events::EventKind::LifeGain)
                    .count(),
                if mode == 3 { 3 } else { 1 }
            );
            assert!(!events.iter().any(|event| {
                event
                    .downcast::<crate::events::MarkersChangedEvent>()
                    .is_some_and(|marker| marker.is_added())
            }));
        }
    }

    #[test]
    fn megamorph_counter_application_preserves_redirect() {
        check_counter_application(0);
    }
    #[test]
    fn megamorph_counter_application_executes_instead() {
        check_counter_application(1);
    }
    #[test]
    fn megamorph_counter_application_propagates_error_and_restores_cost() {
        check_counter_application(2);
    }
    #[test]
    fn megamorph_counter_application_pauses_and_replays_without_partial_commit() {
        check_counter_application(3);
    }
}

#[cfg(test)]
mod replacement_suspend_tests {
    use super::*;
    use crate::card::CardBuilder;
    use crate::ids::CardId;
    use crate::object::CounterType;
    use crate::replacement::{RedirectTarget, RedirectWhich, ReplacementAction, ReplacementEffect};

    struct Answers {
        pause: bool,
        pending: bool,
        calls: usize,
    }
    impl crate::decision::DecisionMaker for Answers {
        fn decide_boolean(
            &mut self,
            _: &GameState,
            _: &crate::decisions::context::BooleanContext,
        ) -> bool {
            assert!(!self.pending);
            self.calls += 1;
            self.pending = self.pause;
            !self.pause
        }
        fn awaiting_choice(&self) -> bool {
            self.pending
        }
    }

    fn check_suspend(mode: usize) {
        let alice = PlayerId::from_index(0);
        let bob = PlayerId::from_index(1);
        let mut game = GameState::new(vec!["Alice".into(), "Bob".into()], 20);
        game.turn.active_player = alice;
        game.turn.priority_player = Some(alice);
        game.turn.phase = crate::game_state::Phase::FirstMain;
        game.turn.step = None;
        let card = CardBuilder::new(CardId::new(), "Suspend subject")
            .card_types(vec![crate::types::CardType::Creature])
            .build();
        let card_id = game.create_object_from_card(&card, alice, Zone::Hand);
        game.object_mut(card_id).unwrap().alternative_casts =
            vec![crate::alternative_cast::AlternativeCastingMethod::Suspend {
                time: ironsmith_core::SuspendTime::Fixed(2),
                cost: crate::mana::ManaCost::from_symbols(vec![crate::mana::ManaSymbol::Green]),
            }]
            .into();
        let stable_id = game.object(card_id).unwrap().stable_id;
        let source = game.create_object_from_card(
            &CardBuilder::new(CardId::new(), "Replacement source").build(),
            alice,
            Zone::Battlefield,
        );
        let recipient = game.create_object_from_card(
            &CardBuilder::new(CardId::new(), "Redirected recipient").build(),
            bob,
            Zone::Battlefield,
        );
        let action = match mode {
            0 => ReplacementAction::Double,
            1 => ReplacementAction::Redirect {
                target: RedirectTarget::ToObject(recipient),
                which: RedirectWhich::First,
            },
            2 => ReplacementAction::Instead(vec![crate::effect::Effect::gain_life(2)]),
            3 => ReplacementAction::Instead(vec![
                crate::effect::Effect::gain_life(2),
                crate::effect::Effect::gain_life(crate::effect::Value::X),
            ]),
            _ => ReplacementAction::Instead(vec![
                crate::effect::Effect::gain_life(2),
                crate::effect::Effect::may(vec![crate::effect::Effect::gain_life(3)]),
            ]),
        };
        let one_shot = game.effect_store.replacement_effects.add_one_shot_effect(
            ReplacementEffect::with_matcher(
                source,
                alice,
                crate::events::counters::matchers::WouldPutCountersMatcher::new(
                    crate::target::ObjectFilter::default().in_zone(Zone::Exile),
                    Some(CounterType::Time),
                ),
                action,
            ),
        );
        game.player_mut(alice)
            .unwrap()
            .mana_pool
            .add(crate::mana::ManaSymbol::Green, 1);
        game.take_pending_trigger_events();
        let mut dm = Answers {
            pause: mode == 4,
            pending: false,
            calls: 0,
        };
        let result = perform(
            SpecialAction::Suspend { card_id },
            &mut game,
            alice,
            &mut dm,
        );
        assert_eq!(result.is_err(), mode == 3);
        if mode >= 3 {
            assert_eq!(game.object(card_id).unwrap().zone, Zone::Hand);
            assert!(game.exile.is_empty());
            assert_eq!(game.player(alice).unwrap().mana_pool.total(), 1);
            assert_eq!(game.player(alice).unwrap().life, 20);
            assert_eq!(game.counter_count(recipient, CounterType::Time), 0);
            assert!(
                game.effect_store
                    .replacement_effects
                    .get_effect(one_shot)
                    .is_some()
            );
            assert!(game.take_pending_trigger_events().is_empty());
            if mode == 3 {
                return;
            }
            assert!(dm.pending);
            assert_eq!(dm.calls, 1);
            let mut replay = Answers {
                pause: false,
                pending: false,
                calls: 0,
            };
            perform(
                SpecialAction::Suspend { card_id },
                &mut game,
                alice,
                &mut replay,
            )
            .unwrap();
            assert_eq!(replay.calls, 1);
        }
        let exiled = game.find_object_by_stable_id(stable_id).unwrap();
        assert_eq!(game.object(exiled).unwrap().zone, Zone::Exile);
        assert_eq!(
            game.counter_count(exiled, CounterType::Time),
            if mode == 0 { 4 } else { 0 }
        );
        assert_eq!(
            game.counter_count(recipient, CounterType::Time),
            if mode == 1 { 2 } else { 0 }
        );
        assert_eq!(game.player(alice).unwrap().mana_pool.total(), 0);
        assert_eq!(
            game.player(alice).unwrap().life,
            match mode {
                2 => 22,
                4 => 25,
                _ => 20,
            }
        );
        assert!(
            game.effect_store
                .replacement_effects
                .get_effect(one_shot)
                .is_none()
        );
        let events = game.take_pending_trigger_events();
        let markers: Vec<_> = events
            .iter()
            .filter_map(|event| event.downcast::<crate::events::MarkersChangedEvent>())
            .collect();
        assert_eq!(markers.len(), usize::from(mode <= 1));
        if let Some(marker) = markers.first() {
            assert_eq!(
                marker.location,
                crate::marker::MarkerLocation::Object(if mode == 1 { recipient } else { exiled })
            );
            assert_eq!(marker.source, Some(exiled));
            assert_eq!(marker.source_controller, Some(alice));
        }
        assert_eq!(
            events
                .iter()
                .filter(|event| event.kind() == crate::events::EventKind::LifeGain)
                .count(),
            match mode {
                2 => 1,
                4 => 2,
                _ => 0,
            }
        );
    }
    #[test]
    fn suspend_counter_application_commits_modified_amount() {
        check_suspend(0);
    }
    #[test]
    fn suspend_counter_application_commits_redirected_recipient() {
        check_suspend(1);
    }
    #[test]
    fn suspend_counter_application_executes_instead() {
        check_suspend(2);
    }
    #[test]
    fn suspend_counter_application_propagates_error_and_restores_cost_and_zone() {
        check_suspend(3);
    }
    #[test]
    fn suspend_counter_application_pauses_and_replays_without_partial_commit() {
        check_suspend(4);
    }
}

#[cfg(test)]
mod fixed_mana_replacement_owner_tests {
    use super::*;
    use crate::effect::{Effect, Value};
    use crate::replacement::{ReplacementAction, ReplacementEffect};
    struct PauseReplacement {
        pause: bool,
        pending: bool,
        questions: usize,
    }
    impl DecisionMaker for PauseReplacement {
        fn decide_boolean(
            &mut self,
            _game: &GameState,
            _ctx: &crate::decisions::context::BooleanContext,
        ) -> bool {
            self.questions += 1;
            if self.pause {
                self.pending = true;
                false
            } else {
                true
            }
        }
        fn awaiting_choice(&self) -> bool {
            self.pending
        }
    }
    fn check_fixed_mana_activation(mode: u8) {
        let mut game = crate::tests::test_helpers::setup_two_player_game();
        let alice = PlayerId::from_index(0);
        let bob = PlayerId::from_index(1);
        let definition = crate::cards::CardDefinitionBuilder::new(
            crate::ids::CardId::new(),
            "Fixed mana owner probe",
        )
        .card_types(vec![crate::types::CardType::Artifact])
        .with_ability(crate::ability::Ability::mana(
            crate::cost::TotalCost::from_cost(crate::costs::Cost::tap()),
            vec![crate::mana::ManaSymbol::Green],
        ))
        .build();
        let source = game.create_object_from_definition(&definition, alice, Zone::Battlefield);
        let mut effects = vec![Effect::gain_life(2)];
        if mode == 1 {
            effects.push(Effect::lose_life(Value::X));
        }
        if mode == 2 {
            effects.push(Effect::may(vec![Effect::gain_life(4)]));
        }
        effects.push(Effect::gain_life(8));
        let shield = game.effect_store.replacement_effects.add_one_shot_effect(
            ReplacementEffect::with_matcher(
                source,
                bob,
                crate::events::mana::matchers::ManaProducedBySourceMatcher::new(
                    crate::target::ObjectFilter::default(),
                ),
                ReplacementAction::Instead(effects),
            ),
        );
        game.take_pending_trigger_events();
        let before_objects = game.objects_in_deterministic_order().len();
        let before_id = game.next_object_id_counter();
        let mut dm = PauseReplacement {
            pause: mode == 2,
            pending: false,
            questions: 0,
        };
        let result = perform_activate_mana_ability(&mut game, alice, source, 0, &mut dm);
        if mode == 1 {
            assert!(
                matches!(
                    result,
                    Err(ActionError::ExecutionFailure {
                        error: crate::effects::ExecutionError::UnresolvableValue(_),
                        ..
                    })
                ),
                "fixed mana replacement errors propagate"
            );
        } else {
            result.expect("valid fixed mana activation succeeds or suspends");
            if mode == 2 {
                assert!(dm.awaiting_choice(), "payload decision is exposed");
            } else {
                assert_eq!(game.player(bob).unwrap().life, 30);
                assert!(game.is_tapped(source));
            }
        }
        assert_eq!(game.player(alice).unwrap().life, 20);
        assert_eq!(game.player(alice).unwrap().mana_pool.green, 0);
        assert_eq!(game.player(bob).unwrap().mana_pool.green, 0);
        assert_eq!(game.objects_in_deterministic_order().len(), before_objects);
        assert_eq!(game.next_object_id_counter(), before_id);
        assert_eq!(
            game.effect_store
                .replacement_effects
                .get_effect(shield)
                .is_some(),
            mode != 0
        );
        let events = game.take_pending_trigger_events();
        if mode != 0 {
            assert!(
                !game.is_tapped(source),
                "incomplete activation restores paid tap cost"
            );
            assert_eq!(game.player(bob).unwrap().life, 20);
            assert!(events.is_empty());
        } else {
            let gains = events
                .iter()
                .filter_map(|event| event.downcast::<crate::events::LifeGainEvent>())
                .collect::<Vec<_>>();
            assert_eq!(
                gains.iter().map(|gain| gain.amount).collect::<Vec<_>>(),
                vec![2, 8]
            );
            assert!(gains.iter().all(|gain| gain.player == bob));
            assert!(
                !events
                    .iter()
                    .any(|event| event.downcast::<crate::events::ManaAddedEvent>().is_some())
            );
        }
        if mode == 2 {
            assert_eq!(dm.questions, 1);
            let mut replay = PauseReplacement {
                pause: false,
                pending: false,
                questions: 0,
            };
            perform_activate_mana_ability(&mut game, alice, source, 0, &mut replay).unwrap();
            assert_eq!(replay.questions, 1);
            assert!(!replay.awaiting_choice());
            assert!(game.is_tapped(source));
            assert_eq!(game.player(bob).unwrap().life, 34);
            assert_eq!(game.player(alice).unwrap().mana_pool.green, 0);
            assert!(
                game.effect_store
                    .replacement_effects
                    .get_effect(shield)
                    .is_none()
            );
            let events = game.take_pending_trigger_events();
            assert_eq!(
                events
                    .iter()
                    .filter_map(|event| event.downcast::<crate::events::LifeGainEvent>())
                    .map(|gain| gain.amount)
                    .collect::<Vec<_>>(),
                vec![2, 4, 8]
            );
            assert!(
                !events
                    .iter()
                    .any(|event| event.downcast::<crate::events::ManaAddedEvent>().is_some())
            );
        }
    }
    #[test]
    fn fixed_mana_activation_retains_instead_payload_and_notifications() {
        check_fixed_mana_activation(0);
    }
    #[test]
    fn fixed_mana_activation_error_restores_paid_cost_and_shield() {
        check_fixed_mana_activation(1);
    }
    #[test]
    fn fixed_mana_activation_pending_restores_cost_then_replays_once() {
        check_fixed_mana_activation(2);
    }
}

#[cfg(test)]
mod replacement_land_owner_contract_tests {
    use super::*;
    use crate::card::CardBuilder;
    use crate::decision::DecisionMaker;
    use crate::effect::{Effect, Value};
    use crate::ids::{CardId, StableId};
    use crate::object::CounterType;
    use crate::replacement::{ReplacementAction, ReplacementEffect};
    use crate::target::{ChooseSpec, ObjectFilter};
    struct Answers {
        original: ObjectId,
        stable: StableId,
        alice: PlayerId,
        pause: bool,
        pending: bool,
        calls: usize,
        binding: bool,
    }
    impl DecisionMaker for Answers {
        fn decide_boolean(
            &mut self,
            game: &GameState,
            _: &crate::decisions::context::BooleanContext,
        ) -> bool {
            self.calls += 1;
            assert!(game.object(self.original).is_none());
            assert_eq!(game.player(self.alice).unwrap().lands_played_this_turn, 1);
            let arrival = game
                .objects_in_deterministic_order()
                .into_iter()
                .find(|object| object.stable_id == self.stable)
                .unwrap();
            assert_eq!(arrival.zone, Zone::Battlefield);
            if self.binding {
                assert_eq!(
                    game.counter_count(arrival.id, CounterType::PlusOnePlusOne),
                    1
                );
            }
            self.pending = self.pause;
            !self.pending
        }
        fn awaiting_choice(&self) -> bool {
            self.pending
        }
    }
    fn card(game: &mut GameState, owner: PlayerId, kind: CardType, zone: Zone) -> ObjectId {
        game.create_object_from_card(
            &CardBuilder::new(CardId::new(), "Land owner fixture")
                .card_types(vec![kind])
                .build(),
            owner,
            zone,
        )
    }
    fn perform_path(
        game: &mut GameState,
        queue: &mut crate::triggers::TriggerQueue,
        state: &mut crate::game_loop::PriorityLoopState,
        alice: PlayerId,
        land: ObjectId,
        priority: bool,
        dm: &mut Answers,
    ) -> Result<(), bool> {
        if priority {
            crate::game_loop::apply_priority_response_with_dm(game, queue, state,
            &crate::PriorityResponse::PriorityAction(crate::decision::LegalAction::PlayLand { land_id: land }), dm)
            .map(|_| ()).map_err(|error| matches!(error,
                crate::game_loop::GameLoopError::ExecutionFailed(
                    crate::effects::ExecutionError::UnresolvableValue(message)
                ) if message.contains('X')))
        } else {
            super::perform(SpecialAction::PlayLand { card_id: land }, game, alice, dm).map_err(
                |error| {
                    matches!(
                        error,
                        ActionError::ExecutionFailure {
                            error: crate::effects::ExecutionError::UnresolvableValue(_),
                            ..
                        }
                    )
                },
            )
        }
    }
    fn check(priority: bool, mode: u8) {
        let mut game = crate::tests::test_helpers::setup_two_player_game();
        let alice = PlayerId::from_index(0);
        let bob = PlayerId::from_index(1);
        game.turn.phase = crate::game_state::Phase::FirstMain;
        game.turn.step = None;
        game.turn.active_player = alice;
        game.turn.priority_player = Some(alice);
        let replacement_source = card(&mut game, bob, CardType::Artifact, Zone::Battlefield);
        let land = card(&mut game, alice, CardType::Land, Zone::Hand);
        let stable = game.object(land).unwrap().stable_id;
        let actions = match mode {
            1 => vec![Effect::gain_life(3), Effect::lose_life(Value::X)],
            3 => vec![
                Effect::new(crate::effects::PutCountersEffect::new(
                    CounterType::PlusOnePlusOne,
                    1,
                    ChooseSpec::tagged("it"),
                )),
                Effect::may(vec![Effect::gain_life(0)]),
            ],
            _ => vec![
                Effect::gain_life(3),
                Effect::may(vec![Effect::gain_life(4)]),
            ],
        };
        let shield = game.effect_store.replacement_effects.add_one_shot_effect(
            ReplacementEffect::with_matcher(
                replacement_source,
                bob,
                crate::events::zones::matchers::WouldChangeZoneMatcher::new(
                    ObjectFilter::specific(land),
                    Some(Zone::Hand),
                    Some(Zone::Battlefield),
                ),
                ReplacementAction::Additionally(actions),
            ),
        );
        game.take_pending_trigger_events();
        let ids = game.next_object_id_counter();
        let objects = game.objects_in_deterministic_order().len();
        let mut queue = crate::triggers::TriggerQueue::new();
        let mut state = crate::game_loop::PriorityLoopState::new(2);
        let mut dm = Answers {
            original: land,
            stable,
            alice,
            pause: mode == 2,
            pending: false,
            calls: 0,
            binding: mode == 3,
        };
        let result = perform_path(
            &mut game, &mut queue, &mut state, alice, land, priority, &mut dm,
        );
        if mode == 1 {
            assert_eq!(
                result,
                Err(true),
                "surface the added program's unresolved X"
            );
        } else if mode == 2 {
            assert!(dm.awaiting_choice());
            assert!(result.is_ok());
        } else {
            assert!(result.is_ok());
            assert!(game.object(land).is_none());
            assert_eq!(game.player(alice).unwrap().lands_played_this_turn, 1);
            let arrival = game
                .objects_in_deterministic_order()
                .into_iter()
                .find(|object| object.stable_id == stable)
                .unwrap();
            assert_eq!(arrival.zone, Zone::Battlefield);
            assert_eq!(game.player(alice).unwrap().life, 20);
            assert_eq!(
                game.player(bob).unwrap().life,
                if mode == 3 { 20 } else { 27 }
            );
            if mode == 3 {
                assert_eq!(
                    game.counter_count(arrival.id, CounterType::PlusOnePlusOne),
                    1
                );
                let played = game.turn_store.turn_history.projected_records()
                    .find_map(|record| record.event.downcast::<crate::events::LandPlayedEvent>())
                    .expect("the original play is recorded before additions");
                assert_eq!(played.land, arrival.id);
                assert_eq!(played.completed_destination, Some(Zone::Battlefield));
                let snapshot = played.snapshot.as_ref().unwrap();
                assert_eq!(snapshot.object_id, arrival.id);
                assert_eq!(snapshot.counters.get(&CounterType::PlusOnePlusOne).copied().unwrap_or(0), 0);
            }
            assert!(
                game.effect_store
                    .replacement_effects
                    .get_effect(shield)
                    .is_none()
            );
            assert_eq!(dm.calls, 1);
            if !priority && mode == 0 {
                let events = game
                    .turn_store
                    .turn_history
                    .projected_records()
                    .map(|record| &record.event)
                    .collect::<Vec<_>>();
                assert_eq!(
                    events
                        .iter()
                        .filter(|event| event.kind() == crate::events::EventKind::LandPlayed)
                        .count(),
                    1
                );
                assert_eq!(
                    events
                        .iter()
                        .filter_map(|event| event.downcast::<crate::events::LifeGainEvent>())
                        .map(|event| (event.player, event.amount))
                        .collect::<Vec<_>>(),
                    vec![(bob, 3), (bob, 4)]
                );
            }
        }
        if mode == 1 || mode == 2 {
            assert_eq!(game.object(land).unwrap().zone, Zone::Hand);
            assert_eq!(game.player(alice).unwrap().lands_played_this_turn, 0);
            assert_eq!(game.player(bob).unwrap().life, 20);
            assert_eq!(game.next_object_id_counter(), ids);
            assert_eq!(game.objects_in_deterministic_order().len(), objects);
            assert!(
                game.effect_store
                    .replacement_effects
                    .get_effect(shield)
                    .is_some()
            );
            assert!(game.take_pending_trigger_events().is_empty());
            assert!(queue.entries.is_empty());
        }
        if mode == 2 {
            assert_eq!(dm.calls, 1);
            dm.pause = false;
            dm.pending = false;
            let result = perform_path(
                &mut game, &mut queue, &mut state, alice, land, priority, &mut dm,
            );
            assert!(result.is_ok());
            assert_eq!(game.player(bob).unwrap().life, 27);
            assert_eq!(game.player(alice).unwrap().lands_played_this_turn, 1);
            assert!(game.object(land).is_none());
            assert!(!dm.awaiting_choice());
            assert_eq!(dm.calls, 2);
        }
    }
    #[test]
    fn special_additions_follow_land_play_bookkeeping() {
        check(false, 0);
    }
    #[test]
    fn special_error_restores_land_play() {
        check(false, 1);
    }
    #[test]
    fn special_pending_replays_once() {
        check(false, 2);
    }
    #[test]
    fn special_addition_binds_entering_land() {
        check(false, 3);
    }
    #[test]
    fn priority_additions_follow_land_play_bookkeeping() {
        check(true, 0);
    }
    #[test]
    fn priority_error_restores_land_and_trigger_queue() {
        check(true, 1);
    }
    #[test]
    fn priority_pending_replays_once() {
        check(true, 2);
    }
    #[test]
    fn priority_addition_binds_entering_land() {
        check(true, 3);
    }
}

#[cfg(test)]
mod replacement_sacrifice_cost_owner_contract_tests {
    use super::*;
    use crate::card::CardBuilder;
    use crate::decision::DecisionMaker;
    use crate::effect::{Effect, Value};
    use crate::ids::{CardId, StableId};
    use crate::object::CounterType;
    use crate::replacement::{ReplacementAction, ReplacementEffect};
    use crate::target::{ChooseSpec, ObjectFilter};
    struct Answers {
        original: ObjectId,
        stable: StableId,
        pause: bool,
        pending: bool,
        calls: usize,
        binding: bool,
    }
    impl DecisionMaker for Answers {
        fn decide_boolean(
            &mut self,
            game: &GameState,
            _: &crate::decisions::context::BooleanContext,
        ) -> bool {
            self.calls += 1;
            assert!(game.object(self.original).is_none());
            let arrival = game
                .objects_in_deterministic_order()
                .into_iter()
                .find(|object| object.stable_id == self.stable)
                .unwrap();
            assert_eq!(arrival.zone, Zone::Graveyard);
            if self.binding {
                assert_eq!(
                    game.counter_count(arrival.id, CounterType::PlusOnePlusOne),
                    1
                );
            }
            self.pending = self.pause;
            !self.pending
        }
        fn awaiting_choice(&self) -> bool {
            self.pending
        }
    }
    fn card(game: &mut GameState, player: PlayerId) -> ObjectId {
        game.create_object_from_card(
            &CardBuilder::new(CardId::new(), "Sacrifice cost fixture")
                .card_types(vec![CardType::Artifact])
                .build(),
            player,
            Zone::Battlefield,
        )
    }
    fn pay(
        game: &mut GameState,
        source: ObjectId,
        payer: PlayerId,
        victim: ObjectId,
        dm: &mut Answers,
    ) -> Result<(), CostPaymentError> {
        let cost = crate::costs::Cost::sacrifice(ObjectFilter::specific(victim).you_control());
        let mut ctx = CostContext::new(source, payer, dm);
        super::resolve_cost_choice(game, &cost, &mut ctx)
    }
    fn check(mode: u8) {
        let mut game = crate::tests::test_helpers::setup_two_player_game();
        let alice = PlayerId::from_index(0);
        let bob = PlayerId::from_index(1);
        let source = card(&mut game, alice);
        let replacement = card(&mut game, bob);
        let victim = card(&mut game, alice);
        let stable = game.object(victim).unwrap().stable_id;
        let action = match mode {
            1 => ReplacementAction::Additionally(vec![
                Effect::gain_life(3),
                Effect::lose_life(Value::X),
            ]),
            3 => ReplacementAction::Additionally(vec![
                Effect::new(crate::effects::PutCountersEffect::new(
                    CounterType::PlusOnePlusOne,
                    1,
                    ChooseSpec::tagged("it"),
                )),
                Effect::may(vec![Effect::gain_life(0)]),
            ]),
            4 => ReplacementAction::Prevent,
            5 => ReplacementAction::ChangeDestination(Zone::Exile),
            6 => ReplacementAction::Instead(vec![Effect::gain_life(7)]),
            _ => ReplacementAction::Additionally(vec![
                Effect::gain_life(3),
                Effect::may(vec![Effect::gain_life(4)]),
            ]),
        };
        let shield = game.effect_store.replacement_effects.add_one_shot_effect(
            ReplacementEffect::with_matcher(
                replacement,
                bob,
                crate::events::zones::matchers::WouldChangeZoneMatcher::new(
                    ObjectFilter::specific(victim),
                    Some(Zone::Battlefield),
                    Some(Zone::Graveyard),
                ),
                action,
            ),
        );
        game.take_pending_trigger_events();
        let ids = game.next_object_id_counter();
        let objects = game.objects_in_deterministic_order().len();
        let mut dm = Answers {
            original: victim,
            stable,
            pause: mode == 2,
            pending: false,
            calls: 0,
            binding: mode == 3,
        };
        let result = pay(&mut game, source, alice, victim, &mut dm);
        if mode == 1 {
            assert!(
                matches!(
                    result,
                    Err(CostPaymentError::ExecutionFailed(
                        crate::effects::ExecutionError::UnresolvableValue(_)
                    ))
                ),
                "added error must surface"
            );
        } else if mode == 2 {
            assert!(dm.awaiting_choice());
            assert!(result.is_err());
        } else {
            assert!(
                result.is_ok(),
                "legally started cost remains paid after replacement"
            );
            let arrival = game
                .objects_in_deterministic_order()
                .into_iter()
                .find(|object| object.stable_id == stable)
                .unwrap();
            assert_eq!(
                arrival.zone,
                match mode {
                    4 | 6 => Zone::Battlefield,
                    5 => Zone::Exile,
                    _ => Zone::Graveyard,
                }
            );
            assert_eq!(game.player(alice).unwrap().life, 20);
            assert_eq!(
                game.player(bob).unwrap().life,
                if mode == 0 || mode == 6 { 27 } else { 20 }
            );
            if mode == 3 {
                assert_eq!(
                    game.counter_count(arrival.id, CounterType::PlusOnePlusOne),
                    1
                );
            }
            assert_eq!(
                game.turn_store
                    .turn_history
                    .event_kind_count(crate::events::EventKind::Sacrifice),
                if mode == 4 || mode == 6 { 0 } else { 1 }
            );
            assert!(
                game.effect_store
                    .replacement_effects
                    .get_effect(shield)
                    .is_none()
            );
            assert_eq!(dm.calls, if mode == 0 || mode == 3 { 1 } else { 0 });
        }
        if mode == 1 || mode == 2 {
            assert_eq!(game.object(victim).unwrap().zone, Zone::Battlefield);
            assert_eq!(game.player(bob).unwrap().life, 20);
            assert_eq!(game.next_object_id_counter(), ids);
            assert_eq!(game.objects_in_deterministic_order().len(), objects);
            assert!(
                game.effect_store
                    .replacement_effects
                    .get_effect(shield)
                    .is_some()
            );
            assert!(game.take_pending_trigger_events().is_empty());
        }
        if mode == 2 {
            dm.pause = false;
            dm.pending = false;
            assert!(pay(&mut game, source, alice, victim, &mut dm).is_ok());
            assert!(game.object(victim).is_none());
            assert_eq!(game.player(bob).unwrap().life, 27);
            assert_eq!(dm.calls, 2);
            assert!(!dm.awaiting_choice());
        }
    }
    #[test]
    fn additions_follow_paid_sacrifice() {
        check(0);
    }
    #[test]
    fn added_error_restores_payment() {
        check(1);
    }
    #[test]
    fn pending_replays_payment_once() {
        check(2);
    }
    #[test]
    fn addition_binds_actual_arrival() {
        check(3);
    }
    #[test]
    fn prevented_sacrifice_cost_paid_without_sacrifice_event() {
        check(4);
    }
    #[test]
    fn redirected_sacrifice_cost_paid_with_sacrifice_event() {
        check(5);
    }
    #[test]
    fn instead_cost_paid_without_sacrifice_event() {
        check(6);
    }
}

#[cfg(test)]
mod recovered_activation_counter_receipts {
    use super::*;
    use crate::effect::{Effect, EffectId, EffectOutcome, Value};
    use crate::effects::{ExecutionContext, WithIdEffect};
    #[test]
    fn native_in_context_owner_retains_exact_paid_count_and_independent_x() {
        for count in [0, 3, i32::MAX as u32 + 1, u32::MAX] {
            let payer = PlayerId::from_index(0);
            let mut game = GameState::new(vec!["A".into(), "B".into()], 20);
            let card = crate::card::CardBuilder::new(crate::CardId::new(), "Receipt source")
                .card_types(vec![crate::CardType::Artifact]).build();
            let source = game.create_object_from_card(&card, payer, crate::Zone::Battlefield);
            game.object_mut(source).unwrap().counters.insert(crate::CounterType::Charge, count);
            let cost = crate::cost::TotalCost::from_costs(vec![crate::costs::Cost::effect(WithIdEffect::new(
                EffectId::ACTIVATION_COUNTER_COST, Effect::new(crate::effects::RemoveAnyCountersFromSourceEffect::all(Some(crate::CounterType::Charge)))))]);
            let mut context = ExecutionContext::new_default(source, payer).with_x(17);
            context.effect_outcomes.insert(EffectId(9), EffectOutcome::count(11));
            pay_total_cost_with_choice_in_context(&mut game, payer, source, &cost,
                crate::costs::PaymentReason::ActivateAbility, &mut context).unwrap();
            assert_eq!(context.x_value, Some(17));
            assert_eq!(context.effect_outcomes[&EffectId(9)].count_or_zero(), 11);
            assert_eq!(crate::effects::helpers::resolve_value_wide(&game, &Value::EffectValue(EffectId::ACTIVATION_COUNTER_COST), &context).unwrap(), i64::from(count));
            assert_eq!(game.counter_count(source, crate::CounterType::Charge), 0);
        }
    }
    #[test]
    fn reserved_missing_receipt_is_incomplete_evidence_and_pending_keeps_previous_memory() {
        struct Pending;
        impl crate::decision::DecisionMaker for Pending { fn awaiting_choice(&self) -> bool { true } }
        let payer = PlayerId::from_index(0);
        let mut game = GameState::new(vec!["A".into(), "B".into()], 20);
        let card = crate::card::CardBuilder::new(crate::CardId::new(), "Pending receipt source")
            .card_types(vec![crate::CardType::Artifact]).build();
        let source = game.create_object_from_card(&card, payer, crate::Zone::Battlefield);
        game.add_counters(source, crate::CounterType::Charge, 3);
        let mut dm = Pending;
        let mut context = ExecutionContext::new(source, payer, &mut dm);
        context.effect_outcomes.insert(EffectId(9), EffectOutcome::count(11));
        assert!(matches!(crate::effects::helpers::resolve_value_wide(&game, &Value::EffectValue(EffectId::ACTIVATION_COUNTER_COST), &context), Err(crate::effects::ExecutionError::IncompleteEvidence(_))));
        let cost = crate::cost::TotalCost::from_costs(vec![crate::costs::Cost::effect(WithIdEffect::new(
            EffectId::ACTIVATION_COUNTER_COST, Effect::remove_counters(crate::CounterType::Charge, 2, crate::ChooseSpec::Source)))]);
        pay_total_cost_with_choice_in_context(&mut game, payer, source, &cost,
            crate::costs::PaymentReason::ActivateAbility, &mut context).unwrap();
        assert_eq!(game.counter_count(source, crate::CounterType::Charge), 3);
        assert_eq!(context.effect_outcomes.len(), 1);
        assert_eq!(context.effect_outcomes[&EffectId(9)].count_or_zero(), 11);
    }
}

#[cfg(test)]
mod retained_counter_follow_on_costs {
    use super::*;
    use crate::effect::{Effect, EffectId, EffectOutcome, Value};
    use crate::effects::{ExecutionContext, ExecutionError, EffectExecutor, CostExecutableEffect, CostValidationError, WithIdEffect};
    #[derive(Clone, Debug)]
    struct CompletionGate { fail: bool }
    impl EffectExecutor for CompletionGate {
        fn execute(&self, game: &mut GameState, ctx: &mut ExecutionContext) -> Result<EffectOutcome, ExecutionError> {
            if self.fail { return Err(ExecutionError::InternalError("failure after paid prefix".into())); }
            ctx.decision_maker.decide_boolean(game, &crate::decisions::context::BooleanContext::new(ctx.controller, Some(ctx.source), "Pending suffix"));
            Ok(EffectOutcome::resolved())
        }
        fn as_cost_executable(&self) -> Option<&dyn CostExecutableEffect> { Some(self) }
    }
    impl CostExecutableEffect for CompletionGate {
        fn can_execute_as_cost(&self, _: &GameState, _: ObjectId, _: PlayerId) -> Result<(), CostValidationError> { Ok(()) }
    }
    #[derive(Default)]
    struct Pause { pending: bool }
    impl DecisionMaker for Pause {
        fn decide_boolean(&mut self, _: &GameState, _: &crate::decisions::context::BooleanContext) -> bool { self.pending = true; false }
        fn awaiting_choice(&self) -> bool { self.pending }
    }
    #[test]
    fn retained_receipt_drives_native_follow_on_life_cost_and_paid_prefix_rolls_back() {
        for suffix in [None, Some(true), Some(false)] {
            let payer=PlayerId::from_index(0);let mut game=GameState::new(vec!["A".into(),"B".into()],20);
            let card=crate::card::CardBuilder::new(crate::CardId::new(),"Follow-on receipt").card_types(vec![crate::CardType::Artifact]).build();
            let source=game.create_object_from_card(&card,payer,Zone::Battlefield);game.add_counters(source,crate::CounterType::Charge,3);
            let mut dm=Pause::default();let mut ctx=ExecutionContext::new(source,payer,&mut dm).with_x(17);
            let remove=crate::cost::TotalCost::from_costs(vec![crate::costs::Cost::effect(WithIdEffect::new(EffectId::ACTIVATION_COUNTER_COST,
                Effect::remove_counters(crate::CounterType::Charge,3,crate::ChooseSpec::Source)))]);
            pay_total_cost_with_choice_in_context(&mut game,payer,source,&remove,crate::costs::PaymentReason::ActivateAbility,&mut ctx).unwrap();
            let mut components=vec![crate::costs::Cost::effect(WithIdEffect::new(EffectId(33),Effect::pay_life(Value::EffectValue(EffectId::ACTIVATION_COUNTER_COST))))];
            if let Some(fail)=suffix {components.push(crate::costs::Cost::effect(CompletionGate {fail}));}
            let result=pay_total_cost_with_choice_in_context(&mut game,payer,source,&crate::cost::TotalCost::from_costs(components),crate::costs::PaymentReason::ActivateAbility,&mut ctx);
            assert_eq!(result.is_err(),suffix==Some(true));assert_eq!(game.counter_count(source,crate::CounterType::Charge),0);
            assert_eq!(ctx.effect_outcomes[&EffectId::ACTIVATION_COUNTER_COST].instruction_result().count_or_zero(),3);assert_eq!(ctx.x_value,Some(17));
            assert_eq!(game.player(payer).unwrap().life,if suffix.is_none(){17}else{20});
            assert_eq!(ctx.effect_outcomes.contains_key(&EffectId(33)),suffix.is_none());
        }
    }
}
