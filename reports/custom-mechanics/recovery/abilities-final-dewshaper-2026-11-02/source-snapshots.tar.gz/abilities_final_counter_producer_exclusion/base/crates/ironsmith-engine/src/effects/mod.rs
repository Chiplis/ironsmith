//! Modular effect system for MTG.
//!
//! This module provides a trait-based architecture for effect execution.
//! Each effect type implements the `EffectExecutor` trait, allowing for:
//! - Co-located tests with each effect implementation
//! - Self-contained effect logic
//! - Easy addition of new effects without modifying central dispatcher
//!
//! # Module Structure
//!
//! ```text
//! effects/
//!   mod.rs              - This file, module organization
//!   executor_trait.rs   - EffectExecutor trait definition
//!   helpers.rs          - Shared utilities (resolve_value, etc.)
//!   damage/
//!     mod.rs
//!     deal_damage.rs    - DealDamageEffect implementation + tests
//! ```
//!
//! # Usage
//!
//! Effects can be executed through the `EffectExecutor` trait:
//!
//! ```ignore
//! use ironsmith::effects::{EffectExecutor, DealDamageEffect};
//!
//! let effect = DealDamageEffect::new(3, ChooseSpec::AnyTarget);
//! let result = effect.execute(&mut game, &mut ctx)?;
//! ```
//!
//! # Runtime Categories
//!
//! The supported runtime extension categories are:
//! - `Standard`: ordinary resolving effects
//! - `CostExecutable`: effects that can participate in cost payment
//! - `DelayedTriggerRegistration`: effects that register delayed trigger state
//! - `ReplacementRegistration`: effects that register replacement state
//!
//! New runtime work should fit one of those categories. When in doubt, prefer
//! building a reusable `Standard` effect first and only opt into the more
//! specialized categories when the effect's main job is registration or cost handling.
//!
//! # Ownership
//!
//! Effect execution routes through the runtime harness in this module. Public
//! effect execution entry points live here, while effect model data remains in
//! the shared compiled-card domain.

mod action_observation;
pub(crate) mod target_packets;
pub mod cards;
pub mod combat;
pub mod composition;
pub mod consult_helpers;
mod context;
pub mod continuous;
pub mod control;
pub mod counters;
pub mod damage;
pub mod delayed;
mod executor_trait;
pub(crate) use executor_trait::CompletedActionPrefix;
mod payment_resources;
pub use payment_resources::PaymentResourceClaim;
pub(crate) use payment_resources::{can_pay_declared_resource_claims, can_pay_declared_resources};
pub mod helpers;
pub mod life;
pub mod mana;
pub(crate) use action_observation::{
    observe_action_completion, observe_action_completions_retaining_groups,
    observe_lifecycle_completions, observe_lifecycle_completions_with_observations,
    observe_lifecycle_completions_with_outputs, with_action_observations,
};
pub(crate) mod outcome_recording;
pub mod permanents;
pub mod player;
pub(crate) mod player_reference_binding;
pub mod replacement;
pub mod restrictions;
mod runtime;
pub mod stack;
pub mod tokens;
pub mod zones;

/// Reserved tag used to carry public reveal visibility across stack lifetime.
pub const PUBLIC_REVEALED_TAG: &str = "__public_revealed";
/// Cards revealed by an earlier effect in the same execution ("revealed this way").
pub const REVEALED_THIS_WAY_TAG: &str = crate::tag::REVEALED_THIS_WAY_TAG;

// Re-export the traits, modal spec, and cost validation error
#[path="composition/link_objects_to_group.rs"]
mod link_objects_to_group;
pub use link_objects_to_group::LinkObjectsToGroupEffect;
pub use composition::{
    ActionProgramCursor, ProgramAction, ProgramActionScope, ProgramCompletion,
    ProgramInstructionSelection, ProgramPreparation,
};
pub use context::{
    DoThisLimit, ExecutionError, IterationContext, ReplacementExecutionContext, ResolvedTarget,
    TargetError, rebase_target_scope,
};
pub(crate) use executor_trait::canonical_cost_children;
pub use executor_trait::{
    CompletedEffectOutputs, CostChoiceBindings, CostExecutableEffect, CostValidationError,
    DamageActionBinding, DeferredPlayerActionProposal, EffectExecutionCategory, EffectExecutor,
    EffectOutcomeContribution, EffectOutcomeScope, ModalEffectSpec, ModalSpec,
    OriginalEffectOutput, OriginalPhaseStatus, PreparedSelectionBinding, PublishedEffectOutputs,
    ResolutionPreludeBinding, ScopedEffectOutcome, SharedEffectOutcome, SharedEffectOutputView,
    SharedOutcomeOwnership, SimultaneousEffectCommit, SimultaneousEffectCompletion,
    SimultaneousEffectProposal, TargetReusePolicy, TargetSelectionProfile,
};
pub type EffectContext<'a> = context::ExecutionContext<'a>;
pub(crate) use context::{ExecutionContext, ExecutionContextCheckpoint, PaymentExecutionInputs};
pub(crate) use runtime::{EffectExecutionPurpose, execute_effect_payment_with_outputs};
pub(crate) use runtime::{
    capture_triggers_before_added_program, match_triggers_at_instruction_boundary,
    retain_unmatched_outcome_events, select_reached_action_program,
    with_per_event_trigger_matching,
};
pub use runtime::{execute_effect, execute_effect_with_outputs, resolve_value, validate_target};

// Re-export effect implementations
pub use cards::{
    ClashEffect, ClashOpponentMode, ConniveEffect, ConsultTopOfLibraryEffect,
    ConsultTopOfLibraryStopRule, DiscardEffect, DiscardHandEffect, DrawCardsEffect,
    DrawForEachTaggedMatchingEffect, EachPlayerScryEffect, ExileTopOfLibraryEffect,
    ExileUntilMatchEffect, FatesealEffect, LearnEffect, LookAtHandEffect, LookAtObjectsEffect,
    LookAtTopCardsEffect, MillEffect, PutTaggedRemainderOnLibraryBottomEffect,
    RearrangeLookedCardsInLibraryEffect, ReorderTopPlanarDeckEffect, RevealFromHandEffect,
    RevealSourceFromHandEffect, RevealTaggedEffect, RevealTopEffect, ScryEffect,
    SearchLibraryEffect, SearchLibrarySlot, SearchLibrarySlotsEffect,
    ShuffleGraveyardIntoLibraryEffect, ShuffleHandAndGraveyardIntoLibraryEffect,
    ShuffleLibraryEffect, SurveilEffect,
};
pub use combat::{
    AssignNoCombatDamageEffect, BecomeBlockedEffect, ClearGoadEffect, CombatDamagePreventionTarget,
    EnterAttackingEffect, ExchangeValueKind, ExchangeValueOperand, ExchangeValuesEffect,
    FightEffect, GoadEffect, GrantAbilitiesAllEffect, GrantAbilitiesTargetEffect, MeleeEffect,
    MustAttackPlayerThisTurnEffect,
    ModifyPowerToughnessAllEffect, ModifyPowerToughnessEffect, ModifyPowerToughnessForEachEffect,
    PreventAllCombatDamageEffect, PreventAllCombatDamageFromEffect, PreventAllDamageEffect,
    PreventAllDamageToTargetEffect, PreventDamageEffect, RemoveFromCombatEffect,
    ReselectAttackTargetEffect, ExchangeBlocksEffect, SetBasePowerToughnessEffect,
    UnblockSoleBlockedAttackersEffect, BlockAttackerOfChoiceEffect,
    DeclareBlockersByRandomPilesThisTurnEffect,
};
pub use composition::{
    AdaptEffect, AmplifyEffect, AuraSwapEffect, BackupEffect, BeholdEffect, BidLifeEffect,
    BolsterEffect, CastEncodedCardCopyEffect, ChooseModeEffect, ChooseObjectsEffect,
    ChooseSpellCastHistoryEffect, CipherEffect, CollectEvidenceEffect, CollectManaPaymentsEffect,
    BindXValueEffect,
    ConditionalEffect, CounterAbilityEffect, CumulativeUpkeepEffect, DevourEffect,
    EmitGiftGivenEffect, EmitKeywordActionEffect, PerformNamedActionEffect, ExecuteWithSourceEffect, ExploreEffect,
    ForEachControllerOfTaggedEffect, ForEachObject, ForEachObjectCorrelatedResultEffect,
    ForEachAnnouncedTargetSlotEffect, ForEachTaggedEffect, ForEachTaggedPlayerEffect, ForPlayersEffect,
    GrantEndThisEffectPaymentEffect, GrantRepeatableManaPaymentActionUntilEndOfTurnEffect,
    IfEffect, LifeBidStart, LocalRewriteEffect, ManaRestrictedEffect, ManaRetainedEffect,
    ManifestCardFromHandEffect, ManifestDreadEffect, ManifestObjectsEffect,
    ManifestTopCardOfLibraryEffect, MayEffect, OpenAttractionEffect, PopulateEffect,
    ReflexiveTriggerEffect, RepeatEffectsEffect, RepeatProcessEffect, RepeatProcessPromptEffect,
    SecretChoiceEffect, SecretChoiceResult, SequenceEffect, SupportEffect, TagAllEffect,
    TagAttachedToSourceEffect, TagMatchingObjectsEffect, TagOtherBlockParticipantEffect,
    TagSplicedCardsEffect, TagLastDamageSourceEffect,
    TagTriggeringAttackerEffect, TagTriggeringBlockersEffect, TagTriggeringDamageTargetEffect,
    TagTriggeringObjectEffect, TagTriggeringSourceEffect, TaggedEffect, TargetOnlyEffect,
    UnlessActionEffect, UnlessPaysEffect, VOTE_WINNERS_TAG, VOTED_OBJECTS_TAG,
    VillainousChoiceEffect, VoteChoice, VoteEffect, VoteOption, VoteResult, WithIdEffect,
    ChoosePlayerOptionEffect, ControlVotesThisTurnEffect, PlayerOptionChooser,
    player_option_choice_tag,
};
pub use continuous::{
    ApplyContinuousEffect, ChangeTextEffect, RemoveOptionalTextFragmentEffect, ExchangeTextBoxesEffect, RuntimeModification,
};
pub use control::{
    DirectionalAdjacentPlayerControlEffect, ExchangeControlEffect, GainControlEffect,
    SharedTypeConstraint,
};
pub use counters::remove_any_counters_among_cost_display;
pub(crate) use counters::remove_any_counters_among_valid_targets_with_tags;
pub use counters::{
    DoubleCountersEffect, ForEachCounterKindPutOrRemoveEffect, MoveAllCountersEffect,
    MoveCountersEffect, MoveOneCounterEffect, NoteCountersEffect, ProliferateEffect,
    PutCounterOfChosenKindEffect,
    PutCounterOfKindChosenFromEffect, PutCounterOfRandomKindEffect,
    PutCountersEffect, RemoveAnyCountersAmongEffect, RemoveAnyCountersFromSourceEffect,
    RemoveCountersEffect, RemoveUpToAnyCountersEffect, RemoveUpToCountersEffect,
};
pub use damage::{
    ClearDamageEffect, DamageDistributionMode, DealDamageEffect, DealDistributedDamageEffect,
    HealDamageEffect, PreventNextTimeDamageEffect, PreventNextTimeDamageSource,
    PreventNextTimeDamageTarget, RedirectAllDamageThisTurnToTargetEffect,
    RedirectNextDamageDestination, RedirectNextDamageToTargetEffect,
    RedirectNextTimeDamageDestination, RedirectNextTimeDamageSource,
    RedirectNextTimeDamageToSourceEffect, ReplaceNextDamageToTargetEffect,
};
pub use delayed::{
    DelayedTriggerPrepayment, ExileTaggedWhenSourceLeavesEffect,
    SacrificeSourceWhenTaggedLeavesEffect, ScheduleDelayedTriggerEffect,
    ScheduleEffectsWhenTaggedLeavesEffect, TaggedLeavesAbilitySource,
};
pub use life::{
    ExchangeLifeTotalsEffect, GainLifeEffect, LoseLifeEffect, NoteLifeTotalEffect, PayLifeEffect,
    RedistributeLifeTotalsEffect,
    SetLifeTotalEffect,
};
pub use mana::{
    ActivateManaAbilityOfEachLandEffect, AddColorlessManaEffect, AddManaEffect, AddManaFromCommanderColorIdentityEffect,
    AddManaOfAnyColorEffect, AddManaOfAnyOneColorEffect, AddManaOfChosenColorEffect,
    AddManaEqualToManaCostEffect, AddManaLostThisWayEffect, AddManaOfColorsAmongEffect, AddManaOfLandProducedTypesEffect,
    AddManaOfNotedTypeEffect,
    AddOneManaOfAnyColorAmongEffect, AddScaledManaEffect, DoubleManaPoolEffect,
    EmptyManaPoolEffect, GrantManaAbilityUntilEotEffect,
    GrantPayLifeManaAbilityUntilEndOfTurnEffect, ManaTypeSource,
    NoteActivationManaTypeEffect, NoteActivationManaPaymentEffect, NoteTriggeringCreatureTypeEffect, PayManaEffect,
    RetainManaUntilEndOfTurnEffect,
};
pub use permanents::{
    AttachObjectsEffect, AttachToEffect, BecomeBasicLandTypeChoiceEffect, BecomeColorChoiceEffect,
    BecomeCreatureTypeChoiceEffect, BecomeSaddledUntilEotEffect, ClearSuspectedEffect,
    ConspireCostEffect, ConvertEffect, CrewCostEffect, DetainEffect, EarthbendEffect, EvolveEffect,
    ExertCostEffect, FlipEffect, GrantObjectAbilityEffect, MeldEffect, MergePermanentsEffect, MonstrosityEffect,
    NextAdaptIgnoresCountersEffect, NinjutsuCostEffect, NinjutsuEffect, PhaseInEffect,
    PhaseOutDuration, PhaseOutEffect, PrepareEffect, PutStickerEffect, ReconfigureEffect,
    RegenerateEffect, RenownEffect, SaddleCostEffect, SetClassLevelEffect, SetDayNightEffect,
    DayNightDesignation, SneakCostEffect,
    SolveCaseEffect, LinkPermanentsEffect, SoulbondPairEffect, SuspectEffect, TapEffect, TransformEffect,
    TurnFaceDownEffect, TurnFaceUpEffect, UmbraArmorEffect, UnattachObjectsEffect, UnearthEffect,
    UnlockRoomDoorEffect, UntapEffect,
};
pub use player::{
    ActivateAbilityWithoutCostsEffect,KeepGreatestManaValuePlayersEffect, RollDieKeepHighestPlayersEffect, TagPlayersEffect};
pub use player::{
    AdditionalLandPlaysEffect, AdditionalPhase, AdditionalPhasesEffect, AdditionalStepAnchor, AdditionalStepKind, AdditionalStepsEffect, AscendEffect,
    BecomeMonarchEffect, CascadeEffect, CastSourceEffect, CastTaggedEffect, ChooseCardNameEffect,
    ChooseCardTypeEffect, ChooseColorEffect, ChooseCreatureTypeEffect, ChooseLandTypeEffect,
    ChooseNamedOptionEffect, ChooseNumberAtRandomEffect, ChooseNumberEffect, ChoosePlayerEffect,
    ChooseFriendsOrFoesEffect,
    ControlCombatChoicesThisTurnEffect, ControlPlayerEffect, CreateEmblemEffect, DiscoverEffect,
    DrawTheGameEffect, EndCombatPhaseEffect, EndTurnEffect, EnergyCountersEffect,
    ExileInsteadOfGraveyardEffect, ExileThenGrantPlayEffect, ExileUntilMatchCastEffect,
    ExileUntilMatchGrantPlayEffect, ExperienceCountersEffect, ExtraTurnAfterNextTurnEffect,
    ExtraTurnEffect, FlipCoinEffect, CoinFlipLifeStakesEffect, RedirectEnteringSourceEffect, GrantBySpecEffect, GrantEffect, GrantNextSpellAbilityEffect,
    GrantNextSpellCostReductionEffect, GrantPlayTaggedDuration, GrantPlayTaggedEffect,
    GrantTaggedSpellFreeCastUntilEndOfTurnEffect, GrantTaggedSpellLifeCostByManaValueEffect,
    IncreaseSpeedEffect, LoseTheGameEffect, GrantLoyaltyActivationAllowanceEffect,
    CastFaceDownUsingActivationManaEffect, RegisterExtraDieReplacementEffect, GrantTapUncontrolledLandsForManaEffect, RerollStoredDieResultsEffect, RollAndStoreDieResultsEffect,
    LoyaltyActivationAllowance, LoyaltyActivationScope, MayCastForMadnessCostEffect,
    MayCastMatchingSpellWithoutPayingManaCostEffect, PayAnyEnergyEffect, PayAnyLifeEffect,
    PayEnergyEffect, PlaySubgameEffect, PlayerCountersEffect, PoisonCountersEffect,
    RadiationEffect, ReduceSpeedEffect, RestartGameEffect, RevealChosenPlayerEffect,
    RevealChosenSubtypeEffect,
    ReverseTurnOrderEffect, RingTemptsYouEffect, RippleEffect, RollDiceChooseResultEffect,
    RollDieEffect, RollPlanarDieEffect, RollToVisitAttractionsEffect, SkipCombatPhasesEffect, SkipCombatPhasesThisTurnEffect, SkipDrawStepEffect, PlayWithHandRevealedEffect, RevealSourceInHandUntilOwnersNextTurnEffect,
    SkipMainPhasesThisTurnEffect, SkipNextCombatPhaseThisTurnEffect, SkipScheduledEffect,
    SkipTurnEffect, TakeInitiativeEffect, TicketCountersEffect, VentureIntoDungeonEffect,
    WinTheGameEffect,
};
pub use replacement::{
    ApplyReplacementEffect, RegisterCounterPlacementReplacementEffect,
    RegisterDamagedBySourceZoneReplacementEffect, RegisterDrawReplacementEffect, RegisterEventReplacementEffect,
    RegisterEnterTappedReplacementEffect, RegisterEnterUnderControlReplacementEffect,
    RegisterEnterWithCountersReplacementEffect, RegisterFutureZoneReplacementEffect,
    RegisterManaReplacementEffect, RegisterManaRewriteEffect, RegisterManaSpendPermissionEffect,
    RegisterNextBatchEnterAsCopyEffect, RegisterNextBatchEnterWithCountersEffect,
    RegisterZoneReplacementEffect, ReplacementApplyMode,
};
pub use restrictions::CantEffect;
pub(crate) use stack::{CastStoredCardCopyEffect, EpicSpellCopyEffect};
pub use stack::{
    ChooseNewTargetsEffect, CopySpellEffect, CopySpellForEachTargetEffect, CounterEffect,
    PutRetainedSpellCopyOntoStackEffect, RetainSpellChoicesEffect,
    NewTargetRestriction, RetargetMode, RetargetStackObjectEffect, ScaleXValueEffect,
    VariableCasualtyPlaneswalkerCopyEffect,
};
pub use tokens::{
    AmassEffect, CreateLinkedFaceTokenEffect, CopyAttackTargetMode, CreateTokenCopyEffect, CreateTokenEffect, EmpowerJaceEffect,
    IncubateEffect, InvestigateEffect, TokenCopyReferenceSurface,
};
pub use zones::{
    BattlefieldController, BecomePlottedEffect, BecomeForetoldEffect, DestroyEffect, DestroyNoRegenerationEffect,
    EachPlayerSacrificesEffect, ExchangeZonesEffect, ExileEffect, ExileUntilDuration,
    ExileUntilEffect, LinkExiledCardsEffect, HauntExileEffect, LibraryPlacementOrder, MayMoveToZoneEffect,
    MoveToLibraryNthFromTopEffect, MoveToLibraryTopOrBottomChoiceEffect,
    MoveToZoneAttackTargetMode, MoveToZoneEffect, PutOntoBattlefieldEffect, ReorderGraveyardEffect,
    ReorderLibraryTopEffect, ReturnAllToBattlefieldEffect, ReturnAsAuraOptions,
    ReturnFromGraveyardOrExileToBattlefieldEffect, ReturnFromGraveyardToBattlefieldEffect,
    ReturnFromGraveyardToHandEffect, ReturnToHandEffect, SacrificeEffect, SacrificeTargetEffect,
    ShuffleObjectsIntoLibraryEffect,
};

pub use damage::DealDamageToRecipientsEffect;
pub use replacement::RegisterDamageAdditionEffect;
pub use replacement::RegisterDamageMultiplierEffect;
pub use replacement::RegisterTokenCreationMultiplierEffect;
pub use replacement::{RegisterDamageCounterReplacementEffect, RegisteredReplacementExpiry};

pub(crate) use composition::{
    TaggedRuntimeState, apply_outcome_tags, capture_tagged_runtime_state, is_object_selection,
    prepare_conditional_branch, resolve_source_binding,
};

pub(crate) use composition::{
    PreparedIfBranch, execute_if_branches_with_outputs, prepare_if_branches,
};


pub use damage::DealDamageBySourcesEffect;

pub use damage::DealDamageEachEffect;

pub use ironsmith_core::{SetPermanentDesignationEffect,GrantExileControllerInspectionEffect};

pub use composition::{NamedActionProgramEffect, FirstResolutionEachTurnEffect};
pub use ironsmith_core::GrantActivationCostAlternativeEffect;
pub use stack::TriggerAbilitiesByClassEffect;

pub(crate) use player::{HandRevealFrame,freeze_hand_reveal_frame,capture_hand_reveal_window,answer_hand_reveal_windows};
