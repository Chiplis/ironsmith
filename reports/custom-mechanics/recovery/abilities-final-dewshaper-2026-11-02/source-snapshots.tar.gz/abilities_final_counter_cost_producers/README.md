# Frozen spending-rule producer acquisition

Patch `frozen-counter-spending-rule-producers.patch` SHA256 `566b6ceb7dad3a8fd95afd3c50e8f998430c5bfccef2563e6414447e19c4985e` is a separate prerequisite, not a complete Dewshaper fix.

`ManaSpendingRuleProducer` freezes the exact effective ability's rule, source, controller, occurrence and designations when determining the cost. Complete native and granted Ability wrappers are sampled before extracting static leaves. Equal rules from distinct acquisitions are retained separately. No current source keyword, current marker, or counter-operation shape supplies a missing class.

The vector remains ordered through repricing, `with_pips` and inherited spending conditions so pending allocation indices stay meaningful. Activation-history rule binding updates the associated producer rule. Removing per-unit conditions removes orphan receipts; the nominal-price display clone clears all receipts with the conditions, preserving the earlier renderer progress fix.

Only `executable_definitions` changes in the four Siphon executable cohort rows, adding existing generic `abilityDesignation: "siphon"`. All previous fields, original reminders, original card text and complete source faces remain equal. The immutable `msem-source.json` inventory is unchanged. The complete-owner fixture hunk requires the whole14 input packet `9cd4c197...` first.

Dependent allocation/preview/commit/wasm transport is actions_linked packet `075485e317d7fc8ff10aee1684ef7a98712ce61d4a017ecf4b6d3eaf4a04ca5d`. Its later mixed-rule incomplete-evidence and activation-keyword provenance followup remains separately tracked. Do not infer those fixes from this prerequisite.

Root preparation after coherent integration:

```
node scripts/materialize-custom-mechanic-cohort.mjs fixtures/custom_mechanics/msem-final-abilities.json
node scripts/materialize-custom-mechanic-cohort.mjs fixtures/custom_mechanics/msem-final-real-source-next-wave.json
node scripts/materialize-custom-mechanic-cohort.mjs fixtures/custom_mechanics/msem-siphon-next-wave.json
node scripts/materialize-custom-mechanic-cohort.mjs fixtures/custom_mechanics/msem-final-owner-complete-inventory.json
```

Use the normal complete exact-source definition index. Keep all older cohorts and collision diagnostics; do not resolve policies by file ordering. Root must refresh effective typed schema bindings while retaining old format descriptors/goldens unchanged.

Authored unit filters: `spending_rule_producer_tests`, `counter_producer_acquisition_tests`. No tests, builds, probes, materialization or live edits were performed. Static apply-check passed for the five current-live paths; the sixth fixture hunk is explicitly based on the frozen whole14 input.
