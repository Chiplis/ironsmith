use super::*;
use crate::ability::AbilityKind;
use crate::ability::ActivatedAbilityRuntimeExt as _;
use crate::filter::{
    FilterContext, ObjectFilterExt as _, PlayerFilterExt as _, TaggedConstraintSubject as _,
};
use crate::types::CardType;

#[cfg(test)]
mod analysis_probe;
mod mechanics;
mod payment_characteristic_preview;
mod exile_payment_preview;
mod resumable;
pub use resumable::ManaAnalysisSession;
pub(super) use resumable::{
    analysis_failure, with_assumed_mana_for_presentation, with_checked_query,
};
pub(crate) use resumable::mana_payment_is_assumed;

pub use mechanics::*;

pub(super) fn check_scoped_mana_payment(game: &GameState, request: &crate::mana_payment::ManaPaymentRequest) -> bool {
    resumable::check_payment(game, request)
}

pub(crate) fn mana_cost_has_black_symbol(cost: &crate::mana::ManaCost) -> bool {
    cost.pips()
        .iter()
        .any(|pip| pip.contains(&crate::mana::ManaSymbol::Black))
}

fn with_source_exiled_tagged_objects(
    game: &GameState,
    mut ctx: crate::filter::FilterContext,
    source: ObjectId,
) -> crate::filter::FilterContext {
    let source_exiled = game
        .get_exiled_with_source_links(source)
        .iter()
        .filter_map(|id| {
            game.object(*id)
                .filter(|object| object.zone == Zone::Exile)
                .map(|obj| crate::snapshot::ObjectSnapshot::from_object(obj, game))
        })
        .collect::<Vec<_>>();
    if !source_exiled.is_empty() {
        ctx.tagged_objects
            .insert(crate::tag::SOURCE_EXILED_TAG.into(), source_exiled);
    }
    ctx
}

fn count_basic_land_types_among_filter(
    game: &GameState,
    filter: &crate::target::ObjectFilter,
    filter_ctx: &crate::filter::FilterContext,
) -> u32 {
    let mut seen = std::collections::HashSet::new();
    for obj in game.objects_in_deterministic_order() {
        if !filter.matches(obj, filter_ctx, game) {
            continue;
        }
        for subtype in game.calculated_subtypes(obj.id) {
            if subtype.is_basic_land_type() {
                seen.insert(subtype);
            }
        }
    }
    seen.len() as u32
}

fn shared_spell_characteristic_count(
    game: &GameState,
    spell: &crate::object::Object,
    source: ObjectId,
    controller: PlayerId,
    intersection: &ironsmith_core::CostReductionCharacteristicIntersection,
) -> i32 {
    let filter_ctx = with_source_exiled_tagged_objects(
        game,
        FilterContext::new(controller)
            .with_source(source)
            .with_active_player(game.turn.active_player)
            .with_opponents(
                game.turn_store
                    .turn_order
                    .iter()
                    .copied()
                    .filter(|player| *player != controller)
                    .collect(),
            ),
        source,
    );
    let comparison_objects = game
        .objects_in_deterministic_order()
        .into_iter()
        .filter(|object| intersection.comparison.matches(object, &filter_ctx, game))
        .collect::<Vec<_>>();

    // "for each card with the same name as that spell in your graveyard"
    // (Locket of Yesterdays): one per comparison object sharing the
    // characteristic, not per distinct shared value.
    if intersection.count_matching_objects {
        let spell_name = game
            .current_name(spell.id)
            .unwrap_or_else(|| spell.name.to_string());
        let spell_colors = game
            .current_colors(spell.id)
            .unwrap_or_else(|| spell.colors());
        let spell_types = game
            .current_card_types(spell.id)
            .unwrap_or_else(|| spell.card_types.to_vec());
        return comparison_objects
            .iter()
            .filter(|object| object.id != spell.id)
            .filter(|object| match intersection.characteristic {
                crate::ObjectCharacteristic::Name => crate::filter::names_share(
                    &spell_name,
                    spell.split_other_half_name(),
                    &game
                        .current_name(object.id)
                        .unwrap_or_else(|| object.name.to_string()),
                    object.split_other_half_name(),
                ),
                crate::ObjectCharacteristic::Color => !game
                    .current_colors(object.id)
                    .unwrap_or_else(|| object.colors())
                    .intersection(spell_colors)
                    .is_empty(),
                crate::ObjectCharacteristic::AllCardTypes => {
                    crate::ObjectCharacteristic::card_type_sets_match(
                        &game
                            .current_card_types(object.id)
                            .unwrap_or_else(|| object.card_types.to_vec()),
                        &spell_types,
                    )
                }
                crate::ObjectCharacteristic::CardType
                | crate::ObjectCharacteristic::PermanentType => game
                    .current_card_types(object.id)
                    .unwrap_or_else(|| object.card_types.to_vec())
                    .iter()
                    .any(|card_type| spell_types.contains(card_type)),
                crate::ObjectCharacteristic::Subtype(family) => {
                    let spell_subtypes = game.calculated_subtypes(spell.id);
                    game.calculated_subtypes(object.id)
                        .into_iter()
                        .filter(|subtype| subtype.belongs_to_family(family))
                        .any(|subtype| spell_subtypes.contains(&subtype))
                }
                crate::ObjectCharacteristic::ManaValue => {
                    object.subject_mana_value() == spell.subject_mana_value()
                }
            })
            .count() as i32;
    }

    match intersection.characteristic {
        crate::ObjectCharacteristic::AllCardTypes => {
            let spell_types = game
                .current_card_types(spell.id)
                .unwrap_or_else(|| spell.card_types.to_vec());
            comparison_objects.iter().any(|object| {
                crate::ObjectCharacteristic::card_type_sets_match(
                    &game
                        .current_card_types(object.id)
                        .unwrap_or_else(|| object.card_types.to_vec()),
                    &spell_types,
                )
            }) as i32
        }
        crate::ObjectCharacteristic::CardType => {
            let comparison = comparison_objects
                .iter()
                .flat_map(|object| {
                    game.current_card_types(object.id)
                        .unwrap_or_else(|| object.card_types.to_vec())
                })
                .collect::<std::collections::HashSet<_>>();
            game.current_card_types(spell.id)
                .unwrap_or_else(|| spell.card_types.to_vec())
                .into_iter()
                .filter(|card_type| comparison.contains(card_type))
                .count() as i32
        }
        crate::ObjectCharacteristic::PermanentType => {
            let is_permanent_type = |card_type: &CardType| {
                matches!(
                    card_type,
                    CardType::Land
                        | CardType::Creature
                        | CardType::Artifact
                        | CardType::Enchantment
                        | CardType::Planeswalker
                        | CardType::Battle
                )
            };
            let comparison = comparison_objects
                .iter()
                .flat_map(|object| {
                    game.current_card_types(object.id)
                        .unwrap_or_else(|| object.card_types.to_vec())
                })
                .filter(is_permanent_type)
                .collect::<std::collections::HashSet<_>>();
            game.current_card_types(spell.id)
                .unwrap_or_else(|| spell.card_types.to_vec())
                .into_iter()
                .filter(is_permanent_type)
                .filter(|card_type| comparison.contains(card_type))
                .count() as i32
        }
        crate::ObjectCharacteristic::Subtype(family) => {
            let comparison = comparison_objects
                .iter()
                .flat_map(|object| game.calculated_subtypes(object.id))
                .filter(|subtype| subtype.belongs_to_family(family))
                .collect::<std::collections::HashSet<_>>();
            game.calculated_subtypes(spell.id)
                .into_iter()
                .filter(|subtype| subtype.belongs_to_family(family))
                .filter(|subtype| comparison.contains(subtype))
                .count() as i32
        }
        crate::ObjectCharacteristic::Color if intersection.against_source_chosen_colors => game
            .current_colors(spell.id)
            .unwrap_or_else(|| spell.colors())
            .intersection(
                game.chosen_colors(source)
                    .unwrap_or(crate::color::ColorSet::COLORLESS),
            )
            .count() as i32,
        crate::ObjectCharacteristic::Color => {
            let comparison = comparison_objects.iter().fold(
                crate::color::ColorSet::COLORLESS,
                |colors, object| {
                    colors.union(
                        game.current_colors(object.id)
                            .unwrap_or_else(|| object.colors()),
                    )
                },
            );
            game.current_colors(spell.id)
                .unwrap_or_else(|| spell.colors())
                .intersection(comparison)
                .count() as i32
        }
        crate::ObjectCharacteristic::ManaValue => comparison_objects
            .iter()
            .any(|object| object.subject_mana_value() == spell.subject_mana_value())
            as i32,
        crate::ObjectCharacteristic::Name => {
            let primary = game
                .current_name(spell.id)
                .unwrap_or_else(|| spell.name.to_string());
            let mut names: Vec<String> = Vec::new();
            for name in primary.split(" // ").chain(
                spell
                    .split_other_half_name()
                    .into_iter()
                    .flat_map(|name| name.split(" // ")),
            ) {
                if !crate::filter::name_is_nameless(name)
                    && !names
                        .iter()
                        .any(|other| crate::filter::names_match(name, other))
                {
                    names.push(name.to_string());
                }
            }
            names
                .into_iter()
                .filter(|name| {
                    comparison_objects.iter().any(|object| {
                        crate::filter::names_share(
                            name,
                            None,
                            &game
                                .current_name(object.id)
                                .unwrap_or_else(|| object.name.to_string()),
                            object.split_other_half_name(),
                        )
                    })
                })
                .count() as i32
        }
    }
}

fn resolve_cost_reduction_amount(
    game: &GameState,
    spell: &crate::object::Object,
    source: ObjectId,
    controller: PlayerId,
    reduction: &crate::static_abilities::CostReduction,
) -> i32 {
    resolve_cost_reduction_amount_for_caster(game, spell, source, controller, controller, reduction)
}

/// How many times a mana-symbol reduction applies: once, or once per unit
/// of its "for each" count (Eluge), counted as the total cost is determined.
fn mana_cost_reduction_for_each(
    game: &GameState,
    spell: &crate::object::Object,
    source: ObjectId,
    controller: PlayerId,
    caster: PlayerId,
    reduction: &crate::static_abilities::CostReductionManaCost,
) -> usize {
    let Some(count) = &reduction.repetitions else {
        return 1;
    };
    let mut dm = SelectFirstDecisionMaker;
    let mut ctx = ExecutionContext::new(source, controller, &mut dm);
    ctx.iteration.iterated_player = Some(caster);
    ctx.iteration.iterated_object = Some(spell.id);
    usize::try_from(resolve_value(game, count, &ctx).unwrap_or(0)).unwrap_or(0)
}

fn resolve_cost_reduction_amount_for_caster(
    game: &GameState,
    spell: &crate::object::Object,
    source: ObjectId,
    controller: PlayerId,
    caster: PlayerId,
    reduction: &crate::static_abilities::CostReduction,
) -> i32 {
    // "for each time it's been cast" (Myth Unbound): within a cost
    // modifier, "it" is the spell being priced, exposed as the iterated
    // object alongside the iterated caster.
    let per_characteristic = {
        let mut dm = SelectFirstDecisionMaker;
        let mut ctx = ExecutionContext::new(source, controller, &mut dm);
        ctx.iteration.iterated_player = Some(caster);
        ctx.iteration.iterated_object = Some(spell.id);
        resolve_value(game, &reduction.reduction, &ctx).unwrap_or(0)
    };
    let Some(intersection) = &reduction.characteristic_intersection else {
        return per_characteristic;
    };
    per_characteristic.saturating_mul(shared_spell_characteristic_count(
        game,
        spell,
        source,
        controller,
        intersection,
    ))
}

fn alternative_method_is_emerge(
    method: &crate::alternative_cast::AlternativeCastingMethod,
) -> bool {
    method.sacrifice_reduces_generic_by_mana_value()
}

fn emerge_sacrifice_filter(
    method: &crate::alternative_cast::AlternativeCastingMethod,
) -> Option<crate::target::ObjectFilter> {
    method
        .non_mana_costs()
        .into_iter()
        .find_map(|cost| cost.sacrifice_filter().cloned())
}

fn maximum_emerge_reduction(
    game: &GameState,
    player: PlayerId,
    source: crate::ids::ObjectId,
    method: &crate::alternative_cast::AlternativeCastingMethod,
) -> u32 {
    if !alternative_method_is_emerge(method) {
        return 0;
    }
    let Some(filter) = emerge_sacrifice_filter(method) else {
        return 0;
    };
    let ctx = game.filter_context_for(player, Some(source));
    game.battlefield
        .iter()
        .copied()
        .filter_map(|id| {
            let obj = game.object(id)?;
            if game.controller_of(obj) != player
                || !filter.matches(obj, &ctx, game)
                || !game.can_be_sacrificed(id)
                || game.player_cant_sacrifice_object_to_cast_or_activate(player, id)
            {
                return None;
            }
            Some(crate::filter::object_current_mana_value(game, id))
        })
        .max()
        .unwrap_or(0)
}

/// What the activation cost pipeline needs to know about the activated
/// ability being priced (CR 601.2f, 602.2b): some modifiers apply only to
/// abilities that aren't mana abilities (Tithe Taker, CR 605.1a) or only to
/// equip abilities (Auriok Steelshaper, CR 702.6), other keyword abilities,
/// loyalty abilities, or activations performed by a particular player.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub struct ActivationCostAbility {
    /// None prices the maximum optional reduction for legality previews;
    /// an announced activation retains the player's exact chosen amount.
    pub optional_generic_reduction_limit: Option<u32>,
    pub mana_ability: bool,
    pub equip: bool,
    pub keyword: Option<ironsmith_core::ActivatedAbilityKeyword>,
    pub loyalty_ability: bool,
    pub activator: Option<PlayerId>,
    /// Index of the ability among its source's abilities, for "This ability
    /// costs ... less" (CR 602.2b), when known.
    pub ability_index: Option<usize>,
}

impl ActivationCostAbility {
    /// The payment reason these facts announce (keyword, mana, or loyalty
    /// activation), matching `ActivatedAbility::payment_reason`.
    pub fn payment_reason(&self) -> crate::costs::PaymentReason {
        crate::costs::PaymentReason::activation_of_kind(self.keyword, self.mana_ability, self.loyalty_ability)
    }

    /// Facts for the activated ability at `ability_index` of `source`, if
    /// there is one.
    pub fn at(
        game: &GameState,
        activator: PlayerId,
        source: ObjectId,
        ability_index: usize,
    ) -> Option<Self> {
        let ability = game.current_ability(source, ability_index)?;
        match &ability.kind {
            crate::ability::AbilityKind::Activated(activated) => Some(Self {
                ability_index: Some(ability_index),
                ..Self::of(game, activator, source, activated)
            }),
            _ => None,
        }
    }

    pub fn of(
        game: &GameState,
        activator: PlayerId,
        source: ObjectId,
        activated: &crate::ability::ActivatedAbility,
    ) -> Self {
        use crate::ability::ActivatedAbilityRuntimeExt as _;
        let ability_index = game.object(source).and_then(|object| {
            object.abilities.iter().position(|ability| {
                matches!(&ability.kind, crate::ability::AbilityKind::Activated(candidate)
                    if candidate == activated)
            })
        });
        Self {
            mana_ability: activated.is_runtime_mana_ability(game, source, activator),
            equip: super::legal_actions::is_equip_ability(game, source, activated),
            keyword: activated.keyword,
            loyalty_ability: activated.is_loyalty_ability(),
            activator: Some(activator),
            ability_index,
            optional_generic_reduction_limit: None,
        }
    }
}

/// Calculate activated-ability cost after applying battlefield static cost modifiers.
///
/// Without the ability, legacy equip/this-ability gates are estimates; exact
/// keyword, loyalty, nonmana and activator selectors require captured facts.
/// Actual activation owners use [`calculate_effective_activation_total_cost_for_ability`].
pub fn calculate_effective_activation_total_cost(
    game: &GameState,
    activator: PlayerId,
    ability_source: ObjectId,
    cost: &crate::cost::TotalCost,
) -> crate::cost::TotalCost {
    calculate_effective_activation_total_cost_with_chosen_targets(
        game,
        activator,
        ability_source,
        cost,
        &[],
    )
}

pub fn calculate_effective_activation_total_cost_with_chosen_targets(
    game: &GameState,
    activator: PlayerId,
    ability_source: ObjectId,
    cost: &crate::cost::TotalCost,
    chosen_targets: &[Target],
) -> crate::cost::TotalCost {
    let view = DerivedGameView::new(game);
    calculate_effective_activation_total_cost_with_view(
        game,
        activator,
        ability_source,
        cost,
        chosen_targets,
        None,
        &view,
    )
}

/// Calculate the total cost of activating `ability` (see
/// [`ActivationCostAbility`]) after static cost modifiers.
pub fn calculate_effective_activation_total_cost_for_ability(
    game: &GameState,
    activator: PlayerId,
    ability_source: ObjectId,
    cost: &crate::cost::TotalCost,
    chosen_targets: &[Target],
    ability: Option<ActivationCostAbility>,
) -> crate::cost::TotalCost {
    let view = DerivedGameView::new(game);
    calculate_effective_activation_total_cost_with_view(
        game,
        activator,
        ability_source,
        cost,
        chosen_targets,
        ability,
        &view,
    )
}

pub(crate) fn calculate_effective_activation_total_cost_with_view(
    game: &GameState, activator: PlayerId, ability_source: ObjectId,
    cost: &crate::cost::TotalCost, chosen_targets: &[Target],
    ability: Option<ActivationCostAbility>, view: &DerivedGameView<'_>,
) -> crate::cost::TotalCost {
    let raw = ability.map(|facts| crate::activation_cost_alternatives::unpriced_cost(game, ability_source, facts, cost, view)).unwrap_or_else(|| cost.clone());
    calculate_effective_activation_total_cost_without_grants(game, activator, ability_source, &raw, chosen_targets, ability, view)
}

/// Price an already selected and frozen branch without offering new methods.
pub(crate) fn calculate_effective_activation_selected_branch_cost(
    game: &GameState, activator: PlayerId, source: ObjectId, cost: &crate::cost::TotalCost,
    targets: &[Target], facts: Option<ActivationCostAbility>,
) -> crate::cost::TotalCost {
    calculate_effective_activation_total_cost_without_grants(game, activator, source, cost, targets, facts, &DerivedGameView::new(game))
}

pub(crate) fn calculate_effective_activation_total_cost_without_grants(
    game: &GameState,
    activator: PlayerId,
    ability_source: ObjectId,
    cost: &crate::cost::TotalCost,
    chosen_targets: &[Target],
    ability: Option<ActivationCostAbility>,
    view: &DerivedGameView<'_>,
) -> crate::cost::TotalCost {
    use crate::ability::AbilityKind;
    use crate::filter::{FilterContext, player_filter_matches_game};
    let bound;
    let cost = if crate::activation_color_history::needs_binding(cost) {
        bound=crate::activation_color_history::bind(game,ability_source,ability.and_then(|facts|facts.ability_index),cost);
        &bound
    } else {cost};

    if let ironsmith_core::TotalCostKind::OneOf(branches) = cost.kind() {
        return crate::cost::TotalCost::one_of(
            branches
                .iter()
                .map(|branch| {
                    calculate_effective_activation_total_cost_without_grants(
                        game,
                        activator,
                        ability_source,
                        branch,
                        chosen_targets,
                        ability,
                        view,
                    )
                })
                .collect(),
        );
    }

    fn opponents_of(game: &GameState, player: PlayerId) -> Vec<PlayerId> {
        game.turn_store
            .turn_order
            .iter()
            .copied()
            .filter(|p| *p != player)
            .collect()
    }

    // CR 601.2f / 602.2b: determine state-dependent payment amounts before
    // combining/increasing/reducing the total, then keep that determined cost
    // during payment. Unannounced X or unresolved object references remain
    // dynamic and must still pass the later context-aware payment check.
    let mut amount_context =
        crate::effects::ExecutionContext::new_default(ability_source, activator);
    amount_context.announced_targets = Some(
        chosen_targets
            .iter()
            .map(|target| match target {
                Target::Object(id) => crate::effects::ResolvedTarget::Object(*id),
                Target::Player(player) => crate::effects::ResolvedTarget::Player(*player),
            })
            .collect(),
    );
    let resolved = cost
        .costs()
        .iter()
        .map(|component| {
            if let Some(dynamic) = component.dynamic_mana_cost_ref()
                && dynamic.source_mana_cost_reduction_condition.is_none()
                && let Ok(mana) = crate::special_actions::resolve_dynamic_mana_cost(
                    game,
                    dynamic,
                    &mut amount_context,
                )
            {
                return crate::costs::Cost::mana(mana);
            }
            if let Some(life) = component
                .effect_ref()
                .and_then(|effect| effect.downcast_ref::<crate::effects::PayLifeEffect>())
                && !matches!(life.amount.unhinted(), crate::effect::Value::Fixed(_))
                && let Ok(amount) =
                    crate::effects::helpers::resolve_value(game, &life.amount, &amount_context)
            {
                return crate::costs::Cost::validated_effect(crate::effect::Effect::new(
                    crate::effects::PayLifeEffect::new(amount.max(0), life.player.clone()),
                ));
            }
            component.clone()
        })
        .collect();
    let mut adjusted = crate::cost::TotalCost::from_costs(resolved);
    let Some(ability_source_object) = game.object(ability_source) else {
        return adjusted;
    };

    let mut cost_modifier_sources = view.activated_ability_cost_modifier_sources();
    if ability_source_object.zone != Zone::Battlefield {
        cost_modifier_sources.push(ability_source);
    }

    for source_id in cost_modifier_sources {
        let Some(perm) = game.object(source_id) else {
            continue;
        };
        let controller = game.controller_of(perm);
        let filter_ctx = FilterContext::new(controller)
            .with_source(source_id)
            .with_active_player(game.turn.active_player)
            .with_opponents(opponents_of(game, controller));

        let static_abilities = if perm.zone == Zone::Battlefield {
            view.static_abilities_rc(source_id).unwrap_or_else(|| {
                std::sync::Arc::new(
                    perm.abilities
                        .iter()
                        .filter_map(|a| match &a.kind {
                            AbilityKind::Static(sa) => Some(sa.clone()),
                            _ => None,
                        })
                        .collect(),
                )
            })
        } else {
            std::sync::Arc::new(
                perm.abilities
                    .iter()
                    .filter_map(|a| match &a.kind {
                        AbilityKind::Static(sa) if a.functions_in(&perm.zone) => Some(sa.clone()),
                        _ => None,
                    })
                    .collect(),
            )
        };

        for static_ability in static_abilities.iter() {
            if !static_ability.is_active(game, source_id) {
                continue;
            }

            if let Some(increase) = static_ability.activated_ability_cost_increase() {
                if let Some(activator_filter) = &increase.activator
                    && !player_filter_matches_game(activator_filter, activator, game, &filter_ctx)
                {
                    continue;
                }
                // "... unless they're mana abilities" (Tithe Taker).
                if increase.non_mana_only && ability.is_some_and(|ability| ability.mana_ability) {
                    continue;
                }
                if !increase
                    .filter
                    .matches(ability_source_object, &filter_ctx, game)
                {
                    continue;
                }

                if let Some(condition) = &increase.ability_condition
                    && !crate::static_abilities::activated_ability_cost_condition_is_active_for_activation(
                        game, ability_source, source_id, condition, chosen_targets, ability,
                    ) { continue; }
                // Determine each surcharge in its author's source/controller
                // context before it joins the single total mana price. Keep
                // announced target identities from this activation available.
                let mut context = ExecutionContext::new_default(source_id, controller);
                context.announced_targets = Some(
                    chosen_targets
                        .iter()
                        .map(|target| match target {
                            Target::Object(id) => crate::effects::ResolvedTarget::Object(*id),
                            Target::Player(id) => crate::effects::ResolvedTarget::Player(*id),
                        })
                        .collect(),
                );
                let mut costs = adjusted.costs().to_vec();
                costs.extend(increase.increase.costs().iter().map(|component| {
                    if let Some(dynamic) = component.dynamic_mana_cost_ref()
                        && let Ok(mana) = crate::special_actions::resolve_dynamic_mana_cost(
                            game,
                            dynamic,
                            &mut context,
                        )
                    {
                        crate::costs::Cost::mana(mana)
                    } else {
                        component.clone()
                    }
                }));
                adjusted = crate::cost::TotalCost::from_costs(costs);
            }
        }
    }

    // Mana added by a cost increase is part of the same total. Merge it before
    // reductions; separate payment components otherwise overwrite one another
    // when the priority loop constructs its single mana payment.
    let components = adjusted.costs();
    let dynamic_indices = components
        .iter()
        .enumerate()
        .filter_map(|(index, cost)| cost.dynamic_mana_cost_ref().map(|_| index))
        .collect::<Vec<_>>();
    let merge_index = match dynamic_indices.as_slice() {
        [] => components
            .iter()
            .position(|cost| cost.mana_cost_ref().is_some()),
        [index] => {
            let mut probe = components[*index].dynamic_mana_cost_ref().unwrap().clone();
            probe.source_mana_cost_reduction_condition = None;
            probe.resolved_static_base().map(|_| *index)
        }
        _ => None,
    };
    if let Some(merge_index) = merge_index {
        let mut mana = crate::mana::ManaCost::new();
        for (index, component) in components.iter().enumerate() {
            if component.mana_cost_ref().is_some() {
                mana = add_mana_cost(&mana, component.mana_cost_ref().unwrap());
            } else if index == merge_index {
                mana = add_mana_cost(&mana, &component.dynamic_mana_cost_ref().unwrap().base);
            }
        }
        let merged = if let Some(dynamic) = components[merge_index].dynamic_mana_cost_ref() {
            let mut dynamic = dynamic.clone();
            dynamic.base = mana;
            crate::costs::Cost::dynamic_mana(dynamic)
        } else {
            crate::costs::Cost::mana(mana)
        };
        adjusted = crate::cost::TotalCost::from_costs(
            components
                .iter()
                .enumerate()
                .filter_map(|(index, component)| {
                    if index == merge_index {
                        Some(merged.clone())
                    } else if component.mana_cost_ref().is_some() {
                        None
                    } else {
                        Some(component.clone())
                    }
                })
                .collect(),
        );
    }
    let cost = &adjusted;
    let mut costs = Vec::with_capacity(cost.costs().len());
    for component in cost.costs() {
        if let Some(mana_cost) = component.mana_cost_ref() {
            let reduced = calculate_effective_activation_mana_cost_with_view(
                game,
                activator,
                ability_source,
                mana_cost,
                chosen_targets,
                ability,
                view,
            );
            costs.push(crate::costs::Cost::mana(reduced));
        } else if let Some(dynamic) = component.dynamic_mana_cost_ref() {
            let mut adjusted_dynamic = dynamic.clone();
            let mut base_probe = dynamic.clone();
            base_probe.source_mana_cost_reduction_condition = None;
            if let Some(base) = base_probe.resolved_static_base() {
                // Apply ordinary activation modifiers to the known base first;
                // the conditional source-cost reduction keeps its payer choices
                // until the activation's dynamic payment step.
                adjusted_dynamic.base = calculate_effective_activation_mana_cost_with_view(
                    game,
                    activator,
                    ability_source,
                    &base,
                    chosen_targets,
                    ability,
                    view,
                );
            }
            costs.push(crate::costs::Cost::dynamic_mana(adjusted_dynamic));
        } else {
            costs.push(component.clone());
        }
    }

    merge_loyalty_cost_components(crate::cost::TotalCost::from_costs(costs))
}

/// An additional loyalty cost ("Planeswalkers' loyalty abilities you activate
/// cost an additional [+1] to activate", Carth the Lion) changes the printed
/// loyalty cost rather than adding a second payment: [-2] becomes [-1] and
/// [+1] becomes [+2], so a planeswalker with 1 loyalty may activate [-2].
fn merge_loyalty_cost_components(cost: crate::cost::TotalCost) -> crate::cost::TotalCost {
    use crate::object::CounterType;
    let effect_loyalty_delta = |component: &crate::costs::Cost| -> Option<i64> {
        // A cost increase such as Carth's "[+1]" is an effect-backed
        // "put a loyalty counter on this" cost component.
        let effect = component.effect_ref()?;
        let effect = effect
            .downcast_ref::<crate::effects::WithIdEffect>()
            .map_or(effect, |observed| &observed.effect);
        let is_source = |spec: &crate::target::ChooseSpec| {
            matches!(spec.base(), crate::target::ChooseSpec::Source)
        };
        if let Some(put) = effect.downcast_ref::<crate::effects::PutCountersEffect>()
            && put.counter_type == CounterType::Loyalty
            && is_source(&put.target)
            && put.maximum_total.is_none()
            && let crate::effect::Value::Fixed(count) = put.amount
        {
            return Some(i64::from(count));
        }
        if let Some(remove) = effect.downcast_ref::<crate::effects::RemoveCountersEffect>()
            && remove.counter_type == CounterType::Loyalty
            && is_source(&remove.target)
            && let crate::effect::Value::Fixed(count) = remove.count
        {
            return Some(-i64::from(count));
        }
        None
    };
    let loyalty_delta = |component: &crate::costs::Cost| -> Option<i64> {
        match component.compiled_model() {
            Some(ironsmith_core::Cost::AddCounters {
                counter_type: CounterType::Loyalty,
                count,
            }) => Some(i64::from(*count)),
            Some(ironsmith_core::Cost::RemoveCounters {
                counter_type: CounterType::Loyalty,
                count,
            }) => Some(-i64::from(*count)),
            _ => effect_loyalty_delta(component),
        }
    };
    let components = cost.costs();
    let loyalty = components
        .iter()
        .enumerate()
        .filter_map(|(index, component)| loyalty_delta(component).map(|delta| (index, delta)))
        .collect::<Vec<_>>();
    if loyalty.len() < 2 {
        return cost;
    }
    let net: i64 = loyalty.iter().map(|(_, delta)| delta).sum();
    let merged = if net < 0 {
        crate::costs::Cost::remove_counters(
            CounterType::Loyalty,
            u32::try_from(-net).unwrap_or(u32::MAX),
        )
    } else {
        crate::costs::Cost::add_counters(CounterType::Loyalty, u32::try_from(net).unwrap_or(u32::MAX))
    };
    let first = loyalty[0].0;
    crate::cost::TotalCost::from_costs(
        components
            .iter()
            .enumerate()
            .filter_map(|(index, component)| {
                if index == first {
                    Some(merged.clone())
                } else if loyalty.iter().any(|(loyalty_index, _)| *loyalty_index == index) {
                    None
                } else {
                    Some(component.clone())
                }
            })
            .collect(),
    )
}

/// Calculate the effective mana portion of an activated ability's cost.
pub fn calculate_effective_activation_mana_cost(
    game: &GameState,
    activator: PlayerId,
    ability_source: ObjectId,
    base_cost: &crate::mana::ManaCost,
) -> crate::mana::ManaCost {
    let view = DerivedGameView::new(game);
    calculate_effective_activation_mana_cost_with_view(
        game,
        activator,
        ability_source,
        base_cost,
        &[],
        None,
        &view,
    )
}

pub(crate) fn calculate_effective_activation_mana_cost_with_view(
    game: &GameState,
    activator: PlayerId,
    ability_source: ObjectId,
    base_cost: &crate::mana::ManaCost,
    chosen_targets: &[Target],
    ability: Option<ActivationCostAbility>,
    view: &DerivedGameView<'_>,
) -> crate::mana::ManaCost {
    calculate_effective_activation_mana_cost_with_view_and_budget(
        game, activator, ability_source, base_cost, chosen_targets, ability, view,
    ).0
}

pub(crate) fn calculate_effective_activation_mana_cost_with_view_and_budget(
    game: &GameState,
    activator: PlayerId,
    ability_source: ObjectId,
    base_cost: &crate::mana::ManaCost,
    chosen_targets: &[Target],
    ability: Option<ActivationCostAbility>,
    view: &DerivedGameView<'_>,
) -> (crate::mana::ManaCost, u32) {
    use crate::ability::AbilityKind;
    use crate::filter::FilterContext;

    fn opponents_of(game: &GameState, player: PlayerId) -> Vec<PlayerId> {
        game.turn_store
            .turn_order
            .iter()
            .copied()
            .filter(|p| *p != player)
            .collect()
    }

    let mut adjusted = base_cost.clone();
    let mut reductions = Vec::new();
    let mut optional_remaining = ability.and_then(|facts| facts.optional_generic_reduction_limit).unwrap_or(u32::MAX);
    let Some(ability_source_object) = game.object(ability_source) else {
        return (adjusted, 0);
    };

    let mut cost_modifier_sources = view.activated_ability_cost_modifier_sources();
    if ability_source_object.zone != Zone::Battlefield {
        cost_modifier_sources.push(ability_source);
    }

    for source_id in cost_modifier_sources {
        let Some(perm) = game.object(source_id) else {
            continue;
        };
        let controller = game.controller_of(perm);
        let filter_ctx = FilterContext::new(controller)
            .with_source(source_id)
            .with_active_player(game.turn.active_player)
            .with_opponents(opponents_of(game, controller));

        let static_abilities = if perm.zone == Zone::Battlefield {
            view.static_abilities_rc(source_id).unwrap_or_else(|| {
                std::sync::Arc::new(
                    perm.abilities
                        .iter()
                        .filter_map(|a| match &a.kind {
                            AbilityKind::Static(sa) => Some(sa.clone()),
                            _ => None,
                        })
                        .collect(),
                )
            })
        } else {
            std::sync::Arc::new(
                perm.abilities
                    .iter()
                    .filter_map(|a| match &a.kind {
                        AbilityKind::Static(sa) if a.functions_in(&perm.zone) => Some(sa.clone()),
                        _ => None,
                    })
                    .collect(),
            )
        };

        for static_ability in static_abilities.iter() {
            if !static_ability.is_active(game, source_id) {
                continue;
            }

            if let Some(reduction) = static_ability.activated_ability_cost_reduction() {
                if !reduction
                    .filter
                    .matches(ability_source_object, &filter_ctx, game)
                {
                    continue;
                }
                if let Some(condition) = &reduction.condition
                    && !crate::static_abilities::activated_ability_cost_condition_is_active_for_activation(
                        game,
                        ability_source,
                        source_id,
                        condition,
                        chosen_targets,
                        ability,
                    )
                {
                    continue;
                }

                let multiplier = if let Some(value) = &reduction.multiplier {
                    let mut dm = SelectFirstDecisionMaker;
                    let targets = chosen_targets
                        .iter()
                        .map(|target| match target {
                            Target::Object(id) => crate::effects::ResolvedTarget::Object(*id),
                            Target::Player(id) => crate::effects::ResolvedTarget::Player(*id),
                        })
                        .collect();
                    // Values authored by a cost modifier use that modifier's
                    // source/controller; announced targets still belong to the
                    // activation being priced. These identities can differ.
                    let ctx =
                        ExecutionContext::new(source_id, controller, &mut dm).with_targets(targets);
                    resolve_value(game, value, &ctx).unwrap_or(0).max(0) as u32
                } else if let Some(per_filter) = &reduction.per_matching_objects {
                    game.objects_in_deterministic_order()
                        .into_iter()
                        .filter(|obj| per_filter.matches(obj, &filter_ctx, game))
                        .count() as u32
                } else if let Some(lands_filter) = &reduction.per_basic_land_types_among {
                    count_basic_land_types_among_filter(game, lands_filter, &filter_ctx)
                } else {
                    1
                };
                if multiplier == 0 {
                    continue;
                }

                if let Some(replacement) = &reduction.replacement_mana_cost {
                    adjusted = replacement.clone();
                    reductions.clear();
                    optional_remaining = ability.and_then(|facts| facts.optional_generic_reduction_limit).unwrap_or(u32::MAX);
                    continue;
                }

                let mut amount = reduction.reduction.saturating_mul(multiplier);
                if reduction.optional {
                    amount = amount.min(optional_remaining);
                    optional_remaining -= amount;
                }
                reductions.push((amount, reduction.minimum_total_mana));
            }
        }
    }

    // CR 601.2f: the activator chooses reduction order. Applying larger
    // floors first, and unbounded reductions last, gives the least legal
    // generic price independently of battlefield insertion order.
    reductions.sort_by_key(|(_, minimum)| std::cmp::Reverse(minimum.unwrap_or(0)));
    let mut budget = 0u32;
    for (amount, minimum) in reductions {
        budget = budget.saturating_add(amount);
        let before = adjusted.clone();
        adjusted = adjusted.reduce_generic(amount);
        if let Some(minimum) = minimum
            && before.mana_value() > 0 && adjusted.mana_value() < minimum
        { adjusted = add_generic_mana_cost(&adjusted, minimum - adjusted.mana_value()); }
    }
    let adjusted = apply_payment_reason_mana_adjustments(
        game,
        activator,
        Some(ability_source),
        &adjusted,
        crate::costs::PaymentReason::ActivateAbility,
    );
    // CR 602.1e: an ability's "for each mana in this ability's activation
    // cost" payment method applies after taxes and reductions establish the
    // total. Waterbend itself remains scoped to its authored component.
    let adjusted = if base_cost.has_creature_tap_payment() {
        adjusted.with_creature_tap_payment()
    } else if base_cost.has_artifact_tap_payment() {
        adjusted.with_artifact_tap_payment()
    } else { adjusted };
    let adjusted=with_source_generic_tap_payment(game,activator,ability_source_object,adjusted,true);
    (adjusted, budget)
}

/// Capacity of matching optional generic reductions, using the same source,
/// controller and selected-ability gates as total-cost pricing.
pub(crate) fn optional_activation_reduction_capacity(
    game: &GameState, activator: PlayerId, source: ObjectId,
    targets: &[Target], facts: ActivationCostAbility,
) -> u32 {
    let view = DerivedGameView::new(game);
    let base = crate::mana::ManaCost::default();
    let mut all = facts;
    all.optional_generic_reduction_limit = None;
    let mut none = facts;
    none.optional_generic_reduction_limit = Some(0);
    let (_, maximum) = calculate_effective_activation_mana_cost_with_view_and_budget(game, activator, source, &base, targets, Some(all), &view);
    let (_, mandatory) = calculate_effective_activation_mana_cost_with_view_and_budget(game, activator, source, &base, targets, Some(none), &view);
    maximum.saturating_sub(mandatory)
}

/// Lock announced X in the original cost before taxes and reductions.
pub(crate) fn activation_cost_with_locked_x(cost: &crate::cost::TotalCost, x: u32) -> crate::cost::TotalCost {
    match cost.kind() {
        ironsmith_core::TotalCostKind::OneOf(branches) => crate::cost::TotalCost::one_of(
            branches.iter().map(|branch| activation_cost_with_locked_x(branch, x)).collect()),
        ironsmith_core::TotalCostKind::All(components) => crate::cost::TotalCost::from_costs(
            components.iter().map(|component| match component.mana_cost_ref() {
                Some(mana) if mana.has_x() => crate::costs::Cost::mana(
                    mana_cost_with_locked_x_and_generic_reduction(mana, x, 0)),
                _ => if let Some(dynamic) = component.dynamic_mana_cost_ref() {
                    let mut dynamic = dynamic.clone();
                    if dynamic.base.has_x() {
                        dynamic.base = mana_cost_with_locked_x_and_generic_reduction(&dynamic.base, x, 0);
                    }
                    crate::costs::Cost::dynamic_mana(dynamic)
                } else { component.clone() },
            }).collect()),
    }
}

/// Maximum ordinary mana-funded X for one selected activation-cost branch.
/// The upper bound retains all matching generic reduction capacity, then each
/// binary-search candidate is locked and priced by the same total-cost owner.
/// No fixed trial X clips a large legitimate reduction.
pub(crate) fn maximum_x_for_activation_cost(
    game: &GameState, activator: PlayerId, source: ObjectId,
    original: &crate::cost::TotalCost, targets: &[Target], facts: ActivationCostAbility,
) -> Result<Option<u32>, crate::effects::ExecutionError> {
    super::with_complete_legality_query(game, |checked| {
        maximum_x_for_activation_cost_in_query(checked, activator, source, original, targets, facts)
    })
}

fn maximum_x_for_activation_cost_in_query(
    game: &GameState, activator: PlayerId, source: ObjectId,
    original: &crate::cost::TotalCost, targets: &[Target], facts: ActivationCostAbility,
) -> Result<Option<u32>, crate::effects::ExecutionError> {
    let components = original.as_all().ok_or_else(|| crate::effects::ExecutionError::IncompleteEvidence(
        "activation X has no selected original cost branch".into()))?;
    let symbolic = calculate_effective_activation_selected_branch_cost(
        game, activator, source, original, targets, Some(facts));
    let Some(mana) = symbolic.mana_cost().or_else(|| symbolic.dynamic_mana_cost().map(|cost| &cost.base)) else {
        return Ok(None);
    };
    if !mana.has_x() { return Ok(None); }
    let x_pips = mana.pips().iter().filter(|pip| pip.contains(&crate::mana::ManaSymbol::X)).count() as u32;
    let policy = game.mana_spend_policy_with_reason(activator, Some(source), facts.payment_reason());
    let allow_black_life = mana_cost_has_black_symbol(mana)
        && game.player_can_pay_black_with_life_for_reason(activator, Some(source), facts.payment_reason());
    let potential = if components.iter().any(|cost| cost.requires_tap()) {
        // A tapped resource cannot finance the activation that reserves its tap.
        let mut funding = game.clone();
        funding.tap(source);
        compute_potential_mana(&funding, activator)
    } else { compute_potential_mana(game, activator) };
    let view = DerivedGameView::new(game);
    let (_, budget) = calculate_effective_activation_mana_cost_with_view_and_budget(
        game, activator, source, mana, targets, Some(facts), &view);
    let intrinsic_credit = symbolic.dynamic_mana_cost()
        .filter(|cost| cost.source_mana_cost_reduction_condition.is_some())
        .and_then(|_| game.object(source)).and_then(|object| object.mana_cost.as_ref())
        .map_or(0, |cost| cost.mana_value());
    let mut high = potential.total().saturating_add(budget).saturating_add(intrinsic_credit) / x_pips.max(1);
    let mut low = 0;
    while low < high {
        let middle = low + (high - low).div_ceil(2);
        let locked = activation_cost_with_locked_x(original, middle);
        let price = calculate_effective_activation_selected_branch_cost(
            game, activator, source, &locked, targets, Some(facts));
        let mut context = ExecutionContext::new_default(source, activator).with_x(middle);
        let fixed = if let Some(dynamic) = price.dynamic_mana_cost() {
            Some(crate::special_actions::resolve_dynamic_mana_cost(game, dynamic, &mut context).map_err(|error| match error {
                crate::cost::CostPaymentError::ExecutionFailed(error) => error,
                error => crate::effects::ExecutionError::UnresolvableValue(format!("activation X price: {error:?}")),
            })?)
        } else { price.mana_cost().cloned() };
        let affordable = fixed.as_ref().is_none_or(|mana| {
            potential.clone().try_pay_tracking_life_with_mana_spend_policy_and_black_life(
                mana, 0, &policy, allow_black_life).0
        });
        if affordable { low = middle; } else { high = middle - 1; }
    }
    Ok(Some(low))
}

/// Resolve an alternative method index for `CastingMethod::PlayFrom`.
///
/// The index space is:
/// 1) Card intrinsic alternatives (`card.alternative_casts`)
/// 2) Granted alternatives for this card/zone/player (appended after intrinsic methods)
pub fn resolve_play_from_alternative_method(
    game: &GameState,
    player: PlayerId,
    spell: &crate::object::Object,
    zone: Zone,
    idx: usize,
) -> Option<crate::alternative_cast::AlternativeCastingMethod> {
    // Announcement owns the selected method after the spell moves to the
    // stack. Paying costs may remove or consume its provider and change the
    // current grant index space; those changes cannot rewrite this cast.
    if spell.zone == Zone::Stack {
        if let Some(method) = spell.cast_alternative_method_owned() {
            return Some(method);
        }
    }
    if let Some(method) = spell.alternative_casts.get(idx) {
        return Some(method.clone());
    }

    resolve_play_from_alternative_grant(game, player, spell, zone, idx).map(|entry| entry.method)
}

/// Resolve the exact indexed grant while the originating card and permissions
/// still exist. Intrinsic alternatives deliberately have no grant payload.
pub(crate) fn resolve_play_from_alternative_grant(
    game: &GameState,
    player: PlayerId,
    spell: &crate::object::Object,
    zone: Zone,
    idx: usize,
) -> Option<crate::grant_registry::GrantedAlternativeCast> {
    let granted = game
        .effect_store
        .grant_registry
        .granted_alternative_casts_for_card(game, spell.id, zone, player);
    let granted_idx = idx.checked_sub(spell.alternative_casts.len())?;
    if let Some(entry) = granted.get(granted_idx) {
        return Some(entry.clone());
    }

    let adventure_idx = granted_idx.checked_sub(granted.len())?;
    let adventure_view = spell_view_for_split_other_half_cast(game, spell)?;
    let view = DerivedGameView::new(game);
    let adventure_granted =
        view.granted_alternative_casts_for_card_view(spell.id, &adventure_view, zone, player);
    adventure_granted.get(adventure_idx).cloned()
}

pub(crate) fn alternative_cast_method_matches_kind(
    method: &crate::alternative_cast::AlternativeCastingMethod,
    kind: crate::filter::AlternativeCastKind,
) -> bool {
    use crate::alternative_cast::AlternativeCastingMethod;
    use crate::filter::AlternativeCastKind;

    matches!(
        (kind, method),
        (
            AlternativeCastKind::Blitz,
            AlternativeCastingMethod::Blitz { .. }
        ) | (
            AlternativeCastKind::Dash,
            AlternativeCastingMethod::Dash { .. }
        ) | (
            AlternativeCastKind::Flashback,
            AlternativeCastingMethod::Flashback { .. }
        ) | (
            AlternativeCastKind::JumpStart,
            AlternativeCastingMethod::JumpStart { .. }
        ) | (
            AlternativeCastKind::Escape,
            AlternativeCastingMethod::Escape { .. }
        ) | (
            AlternativeCastKind::Madness,
            AlternativeCastingMethod::Madness { .. }
        ) | (
            AlternativeCastKind::Miracle,
            AlternativeCastingMethod::Miracle { .. }
        ) | (
            AlternativeCastKind::Suspend,
            AlternativeCastingMethod::Suspend { .. }
        ) | (
            AlternativeCastKind::Foretell,
            AlternativeCastingMethod::Foretell { .. }
        )
    )
}

pub(crate) fn casting_method_matches_alternative_kind(
    game: &GameState,
    caster: PlayerId,
    spell: &crate::object::Object,
    casting_method: &CastingMethod,
    kind: crate::filter::AlternativeCastKind,
) -> bool {
    if matches!(casting_method, CastingMethod::ExactPermission { .. }) {
        return alternative_method_for_casting_method(game, caster, spell, casting_method).as_ref().is_some_and(|method| alternative_cast_method_matches_kind(method, kind));
    }
    if matches!(casting_method.without_exact_permission(), CastingMethod::AlternativePrice { .. }) {
        return crate::alternative_cast::price_routes::origin_alternative(
            game,
            caster,
            spell,
            casting_method,
        )
        .as_ref()
        .is_some_and(|method| alternative_cast_method_matches_kind(method, kind));
    }
    match casting_method.origin_method() {
        CastingMethod::Alternative(idx) => spell
            .alternative_casts
            .get(*idx)
            .is_some_and(|method| alternative_cast_method_matches_kind(method, kind)),
        CastingMethod::GrantedEscape { .. } => kind == crate::filter::AlternativeCastKind::Escape,
        CastingMethod::GrantedFlashback => kind == crate::filter::AlternativeCastKind::Flashback,
        CastingMethod::PlayFrom {
            use_alternative: Some(idx),
            zone,
            ..
        }
        | CastingMethod::SplitOtherHalfPlayFrom {
            use_alternative: Some(idx),
            zone,
            ..
        } => resolve_play_from_alternative_method(game, caster, spell, *zone, *idx)
            .or_else(|| spell.cast_alternative_method_owned())
            .as_ref()
            .is_some_and(|method| alternative_cast_method_matches_kind(method, kind)),
        CastingMethod::Normal => spell
            .cast_alternative_method
            .as_ref()
            .is_some_and(|method| alternative_cast_method_matches_kind(method, kind)),
        CastingMethod::FaceDown
        | CastingMethod::FaceDownPlayFrom { .. }
        | CastingMethod::SplitOtherHalf
        | CastingMethod::Fuse
        | CastingMethod::PlayFrom {
            use_alternative: None,
            ..
        }
        | CastingMethod::SplitOtherHalfPlayFrom {
            use_alternative: None,
            ..
        } => false,
        CastingMethod::AlternativePrice { .. } | CastingMethod::ExactPermission { .. } => false,
    }
}

fn casting_method_is_bestow(
    game: &GameState,
    caster: PlayerId,
    spell: &crate::object::Object,
    casting_method: &CastingMethod,
) -> bool {
    if matches!(casting_method, CastingMethod::ExactPermission { .. }) {
        return alternative_method_for_casting_method(game, caster, spell, casting_method).is_some_and(|method| method.is_bestow());
    }
    match casting_method.without_exact_permission() {
        CastingMethod::Alternative(idx) => spell
            .alternative_casts
            .get(*idx)
            .is_some_and(|method| method.is_bestow()),
        CastingMethod::PlayFrom {
            use_alternative: Some(idx),
            zone,
            ..
        }
        | CastingMethod::SplitOtherHalfPlayFrom {
            use_alternative: Some(idx),
            zone,
            ..
        } => resolve_play_from_alternative_method(game, caster, spell, *zone, *idx)
            .or_else(|| spell.cast_alternative_method_owned())
            .as_ref()
            .is_some_and(|method| method.is_bestow()),
        _ => false,
    }
}

fn casting_method_is_mutate(
    game: &GameState,
    caster: PlayerId,
    spell: &crate::object::Object,
    casting_method: &CastingMethod,
) -> bool {
    if matches!(casting_method, CastingMethod::ExactPermission { .. }) {
        return alternative_method_for_casting_method(game, caster, spell, casting_method).is_some_and(|method| method.is_mutate());
    }
    match casting_method.without_exact_permission() {
        CastingMethod::Alternative(idx) => spell
            .alternative_casts
            .get(*idx)
            .is_some_and(|method| method.is_mutate()),
        CastingMethod::PlayFrom {
            use_alternative: Some(idx),
            zone,
            ..
        }
        | CastingMethod::SplitOtherHalfPlayFrom {
            use_alternative: Some(idx),
            zone,
            ..
        } => resolve_play_from_alternative_method(game, caster, spell, *zone, *idx)
            .or_else(|| spell.cast_alternative_method_owned())
            .as_ref()
            .is_some_and(|method| method.is_mutate()),
        _ => false,
    }
}

fn inferred_cast_origin_zone_for_cost_filter(
    _game: &GameState,
    _caster: PlayerId,
    spell: &crate::object::Object,
    casting_method: &CastingMethod,
) -> Zone {
    match casting_method.origin_method() {
        CastingMethod::Normal => {
            if spell.zone == Zone::Stack {
                Zone::Hand
            } else {
                spell.zone
            }
        }
        CastingMethod::FaceDown | CastingMethod::SplitOtherHalf | CastingMethod::Fuse => Zone::Hand,
        CastingMethod::Alternative(idx) => spell
            .alternative_casts
            .get(*idx)
            .cloned()
            .or_else(|| spell.cast_alternative_method_owned())
            .map(|method| method.cast_from_zone())
            .unwrap_or_else(|| {
                if spell.zone == Zone::Stack {
                    Zone::Hand
                } else {
                    spell.zone
                }
            }),
        CastingMethod::GrantedEscape { .. } | CastingMethod::GrantedFlashback => Zone::Graveyard,
        CastingMethod::PlayFrom { zone, .. }
        | CastingMethod::SplitOtherHalfPlayFrom { zone, .. }
        | CastingMethod::FaceDownPlayFrom { zone, .. } => *zone,
        CastingMethod::AlternativePrice { .. } | CastingMethod::ExactPermission { .. } => spell.zone,
    }
}

fn spell_view_for_cost_filter_match(
    game: &GameState,
    caster: PlayerId,
    spell: &crate::object::Object,
    casting_method: &CastingMethod,
    cast_from_zone: Option<Zone>,
) -> Option<crate::object::Object> {
    let selected_price_face = if let CastingMethod::ExactPermission { .. } = casting_method {
        if spell.zone == Zone::Stack { game.object(spell.id).cloned() }
        else { match crate::alternative_cast::play_permission::selected_face(game, caster, spell, casting_method) {
            Ok((face, _, _)) => Some(face),
            Err(error) => { game.record_token_resource_failure(&error); return None; }
        } }
    } else { match casting_method.without_exact_permission() {
        CastingMethod::AlternativePrice {
            origin,
            prototype: Some(index),
            ..
        } => {
            crate::alternative_cast::price_routes::proposed_face(game, spell, origin, Some(*index))
        }
        _ => None,
    } };
    let mut changed = selected_price_face.is_some();
    let mut view = selected_price_face.unwrap_or_else(|| spell.clone());

    if matches!(casting_method.origin_method(), CastingMethod::FaceDown | CastingMethod::FaceDownPlayFrom { .. }) {
        // Cost modifiers inspect the selected spell characteristics before
        // announcement publishes the object or its face-down status.
        view = spell_view_for_face_down_cast(game, &view);
        changed = true;
    } else if casting_method_is_bestow(game, caster, spell, casting_method) {
        view.apply_bestow_cast_overlay();
        changed = true;
    } else {
        let method = match casting_method.without_exact_permission() {
            CastingMethod::Alternative(idx) => spell
                .alternative_casts
                .get(*idx)
                .cloned()
                .or_else(|| spell.cast_alternative_method_owned()),
            CastingMethod::PlayFrom {
                use_alternative: Some(idx),
                zone,
                ..
            }
            | CastingMethod::SplitOtherHalfPlayFrom {
                use_alternative: Some(idx),
                zone,
                ..
            } => resolve_play_from_alternative_method(game, caster, spell, *zone, *idx)
                .or_else(|| spell.cast_alternative_method_owned()),
            _ => spell.cast_alternative_method_owned(),
        };

        if method
            .as_ref()
            .is_some_and(|method| method.casts_transformed())
        {
            if let Some(disturb_view) = spell_view_for_disturb_cast(game, spell) {
                view = disturb_view;
                changed = true;
            }
        } else if let Some(method) = method.as_ref()
            && let Some(power_toughness) = method.prototype_power_toughness()
            && let Some(cost) = method.mana_cost()
            && view.apply_prototype_cast_overlay(cost.clone(), power_toughness)
        {
            changed = true;
        }
    }

    if cast_from_zone.is_some() || spell.zone == Zone::Stack {
        view.zone = cast_from_zone.unwrap_or_else(|| {
            inferred_cast_origin_zone_for_cost_filter(game, caster, spell, casting_method)
        });
        changed = true;
    }

    changed.then_some(view)
}

pub(crate) fn optional_life_cost_reduction_costs_for_cast(
    game: &GameState,
    caster: PlayerId,
    spell_id: ObjectId,
    casting_method: &CastingMethod,
    cast_from_zone: Option<Zone>,
) -> Vec<(ObjectId, ironsmith_core::OptionalLifeAdditionalCost)> {
    let Some(spell) = game.object(spell_id) else {
        return Vec::new();
    };
    let view = DerivedGameView::new(game);
    let modifier_sources = view.battlefield_spell_cost_modifier_sources();
    if modifier_sources.is_empty() {
        return Vec::new();
    }

    // A printed modifier source can be discovered without layered reads, but
    // inspecting its active abilities and the live stack spell can still need
    // them. Batch both classes before either lookup so a dirty cast state never
    // falls back to one full-board baseline per source.
    let mut prewarm_ids = modifier_sources.clone();
    if !prewarm_ids.contains(&spell_id) {
        prewarm_ids.push(spell_id);
    }
    view.prewarm_characteristics_forced(&prewarm_ids);

    let spell_for_filter =
        spell_view_for_cost_filter_match(game, caster, spell, casting_method, cast_from_zone)
            .unwrap_or_else(|| {
                let mut spell_for_filter = spell.clone();
                if let Some(chars) = view.current_characteristics_arc(spell_id) {
                    spell_for_filter.name = chars.name.clone();
                    spell_for_filter.card_types = chars.card_types.to_vec().into();
                    spell_for_filter.subtypes = chars.subtypes.to_vec().into();
                    spell_for_filter.supertypes = chars.supertypes.to_vec().into();
                    spell_for_filter.color_override = Some(chars.colors);
                }
                spell_for_filter
            });

    let mut costs = Vec::new();
    for perm_id in modifier_sources {
        let Some(perm) = game.object(perm_id) else {
            continue;
        };
        let controller = view
            .current_controller(perm_id)
            .unwrap_or_else(|| game.controller_of(perm));
        let filter_ctx = game
            .filter_context_for(controller, Some(perm_id))
            .with_caster(Some(caster));
        let Some(abilities) = view.spell_cost_modifier_static_abilities_rc(perm_id) else {
            continue;
        };
        for static_ability in abilities.iter() {
            if !static_ability.is_active(game, perm_id) {
                continue;
            }
            let Some(reduction) = static_ability.cost_reduction_mana_cost() else {
                continue;
            };
            let Some(optional) = &reduction.optional_life_additional_cost else {
                continue;
            };
            if reduction
                .filter
                .matches_non_recursive(&spell_for_filter, &filter_ctx, game)
            {
                costs.push((perm_id, optional.clone()));
            }
        }
    }

    costs
}

pub(crate) fn optional_life_cost_reduction_label(
    optional: &ironsmith_core::OptionalLifeAdditionalCost,
    source: ObjectId,
) -> String {
    format!("{} [source:{}]", optional.label, source.0)
}

fn spell_with_optional_life_cost_reduction_costs(
    game: &GameState,
    player: PlayerId,
    spell: &crate::object::Object,
    casting_method: &CastingMethod,
) -> crate::object::Object {
    let mut spell_with_optional_costs = spell.clone();
    for (source, optional) in
        optional_life_cost_reduction_costs_for_cast(game, player, spell.id, casting_method, None)
    {
        let label = optional_life_cost_reduction_label(&optional, source);
        if spell_with_optional_costs
            .optional_costs
            .iter()
            .any(|existing| existing.source_label == label)
        {
            continue;
        }
        spell_with_optional_costs
            .optional_costs
            .push(crate::cost::OptionalCost::custom(
                label,
                crate::cost::TotalCost::from_cost(crate::costs::Cost::life(optional.life_cost)),
            ));
    }
    spell_with_optional_costs
}

fn disturb_linked_face_matches_cost_filter(
    game: &GameState,
    caster: PlayerId,
    spell: &crate::object::Object,
    filter: &crate::target::ObjectFilter,
    ctx: &crate::target::FilterContext,
) -> bool {
    if !filter.subtypes.contains(&crate::types::Subtype::Aura) {
        return false;
    }
    let Some(view) = spell_view_for_disturb_cast(game, spell) else {
        return false;
    };
    filter.matches_non_recursive(&view, &ctx.clone().with_caster(Some(caster)), game)
}

pub(crate) fn spell_matches_cast_filter(
    game: &GameState,
    spell: &crate::object::Object,
    spell_filter: &crate::target::ObjectFilter,
) -> bool {
    spell_filter.matches(spell, &crate::target::FilterContext::default(), game)
}

pub(crate) fn snapshot_matches_cast_filter(
    game: &GameState,
    snapshot: &crate::snapshot::ObjectSnapshot,
    spell_filter: &crate::target::ObjectFilter,
) -> bool {
    spell_filter.matches_snapshot(snapshot, &crate::target::FilterContext::default(), game)
}

pub(crate) fn spells_cast_this_turn_matching_filter(
    game: &GameState,
    player: PlayerId,
    spell_filter: &crate::target::ObjectFilter,
) -> u32 {
    if spell_filter == &crate::target::ObjectFilter::default() {
        return game.turn_store.turn_history.spells_cast_by_player(player);
    }

    game.turn_store
        .turn_history
        .spell_cast_snapshot_history()
        .iter()
        .filter(|snapshot| {
            snapshot.controller == player
                && snapshot_matches_cast_filter(game, snapshot, spell_filter)
        })
        .count() as u32
}

pub(crate) fn violates_cast_limit(
    game: &GameState,
    player: PlayerId,
    spell: &crate::object::Object,
    spell_filter: &crate::target::ObjectFilter,
) -> bool {
    spell_matches_cast_filter(game, spell, spell_filter)
        && spells_cast_this_turn_matching_filter(game, player, spell_filter) >= 1
}

pub(crate) fn violates_any_cast_limit(
    game: &GameState,
    player: PlayerId,
    spell: &crate::object::Object,
) -> bool {
    let cant = &game.effect_store.cant_effects;
    cant.cast_limit_filters_for_player(player)
        .is_some_and(|filters| {
            filters
                .iter()
                .any(|spell_filter| violates_cast_limit(game, player, spell, spell_filter))
        })
        || cant
            .counted_cast_limits_for_player(player)
            .is_some_and(|limits| {
                limits.iter().any(|(spell_filter, maximum)| {
                    spell_matches_cast_filter(game, spell, spell_filter)
                        && spells_cast_this_turn_matching_filter(game, player, spell_filter)
                            >= *maximum
                })
            })
}

pub(crate) fn violates_any_cant_cast_restriction(
    game: &GameState,
    player: PlayerId,
    spell: &crate::object::Object,
) -> bool {
    violates_any_cant_cast_restriction_from_other_sources(game, player, spell, None)
}

/// As [`violates_any_cant_cast_restriction`], ignoring prohibitions that one
/// object imposes on itself.
///
/// CR 601.2a puts a spell on the stack before the rest of its announcement, so
/// a spell whose own stack-zone ability prohibits casting spells — split second
/// (CR 702.61b) is the printed case — is already restricting the game when
/// CR 601.2e revalidates its completed proposal. That prohibition governs
/// *beginning* to cast a spell, which this spell did legally, so it cannot
/// retroactively invalidate the announcement that created it.
pub(crate) fn violates_any_cant_cast_restriction_from_other_sources(
    game: &GameState,
    player: PlayerId,
    spell: &crate::object::Object,
    ignore_source: Option<ObjectId>,
) -> bool {
    // "... plays with that card revealed in their hand and can't play it"
    // (Firestorm Phoenix): that exact hand card.
    if game.hand_card_cant_be_played_until_owners_next_turn(spell.id) {
        return true;
    }
    let Some(filters) = game
        .effect_store
        .cant_effects
        .cast_filters_for_player(player)
    else {
        return false;
    };
    // Restrictions describe the spell being proposed, regardless of its origin
    // zone or casting permission (normal, flashback, escape, granted casts, ...).
    // Keep the real object in its origin zone until casting actually begins.
    let prospective;
    let spell = if spell.zone != Zone::Stack {
        prospective = {
            let mut proposal = spell.clone();
            proposal.zone = Zone::Stack;
            proposal
        };
        &prospective
    } else {
        spell
    };
    // CR 601.3e / 709.3a / 715.3a / 718.3a: when the proposal uses alternative
    // characteristics (a split half, an Adventure, a prototype...), only those
    // characteristics are evaluated, not the live card's calculated ones.
    let alternative_snapshot = game
        .object(spell.id)
        .is_some_and(|live| {
            live.name != spell.name
                || live.card_types != spell.card_types
                || live.subtypes != spell.subtypes
                || live.mana_cost != spell.mana_cost
                || live.color_override != spell.color_override
                || live.base_power != spell.base_power
                || live.base_toughness != spell.base_toughness
        })
        .then(|| crate::snapshot::ObjectSnapshot::from_object(spell, game));
    filters.iter().any(|restriction| {
        if ignore_source.is_some() && restriction.source == ignore_source {
            return false;
        }
        let mut ctx = game
            .filter_context_for_combat(
                restriction.controller.unwrap_or(player),
                restriction.source,
                None,
                None,
            )
            .with_caster(Some(player))
            .with_iterated_player(restriction.iterated_player.or(Some(player)))
            .with_tagged_objects(&restriction.tagged_objects)
            .with_prospective_cast(spell.id);
        if let Some(source) = restriction.source {
            ctx = with_source_exiled_tagged_objects(game, ctx.with_source(source), source);
        }
        ctx.source_number_owner=restriction.source_number_owner.clone();
        match alternative_snapshot.as_ref() {
            Some(snapshot) => restriction.filter.matches_snapshot(snapshot, &ctx, game),
            None => restriction.filter.matches(spell, &ctx, game),
        }
    })
}

fn optional_cost_selection_subsets(
    optional_costs: &[crate::cost::OptionalCost],
) -> Vec<Vec<usize>> {
    fn visit(
        index: usize,
        len: usize,
        selected: &mut Vec<usize>,
        selections: &mut Vec<Vec<usize>>,
    ) {
        if index == len {
            selections.push(selected.clone());
            return;
        }

        visit(index + 1, len, selected, selections);
        selected.push(index);
        visit(index + 1, len, selected, selections);
        selected.pop();
    }

    let mut selections = Vec::new();
    visit(0, optional_costs.len(), &mut Vec::new(), &mut selections);
    selections
}

fn optional_cost_and_fragment_proposals(spell:&crate::object::Object)->Vec<(Vec<usize>,Option<(usize,u64)>)>{
    let plan=crate::continuous::optional_text_fragments::declared_plan(spell).filter(|plan|plan.validate().is_ok());
    let mut proposals=Vec::new();
    for selected in optional_cost_selection_subsets(&spell.optional_costs){
        if let Some(plan)=&plan && let Some(index)=plan.casting_payment {
            for variant in &plan.variants{
                let count=variant.removed.count_ones();
                if selected.contains(&index)!=(count>0){continue}
                let mut repeated=selected.iter().copied().filter(|other|*other!=index).collect::<Vec<_>>();
                repeated.extend(std::iter::repeat_n(index,count as usize));
                proposals.push((repeated,Some((index,variant.removed))));
            }
        }else{proposals.push((selected,None));}
    }
    proposals
}

/// Visit complete CR 601.2 proposals formed by the joint yes/no choices for
/// optional costs. Ordinary repeatable costs need only zero- and one-payment
/// hypotheses here: the legality predicates tested before casting begins are
/// sensitive to whether that cost was paid, while the transaction records its
/// exact announced count later. Fragment plans instead enumerate every typed
/// subset with its minimum payment count, since target legality can differ.
fn any_payable_optional_cost_proposal<F>(
    game: &GameState,
    player: PlayerId,
    spell: &crate::object::Object,
    base_mana_cost: Option<&crate::mana::ManaCost>,
    casting_method: &CastingMethod,
    mut predicate: F,
) -> bool
where
    F: FnMut(
        &GameState,
        &crate::object::Object,
        Option<&crate::mana::ManaCost>,
        &DerivedGameView<'_>,
    ) -> bool,
{
    let mut priced_spell=spell.clone();
    if let Some(prices)=crate::granted_spell_keywords::optional_cost_payment_alternatives(game,spell.id,player){priced_spell.optional_costs=prices.into();}
    let spell=&priced_spell;
    for (selected,fragment_choice) in optional_cost_and_fragment_proposals(spell) {
        let mut selections=vec![Vec::new()];
        for index in &selected {
            let count=spell.optional_costs[*index].cost.as_one_of().map_or(1,|branches|branches.len());
            selections=selections.into_iter().flat_map(|selection| (0..count).map(move |branch|{let mut next=selection.clone();next.push(branch);next})).collect();
        }
        for branches in selections {
        let selected_costs=selected.iter().zip(&branches).map(|(index,branch)|crate::cost::optional_cost_payment_branch(&spell.optional_costs[*index].cost,Some(*branch))).collect::<Vec<_>>();
        let joint_non_mana=crate::cost::TotalCost::from_costs(selected_costs.iter().flat_map(|cost|cost.non_mana_costs().cloned()).collect());
        if crate::cost::can_pay_cost_with_reason(game,spell.id,player,&joint_non_mana,crate::costs::PaymentReason::CastSpell).is_err(){continue;}
        if selected_costs.iter().any(|cost| {
            crate::cost::can_pay_cost_with_reason(
                game,
                spell.id,
                player,
                cost,
                crate::costs::PaymentReason::CastSpell,
            )
            .is_err()
        }) {
            continue;
        }

        let mut hypothetical_storage = (!selected.is_empty() || fragment_choice.is_some()).then(|| game.clone());
        if let Some(hypothetical) = hypothetical_storage.as_mut()
            && let Some(hypothetical_spell) = hypothetical.object_mut(spell.id)
        {
            hypothetical_spell.optional_costs=spell.optional_costs.clone();
            hypothetical_spell.optional_costs_paid =
                crate::cost::OptionalCostsPaid::from_costs(&hypothetical_spell.optional_costs);
            for (&index,&branch) in selected.iter().zip(&branches) {
                let occurrence=hypothetical_spell.optional_costs_paid.times_paid(index);
                hypothetical_spell.optional_costs_paid.pay_times(index,1);
                hypothetical_spell.optional_costs_paid.set_payment_branch_choice(index,occurrence,branch);
            }
            if let Some((index,mask))=fragment_choice{hypothetical_spell.optional_costs_paid.set_text_fragment_choice(index,mask);}
        }
        if let Some(hypothetical) = hypothetical_storage.as_mut() {
            if let Err(error) = hypothetical.refresh_continuous_state() {
                game.record_token_resource_failure(&crate::effects::ExecutionError::ContinuousDiscovery(error));
                return false;
            }
        }
        let hypothetical = hypothetical_storage.as_ref().unwrap_or(game);

        let mut proposal = spell.clone();
        proposal.zone = Zone::Stack;
        proposal.optional_costs_paid =
            crate::cost::OptionalCostsPaid::from_costs(&proposal.optional_costs);
        for (&index,&branch) in selected.iter().zip(&branches) {
            let occurrence=proposal.optional_costs_paid.times_paid(index);
            proposal.optional_costs_paid.pay_times(index,1);
            proposal.optional_costs_paid.set_payment_branch_choice(index,occurrence,branch);
        }
        if let Some((index,mask))=fragment_choice{proposal.optional_costs_paid.set_text_fragment_choice(index,mask);}

        let mut combined = base_mana_cost.cloned().unwrap_or_default();
        for cost in &selected_costs {
            if let Some(optional_mana_cost) = cost.mana_cost() {
                combined = add_mana_cost(&combined, optional_mana_cost);
            }
        }
        let combined_cost = (!combined.is_empty()).then_some(combined);
        let hypothetical_view = DerivedGameView::new(hypothetical);
        let mut unreduced_effective_cost = None;
        let effective_cost = combined_cost.as_ref().map(|cost| {
            let effective = calculate_effective_mana_cost_with_view_for_casting_method(
                hypothetical,
                player,
                &proposal,
                cost,
                casting_method,
                &hypothetical_view,
            );
            unreduced_effective_cost = Some(effective.clone());
            // Target/restriction preflight also checks affordability. It must
            // account for the sacrifices offered by this announced optional
            // cost subset, before a full-price rejection hides the spell.
            let mut reduction = max_cost_payment_sacrifice_reduction_for_selection(
                hypothetical, player, &proposal, true,
            );
            // CR 702.180a, 702.119a: the stack-zoned proposal skips the
            // resource preview, so add the best tap or sacrifice reduction here.
            if spell.zone != Zone::Stack
                && let Some(method) = alternative_method_for_casting_method(game, player, spell, casting_method)
            {
                if method.can_tap_creature_for_power_reduction() {
                    reduction += get_convoke_creatures(game, player)
                        .iter()
                        .map(|(id, _)| game.current_power(*id).unwrap_or(0).max(0) as u32)
                        .max()
                        .unwrap_or(0);
                } else {
                    reduction += maximum_emerge_reduction(game, player, spell.id, &method);
                }
            }
            apply_minimum_spell_total_mana_with_view(
                &hypothetical_view, &effective.reduce_generic(reduction),
            )
        });
        let max_x = effective_cost
            .as_ref()
            .filter(|cost| cost.has_x())
            .map(|cost| {
                let potential = hypothetical_view.potential_mana(player);
                let mana_spend_policy = crate::alternative_cast::play_permission::casting_spend_policy(hypothetical, player, &proposal, casting_method);
                let allow_black_life = mana_cost_has_black_symbol(cost)
                    && hypothetical_view.player_can_pay_black_with_life_for_reason(
                        player,
                        crate::costs::PaymentReason::CastSpell,
                    );
                let caster_only = potential.max_x_for_cost_with_mana_spend_policy_and_black_life(
                    cost,
                    &mana_spend_policy,
                    allow_black_life,
                );
                max_x_payable_with_payment_resources(hypothetical, player, proposal.id, cost)
                    .unwrap_or(caster_only)
            })
            .unwrap_or(0);

        for x_value in 0..=max_x {
            if effective_cost.as_ref().is_some_and(|cost| {
                !payment_characteristic_preview::can_pay_scoped_tap(
                    hypothetical, player, &proposal, casting_method,
                    unreduced_effective_cost.as_ref().unwrap_or(cost), true, x_value,
                ).unwrap_or_else(|| mana_cost_can_be_paid_by_caster_or_assist_with_view_at_x(
                    hypothetical,
                    player,
                    spell.id,
                    cost,
                    x_value,
                    &hypothetical_view,
                    Some((&proposal, casting_method)),
                ))
            }) {
                continue;
            }

            if !effective_cost.as_ref().is_some_and(|cost| cost.has_x()) {
                if predicate(
                    hypothetical,
                    &proposal,
                    effective_cost.as_ref(),
                    &hypothetical_view,
                ) {
                    return true;
                }
                continue;
            }

            let mut x_game = hypothetical.clone();
            let mut x_proposal = proposal.clone();
            x_proposal.x_value = Some(x_value);
            if let Some(game_spell) = x_game.object_mut(spell.id) {
                game_spell.x_value = Some(x_value);
            }
            if let Err(error) = x_game.refresh_continuous_state() {
                game.record_token_resource_failure(&crate::effects::ExecutionError::ContinuousDiscovery(error));
                return false;
            }
            let x_view = DerivedGameView::new(&x_game);
            if predicate(&x_game, &x_proposal, effective_cost.as_ref(), &x_view) {
                return true;
            }
        }
        }
    }

    false
}

/// CR 601.3a allows casting to begin when any later announcement can make the
/// completed proposal escape a prohibition. Test optional costs jointly and X
/// at every payable value against the spell as it would exist on the stack.
fn every_payable_proposal_violates_cant_cast(
    game: &GameState,
    player: PlayerId,
    spell: &crate::object::Object,
    mana_cost: Option<&crate::mana::ManaCost>,
    casting_method: &CastingMethod,
) -> bool {
    if !violates_any_cant_cast_restriction(game, player, spell) {
        return false;
    }

    !any_payable_optional_cost_proposal(
        game,
        player,
        spell,
        mana_cost,
        casting_method,
        |hypothetical, proposal, _effective_cost, _hypothetical_view| {
            !violates_any_cant_cast_restriction(hypothetical, player, proposal)
        },
    )
}

pub(crate) fn is_sorcery_speed_spell(spell: &crate::object::Object) -> bool {
    use crate::types::CardType;

    // CR 709.3a: only the split half being cast is evaluated, so timing reads
    // the shown half's own types, not both halves' combined types (CR 709.4).
    // A fused split spell's view already carries both halves' types.
    let has_card_type = |card_type: CardType| spell.card_types.contains(&card_type);
    has_card_type(CardType::Sorcery)
        || has_card_type(CardType::Creature)
        || has_card_type(CardType::Artifact)
        || has_card_type(CardType::Enchantment)
        || has_card_type(CardType::Planeswalker)
        // CR 310.1 / 307.1: battles are permanent spells cast at sorcery speed.
        || has_card_type(CardType::Battle)
}

/// CR 709.3a: when a split card is cast, only the chosen half is evaluated to
/// see whether it can be cast, so cast-legality views drop the combined
/// characteristics a split card has in other zones (CR 709.4). A fused split
/// spell keeps both halves (CR 709.4d); its view is built separately.
fn without_combined_split_characteristics(
    view: Option<crate::object::Object>,
    spell: &crate::object::Object,
    casting_method: &CastingMethod,
) -> Option<crate::object::Object> {
    if matches!(casting_method.origin_method(), CastingMethod::Fuse) {
        return view;
    }
    match view {
        Some(mut view) => {
            view.split_combined = None;
            Some(view)
        }
        None if spell.split_combined.is_some() => {
            let mut view = spell.clone();
            view.split_combined = None;
            Some(view)
        }
        None => None,
    }
}

pub(crate) fn spell_has_active_flash_with_view(
    game: &GameState,
    player: PlayerId,
    spell: &crate::object::Object,
    spell_id: ObjectId,
    view: &DerivedGameView<'_>,
) -> bool {
    spell.abilities.iter().any(|a| {
        if let crate::ability::AbilityKind::Static(s) = &a.kind {
            if let Some(condition) = s.conditional_flash_condition() {
                return crate::condition_eval::evaluate_condition_cast_time(
                    game, condition, player, spell_id,
                );
            }
            if s.has_flash() {
                return true;
            }
            if s.keyword_marker_mechanic() == Some(ironsmith_core::KeywordMarkerMechanic::CastAtInstantTiming)
                && a.functions_in(&spell.zone) && s.is_active(game, spell_id)
            {
                return true;
            }
            // "This spell has flash as long as ..." compiled as a conditional
            // grant of flash to the spell itself (CR 601.3d).
            if let Some(ironsmith_core::StaticAbilityPayload::GrantObjectAbilityForFilter(grant)) =
                s.compiled_model().map(|model| &model.payload)
                && grant.filter.source
                && matches!(
                    &crate::static_abilities::StaticAbilityModelInterpreter::ability_from_model(&grant.ability).kind,
                    crate::ability::AbilityKind::Static(granted) if granted.has_flash()
                )
            {
                return grant.condition.as_ref().is_none_or(|condition| {
                    crate::condition_eval::evaluate_condition_cast_time(
                        game, condition, player, spell_id,
                    )
                });
            }
            if let Some(spec) = s.conditional_spell_keyword_spec()
                && spec.keyword == crate::static_abilities::ConditionalSpellKeywordKind::Flash
            {
                return crate::static_abilities::conditional_spell_keyword_active(
                    spec, game, player,
                );
            }
        }
        false
    }) || {
        // A zone-limited card grant checks the captured origin. A spell-wide
        // timing grant checks the chosen prospective face on the stack. Neither
        // grants permission to cast from that origin, and a front face cannot
        // lend its characteristics to a different face being cast.
        let origin = if spell.zone == Zone::Stack {
            game.cast_origin_snapshot(spell_id)
                .map_or(Zone::Stack, |snapshot| snapshot.zone)
        } else {
            spell.zone
        };
        let mut origin_card = spell.clone();
        origin_card.zone = origin;
        let mut prospective_spell = spell.clone();
        prospective_spell.zone = Zone::Stack;
        view.card_view_has_granted_static_ability_id(
            spell_id,
            &origin_card,
            origin,
            player,
            crate::static_abilities::StaticAbilityId::Flash,
        ) || view.card_view_has_granted_static_ability_id(
            spell_id,
            &prospective_spell,
            Zone::Stack,
            player,
            crate::static_abilities::StaticAbilityId::Flash,
        )
    }
}

pub(crate) fn player_was_attacked_this_step(game: &GameState, player: PlayerId) -> bool {
    use crate::game_state::{Phase, Step};

    if !matches!(game.turn.phase, Phase::Combat) || game.turn.step != Some(Step::DeclareAttackers) {
        return false;
    }

    // Past declaration evidence survives attacker removal but is cleared at
    // the next declaration-step entry, even inside this same combat phase.
    game.combat.as_ref()
        .and_then(|combat| combat.last_attack_declaration_step_players.as_ref())
        .is_some_and(|defenders| defenders.contains(&player))
}

pub(crate) fn this_spell_cast_restriction_allows(
    game: &GameState,
    player: PlayerId,
    kind: &crate::static_abilities::ThisSpellCastRestrictionKind,
) -> bool {
    let timing_allows = kind
        .timing
        .is_none_or(|timing| this_spell_cast_timing_allows(game, player, timing));
    if !timing_allows {
        return false;
    }
    kind.condition
        .as_ref()
        .is_none_or(|condition| this_spell_cast_condition_allows(game, player, condition))
}

pub(crate) fn this_spell_cast_timing_allows(
    game: &GameState,
    player: PlayerId,
    timing: crate::static_abilities::ThisSpellCastTiming,
) -> bool {
    use crate::game_state::{Phase, Step};
    use crate::static_abilities::ThisSpellCastTiming;

    let opponents_turn = game
        .turn_players()
        .into_iter()
        .any(|active| game.are_opponents(player, active));
    match timing {
        ThisSpellCastTiming::DuringDeclareBlockersStep => {
            matches!(game.turn.phase, Phase::Combat)
                && game.turn.step == Some(Step::DeclareBlockers)
                && game
                    .combat
                    .as_ref()
                    .is_some_and(|combat| combat.block_declaration_complete)
        }
        ThisSpellCastTiming::DuringCombatOnYourTurn => {
            game.is_active_player(player) && matches!(game.turn.phase, Phase::Combat)
        }
        ThisSpellCastTiming::DuringYourTurn => game.is_active_player(player),
        ThisSpellCastTiming::DuringOpponentsTurn => opponents_turn,
        // Count the caster's own turns taken, including the current one.
        ThisSpellCastTiming::NotDuringYourFirstTurns(count) => {
            !(game.is_active_player(player) && game.turns_taken_by(player) <= count)
        }
        ThisSpellCastTiming::DuringDeclareAttackersStep => {
            matches!(game.turn.phase, Phase::Combat)
                && game.turn.step == Some(Step::DeclareAttackers)
        }
        ThisSpellCastTiming::DuringCombat => matches!(game.turn.phase, Phase::Combat),
        ThisSpellCastTiming::DuringCombatBeforeBlockersAreDeclared => {
            matches!(game.turn.phase, Phase::Combat)
                && matches!(
                    game.turn.step,
                    Some(Step::BeginCombat | Step::DeclareAttackers)
                )
        }
        ThisSpellCastTiming::DuringCombatAfterBlockersAreDeclared => {
            game.combat
                .as_ref()
                .is_some_and(|combat| combat.block_declaration_complete)
                && matches!(game.turn.phase, Phase::Combat)
                && matches!(
                    game.turn.step,
                    Some(Step::DeclareBlockers | Step::CombatDamage | Step::EndCombat)
                )
        }
        ThisSpellCastTiming::DuringCombatOnYourTurnBeforeBlockersAreDeclared => {
            game.is_active_player(player)
                && matches!(game.turn.phase, Phase::Combat)
                && matches!(
                    game.turn.step,
                    Some(Step::BeginCombat | Step::DeclareAttackers)
                )
        }
        ThisSpellCastTiming::DuringCombatOnOpponentsTurn => {
            opponents_turn && matches!(game.turn.phase, Phase::Combat)
        }
        // CR 506.8a / 506.8d: before the declare attackers step of the
        // turn's first combat phase begins.
        ThisSpellCastTiming::BeforeAttackersAreDeclared => {
            crate::decision::legal_actions::turn_is_before_first_combat_step(
                game,
                Step::DeclareAttackers,
            )
        }
        // Any time earlier in the turn than its first combat damage step: the
        // beginning phase, the precombat main phase, or combat before damage.
        ThisSpellCastTiming::BeforeCombatDamageStep => {
            crate::decision::legal_actions::turn_is_before_first_combat_step(
                game,
                Step::CombatDamage,
            )
        }
        ThisSpellCastTiming::DuringOpponentsUpkeep => {
            opponents_turn
                && matches!(game.turn.phase, Phase::Beginning)
                && game.turn.step == Some(Step::Upkeep)
        }
        ThisSpellCastTiming::DuringOpponentsTurnAfterUpkeep => {
            if !opponents_turn {
                return false;
            }
            // CR 503.2: with several upkeep steps, any time after the first
            // upkeep step ends, including during a later upkeep step.
            match (game.turn.phase, game.turn.step) {
                (Phase::Beginning, Some(Step::Untap)) => false,
                (Phase::Beginning, Some(Step::Upkeep)) => {
                    game.turn_store.upkeep_steps_started_this_turn > 1
                }
                _ => true,
            }
        }
        ThisSpellCastTiming::DuringYourEndStep => {
            game.is_active_player(player)
                && matches!(game.turn.phase, Phase::Ending)
                && game.turn.step == Some(Step::End)
        }
        ThisSpellCastTiming::AfterCombat => {
            matches!(game.turn.phase, Phase::NextMain | Phase::Ending)
        }
        // CR 506.8b / 506.8d: before the first combat's declare blockers step.
        ThisSpellCastTiming::BeforeBlockersAreDeclared => {
            crate::decision::legal_actions::turn_is_before_first_combat_step(
                game,
                Step::DeclareBlockers,
            )
        }
        ThisSpellCastTiming::DuringYourDeclareAttackersStep => {
            game.is_active_player(player)
                && matches!(game.turn.phase, Phase::Combat)
                && game.turn.step == Some(Step::DeclareAttackers)
        }
        ThisSpellCastTiming::DuringDeclareBlockersStepOnOpponentsTurn => {
            opponents_turn
                && matches!(game.turn.phase, Phase::Combat)
                && game.turn.step == Some(Step::DeclareBlockers)
                && game
                    .combat
                    .as_ref()
                    .is_some_and(|combat| combat.block_declaration_complete)
        }
        ThisSpellCastTiming::DuringOpponentsTurnBeforeAttackersAreDeclared => {
            opponents_turn
                && match game.turn.phase {
                    Phase::Beginning | Phase::FirstMain => true,
                    Phase::Combat => game.turn.step == Some(Step::BeginCombat),
                    Phase::NextMain | Phase::Ending => false,
                }
        }
    }
}

pub(crate) fn players_matching_cast_restriction_filter(
    game: &GameState,
    player: PlayerId,
    filter: &crate::target::PlayerFilter,
) -> Vec<PlayerId> {
    let filter_ctx = game.filter_context_for(player, None);
    match filter {
        crate::target::PlayerFilter::You => vec![player],
        crate::target::PlayerFilter::Opponent => filter_ctx.opponents.clone(),
        crate::target::PlayerFilter::Teammate => filter_ctx.teammates.clone(),
        crate::target::PlayerFilter::Specific(id) => vec![*id],
        crate::target::PlayerFilter::Any => game
            .players
            .iter()
            .filter(|candidate| candidate.is_in_game())
            .map(|candidate| candidate.id)
            .collect(),
        crate::target::PlayerFilter::NotYou => game
            .players
            .iter()
            .filter_map(|candidate| {
                (candidate.is_in_game() && candidate.id != player).then_some(candidate.id)
            })
            .collect(),
        _ => Vec::new(),
    }
}

pub(crate) fn this_spell_cast_condition_allows(
    game: &GameState,
    player: PlayerId,
    condition: &crate::static_abilities::ThisSpellCastCondition,
) -> bool {
    match condition {
        crate::static_abilities::ThisSpellCastCondition::YouWereAttackedThisStep => {
            player_was_attacked_this_step(game, player)
        }
        crate::static_abilities::ThisSpellCastCondition::PlayerCastSpellThisTurnOrMore {
            player: player_filter,
            spell_filter,
            count,
        } => players_matching_cast_restriction_filter(game, player, player_filter)
            .into_iter()
            .map(|matched_player| {
                spells_cast_this_turn_matching_filter(game, matched_player, spell_filter)
            })
            .sum::<u32>()
            >= *count,
        crate::static_abilities::ThisSpellCastCondition::CreatureIsAttackingYou => {
            // Present-tense permission must not inherit retained attack history.
            game.combat.as_ref().is_some_and(|combat| {
                combat.attackers.iter().any(|attacker| match attacker.target {
                    crate::combat_state::AttackTarget::Player(defender) => defender == player,
                    crate::combat_state::AttackTarget::Planeswalker(planeswalker_id) => game
                        .object(planeswalker_id)
                        .is_some_and(|planeswalker| game.controller_of(planeswalker) == player),
                    crate::combat_state::AttackTarget::Battle(battle_id) => {
                        game.battle_protector(battle_id) == Some(player)
                    }
                    // CR 506.4c: it isn't attacking anything.
                    crate::combat_state::AttackTarget::Nothing { .. } => false,
                })
            })
        }
        crate::static_abilities::ThisSpellCastCondition::CreatureDiedThisTurn => {
            game.turn_store.turn_history.total_creatures_died_this_turn() > 0
        }
        crate::static_abilities::ThisSpellCastCondition::NoPermanentsNamedOnBattlefield(name) => {
            !game.battlefield.iter().any(|&id| {
                game.object(id)
                    .is_some_and(|object| object.name.eq_ignore_ascii_case(name))
            })
        }
        crate::static_abilities::ThisSpellCastCondition::YouControlAtLeast { filter, count } => {
            let mut required_filter = filter.clone();
            required_filter.zone = Some(Zone::Battlefield);
            let filter_ctx = game.filter_context_for(player, None);
            game.battlefield
                .iter()
                .filter_map(|&id| game.object(id))
                .filter(|object| {
                    game.controller_of(object) == player
                        && required_filter.matches(object, &filter_ctx, game)
                })
                .count()
                >= *count as usize
        }
        // Evaluated by `spell_cast_restrictions_allow`, which knows the spell.
        crate::static_abilities::ThisSpellCastCondition::Condition(_) => true,
        crate::static_abilities::ThisSpellCastCondition::YouControlFewerCreaturesThanEachOpponent => {
            let your_creatures = game.creatures_controlled_by(player).len();
            game.players
                .iter()
                .filter(|opponent| opponent.is_in_game() && opponent.id != player)
                .all(|opponent| your_creatures < game.creatures_controlled_by(opponent.id).len())
        }
        crate::static_abilities::ThisSpellCastCondition::YouControlNameWordOrMore {
            word,
            count,
        } => game
            .permanents_controlled_by(player)
            .iter()
            .filter(|id| {
                game.object(**id).is_some_and(|object| {
                    object
                        .name
                        .to_ascii_lowercase()
                        .contains(&word.to_ascii_lowercase())
                })
            })
            .count()
            >= *count as usize,
    }
}

pub(crate) fn spell_cast_restrictions_allow(
    game: &GameState,
    player: PlayerId,
    spell: &crate::object::Object,
) -> bool {
    legendary_spell_cast_restriction_allows(game, player, spell)
        && spell.abilities.iter().all(|ability| {
            let crate::ability::AbilityKind::Static(static_ability) = &ability.kind else {
                return true;
            };
            let Some(kind) = static_ability.this_spell_cast_restriction_kind() else {
                return true;
            };
            // "You may cast this card from your graveyard, but not from
            // anywhere else" (Haakon): where the card is cast from is checked
            // at the proposal, against the zone the card is in (CR 601.3e),
            // never against the stack it is moving to.
            if let Some(crate::static_abilities::ThisSpellCastCondition::Condition(
                ironsmith_core::Condition::SourceIsInZone(zone),
            )) = &kind.condition
            {
                return kind
                    .timing
                    .is_none_or(|timing| this_spell_cast_timing_allows(game, player, timing))
                    && spell.zone == *zone;
            }
            // A typed condition reads the spell itself as its source.
            if let Some(crate::static_abilities::ThisSpellCastCondition::Condition(condition)) =
                &kind.condition
            {
                return kind
                    .timing
                    .is_none_or(|timing| this_spell_cast_timing_allows(game, player, timing))
                    && crate::condition_eval::evaluate_condition_cast_time(
                        game, condition, player, spell.id,
                    );
            }
            this_spell_cast_restriction_allows(game, player, &kind)
        })
}

/// Values admitted by an exact text definition of X. A count mentioning an
/// opponent chooses one real opponent's count, never the interval between them.
pub(crate) fn spell_defined_x_values(
    game: &GameState, player: PlayerId, spell: &crate::object::Object,
) -> Result<Option<Vec<u32>>, crate::effects::ExecutionError> {
    use crate::target::PlayerFilter;
    let ctx = ExecutionContext::new_default(spell.id, player);
    let mut admitted: Option<Vec<u32>> = None;
    for ability in spell.abilities.iter() {
        if !ability.functional_zones.contains(&Zone::Stack) { continue; }
        let crate::ability::AbilityKind::Static(rule) = &ability.kind else { continue; };
        let Some(value) = rule.this_spell_x_definition_value() else { continue; };
        let mut values = Vec::new();
        if let crate::effect::Value::Count(filter) = value.unhinted()
            && (filter.owner == Some(PlayerFilter::Opponent)
                || filter.controller == Some(PlayerFilter::Opponent))
        {
            for opponent in crate::effects::helpers::resolve_player_filter_to_list(game, &PlayerFilter::Opponent, &ctx.filter_context(game), &ctx)? {
                let mut specific = filter.clone();
                if specific.owner == Some(PlayerFilter::Opponent) { specific.owner = Some(PlayerFilter::Specific(opponent)); }
                if specific.controller == Some(PlayerFilter::Opponent) { specific.controller = Some(PlayerFilter::Specific(opponent)); }
                values.push(resolve_value(game, &crate::effect::Value::Count(specific), &ctx)?.max(0) as u32);
            }
        } else {
            values.push(resolve_value(game, &value, &ctx)?.max(0) as u32);
        }
        values.sort_unstable(); values.dedup();
        if let Some(previous) = &mut admitted { previous.retain(|value| values.contains(value)); }
        else { admitted = Some(values); }
    }
    Ok(admitted)
}

/// Whether a resulting spell can satisfy an effect's restriction with its
/// text-defined X. Preserve the selected face and the instruction's bindings.
pub(crate) fn spell_matches_requirement_with_defined_x(
    game: &GameState, caster: PlayerId, spell: &crate::object::Object,
    requirement: &crate::target::ObjectFilter, filter_ctx: &crate::filter::FilterContext,
) -> Result<Option<bool>, crate::effects::ExecutionError> {
    let Some(values) = spell_defined_x_values(game, caster, spell)? else { return Ok(None); };
    let mut snapshot = crate::snapshot::ObjectSnapshot::from_object(spell, game);
    snapshot.zone = Zone::Stack;
    snapshot.controller = caster;
    Ok(Some(values.into_iter().any(|value| {
        snapshot.x_value = Some(value);
        requirement.matches_snapshot(&snapshot, filter_ctx, game)
    })))
}

/// Check a forced printed-mana-cost X of zero on the proposed spell face.
/// The caller supplies a stack proposal, including its casting controller;
/// source-relative values must not inspect the physical card's exile face.
pub(crate) fn spell_x_minimum_allows_zero(
    game: &GameState,
    player: PlayerId,
    spell: &crate::object::Object,
) -> Result<bool, crate::effects::ExecutionError> {
    if let Some(values) = spell_defined_x_values(game, player, spell)? { return Ok(!values.is_empty()); }
    let ctx = ExecutionContext::new_default(spell.id, player).with_x(0);
    for ability in spell.abilities.iter() {
        if !ability.functional_zones.contains(&Zone::Stack) {
            continue;
        }
        let crate::ability::AbilityKind::Static(static_ability) = &ability.kind else {
            continue;
        };
        if let Some(minimum) = static_ability.this_spell_x_minimum_value()
            && resolve_value(game, &minimum, &ctx)? > 0
        {
            return Ok(false);
        }
    }
    Ok(true)
}

/// CR 205.4e: a player can't cast a legendary instant or sorcery spell unless
/// that player controls a legendary creature or a legendary planeswalker.
/// `spell` is the cast view, so a split/adventure half is checked by itself.
fn legendary_spell_cast_restriction_allows(
    game: &GameState,
    player: PlayerId,
    spell: &crate::object::Object,
) -> bool {
    use crate::types::Supertype;

    if !spell.has_supertype(Supertype::Legendary)
        || !(spell.has_card_type(CardType::Instant) || spell.has_card_type(CardType::Sorcery))
    {
        return true;
    }
    // CR 702.26b: a phased-out legend is treated as though it doesn't exist.
    game.battlefield.iter().any(|&id| {
        !game.is_phased_out(id)
            && game
                .object(id)
                .is_some_and(|object| game.controller_of(object) == player)
            && game.current_characteristics(id).is_some_and(|chars| {
                chars.supertypes.contains(&Supertype::Legendary)
                    && (chars.card_types.contains(&CardType::Creature)
                        || chars.card_types.contains(&CardType::Planeswalker))
            })
    })
}

pub(crate) fn has_valid_spell_timing(
    game: &GameState,
    player: PlayerId,
    spell: &crate::object::Object,
    spell_id: ObjectId,
) -> bool {
    let view = DerivedGameView::new(game);
    has_valid_spell_timing_with_view(game, player, spell, spell_id, &view)
}

/// Test the existential target condition against a proposed set of targets.
/// This is a cast permission, not a restriction on later resolution or retargeting.
pub(crate) fn target_dependent_flash_matches(
    game: &GameState,
    player: PlayerId,
    spell: &crate::object::Object,
    targets: &[crate::Target],
) -> bool {
    let context = game.filter_context_for(player, Some(spell.id));
    spell.abilities.iter().any(|ability| {
        let crate::ability::AbilityKind::Static(ability) = &ability.kind else {
            return false;
        };
        let Some(model) = ability.compiled_model() else {
            return false;
        };
        let ironsmith_core::StaticAbilityPayload::FlashIfTargetsMatching(filter) = &model.payload
        else {
            return false;
        };
        targets.iter().any(|target| match target {
            crate::Target::Object(id) => game
                .object(*id)
                .is_some_and(|object| filter.matches(object, &context, game)),
            crate::Target::Player(_) => false,
        })
    })
}

fn cast_choice_flash_permissions(
    spell: &crate::object::Object,
) -> Vec<ironsmith_core::FlashCastChoice> {
    spell
        .abilities
        .iter()
        .filter_map(|ability| {
            let crate::ability::AbilityKind::Static(ability) = &ability.kind else {
                return None;
            };
            match &ability.compiled_model()?.payload {
                ironsmith_core::StaticAbilityPayload::FlashIfCastChoice(choice) => {
                    Some(choice.clone())
                }
                _ => None,
            }
        })
        .collect()
}

/// "You may cast this spell as though it had flash if X is 3 or less" / "if
/// it's cast using teamwork": the decision is made during casting (CR
/// 601.2b-c), so casting may begin; the completed proposal is checked by
/// [`cast_choice_flash_matches`].
fn cast_choice_flash_can_begin(
    game: &GameState,
    player: PlayerId,
    spell: &crate::object::Object,
) -> bool {
    !game
        .effect_store
        .cant_effects
        .cast_spells_only_as_sorcery
        .contains(&player)
        && !cast_choice_flash_permissions(spell).is_empty()
}

/// Test a completed proposal's committed X and optional-cost choices against
/// its decision-dependent flash permissions.
pub(crate) fn cast_choice_flash_matches(spell: &crate::object::Object) -> bool {
    cast_choice_flash_permissions(spell)
        .iter()
        .any(|choice| match choice {
            ironsmith_core::FlashCastChoice::XAtMost(max) => {
                spell.x_value.unwrap_or(0) <= *max
            }
            ironsmith_core::FlashCastChoice::OptionalCostPaid(label) => {
                spell.optional_costs_paid.was_paid_label(label.clone())
            }
        })
}

fn target_dependent_flash_can_begin(
    game: &GameState,
    player: PlayerId,
    spell: &crate::object::Object,
) -> bool {
    if game
        .effect_store
        .cant_effects
        .cast_spells_only_as_sorcery
        .contains(&player)
    {
        return false;
    }
    // Avoid extracting target requirements for spells with no such permission.
    if !spell.abilities.iter().any(|ability| matches!(&ability.kind,
        crate::ability::AbilityKind::Static(ability) if ability.compiled_model().is_some_and(|model|
            matches!(model.payload, ironsmith_core::StaticAbilityPayload::FlashIfTargetsMatching(_))))) {
        return false;
    }
    let aura_program;
    let program = if let Some(program) = spell.spell_effect.as_deref() {
        program
    } else if spell.subtypes.contains(&crate::types::Subtype::Aura) {
        let Some(filter) = &spell.aura_attach_filter else {
            return false;
        };
        aura_program = crate::resolution::ResolutionProgram::from_effects(vec![
            crate::effect::Effect::attach_to(filter.target_spec()),
        ]);
        &aura_program
    } else {
        return false;
    };
    let requirements = crate::game_loop::extract_target_requirements_from_program_with_modes(
        game,
        program,
        player,
        Some(spell.id),
        None,
    );
    requirements.iter().any(|requirement| {
        target_dependent_flash_matches(game, player, spell, &requirement.legal_targets)
    })
}

pub(crate) fn has_valid_spell_timing_with_view(
    game: &GameState,
    player: PlayerId,
    spell: &crate::object::Object,
    spell_id: ObjectId,
    view: &DerivedGameView<'_>,
) -> bool {
    has_valid_spell_timing_without_target_permission(game, player, spell, spell_id, view)
        || target_dependent_flash_can_begin(game, player, spell)
        || cast_choice_flash_can_begin(game, player, spell)
}

pub(crate) fn has_valid_spell_timing_without_target_permission(
    game: &GameState,
    player: PlayerId,
    spell: &crate::object::Object,
    spell_id: ObjectId,
    view: &DerivedGameView<'_>,
) -> bool {
    if game
        .effect_store
        .cant_effects
        .cast_spells_only_as_sorcery
        .contains(&player)
    {
        return game.is_active_player(player) && crate::turn::is_sorcery_timing(game);
    }

    if !is_sorcery_speed_spell(spell)
        || spell_has_active_flash_with_view(game, player, spell, spell_id, view)
        || game.next_play_timing_allows(player, spell, false)
    {
        return true;
    }

    // Sorcery-speed spells require: active player, main phase, empty stack.
    game.is_active_player(player) && crate::turn::is_sorcery_timing(game)
}

fn casting_method_grants_flash_timing(
    game: &GameState,
    player: PlayerId,
    spell: &crate::object::Object,
    casting_method: &CastingMethod,
) -> bool {
    if matches!(casting_method, CastingMethod::ExactPermission { .. }) {
        return crate::alternative_cast::play_permission::receipt_or_latch(game, player, spell, casting_method)
            .is_some_and(|receipt| receipt.constraints.instant_timing);
    }
    if crate::alternative_cast::price_routes::receipt_or_latch(game, player, spell, casting_method)
        .is_some_and(|price| price.constraints.instant_timing)
    {
        return true;
    }
    let origin = casting_method.origin_method();
    if let CastingMethod::PlayFrom {
        source,
        zone,
        use_alternative: None,
    }
    | CastingMethod::SplitOtherHalfPlayFrom {
        source,
        zone,
        use_alternative: None,
    }
    | CastingMethod::FaceDownPlayFrom { source, zone } = origin
    {
        let constraints = if spell.zone == Zone::Stack {
            spell
                .cast_play_from_constraints
                .as_deref()
                .filter(|(captured_source, captured_zone, _)| {
                    captured_source == source && captured_zone == zone
                })
                .map(|(_, _, constraints)| constraints.clone())
        } else if matches!(casting_method.without_exact_permission(), CastingMethod::AlternativePrice { .. }) {
            crate::alternative_cast::price_routes::origin_constraints_or_latch(
                game,
                player,
                spell,
                casting_method,
            )
        } else {
            game.effect_store
                .grant_registry
                .selected_play_from_grant_for_card_view(
                    game,
                    spell.id,
                    Some(spell),
                    *zone,
                    player,
                    *source,
                )
                .map(|grant| grant.play_from_constraints)
        };
        if constraints.is_some_and(|constraints| constraints.instant_timing) {
            return true;
        }
    }
    let method = match origin {
        CastingMethod::Alternative(idx) => spell.alternative_casts.get(*idx).cloned(),
        CastingMethod::PlayFrom {
            zone,
            use_alternative: Some(idx),
            ..
        }
        | CastingMethod::SplitOtherHalfPlayFrom {
            zone,
            use_alternative: Some(idx),
            ..
        } => {
            crate::decision::resolve_play_from_alternative_method(game, player, spell, *zone, *idx)
                .or_else(|| spell.cast_alternative_method_owned())
        }
        _ => None,
    };
    // Legacy (pre-rebake) definitions still carry the alternative-cast form.
    matches!(
        method,
        Some(crate::alternative_cast::AlternativeCastingMethod::FlashWithAdditionalCost { .. })
    ) || method
        .as_ref()
        .is_some_and(|method| method.grants_instant_timing())
        || flash_timing_optional_cost_grants_timing(game, player, spell, casting_method)
}

/// "Cast this spell as though it had flash if you pay {N} more" (an optional
/// additional cost, CR 601.2f). Before the cast is proposed the permission is
/// available only when some complete proposal that announces that cost is
/// payable (CR 601.2f-h: the extra {N} is added to the total cost with every
/// other modifier); once the spell is on the stack, it holds only if that
/// cost was announced. As with Offering, the completed-proposal check (CR
/// 601.2e) cancels a cast that relied on flash timing without paying it.
fn flash_timing_optional_cost_grants_timing(
    game: &GameState,
    player: PlayerId,
    spell: &crate::object::Object,
    casting_method: &CastingMethod,
) -> bool {
    let mut flash_costs = spell
        .optional_costs
        .iter()
        .filter(|optional| optional.kind == ironsmith_core::OptionalCostKind::FlashTiming)
        .peekable();
    if flash_costs.peek().is_none() {
        return false;
    }
    if spell.zone == Zone::Stack {
        return flash_costs.any(|optional| {
            spell
                .optional_costs_paid
                .was_paid_label(optional.cost_ref())
        });
    }
    let flash_labels = flash_costs
        .map(|optional| optional.cost_ref())
        .collect::<Vec<_>>();
    let base_mana_cost = spell_mana_cost_for_cast(game, player, spell, casting_method, spell.zone);
    any_payable_optional_cost_proposal(
        game,
        player,
        spell,
        base_mana_cost.as_ref(),
        casting_method,
        |_hypothetical, proposal, _effective_cost, _hypothetical_view| {
            flash_labels
                .iter()
                .any(|label| proposal.optional_costs_paid.was_paid_label(label.clone()))
        },
    )
}

fn casting_method_grants_library_search_timing(
    game: &GameState,
    spell: &crate::object::Object,
    spell_id: ObjectId,
    casting_method: &CastingMethod,
) -> bool {
    matches!(
        casting_method.origin_method(),
        CastingMethod::PlayFrom {
            zone: Zone::Library,
            ..
        }
    ) && spell.zone == Zone::Library
        && game.current_has_static_ability_id(
            spell_id,
            crate::static_abilities::StaticAbilityId::CastThisCardFromLibraryWhileSearching,
        )
}

fn offering_grants_timing(
    game: &GameState,
    player: PlayerId,
    spell: &crate::object::Object,
) -> bool {
    spell.optional_costs.iter().any(|optional| {
        optional.kind.sacrifice_reduces_mana_cost_and_grants_timing()
            && (spell.zone != Zone::Stack
                || spell
                    .optional_costs_paid
                    .was_paid_label(optional.cost_ref()))
            && optional
                .cost
                .non_mana_costs()
                .all(|cost| can_pay_cost_with_spell_exclusion(game, player, cost, Some(spell.id)))
    })
}

fn casting_method_grants_special_timing(
    ctx: &CastLegalityContext<'_>,
    spell: &crate::object::Object,
    spell_id: ObjectId,
    casting_method: &CastingMethod,
) -> bool {
    // "Can cast spells only any time they could cast a sorcery" (Teferi, Time
    // Raveler) restricts the player; flash-like casting permissions don't
    // override it (CR 307.5, 601.3).
    if ctx
        .game
        .effect_store
        .cant_effects
        .cast_spells_only_as_sorcery
        .contains(&ctx.player)
    {
        return false;
    }
    offering_grants_timing(ctx.game, ctx.player, spell)
        || casting_method_grants_flash_timing(ctx.game, ctx.player, spell, casting_method)
        || casting_method_grants_sneak_timing(ctx.game, ctx.player, spell, casting_method)
        || (ctx.allow_library_search_cast_timing
            && casting_method_grants_library_search_timing(
                ctx.game,
                spell,
                spell_id,
                casting_method,
            ))
}

fn casting_method_grants_sneak_timing(
    game: &GameState,
    player: PlayerId,
    spell: &crate::object::Object,
    casting_method: &CastingMethod,
) -> bool {
    // Granted and exact zone permissions carry the same keyword timing as
    // a printed alternative cost. Resolve the selected method on all routes.
    let method = alternative_method_for_casting_method(game, player, spell, casting_method);
    let Some(method) = method else {
        return false;
    };
    method.returns_attacker_enters_attacking()
        && game.active_players().contains(&player)
        && matches!(game.turn.phase, Phase::Combat)
        && game.turn.step == Some(Step::DeclareBlockers)
}

pub(crate) fn face_down_cast_mana_cost() -> crate::mana::ManaCost {
    crate::mana::ManaCost::from_pips(vec![vec![crate::mana::ManaSymbol::Generic(3)]])
}

fn commander_tax_life_per_previous_cast(spell: &crate::object::Object) -> Option<u32> {
    spell.abilities.iter().find_map(|ability| {
        if !ability.functions_in(&Zone::Command) {
            return None;
        }
        let crate::ability::AbilityKind::Static(static_ability) = &ability.kind else {
            return None;
        };
        match &static_ability.compiled_model()?.payload {
            ironsmith_core::StaticAbilityPayload::CommanderTaxLifeSubstitution {
                life_per_previous_cast,
            } => Some(*life_per_previous_cast),
            _ => None,
        }
    })
}

pub(crate) fn commander_tax_life_payment_amount(
    game: &GameState,
    spell: &crate::object::Object,
    from_zone: Zone,
) -> u32 {
    if from_zone != Zone::Command {
        return 0;
    }
    commander_tax_life_per_previous_cast(spell)
        .unwrap_or(0)
        .saturating_mul(game.commander_cast_count(spell.id))
}

/// The face-down cast kind (morph, megamorph, disguise) `spell` may be cast
/// with (CR 702.37a, 702.168a).
///
/// In hidden-information matches the face-down cast command carries the kind
/// publicly and every peer records it before replaying the command
/// ([`GameState::set_hidden_face_down_cast_claim`]); that claim wins, so peers
/// that hold only a hidden-card placeholder agree with the caster. Peers
/// holding a placeholder check the claim against the card once it is opened.
///
/// Without a printed keyword, an effect's face-down cast permission covering
/// the card allows the cast as [`crate::game_state::FaceDownCastKind::Permission`]
/// (see [`crate::game_state::FaceDownCastPermission`]).
pub fn face_down_cast_kind(
    game: &GameState,
    spell: &crate::object::Object,
) -> Option<crate::game_state::FaceDownCastKind> {
    game.hidden_face_down_cast_claim(spell.id)
        .or_else(|| crate::game_state::FaceDownCastKind::of_abilities(&spell.abilities))
        .or_else(|| {
            game.face_down_cast_permission_source_for(spell)
                .map(|source| crate::game_state::FaceDownCastKind::Permission { source })
        })
}

pub(crate) fn spell_can_be_cast_face_down(game: &GameState, spell: &crate::object::Object) -> bool {
    face_down_cast_kind(game, spell).is_some()
}

/// Resolve the mana cost for a spell cast from a specific zone and method.
pub fn spell_mana_cost_for_cast(
    game: &GameState,
    player: PlayerId,
    spell: &crate::object::Object,
    casting_method: &CastingMethod,
    from_zone: Zone,
) -> Option<crate::mana::ManaCost> {
    if matches!(casting_method, CastingMethod::ExactPermission { .. })
        && let Err(error) = crate::alternative_cast::blind_play::admit_pre_stack_method(game, spell.id, player, casting_method) {
        game.record_token_resource_failure(&error);
        return None;
    }
    // CR 708: the face-down spell has no printed additional costs. Callers
    // may still supply the private origin card while previewing its price.
    let face_down_view = matches!(casting_method.origin_method(),
        CastingMethod::FaceDown | CastingMethod::FaceDownPlayFrom { .. })
        .then(|| spell_view_for_face_down_cast(game, spell));
    let spell = face_down_view.as_ref().unwrap_or(spell);
    let base_cost = match casting_method.without_exact_permission() {
        CastingMethod::ExactPermission { .. } => {
            game.record_token_resource_failure(&crate::effects::ExecutionError::IncompleteEvidence("nested exact permission is not a casting method".into()));
            None
        }
        CastingMethod::AlternativePrice { .. } => {
            let price = crate::alternative_cast::price_routes::receipt_or_latch(
                game,
                player,
                spell,
                casting_method,
            )?;
            Some(crate::alternative_cast::price_routes::mana_cost(&price))
        }
        CastingMethod::Normal => spell.mana_cost_owned(),
        CastingMethod::FaceDown | CastingMethod::FaceDownPlayFrom { .. } => {
            Some(face_down_cast_mana_cost())
        }
        CastingMethod::SplitOtherHalf
        | CastingMethod::SplitOtherHalfPlayFrom {
            use_alternative: None,
            ..
        } => {
            if spell.zone == Zone::Stack {
                spell.mana_cost_owned()
            } else {
                linked_face_definition(game, spell).and_then(|def| def.card.mana_cost)
            }
        }
        CastingMethod::Fuse => {
            if spell.zone == Zone::Stack {
                spell.mana_cost_owned()
            } else {
                spell_view_for_fused_split_cast(game, spell).and_then(|view| view.mana_cost_owned())
            }
        }
        CastingMethod::Alternative(idx) => {
            if let Some(method) = spell
                .alternative_casts
                .get(*idx)
                .or(spell.cast_alternative_method.as_deref())
            {
                if matches!(
                    method,
                    crate::alternative_cast::AlternativeCastingMethod::Plot { .. }
                ) {
                    Some(crate::mana::ManaCost::new())
                } else if method.total_cost().is_some() {
                    Some(method.mana_cost().cloned().unwrap_or_default())
                } else {
                    method
                        .mana_cost()
                        .cloned()
                        .or_else(|| spell.mana_cost_owned())
                }
            } else {
                spell.mana_cost_owned()
            }
        }
        CastingMethod::GrantedEscape { .. } => spell.mana_cost_owned(),
        CastingMethod::GrantedFlashback => spell.mana_cost_owned(),
        CastingMethod::PlayFrom {
            use_alternative: None,
            ..
        } => spell.mana_cost_owned(),
        CastingMethod::PlayFrom {
            use_alternative: Some(idx),
            zone,
            ..
        }
        | CastingMethod::SplitOtherHalfPlayFrom {
            use_alternative: Some(idx),
            zone,
            ..
        } => {
            let method = if matches!(casting_method, CastingMethod::ExactPermission { .. }) {
                alternative_method_for_casting_method(game, player, spell, casting_method)
            } else { resolve_play_from_alternative_method(game, player, spell, *zone, *idx)
                .or_else(|| spell.cast_alternative_method_owned()) };
            if let Some(method) = method
            {
                if matches!(
                    method,
                    crate::alternative_cast::AlternativeCastingMethod::Plot { .. }
                ) {
                    Some(crate::mana::ManaCost::new())
                } else if method.total_cost().is_some() {
                    Some(method.mana_cost().cloned().unwrap_or_default())
                } else {
                    method
                        .mana_cost()
                        .cloned()
                        .or_else(|| spell.mana_cost_owned())
                }
            } else {
                spell.mana_cost_owned()
            }
        }
    };

    let base_cost = base_cost.map(|cost| {
        let cost = spell
            .additional_cost
            .costs()
            .iter()
            .filter_map(|part| part.mana_cost_ref())
            .fold(cost, |total, part| add_mana_cost(&total, part));
        with_spell_mana_spending_rules(game, player, spell, &cost)
    });

    if from_zone == Zone::Command {
        let tax = if commander_tax_life_per_previous_cast(spell).is_some() {
            0
        } else {
            game.commander_cast_count(spell.id).saturating_mul(2)
        };
        base_cost.map(|cost| cost.add_generic(tax))
    } else {
        base_cost
    }
}

pub(crate) fn alternative_method_for_casting_method(
    game: &GameState,
    player: PlayerId,
    spell: &crate::object::Object,
    casting_method: &CastingMethod,
) -> Option<crate::alternative_cast::AlternativeCastingMethod> {
    if matches!(casting_method, CastingMethod::ExactPermission { .. }) {
        return match crate::alternative_cast::play_permission::selected_alternative(game, player, spell, casting_method) {
            Ok(method) => method,
            Err(error) => { game.record_token_resource_failure(&error); None }
        };
    }
    match casting_method.without_exact_permission() {
        CastingMethod::AlternativePrice { .. } => {
            crate::alternative_cast::price_routes::origin_alternative(
                game,
                player,
                spell,
                casting_method,
            )
        }
        CastingMethod::Alternative(idx) => spell
            .alternative_casts
            .get(*idx)
            .or(spell.cast_alternative_method.as_deref())
            .cloned(),
        CastingMethod::PlayFrom {
            use_alternative: Some(idx),
            zone,
            ..
        }
        | CastingMethod::SplitOtherHalfPlayFrom {
            use_alternative: Some(idx),
            zone,
            ..
        } => resolve_play_from_alternative_method(game, player, spell, *zone, *idx)
            .or_else(|| spell.cast_alternative_method_owned()),
        CastingMethod::Normal => spell.cast_alternative_method_owned(),
        CastingMethod::ExactPermission { .. }
        | CastingMethod::FaceDown
        | CastingMethod::FaceDownPlayFrom { .. }
        | CastingMethod::SplitOtherHalf
        | CastingMethod::Fuse
        | CastingMethod::GrantedEscape { .. }
        | CastingMethod::GrantedFlashback
        | CastingMethod::PlayFrom {
            use_alternative: None,
            ..
        }
        | CastingMethod::SplitOtherHalfPlayFrom {
            use_alternative: None,
            ..
        } => None,
    }
}

fn plotted_cast_method_allows(
    game: &GameState,
    player: PlayerId,
    spell: &crate::object::Object,
    casting_method: &CastingMethod,
) -> bool {
    if !matches!(
        alternative_method_for_casting_method(game, player, spell, casting_method),
        Some(method) if method.prepares_face_up_sorcery()
    ) {
        return true;
    }
    if spell.owner != player
        || !game.is_active_player(player)
        || !crate::turn::is_sorcery_timing(game)
    {
        return false;
    }
    // The accepted proposal carries its selected alternative method onto the
    // stack; zone-change cleanup has removed the old exile object's designation.
    spell.zone == Zone::Stack
        || (spell.zone == Zone::Exile
            && game.is_prepared_face_up_by(spell.id, player)
            && game
                .plotted_turn(spell.id)
                .is_some_and(|turn| turn < game.turn.turn_number))
}

/// CR 702.143a/d: a foretell cost may be paid only by the card's owner and
/// only after the turn the card became foretold has ended.
fn foretold_cast_method_allows(
    game: &GameState,
    player: PlayerId,
    spell: &crate::object::Object,
    casting_method: &CastingMethod,
) -> bool {
    if !matches!(
        alternative_method_for_casting_method(game, player, spell, casting_method),
        Some(method) if method.prepares_face_down()
    ) {
        return true;
    }
    if spell.owner != player {
        return false;
    }
    // As with Plot, zone-change cleanup has removed the exile designation
    // once the accepted proposal is on the stack.
    spell.zone == Zone::Stack
        || (spell.zone == Zone::Exile && game.foretold_card_is_castable(spell.id))
}

pub(crate) fn alternative_method_uses_printed_mana_cost(
    method: &crate::alternative_cast::AlternativeCastingMethod,
) -> bool {
    matches!(
        method,
        crate::alternative_cast::AlternativeCastingMethod::JumpStart { .. }
            | crate::alternative_cast::AlternativeCastingMethod::Escape { cost: None, .. }
    )
}

pub(crate) fn casting_method_requires_printed_mana_cost(
    game: &GameState,
    player: PlayerId,
    spell: &crate::object::Object,
    casting_method: &CastingMethod,
) -> bool {
    if matches!(casting_method, CastingMethod::ExactPermission { .. }) {
        return match casting_method.origin_method() {
            CastingMethod::PlayFrom { use_alternative: None, .. }
            | CastingMethod::SplitOtherHalfPlayFrom { use_alternative: None, .. } => true,
            _ => alternative_method_for_casting_method(game, player, spell, casting_method)
                .as_ref().is_some_and(alternative_method_uses_printed_mana_cost),
        };
    }
    match casting_method.without_exact_permission() {
        // CR 709.3b / 118.6: a split half without a mana cost can't be cast
        // by paying its mana cost.
        CastingMethod::Normal
        | CastingMethod::SplitOtherHalf
        | CastingMethod::GrantedEscape { .. }
        | CastingMethod::GrantedFlashback
        | CastingMethod::PlayFrom {
            use_alternative: None,
            ..
        }
        | CastingMethod::SplitOtherHalfPlayFrom {
            use_alternative: None,
            ..
        } => true,
        CastingMethod::Alternative(idx) => spell
            .alternative_casts
            .get(*idx)
            .is_some_and(alternative_method_uses_printed_mana_cost),
        CastingMethod::PlayFrom {
            use_alternative: Some(idx),
            zone,
            ..
        }
        | CastingMethod::SplitOtherHalfPlayFrom {
            use_alternative: Some(idx),
            zone,
            ..
        } => resolve_play_from_alternative_method(game, player, spell, *zone, *idx)
            .or_else(|| spell.cast_alternative_method_owned())
            .as_ref()
            .is_some_and(alternative_method_uses_printed_mana_cost),
        _ => false,
    }
}

/// Check if a spell can be cast by a player using the given casting method.
pub fn can_cast_spell(
    game: &GameState,
    player: PlayerId,
    spell: &crate::object::Object,
    casting_method: &CastingMethod,
) -> bool {
    let view = DerivedGameView::new(game);
    can_cast_spell_with_view(game, player, spell, casting_method, &view)
}

/// Validate the fully announced CR 601.2 proposal without testing payment.
///
/// Unlike initial action discovery, this is deliberately strict: X, modes,
/// optional costs, targets, and cast overlays have already been committed to
/// the proposed stack object, so no further look-ahead is permitted here.
pub(crate) fn completed_cast_proposal_is_legal(
    game: &GameState,
    player: PlayerId,
    spell: &crate::object::Object,
    casting_method: &CastingMethod,
    from_zone: Zone,
    targets: &[crate::Target],
) -> bool {
    completed_cast_proposal_is_legal_with_timing_permission(
        game,
        player,
        spell,
        casting_method,
        from_zone,
        false,
        targets,
    )
}

/// Validate a completed proposal initiated by a resolving effect.
///
/// The effect supplies the permission to cast at this time, but it does not
/// override prohibitions, cast limits, or restrictions printed on the spell.
pub(crate) fn completed_effect_driven_cast_proposal_is_legal(
    game: &GameState,
    player: PlayerId,
    spell: &crate::object::Object,
    casting_method: &CastingMethod,
    from_zone: Zone,
) -> bool {
    completed_cast_proposal_is_legal_with_timing_permission(
        game,
        player,
        spell,
        casting_method,
        from_zone,
        true,
        &[],
    )
}

fn completed_cast_proposal_is_legal_with_timing_permission(
    game: &GameState,
    player: PlayerId,
    spell: &crate::object::Object,
    casting_method: &CastingMethod,
    from_zone: Zone,
    timing_permission_from_effect: bool,
    targets: &[crate::Target],
) -> bool {
    if matches!(casting_method, CastingMethod::ExactPermission { .. })
        && crate::alternative_cast::play_permission::receipt_or_latch(game, player, spell, casting_method).is_none()
    { return false; }
    if matches!(casting_method.without_exact_permission(), CastingMethod::AlternativePrice { .. })
        && crate::alternative_cast::price_routes::receipt_or_latch(
            game,
            player,
            spell,
            casting_method,
        )
        .is_none()
    {
        return false;
    }
    if !plotted_cast_method_allows(game, player, spell, casting_method)
        || !foretold_cast_method_allows(game, player, spell, casting_method)
    {
        return false;
    }
    let mut origin_view = spell.clone();
    origin_view.zone = from_zone;
    if violates_any_cant_cast_restriction_from_other_sources(game, player, spell, Some(spell.id))
        || violates_any_cast_limit(game, player, spell)
        || spell.is_land()
        || !spell_cast_restrictions_allow(game, player, &origin_view)
    {
        return false;
    }

    // "Can cast spells only any time they could cast a sorcery" (Teferi,
    // Time Raveler) restricts the player, not the spell's type-based timing,
    // so a resolving effect's permission to cast doesn't waive it (CR 608.2g,
    // 307.1). While an effect resolves the stack isn't empty, so such a
    // player can't cast the spell at all.
    if timing_permission_from_effect
        && game
            .effect_store
            .cant_effects
            .cast_spells_only_as_sorcery
            .contains(&player)
    {
        return false;
    }
    let view = DerivedGameView::new(game);
    let ctx = CastLegalityContext::new(game, player, &view);
    timing_permission_from_effect
        || has_valid_spell_timing_without_target_permission(game, player, spell, spell.id, &view)
        || (!game
            .effect_store
            .cant_effects
            .cast_spells_only_as_sorcery
            .contains(&player)
            && (target_dependent_flash_matches(game, player, spell, targets)
                || cast_choice_flash_matches(spell)))
        || casting_method_grants_special_timing(&ctx, spell, spell.id, casting_method)
}

/// Check whether a player could begin casting a spell from hand for suspend.
///
/// This enforces cast prohibitions, cast limits, timing, and explicit
/// "cast this spell only ..." restrictions without requiring a printable mana
/// cost or legal targets yet.
pub fn can_begin_to_cast_from_hand_for_suspend(
    game: &GameState,
    player: PlayerId,
    spell: &crate::object::Object,
) -> bool {
    if violates_any_cant_cast_restriction(game, player, spell) {
        return false;
    }

    if violates_any_cast_limit(game, player, spell) {
        return false;
    }

    if spell.is_land() {
        return false;
    }

    if !has_valid_spell_timing(game, player, spell, spell.id) {
        return false;
    }

    spell_cast_restrictions_allow(game, player, spell)
}

pub(crate) fn spell_has_legal_targets_for_cast_with_view(
    game: &GameState,
    spell: &crate::object::Object,
    spell_id: ObjectId,
    program_override: Option<&crate::resolution::ResolutionProgram>,
    effects_override: Option<&[crate::effect::Effect]>,
    player: PlayerId,
    view: &DerivedGameView<'_>,
) -> bool {
    view.with_casting_spell(spell_id, || {
        spell_has_legal_targets_for_cast_with_view_inner(
            game,
            spell,
            spell_id,
            program_override,
            effects_override,
            player,
            view,
        )
    })
}

fn spell_has_legal_targets_for_cast_with_view_inner(
    game: &GameState,
    spell: &crate::object::Object,
    spell_id: ObjectId,
    program_override: Option<&crate::resolution::ResolutionProgram>,
    effects_override: Option<&[crate::effect::Effect]>,
    player: PlayerId,
    view: &DerivedGameView<'_>,
) -> bool {
    if let Some(effects) = effects_override {
        return effects.is_empty()
            || view.spell_has_legal_targets(effects, player, Some(spell_id), None);
    }

    if let Some(program) = program_override.or(spell.spell_effect.as_deref()) {
        return crate::game_loop::spell_program_has_legal_targets_with_modes_and_view(
            game,
            program,
            player,
            Some(spell_id),
            None,
            view,
        );
    }

    let synthesized_aura_effects = if spell.subtypes.contains(&crate::types::Subtype::Aura) {
        spell
            .aura_attach_filter
            .clone()
            .map(|filter| vec![crate::effect::Effect::attach_to(filter.target_spec())])
    } else {
        None
    };
    let effects = synthesized_aura_effects.as_deref().unwrap_or(&[]);
    effects.is_empty() || view.spell_has_legal_targets(effects, player, Some(spell_id), None)
}

fn spree_mode_selections(mode_count: usize, min: usize, max: usize) -> Vec<Vec<usize>> {
    fn visit(
        next: usize,
        mode_count: usize,
        min: usize,
        max: usize,
        selected: &mut Vec<usize>,
        out: &mut Vec<Vec<usize>>,
    ) {
        if selected.len() >= min {
            out.push(selected.clone());
        }
        if selected.len() == max {
            return;
        }
        for mode in next..mode_count {
            selected.push(mode);
            visit(mode + 1, mode_count, min, max, selected, out);
            selected.pop();
        }
    }

    let mut selections = Vec::new();
    visit(0, mode_count, min, max, &mut Vec::new(), &mut selections);
    selections
}

#[allow(clippy::too_many_arguments)]
fn has_payable_legal_spree_selection_with_view(
    game: &GameState,
    spell: &crate::object::Object,
    spell_id: ObjectId,
    program_override: Option<&crate::resolution::ResolutionProgram>,
    effects_override: Option<&[crate::effect::Effect]>,
    player: PlayerId,
    base_mana_cost: Option<&crate::mana::ManaCost>,
    casting_method: &CastingMethod,
    view: &DerivedGameView<'_>,
) -> Option<bool> {
    let program = program_override.or(spell.spell_effect.as_deref())?;
    let modal = program.all_effects().into_iter().find_map(|effect| {
        effect
            .0
            .get_modal_spec_with_context(game, player, spell_id)
            .filter(|modal| modal.spree)
    })?;
    let min = match modal.min_modes {
        crate::effect::Value::Fixed(value) => value.max(0) as usize,
        _ => return Some(false),
    };
    let max = match modal.max_modes {
        crate::effect::Value::Fixed(value) => {
            (value.max(0) as usize).min(modal.mode_descriptions.len())
        }
        _ => return Some(false),
    };

    for modes in spree_mode_selections(modal.mode_descriptions.len(), min, max) {
        let targets_are_legal = view.with_casting_spell(spell_id, || {
            if let Some(effects) = effects_override {
                view.spell_has_legal_targets(effects, player, Some(spell_id), Some(&modes))
            } else {
                crate::game_loop::spell_program_has_legal_targets_with_modes_and_view(
                    game,
                    program,
                    player,
                    Some(spell_id),
                    Some(&modes),
                    view,
                )
            }
        });
        if !targets_are_legal {
            continue;
        }

        let mut combined = base_mana_cost.cloned().unwrap_or_default();
        for (index, optional) in spell.optional_costs.iter().enumerate() {
            for occurrence in 0..spell.optional_costs_paid.times_paid(index) {
                if let Some(cost) = crate::cost::optional_cost_payment_branch(
                    &optional.cost,
                    spell.optional_costs_paid.payment_branch_choice(index,occurrence),
                )
                .mana_cost()
                {
                    combined = add_mana_cost(&combined, cost);
                }
            }
        }
        for mode in &modes {
            if let Some(cost) = modal.mode_additional_mana_costs.get(*mode) {
                combined = add_mana_cost(&combined, cost);
            }
        }
        let effective = calculate_effective_mana_cost_with_view_for_casting_method(
            game,
            player,
            spell,
            &combined,
            casting_method,
            view,
        );
        if mana_cost_can_be_paid_by_caster_or_assist_with_view_at_x(
            game,
            player,
            spell_id,
            &effective,
            spell.x_value.unwrap_or(0),
            view,
            Some((spell, casting_method)),
        ) {
            return Some(true);
        }
    }

    Some(false)
}

fn spell_has_legal_targets_for_cast_or_payable_optional_cost_hypothesis_with_view(
    game: &GameState,
    spell: &crate::object::Object,
    spell_id: ObjectId,
    program_override: Option<&crate::resolution::ResolutionProgram>,
    effects_override: Option<&[crate::effect::Effect]>,
    player: PlayerId,
    base_mana_cost: Option<&crate::mana::ManaCost>,
    casting_method: &CastingMethod,
) -> bool {
    let spell_with_optional_costs =
        spell_with_optional_life_cost_reduction_costs(game, player, spell, casting_method);
    any_payable_optional_cost_proposal(
        game,
        player,
        &spell_with_optional_costs,
        base_mana_cost,
        casting_method,
        |hypothetical, proposal, _effective_cost, hypothetical_view| {
            if casting_method_is_mutate(hypothetical, player, proposal, casting_method) {
                let mutate_target =
                    crate::target::ChooseSpec::target(crate::target::ChooseSpec::Object(
                        crate::target::ObjectFilter::creature()
                            .owned_by(crate::target::PlayerFilter::Specific(proposal.owner))
                            .without_subtype(crate::types::Subtype::Human),
                    ));
                let requirement = crate::effect::Effect::new(
                    crate::effects::TargetOnlyEffect::new(mutate_target),
                );
                if !hypothetical_view.with_casting_spell(spell_id, || {
                    hypothetical_view.spell_has_legal_targets(
                        &[requirement],
                        player,
                        Some(spell_id),
                        None,
                    )
                }) {
                    return false;
                }
            }
            if let Some(legal) = has_payable_legal_spree_selection_with_view(
                hypothetical,
                proposal,
                spell_id,
                program_override,
                effects_override,
                player,
                base_mana_cost,
                casting_method,
                hypothetical_view,
            ) {
                return legal;
            }
            spell_has_legal_targets_for_cast_with_view(
                hypothetical,
                proposal,
                spell_id,
                program_override,
                effects_override,
                player,
                hypothetical_view,
            )
        },
    )
}

// A color-only source inventory spends each permanent at most once and does
// not execute activation costs. Converters and other nontrivial sources must
// use the stateful planner, including during the initial affordability gate.
pub(crate) fn payment_requires_stateful_sources(game: &GameState, player: PlayerId, view: &DerivedGameView<'_>) -> bool {
    // A color-only pool erases spending restrictions. They remain binding
    // even after the permanent that produced the mana has left play.
    if game.player(player).is_some_and(|player| !player.restricted_mana.is_empty()) {
        return true;
    }
    // Lands tapped through "you may tap lands you don't control for mana"
    // are activated by a non-controller under the permission's restrictions.
    if game.has_uncontrolled_land_mana_permission(player) {
        return true;
    }
    let analysis = view.simple_battlefield_mana_analysis(player);
    analysis.mana_source_ids().iter().any(|source| {
        view.abilities_rc(*source).is_some_and(|abilities| {
            analysis.mana_ability_indices_for(*source).iter().any(|index| {
                let Some(crate::ability::AbilityKind::Activated(ability))=abilities.get(*index).map(|ability|&ability.kind) else{return false};
                let mut facts=ActivationCostAbility::of(game,player,*source,ability);
                facts.ability_index=Some(*index);
                !ability.mana_usage_restrictions.is_empty()
                    || !ability.has_tap_cost()
                    || ability.mana_cost.as_all().is_none_or(|costs|costs.iter().any(|cost|!cost.requires_tap()))
                    // The legacy source inventory spends each permanent once.
                    // Distinct alternative payments require the full planner's
                    // exact cost/quota state even when the printed cost taps.
                    || crate::activation_cost_alternatives::has_available_alternative(game,*source,facts,&ability.mana_cost)
            })
        })
    })
}

fn mana_cost_can_be_paid_with_view_at_x(
    game: &GameState,
    player: PlayerId,
    spell_id: ObjectId,
    cost: &crate::mana::ManaCost,
    x_value: u32,
    view: &DerivedGameView<'_>,
) -> bool {
    if resumable::mana_payment_is_assumed() {
        return true;
    }
    let has_restricted_mana = game
        .player(player)
        .is_some_and(|player| !player.restricted_mana.is_empty())
        || game.battlefield.iter().any(|source| {
            view.abilities_rc(*source).is_some_and(|abilities| {
                abilities.iter().any(|ability| {
                    ability.functions_in(&Zone::Battlefield)
                        && matches!(&ability.kind, crate::ability::AbilityKind::Activated(activated)
                        if !activated.mana_usage_restrictions.is_empty())
                })
            })
        });
    if !cost.spending_restrictions().is_empty() || cost.has_waterbend_obligation()
        || has_restricted_mana
        || payment_requires_stateful_sources(game, player, view)
        || crate::mana_payment::has_potential_mana_triggers(game, view)
        || crate::mana_payment::has_mana_modifying_replacements(game)
        || game.object(spell_id).is_some_and(|spell| {
            game.controller_of(spell) == player
                && (spell_has_delve(game, spell)
                    || spell_has_convoke(game, spell)
                    || spell_has_improvise(game, spell))
        })
    {
        let mut request = crate::mana_payment::ManaPaymentRequest::new(
            player,
            spell_id,
            crate::costs::PaymentReason::CastSpell,
            cost.clone(),
        )
        .with_spend_policy(game.mana_spend_policy_for_cast(player, Some(spell_id)));
        request.x_value = x_value;
        // CR 601.2a: spending restrictions inspect the proposed spell on the
        // stack. The real card stays in its origin zone during menu analysis.
        // Give the payment planner that proposal too, rather than a hand card
        // that can never satisfy a creature-spell restriction.
        let mut prospective;
        let payment_game = if game
            .object(spell_id)
            .is_some_and(|spell| spell.zone != Zone::Stack)
        {
            prospective = game.clone();
            prospective.project_spell_for_payment(spell_id);
            &prospective
        } else {
            game
        };
        return resumable::with_proposed_spell(game, payment_game, spell_id, || {
            resumable::check_payment(payment_game, &request)
        });
    }
    let potential = view.potential_mana(player);
    let mana_spend_policy = game.mana_spend_policy_for_cast(player, Some(spell_id));
    let allow_any_color_for_obvious = mana_spend_policy.has_any_color_spending()
        || game.has_source_filtered_mana_spend_permission(player, Some(spell_id));
    let allow_black_life = mana_cost_has_black_symbol(cost)
        && view.player_can_pay_black_with_life_for_reason(
            player,
            crate::costs::PaymentReason::CastSpell,
        );
    !mana_cost_is_obviously_unpayable(
        &potential,
        cost,
        allow_any_color_for_obvious,
        allow_black_life,
    ) && can_pay_mana_cost_with_available_sources(
        game,
        player,
        Some(spell_id),
        cost,
        x_value,
        crate::costs::PaymentReason::CastSpell,
        &mana_spend_policy,
        allow_black_life,
        view,
    )
}

pub(crate) fn mana_cost_with_locked_x_and_generic_reduction(
    cost: &crate::mana::ManaCost,
    x_value: u32,
    reduction: u32,
) -> crate::mana::ManaCost {
    let cost = cost.clone().bind_x_payment_if_unbound(x_value);
    let mut pips = Vec::new();
    for pip in cost.pips() {
        if pip
            .iter()
            .any(|symbol| matches!(symbol, crate::mana::ManaSymbol::X))
        {
            let mut remaining = x_value;
            while remaining > 0 {
                let chunk = remaining.min(u32::from(u8::MAX)) as u8;
                pips.push(vec![crate::mana::ManaSymbol::Generic(chunk)]);
                remaining -= u32::from(chunk);
            }
        } else {
            pips.push(pip.clone());
        }
    }
    cost.with_pips(pips).reduce_generic(reduction)
}


/// Build the selected face once for every payment route, including explicit
/// requests that reserve a Harmonize resource. Arbitrary supplied views are
/// legitimate hypotheses, but never inherit the immutable root's cache entry.
fn with_cast_payment_proposal(
    game: &GameState, caster: PlayerId, spell_id: ObjectId,
    spell: &crate::object::Object, method: &CastingMethod,
    compute: impl FnOnce(&GameState) -> bool,
) -> bool {
    let Some(physical) = game.object(spell_id) else { return false; };
    if physical.zone == Zone::Stack { return compute(game); }
    // This proves the supplied view is uniquely determined by the root and
    // method. The address is not a cache key and is never retained.
    let supplied_is_root_object = std::ptr::eq(physical, spell);
    let origin = crate::snapshot::ObjectSnapshot::from_object_with_calculated_characteristics(physical, game);
    let selected = alternative_method_for_casting_method(game, caster, spell, method);
    let mut face = match method.origin_method() {
        CastingMethod::FaceDown | CastingMethod::FaceDownPlayFrom { .. } => spell_view_for_face_down_cast(game, spell),
        CastingMethod::SplitOtherHalf | CastingMethod::SplitOtherHalfPlayFrom { .. } if supplied_is_root_object => {
            let Some(face) = spell_view_for_split_other_half_cast(game, spell) else { return false; };
            face
        }
        CastingMethod::Fuse if supplied_is_root_object => {
            let Some(face) = spell_view_for_fused_split_cast(game, spell) else { return false; };
            face
        }
        _ if selected.as_ref().is_some_and(|alternative| alternative.casts_transformed()) => {
            let Some(face) = spell_view_for_disturb_cast(game, spell) else { return false; };
            face
        }
        _ => spell.clone(),
    };
    if let Some(alternative) = selected.as_ref() {
        if alternative.is_bestow() { face.apply_bestow_cast_overlay(); }
        if let Some(power_toughness) = alternative.prototype_power_toughness()
            && let Some(cost) = alternative.mana_cost()
        {
            face.apply_prototype_cast_overlay(cost.clone(), power_toughness);
        }
    }
    face.cast_alternative_method = selected.map(Box::new);
    let local_receipt = if matches!(method, CastingMethod::ExactPermission { .. }) {
        match crate::alternative_cast::play_permission::receipt_for_method(game, caster, spell, method) {
            Ok(Some(receipt)) => Some(receipt),
            Ok(None) => return false,
            Err(error) => return resumable::failed_calculation(game, error),
        }
    } else if matches!(method, CastingMethod::AlternativePrice { .. }) {
        match crate::alternative_cast::price_routes::resolve_announcement(game, caster, spell, method) {
            Ok(route) => match route.and_then(|route| route.origin).filter(|grant| !grant.play_from_constraints.cast_mana_spend_mode.is_normal()) {
                Some(grant) => match crate::alternative_cast::play_permission::PlayPermissionReceipt::from_resolved_grant(
                    &grant, caster, spell_id, physical.zone, method.origin_method()) {
                        Ok(receipt) => Some(receipt), Err(error) => return resumable::failed_calculation(game, error),
                    },
                None => None,
            },
            Err(error) => return resumable::failed_calculation(game, error),
        }
    } else { None };
    if let Some(receipt) = local_receipt {
        face.cast_play_from_constraints = Some(Box::new((receipt.source, receipt.zone, receipt.constraints.clone())));
        face.cast_grant_usage_identity = Some(Box::new(receipt.identity.clone()));
        face.cast_play_permission = Some(Box::new(receipt));
    }
    let mut proposed = game.clone();
    proposed.project_spell_for_payment(spell_id);
    face.zone = Zone::Stack;
    *proposed.object_mut(spell_id).expect("proposal source exists") = face;
    proposed.stage_initial_controller_for_assembly(spell_id, caster);
    proposed.set_cast_origin_snapshot(spell_id, origin);
    if matches!(method.origin_method(), CastingMethod::FaceDown | CastingMethod::FaceDownPlayFrom { .. }) {
        proposed.set_face_down(spell_id);
    }
    if let Err(error) = proposed.refresh_continuous_state() {
        return resumable::failed_calculation(game, crate::effects::ExecutionError::ContinuousDiscovery(error));
    }
    if supplied_is_root_object {
        resumable::with_declared_cast(game, &proposed, spell_id, method, &spell.optional_costs_paid, || compute(&proposed))
    } else {
        // check_payment already handles non-root hypothetical games exactly,
        // without caching a result against a different declared view.
        compute(&proposed)
    }
}

fn mana_cost_can_be_paid_by_caster_or_assist_with_view_at_x(
    game: &GameState,
    caster: PlayerId,
    spell_id: ObjectId,
    cost: &crate::mana::ManaCost,
    x_value: u32,
    view: &DerivedGameView<'_>,
    declaration: Option<(&crate::object::Object, &CastingMethod)>,
) -> bool {
    if let Some((spell, method)) = declaration {
        return with_cast_payment_proposal(game, caster, spell_id, spell, method, |proposed| {
            let proposed_view = DerivedGameView::new(proposed);
            mana_cost_can_be_paid_by_caster_or_assist_with_view_at_x(
                proposed, caster, spell_id, cost, x_value, &proposed_view, None,
            )
        });
    }
    if mana_cost_can_be_paid_with_view_at_x(game, caster, spell_id, cost, x_value, view) {
        return true;
    }
    if !game
        .spell_allows_other_player_generic_payment(spell_id)
    {
        return false;
    }

    let x_pips = cost
        .pips()
        .iter()
        .filter(|pip| {
            pip.iter()
                .any(|symbol| matches!(symbol, crate::mana::ManaSymbol::X))
        })
        .count() as u32;
    let generic_total = cost
        .generic_mana_total()
        .saturating_add(x_pips.saturating_mul(x_value));
    if generic_total == 0 {
        return false;
    }

    game.turn_store
        .turn_order
        .iter()
        .copied()
        .filter(|helper| *helper != caster && game.player(*helper).is_some())
        .any(|helper| {
            (1..=generic_total).any(|contribution| {
                if cost.has_x_spending_restriction() || cost.has_waterbend_obligation() {
                    let remaining =
                        mana_cost_with_locked_x_and_generic_reduction(cost, x_value, contribution);
                    let completion = crate::mana_payment::ManaPaymentRequest::new(
                        caster,
                        spell_id,
                        crate::costs::PaymentReason::CastSpell,
                        remaining,
                    )
                    .with_spend_policy(game.mana_spend_policy_for_cast(caster, Some(spell_id)));
                    let mut helper_request = crate::mana_payment::ManaPaymentRequest::new(
                        helper,
                        spell_id,
                        crate::costs::PaymentReason::CastSpell,
                        crate::mana::ManaCost::new()
                            .add_generic(contribution)
                            .inherit_transaction_spending_restrictions(cost),
                    )
                    .with_spend_policy(game.mana_spend_policy_for_cast(helper, Some(spell_id)));
                    helper_request.assist_completion = Some(Box::new(completion));
                    let mut prospective = game.clone();
                    prospective.project_spell_for_payment(spell_id);
                    return resumable::check_payment(&prospective, &helper_request);
                }
                let helper_cost = crate::mana::ManaCost::new()
                    .add_generic(contribution)
                    .inherit_spending_restrictions(cost);
                if !mana_cost_can_be_paid_with_view_at_x(
                    game,
                    helper,
                    spell_id,
                    &helper_cost,
                    0,
                    view,
                ) {
                    return false;
                }
                let caster_cost =
                    mana_cost_with_locked_x_and_generic_reduction(cost, x_value, contribution);
                mana_cost_can_be_paid_with_view_at_x(game, caster, spell_id, &caster_cost, 0, view)
            })
        })
}

fn mana_cost_can_be_paid_by_caster_or_assist_with_view(
    game: &GameState,
    caster: PlayerId,
    spell: &crate::object::Object,
    method: &CastingMethod,
    cost: &crate::mana::ManaCost,
    view: &DerivedGameView<'_>,
) -> bool {
    mana_cost_can_be_paid_by_caster_or_assist_with_view_at_x(game, caster, spell.id, cost, 0, view, Some((spell, method)))
}

pub(crate) fn max_x_payable_with_payment_resources(
    game: &GameState,
    caster: PlayerId,
    spell_id: ObjectId,
    cost: &crate::mana::ManaCost,
) -> Option<u32> {
    let spell = game.object(spell_id)?;
    let assist = game
        .spell_allows_other_player_generic_payment(spell_id);
    let delve = spell_has_delve(game, spell);
    let convoke = spell_has_convoke(game, spell);
    let improvise = spell_has_improvise(game, spell);
    if !cost.has_x() || !(assist || delve || convoke || improvise || cost.has_waterbend_obligation()) {
        return None;
    }
    let view = DerivedGameView::new(game);
    let mut upper_bound = if assist {
        game.turn_store
            .turn_order
            .iter()
            .copied()
            .map(|player| view.potential_mana(player).total())
            .sum::<u32>()
    } else {
        view.potential_mana(caster).total()
    };
    let mut tap_resources = std::collections::HashSet::new();
    if convoke {
        tap_resources.extend(
            get_convoke_creatures(game, caster)
                .into_iter()
                .map(|(id, _)| id),
        );
    }
    if improvise {
        tap_resources.extend(get_improvise_artifacts(game, caster));
    }
    if cost.has_waterbend_obligation() {
        let request = crate::mana_payment::ManaPaymentRequest::new(caster, spell_id,
            crate::costs::PaymentReason::CastSpell, cost.clone()).with_x(1);
        tap_resources.extend(crate::mana_payment::waterbend_sources(game, &request));
    }
    upper_bound = upper_bound.saturating_add(tap_resources.len() as u32);
    if delve {
        upper_bound = upper_bound.saturating_add(game.player(caster).map_or(0, |player| {
            player
                .graveyard
                .iter()
                .filter(|id| {
                    **id != spell_id
                        && game
                            .object(**id)
                            .is_some_and(|card| card.kind != crate::object::ObjectKind::Token)
                })
                .count() as u32
        }));
    }
    // Paying the fixed cost plus X is monotone; the planner verifies shared
    // resources jointly rather than assuming every possible source can stack.
    let mut lower = 0;
    while lower < upper_bound {
        let middle = lower + (upper_bound - lower).div_ceil(2);
        if mana_cost_can_be_paid_by_caster_or_assist_with_view_at_x(
            game, caster, spell_id, cost, middle, &view, None,
        ) {
            lower = middle;
        } else {
            upper_bound = middle - 1;
        }
    }
    Some(lower)
}

fn effective_cost_with_affordable_optional_cost_hypothesis(
    game: &GameState,
    player: PlayerId,
    spell: &crate::object::Object,
    base_cost: &crate::mana::ManaCost,
    casting_method: &CastingMethod,
) -> Option<crate::mana::ManaCost> {
    let spell_with_optional_costs =
        spell_with_optional_life_cost_reduction_costs(game, player, spell, casting_method);

    let mut adjusted = None;
    any_payable_optional_cost_proposal(
        game,
        player,
        &spell_with_optional_costs,
        Some(base_cost),
        casting_method,
        |_hypothetical, _proposal, effective_cost, _hypothetical_view| {
            if let Some(effective_cost) = effective_cost
                && effective_cost != base_cost
            {
                adjusted = Some(effective_cost.clone());
                return true;
            }
            false
        },
    );
    adjusted
}

/// Reuse the normal proposal owner for a private characteristic preview.
/// Payment and event publication are never run in this query copy.
fn selected_characteristic_preview(
    game: &GameState, player: PlayerId, spell: &crate::object::Object,
    method: &CastingMethod,
) -> Option<Result<(GameState, ObjectId), crate::game_loop::GameLoopError>> {
    if spell.zone == Zone::Stack { return None; }
    let selected = alternative_method_for_casting_method(game, player, spell, method)?;
    if !crate::alternative_cast::has_selected_price_characteristics(&selected) { return None; }
    let mut preview = game.clone();
    *preview.object_mut(spell.id)? = spell.clone();
    Some(crate::game_loop::propose_spell_cast(&mut preview, spell.id, spell.zone, player, method)
        .map(|id| (preview, id)))
}

pub(crate) fn can_cast_spell_with_context(
    spell: &crate::object::Object,
    casting_method: &CastingMethod,
    ctx: &CastLegalityContext<'_>,
) -> bool {
    let total_started_at = PerfTimer::start();
    let game = ctx.game;
    let player = ctx.player;
    let view = ctx.view;
    if let Some(preview) = selected_characteristic_preview(game, player, spell, casting_method) {
        return match preview {
            Ok((preview, id)) => {
                let view = DerivedGameView::new(&preview);
                let mut preview_ctx = CastLegalityContext::new(&preview, player, &view);
                preview_ctx.allow_library_search_cast_timing = ctx.allow_library_search_cast_timing;
                can_cast_spell_with_context(preview.object(id).unwrap(), casting_method, &preview_ctx)
            }
            Err(crate::game_loop::GameLoopError::ExecutionFailed(error)) => { game.record_token_resource_failure(&error); false }
            Err(_) => false,
        };
    }
    if matches!(casting_method, CastingMethod::ExactPermission { .. })
        && crate::alternative_cast::play_permission::receipt_or_latch(game, player, spell, casting_method).is_none()
    { return false; }
    if matches!(casting_method.without_exact_permission(), CastingMethod::AlternativePrice { .. })
        && crate::alternative_cast::price_routes::receipt_or_latch(
            game,
            player,
            spell,
            casting_method,
        )
        .is_none()
    {
        return false;
    }
    if game.is_planar_card(spell.id) {
        return false;
    }
    // Permission to play a card from another zone does not waive Warp's
    // explicit "from your hand" restriction.
    let selected_alternative = if matches!(casting_method, CastingMethod::ExactPermission { .. }) {
        alternative_method_for_casting_method(game, player, spell, casting_method)
    } else { match casting_method.without_exact_permission() {
        CastingMethod::Alternative(idx) => spell.alternative_casts.get(*idx).cloned(),
        CastingMethod::PlayFrom {
            zone,
            use_alternative: Some(idx),
            ..
        }
        | CastingMethod::SplitOtherHalfPlayFrom {
            zone,
            use_alternative: Some(idx),
            ..
        } => resolve_play_from_alternative_method(game, player, spell, *zone, *idx),
        _ => None,
    } };
    if spell.zone != Zone::Hand
        && matches!(
            selected_alternative,
            Some(crate::alternative_cast::AlternativeCastingMethod::Warp { .. })
        )
    {
        return false;
    }
    let cast_view = match casting_method.origin_method() {
        CastingMethod::FaceDown | CastingMethod::FaceDownPlayFrom { .. } => {
            if !spell_can_be_cast_face_down(game, spell) {
                return false;
            }
            Some(spell_view_for_face_down_cast(game, spell))
        }
        CastingMethod::SplitOtherHalf | CastingMethod::SplitOtherHalfPlayFrom { .. } => {
            match spell_view_for_split_other_half_cast(game, spell) {
                Some(view) => Some(view),
                None => return false,
            }
        }
        CastingMethod::Fuse => match spell_view_for_fused_split_cast(game, spell) {
            Some(view) => Some(view),
            None => return false,
        },
        _ if casting_method_is_bestow(game, player, spell, casting_method) => {
            let mut view = spell.clone();
            view.apply_bestow_cast_overlay();
            Some(view)
        }
        _ => None,
    };
    let cast_view = match casting_method.without_exact_permission() {
        CastingMethod::AlternativePrice {
            origin,
            prototype: Some(index),
            ..
        } => {
            let Some(face) = crate::alternative_cast::price_routes::proposed_face(
                game,
                spell,
                origin,
                Some(*index),
            ) else {
                return false;
            };
            Some(face)
        }
        _ => cast_view,
    };
    let cast_view = if let CastingMethod::ExactPermission { .. } = casting_method {
        if spell.zone == Zone::Stack {
            game.object(spell.id).cloned()
        } else {
            match crate::alternative_cast::play_permission::selected_face(game, player, spell, casting_method) {
                Ok((face, _, _)) => Some(face),
                Err(error) => { game.record_token_resource_failure(&error); return false; }
            }
        }
    } else { cast_view };
    let cast_view = without_combined_split_characteristics(cast_view, spell, casting_method);
    let spell_for_checks = cast_view.as_ref().unwrap_or(spell);

    // An empty zone price fixes printed X to zero. Check the authored
    // minimum in the same selected-face, stack-zone proposal used for payment,
    // rather than reading the original zone object's characteristics by ID.
    // This gate is deliberately separate from additional-only X and paid/X
    // prices, whose X remains a later announcement.
    if spell_for_checks.mana_cost.as_ref().is_some_and(|cost| cost.has_x())
        && matches!(selected_alternative.as_ref(),
            Some(crate::alternative_cast::AlternativeCastingMethod::FromZone {
                total_cost, ..
            }) if total_cost.costs().is_empty())
        && !with_cast_payment_proposal(
            game, player, spell.id, spell_for_checks, casting_method, |proposed| {
                let Some(proposed_spell) = proposed.object(spell.id) else { return false; };
                match spell_x_minimum_allows_zero(proposed, player, proposed_spell) {
                    Ok(allowed) => allowed,
                    Err(error) => resumable::failed_calculation(game, error),
                }
            },
        )
    {
        return false;
    }

    if let Some(method) = alternative_method_for_casting_method(game, player, spell, casting_method)
        && !crate::alternative_cast::land_play_price_is_available(game, player, &method)
    { return false; }

    if spell.zone != Zone::Stack
        && let Some(method)=alternative_method_for_casting_method(game,player,spell,casting_method)
        && !crate::alternative_cast::hand_event_price_is_available(game,spell.id,&method) {return false;}

    if let Some(method) = alternative_method_for_casting_method(game, player, spell, casting_method)
        && let Some(window) = method.battlefield_instructions().casting_window
        && !this_spell_cast_timing_allows(game, player, window)
    { return false; }

    if let Some(method) = alternative_method_for_casting_method(game, player, spell, casting_method) && let Some(condition) = method.cast_condition()
        && !crate::static_abilities::this_spell_cost_condition_is_active_for_player(
            game,
            spell.id,
            player,
            condition,
            &[],
        )
    {
        return false;
    }

    let restrictions_started_at = PerfTimer::start();
    let proposal_mana_cost = spell_mana_cost_for_cast(
        game,
        player,
        spell_for_checks,
        casting_method,
        spell_for_checks.zone,
    );
    if every_payable_proposal_violates_cant_cast(
        game,
        player,
        spell_for_checks,
        proposal_mana_cost.as_ref(),
        casting_method,
    ) {
        ctx.add_restrictions_ms(restrictions_started_at.elapsed_ms());
        ctx.add_total_ms(total_started_at.elapsed_ms());
        return false;
    }
    if violates_any_cast_limit(game, player, spell_for_checks) {
        ctx.add_restrictions_ms(restrictions_started_at.elapsed_ms());
        ctx.add_total_ms(total_started_at.elapsed_ms());
        return false;
    }
    if spell_for_checks.is_land() {
        ctx.add_restrictions_ms(restrictions_started_at.elapsed_ms());
        ctx.add_total_ms(total_started_at.elapsed_ms());
        return false;
    }
    if !spell_cast_restrictions_allow(game, player, spell_for_checks) {
        ctx.add_restrictions_ms(restrictions_started_at.elapsed_ms());
        ctx.add_total_ms(total_started_at.elapsed_ms());
        return false;
    }
    ctx.add_restrictions_ms(restrictions_started_at.elapsed_ms());

    let timing_started_at = PerfTimer::start();
    if !has_valid_spell_timing_with_view(game, player, spell_for_checks, spell.id, view)
        && !casting_method_grants_special_timing(ctx, spell_for_checks, spell.id, casting_method)
    {
        ctx.add_timing_ms(timing_started_at.elapsed_ms());
        ctx.add_total_ms(total_started_at.elapsed_ms());
        return false;
    }
    ctx.add_timing_ms(timing_started_at.elapsed_ms());

    let base_mana_cost = spell_mana_cost_for_cast(game, player, spell, casting_method, spell.zone);
    if base_mana_cost.is_none()
        && casting_method_requires_printed_mana_cost(game, player, spell, casting_method)
    {
        return false;
    }

    let target_started_at = PerfTimer::start();
    // An explicit face-down view intentionally has no printed program.
    // Absence on that face must not recover the secret face's targets.
    let program = cast_view.as_ref().map_or(spell.spell_effect.as_deref(), |view| view.spell_effect.as_deref());
    // Target legality is a pure function of the analysis snapshot, and this is
    // the dominant fixed cost of a menu pass. Under a sliced analysis the
    // snapshot is frozen, so the answer is memoized across slices; synchronous
    // callers compute it as before.
    let has_legal_targets = resumable::memo_snapshot_fact(
        resumable::SnapshotFactKey {
            kind: resumable::SnapshotFactKind::CastTargetLegality,
            object: spell.id,
            player,
        },
        &resumable::SnapshotFactContext {
            casting_method: casting_method.clone(),
            mana_cost: base_mana_cost.clone(),
        },
        || {
            spell_has_legal_targets_for_cast_or_payable_optional_cost_hypothesis_with_view(
                game,
                spell_for_checks,
                spell.id,
                program,
                None,
                player,
                base_mana_cost.as_ref(),
                casting_method,
            )
        },
    );
    ctx.add_target_legality_ms(target_started_at.elapsed_ms());
    if !has_legal_targets {
        ctx.add_total_ms(total_started_at.elapsed_ms());
        return false;
    }

    let commander_tax_life = commander_tax_life_payment_amount(game, spell, spell.zone);
    let mut additional_costs = spell_for_checks.additional_non_mana_costs();
    if matches!(casting_method.without_exact_permission(), CastingMethod::AlternativePrice { .. }) {
        let Some(price) = crate::alternative_cast::price_routes::receipt_or_latch(
            game,
            player,
            spell,
            casting_method,
        ) else {
            return false;
        };
        additional_costs.extend(price.total_cost.non_mana_costs().cloned());
        if let Some(origin) = crate::alternative_cast::price_routes::origin_alternative(
            game,
            player,
            spell,
            casting_method,
        ) {
            additional_costs.extend(origin.non_mana_costs());
            if matches!(
                origin,
                crate::alternative_cast::AlternativeCastingMethod::JumpStart { .. }
            ) && !spell_for_checks
                .card_types
                .contains(&crate::types::CardType::Instant)
                && !spell_for_checks
                    .card_types
                    .contains(&crate::types::CardType::Sorcery)
            {
                return false;
            }
        }
    }
    let has_modal_mana_cost = additional_costs
        .iter()
        .any(|cost| crate::costs::simple_modal_mana_cost_branches(cost).is_some());
    if !has_modal_mana_cost
        && !can_pay_non_mana_cost_sequence_for_cast(
            game,
            player,
            spell.id,
            additional_costs.clone(),
        )
    {
        ctx.add_total_ms(total_started_at.elapsed_ms());
        return false;
    }
    if commander_tax_life > 0
        && !can_pay_cost_with_spell_exclusion(
            game,
            player,
            &crate::costs::Cost::life(commander_tax_life),
            Some(spell.id),
        )
    {
        ctx.add_total_ms(total_started_at.elapsed_ms());
        return false;
    }

    if let Some(base_cost) = base_mana_cost.as_ref() {
        let cost_started_at = PerfTimer::start();
        let has_cost_adjustments = spell_has_intrinsic_cost_adjustments(spell_for_checks)
            || !spell_granted_cost_static_abilities(game, spell_for_checks).is_empty()
            || matches!(
                casting_method.without_exact_permission(),
                CastingMethod::PlayFrom { .. }
                    | CastingMethod::SplitOtherHalfPlayFrom { .. }
                    | CastingMethod::FaceDownPlayFrom { .. }
                    | CastingMethod::AlternativePrice { .. }
            );
        let effective_cost = if ctx.can_use_printed_cost_directly(has_cost_adjustments) {
            base_cost.clone()
        } else if ctx.spell_cost_needs_adjustment(has_cost_adjustments) {
            calculate_effective_mana_cost_with_view_for_casting_method(
                game,
                player,
                spell_for_checks,
                base_cost,
                casting_method,
                view,
            )
        } else {
            apply_minimum_spell_total_mana_with_view(
                view,
                &apply_payment_reason_mana_adjustments(
                    game,
                    player,
                    Some(spell.id),
                    base_cost,
                    crate::costs::PaymentReason::CastSpell,
                ),
            )
        };
        ctx.add_cost_adjustment_ms(cost_started_at.elapsed_ms());

        let affordability_started_at = PerfTimer::start();
        let can_pay_effective = mana_cost_can_be_paid_by_caster_or_assist_with_view(
            game,
            player,
            spell_for_checks,
            casting_method,
            &effective_cost,
            view,
        );
        let can_pay_with_optional_reduction = !can_pay_effective
            && effective_cost_with_affordable_optional_cost_hypothesis(
                game,
                player,
                spell_for_checks,
                base_cost,
                casting_method,
            )
            .is_some_and(|cost| {
                mana_cost_can_be_paid_by_caster_or_assist_with_view(
                    game, player, spell_for_checks, casting_method, &cost, view,
                )
            });
        let can_pay_with_sacrifice_reduction = !can_pay_effective
            && !can_pay_with_optional_reduction
            && affordable_with_max_cost_payment_sacrifice_reduction(
                game,
                player,
                spell_for_checks,
                spell.id,
                casting_method,
                &effective_cost,
                view,
            );
        if !can_pay_effective
            && !can_pay_with_optional_reduction
            && !can_pay_with_sacrifice_reduction
        {
            ctx.add_affordability_ms(affordability_started_at.elapsed_ms());
            ctx.add_total_ms(total_started_at.elapsed_ms());
            return false;
        }
        ctx.add_affordability_ms(affordability_started_at.elapsed_ms());
    }

    if has_modal_mana_cost
        && !modal_additional_costs_are_payable(
            game,
            player,
            spell_for_checks,
            casting_method,
            base_mana_cost.as_ref(),
            &additional_costs,
            view,
        )
    {
        ctx.add_total_ms(total_started_at.elapsed_ms());
        return false;
    }
    ctx.add_total_ms(total_started_at.elapsed_ms());
    true
}

/// Test an entire announced branch, sharing its mana and discard resources
/// with the spell's base cost. Stop on a witness, without truncating alternatives.
fn modal_additional_costs_are_payable(
    game: &GameState,
    player: PlayerId,
    spell: &crate::object::Object,
    casting_method: &CastingMethod,
    base: Option<&crate::mana::ManaCost>,
    costs: &[crate::costs::Cost],
    view: &DerivedGameView<'_>,
) -> bool {
    fn visit(
        game: &GameState,
        player: PlayerId,
        spell: &crate::object::Object,
        casting_method: &CastingMethod,
        base: &crate::mana::ManaCost,
        costs: &[crate::costs::Cost],
        selected: &mut Vec<crate::costs::Cost>,
        view: &DerivedGameView<'_>,
    ) -> bool {
        if let Some((cost, rest)) = costs.split_first() {
            let branches = crate::costs::simple_modal_mana_cost_branches(cost)
                .unwrap_or_else(|| vec![(String::new(), vec![cost.clone()])]);
            for (_, branch) in branches {
                let before = selected.len();
                selected.extend(branch);
                let payable = visit(
                    game,
                    player,
                    spell,
                    casting_method,
                    base,
                    rest,
                    selected,
                    view,
                );
                selected.truncate(before);
                if payable {
                    return true;
                }
            }
            return false;
        }
        let non_mana = selected
            .iter()
            .filter(|cost| cost.mana_cost_ref().is_none())
            .cloned()
            .collect();
        if !can_pay_non_mana_cost_sequence_for_cast(game, player, spell.id, non_mana) {
            return false;
        }
        let mut combined = base.clone();
        for cost in selected.iter().filter_map(|cost| cost.mana_cost_ref()) {
            combined = add_mana_cost(&combined, cost);
        }
        let effective = calculate_effective_mana_cost_with_view_for_casting_method(
            game,
            player,
            spell,
            &combined,
            casting_method,
            view,
        );
        if mana_cost_can_be_paid_by_caster_or_assist_with_view(
            game, player, spell, casting_method, &effective, view,
        ) {
            return true;
        }
        effective_cost_with_affordable_optional_cost_hypothesis(
            game,
            player,
            spell,
            &combined,
            casting_method,
        )
        .is_some_and(|cost| {
            mana_cost_can_be_paid_by_caster_or_assist_with_view(game, player, spell, casting_method, &cost, view)
        }) || affordable_with_max_cost_payment_sacrifice_reduction(
            game, player, spell, spell.id, casting_method, &effective, view,
        )
    }
    visit(
        game,
        player,
        spell,
        casting_method,
        &base.cloned().unwrap_or_default(),
        costs,
        &mut Vec::new(),
        view,
    )
}

pub(crate) fn can_cast_spell_with_view(
    game: &GameState,
    player: PlayerId,
    spell: &crate::object::Object,
    casting_method: &CastingMethod,
    view: &DerivedGameView<'_>,
) -> bool {
    let ctx = CastLegalityContext::new(game, player, view);
    can_cast_spell_with_context(spell, casting_method, &ctx)
}

// ============================================================================
// Unified Spell Casting Validation
// ============================================================================

/// Additional requirements for casting a spell beyond mana.
#[derive(Debug, Clone, Default)]
pub struct AdditionalCastRequirements {
    /// Cards that must be exiled from graveyard (excluding the spell itself).
    pub exile_from_graveyard: u32,
    /// Cards that must be discarded from hand.
    pub discard_from_hand: u32,
    /// A TotalCost that must be paid (for alternative costs like Force of Will).
    /// This is checked with spell exclusion (the spell being cast is excluded from hand).
    pub total_cost: Option<crate::cost::TotalCost>,
    /// If true, spell must be instant or sorcery only.
    pub must_be_instant_or_sorcery: bool,
}

pub(crate) fn can_cast_with_cost_with_view(
    game: &GameState,
    player: PlayerId,
    spell: &crate::object::Object,
    spell_id: crate::ids::ObjectId,
    mana_cost: Option<&crate::mana::ManaCost>,
    effects_override: Option<&[crate::effect::Effect]>,
    requirements: &AdditionalCastRequirements,
    view: &DerivedGameView<'_>,
) -> bool {
    can_cast_with_cost_with_view_for_casting_method(
        game,
        player,
        spell,
        spell_id,
        mana_cost,
        effects_override,
        requirements,
        &CastingMethod::Normal,
        view,
    )
}

pub(crate) fn can_cast_with_cost_with_view_for_casting_method(
    game: &GameState,
    player: PlayerId,
    spell: &crate::object::Object,
    spell_id: crate::ids::ObjectId,
    mana_cost: Option<&crate::mana::ManaCost>,
    effects_override: Option<&[crate::effect::Effect]>,
    requirements: &AdditionalCastRequirements,
    casting_method: &CastingMethod,
    view: &DerivedGameView<'_>,
) -> bool {
    let ctx = CastLegalityContext::new(game, player, view);
    if matches!(casting_method, CastingMethod::ExactPermission { .. })
        && crate::alternative_cast::play_permission::receipt_or_latch(game, player, spell, casting_method).is_none()
    { return false; }
    can_cast_with_cost_with_context(
        spell,
        spell_id,
        mana_cost,
        effects_override,
        requirements,
        casting_method,
        &ctx,
    )
}

pub(crate) fn can_cast_with_cost_with_context(
    spell: &crate::object::Object,
    spell_id: crate::ids::ObjectId,
    mana_cost: Option<&crate::mana::ManaCost>,
    effects_override: Option<&[crate::effect::Effect]>,
    requirements: &AdditionalCastRequirements,
    casting_method: &CastingMethod,
    ctx: &CastLegalityContext<'_>,
) -> bool {
    use crate::types::CardType;
    let game = ctx.game;
    let player = ctx.player;
    let view = ctx.view;
    if matches!(casting_method, CastingMethod::ExactPermission { .. })
        && crate::alternative_cast::play_permission::receipt_or_latch(game, player, spell, casting_method).is_none()
    { return false; }
    if !plotted_cast_method_allows(game, player, spell, casting_method)
        || !foretold_cast_method_allows(game, player, spell, casting_method)
    {
        return false;
    }
    if game.is_planar_card(spell_id) {
        return false;
    }
    let cast_view = if casting_method_is_bestow(game, player, spell, casting_method) {
        let mut view = spell.clone();
        view.apply_bestow_cast_overlay();
        Some(view)
    } else {
        // CR 718.3a: a prototyped spell's legality uses its prototype mana
        // cost, color and power/toughness.
        alternative_method_for_casting_method(game, player, spell, casting_method).and_then(
            |method| {
                let power_toughness = method.prototype_power_toughness()?;
                let cost = method.mana_cost()?.clone();
                let mut view = spell.clone();
                view.apply_prototype_cast_overlay(cost, power_toughness)
                    .then_some(view)
            },
        )
    };
    let cast_view = if let CastingMethod::ExactPermission { .. } = casting_method {
        if spell.zone == Zone::Stack {
            game.object(spell.id).cloned()
        } else {
            match crate::alternative_cast::play_permission::selected_face(game, player, spell, casting_method) {
                Ok((face, _, _)) => Some(face),
                Err(error) => { game.record_token_resource_failure(&error); return false; }
            }
        }
    } else { cast_view };
    let cast_view = without_combined_split_characteristics(cast_view, spell, casting_method);
    let spell_for_checks = cast_view.as_ref().unwrap_or(spell);

    if let Some(method) = alternative_method_for_casting_method(game, player, spell, casting_method)
        && !crate::alternative_cast::land_play_price_is_available(game, player, &method)
    { return false; }

    if spell.zone != Zone::Stack
        && let Some(method)=alternative_method_for_casting_method(game,player,spell,casting_method)
        && !crate::alternative_cast::hand_event_price_is_available(game,spell.id,&method) {return false;}

    if let Some(method) = alternative_method_for_casting_method(game, player, spell, casting_method)
        && let Some(window) = method.battlefield_instructions().casting_window
        && !this_spell_cast_timing_allows(game, player, window)
    { return false; }

    if let Some(method) = alternative_method_for_casting_method(game, player, spell, casting_method) && let Some(condition) = method.cast_condition()
        && !crate::static_abilities::this_spell_cost_condition_is_active_for_player(
            game,
            spell_id,
            player,
            condition,
            &[],
        )
    {
        return false;
    }

    let restrictions_started_at = PerfTimer::start();
    if every_payable_proposal_violates_cant_cast(
        game,
        player,
        spell_for_checks,
        mana_cost,
        casting_method,
    ) {
        ctx.add_restrictions_ms(restrictions_started_at.elapsed_ms());
        return false;
    }
    if violates_any_cast_limit(game, player, spell_for_checks) {
        ctx.add_restrictions_ms(restrictions_started_at.elapsed_ms());
        return false;
    }
    if spell_for_checks.is_land() {
        ctx.add_restrictions_ms(restrictions_started_at.elapsed_ms());
        return false;
    }
    if requirements.must_be_instant_or_sorcery
        && !spell.has_card_type(CardType::Instant)
        && !spell.has_card_type(CardType::Sorcery)
    {
        ctx.add_restrictions_ms(restrictions_started_at.elapsed_ms());
        return false;
    }
    if !spell_cast_restrictions_allow(game, player, spell_for_checks) {
        ctx.add_restrictions_ms(restrictions_started_at.elapsed_ms());
        return false;
    }
    ctx.add_restrictions_ms(restrictions_started_at.elapsed_ms());

    let timing_started_at = PerfTimer::start();
    if !has_valid_spell_timing_with_view(game, player, spell_for_checks, spell_id, view)
        && !casting_method_grants_special_timing(ctx, spell_for_checks, spell_id, casting_method)
    {
        ctx.add_timing_ms(timing_started_at.elapsed_ms());
        return false;
    }
    ctx.add_timing_ms(timing_started_at.elapsed_ms());

    let target_started_at = PerfTimer::start();
    let effects = effects_override;
    let program = if effects_override.is_some() {
        None
    } else {
        spell_for_checks.spell_effect.as_deref()
    };
    // Not memoized: callers of this entry point supply their own spell view
    // for a given id, so (id, method, cost) does not pin the computation the
    // way it does on the primary cast path.
    let has_legal_targets =
        spell_has_legal_targets_for_cast_or_payable_optional_cost_hypothesis_with_view(
            game,
            spell_for_checks,
            spell_id,
            program,
            effects,
            player,
            mana_cost,
            casting_method,
        );
    ctx.add_target_legality_ms(target_started_at.elapsed_ms());
    if !has_legal_targets {
        return false;
    }

    let Some(player_obj) = game.player(player) else {
        return false;
    };

    // Check exile from graveyard requirement
    if requirements.exile_from_graveyard > 0 {
        let other_cards_in_graveyard = player_obj
            .graveyard
            .iter()
            .filter(|&&id| id != spell_id)
            .count();
        if other_cards_in_graveyard < requirements.exile_from_graveyard as usize {
            return false;
        }
    }

    // Check discard from hand requirement
    // For Jump-Start, need at least discard_from_hand cards in hand
    if requirements.discard_from_hand > 0
        && (player_obj.hand.len() as u32) < requirements.discard_from_hand
    {
        return false;
    }

    if !can_pay_non_mana_cost_sequence_for_cast(
        game,
        player,
        spell_id,
        spell_for_checks.additional_non_mana_costs(),
    ) {
        return false;
    }

    // Check TotalCost requirement (for Force of Will style costs)
    if let Some(ref total_cost) = requirements.total_cost {
        for individual_cost in total_cost.costs() {
            if !can_pay_cost_with_spell_exclusion(game, player, individual_cost, Some(spell_id)) {
                return false;
            }
        }
    }

    if let Some(cost) = mana_cost {
        let cost_started_at = PerfTimer::start();
        let has_cost_adjustments = spell_has_intrinsic_cost_adjustments(spell_for_checks)
            || !spell_granted_cost_static_abilities(game, spell_for_checks).is_empty()
            || matches!(
                casting_method.without_exact_permission(),
                CastingMethod::PlayFrom { .. }
                    | CastingMethod::SplitOtherHalfPlayFrom { .. }
                    | CastingMethod::FaceDownPlayFrom { .. }
            );
        let adjusted = if ctx.can_use_printed_cost_directly(has_cost_adjustments) {
            cost.clone()
        } else if ctx.spell_cost_needs_adjustment(has_cost_adjustments) {
            calculate_effective_mana_cost_with_view_for_casting_method(
                game,
                player,
                spell_for_checks,
                cost,
                casting_method,
                view,
            )
        } else {
            apply_minimum_spell_total_mana_with_view(
                view,
                &apply_payment_reason_mana_adjustments(
                    game,
                    player,
                    Some(spell_id),
                    cost,
                    crate::costs::PaymentReason::CastSpell,
                ),
            )
        };
        ctx.add_cost_adjustment_ms(cost_started_at.elapsed_ms());

        let affordability_started_at = PerfTimer::start();
        let selected_method =
            alternative_method_for_casting_method(game, player, spell_for_checks, casting_method);
        let can_pay_adjusted = if selected_method.as_ref().is_some_and(|method| {
            method.can_tap_creature_for_power_reduction()
        }) {
            let full_cost = calculate_effective_mana_cost_with_targets_internal(
                game,
                player,
                spell_for_checks,
                cost,
                0,
                &[],
                false,
                casting_method,
                None,
                view,
            );
            std::iter::once(None)
                .chain(
                    get_convoke_creatures(game, player)
                        .into_iter()
                        .map(|(id, _)| Some(id)),
                )
                .any(|resource| {
                    let reduction =
                        resource.map_or(0, |id| game.current_power(id).unwrap_or(0).max(0) as u32);
                    let reduced = apply_minimum_spell_total_mana_with_view(
                        view,
                        &full_cost.reduce_generic(reduction),
                    );
                    let mut request = crate::mana_payment::ManaPaymentRequest::new(
                        player,
                        spell_id,
                        crate::costs::PaymentReason::CastSpell,
                        reduced,
                    )
                    .with_spend_policy(crate::alternative_cast::play_permission::casting_spend_policy(game, player, spell_for_checks, casting_method));
                    request.reserved_tap_sources = resource.into_iter().collect();
                    with_cast_payment_proposal(game, player, spell_id, spell_for_checks, casting_method,
                        |proposed| resumable::check_payment(proposed, &request))
                })
        } else {
            mana_cost_can_be_paid_by_caster_or_assist_with_view(
                game, player, spell_for_checks, casting_method, &adjusted, view,
            )
        };
        let can_pay_with_optional_reduction = !can_pay_adjusted
            && effective_cost_with_affordable_optional_cost_hypothesis(
                game,
                player,
                spell_for_checks,
                cost,
                casting_method,
            )
            .is_some_and(|optional_adjusted| {
                mana_cost_can_be_paid_by_caster_or_assist_with_view(
                    game,
                    player,
                    spell_for_checks,
                    casting_method,
                    &optional_adjusted,
                    view,
                )
            });
        let can_pay_with_sacrifice_reduction = !can_pay_adjusted
            && !can_pay_with_optional_reduction
            && affordable_with_max_cost_payment_sacrifice_reduction(
                game,
                player,
                spell_for_checks,
                spell_id,
                casting_method,
                &adjusted,
                view,
            );
        if !can_pay_adjusted
            && !can_pay_with_optional_reduction
            && !can_pay_with_sacrifice_reduction
        {
            ctx.add_affordability_ms(affordability_started_at.elapsed_ms());
            return false;
        }
        ctx.add_affordability_ms(affordability_started_at.elapsed_ms());
    }

    true
}

pub(crate) fn provisional_casting_method_for_alternative(
    spell: &crate::object::Object,
    method: &crate::alternative_cast::AlternativeCastingMethod,
) -> CastingMethod {
    if let Some(index) = spell
        .alternative_casts
        .iter()
        .position(|candidate| candidate == method)
    {
        return CastingMethod::Alternative(index);
    }

    match method {
        crate::alternative_cast::AlternativeCastingMethod::Escape { exile_count, .. } => {
            CastingMethod::GrantedEscape {
                source: spell.id,
                exile_count: *exile_count,
            }
        }
        crate::alternative_cast::AlternativeCastingMethod::Flashback { .. } => {
            CastingMethod::GrantedFlashback
        }
        _ => CastingMethod::Normal,
    }
}

/// Build additional cast requirements from an alternative casting method.
pub(crate) fn build_requirements_for_method(
    method: &crate::alternative_cast::AlternativeCastingMethod,
) -> AdditionalCastRequirements {
    let method_requirements = method.requirements();
    AdditionalCastRequirements {
        exile_from_graveyard: method_requirements.exile_from_graveyard,
        discard_from_hand: method_requirements.discard_from_hand,
        ..Default::default()
    }
}

/// Get the mana cost for an alternative casting method.
pub(crate) fn get_mana_cost_for_method<'a>(
    method: &'a crate::alternative_cast::AlternativeCastingMethod,
    spell: &'a crate::object::Object,
) -> Option<&'a crate::mana::ManaCost> {
    // Composed costs can intentionally represent "without paying its mana cost"
    // by omitting a mana component, so do not fall back to the card's printed cost.
    if method.is_composed_cost()
        || method.total_cost().is_some()
        || matches!(
            method,
            crate::alternative_cast::AlternativeCastingMethod::FromZone { .. }
        )
    {
        return method.mana_cost();
    }

    // Method's cost takes priority, fallback to spell's cost for methods that
    // explicitly say they reuse the spell's normal mana cost.
    method.mana_cost().or(spell.mana_cost.as_deref())
}

pub(crate) fn spell_view_for_disturb_cast(
    game: &GameState,
    spell: &crate::object::Object,
) -> Option<crate::object::Object> {
    let already_overlaid_disturb_spell = spell
        .cast_alternative_method
        .as_deref()
        .is_some_and(|method| method.casts_transformed())
        && !spell
            .alternative_casts
            .iter()
            .any(|method| method.casts_transformed());
    if already_overlaid_disturb_spell {
        let mut view = spell.clone();
        view.ensure_aura_cast_spell_effect();
        return Some(view);
    }

    let other_def = game
        .linked_face_definition_by_name_or_id(spell.other_face_name.as_deref(), spell.other_face)?;
    // The back face's color comes from its own color indicator (CR 712.8e).
    let mut view = spell.clone();
    view.apply_definition_face(&other_def);
    view.ensure_aura_cast_spell_effect();
    Some(view)
}

pub(crate) fn spell_view_for_face_down_cast(
    game: &GameState,
    spell: &crate::object::Object,
) -> crate::object::Object {
    let mut view = spell.clone();
    let disguise_ward = face_down_cast_uses_disguise(game, spell);
    view.apply_face_down_cast_overlay_with_disguise_ward(disguise_ward);
    view
}

/// Whether a face-down cast of `spell` is a disguise cast, whose face-down
/// spell has ward {2} (CR 702.168a).
///
/// The caster decides this when choosing the casting permission. In peer
/// matches the face-down cast command carries the kind publicly (the card
/// itself stays hidden), so every peer reaches the same answer here from
/// [`face_down_cast_kind`]. The result is then stored publicly on the
/// face-down state (`FaceDownCastState::disguise_ward`) and never re-derived.
pub fn face_down_cast_uses_disguise(game: &GameState, spell: &crate::object::Object) -> bool {
    face_down_cast_kind(game, spell).is_some_and(crate::game_state::FaceDownCastKind::grants_ward)
}

pub(crate) fn linked_face_definition(
    game: &GameState,
    spell: &crate::object::Object,
) -> Option<crate::cards::CardDefinition> {
    game.linked_face_definition_by_name_or_id(spell.other_face_name.as_deref(), spell.other_face)
}

pub fn linked_other_face_land_definition(
    game: &GameState,
    spell: &crate::object::Object,
) -> Option<crate::cards::CardDefinition> {
    if spell.linked_face_layout != crate::card::LinkedFaceLayout::TransformLike
        || spell.has_card_type(crate::types::CardType::Land)
    {
        return None;
    }

    linked_face_definition(game, spell).filter(|def| {
        // CR 712.12 vs 712.8a: only a modal DFC can be played using its
        // back face; a transforming DFC is played front face up.
        !def.card.transforming_dfc && def.card.card_types.contains(&crate::types::CardType::Land)
    })
}

/// CR 712.12: a player playing a modal double-faced card as a land chooses
/// one of its faces that's a land. When the front face is itself a land and
/// the back face is also a land (the Pathways), this is the back face; the
/// front face is played by an ordinary [`LegalAction::PlayLand`].
///
/// Outside the battlefield and the stack the card shows its front face
/// (CR 712.8a), so its linked face is its back face.
pub fn linked_back_face_land_definition(
    game: &GameState,
    card: &crate::object::Object,
) -> Option<crate::cards::CardDefinition> {
    if card.linked_face_layout != crate::card::LinkedFaceLayout::TransformLike
        || !card.has_card_type(crate::types::CardType::Land)
        || matches!(card.zone, Zone::Battlefield | Zone::Stack)
    {
        return None;
    }

    linked_face_definition(game, card).filter(|def| {
        // A transforming DFC (Havengul Laboratory) is played front face up
        // (CR 712.8a); only a modal DFC chooses its land face.
        !def.card.transforming_dfc && def.card.card_types.contains(&crate::types::CardType::Land)
    })
}

/// The face a land play puts onto the battlefield, if it isn't the card's
/// current face: the back face when explicitly chosen, or the linked land
/// face of a card whose front face isn't a land. `Err` when the chosen face
/// isn't a land.
pub(crate) fn land_play_face_definition(
    game: &GameState,
    card: &crate::object::Object,
    back_face: bool,
) -> Result<Option<crate::cards::CardDefinition>, ()> {
    if back_face {
        return linked_back_face_land_definition(game, card)
            .map(Some)
            .ok_or(());
    }
    if card.has_card_type(crate::types::CardType::Land) {
        return Ok(None);
    }
    linked_other_face_land_definition(game, card)
        .map(Some)
        .ok_or(())
}

pub(crate) fn spell_has_adventure_half(game: &GameState, spell: &crate::object::Object) -> bool {
    linked_face_definition(game, spell).is_some_and(|def| {
        def.card
            .subtypes
            .contains(&crate::types::Subtype::Adventure)
            && (def
                .card
                .card_types
                .contains(&crate::types::CardType::Instant)
                || def
                    .card
                    .card_types
                    .contains(&crate::types::CardType::Sorcery))
    })
}

pub(crate) fn spell_has_castable_linked_other_half(
    game: &GameState,
    spell: &crate::object::Object,
) -> bool {
    if spell.linked_face_layout == crate::card::LinkedFaceLayout::Split
        || spell_has_adventure_half(game, spell)
    {
        return true;
    }

    // CR 712.11: only a modal DFC is cast using its back face.
    spell.linked_face_layout == crate::card::LinkedFaceLayout::TransformLike
        && linked_face_definition(game, spell)
            .is_some_and(|def| !def.card.transforming_dfc && def.card.mana_cost.is_some())
}

pub(crate) fn spell_view_for_split_other_half_cast(
    game: &GameState,
    spell: &crate::object::Object,
) -> Option<crate::object::Object> {
    if !spell_has_castable_linked_other_half(game, spell) {
        return None;
    }
    let other_def = linked_face_definition(game, spell)?;
    // CR 702.127a: an aftermath half "can't be cast from any zone other than a
    // graveyard" (a cast in progress has already moved to the stack).
    if definition_casts_only_from_graveyard(&other_def) && !matches!(spell.zone, Zone::Graveyard | Zone::Stack)
    {
        return None;
    }
    let mut view = spell.clone();
    view.apply_definition_face(&other_def);
    view.ensure_aura_cast_spell_effect();
    // CR 709.3a: only the half being cast is evaluated.
    view.split_combined = None;
    Some(view)
}

/// A zone restriction belongs to the selected half, regardless of its keyword name.
pub(crate) fn definition_casts_only_from_graveyard(def: &crate::cards::CardDefinition) -> bool {
    def.abilities.iter().any(|ability| {
        let crate::ability::AbilityKind::Static(ability) = &ability.kind else { return false; };
        ability.this_spell_cast_restriction_kind().is_some_and(|kind| matches!(
            kind.condition,
            Some(crate::static_abilities::ThisSpellCastCondition::Condition(
                ironsmith_core::Condition::SourceIsInZone(crate::zone::Zone::Graveyard)
            ))
        ))
    })
}

pub(crate) fn spell_view_for_fused_split_cast(
    game: &GameState,
    spell: &crate::object::Object,
) -> Option<crate::object::Object> {
    if spell.linked_face_layout != crate::card::LinkedFaceLayout::Split || !spell.can_combine_split_halves() {
        return None;
    }
    let other_def = linked_face_definition(game, spell)?;
    let mut view = spell.clone();
    view.apply_fused_split_spell_overlay(&other_def);
    Some(view)
}

pub(crate) fn can_cast_with_alternative_with_view(
    game: &GameState,
    player: PlayerId,
    spell: &crate::object::Object,
    method: &crate::alternative_cast::AlternativeCastingMethod,
    view: &DerivedGameView<'_>,
) -> bool {
    let ctx = CastLegalityContext::new(game, player, view);
    can_cast_with_alternative_with_context(spell, method, &ctx)
}

pub(crate) fn can_cast_with_alternative_with_context(
    spell: &crate::object::Object,
    method: &crate::alternative_cast::AlternativeCastingMethod,
    ctx: &CastLegalityContext<'_>,
) -> bool {
    use crate::alternative_cast::AlternativeCastingMethod;
    let game = ctx.game;
    let player = ctx.player;

    if spell.zone != Zone::Stack && crate::alternative_cast::has_selected_price_characteristics(method) {
        let mut candidate = spell.clone();
        let index = candidate.alternative_casts.iter().position(|known| known == method).unwrap_or_else(|| {
            let index = candidate.alternative_casts.len();
            candidate.alternative_casts.push(method.clone());
            index
        });
        if let Some(preview) = selected_characteristic_preview(game, player, &candidate, &CastingMethod::Alternative(index)) {
            return match preview {
                Ok((preview, id)) => {
                    let view = DerivedGameView::new(&preview);
                    can_cast_with_alternative_with_context(preview.object(id).unwrap(), method,
                        &CastLegalityContext::new(&preview, player, &view))
                }
                Err(crate::game_loop::GameLoopError::ExecutionFailed(error)) => { game.record_token_resource_failure(&error); false }
                Err(_) => false,
            };
        }
    }

    let disturbed_view = match method {
        method if method.casts_transformed() => match spell_view_for_disturb_cast(game, spell) {
            Some(view) => Some(view),
            None => return false,
        },
        _ => None,
    };
    let disturbed_view =
        without_combined_split_characteristics(disturbed_view, spell, &CastingMethod::Normal);
    let base_spell_for_checks = disturbed_view.as_ref().unwrap_or(spell);
    let provisional_alternative_spell = (!base_spell_for_checks
        .alternative_casts
        .iter()
        .any(|candidate| candidate == method))
    .then(|| {
        let mut view = base_spell_for_checks.clone();
        view.cast_alternative_method = Some(Box::new(method.clone()));
        view
    });
    let spell_for_checks = provisional_alternative_spell
        .as_ref()
        .unwrap_or(base_spell_for_checks);
    let effects_override = method
        .overload_effects()
        .or_else(|| method.cleave_effects())
        .or_else(|| method.awaken_effects())
        .or_else(|| {
            disturbed_view
                .as_ref()
                .and_then(|view| view.spell_effect.as_deref())
                .map(|program| &**program)
        });
    if !crate::alternative_cast::land_play_price_is_available(game, player, method) {
        return false;
    }
    if spell.zone != Zone::Stack && !crate::alternative_cast::hand_event_price_is_available(game,spell.id,method) {return false;}
    if method.uses_first_draw_reveal() && spell.zone != Zone::Stack
        && !game.miracle_cast_is_authorized(spell.id) { return false; }
    if method.discard_exile_cast_cost().is_some()
        && spell.zone != Zone::Stack && !game.madness_cast_is_authorized(spell.id, player) { return false; }
    if let Some(window) = method.battlefield_instructions().casting_window
        && !this_spell_cast_timing_allows(game, player, window)
    { return false; }
    let free_plot_cost = crate::mana::ManaCost::new();
    if let Some(condition) = method.cast_condition()
        && !crate::static_abilities::this_spell_cost_condition_is_active_for_player(
            game,
            spell.id,
            player,
            condition,
            &[],
        )
    {
        return false;
    }
    let mana_cost = match method {
        method if method.prepares_face_down() => {
            // CR 702.143a/d: only the card's owner, and only after the turn it
            // became foretold has ended (the stack shortcut covers a cast in
            // progress, as for Plot).
            if spell.zone != Zone::Stack
                && (!game.foretold_card_is_castable(spell.id) || spell.owner != player)
            {
                return false;
            }
            get_mana_cost_for_method(method, spell_for_checks)
        }
        method if method.prepares_face_up_sorcery() => {
            if !game.is_prepared_face_up_by(spell.id, player) {
                return false;
            }
            let Some(plotted_turn) = game.plotted_turn(spell.id) else {
                return false;
            };
            if plotted_turn >= game.turn.turn_number {
                return false;
            }
            if !game.is_active_player(player) || !crate::turn::is_sorcery_timing(game) {
                return false;
            }
            Some(&free_plot_cost)
        }
        method if method.suspend_spec().is_some() => return false,
        // CR 702.35a: only the madness trigger grants permission, only to the
        // card's owner, and only while that trigger resolves.
        AlternativeCastingMethod::Madness { .. } => {
            if spell.zone != Zone::Stack && !game.madness_cast_is_authorized(spell.id, player) {
                return false;
            }
            get_mana_cost_for_method(method, spell_for_checks)
        }
        // CR 702.94a: the miracle cost is available only while the miracle
        // trigger ("when you reveal this card this way") resolves, never at
        // ordinary priority.
        AlternativeCastingMethod::Miracle { .. } => {
            if spell.zone != Zone::Stack && !game.miracle_cast_is_authorized(spell.id) {
                return false;
            }
            get_mana_cost_for_method(method, spell_for_checks)
        }
        _ => get_mana_cost_for_method(method, spell_for_checks),
    };
    if mana_cost.is_none() && alternative_method_uses_printed_mana_cost(method) {
        return false;
    }
    let mana_cost = mana_cost.cloned();

    let requirements = build_requirements_for_method(method);
    let casting_method = provisional_casting_method_for_alternative(spell, method);
    if !can_cast_with_cost_with_context(
        spell_for_checks,
        spell.id,
        mana_cost.as_ref(),
        effects_override,
        &requirements,
        &casting_method,
        ctx,
    ) {
        return false;
    }

    if !can_pay_non_mana_cost_sequence_for_cast(game, player, spell.id, method.non_mana_costs()) {
        return false;
    }

    true
}

pub(crate) fn can_pay_non_mana_cost_sequence_for_cast(
    game: &GameState,
    player: PlayerId,
    source: ObjectId,
    costs: Vec<crate::costs::Cost>,
) -> bool {
    crate::cost::can_pay_cost_with_reason(
        game,
        source,
        player,
        &crate::cost::TotalCost::from_costs(costs),
        crate::costs::PaymentReason::CastSpell,
    )
    .is_ok()
}

/// Check if a spell can be cast with an alternative cost from hand (e.g., Force of Will).
pub fn can_cast_with_alternative_from_hand(
    game: &GameState,
    player: PlayerId,
    spell: &crate::object::Object,
    spell_id: crate::ids::ObjectId,
    method: &crate::alternative_cast::AlternativeCastingMethod,
) -> bool {
    let view = DerivedGameView::new(game);
    can_cast_with_alternative_from_hand_with_view(game, player, spell, spell_id, method, &view)
}

pub(crate) fn can_cast_with_alternative_from_hand_with_view(
    game: &GameState,
    player: PlayerId,
    spell: &crate::object::Object,
    spell_id: crate::ids::ObjectId,
    method: &crate::alternative_cast::AlternativeCastingMethod,
    view: &DerivedGameView<'_>,
) -> bool {
    let ctx = CastLegalityContext::new(game, player, view);
    can_cast_with_alternative_from_hand_with_context(spell, spell_id, method, &ctx)
}

pub(crate) fn can_cast_with_alternative_from_hand_with_context(
    spell: &crate::object::Object,
    spell_id: crate::ids::ObjectId,
    method: &crate::alternative_cast::AlternativeCastingMethod,
    ctx: &CastLegalityContext<'_>,
) -> bool {
    use crate::alternative_cast::AlternativeCastingMethod;
    let game = ctx.game;
    let player = ctx.player;

    if method.casts_transformed() {
        return can_cast_with_alternative_with_context(spell, method, ctx);
    }

    match method {
        method if method.is_composed_cost() => {
            if !crate::alternative_cast::land_play_price_is_available(game, player, method) {
                return false;
            }
            let zero_cost = crate::mana::ManaCost::new();
            let casting_method = provisional_casting_method_for_alternative(spell, method);
            let mana_cost = Some(method.mana_cost().unwrap_or(&zero_cost).clone());
            if let Some(condition) = method.cast_condition()
                && !crate::static_abilities::this_spell_cost_condition_is_active_for_player(
                    game,
                    spell_id,
                    player,
                    condition,
                    &[],
                )
            {
                return false;
            }

            if !can_cast_with_cost_with_context(
                spell,
                spell_id,
                mana_cost.as_ref(),
                None,
                &AdditionalCastRequirements::default(),
                &casting_method,
                ctx,
            ) {
                return false;
            }

            can_pay_non_mana_cost_sequence_for_cast(game, player, spell_id, method.non_mana_costs())
        }
        AlternativeCastingMethod::Bestow { total_cost } => {
            let Some(cost) = total_cost.mana_cost() else {
                return false;
            };
            let casting_method = provisional_casting_method_for_alternative(spell, method);

            if !can_cast_with_cost_with_context(
                spell,
                spell_id,
                Some(cost),
                None,
                &AdditionalCastRequirements::default(),
                &casting_method,
                ctx,
            ) {
                return false;
            }

            if !can_pay_non_mana_cost_sequence_for_cast(
                game,
                player,
                spell_id,
                method.non_mana_costs(),
            ) {
                return false;
            }

            let bestow_spec = ChooseSpec::Object(crate::target::ObjectFilter::creature());
            let bestow_targets =
                crate::targeting::compute_legal_targets_with_tagged_objects_with_view(
                    game,
                    &bestow_spec,
                    player,
                    Some(spell_id),
                    None,
                    ctx.view,
                );
            !bestow_targets.is_empty()
        }
        AlternativeCastingMethod::Trap {
            cost, condition, ..
        } => {
            // Check if the trap condition is met
            if !is_trap_condition_met(game, player, condition) {
                return false;
            }
            // Check if player can pay the trap cost (usually {0})
            let casting_method = provisional_casting_method_for_alternative(spell, method);
            can_cast_with_cost_with_context(
                spell,
                spell_id,
                Some(cost),
                None,
                &AdditionalCastRequirements::default(),
                &casting_method,
                ctx,
            )
        }
        _ => can_cast_with_alternative_with_context(spell, method, ctx),
    }
}

/// Check if a trap condition is met for the given player.
pub(crate) fn is_trap_condition_met(
    game: &GameState,
    player: PlayerId,
    condition: &crate::alternative_cast::TrapCondition,
) -> bool {
    use crate::alternative_cast::TrapCondition;

    // Get all opponents
    let opponents: Vec<PlayerId> = game
        .players
        .iter()
        .filter(|p| p.id != player && p.is_in_game())
        .map(|p| p.id)
        .collect();

    match condition {
        TrapCondition::OpponentCastSpells { count } => {
            // Check if any opponent cast N or more spells this turn
            opponents
                .iter()
                .any(|&opp| game.turn_store.turn_history.spells_cast_by_player(opp) >= *count)
        }
        TrapCondition::OpponentSearchedLibrary => {
            // Check if any opponent searched their library this turn
            opponents.iter().any(|opp| {
                game.turn_store
                    .turn_history
                    .player_searched_library_this_turn(*opp)
            })
        }
        TrapCondition::OpponentCreatureEntered => {
            // Check if any opponent had a creature enter the battlefield this turn
            opponents.iter().any(|&opp| {
                game.turn_store
                    .turn_history
                    .player_had_creature_enter_battlefield_this_turn(opp)
            })
        }
        TrapCondition::CreatureDealtDamageToYou => {
            // Check if any creature dealt damage to the player this turn
            game.turn_store
                .turn_history
                .player_was_dealt_damage_by_creature_this_turn(player)
        }
    }
}

/// Check if a player can pay a specific cost, excluding a specific card from hand (the spell being cast).
pub(crate) fn can_pay_cost_with_spell_exclusion(
    game: &GameState,
    player: PlayerId,
    cost: &crate::costs::Cost,
    spell_to_exclude: Option<crate::ids::ObjectId>,
) -> bool {
    use crate::costs::CostProcessingMode;

    let source = spell_to_exclude.or_else(|| {
        game.player(player).and_then(|p| {
            p.hand
                .first()
                .copied()
                .or_else(|| p.graveyard.first().copied())
        })
    });
    let Some(source) = source else {
        return false;
    };

    let mut dm = crate::decision::CliDecisionMaker;
    let ctx = crate::costs::CostContext::new(source, player, &mut dm)
        .with_reason(crate::costs::PaymentReason::CastSpell);
    if game
        .validate_cost_for_payment_reason(player, source, cost, ctx.reason)
        .is_err()
    {
        return false;
    }

    match cost.processing_mode() {
        CostProcessingMode::ManaPayment { .. } => cost.can_potentially_pay(game, &ctx).is_ok(),
        CostProcessingMode::Immediate
        | CostProcessingMode::InlineWithTriggers
        | CostProcessingMode::SacrificeTarget { .. }
        | CostProcessingMode::DiscardCards { .. }
        | CostProcessingMode::ExileFromHand { .. }
        | CostProcessingMode::ExileFromGraveyard { .. }
        | CostProcessingMode::ExileObjects { .. }
        | CostProcessingMode::RevealFromHand { .. }
        | CostProcessingMode::ReturnToHandTarget { .. } => cost.can_pay(game, &ctx).is_ok(),
    }
}

pub(crate) fn apply_payment_reason_mana_adjustments(
    game: &GameState,
    payer: PlayerId,
    source: Option<ObjectId>,
    cost: &crate::mana::ManaCost,
    reason: crate::costs::PaymentReason,
) -> crate::mana::ManaCost {
    game.adjust_mana_cost_for_payment_reason(payer, source, cost, reason)
}

pub(crate) fn apply_minimum_spell_total_mana_with_view(
    view: &DerivedGameView<'_>,
    cost: &crate::mana::ManaCost,
) -> crate::mana::ManaCost {
    if let Some(minimum) = view.minimum_total_spell_mana_payment()
        && cost.mana_value() < minimum
    {
        return cost.add_generic(minimum - cost.mana_value());
    }

    cost.clone()
}

// ============================================================================
// Cost Modifier Helpers (Tier 9)
// ============================================================================

/// Calculate the total mana cost after increases, reductions, and minimums.
/// Delve, Convoke, and Improvise pay that total through the mana planner;
/// their resources are not subtracted here.
pub fn calculate_effective_mana_cost(
    game: &GameState,
    player: PlayerId,
    spell: &crate::object::Object,
    base_cost: &crate::mana::ManaCost,
) -> crate::mana::ManaCost {
    calculate_effective_mana_cost_for_casting_method(
        game,
        player,
        spell,
        base_cost,
        &CastingMethod::Normal,
    )
}

pub fn calculate_effective_mana_cost_for_casting_method(
    game: &GameState,
    player: PlayerId,
    spell: &crate::object::Object,
    base_cost: &crate::mana::ManaCost,
    casting_method: &CastingMethod,
) -> crate::mana::ManaCost {
    let view = DerivedGameView::new(game);
    calculate_effective_mana_cost_with_targets_internal(
        game,
        player,
        spell,
        base_cost,
        1,
        &[],
        true,
        casting_method,
        None,
        &view,
    )
}

pub(crate) fn calculate_effective_mana_cost_with_view_for_casting_method(
    game: &GameState,
    player: PlayerId,
    spell: &crate::object::Object,
    base_cost: &crate::mana::ManaCost,
    casting_method: &CastingMethod,
    view: &DerivedGameView<'_>,
) -> crate::mana::ManaCost {
    calculate_effective_mana_cost_with_targets_internal(
        game,
        player,
        spell,
        base_cost,
        1,
        &[],
        true,
        casting_method,
        None,
        view,
    )
}

/// Calculate the effective mana cost with explicit chosen target count.
pub fn calculate_effective_mana_cost_with_targets(
    game: &GameState,
    player: PlayerId,
    spell: &crate::object::Object,
    base_cost: &crate::mana::ManaCost,
    chosen_target_count: usize,
) -> crate::mana::ManaCost {
    let view = DerivedGameView::new(game);
    calculate_effective_mana_cost_with_targets_internal(
        game,
        player,
        spell,
        base_cost,
        chosen_target_count,
        &[],
        true,
        &CastingMethod::Normal,
        None,
        &view,
    )
}

/// Calculate the effective mana cost using the exact chosen targets.
pub fn calculate_effective_mana_cost_with_chosen_targets(
    game: &GameState,
    player: PlayerId,
    spell: &crate::object::Object,
    base_cost: &crate::mana::ManaCost,
    chosen_targets: &[Target],
) -> crate::mana::ManaCost {
    calculate_effective_mana_cost_with_chosen_targets_for_casting_method(
        game,
        player,
        spell,
        base_cost,
        chosen_targets,
        &CastingMethod::Normal,
    )
}

pub fn calculate_effective_mana_cost_with_chosen_targets_for_casting_method(
    game: &GameState,
    player: PlayerId,
    spell: &crate::object::Object,
    base_cost: &crate::mana::ManaCost,
    chosen_targets: &[Target],
    casting_method: &CastingMethod,
) -> crate::mana::ManaCost {
    let view = DerivedGameView::new(game);
    calculate_effective_mana_cost_with_targets_internal(
        game,
        player,
        spell,
        base_cost,
        chosen_targets.len(),
        chosen_targets,
        true,
        casting_method,
        None,
        &view,
    )
}

pub(crate) fn calculate_effective_mana_cost_with_chosen_targets_for_casting_method_from_zone(
    game: &GameState,
    player: PlayerId,
    spell: &crate::object::Object,
    base_cost: &crate::mana::ManaCost,
    chosen_targets: &[Target],
    casting_method: &CastingMethod,
    cast_from_zone: Zone,
) -> crate::mana::ManaCost {
    let view = DerivedGameView::new(game);
    calculate_effective_mana_cost_with_targets_internal(
        game,
        player,
        spell,
        base_cost,
        chosen_targets.len(),
        chosen_targets,
        true,
        casting_method,
        Some(cast_from_zone),
        &view,
    )
}

/// Calculate effective cost for payment stage where Convoke/Improvise are handled
/// as pip alternatives instead of up-front reductions.
pub fn calculate_effective_mana_cost_for_payment_with_targets(
    game: &GameState,
    player: PlayerId,
    spell: &crate::object::Object,
    base_cost: &crate::mana::ManaCost,
    chosen_target_count: usize,
) -> crate::mana::ManaCost {
    calculate_effective_mana_cost_for_payment_with_targets_for_casting_method(
        game,
        player,
        spell,
        base_cost,
        chosen_target_count,
        &CastingMethod::Normal,
    )
}

pub fn calculate_effective_mana_cost_for_payment_with_targets_for_casting_method(
    game: &GameState,
    player: PlayerId,
    spell: &crate::object::Object,
    base_cost: &crate::mana::ManaCost,
    chosen_target_count: usize,
    casting_method: &CastingMethod,
) -> crate::mana::ManaCost {
    let view = DerivedGameView::new(game);
    calculate_effective_mana_cost_with_targets_internal(
        game,
        player,
        spell,
        base_cost,
        chosen_target_count,
        &[],
        false,
        casting_method,
        None,
        &view,
    )
}

/// Calculate payment-stage effective cost using exact chosen targets.
pub fn calculate_effective_mana_cost_for_payment_with_chosen_targets(
    game: &GameState,
    player: PlayerId,
    spell: &crate::object::Object,
    base_cost: &crate::mana::ManaCost,
    chosen_targets: &[Target],
) -> crate::mana::ManaCost {
    calculate_effective_mana_cost_for_payment_with_chosen_targets_for_casting_method(
        game,
        player,
        spell,
        base_cost,
        chosen_targets,
        &CastingMethod::Normal,
    )
}

pub fn calculate_effective_mana_cost_for_payment_with_chosen_targets_for_casting_method(
    game: &GameState,
    player: PlayerId,
    spell: &crate::object::Object,
    base_cost: &crate::mana::ManaCost,
    chosen_targets: &[Target],
    casting_method: &CastingMethod,
) -> crate::mana::ManaCost {
    let view = DerivedGameView::new(game);
    calculate_effective_mana_cost_with_targets_internal(
        game,
        player,
        spell,
        base_cost,
        chosen_targets.len(),
        chosen_targets,
        false,
        casting_method,
        None,
        &view,
    )
}

pub(crate) fn calculate_effective_mana_cost_for_payment_with_chosen_targets_for_casting_method_from_zone(
    game: &GameState,
    player: PlayerId,
    spell: &crate::object::Object,
    base_cost: &crate::mana::ManaCost,
    chosen_targets: &[Target],
    casting_method: &CastingMethod,
    cast_from_zone: Zone,
) -> crate::mana::ManaCost {
    let view = DerivedGameView::new(game);
    calculate_effective_mana_cost_with_targets_internal(
        game,
        player,
        spell,
        base_cost,
        chosen_targets.len(),
        chosen_targets,
        false,
        casting_method,
        Some(cast_from_zone),
        &view,
    )
}

/// Bind a source-wide tap substitution only after all increases, reductions and minima.
fn with_source_generic_tap_payment(
    game:&GameState, payer:PlayerId, source:&crate::object::Object,
    cost:crate::mana::ManaCost, activation:bool,
)->crate::mana::ManaCost {
    if activation && (source.zone!=Zone::Battlefield || !game.object(source.id).is_some_and(|actual|
        actual.zone==Zone::Battlefield && actual.stable_id==source.stable_id)) {return cost}
    fn policy(game:&GameState,payer:PlayerId,source:ObjectId,model:&crate::static_abilities::CompiledStaticAbility,activation:bool)->Option<ironsmith_core::mana::TapPaymentMethod>{
        match &model.payload {
            ironsmith_core::StaticAbilityPayload::GenericManaTapPayment {spells,activated_abilities,exclude_source,name,..}
                if (activation && *activated_abilities) || (!activation && *spells) => Some(ironsmith_core::mana::TapPaymentMethod {name:name.clone(),exclude_source:*exclude_source}),
            ironsmith_core::StaticAbilityPayload::Conditional {ability,condition,..}
                if crate::condition_eval::evaluate_condition_cast_time(game,condition,payer,source)=>policy(game,payer,source,ability,activation),
            _=>None,
        }
    }
    let mut methods=Vec::new();
    for ability in game.current_abilities(source.id).unwrap_or_else(||source.abilities_vec()) {
        if let crate::ability::AbilityKind::Static(rule)=&ability.kind
            && let Some(model)=rule.compiled_model()
            && let Some(method)=policy(game,payer,source.id,model,activation)
            && !methods.contains(&method) {methods.push(method);}
    }
    if methods.is_empty() {cost} else {cost.with_creature_tap_payment_methods(methods)}
}

/// Attach intrinsic spending conditions while the selected price still has
/// its X symbols. The same helper is idempotent after expansion/modification.
pub(crate) fn with_spell_mana_spending_rules(
    game: &GameState,
    player: PlayerId,
    spell: &crate::object::Object,
    base_cost: &crate::mana::ManaCost,
) -> crate::mana::ManaCost {
    fn active_spending_rule<'a>(
        game: &GameState,
        player: PlayerId,
        source: ObjectId,
        model: &'a crate::static_abilities::CompiledStaticAbility,
    ) -> Option<&'a ironsmith_core::mana::ManaSpendingRestriction> {
        match &model.payload {
            ironsmith_core::StaticAbilityPayload::SpellManaSpendingRestriction(rule) => Some(rule),
            ironsmith_core::StaticAbilityPayload::Conditional { ability, condition, .. }
                if crate::condition_eval::evaluate_condition_cast_time(
                    game, condition, player, source,
                ) =>
            {
                active_spending_rule(game, player, source, ability)
            }
            _ => None,
        }
    }
    let mut base_cost = base_cost.clone();
    // Cost-time grants use the same prospective spell view as convoke and
    // improvise. A granted counter-payment rule must affect legality too.
    for ability in spell_granted_cost_static_abilities(game, spell) {
        if let Some(model) = ability.compiled_model()
            && let Some(rule) = active_spending_rule(game, player, spell.id, model)
        { base_cost = base_cost.with_spending_restriction(rule.clone()); }
    }
    for ability in spell.abilities.iter() {
        if let AbilityKind::Static(ability) = &ability.kind
            && let Some(model) = ability.compiled_model()
            && let Some(rule) = active_spending_rule(game, player, spell.id, model)
        {
            base_cost = base_cost.with_spending_restriction(rule.clone());
        }
    }
    base_cost
}

pub(crate) fn calculate_effective_mana_cost_with_targets_internal(
    game: &GameState,
    player: PlayerId,
    spell: &crate::object::Object,
    base_cost: &crate::mana::ManaCost,
    chosen_target_count: usize,
    chosen_targets: &[Target],
    preview_resource_reductions: bool,
    casting_method: &CastingMethod,
    cast_from_zone: Option<Zone>,
    view: &DerivedGameView<'_>,
) -> crate::mana::ManaCost {
    // CR 601.2f: gather every increase and reduction first (affinity, the
    // spell's own modifiers, and battlefield modifiers such as Sphere of
    // Resistance), then add all increases before subtracting reductions, so
    // surplus reductions absorb taxes and the {0} floor applies only once.
    let mut totals = collect_spell_cost_modifiers(
        game,
        player,
        spell,
        chosen_target_count,
        chosen_targets,
        casting_method,
        cast_from_zone,
    );
    if let Some(method) = alternative_method_for_casting_method(game, player, spell, casting_method) {
        let ctx = game.filter_context_for(player, Some(spell.id));
        for (amount, filter) in &method.battlefield_instructions().generic_cost_reductions {
            let count = game.objects_in_deterministic_order().into_iter()
                .filter(|object| filter.matches(object, &ctx, game)).count() as u32;
            totals.add_generic_reduction(amount.saturating_mul(count));
        }
    }
    totals.add_generic_reduction(affinity_for_artifacts_reduction_with_view(
        game, player, spell, view,
    ));
    totals.merge(collect_battlefield_spell_cost_modifiers(
        game,
        player,
        spell,
        chosen_target_count,
        chosen_targets,
        casting_method,
        cast_from_zone,
        view,
    ));
    let base_cost = with_spell_mana_spending_rules(game, player, spell, base_cost);
    let mut current_cost = totals.apply(&base_cost);

    if preview_resource_reductions {
        if spell.zone != Zone::Stack {
            if let Some(method) =
                alternative_method_for_casting_method(game, player, spell, casting_method)
            {
                let reduction = if method.can_tap_creature_for_power_reduction() {
                    get_convoke_creatures(game, player)
                        .iter()
                        .map(|(id, _)| game.current_power(*id).unwrap_or(0).max(0) as u32)
                        .max()
                        .unwrap_or(0)
                } else {
                    maximum_emerge_reduction(game, player, spell.id, &method)
                };
                current_cost = current_cost.reduce_generic(reduction);
            }
        }
        for optional in spell.optional_costs.iter().filter(|optional| {
            optional.kind.sacrifice_reduces_mana_cost_and_grants_timing()
                && spell
                    .optional_costs_paid
                    .was_paid_label(optional.cost_ref())
        }) {
            if let Some(filter) = optional
                .cost
                .non_mana_costs()
                .find_map(|cost| cost.sacrifice_filter())
            {
                let ctx = game.filter_context_for(player, Some(spell.id));
                current_cost = game
                    .battlefield
                    .iter()
                    .filter_map(|id| game.object(*id))
                    .filter(|object| {
                        filter.matches(object, &ctx, game) && game.can_be_sacrificed(object.id)
                    })
                    .filter_map(|object| crate::filter::object_current_mana_cost(game, object.id))
                    .flat_map(|cost| offering_mana_reduction_choices(&cost))
                    .map(|reduction| reduce_offering_mana_cost(&current_cost, &reduction))
                    .min_by_key(|cost| {
                        (
                            !mana_cost_can_be_paid_by_caster_or_assist_with_view(
                                game, player, spell, casting_method, cost, view,
                            ),
                            cost.mana_value(),
                        )
                    })
                    .unwrap_or(current_cost);
            }
        }
    }
    // CR 601.2f: lock the total before payment substitutions. Resource usage is
    // checked jointly by the planner, never subtracted independently here.
    let current_cost = apply_payment_reason_mana_adjustments(
        game,
        player,
        Some(spell.id),
        &current_cost,
        crate::costs::PaymentReason::CastSpell,
    );

    let current_cost=apply_minimum_spell_total_mana_with_view(view, &current_cost);
    with_source_generic_tap_payment(game,player,spell,current_cost,false)
}

fn chosen_targets_match_cost_filter(
    game: &GameState,
    filter: &crate::target::ObjectFilter,
    ctx: &crate::filter::FilterContext,
    chosen_targets: &[Target],
) -> bool {
    if let Some(count) = filter.target_count
        && (chosen_targets.len() < count.min
            || count
                .max
                .is_some_and(|maximum| chosen_targets.len() > maximum))
    {
        return false;
    }

    let requires_witnessed_target = filter.targets_player.is_some()
        || filter.targets_object.is_some()
        || filter.targets_only_player.is_some()
        || filter.targets_only_object.is_some();
    if !requires_witnessed_target {
        return true;
    }
    if chosen_targets.is_empty() {
        return false;
    }

    let matches_player = filter.targets_player.as_ref().is_none_or(|player_filter| {
        chosen_targets.iter().any(|target| match target {
            Target::Player(player) => player_filter.matches_player(*player, ctx),
            Target::Object(_) => false,
        })
    });
    let matches_object = filter.targets_object.as_ref().is_none_or(|object_filter| {
        chosen_targets.iter().any(|target| match target {
            Target::Object(object) => game
                .object(*object)
                .is_some_and(|object| object_filter.matches(object, ctx, game)),
            Target::Player(_) => false,
        })
    });
    if filter.targets_player.is_some() || filter.targets_object.is_some() {
        let matches = if filter.targets_any_of
            && filter.targets_player.is_some()
            && filter.targets_object.is_some()
        {
            matches_player || matches_object
        } else {
            matches_player && matches_object
        };
        if !matches {
            return false;
        }
    }

    if filter.targets_only_player.is_some() || filter.targets_only_object.is_some() {
        let every_target_matches = chosen_targets.iter().all(|target| {
            let matches_player = filter
                .targets_only_player
                .as_ref()
                .is_some_and(|player_filter| match target {
                    Target::Player(player) => player_filter.matches_player(*player, ctx),
                    Target::Object(_) => false,
                });
            let matches_object = filter
                .targets_only_object
                .as_ref()
                .is_some_and(|object_filter| match target {
                    Target::Object(object) => game
                        .object(*object)
                        .is_some_and(|object| object_filter.matches(object, ctx, game)),
                    Target::Player(_) => false,
                });
            if filter.targets_only_player.is_some() && filter.targets_only_object.is_some() {
                matches_player || matches_object
            } else if filter.targets_only_player.is_some() {
                matches_player
            } else {
                matches_object
            }
        });
        if !every_target_matches {
            return false;
        }
    }

    true
}

/// How many times a per-target cost modifier applies (CR 601.2f). "For each
/// target" counts every chosen target; "for each creature it targets"
/// (Battlefield Thaumaturge) carries the described kind in the modifier's
/// `targets_object` and counts the distinct chosen objects matching it.
fn cost_modifier_target_repetitions(
    game: &GameState,
    filter: &crate::target::ObjectFilter,
    ctx: &crate::filter::FilterContext,
    per_target: bool,
    chosen_target_count: usize,
    chosen_targets: &[Target],
) -> usize {
    if !per_target {
        return 1;
    }
    let Some(object_filter) = filter
        .targets_object
        .as_deref()
        .filter(|_| filter.targets_player.is_none() && !filter.targets_any_of)
    else {
        return chosen_target_count;
    };
    let mut matched = Vec::new();
    for target in chosen_targets {
        if let Target::Object(object_id) = target
            && !matched.contains(object_id)
            && game
                .object(*object_id)
                .is_some_and(|object| object_filter.matches(object, ctx, game))
        {
            matched.push(*object_id);
        }
    }
    matched.len()
}

/// Cost increases and reductions gathered from every source before any of
/// them is applied. CR 601.2f nets all increases and reductions against the
/// whole total and floors it at {0} once, so reductions from one source must
/// be able to absorb increases from another (affinity vs. Thalia).
#[derive(Debug, Clone, Default)]
pub(crate) struct SpellCostModifierTotals {
    pub(crate) total_increase: i32,
    pub(crate) total_reduction: i32,
    pub(crate) increase_pips: Vec<Vec<crate::mana::ManaSymbol>>,
    pub(crate) reduction_pips: Vec<Vec<crate::mana::ManaSymbol>>,
    /// Colored reductions without "reduces only the amount of colored mana":
    /// whatever the cost doesn't require of that color reduces generic mana
    /// instead (CR 118.7b-c).
    pub(crate) spilling_reduction_pips: Vec<Vec<crate::mana::ManaSymbol>>,
}

impl SpellCostModifierTotals {
    pub(crate) fn merge(&mut self, other: SpellCostModifierTotals) {
        self.total_increase = self.total_increase.saturating_add(other.total_increase);
        self.total_reduction = self.total_reduction.saturating_add(other.total_reduction);
        self.increase_pips.extend(other.increase_pips);
        self.reduction_pips.extend(other.reduction_pips);
        self.spilling_reduction_pips
            .extend(other.spilling_reduction_pips);
    }

    pub(crate) fn add_generic_reduction(&mut self, amount: u32) {
        self.total_reduction = self
            .total_reduction
            .saturating_add(i32::try_from(amount).unwrap_or(i32::MAX));
    }

    /// Adds every increase first, then subtracts every reduction.
    pub(crate) fn apply(self, cost: &crate::mana::ManaCost) -> crate::mana::ManaCost {
        use crate::mana::ManaCost;
        let mut adjusted = cost.clone();
        if !self.increase_pips.is_empty() {
            adjusted = add_mana_cost(&adjusted, &ManaCost::from_pips(self.increase_pips));
        }
        if self.total_increase > 0 {
            adjusted = add_generic_mana_cost(&adjusted, self.total_increase as u32);
        }
        if self.total_reduction > 0 {
            adjusted = adjusted.reduce_generic(self.total_reduction as u32);
        }
        if !self.reduction_pips.is_empty() {
            adjusted = reduce_mana_cost(&adjusted, &ManaCost::from_pips(self.reduction_pips));
        }
        if !self.spilling_reduction_pips.is_empty() {
            adjusted = reduce_mana_cost_spilling_to_generic(
                &adjusted,
                &ManaCost::from_pips(self.spilling_reduction_pips),
            );
        }
        adjusted
    }
}

/// Affinity for artifacts as a generic reduction to fold into the totals.
pub(crate) fn affinity_for_artifacts_reduction_with_view(
    game: &GameState,
    player: PlayerId,
    spell: &crate::object::Object,
    view: &DerivedGameView<'_>,
) -> u32 {
    let intrinsic = spell.abilities.iter().filter(|ability| matches!(
        &ability.kind, crate::ability::AbilityKind::Static(ability)
            if ability.id() == crate::static_abilities::StaticAbilityId::AffinityForArtifacts
    )).count();
    let granted = spell_granted_cost_static_abilities(game, spell)
        .iter()
        .filter(|ability| {
            ability.id() == crate::static_abilities::StaticAbilityId::AffinityForArtifacts
        })
        .count();
    // Affinity is cumulative; unlike Convoke each instance reduces the total.
    count_artifacts_controlled_with_view(game, player, view)
        .saturating_mul((intrinsic + granted) as u32)
}

pub(crate) fn apply_spell_cost_modifiers(
    game: &GameState,
    player: PlayerId,
    spell: &crate::object::Object,
    cost: &crate::mana::ManaCost,
    chosen_target_count: usize,
    chosen_targets: &[Target],
    casting_method: &CastingMethod,
    cast_from_zone: Option<Zone>,
) -> crate::mana::ManaCost {
    collect_spell_cost_modifiers(
        game,
        player,
        spell,
        chosen_target_count,
        chosen_targets,
        casting_method,
        cast_from_zone,
    )
    .apply(cost)
}

pub(crate) fn collect_spell_cost_modifiers(
    game: &GameState,
    player: PlayerId,
    spell: &crate::object::Object,
    chosen_target_count: usize,
    chosen_targets: &[Target],
    casting_method: &CastingMethod,
    cast_from_zone: Option<Zone>,
) -> SpellCostModifierTotals {
    use crate::ability::AbilityKind;
    use crate::filter::FilterContext;
    use crate::mana::ManaSymbol;
    use crate::target::ObjectFilter;

    fn opponents_of(game: &GameState, player: PlayerId) -> Vec<PlayerId> {
        game.turn_store
            .turn_order
            .iter()
            .copied()
            .filter(|p| *p != player)
            .collect()
    }

    fn spell_matches_filter(
        game: &GameState,
        spell: &crate::object::Object,
        caster: PlayerId,
        filter: &ObjectFilter,
        ctx: &FilterContext,
        casting_method: &CastingMethod,
        cast_from_zone: Option<Zone>,
        chosen_targets: &[Target],
    ) -> bool {
        let targets_match = chosen_targets_match_cost_filter(game, filter, ctx, chosen_targets);
        let mut cast_filter = filter.clone();
        let alternative_cast = cast_filter.alternative_cast;
        cast_filter.targets_player = None;
        cast_filter.targets_object = None;
        cast_filter.targets_any_of = false;
        cast_filter.targets_only_player = None;
        cast_filter.targets_only_object = None;
        cast_filter.targets_only_any_of = false;
        cast_filter.target_count = None;
        cast_filter.alternative_cast = None;
        let overlaid_spell =
            spell_view_for_cost_filter_match(game, caster, spell, casting_method, cast_from_zone);
        let spell_for_match = overlaid_spell.as_ref().unwrap_or(spell);
        let matches =
            cast_filter.matches_non_recursive(
                spell_for_match,
                &ctx.clone()
                    .with_caster(Some(caster))
                    .with_prospective_cast(spell.id),
                game,
            ) || disturb_linked_face_matches_cost_filter(game, caster, spell, &cast_filter, ctx);
        targets_match
            && matches
            && alternative_cast.is_none_or(|kind| {
                casting_method_matches_alternative_kind(game, caster, spell, casting_method, kind)
            })
    }

    fn optional_life_reduction_was_paid(
        spell: &crate::object::Object,
        reduction: &crate::static_abilities::CostReductionManaCost,
        source: ObjectId,
    ) -> bool {
        match &reduction.optional_life_additional_cost {
            Some(optional) => spell
                .optional_costs_paid
                .was_paid_label(optional_life_cost_reduction_label(optional, source)),
            None => true,
        }
    }

    let mut total_increase: i32 = 0;
    let mut total_reduction: i32 = 0;
    let mut increase_pips: Vec<Vec<ManaSymbol>> = Vec::new();
    let mut reduction_pips: Vec<Vec<ManaSymbol>> = Vec::new();
    let mut spilling_reduction_pips: Vec<Vec<ManaSymbol>> = Vec::new();
    if let CastingMethod::PlayFrom { source, zone, .. }
    | CastingMethod::SplitOtherHalfPlayFrom { source, zone, .. }
    | CastingMethod::FaceDownPlayFrom { source, zone } = casting_method.origin_method()
    {
        let constraints = spell
            .cast_play_from_constraints
            .as_deref()
            .filter(|(grant_source, grant_zone, _)| {
                spell.zone == Zone::Stack
                    && game.controller_of_id(spell.id) == Some(player)
                    && grant_source == source
                    && grant_zone == zone
            })
            .map(|(_, _, constraints)| constraints.clone())
            .unwrap_or_else(|| {
                if matches!(casting_method, CastingMethod::ExactPermission { .. }) {
                    return crate::alternative_cast::play_permission::receipt_or_latch(game, player, spell, casting_method)
                        .map(|receipt| receipt.constraints).unwrap_or_default();
                }
                if matches!(casting_method.without_exact_permission(), CastingMethod::AlternativePrice { .. }) {
                    return crate::alternative_cast::price_routes::origin_constraints_or_latch(
                        game,
                        player,
                        spell,
                        casting_method,
                    )
                    .unwrap_or_default();
                }
                game.effect_store
                    .grant_registry
                    .play_from_constraints_for_card(game, spell.id, *zone, player, *source)
            });
        if let Some(reduction) = constraints.spell_cost_reduction {
            reduction_pips.extend(reduction.pips().iter().cloned());
        }
        // "That spell has undaunted" (CR 702.125a): {1} less per opponent,
        // counted now as the total cost is determined (CR 601.2f).
        if constraints.spell_cost_reduction_per_opponent > 0 {
            let opponents = opponents_of(game, player).len() as u32;
            let generic = constraints
                .spell_cost_reduction_per_opponent
                .saturating_mul(opponents);
            if generic > 0 {
                reduction_pips.push(vec![crate::mana::ManaSymbol::Generic(
                    u8::try_from(generic).unwrap_or(u8::MAX),
                )]);
            }
        }
        // "If that spell doesn't target <filter>, it costs {N} more to cast
        // this way": targets are chosen before costs are determined
        // (CR 601.2c, 601.2f), so the surcharge reads the chosen targets.
        let surcharge_waived = constraints
            .spell_cost_increase_unless_targets
            .as_ref()
            .is_some_and(|filter| {
                let ctx = crate::filter::FilterContext::new(player)
                    .with_source(spell.id)
                    .with_active_player(game.turn.active_player)
                    .with_opponents(opponents_of(game, player));
                chosen_targets.iter().any(|target| match target {
                    Target::Object(object) => game
                        .object(*object)
                        .is_some_and(|object| filter.matches(object, &ctx, game)),
                    Target::Player(_) => false,
                })
            });
        if let Some(increase) = constraints.spell_cost_increase
            && !surcharge_waived
        {
            increase_pips.extend(increase.pips().iter().cloned());
        }
    }
    if let Some(price) =
        crate::alternative_cast::price_routes::receipt_or_latch(game, player, spell, casting_method)
    {
        if let Some(reduction) = price.constraints.spell_cost_reduction {
            reduction_pips.extend(reduction.pips().iter().cloned());
        }
        if let Some(increase) = price.constraints.spell_cost_increase {
            increase_pips.extend(increase.pips().iter().cloned());
        }
    }
    let ctx = with_source_exiled_tagged_objects(
        game,
        FilterContext::new(player)
            .with_source(spell.id)
            .with_active_player(game.turn.active_player)
            .with_opponents(opponents_of(game, player)),
        spell.id,
    );

    // Abilities granted to the spell ("spells you cast have ...") contribute
    // their this-spell reductions; their zone-functioning generic modifiers
    // belong to the granting permanent (CR 601.2f).
    let granted_cost_abilities = spell_granted_cost_static_abilities(game, spell);
    let own_statics = spell
        .abilities
        .iter()
        .filter_map(|ability| match &ability.kind {
            AbilityKind::Static(static_ability) => {
                Some((static_ability, ability.functions_in(&spell.zone)))
            }
            _ => None,
        });
    for (static_ability, functions_in_current_zone) in own_statics.chain(
        granted_cost_abilities
            .iter()
            .map(|static_ability| (static_ability, false)),
    ) {
        if let Some(reduction) = static_ability.this_spell_cost_reduction() {
            let casting_method_matches = reduction.alternative_cast.is_none_or(|kind| {
                casting_method_matches_alternative_kind(game, player, spell, casting_method, kind)
            });
            if casting_method_matches
                && crate::static_abilities::this_spell_cost_condition_is_active_for_player_with_optional_costs_paid(
                    game,
                    spell.id,
                    player,
                    &reduction.condition,
                    chosen_targets,
                    Some(&spell.optional_costs_paid),
                )
            {
                let amount =
                    resolve_this_spell_cost_reduction_value(game, player, spell, reduction);
                if amount > 0 {
                    total_reduction = total_reduction.saturating_add(amount);
                }
            }
        }
        if let Some(reduction) = static_ability.this_spell_cost_reduction_mana_cost()
            && crate::static_abilities::this_spell_cost_condition_is_active_for_player_with_optional_costs_paid(
                game,
                spell.id,
                player,
                &reduction.condition,
                chosen_targets,
                Some(&spell.optional_costs_paid),
            ) {
                let repetitions = reduction
                    .repetitions
                    .as_ref()
                    .map(|value| resolve_cost_modifier_value(game, player, spell, value).max(0))
                    .unwrap_or(1);
                for _ in 0..repetitions {
                    if reduction.colored_only {
                        reduction_pips.extend(reduction.reduction.pips().iter().cloned());
                    } else {
                        spilling_reduction_pips.extend(reduction.reduction.pips().iter().cloned());
                    }
                }
            }
        if !functions_in_current_zone {
            continue;
        }
        if !static_ability.is_active(game, spell.id) {
            continue;
        }
        if let Some(reduction) = static_ability.cost_reduction()
            && spell_matches_filter(
                game,
                spell,
                player,
                &reduction.filter,
                &ctx,
                casting_method,
                cast_from_zone,
                chosen_targets,
            )
        {
            let multiplier = i32::try_from(cost_modifier_target_repetitions(
                game,
                &reduction.filter,
                &ctx,
                reduction.per_target,
                chosen_target_count,
                chosen_targets,
            ))
            .unwrap_or(i32::MAX);
            let amount = resolve_cost_reduction_amount(game, spell, spell.id, player, reduction)
                .saturating_mul(multiplier);
            if amount > 0 {
                total_reduction = total_reduction.saturating_add(amount);
            }
        }
        if let Some(increase) = static_ability.cost_increase()
            && spell_matches_filter(
                game,
                spell,
                player,
                &increase.filter,
                &ctx,
                casting_method,
                cast_from_zone,
                chosen_targets,
            )
        {
            let multiplier = i32::try_from(cost_modifier_target_repetitions(
                game,
                &increase.filter,
                &ctx,
                increase.per_target,
                chosen_target_count,
                chosen_targets,
            ))
            .unwrap_or(i32::MAX);
            let amount = resolve_cost_modifier_value(game, player, spell, &increase.increase)
                .saturating_mul(multiplier);
            if amount > 0 {
                total_increase = total_increase.saturating_add(amount);
            }
        }
        if let Some(increase) = static_ability.cost_increase_mana_cost()
            && spell_matches_filter(
                game,
                spell,
                player,
                &increase.filter,
                &ctx,
                casting_method,
                cast_from_zone,
                chosen_targets,
            )
        {
            for _ in 0..cost_modifier_target_repetitions(
                game,
                &increase.filter,
                &ctx,
                increase.per_target,
                chosen_target_count,
                chosen_targets,
            ) {
                increase_pips.extend(increase.increase.pips().iter().cloned());
            }
        }
        if let Some(reduction) = static_ability.cost_reduction_mana_cost()
            && spell_matches_filter(
                game,
                spell,
                player,
                &reduction.filter,
                &ctx,
                casting_method,
                cast_from_zone,
                chosen_targets,
            )
            && optional_life_reduction_was_paid(spell, reduction, spell.id)
        {
            let for_each = mana_cost_reduction_for_each(game, spell, spell.id, player, player, reduction);
            for _ in 0..cost_modifier_target_repetitions(
                game,
                &reduction.filter,
                &ctx,
                reduction.per_target,
                chosen_target_count,
                chosen_targets,
            ) * for_each {
                if reduction.colored_only {
                    reduction_pips.extend(reduction.reduction.pips().iter().cloned());
                } else {
                    spilling_reduction_pips.extend(reduction.reduction.pips().iter().cloned());
                }
            }
        }
        if let Some(per_target_amount) = static_ability.cost_increase_per_additional_target() {
            let additional_targets = chosen_target_count.saturating_sub(1);
            if additional_targets > 0 {
                let extra = (per_target_amount as i32).saturating_mul(additional_targets as i32);
                total_increase = total_increase.saturating_add(extra);
            }
        }
        if let Some(per_target_cost) =
            static_ability.cost_increase_mana_cost_per_additional_target()
        {
            let additional_targets = chosen_target_count.saturating_sub(1);
            for _ in 0..additional_targets {
                increase_pips.extend(per_target_cost.pips().iter().cloned());
            }
        }
    }

    for effect in &game.effect_store.temporary_spell_cost_reductions {
        if effect.player != player || effect.is_expired(game) {
            continue;
        }
        let temporary_ctx = with_source_exiled_tagged_objects(
            game,
            FilterContext::new(player)
                .with_source(effect.source)
                .with_active_player(game.turn.active_player)
                .with_opponents(opponents_of(game, player)),
            effect.source,
        );
        if spell_matches_filter(
            game,
            spell,
            player,
            &effect.filter,
            &temporary_ctx,
            casting_method,
            cast_from_zone,
            chosen_targets,
        ) {
            if let Some(generic_reduction) = &effect.generic_reduction {
                let amount = resolve_cost_modifier_value(game, player, spell, generic_reduction);
                if amount > 0 {
                    if effect.increases_cost {
                        total_increase = total_increase.saturating_add(amount);
                    } else {
                        total_reduction = total_reduction.saturating_add(amount);
                    }
                }
            }
            reduction_pips.extend(effect.reduction.pips().iter().cloned());
        }
    }

    SpellCostModifierTotals {
        total_increase,
        total_reduction,
        increase_pips,
        reduction_pips,
        spilling_reduction_pips,
    }
}

/// The generic reduction "Buyback costs cost {N} less" gives `spell`: at most
/// the generic mana of its buyback costs that were announced as paid.
fn paid_buyback_cost_reduction(spell: &crate::object::Object, amount: u32) -> i32 {
    if amount == 0 {
        return 0;
    }
    let paid_buyback_generic: u32 = spell
        .optional_costs
        .iter()
        .filter(|optional| {
            optional.kind == ironsmith_core::OptionalCostKind::Buyback
                && spell
                    .optional_costs_paid
                    .was_paid_label(optional.cost_ref())
        })
        .filter_map(|optional| optional.cost.mana_cost())
        .flat_map(|cost| cost.pips().iter())
        .map(|pip| {
            pip.iter()
                .find_map(|symbol| match symbol {
                    crate::mana::ManaSymbol::Generic(amount) => Some(u32::from(*amount)),
                    _ => None,
                })
                .filter(|_| pip.len() == 1)
                .unwrap_or(0)
        })
        .sum();
    i32::try_from(amount.min(paid_buyback_generic)).unwrap_or(i32::MAX)
}

/// "Spells cost an additional \"Sacrifice a Swamp\" to cast for each black
/// mana symbol in their mana costs." / "Activated abilities cost an
/// additional ... to activate for each black mana symbol in their activation
/// costs." (Drought): the sacrifice costs battlefield permanents add to a
/// spell (`activated == false`) or activated ability whose mana cost is
/// `mana_cost`, one per matching mana symbol (CR 601.2f, 602.2b).
pub(crate) fn battlefield_sacrifice_surcharges_for_mana_cost(
    game: &GameState,
    activated: bool,
    mana_cost: Option<&crate::mana::ManaCost>,
) -> Vec<crate::costs::Cost> {
    let Some(mana_cost) = mana_cost else {
        return Vec::new();
    };
    let mut costs = Vec::new();
    for &permanent in &game.battlefield {
        if game.is_phased_out(permanent) {
            continue;
        }
        let Some(abilities) = game.current_abilities(permanent) else {
            continue;
        };
        for ability in &abilities {
            let AbilityKind::Static(static_ability) = &ability.kind else {
                continue;
            };
            let Some(model) = static_ability.compiled_model() else {
                continue;
            };
            let ironsmith_core::StaticAbilityPayload::AdditionalSacrificePerManaSymbol {
                activated_abilities,
                symbol,
                sacrifice,
                ..
            } = &model.payload
            else {
                continue;
            };
            if *activated_abilities != activated || !static_ability.is_active(game, permanent) {
                continue;
            }
            let count = mana_cost
                .pips()
                .iter()
                .filter(|pip| pip.contains(symbol))
                .count();
            for _ in 0..count {
                costs.push(crate::costs::Cost::sacrifice(sacrifice.clone()));
            }
        }
    }
    costs
}

/// Total life surcharge from battlefield permanents whose "cost an additional
/// N life to cast" static abilities match `spell` (Terror of the Peaks).
pub(crate) fn battlefield_life_cost_increase_for_spell(
    game: &GameState,
    caster: PlayerId,
    spell: &crate::object::Object,
    chosen_targets: &[Target],
    casting_method: &CastingMethod,
    cast_from_zone: Option<Zone>,
) -> u32 {
    use crate::filter::FilterContext;

    let view = DerivedGameView::new(game);
    let mut total: u32 = 0;
    for perm_id in view.battlefield_spell_cost_modifier_sources() {
        let Some(perm) = game.object(perm_id) else {
            continue;
        };
        let controller = game.controller_of(perm);
        let opponents: Vec<PlayerId> = game
            .turn_store
            .turn_order
            .iter()
            .copied()
            .filter(|player| game.are_opponents(controller, *player))
            .collect();
        let ctx = with_source_exiled_tagged_objects(
            game,
            FilterContext::new(controller)
                .with_source(perm_id)
                .with_active_player(game.turn.active_player)
                .with_opponents(opponents),
            perm_id,
        );
        let Some(static_abilities) = view.spell_cost_modifier_static_abilities_rc(perm_id) else {
            continue;
        };
        for static_ability in static_abilities.iter() {
            if !static_ability.is_active(game, perm_id) {
                continue;
            }
            if let Some(increase) = static_ability.cost_increase_life()
                && spell_matches_cost_modifier_filter(
                    game,
                    spell,
                    caster,
                    &increase.filter,
                    &ctx,
                    casting_method,
                    cast_from_zone,
                    chosen_targets,
                )
            {
                total = total.saturating_add(increase.amount);
            }
        }
    }
    total
}

fn spell_matches_cost_modifier_filter(
    game: &GameState,
    spell: &crate::object::Object,
    caster: PlayerId,
    filter: &crate::target::ObjectFilter,
    ctx: &crate::filter::FilterContext,
    casting_method: &CastingMethod,
    cast_from_zone: Option<Zone>,
    chosen_targets: &[Target],
) -> bool {
    let targets_match = chosen_targets_match_cost_filter(game, filter, ctx, chosen_targets);
    let mut cast_filter = filter.clone();
    let alternative_cast = cast_filter.alternative_cast;
    cast_filter.targets_player = None;
    cast_filter.targets_object = None;
    cast_filter.targets_any_of = false;
    cast_filter.targets_only_player = None;
    cast_filter.targets_only_object = None;
    cast_filter.targets_only_any_of = false;
    cast_filter.target_count = None;
    cast_filter.alternative_cast = None;
    let overlaid_spell =
        spell_view_for_cost_filter_match(game, caster, spell, casting_method, cast_from_zone);
    let spell_for_match = overlaid_spell.as_ref().unwrap_or(spell);
    let matches =
        cast_filter.matches_non_recursive(
            spell_for_match,
            &ctx.clone()
                .with_caster(Some(caster))
                .with_prospective_cast(spell.id),
            game,
        ) || disturb_linked_face_matches_cost_filter(game, caster, spell, &cast_filter, ctx);
    targets_match
        && matches
        && alternative_cast.is_none_or(|kind| {
            casting_method_matches_alternative_kind(game, caster, spell, casting_method, kind)
        })
}

pub(crate) fn collect_battlefield_spell_cost_modifiers(
    game: &GameState,
    caster: PlayerId,
    spell: &crate::object::Object,
    chosen_target_count: usize,
    chosen_targets: &[Target],
    casting_method: &CastingMethod,
    cast_from_zone: Option<Zone>,
    view: &DerivedGameView<'_>,
) -> SpellCostModifierTotals {
    use crate::ability::AbilityKind;
    use crate::filter::FilterContext;
    use crate::mana::ManaSymbol;
    use crate::target::ObjectFilter;

    fn opponents_of(game: &GameState, player: PlayerId) -> Vec<PlayerId> {
        game.turn_store
            .turn_order
            .iter()
            .copied()
            .filter(|p| *p != player)
            .collect()
    }

    fn spell_matches_filter(
        game: &GameState,
        spell: &crate::object::Object,
        caster: PlayerId,
        filter: &ObjectFilter,
        ctx: &FilterContext,
        casting_method: &CastingMethod,
        cast_from_zone: Option<Zone>,
        chosen_targets: &[Target],
    ) -> bool {
        let targets_match = chosen_targets_match_cost_filter(game, filter, ctx, chosen_targets);
        let mut cast_filter = filter.clone();
        let alternative_cast = cast_filter.alternative_cast;
        cast_filter.targets_player = None;
        cast_filter.targets_object = None;
        cast_filter.targets_any_of = false;
        cast_filter.targets_only_player = None;
        cast_filter.targets_only_object = None;
        cast_filter.targets_only_any_of = false;
        cast_filter.target_count = None;
        cast_filter.alternative_cast = None;
        let overlaid_spell =
            spell_view_for_cost_filter_match(game, caster, spell, casting_method, cast_from_zone);
        let spell_for_match = overlaid_spell.as_ref().unwrap_or(spell);
        let matches =
            cast_filter.matches_non_recursive(
                spell_for_match,
                &ctx.clone()
                    .with_caster(Some(caster))
                    .with_prospective_cast(spell.id),
                game,
            ) || disturb_linked_face_matches_cost_filter(game, caster, spell, &cast_filter, ctx);
        targets_match
            && matches
            && alternative_cast.is_none_or(|kind| {
                casting_method_matches_alternative_kind(game, caster, spell, casting_method, kind)
            })
    }

    fn optional_life_reduction_was_paid(
        spell: &crate::object::Object,
        reduction: &crate::static_abilities::CostReductionManaCost,
        source: ObjectId,
    ) -> bool {
        match &reduction.optional_life_additional_cost {
            Some(optional) => spell
                .optional_costs_paid
                .was_paid_label(optional_life_cost_reduction_label(optional, source)),
            None => true,
        }
    }

    let mut total_increase: i32 = 0;
    let mut total_reduction: i32 = 0;
    let mut increase_pips: Vec<Vec<ManaSymbol>> = Vec::new();
    let mut reduction_pips: Vec<Vec<ManaSymbol>> = Vec::new();
    let mut spilling_reduction_pips: Vec<Vec<ManaSymbol>> = Vec::new();
    let mut buyback_reduction: u32 = 0;

    for perm_id in view.battlefield_spell_cost_modifier_sources() {
        let Some(perm) = game.object(perm_id) else {
            continue;
        };
        let controller = game.controller_of(perm);
        let ctx = with_source_exiled_tagged_objects(
            game,
            FilterContext::new(controller)
                .with_source(perm_id)
                .with_active_player(game.turn.active_player)
                .with_opponents(opponents_of(game, controller)),
            perm_id,
        );

        if let Some(static_abilities) = view.spell_cost_modifier_static_abilities_rc(perm_id) {
            for static_ability in static_abilities.iter() {
                if !static_ability.is_active(game, perm_id) {
                    continue;
                }
                if let Some(reduction) = static_ability.cost_reduction()
                    && spell_matches_filter(
                        game,
                        spell,
                        caster,
                        &reduction.filter,
                        &ctx,
                        casting_method,
                        cast_from_zone,
                        chosen_targets,
                    )
                {
                    let multiplier = i32::try_from(cost_modifier_target_repetitions(
                        game,
                        &reduction.filter,
                        &ctx,
                        reduction.per_target,
                        chosen_target_count,
                        chosen_targets,
                    ))
                    .unwrap_or(i32::MAX);
                    let amount = resolve_cost_reduction_amount_for_caster(
                        game, spell, perm_id, controller, caster, reduction,
                    )
                    .saturating_mul(multiplier);
                    if amount > 0 {
                        total_reduction = total_reduction.saturating_add(amount);
                    }
                }
                if let Some(increase) = static_ability.cost_increase()
                    && spell_matches_filter(
                        game,
                        spell,
                        caster,
                        &increase.filter,
                        &ctx,
                        casting_method,
                        cast_from_zone,
                        chosen_targets,
                    )
                {
                    let multiplier = i32::try_from(cost_modifier_target_repetitions(
                        game,
                        &increase.filter,
                        &ctx,
                        increase.per_target,
                        chosen_target_count,
                        chosen_targets,
                    ))
                    .unwrap_or(i32::MAX);
                    let amount = resolve_cost_modifier_value_for_cast(
                        game,
                        perm_id,
                        controller,
                        caster,
                        &increase.increase,
                    )
                    .saturating_mul(multiplier);
                    if amount > 0 {
                        total_increase = total_increase.saturating_add(amount);
                    }
                }
                if let Some(increase) = static_ability.cost_increase_mana_cost()
                    && spell_matches_filter(
                        game,
                        spell,
                        caster,
                        &increase.filter,
                        &ctx,
                        casting_method,
                        cast_from_zone,
                        chosen_targets,
                    )
                {
                    for _ in 0..cost_modifier_target_repetitions(
                        game,
                        &increase.filter,
                        &ctx,
                        increase.per_target,
                        chosen_target_count,
                        chosen_targets,
                    ) {
                        increase_pips.extend(increase.increase.pips().iter().cloned());
                    }
                }
                if let Some(reduction) = static_ability.cost_reduction_mana_cost()
                    && spell_matches_filter(
                        game,
                        spell,
                        caster,
                        &reduction.filter,
                        &ctx,
                        casting_method,
                        cast_from_zone,
                        chosen_targets,
                    )
                    && optional_life_reduction_was_paid(spell, reduction, perm_id)
                {
                    let for_each = mana_cost_reduction_for_each(
                        game, spell, perm_id, controller, caster, reduction,
                    );
                    for _ in 0..cost_modifier_target_repetitions(
                        game,
                        &reduction.filter,
                        &ctx,
                        reduction.per_target,
                        chosen_target_count,
                        chosen_targets,
                    ) * for_each {
                        if reduction.colored_only {
                            reduction_pips.extend(reduction.reduction.pips().iter().cloned());
                        } else {
                            spilling_reduction_pips
                                .extend(reduction.reduction.pips().iter().cloned());
                        }
                    }
                }
                if let Some(amount) = static_ability.buyback_cost_reduction_amount() {
                    buyback_reduction = buyback_reduction.saturating_add(amount);
                }
                if let Some(per_target_amount) =
                    static_ability.cost_increase_per_additional_target()
                {
                    let additional_targets = chosen_target_count.saturating_sub(1);
                    if additional_targets > 0 {
                        let extra =
                            (per_target_amount as i32).saturating_mul(additional_targets as i32);
                        total_increase = total_increase.saturating_add(extra);
                    }
                }
                if let Some(per_target_cost) =
                    static_ability.cost_increase_mana_cost_per_additional_target()
                {
                    let additional_targets = chosen_target_count.saturating_sub(1);
                    for _ in 0..additional_targets {
                        increase_pips.extend(per_target_cost.pips().iter().cloned());
                    }
                }
            }
        } else {
            for static_ability in perm
                .abilities
                .iter()
                .filter_map(|ability| match &ability.kind {
                    AbilityKind::Static(static_ability) => Some(static_ability),
                    _ => None,
                })
            {
                if !static_ability.is_active(game, perm_id) {
                    continue;
                }
                if let Some(reduction) = static_ability.cost_reduction()
                    && spell_matches_filter(
                        game,
                        spell,
                        caster,
                        &reduction.filter,
                        &ctx,
                        casting_method,
                        cast_from_zone,
                        chosen_targets,
                    )
                {
                    let multiplier = i32::try_from(cost_modifier_target_repetitions(
                        game,
                        &reduction.filter,
                        &ctx,
                        reduction.per_target,
                        chosen_target_count,
                        chosen_targets,
                    ))
                    .unwrap_or(i32::MAX);
                    let amount = resolve_cost_reduction_amount_for_caster(
                        game, spell, perm_id, controller, caster, reduction,
                    )
                    .saturating_mul(multiplier);
                    if amount > 0 {
                        total_reduction = total_reduction.saturating_add(amount);
                    }
                }
                if let Some(increase) = static_ability.cost_increase()
                    && spell_matches_filter(
                        game,
                        spell,
                        caster,
                        &increase.filter,
                        &ctx,
                        casting_method,
                        cast_from_zone,
                        chosen_targets,
                    )
                {
                    let multiplier = i32::try_from(cost_modifier_target_repetitions(
                        game,
                        &increase.filter,
                        &ctx,
                        increase.per_target,
                        chosen_target_count,
                        chosen_targets,
                    ))
                    .unwrap_or(i32::MAX);
                    let amount = resolve_cost_modifier_value_for_cast(
                        game,
                        perm_id,
                        controller,
                        caster,
                        &increase.increase,
                    )
                    .saturating_mul(multiplier);
                    if amount > 0 {
                        total_increase = total_increase.saturating_add(amount);
                    }
                }
                if let Some(increase) = static_ability.cost_increase_mana_cost()
                    && spell_matches_filter(
                        game,
                        spell,
                        caster,
                        &increase.filter,
                        &ctx,
                        casting_method,
                        cast_from_zone,
                        chosen_targets,
                    )
                {
                    for _ in 0..cost_modifier_target_repetitions(
                        game,
                        &increase.filter,
                        &ctx,
                        increase.per_target,
                        chosen_target_count,
                        chosen_targets,
                    ) {
                        increase_pips.extend(increase.increase.pips().iter().cloned());
                    }
                }
                if let Some(reduction) = static_ability.cost_reduction_mana_cost()
                    && spell_matches_filter(
                        game,
                        spell,
                        caster,
                        &reduction.filter,
                        &ctx,
                        casting_method,
                        cast_from_zone,
                        chosen_targets,
                    )
                    && optional_life_reduction_was_paid(spell, reduction, perm_id)
                {
                    let for_each = mana_cost_reduction_for_each(
                        game, spell, perm_id, controller, caster, reduction,
                    );
                    for _ in 0..cost_modifier_target_repetitions(
                        game,
                        &reduction.filter,
                        &ctx,
                        reduction.per_target,
                        chosen_target_count,
                        chosen_targets,
                    ) * for_each {
                        if reduction.colored_only {
                            reduction_pips.extend(reduction.reduction.pips().iter().cloned());
                        } else {
                            spilling_reduction_pips
                                .extend(reduction.reduction.pips().iter().cloned());
                        }
                    }
                }
                if let Some(amount) = static_ability.buyback_cost_reduction_amount() {
                    buyback_reduction = buyback_reduction.saturating_add(amount);
                }
                if let Some(per_target_amount) =
                    static_ability.cost_increase_per_additional_target()
                {
                    let additional_targets = chosen_target_count.saturating_sub(1);
                    if additional_targets > 0 {
                        let extra =
                            (per_target_amount as i32).saturating_mul(additional_targets as i32);
                        total_increase = total_increase.saturating_add(extra);
                    }
                }
                if let Some(per_target_cost) =
                    static_ability.cost_increase_mana_cost_per_additional_target()
                {
                    let additional_targets = chosen_target_count.saturating_sub(1);
                    for _ in 0..additional_targets {
                        increase_pips.extend(per_target_cost.pips().iter().cloned());
                    }
                }
            }
        }
    }

    // CR 702.27a: buyback is an additional cost; "Buyback costs cost {N}
    // less" reduces only the generic mana of a buyback cost that was paid.
    total_reduction =
        total_reduction.saturating_add(paid_buyback_cost_reduction(spell, buyback_reduction));

    SpellCostModifierTotals {
        total_increase,
        total_reduction,
        increase_pips,
        reduction_pips,
        spilling_reduction_pips,
    }
}

pub(crate) fn resolve_this_spell_cost_reduction_value(
    game: &GameState,
    player: PlayerId,
    spell: &crate::object::Object,
    reduction: &crate::static_abilities::ThisSpellCostReduction,
) -> i32 {
    if matches!(
        (&reduction.condition, &reduction.reduction),
        (
            crate::static_abilities::ThisSpellCostCondition::LifeTotalLessThanStarting,
            crate::effect::Value::X
        )
    ) && let Some(player_state) = game.player(player)
    {
        return player_state
            .starting_life
            .saturating_sub(player_state.life)
            .max(0);
    }

    // "for each permanent sacrificed this way" is decided while the spell's
    // own sacrifice cost is paid; before that it contributes nothing, and
    // `cost_payment_sacrifice_reduction` adds it once the choice is made.
    if let Some(unpaid) = substitute_cost_payment_sacrifice_metric(&reduction.reduction, &|_| {
        crate::effect::Value::Fixed(0)
    }) {
        return resolve_cost_modifier_value(game, player, spell, &unpaid);
    }

    resolve_cost_modifier_value(game, player, spell, &reduction.reduction)
}

/// The actions a spell's own additional or optional cost can perform that a
/// "This spell costs {N} less to cast for each <object> <action> this way"
/// reduction counts once that cost is paid: sacrifices (Torgaar, Dargo) and
/// taps (Explosive Singularity).
const COST_PAYMENT_METRIC_ACTIONS: [ironsmith_core::PriorEffectAction; 3] = [
    ironsmith_core::PriorEffectAction::Sacrificed,
    ironsmith_core::PriorEffectAction::Tapped,
    ironsmith_core::PriorEffectAction::Exiled,
];

/// The cost-payment actions ([`COST_PAYMENT_METRIC_ACTIONS`]) the spell's
/// "for each ... this way" reductions read.
fn spell_cost_payment_metric_actions(
    spell: &crate::object::Object,
) -> Vec<ironsmith_core::PriorEffectAction> {
    let mut actions = Vec::new();
    for reduction in spell_cost_payment_sacrifice_reductions(spell) {
        collect_cost_payment_metric_actions(&reduction.reduction, &mut actions);
    }
    actions
}

fn collect_cost_payment_metric_actions(
    value: &crate::effect::Value,
    out: &mut Vec<ironsmith_core::PriorEffectAction>,
) {
    use crate::effect::Value;
    match value {
        Value::PendingPriorEffectMetric(query) => {
            if let Some(action) = query.action
                && COST_PAYMENT_METRIC_ACTIONS.contains(&action)
                && !out.contains(&action)
            {
                out.push(action);
            }
        }
        Value::SurfaceHinted { value: inner, .. }
        | Value::Scaled(inner, _)
        | Value::DividedRoundedDown(inner, _)
        | Value::HalfRoundedDown(inner) => collect_cost_payment_metric_actions(inner, out),
        Value::Add(left, right) | Value::Min(left, right) => {
            collect_cost_payment_metric_actions(left, out);
            collect_cost_payment_metric_actions(right, out);
        }
        _ => {}
    }
}

/// Replace every unbound "permanents sacrificed / tapped this way" metric in
/// a cost modifier amount. Returns `None` when the amount has no such metric.
pub(crate) fn substitute_cost_payment_sacrifice_metric(
    value: &crate::effect::Value,
    replacement: &dyn Fn(&ironsmith_core::PriorEffectMetricQuery) -> crate::effect::Value,
) -> Option<crate::effect::Value> {
    use crate::effect::Value;
    let pair = |left: &Value, right: &Value| {
        let new_left = substitute_cost_payment_sacrifice_metric(left, replacement);
        let new_right = substitute_cost_payment_sacrifice_metric(right, replacement);
        (new_left.is_some() || new_right.is_some()).then(|| {
            (
                Box::new(new_left.unwrap_or_else(|| left.clone())),
                Box::new(new_right.unwrap_or_else(|| right.clone())),
            )
        })
    };
    match value {
        Value::PendingPriorEffectMetric(query)
            if query
                .action
                .is_some_and(|action| COST_PAYMENT_METRIC_ACTIONS.contains(&action)) =>
        {
            Some(replacement(query))
        }
        Value::SurfaceHinted {
            value: inner,
            hints,
        } => substitute_cost_payment_sacrifice_metric(inner, replacement).map(|inner| {
            Value::SurfaceHinted {
                value: Box::new(inner),
                hints: hints.clone(),
            }
        }),
        Value::Add(left, right) => pair(left, right).map(|(l, r)| Value::Add(l, r)),
        Value::Min(left, right) => pair(left, right).map(|(l, r)| Value::Min(l, r)),
        Value::Scaled(inner, factor) => {
            substitute_cost_payment_sacrifice_metric(inner, replacement)
                .map(|inner| Value::Scaled(Box::new(inner), *factor))
        }
        Value::DividedRoundedDown(inner, divisor) => {
            substitute_cost_payment_sacrifice_metric(inner, replacement)
                .map(|inner| Value::DividedRoundedDown(Box::new(inner), *divisor))
        }
        Value::HalfRoundedDown(inner) => {
            substitute_cost_payment_sacrifice_metric(inner, replacement)
                .map(|inner| Value::HalfRoundedDown(Box::new(inner)))
        }
        _ => None,
    }
}

fn spell_cost_payment_sacrifice_reductions(
    spell: &crate::object::Object,
) -> impl Iterator<Item = &crate::static_abilities::ThisSpellCostReduction> {
    spell
        .abilities
        .iter()
        .filter_map(|ability| match &ability.kind {
            crate::ability::AbilityKind::Static(static_ability) => {
                static_ability.this_spell_cost_reduction()
            }
            _ => None,
        })
        .filter(|reduction| {
            substitute_cost_payment_sacrifice_metric(&reduction.reduction, &|_| {
                crate::effect::Value::Fixed(0)
            })
            .is_some()
        })
}

/// Whether this spell's cost is reduced "for each permanent sacrificed this
/// way" by its own additional cost (Dargo, Rottenmouth Viper).
pub(crate) fn spell_has_cost_payment_sacrifice_reduction(spell: &crate::object::Object) -> bool {
    spell_cost_payment_sacrifice_reductions(spell)
        .next()
        .is_some()
}

fn collect_cost_choices<'a>(
    effect: &'a crate::effect::Effect,
    out: &mut Vec<crate::effects::ChooseObjectsEffect>,
) {
    if let Some(choose) = effect.downcast_ref::<crate::effects::ChooseObjectsEffect>() {
        out.push(choose.clone());
        return;
    }
    if let Some(inner) = effect.transparent_child_effect() {
        collect_cost_choices(inner, out);
        return;
    }
    effect
        .0
        .visit_child_effects(&mut |child| collect_cost_choices(child, out));
}

/// The largest "{N} less for each permanent sacrificed this way" reduction the
/// caster could lock in by sacrificing as many eligible permanents as the
/// spell's additional cost allows (CR 601.2b, 601.2f: the sacrifices are
/// announced before the total cost is determined).
pub(crate) fn max_cost_payment_sacrifice_reduction(
    game: &GameState,
    player: PlayerId,
    spell: &crate::object::Object,
) -> u32 {
    max_cost_payment_sacrifice_reduction_for_selection(game, player, spell, false)
}

fn max_cost_payment_sacrifice_reduction_for_selection(
    game: &GameState,
    player: PlayerId,
    spell: &crate::object::Object,
    only_selected_optional_costs: bool,
) -> u32 {
    if !spell_has_cost_payment_sacrifice_reduction(spell) {
        return 0;
    }
    let mut choices = Vec::new();
    let mut tap_tags = Vec::new();
    let mut costs = spell.additional_non_mana_costs();
    costs.extend(spell.optional_costs.iter().enumerate()
        .filter(|(index, _)| !only_selected_optional_costs || spell.optional_costs_paid.was_paid(*index))
        .flat_map(|(_, optional)| optional.cost.non_mana_costs().cloned()));
    for cost in costs {
        if let Some(effect) = cost.effect_ref() {
            collect_cost_choices(effect, &mut choices);
            payment_characteristic_preview::collect_tap_cost_tags(effect, &mut tap_tags);
        }
    }
    let filter_ctx = game.filter_context_for(player, Some(spell.id));
    let cause = crate::events::cause::EventCause::from_cost(spell.id, player);
    let metric_actions = spell_cost_payment_metric_actions(spell);
    let sacrifice_metric = metric_actions.contains(&ironsmith_core::PriorEffectAction::Sacrificed);
    let tap_only_metric = !sacrifice_metric
        && metric_actions.contains(&ironsmith_core::PriorEffectAction::Tapped);
    let sacrificable = choices
        .iter()
        .filter(|choose| {
            choose
                .filter
                .zone
                .or(choose.zone)
                .is_none_or(|zone| zone == crate::zone::Zone::Battlefield)
        })
        .map(|choose| {
            let available = game
                .battlefield
                .iter()
                .filter_map(|&id| game.object(id).map(|object| (id, object)))
                .filter(|(id, object)| {
                    game.controller_of(object) == player
                        && choose.filter.matches(object, &filter_ctx, game)
                        && if tap_only_metric {
                            // A tap cost can only use untapped permanents.
                            !game.is_tapped(*id)
                        } else {
                            game.can_be_sacrificed_with_cause(*id, &cause)
                                && !game
                                    .player_cant_sacrifice_object_to_cast_or_activate(player, *id)
                        }
                })
                .count();
            choose.count.max.map_or(available, |max| available.min(max))
        })
        .sum::<usize>() as i32;
    if sacrificable == 0 && !metric_actions.contains(&ironsmith_core::PriorEffectAction::Exiled) {
        return 0;
    }
    let mut dm = SelectFirstDecisionMaker;
    let ctx = ExecutionContext::new(spell.id, player, &mut dm);
    let mut total = 0u32;
    for reduction in spell_cost_payment_sacrifice_reductions(spell) {
        let best = substitute_cost_payment_sacrifice_metric(&reduction.reduction, &|query| {
            crate::effect::Value::Fixed(exile_payment_preview::maximum(game, player, spell, only_selected_optional_costs, query)
                .or_else(|| payment_characteristic_preview::maximum(game, player, spell.id, &choices, &tap_tags, query))
                .unwrap_or(sacrificable))
        });
        let none = substitute_cost_payment_sacrifice_metric(&reduction.reduction, &|_| {
            crate::effect::Value::Fixed(0)
        });
        let (Some(best), Some(none)) = (best, none) else {
            continue;
        };
        let best = resolve_value(game, &best, &ctx).unwrap_or(0);
        let none = resolve_value(game, &none, &ctx).unwrap_or(0);
        total = total.saturating_add(best.saturating_sub(none).max(0) as u32);
    }
    total
}

/// Whether the mana cost becomes affordable once the most favourable
/// sacrifice-this-way reduction is locked in.
fn affordable_with_max_cost_payment_sacrifice_reduction(
    game: &GameState,
    player: PlayerId,
    spell: &crate::object::Object,
    _spell_id: ObjectId,
    casting_method: &CastingMethod,
    effective_cost: &crate::mana::ManaCost,
    view: &DerivedGameView<'_>,
) -> bool {
    if let Some(payable) = payment_characteristic_preview::can_pay_scoped_tap(
        game, player, spell, casting_method, effective_cost, false, spell.x_value.unwrap_or(0),
    ) { return payable; }
    let reduction = max_cost_payment_sacrifice_reduction(game, player, spell);
    reduction > 0
        && mana_cost_can_be_paid_by_caster_or_assist_with_view(
            game,
            player,
            spell,
            casting_method,
            &apply_minimum_spell_total_mana_with_view(
                view,
                &effective_cost.reduce_generic(reduction),
            ),
            view,
        )
}

/// The extra generic reduction earned by the permanents sacrificed while
/// paying this spell's additional costs, whose outcomes are `outcomes`
/// (CR 601.2f: the total cost accounts for the announced sacrifices).
pub(crate) fn cost_payment_sacrifice_reduction(
    game: &GameState,
    player: PlayerId,
    spell: &crate::object::Object,
    completed: &crate::effects::CompletedActionPrefix,
    payment_tags: &std::collections::HashMap<crate::tag::TagKey, Vec<crate::snapshot::ObjectSnapshot>>,
) -> u32 {
    // Cost actions need not have compiler-assigned effect IDs. Read the actual
    // completed payment producers; named bindings can omit them or alias them.
    // Selection receipts alone are not evidence of a completed sacrifice.
    let outcomes: std::collections::HashMap<_, _> = completed
        .instruction_outcomes()
        .filter(|outcome| {
            COST_PAYMENT_METRIC_ACTIONS.iter().any(|action| {
                crate::effects::outcome_recording::action_objects(
                    outcome.instruction_result(),
                    *action,
                    None,
                )
                .is_some()
            })
        })
        .enumerate()
        .map(|(index, outcome)| (crate::effect::EffectId(index as u32), outcome.clone()))
        .collect();
    let mut effect_ids = outcomes.keys().copied().collect::<Vec<_>>();
    effect_ids.sort_by_key(|id| id.0);
    let mut dm = SelectFirstDecisionMaker;
    let mut ctx = ExecutionContext::new(spell.id, player, &mut dm);
    ctx.effect_outcomes = outcomes.clone();
    ctx.tagged_objects = payment_tags.clone();
    let mut total = 0u32;
    for reduction in spell_cost_payment_sacrifice_reductions(spell) {
        let paid = substitute_cost_payment_sacrifice_metric(&reduction.reduction, &|query| {
            // The sacrificed objects' memory is last-known information; the
            // query's zone names where they were, not where they are now.
            let mut query = query.clone();
            if let Some(filter) = query.filter.as_mut() {
                filter.zone = None;
            }
            // Only the producers that performed this query's action count
            // (a tap payment never feeds "sacrificed this way").
            effect_ids
                .iter()
                .filter(|effect_id| {
                    query.action.is_some_and(|action| {
                        outcomes.get(*effect_id).is_some_and(|outcome| {
                            crate::effects::outcome_recording::action_objects(
                                outcome.instruction_result(),
                                action,
                                None,
                            )
                            .is_some()
                        })
                    })
                })
                .map(|&effect_id| crate::effect::Value::PriorEffectMetric {
                    effect_id,
                    query: query.clone(),
                })
                .reduce(|left, right| crate::effect::Value::Add(Box::new(left), Box::new(right)))
                .unwrap_or(crate::effect::Value::Fixed(0))
        });
        let unpaid = substitute_cost_payment_sacrifice_metric(&reduction.reduction, &|_| {
            crate::effect::Value::Fixed(0)
        });
        let (Some(paid), Some(unpaid)) = (paid, unpaid) else {
            continue;
        };
        let paid = resolve_value(game, &paid, &ctx).unwrap_or(0);
        let unpaid = resolve_value(game, &unpaid, &ctx).unwrap_or(0);
        total = total.saturating_add(paid.saturating_sub(unpaid).max(0) as u32);
    }
    total
}

pub(crate) fn add_generic_mana_cost(
    cost: &crate::mana::ManaCost,
    increase: u32,
) -> crate::mana::ManaCost {
    if increase == 0 {
        return cost.clone();
    }
    use crate::mana::ManaSymbol;

    let mut new_pips = cost.pips().to_vec();
    let mut remaining = increase;
    while remaining > 0 {
        let chunk = remaining.min(u8::MAX as u32) as u8;
        new_pips.push(vec![ManaSymbol::Generic(chunk)]);
        remaining -= chunk as u32;
    }

    cost.with_pips(coalesce_plain_generic_pips(new_pips))
}

pub(crate) fn add_mana_cost(
    cost: &crate::mana::ManaCost,
    add: &crate::mana::ManaCost,
) -> crate::mana::ManaCost {
    let combined = cost.combined_with(add);
    combined.with_pips(coalesce_plain_generic_pips(combined.pips().to_vec()))
}

fn coalesce_plain_generic_pips(
    pips: Vec<Vec<crate::mana::ManaSymbol>>,
) -> Vec<Vec<crate::mana::ManaSymbol>> {
    use crate::mana::ManaSymbol;

    let generic_total = pips
        .iter()
        .filter_map(|pip| match pip.as_slice() {
            [ManaSymbol::Generic(amount)] => Some(*amount as u32),
            _ => None,
        })
        .fold(0u32, u32::saturating_add);
    if generic_total == 0 {
        return pips;
    }

    let mut non_generic = pips
        .into_iter()
        .filter(|pip| !matches!(pip.as_slice(), [ManaSymbol::Generic(_)]))
        .collect::<Vec<_>>();
    // Canonical mana-cost order keeps leading X symbols ahead of the generic
    // numeral and the remaining colored/hybrid pips after it.
    let insert_at = non_generic
        .iter()
        .take_while(|pip| matches!(pip.as_slice(), [ManaSymbol::X]))
        .count();
    let mut generic_pips = Vec::new();
    let mut remaining = generic_total;
    while remaining > 0 {
        let chunk = remaining.min(u8::MAX as u32) as u8;
        generic_pips.push(vec![ManaSymbol::Generic(chunk)]);
        remaining -= chunk as u32;
    }
    non_generic.splice(insert_at..insert_at, generic_pips);
    non_generic
}

/// CR 702.48c: unlike ordinary colored reductions, excess typed mana from
/// an offering reduces generic mana as well.
/// CR 118.7e–g: choose hybrid halves, ignore Phyrexian life halves,
/// and treat snow in a reduction as generic. Each returned cost is fixed.
pub(crate) fn offering_mana_reduction_choices(
    cost: &crate::mana::ManaCost,
) -> Vec<crate::mana::ManaCost> {
    let mut choices = vec![crate::mana::ManaCost::new()];
    for pip in cost.pips() {
        let halves: Vec<_> = pip
            .iter()
            .copied()
            .filter(|symbol| !matches!(symbol, ManaSymbol::Life(_) | ManaSymbol::X))
            .map(|symbol| {
                if symbol == ManaSymbol::Snow {
                    ManaSymbol::Generic(1)
                } else {
                    symbol
                }
            })
            .collect();
        if halves.is_empty() {
            continue;
        }
        let mut next = Vec::new();
        for previous in &choices {
            for half in &halves {
                let mut pips = previous.pips().to_vec();
                pips.push(vec![*half]);
                pips.sort_by_key(|pip| format!("{:?}", pip));
                let candidate = crate::mana::ManaCost::from_pips(pips);
                if !next.contains(&candidate) {
                    next.push(candidate);
                }
            }
        }
        choices = next;
    }
    choices
}

pub(crate) fn reduce_offering_mana_cost(
    cost: &crate::mana::ManaCost,
    reduction: &crate::mana::ManaCost,
) -> crate::mana::ManaCost {
    let mut result = cost.clone();
    let mut generic = 0u32;
    for pip in reduction.pips() {
        if let Some(ManaSymbol::Generic(amount)) = pip.first() {
            generic += *amount as u32;
            continue;
        }
        if let Some(index) = result
            .pips()
            .iter()
            .position(|candidate| candidate.iter().any(|symbol| pip.contains(symbol)))
        {
            let mut remaining = result.pips().to_vec();
            remaining.remove(index);
            result = result.with_pips(remaining);
        } else if pip.iter().any(|symbol| !matches!(symbol, ManaSymbol::X)) {
            generic += 1;
        }
    }
    result.reduce_generic(generic)
}

pub(crate) fn reduce_mana_cost(
    cost: &crate::mana::ManaCost,
    reduction: &crate::mana::ManaCost,
) -> crate::mana::ManaCost {
    reduce_mana_cost_with_spill(cost, reduction, false)
}

/// [`reduce_mana_cost`] for a colored reduction without "This effect reduces
/// only the amount of colored mana you pay": a colored or colorless reduction
/// symbol the cost doesn't require reduces one generic mana instead (CR
/// 118.7b-c).
pub(crate) fn reduce_mana_cost_spilling_to_generic(
    cost: &crate::mana::ManaCost,
    reduction: &crate::mana::ManaCost,
) -> crate::mana::ManaCost {
    reduce_mana_cost_with_spill(cost, reduction, true)
}

fn reduce_mana_cost_with_spill(
    cost: &crate::mana::ManaCost,
    reduction: &crate::mana::ManaCost,
    spill_to_generic: bool,
) -> crate::mana::ManaCost {
    use crate::mana::ManaSymbol;

    if reduction.pips().is_empty() {
        return cost.clone();
    }
    let mut pips = cost.pips().to_vec();
    let mut generic_reduction: u32 = 0;
    for red_pip in reduction.pips() {
        if red_pip.len() == 1
            && let ManaSymbol::Generic(amount) = red_pip[0]
        {
            generic_reduction = generic_reduction.saturating_add(amount as u32);
            continue;
        }
        // CR 107.4h / 118.7g: a snow symbol in a cost reduction reduces only
        // generic mana, never a {S} requirement.
        if red_pip.as_slice() == [ManaSymbol::Snow] {
            generic_reduction = generic_reduction.saturating_add(1);
            continue;
        }
        if let Some(pos) = pips.iter().position(|pip| pip == red_pip) {
            pips.remove(pos);
            continue;
        }
        // CR 118.7 / 107.4e-f: a hybrid or Phyrexian symbol is each of its
        // colors, so a {G} (or {G/P}) reduction reduces a {G/W} or {G/P} pip.
        // A Phyrexian reduction symbol never reduces life, and an announced
        // life payment ({Life}) isn't reducible by colored mana.
        let reduced_symbols = red_pip
            .iter()
            .filter(|symbol| {
                !matches!(
                    symbol,
                    ManaSymbol::Life(_) | ManaSymbol::X | ManaSymbol::Generic(_)
                )
            })
            .collect::<Vec<_>>();
        if reduced_symbols.is_empty() {
            continue;
        }
        // CR 118.7e: a hybrid reduction symbol lets the payer choose which
        // of its colors to reduce. When it could remove either of two
        // different one-color pips, the remaining requirement is exactly
        // "one of those two colors", i.e. a hybrid pip of both.
        let mut single_colors: Vec<ManaSymbol> = Vec::new();
        for pip in &pips {
            if let [symbol] = pip.as_slice()
                && reduced_symbols.contains(&symbol)
                && !single_colors.contains(symbol)
            {
                single_colors.push(*symbol);
            }
        }
        if let [first, second] = single_colors.as_slice() {
            let (first, second) = (*first, *second);
            if let Some(first_pos) = pips.iter().position(|pip| pip.as_slice() == [first]) {
                pips.remove(first_pos);
            }
            if let Some(second_pos) = pips.iter().position(|pip| pip.as_slice() == [second]) {
                pips.remove(second_pos);
            }
            pips.push(vec![first, second]);
            continue;
        }
        if let Some(pos) = pips
            .iter()
            .enumerate()
            .filter(|(_, pip)| pip.iter().any(|symbol| reduced_symbols.contains(&symbol)))
            .min_by_key(|(index, pip)| (pip.len(), *index))
            .map(|(index, _)| index)
        {
            pips.remove(pos);
        } else if spill_to_generic {
            generic_reduction = generic_reduction.saturating_add(1);
        }
    }
    let reduced = cost.with_pips(pips);
    if generic_reduction > 0 {
        reduced.reduce_generic(generic_reduction)
    } else {
        reduced
    }
}

pub(crate) fn resolve_cost_modifier_value(
    game: &GameState,
    player: PlayerId,
    spell: &crate::object::Object,
    value: &crate::effect::Value,
) -> i32 {
    let mut dm = SelectFirstDecisionMaker;
    let ctx = ExecutionContext::new(spell.id, player, &mut dm);
    resolve_value(game, value, &ctx).unwrap_or(0)
}

pub(crate) fn resolve_cost_modifier_value_for_source(
    game: &GameState,
    source: ObjectId,
    controller: PlayerId,
    value: &crate::effect::Value,
) -> i32 {
    let mut dm = SelectFirstDecisionMaker;
    let ctx = ExecutionContext::new(source, controller, &mut dm);
    resolve_value(game, value, &ctx).unwrap_or(0)
}

/// Resolve a spell cost modifier's amount for a cast by `caster`, who is
/// "that player" in the amount ("for each other spell that player has cast
/// this turn", Damping Sphere).
pub(crate) fn resolve_cost_modifier_value_for_cast(
    game: &GameState,
    source: ObjectId,
    controller: PlayerId,
    caster: PlayerId,
    value: &crate::effect::Value,
) -> i32 {
    let mut dm = SelectFirstDecisionMaker;
    let mut ctx = ExecutionContext::new(source, controller, &mut dm);
    ctx.iteration.iterated_player = Some(caster);
    resolve_value(game, value, &ctx).unwrap_or(0)
}

/// Calculate the number of cards that need to be exiled for Delve.
///
/// Returns how many cards from graveyard should be exiled based on:
/// - The generic mana remaining in the cost after other reductions
/// - The player's available mana
/// - Cards available in graveyard
pub fn calculate_delve_exile_count(
    game: &GameState,
    player: PlayerId,
    spell: &crate::object::Object,
    base_cost: &crate::mana::ManaCost,
) -> u32 {
    calculate_delve_exile_count_with_targets(game, player, spell, base_cost, 1)
}

/// Calculate the number of cards to exile for Delve with explicit target count.
pub fn calculate_delve_exile_count_with_targets(
    game: &GameState,
    player: PlayerId,
    spell: &crate::object::Object,
    base_cost: &crate::mana::ManaCost,
    chosen_target_count: usize,
) -> u32 {
    // Only calculate Delve if the spell actually has Delve
    let has_delve_ability = spell_has_delve(game, spell);
    if !has_delve_ability {
        return 0;
    }

    // First apply other cost reductions (like Affinity)
    let mut cost_after_reductions = base_cost.clone();

    let mut totals = collect_spell_cost_modifiers(
        game,
        player,
        spell,
        chosen_target_count,
        &[],
        &CastingMethod::Normal,
        None,
    );
    totals.add_generic_reduction(affinity_for_artifacts_reduction(game, player, spell));
    cost_after_reductions = totals.apply(&cost_after_reductions);

    // Now calculate how much generic mana remains
    let generic_remaining = cost_after_reductions.generic_mana_total();

    // Get graveyard count and calculate exile amount
    let graveyard_count = game
        .player(player)
        .map(|player| {
            player
                .graveyard
                .iter()
                .filter(|&&card_id| card_id != spell.id)
                .count() as u32
        })
        .unwrap_or(0);

    // Exile up to the generic mana cost (maximum Delve)
    generic_remaining.min(graveyard_count)
}

/// Count the number of artifacts controlled by a player.
pub fn count_artifacts_controlled(game: &GameState, player: PlayerId) -> u32 {
    let view = DerivedGameView::new(game);
    count_artifacts_controlled_with_view(game, player, &view)
}

pub(crate) fn count_artifacts_controlled_with_view(
    game: &GameState,
    player: PlayerId,
    view: &DerivedGameView<'_>,
) -> u32 {
    game.battlefield
        .iter()
        .filter(|&&id| {
            if let Some(obj) = game.object(id) {
                game.controller_of(obj) == player
                    && view.object_has_card_type(id, crate::types::CardType::Artifact)
            } else {
                false
            }
        })
        .count() as u32
}

/// Check if a spell has the Delve ability.
pub fn has_delve(spell: &crate::object::Object) -> bool {
    use crate::ability::AbilityKind;
    spell.abilities.iter().any(|a| {
        if let AbilityKind::Static(s) = &a.kind {
            s.has_delve()
        } else {
            false
        }
    })
}

/// Affinity for artifacts as a generic reduction to fold into the totals.
pub(crate) fn affinity_for_artifacts_reduction(
    game: &GameState,
    player: PlayerId,
    spell: &crate::object::Object,
) -> u32 {
    let view = DerivedGameView::new(game);
    affinity_for_artifacts_reduction_with_view(game, player, spell, &view)
}

/// Static abilities other permanents currently grant to this spell ("Spells
/// you cast have affinity for artifacts", "Nonartifact spells you cast have
/// improvise"). CR 601.2f: the total cost is determined with the spell on the
/// stack, where these grants apply; a card still in hand is evaluated as the
/// prospective cast so legality agrees with payment.
pub(crate) fn spell_granted_cost_static_abilities(
    game: &GameState,
    spell: &crate::object::Object,
) -> Vec<crate::static_abilities::StaticAbility> {
    let view = DerivedGameView::new(game);
    let caster = game.controller_of(spell);
    let mut granted = Vec::new();
    for &permanent in &game.battlefield {
        let Some(static_abilities) = view.static_abilities_rc(permanent) else {
            continue;
        };
        for static_ability in static_abilities.iter() {
            let Some(ironsmith_core::StaticAbilityPayload::GrantObjectAbilityForFilter(grant)) =
                static_ability.compiled_model().map(|model| &model.payload)
            else {
                continue;
            };
            if !static_ability.is_active(game, permanent) {
                continue;
            }
            for granted_ability in std::iter::once(&grant.ability).chain(grant.additional_abilities.iter()) {
            let ability =
                crate::static_abilities::StaticAbilityModelInterpreter::ability_from_model(
                    granted_ability,
                );
            let crate::ability::AbilityKind::Static(granted_static) = ability.kind else {
                continue;
            };
            if !(granted_static.compiled_model().is_some_and(|model| matches!(model.payload,
                    ironsmith_core::StaticAbilityPayload::SpellManaSpendingRestriction(_)))
                || granted_static.has_convoke()
                || granted_static.has_improvise()
                || granted_static.has_delve()
                || granted_static.id()
                    == crate::static_abilities::StaticAbilityId::AffinityForArtifacts
                || granted_static.this_spell_cost_reduction().is_some()
                || granted_static
                    .this_spell_cost_reduction_mana_cost()
                    .is_some())
            {
                continue;
            }
            let Some(permanent_object) = game.object(permanent) else {
                continue;
            };
            let ctx = game
                .filter_context_for(game.controller_of(permanent_object), Some(permanent))
                .with_caster(Some(caster))
                .with_prospective_cast(spell.id);
            let mut filter = grant.filter.clone();
            filter.zone = None;
            if filter.matches_non_recursive(spell, &ctx, game) {
                granted.push(granted_static);
            }
            }
        }
    }
    granted
}

/// Convoke, intrinsic or granted to the spell (CR 702.51a).
pub fn spell_has_convoke(game: &GameState, spell: &crate::object::Object) -> bool {
    has_convoke(spell)
        || spell_granted_cost_static_abilities(game, spell)
            .iter()
            .any(|ability| ability.has_convoke())
}

/// Improvise, intrinsic or granted to the spell (CR 702.126a).
pub fn spell_has_improvise(game: &GameState, spell: &crate::object::Object) -> bool {
    has_improvise(spell)
        || spell_granted_cost_static_abilities(game, spell)
            .iter()
            .any(|ability| ability.has_improvise())
}

/// Delve, intrinsic or granted to the spell (CR 702.66a).
pub fn spell_has_delve(game: &GameState, spell: &crate::object::Object) -> bool {
    has_delve(spell)
        || spell_granted_cost_static_abilities(game, spell)
            .iter()
            .any(|ability| ability.has_delve())
}

/// Count cards in a player's graveyard (for Delve calculation).
pub fn count_cards_in_graveyard(game: &GameState, player: PlayerId) -> u32 {
    game.player(player)
        .map(|p| p.graveyard.len() as u32)
        .unwrap_or(0)
}

/// Compute potential mana available to a player.
///
/// This includes:
/// - Current mana pool
/// - Mana from all untapped lands and mana sources that can be activated
///
/// Returns a ManaPool representing the maximum mana the player could produce.
pub fn compute_potential_mana(game: &GameState, player: PlayerId) -> crate::player::ManaPool {
    let view = DerivedGameView::new(game);
    compute_potential_mana_with_view(game, player, &view)
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) struct AvailableManaSource {
    source_id: ObjectId,
    outputs: Vec<Vec<ManaSymbol>>,
    from_snow_source: bool,
}

#[derive(Debug, Clone, PartialEq, Eq, Hash)]
struct ManaPaymentSearchKey {
    pip_index: usize,
    white: u32,
    blue: u32,
    black: u32,
    red: u32,
    green: u32,
    colorless: u32,
    snow_white: u32,
    snow_blue: u32,
    snow_black: u32,
    snow_red: u32,
    snow_green: u32,
    snow_colorless: u32,
    life_to_pay: u32,
    used_sources_mask: u128,
}

impl ManaPaymentSearchKey {
    fn new(
        pip_index: usize,
        pool: &crate::player::ManaPool,
        snow_pool: &crate::player::ManaPool,
        life_to_pay: u32,
        used_sources_mask: u128,
    ) -> Self {
        Self {
            pip_index,
            white: pool.white,
            blue: pool.blue,
            black: pool.black,
            red: pool.red,
            green: pool.green,
            colorless: pool.colorless,
            snow_white: snow_pool.white,
            snow_blue: snow_pool.blue,
            snow_black: snow_pool.black,
            snow_red: snow_pool.red,
            snow_green: snow_pool.green,
            snow_colorless: snow_pool.colorless,
            life_to_pay,
            used_sources_mask,
        }
    }
}

pub(crate) fn can_pay_mana_cost_with_available_sources(
    game: &GameState,
    player: PlayerId,
    source: Option<ObjectId>,
    cost: &crate::mana::ManaCost,
    x_value: u32,
    reason: crate::costs::PaymentReason,
    mana_spend_policy: &crate::player::ManaSpendPolicy,
    allow_black_life: bool,
    view: &DerivedGameView<'_>,
) -> bool {
    if resumable::mana_payment_is_assumed() {
        return true;
    }
    // The legacy color-only solver cannot retain production evidence. Route
    // constrained costs through the same full request used at payment, before
    // projecting to pips or entering that solver's symbol-only memo cache.
    if !cost.spending_restrictions().is_empty() || cost.has_waterbend_obligation()
        || payment_requires_stateful_sources(game, player, view)
        || crate::mana_payment::has_mana_modifying_replacements(game)
        || crate::mana_payment::has_potential_mana_triggers(game, view)
    {
        let Some(source) = source else {
            return false;
        };
        let mut request =
            crate::mana_payment::ManaPaymentRequest::new(player, source, reason, cost.clone())
                .with_x(x_value)
                .with_spend_policy(mana_spend_policy.clone());
        request.allow_black_life = allow_black_life;
        let mut prospective;
        let payment_game = if reason == crate::costs::PaymentReason::CastSpell
            && game
                .object(source)
                .is_some_and(|object| object.zone != Zone::Stack)
        {
            prospective = game.clone();
            prospective.project_spell_for_payment(source);
            &prospective
        } else {
            game
        };
        return resumable::check_payment(payment_game, &request);
    }

    let Some(player_obj) = game.player(player) else {
        return false;
    };

    let mut pips = expand_mana_cost_to_unit_pips(cost, x_value, allow_black_life);
    pips.sort_by_key(|pip| pip_payment_sort_key(pip));
    let has_life_payment_option = pips
        .iter()
        .flatten()
        .any(|symbol| matches!(symbol, ManaSymbol::Life(_)));
    let max_life_payment = if has_life_payment_option
        && game.can_lose_life(player)
        && !game.player_cant_pay_life_for_payment_reason(player, reason)
    {
        u32::try_from(player_obj.life).unwrap_or(0)
    } else {
        0
    };

    let sources = available_mana_sources_for_payment(game, player, view);
    let snow_pool = snow_mana_pool(game, player, source, reason);
    let source_policies = sources
        .iter()
        .map(|mana_source| {
            let mut policy = mana_spend_policy.clone();
            if game.can_spend_mana_as_any_color_from_mana_source(
                player,
                source,
                mana_source.source_id,
            ) {
                policy.allow_mode(ironsmith_core::value_model::ManaSpendMode::AnyColor);
            }
            policy
        })
        .collect::<Vec<_>>();
    resumable::solve(
        &pips,
        player_obj.mana_pool.clone(),
        snow_pool,
        &sources,
        max_life_payment,
        mana_spend_policy,
        &source_policies,
    )
}

fn expand_mana_cost_to_unit_pips(
    cost: &crate::mana::ManaCost,
    x_value: u32,
    allow_black_life: bool,
) -> Vec<Vec<ManaSymbol>> {
    let mut pips = Vec::new();
    for pip in cost.pips() {
        if pip.len() == 1 {
            match pip[0] {
                ManaSymbol::Generic(n) => {
                    pips.extend((0..n).map(|_| vec![ManaSymbol::Generic(1)]));
                    continue;
                }
                ManaSymbol::X => {
                    pips.extend((0..x_value).map(|_| vec![ManaSymbol::Generic(1)]));
                    continue;
                }
                ManaSymbol::Black if allow_black_life => {
                    pips.push(vec![ManaSymbol::Black, ManaSymbol::Life(2)]);
                    continue;
                }
                _ => {}
            }
        }
        pips.push(pip.clone());
    }
    pips
}

fn pip_payment_sort_key(pip: &[ManaSymbol]) -> (u8, usize) {
    let has_generic = pip
        .iter()
        .any(|symbol| matches!(symbol, ManaSymbol::Generic(_) | ManaSymbol::X));
    let has_life_only = pip
        .iter()
        .all(|symbol| matches!(symbol, ManaSymbol::Life(_)));
    let has_colored = pip.iter().any(|symbol| {
        matches!(
            symbol,
            ManaSymbol::White
                | ManaSymbol::Blue
                | ManaSymbol::Black
                | ManaSymbol::Red
                | ManaSymbol::Green
        )
    });
    let has_colorless_or_snow = pip
        .iter()
        .any(|symbol| matches!(symbol, ManaSymbol::Colorless | ManaSymbol::Snow));

    let class = if has_colored && !has_generic {
        0
    } else if has_colorless_or_snow && !has_generic {
        1
    } else if has_colored {
        2
    } else if has_generic {
        3
    } else if has_life_only {
        4
    } else {
        5
    };
    (class, pip.len())
}

fn available_mana_sources_for_payment(
    game: &GameState,
    player: PlayerId,
    view: &DerivedGameView<'_>,
) -> Rc<Vec<AvailableManaSource>> {
    use crate::ability::AbilityKind;
    if let Some(cached) = view.cached_available_payment_sources(player) {
        return cached;
    }

    let mut sources = Vec::new();
    let analysis = view.simple_battlefield_mana_analysis(player);

    for &perm_id in analysis.mana_source_ids() {
        let Some(object) = game.object(perm_id) else {
            continue;
        };
        let abilities = view
            .abilities_rc(perm_id)
            .unwrap_or_else(|| std::sync::Arc::new(object.abilities_vec()));
        let mut outputs_for_permanent = Vec::new();
        for &ability_index in analysis.mana_ability_indices_for(perm_id) {
            let Some(ability) = abilities.get(ability_index) else {
                continue;
            };
            let AbilityKind::Activated(mana_ability) = &ability.kind else {
                continue;
            };
            if analysis
                .activatable_indices_for(perm_id)
                .contains(&ability_index)
                || crate::special_actions::can_activate_mana_ability_check_with_view(
                    game,
                    player,
                    perm_id,
                    ability_index,
                    ability,
                    view,
                    None,
                )
                .is_ok()
            {
                let outputs = mana_ability_output_options(game, player, perm_id, mana_ability);
                for output in outputs {
                    if !outputs_for_permanent.contains(&output) {
                        outputs_for_permanent.push(output);
                    }
                }
            }
        }
        if !outputs_for_permanent.is_empty() {
            sources.push(AvailableManaSource {
                source_id: perm_id,
                outputs: outputs_for_permanent,
                from_snow_source: game
                    .current_has_supertype(perm_id, crate::types::Supertype::Snow),
            });
        }
    }

    let sources = Rc::new(sources);
    view.cache_available_payment_sources(player, Rc::clone(&sources));
    sources
}

fn snow_mana_pool(
    game: &GameState,
    player: PlayerId,
    payment_source: Option<ObjectId>,
    reason: crate::costs::PaymentReason,
) -> crate::player::ManaPool {
    let Some(player_obj) = game.player(player) else {
        return crate::player::ManaPool::default();
    };
    let mut snow_pool = crate::player::ManaPool::default();
    let mut used_restricted = std::collections::HashSet::new();
    for unit in &player_obj.mana_source_provenance {
        let from_snow_source =
            unit.snapshot.as_ref().is_some_and(|snapshot| {
                snapshot.supertypes.contains(&crate::types::Supertype::Snow)
            }) || (unit.snapshot.is_none()
                && game.current_has_supertype(unit.source, crate::types::Supertype::Snow));
        if !from_snow_source
            || snow_pool.amount(unit.symbol) >= player_obj.mana_pool.amount(unit.symbol)
        {
            continue;
        }
        if unit.restricted {
            let Some(index) = player_obj
                .restricted_mana
                .iter()
                .enumerate()
                .find(|(index, restricted)| {
                    !used_restricted.contains(index)
                        && restricted.symbol == unit.symbol
                        && restricted.source == unit.source
                })
                .map(|(index, _)| index)
            else {
                continue;
            };
            used_restricted.insert(index);
            if !game.restricted_mana_unit_is_payable_for_reason(
                &player_obj.restricted_mana[index],
                payment_source,
                reason,
            ) {
                continue;
            }
        }
        snow_pool.add(unit.symbol, 1);
    }
    snow_pool
}

fn mana_ability_output_options(
    game: &GameState,
    player: PlayerId,
    source: ObjectId,
    mana_ability: &crate::ability::ActivatedAbility,
) -> Vec<Vec<ManaSymbol>> {
    use crate::effects::{
        AddColorlessManaEffect, AddManaEffect, AddManaOfAnyColorEffect, AddManaOfAnyOneColorEffect,
        AddScaledManaEffect,
    };

    if let Some(output) = mana_ability.mana_output.as_ref()
        && !output.is_empty()
    {
        return vec![output.clone()];
    }

    let resolve_amount = |value: &crate::effect::Value| -> usize {
        let mut dm = SelectFirstDecisionMaker;
        let ctx = ExecutionContext::new(source, player, &mut dm);
        resolve_value(game, value, &ctx).unwrap_or(0).max(0) as usize
    };

    let mut outputs = vec![Vec::new()];
    for effect in crate::ability::selected_resolution_effects_for_current_state(
        &mana_ability.effects,
        game,
        source,
        player,
    ) {
        let effect_outputs = if let Some(add_mana) = effect.downcast_ref::<AddManaEffect>() {
            vec![add_mana.mana.clone()]
        } else if let Some(add_colorless) = effect.downcast_ref::<AddColorlessManaEffect>() {
            vec![vec![
                ManaSymbol::Colorless;
                resolve_amount(&add_colorless.amount)
            ]]
        } else if let Some(add_scaled) = effect.downcast_ref::<AddScaledManaEffect>() {
            let repeats = resolve_amount(&add_scaled.amount);
            let mut output = Vec::new();
            for _ in 0..repeats {
                output.extend(add_scaled.mana.iter().copied());
            }
            vec![output]
        } else if let Some(add_any_color) = effect.downcast_ref::<AddManaOfAnyColorEffect>() {
            let colors = add_any_color.available_colors.as_deref().unwrap_or(&[
                crate::color::Color::White,
                crate::color::Color::Blue,
                crate::color::Color::Black,
                crate::color::Color::Red,
                crate::color::Color::Green,
            ]);
            any_color_output_options(colors, resolve_amount(&add_any_color.amount), false)
        } else if let Some(add_any_one_color) = effect.downcast_ref::<AddManaOfAnyOneColorEffect>()
        {
            any_color_output_options(
                &[
                    crate::color::Color::White,
                    crate::color::Color::Blue,
                    crate::color::Color::Black,
                    crate::color::Color::Red,
                    crate::color::Color::Green,
                ],
                resolve_amount(&add_any_one_color.amount),
                true,
            )
        } else if let Some(symbols) = effect.producible_mana_symbols(game, source, player) {
            symbols
                .into_iter()
                .filter(|symbol| is_payable_mana_symbol(*symbol))
                .map(|symbol| vec![symbol])
                .collect()
        } else {
            Vec::new()
        };

        if effect_outputs.is_empty() {
            continue;
        }
        outputs = combine_mana_output_options(&outputs, &effect_outputs);
    }

    let outputs = outputs
        .into_iter()
        .filter(|output| !output.is_empty())
        .collect::<Vec<_>>();
    if outputs.is_empty() {
        let inferred = mana_ability.inferred_mana_symbols(game, source, player);
        if inferred.is_empty() {
            Vec::new()
        } else {
            vec![inferred]
        }
    } else {
        outputs
    }
}

fn any_color_output_options(
    colors: &[crate::color::Color],
    amount: usize,
    same_color: bool,
) -> Vec<Vec<ManaSymbol>> {
    if amount == 0 {
        return vec![Vec::new()];
    }
    if same_color {
        return colors
            .iter()
            .map(|color| vec![ManaSymbol::from_color(*color); amount])
            .collect();
    }

    let mut outputs = vec![Vec::new()];
    for _ in 0..amount {
        let mut next = Vec::new();
        for output in &outputs {
            for color in colors {
                let mut candidate = output.clone();
                candidate.push(ManaSymbol::from_color(*color));
                next.push(candidate);
                if next.len() >= 128 {
                    return next;
                }
            }
        }
        outputs = next;
    }
    outputs
}

fn combine_mana_output_options(
    base: &[Vec<ManaSymbol>],
    next: &[Vec<ManaSymbol>],
) -> Vec<Vec<ManaSymbol>> {
    let mut combined = Vec::new();
    for left in base {
        for right in next {
            let mut output = left.clone();
            output.extend(right.iter().copied());
            combined.push(output);
            if combined.len() >= 128 {
                return combined;
            }
        }
    }
    combined
}

#[allow(clippy::too_many_arguments)]
#[cfg(test)]
fn can_pay_expanded_pips(
    game: &GameState,
    player: PlayerId,
    pips: &[Vec<ManaSymbol>],
    pip_index: usize,
    pool: crate::player::ManaPool,
    snow_pool: crate::player::ManaPool,
    sources: &[AvailableManaSource],
    used_sources_mask: u128,
    life_to_pay: u32,
    max_life_payment: u32,
    mana_spend_policy: &crate::player::ManaSpendPolicy,
    payment_source: Option<ObjectId>,
    failed_states: &mut std::collections::HashSet<ManaPaymentSearchKey>,
) -> bool {
    if pip_index >= pips.len() {
        return life_to_pay <= max_life_payment;
    }

    let key =
        ManaPaymentSearchKey::new(pip_index, &pool, &snow_pool, life_to_pay, used_sources_mask);
    if failed_states.contains(&key) {
        return false;
    }

    let pip = &pips[pip_index];
    for &symbol in pip {
        if let ManaSymbol::Life(amount) = symbol {
            let next_life = life_to_pay.saturating_add(amount as u32);
            if next_life <= max_life_payment
                && can_pay_expanded_pips(
                    game,
                    player,
                    pips,
                    pip_index + 1,
                    pool.clone(),
                    snow_pool.clone(),
                    sources,
                    used_sources_mask,
                    next_life,
                    max_life_payment,
                    mana_spend_policy,
                    payment_source,
                    failed_states,
                )
            {
                return true;
            }
            continue;
        }

        let mut pool_after = pool.clone();
        let mut snow_pool_after = snow_pool.clone();
        if remove_mana_for_pip(
            &mut pool_after,
            &mut snow_pool_after,
            symbol,
            mana_spend_policy,
        ) && can_pay_expanded_pips(
            game,
            player,
            pips,
            pip_index + 1,
            pool_after,
            snow_pool_after,
            sources,
            used_sources_mask,
            life_to_pay,
            max_life_payment,
            mana_spend_policy,
            payment_source,
            failed_states,
        ) {
            return true;
        }

        for (source_index, source) in sources.iter().enumerate() {
            let source_mask = 1u128 << source_index;
            if used_sources_mask & source_mask != 0 {
                continue;
            }
            let mut source_policy = mana_spend_policy.clone();
            if game.can_spend_mana_as_any_color_from_mana_source(
                player,
                payment_source,
                source.source_id,
            ) {
                source_policy.allow_mode(ironsmith_core::value_model::ManaSpendMode::AnyColor);
            }
            for output in &source.outputs {
                if let Some((pool_from_output, snow_pool_from_output)) =
                    consume_output_for_pip(output, symbol, &source_policy, source.from_snow_source)
                {
                    let mut combined_pool = pool.clone();
                    add_pool(&mut combined_pool, &pool_from_output);
                    let mut combined_snow_pool = snow_pool.clone();
                    add_pool(&mut combined_snow_pool, &snow_pool_from_output);
                    let can_pay_rest = can_pay_expanded_pips(
                        game,
                        player,
                        pips,
                        pip_index + 1,
                        combined_pool,
                        combined_snow_pool,
                        sources,
                        used_sources_mask | source_mask,
                        life_to_pay,
                        max_life_payment,
                        mana_spend_policy,
                        payment_source,
                        failed_states,
                    );
                    if can_pay_rest {
                        return true;
                    }
                }
            }
        }
    }

    failed_states.insert(key);
    false
}

#[allow(clippy::too_many_arguments)]
#[cfg(test)]
fn can_pay_expanded_pips_large_source_count(
    game: &GameState,
    player: PlayerId,
    pips: &[Vec<ManaSymbol>],
    pip_index: usize,
    pool: crate::player::ManaPool,
    snow_pool: crate::player::ManaPool,
    sources: &[AvailableManaSource],
    used_sources: &mut [bool],
    life_to_pay: u32,
    max_life_payment: u32,
    mana_spend_policy: &crate::player::ManaSpendPolicy,
    payment_source: Option<ObjectId>,
) -> bool {
    if pip_index >= pips.len() {
        return life_to_pay <= max_life_payment;
    }

    let pip = &pips[pip_index];
    for &symbol in pip {
        if let ManaSymbol::Life(amount) = symbol {
            let next_life = life_to_pay.saturating_add(amount as u32);
            if next_life <= max_life_payment
                && can_pay_expanded_pips_large_source_count(
                    game,
                    player,
                    pips,
                    pip_index + 1,
                    pool.clone(),
                    snow_pool.clone(),
                    sources,
                    used_sources,
                    next_life,
                    max_life_payment,
                    mana_spend_policy,
                    payment_source,
                )
            {
                return true;
            }
            continue;
        }

        let mut pool_after = pool.clone();
        let mut snow_pool_after = snow_pool.clone();
        if remove_mana_for_pip(
            &mut pool_after,
            &mut snow_pool_after,
            symbol,
            mana_spend_policy,
        ) && can_pay_expanded_pips_large_source_count(
            game,
            player,
            pips,
            pip_index + 1,
            pool_after,
            snow_pool_after,
            sources,
            used_sources,
            life_to_pay,
            max_life_payment,
            mana_spend_policy,
            payment_source,
        ) {
            return true;
        }

        for (source_index, source) in sources.iter().enumerate() {
            if used_sources[source_index] {
                continue;
            }
            let mut source_policy = mana_spend_policy.clone();
            if game.can_spend_mana_as_any_color_from_mana_source(
                player,
                payment_source,
                source.source_id,
            ) {
                source_policy.allow_mode(ironsmith_core::value_model::ManaSpendMode::AnyColor);
            }
            for output in &source.outputs {
                if let Some((pool_from_output, snow_pool_from_output)) =
                    consume_output_for_pip(output, symbol, &source_policy, source.from_snow_source)
                {
                    let mut combined_pool = pool.clone();
                    add_pool(&mut combined_pool, &pool_from_output);
                    let mut combined_snow_pool = snow_pool.clone();
                    add_pool(&mut combined_snow_pool, &snow_pool_from_output);
                    used_sources[source_index] = true;
                    let can_pay_rest = can_pay_expanded_pips_large_source_count(
                        game,
                        player,
                        pips,
                        pip_index + 1,
                        combined_pool,
                        combined_snow_pool,
                        sources,
                        used_sources,
                        life_to_pay,
                        max_life_payment,
                        mana_spend_policy,
                        payment_source,
                    );
                    used_sources[source_index] = false;
                    if can_pay_rest {
                        return true;
                    }
                }
            }
        }
    }

    false
}

fn consume_output_for_pip(
    output: &[ManaSymbol],
    pip: ManaSymbol,
    mana_spend_policy: &crate::player::ManaSpendPolicy,
    from_snow_source: bool,
) -> Option<(crate::player::ManaPool, crate::player::ManaPool)> {
    for (idx, &produced) in output.iter().enumerate() {
        if mana_symbol_can_pay_pip(produced, pip, mana_spend_policy, from_snow_source) {
            let mut remainder = crate::player::ManaPool::default();
            let mut snow_remainder = crate::player::ManaPool::default();
            for (other_idx, &symbol) in output.iter().enumerate() {
                if other_idx != idx && is_payable_mana_symbol(symbol) {
                    remainder.add(symbol, 1);
                    if from_snow_source {
                        snow_remainder.add(symbol, 1);
                    }
                }
            }
            return Some((remainder, snow_remainder));
        }
    }
    None
}

fn add_pool(pool: &mut crate::player::ManaPool, addition: &crate::player::ManaPool) {
    for symbol in PAYABLE_MANA_SYMBOLS {
        let amount = addition.amount(symbol);
        if amount > 0 {
            pool.add(symbol, amount);
        }
    }
}

const PAYABLE_MANA_SYMBOLS: [ManaSymbol; 6] = [
    ManaSymbol::White,
    ManaSymbol::Blue,
    ManaSymbol::Black,
    ManaSymbol::Red,
    ManaSymbol::Green,
    ManaSymbol::Colorless,
];

fn remove_mana_for_pip(
    pool: &mut crate::player::ManaPool,
    snow_pool: &mut crate::player::ManaPool,
    pip: ManaSymbol,
    mana_spend_policy: &crate::player::ManaSpendPolicy,
) -> bool {
    match pip {
        ManaSymbol::White
        | ManaSymbol::Blue
        | ManaSymbol::Black
        | ManaSymbol::Red
        | ManaSymbol::Green => {
            for symbol in PAYABLE_MANA_SYMBOLS {
                if mana_spend_policy.can_pay_symbol(symbol, pip)
                    && remove_pool_unit_preserving_snow(pool, snow_pool, symbol)
                {
                    return true;
                }
            }
            false
        }
        ManaSymbol::Colorless => {
            for symbol in PAYABLE_MANA_SYMBOLS {
                if mana_spend_policy.can_pay_symbol(symbol, ManaSymbol::Colorless)
                    && remove_pool_unit_preserving_snow(pool, snow_pool, symbol)
                {
                    return true;
                }
            }
            false
        }
        ManaSymbol::Generic(_) => remove_any_payable_mana(pool, snow_pool),
        ManaSymbol::Snow => remove_any_snow_mana(pool, snow_pool),
        ManaSymbol::Life(_) | ManaSymbol::X => false,
    }
}

fn remove_pool_unit_preserving_snow(
    pool: &mut crate::player::ManaPool,
    snow_pool: &mut crate::player::ManaPool,
    symbol: ManaSymbol,
) -> bool {
    if pool.amount(symbol) > snow_pool.amount(symbol) {
        return pool.remove(symbol, 1);
    }
    if pool.remove(symbol, 1) {
        snow_pool.remove(symbol, 1);
        return true;
    }
    false
}

fn remove_any_payable_mana(
    pool: &mut crate::player::ManaPool,
    snow_pool: &mut crate::player::ManaPool,
) -> bool {
    for symbol in PAYABLE_MANA_SYMBOLS {
        if remove_pool_unit_preserving_snow(pool, snow_pool, symbol) {
            return true;
        }
    }
    false
}

fn remove_any_snow_mana(
    pool: &mut crate::player::ManaPool,
    snow_pool: &mut crate::player::ManaPool,
) -> bool {
    for symbol in PAYABLE_MANA_SYMBOLS {
        if snow_pool.remove(symbol, 1) {
            return pool.remove(symbol, 1);
        }
    }
    false
}

fn mana_symbol_can_pay_pip(
    produced: ManaSymbol,
    pip: ManaSymbol,
    mana_spend_policy: &crate::player::ManaSpendPolicy,
    from_snow_source: bool,
) -> bool {
    match pip {
        ManaSymbol::Generic(_) => is_payable_mana_symbol(produced),
        ManaSymbol::White
        | ManaSymbol::Blue
        | ManaSymbol::Black
        | ManaSymbol::Red
        | ManaSymbol::Green
        | ManaSymbol::Colorless => mana_spend_policy.can_pay_symbol(produced, pip),
        ManaSymbol::Snow => from_snow_source && is_payable_mana_symbol(produced),
        ManaSymbol::Life(_) | ManaSymbol::X => false,
    }
}

fn is_payable_mana_symbol(symbol: ManaSymbol) -> bool {
    matches!(
        symbol,
        ManaSymbol::White
            | ManaSymbol::Blue
            | ManaSymbol::Black
            | ManaSymbol::Red
            | ManaSymbol::Green
            | ManaSymbol::Colorless
    )
}

pub(crate) fn compute_potential_mana_with_view(
    game: &GameState,
    player: PlayerId,
    view: &DerivedGameView<'_>,
) -> crate::player::ManaPool {
    use crate::ability::AbilityKind;

    // Start with current mana pool
    let mut potential = game
        .player(player)
        .map(|p| p.mana_pool.clone())
        .unwrap_or_default();
    let simple_mana_analysis = view.simple_battlefield_mana_analysis(player);

    // Add mana from all available mana abilities.
    // The pass-local analysis already found the controlled mana sources.
    for &perm_id in simple_mana_analysis.mana_source_ids() {
        let Some(perm) = game.object(perm_id) else {
            continue;
        };

        let mana_ability_indices = simple_mana_analysis.mana_ability_indices_for(perm_id);
        if mana_ability_indices.len() == 1
            && let Some(symbols) = simple_mana_analysis.first_output_for(perm_id)
        {
            for mana in symbols {
                potential.add(*mana, 1);
            }
            continue;
        }

        let cached_abilities = view.abilities_rc(perm_id);
        let abilities = cached_abilities.as_deref().unwrap_or(&perm.abilities);
        for &ability_idx in mana_ability_indices {
            let Some(ability) = abilities.get(ability_idx) else {
                continue;
            };
            let AbilityKind::Activated(mana_ability) = &ability.kind else {
                continue;
            };
            if !mana_ability.is_runtime_mana_ability(game, perm_id, game.controller_of(perm)) {
                continue;
            }
            let mut facts = ActivationCostAbility::of(game, player, perm_id, mana_ability);
            facts.ability_index = Some(ability_idx);
            let free_uses = crate::activation_cost_alternatives::available_uses(game, perm_id, facts, &mana_ability.mana_cost, view);
            if mana_ability.has_tap_cost() && !game.can_activate_tap_abilities_of(perm_id) && free_uses == 0 {
                continue;
            }
            // Source discovery assumes mana funding to avoid recursing into
            // itself; all non-mana dependencies still use the shared owner.
            let mut decision_maker = crate::decision::SelectFirstDecisionMaker;
            let mut execution =
                crate::effects::ExecutionContext::new(perm_id, player, &mut decision_maker);
            let normal_payable = crate::special_actions::can_pay_non_mana_parts_of_cost_in_context(
                game, player, perm_id, &mana_ability.mana_cost, mana_ability.payment_reason(game, perm_id, player), &mut execution,
            ).is_ok();
            let effective_cost = crate::activation_cost_alternatives::unpriced_cost(game, perm_id, facts, &mana_ability.mana_cost, view);
            let can_activate = crate::special_actions::can_pay_non_mana_parts_of_cost_in_context(
                game,
                player,
                perm_id,
                &effective_cost,
                mana_ability.payment_reason(game, perm_id, player),
                &mut execution,
            )
            .is_ok();

            // Also check activation condition if present
            let condition_met = mana_ability
                .activation_condition
                .as_ref()
                .is_none_or(|cond| {
                    check_mana_ability_condition_for_potential(
                        game,
                        player,
                        perm_id,
                        ability_idx,
                        cond,
                    )
                });

            if can_activate && condition_met {
                // Add the mana this ability could produce, preserving
                // multiplicity for effects like Black Lotus.
                for mana in
                    inferred_potential_mana_symbols_for_ability(game, perm_id, player, mana_ability)
                {
                    potential.add(mana, u32::from(normal_payable).saturating_add(free_uses).max(1));
                }
            }
        }
    }

    potential
}

pub(crate) fn simple_battlefield_mana_ability_output(
    game: &GameState,
    player: PlayerId,
    permanent_id: ObjectId,
    ability_index: usize,
    ability: &crate::ability::Ability,
    _view: &DerivedGameView<'_>,
) -> Option<Vec<ManaSymbol>> {
    use crate::ability::AbilityKind;

    let object = game.object(permanent_id)?;
    if game.controller_of(object) != player
        || object.zone != Zone::Battlefield
        || !ability.functions_in(&object.zone)
        || !game.can_activate_abilities(player)
    {
        return None;
    }

    let AbilityKind::Activated(mana_ability) = &ability.kind else {
        return None;
    };
    if !mana_ability.is_runtime_mana_ability(game, permanent_id, player)
        || !game.can_activate_abilities_of(permanent_id)
    {
        return None;
    }
    if mana_ability.has_tap_cost() && !game.can_activate_tap_abilities_of(permanent_id) {
        return None;
    }
    if ActivationCostAbility::at(game, player, permanent_id, ability_index).is_some_and(|facts|
        crate::activation_cost_alternatives::has_available_alternative(game, permanent_id, facts, &mana_ability.mana_cost)) { return None; }
    // Alternative prices need the full planner to choose and price a branch.
    let costs = mana_ability.mana_cost.as_all()?;
    if !costs
        .iter()
        .all(|cost| cost.requires_tap() || cost.requires_untap())
    {
        return None;
    }

    let mut decision_maker = crate::decision::SelectFirstDecisionMaker;
    let mut execution =
        crate::effects::ExecutionContext::new(permanent_id, player, &mut decision_maker);
    crate::special_actions::can_pay_non_mana_parts_of_cost_in_context(
        game,
        player,
        permanent_id,
        &mana_ability.mana_cost,
        crate::costs::PaymentReason::ActivateManaAbility,
        &mut execution,
    )
    .ok()?;

    if let Some(condition) = &mana_ability.activation_condition
        && !check_mana_ability_condition_for_potential(
            game,
            player,
            permanent_id,
            ability_index,
            condition,
        )
    {
        return None;
    }

    Some(inferred_potential_mana_symbols_for_ability(
        game,
        permanent_id,
        player,
        mana_ability,
    ))
}

pub(crate) fn inferred_potential_mana_symbols_for_ability(
    game: &GameState,
    source: ObjectId,
    controller: PlayerId,
    mana_ability: &crate::ability::ActivatedAbility,
) -> Vec<ManaSymbol> {
    use crate::effects::{
        AddColorlessManaEffect, AddManaEffect, AddManaOfAnyColorEffect, AddManaOfAnyOneColorEffect,
        AddScaledManaEffect,
    };

    if let Some(mana_output) = mana_ability.mana_output.as_ref()
        && !mana_output.is_empty()
    {
        return mana_output.clone();
    }

    let resolve_amount = |value: &crate::effect::Value| -> usize {
        let mut dm = SelectFirstDecisionMaker;
        let ctx = ExecutionContext::new(source, controller, &mut dm);
        resolve_value(game, value, &ctx).unwrap_or(0).max(0) as usize
    };

    let mut inferred = Vec::new();
    for effect in crate::ability::selected_resolution_effects_for_current_state(
        &mana_ability.effects,
        game,
        source,
        controller,
    ) {
        if let Some(add_mana) = effect.downcast_ref::<AddManaEffect>() {
            inferred.extend(add_mana.mana.iter().copied());
            continue;
        }
        if let Some(add_colorless) = effect.downcast_ref::<AddColorlessManaEffect>() {
            inferred.extend(std::iter::repeat_n(
                ManaSymbol::Colorless,
                resolve_amount(&add_colorless.amount),
            ));
            continue;
        }
        if let Some(add_scaled) = effect.downcast_ref::<AddScaledManaEffect>() {
            let repeats = resolve_amount(&add_scaled.amount);
            for _ in 0..repeats {
                inferred.extend(add_scaled.mana.iter().copied());
            }
            continue;
        }
        if let Some(add_any_color) = effect.downcast_ref::<AddManaOfAnyColorEffect>() {
            let amount = resolve_amount(&add_any_color.amount);
            let colors = add_any_color.available_colors.as_deref().unwrap_or(&[
                crate::color::Color::White,
                crate::color::Color::Blue,
                crate::color::Color::Black,
                crate::color::Color::Red,
                crate::color::Color::Green,
            ]);
            for color in colors {
                inferred.extend(std::iter::repeat_n(ManaSymbol::from_color(*color), amount));
            }
            continue;
        }
        if let Some(add_any_one_color) = effect.downcast_ref::<AddManaOfAnyOneColorEffect>() {
            let amount = resolve_amount(&add_any_one_color.amount);
            for color in [
                crate::color::Color::White,
                crate::color::Color::Blue,
                crate::color::Color::Black,
                crate::color::Color::Red,
                crate::color::Color::Green,
            ] {
                inferred.extend(std::iter::repeat_n(ManaSymbol::from_color(color), amount));
            }
            continue;
        }

        if let Some(symbols) = effect.producible_mana_symbols(game, source, controller) {
            inferred.extend(symbols.into_iter().filter(|symbol| {
                matches!(
                    symbol,
                    ManaSymbol::White
                        | ManaSymbol::Blue
                        | ManaSymbol::Black
                        | ManaSymbol::Red
                        | ManaSymbol::Green
                        | ManaSymbol::Colorless
                )
            }));
        }
    }

    if inferred.is_empty() {
        mana_ability.inferred_mana_symbols(game, source, controller)
    } else {
        inferred
    }
}

/// Check mana ability condition for potential mana computation.
pub(crate) fn check_mana_ability_condition_for_potential(
    game: &GameState,
    player: PlayerId,
    source: ObjectId,
    ability_index: usize,
    condition: &crate::ConditionExpr,
) -> bool {
    let eval_ctx = crate::condition_eval::ExternalEvaluationContext {
        controller: player,
        source,
        defending_player: None,
        attacking_player: None,
        filter_source: Some(source),
        iterated_player: None,
        triggering_event: None,
        trigger_identity: None,
        ability_index: Some(ability_index),
        options: crate::condition_eval::ExternalEvaluationOptions::default(),
    };
    crate::condition_eval::evaluate_condition_external(game, condition, &eval_ctx)
}

#[cfg(test)]
mod tests;

#[cfg(test)]
mod typed_cast_timing_tests {
    use super::*;
    #[test]
    fn exact_blocker_step_and_player_turn_scope_are_independent() {
        use crate::game_state::{Phase, Step};
        use crate::static_abilities::ThisSpellCastTiming as Timing;
        let mut game = GameState::new(vec!["Alice".into(), "Teammate".into(), "Bob".into()], 20);
        let [a, mate, b] = std::array::from_fn(|i| game.players[i].id);
        game.set_teams(vec![vec![a, mate], vec![b]]).unwrap();
        game.turn.active_player = mate;
        assert!(!this_spell_cast_timing_allows(
            &game,
            a,
            Timing::DuringOpponentsTurn
        ));
        game.turn.active_player = b;
        assert!(this_spell_cast_timing_allows(
            &game,
            a,
            Timing::DuringOpponentsTurn
        ));
        game.turn.phase = Phase::Combat;
        game.turn.step = Some(Step::DeclareBlockers);
        game.combat = Some(crate::combat_state::CombatState::default());
        assert!(!this_spell_cast_timing_allows(
            &game,
            a,
            Timing::DuringDeclareBlockersStep
        ));
        assert!(!this_spell_cast_timing_allows(
            &game,
            a,
            Timing::DuringCombatAfterBlockersAreDeclared
        ));
        game.combat.as_mut().unwrap().block_declaration_complete = true;
        assert!(this_spell_cast_timing_allows(
            &game,
            a,
            Timing::DuringDeclareBlockersStep
        ));
        assert!(this_spell_cast_timing_allows(
            &game,
            a,
            Timing::DuringCombatAfterBlockersAreDeclared
        ));
        game.turn.step = Some(Step::CombatDamage);
        assert!(!this_spell_cast_timing_allows(
            &game,
            a,
            Timing::DuringDeclareBlockersStep
        ));
        assert!(this_spell_cast_timing_allows(
            &game,
            a,
            Timing::DuringCombatAfterBlockersAreDeclared
        ));
        assert!(!this_spell_cast_timing_allows(
            &game,
            a,
            Timing::DuringCombatOnYourTurn
        ));
        assert!(this_spell_cast_timing_allows(
            &game,
            b,
            Timing::DuringCombatOnYourTurn
        ));
    }
}

#[cfg(test)]
mod retained_player_attack_window_tests {
    use super::*;
    use crate::combat_state::{AttackTarget, AttackerInfo, CombatState};
    use crate::game_state::{Phase, Step};
    use crate::static_abilities::ThisSpellCastCondition;

    #[test]
    fn past_declaration_and_present_attacking_conditions_have_distinct_owners() {
        let a = PlayerId::from_index(0);
        let b = PlayerId::from_index(1);
        let mut game = GameState::new(vec!["Alice".into(), "Bob".into()], 20);
        game.turn.phase = Phase::Combat;
        game.turn.step = Some(Step::DeclareAttackers);
        game.mark_combat_phase_started();
        let phase = game.turn_store.combat_phases_started_this_turn;
        game.turn_store.turn_history.players_attacked_in_combat.entry((phase, b))
            .or_default().insert(a);
        // No current combat frame: retain the previous fail-closed behavior.
        assert!(!player_was_attacked_this_step(&game, a));
        game.combat = Some(CombatState::default());
        assert!(!player_was_attacked_this_step(&game, a), "missing step evidence is not inferred from phase history");
        game.combat.as_mut().unwrap().last_attack_declaration_step_players = Some([a].into_iter().collect());
        assert!(player_was_attacked_this_step(&game, a));
        assert!(!this_spell_cast_condition_allows(&game, a,
            &ThisSpellCastCondition::CreatureIsAttackingYou));
        let attacker = game.create_object_from_card(&crate::card::CardBuilder::new(
            crate::CardId::new(), "Live attacker witness")
            .card_types(vec![crate::CardType::Creature]).build(), b, Zone::Battlefield);
        game.combat.as_mut().unwrap().attackers.push(AttackerInfo {
            creature: attacker, target: AttackTarget::Player(a),
        });
        assert!(this_spell_cast_condition_allows(&game, a,
            &ThisSpellCastCondition::CreatureIsAttackingYou));
        game.mark_combat_phase_started();
        assert!(!player_was_attacked_this_step(&game, a));
        assert!(this_spell_cast_condition_allows(&game, a,
            &ThisSpellCastCondition::CreatureIsAttackingYou));
        game.combat.as_mut().unwrap().attackers.clear();
        assert!(!this_spell_cast_condition_allows(&game, a,
            &ThisSpellCastCondition::CreatureIsAttackingYou));
    }
}
