use crate::tag::TagKeyWalk;

use crate::color::{Color, ColorSet};
mod x_payment;
mod payment_budget;
pub use payment_budget::ManaPaymentBudget;
mod waterbend;
pub use waterbend::{WaterbendCapacity, WaterbendObligation, WaterbendPaymentScope, TapPaymentMethod};
pub use x_payment::{XPaymentScope, XManaAllocation, ActualManaAllocation};

/// Atomic mana payment options.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, TagKeyWalk)]
pub enum ManaSymbol {
    /// White mana {W}
    White,
    /// Blue mana {U}
    Blue,
    /// Black mana {B}
    Black,
    /// Red mana {R}
    Red,
    /// Green mana {G}
    Green,
    /// Colorless mana {C}
    Colorless,
    /// Generic mana {1}, {2}, etc.
    Generic(u8),
    /// Snow mana {S}
    Snow,
    /// Life payment for Phyrexian costs
    Life(u8),
    /// Variable mana {X}
    X,
}

impl ManaSymbol {
    /// Returns the mana value contribution of this symbol.
    pub fn mana_value(&self) -> u32 {
        match self {
            ManaSymbol::White => 1,
            ManaSymbol::Blue => 1,
            ManaSymbol::Black => 1,
            ManaSymbol::Red => 1,
            ManaSymbol::Green => 1,
            ManaSymbol::Colorless => 1,
            ManaSymbol::Generic(n) => *n as u32,
            ManaSymbol::Snow => 1,
            ManaSymbol::Life(_) => 0, // Life payment doesn't contribute to mana value
            ManaSymbol::X => 0,       // X is 0 except on the stack
        }
    }

    /// Creates a colored mana symbol from a Color.
    pub fn from_color(color: Color) -> Self {
        match color {
            Color::White => ManaSymbol::White,
            Color::Blue => ManaSymbol::Blue,
            Color::Black => ManaSymbol::Black,
            Color::Red => ManaSymbol::Red,
            Color::Green => ManaSymbol::Green,
        }
    }
}

/// Characteristics of the object that produced a mana unit, frozen at production.
/// This is independent of what the unit may be spent as.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, Eq, Hash, TagKeyWalk)]
pub enum ManaProducerFilter {
    CardType(crate::types::CardType),
    Supertype(crate::types::Supertype),
    Subtype(crate::types::Subtype),
    All(Vec<ManaProducerFilter>),
}

/// A consumer-side condition on actual mana spent on this cost.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, Eq, Hash, TagKeyWalk)]
pub enum ManaSpendingRestriction {
    ProducedBy(ManaProducerFilter),
    /// Only the actual mana allocated to the generic X portion is constrained.
    /// Appended to preserve existing typed-artifact enum discriminants.
    OnX { colors: ColorSet, maximum_per_color: Option<u32> },
    /// "You can't spend mana to cast this spell." (Hogaak, Arisen
    /// Necropolis): no actual mana unit may be spent on this cost, so every
    /// pip is paid by non-mana means such as convoke or delve (CR 601.2h).
    NoMana,
    /// "Spend only mana of the chosen color to activate this ability."
    /// (Throne of Eldraine): every unit spent must be the color chosen for
    /// the object whose cost is being paid. With no chosen color, no mana
    /// unit qualifies.
    SourceChosenColor,
    /// "Spend only black and/or red mana to activate this ability": every
    /// unit spent must be one of these colors (all five for "colored").
    Colors(ColorSet),
    /// "Spend only colorless mana ...": every unit spent must be colorless.
    Colorless,
    /// "Spend only snow mana ...": every unit spent must come from a snow
    /// source (CR 107.4h).
    Snow,
    /// Minimum number of actual colored mana types spent on the whole cost.
    /// Colorless and nonmana substitutes do not contribute.
    AtLeastColors(u8),
    /// Each counter placed on a controlled creature pays one generic mana,
    /// bounded by that creature's remaining toughness (toughness minus damage).
    GenericManaByMinusOneCounters,
    /// Actual colors not previously spent to activate this exact occurrence.
    /// The activation cost owner resolves this against its retained identity.
    UnspentActivationColors,
}

impl ManaSymbol {
    /// The color of one unit of mana of this type, if it is colored.
    pub fn unit_color(self) -> Option<Color> {
        match self {
            ManaSymbol::White => Some(Color::White),
            ManaSymbol::Blue => Some(Color::Blue),
            ManaSymbol::Black => Some(Color::Black),
            ManaSymbol::Red => Some(Color::Red),
            ManaSymbol::Green => Some(Color::Green),
            _ => None,
        }
    }
}

impl ManaProducerFilter {
    pub fn description(&self) -> String {
        match self {
            Self::CardType(kind) => format!("{}s", kind.to_string().to_ascii_lowercase()),
            Self::Supertype(kind) => format!("{} permanents", kind.to_string().to_ascii_lowercase()),
            Self::Subtype(kind) => format!("{kind}s"),
            Self::All(parts) => {
                if let [Self::CardType(kind), Self::Supertype(supertype)] = parts.as_slice() {
                    return format!("{} {}s", supertype.to_string().to_ascii_lowercase(), kind.to_string().to_ascii_lowercase());
                }
                parts.iter().map(Self::description).collect::<Vec<_>>().join(" and ")
            }
        }
    }
}
impl ManaSpendingRestriction {
    pub fn cast_description(&self, alternative: bool) -> String {
        let scope = if alternative { "it this way" } else { "this spell" };
        match self {
            Self::ProducedBy(filter) => format!("Spend only mana produced by {} to cast {scope}", filter.description()),
            Self::OnX { colors, maximum_per_color } => {
                let colors = if colors.count() == 5 { "colored".to_string() } else {
                    Color::ALL.into_iter().filter(|color| colors.contains(*color)).map(Color::name).collect::<Vec<_>>().join(" and/or ")
                };
                let mut text = format!("Spend only {colors} mana on X");
                if let Some(limit) = maximum_per_color {
                    text.push_str(&format!(". No more than {limit} mana of each color may be spent this way"));
                }
                text
            },
            Self::NoMana => format!("You can't spend mana to cast {scope}"),
            Self::AtLeastColors(count) => format!("Spend mana of at least {count} different colors to cast {scope}"),
            Self::GenericManaByMinusOneCounters => "For each generic mana in this spell's total cost, you may put a -1/-1 counter on a creature you control up to its remaining toughness rather than pay that mana".into(),
            _ => format!("Spend only {} to cast {scope}", self.unit_requirement_description()),
        }
    }

    /// The rider an activated ability's restricted cost carries:
    /// "Spend only mana of the chosen color to activate this ability".
    pub fn activation_description(&self) -> String {
        match self {
            Self::OnX { .. } => self.cast_description(false),
            Self::NoMana => "You can't spend mana to activate this ability".to_string(),
            Self::AtLeastColors(count) => format!("Spend mana of at least {count} different colors to activate this ability"),
            Self::GenericManaByMinusOneCounters => "For each generic mana in this ability's total cost, you may put a -1/-1 counter on a creature you control up to its remaining toughness rather than pay that mana".into(),
            _ => format!(
                "Spend only {} to activate this ability",
                self.unit_requirement_description()
            ),
        }
    }

    /// The mana a per-unit restriction admits ("mana of the chosen color",
    /// "black and/or red mana", "mana produced by creatures").
    fn unit_requirement_description(&self) -> String {
        match self {
            Self::ProducedBy(filter) => format!("mana produced by {}", filter.description()),
            Self::SourceChosenColor => "mana of the chosen color".to_string(),
            Self::UnspentActivationColors => "mana of a color that has not been spent this way".to_string(),
            Self::Colors(colors) if colors.count() == 5 => "colored mana".to_string(),
            Self::Colors(colors) => format!(
                "{} mana",
                Color::ALL
                    .into_iter()
                    .filter(|color| colors.contains(*color))
                    .map(Color::name)
                    .collect::<Vec<_>>()
                    .join(" and/or ")
            ),
            Self::Colorless => "colorless mana".to_string(),
            Self::Snow => "snow mana".to_string(),
            Self::OnX { .. } | Self::NoMana | Self::AtLeastColors(_) | Self::GenericManaByMinusOneCounters => "mana".to_string(),
        }
    }

    /// Whether one unit of `symbol` may be spent under this restriction,
    /// judged on the unit itself. `chosen_color` is the paying object's
    /// chosen color; `from_snow_source` is the unit's production provenance.
    /// Producer-type and X-allocation restrictions are judged elsewhere.
    pub fn admits_unit(
        &self,
        symbol: ManaSymbol,
        chosen_color: Option<Color>,
        from_snow_source: bool,
    ) -> bool {
        match self {
            Self::SourceChosenColor => {
                chosen_color.is_some_and(|color| symbol.unit_color() == Some(color))
            }
            Self::Colors(colors) => symbol.unit_color().is_some_and(|color| colors.contains(color)),
            Self::Colorless => symbol == ManaSymbol::Colorless,
            Self::Snow => from_snow_source,
            Self::NoMana | Self::UnspentActivationColors => false,
            Self::ProducedBy(_) | Self::OnX { .. } | Self::AtLeastColors(_) | Self::GenericManaByMinusOneCounters => true,
        }
    }
}

/// Producer of one static spending rule frozen while the cost is determined.
/// The occurrence indexes the effective ability list of this proposed source;
/// it is never reconstructed from keywords after payment has begun.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, Eq, TagKeyWalk)]
pub struct ManaSpendingRuleProducer {
    pub rule: ManaSpendingRestriction,
    pub source: crate::ObjectId,
    pub controller: crate::PlayerId,
    pub occurrence: u32,
    pub ability_designations: Vec<String>,
}

/// Represents a mana cost as a sequence of pips, where each pip is a list of
/// alternative payment options (disjunction).
///
/// The outer vector represents pips that must ALL be paid (conjunction).
/// Each inner vector represents alternative ways to pay that pip (disjunction).
///
/// Examples:
/// - `{2}{W}{W}` = `[[Generic(2)], [White], [White]]`
/// - `{W/U}` (hybrid) = `[[White, Blue]]`
/// - `{2/W}` (twobrid) = `[[Generic(2), White]]`
/// - `{W/P}` (phyrexian) = `[[White, Life(2)]]`

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, Eq, Default, TagKeyWalk)]
pub struct ManaCost {
    pips: Vec<Vec<ManaSymbol>>,
    /// Kept on the priced cost, so taxes, alternative payments, planner roots,
    /// and resumed transactions cannot silently discard a spending condition.
    #[cfg_attr(feature = "serde", serde(default, skip_serializing_if = "Vec::is_empty"))]
    spending_restrictions: Vec<ManaSpendingRestriction>,
    #[cfg_attr(feature = "serde", serde(default, skip_serializing_if = "Option::is_none"))]
    x_payment_scope: Option<XPaymentScope>,
    #[cfg_attr(feature = "serde", serde(default, skip_serializing_if = "Option::is_none"))]
    required_actual_payment: Option<ActualManaAllocation>,
    #[cfg_attr(feature = "serde", serde(default, skip_serializing_if = "Option::is_none"))]
    waterbend_payment_scope: Option<WaterbendPaymentScope>,
    #[cfg_attr(feature = "serde", serde(default, skip_serializing_if = "Vec::is_empty"))]
    spending_rule_producers: Vec<ManaSpendingRuleProducer>,
}

impl ManaCost {
    /// Creates an empty mana cost.
    pub fn new() -> Self {
        Self { pips: Vec::new(), waterbend_payment_scope: None, spending_restrictions: Vec::new(), spending_rule_producers: Vec::new(), x_payment_scope: None, required_actual_payment: None }
    }

    /// Creates a mana cost from a list of pips, where each pip is a list of
    /// alternative payment options.
    pub fn from_pips(pips: Vec<Vec<ManaSymbol>>) -> Self {
        Self { pips, waterbend_payment_scope: None, spending_restrictions: Vec::new(), spending_rule_producers: Vec::new(), x_payment_scope: None, required_actual_payment: None }
    }

    /// Creates a mana cost from a simple list of symbols (each becomes one pip).
    pub fn from_symbols(symbols: Vec<ManaSymbol>) -> Self {
        Self {
            pips: symbols.into_iter().map(|s| vec![s]).collect(),
            waterbend_payment_scope: None,
            spending_restrictions: Vec::new(), spending_rule_producers: Vec::new(),
            x_payment_scope: None,
            required_actual_payment: None,
        }
    }

    /// Bind a retained activation's history before payment is locked. Other
    /// spending restrictions and all payment-allocation metadata survive.
    pub fn resolve_activation_history_colors(mut self, allowed: ColorSet) -> Self {
        for producer in &mut self.spending_rule_producers {
            if matches!(producer.rule,ManaSpendingRestriction::UnspentActivationColors){producer.rule=ManaSpendingRestriction::Colors(allowed);}
        }
        for rule in &mut self.spending_restrictions {
            if matches!(rule, ManaSpendingRestriction::UnspentActivationColors) {
                *rule = ManaSpendingRestriction::Colors(allowed);
            }
        }
        self
    }

    pub fn spending_restrictions(&self) -> &[ManaSpendingRestriction] {
        &self.spending_restrictions
    }

    pub fn spending_rule_producers(&self) -> &[ManaSpendingRuleProducer] { &self.spending_rule_producers }

    pub fn with_spending_rule_producer(mut self, producer: ManaSpendingRuleProducer) -> Self {
        self=self.with_spending_restriction(producer.rule.clone());
        if !self.spending_rule_producers.contains(&producer) {self.spending_rule_producers.push(producer);}
        self
    }

    pub fn with_spending_restriction(mut self, restriction: ManaSpendingRestriction) -> Self {
        if matches!(restriction, ManaSpendingRestriction::OnX { .. }) && self.x_payment_scope.is_none() {
            self.x_payment_scope = Some(XPaymentScope {
                symbols: self.pips.iter().filter(|pip| pip.contains(&ManaSymbol::X)).count() as u32,
                announced_x: None,
                ordinary_generic: self.generic_mana_total(),
                prepaid_generic: Vec::new(), required: None, incompatible: false,
            });
        }
        if !self.spending_restrictions.contains(&restriction) {
            self.spending_restrictions.push(restriction);
        }
        self
    }

    /// Rewrite the price while retaining transaction-wide spending rules.
    pub fn with_pips(&self, pips: Vec<Vec<ManaSymbol>>) -> Self {
        let mut result = Self { pips, waterbend_payment_scope: self.waterbend_payment_scope.clone(), spending_restrictions: self.spending_restrictions.clone(), spending_rule_producers: self.spending_rule_producers.clone(),
            x_payment_scope: self.x_payment_scope.clone(), required_actual_payment: self.required_actual_payment };
        if let Some(scope) = result.x_payment_scope.as_mut() {
            let old_x = self.pips.iter().filter(|pip| pip.contains(&ManaSymbol::X)).count() as u32;
            let new_x = result.pips.iter().filter(|pip| pip.contains(&ManaSymbol::X)).count() as u32;
            let added_x = new_x.saturating_sub(old_x);
            scope.symbols = scope.symbols.saturating_add(added_x);
            let value = scope.announced_x.unwrap_or(0);
            let before = self.generic_mana_total().saturating_add(old_x.saturating_mul(value));
            let after = result.pips.iter().filter_map(|pip| match pip.as_slice() {
                [ManaSymbol::Generic(n)] => Some(u32::from(*n)), _ => None,
            }).sum::<u32>().saturating_add(new_x.saturating_mul(value));
            scope.ordinary_generic = scope.ordinary_generic.saturating_add(
                after.saturating_sub(before).saturating_sub(added_x.saturating_mul(value)));
        }
        result.reprice_waterbend_from(self);
        result
    }

    /// Drop every per-unit spending rule (color, snow, producer, no-mana),
    /// keeping X-allocation rules. Renderers use it to print the rule once
    /// as the ability's rider instead of inside the price.
    pub fn without_unit_spending_restrictions(mut self) -> Self {
        self.spending_restrictions
            .retain(|rule| matches!(rule, ManaSpendingRestriction::OnX { .. } | ManaSpendingRestriction::AtLeastColors(_) | ManaSpendingRestriction::GenericManaByMinusOneCounters));
        self.spending_rule_producers.retain(|producer|self.spending_restrictions.contains(&producer.rule));
        self
    }

    /// A renderer may print every consumer rider separately from the nominal
    /// price. Only its display clone may erase all riders; payment keeps them.
    pub fn without_spending_restrictions_for_display(mut self) -> Self {
        self.spending_restrictions.clear();
        self.spending_rule_producers.clear();
        self.x_payment_scope = None;
        self.required_actual_payment = None;
        self
    }

    pub fn inherit_spending_restrictions(mut self, other: &Self) -> Self {
        for restriction in other.spending_restrictions() {
            self = self.with_spending_restriction(restriction.clone());
        }
        for producer in other.spending_rule_producers() {
            self=self.with_spending_rule_producer(producer.clone());
        }
        self
    }

    /// Returns the mana value (formerly converted mana cost) of this cost.
    ///
    /// For each pip, uses the maximum mana value among its alternatives.
    pub fn mana_value(&self) -> u32 {
        self.pips
            .iter()
            .map(|pip| pip.iter().map(|s| s.mana_value()).max().unwrap_or(0))
            .sum()
    }

    /// Returns this cost's mana value while it is a spell on the stack.
    ///
    /// Outside the stack, X contributes zero. On the stack, each X symbol
    /// contributes the value chosen for X (CR 202.3e).
    pub fn mana_value_with_x(&self, x_value: u32) -> u32 {
        self.pips
            .iter()
            .map(|pip| {
                pip.iter()
                    .map(|symbol| match symbol {
                        ManaSymbol::X => x_value,
                        other => other.mana_value(),
                    })
                    .max()
                    .unwrap_or(0)
            })
            .sum()
    }

    /// Returns the pips in this mana cost.
    pub fn pips(&self) -> &[Vec<ManaSymbol>] {
        &self.pips
    }

    /// Format the mana cost in oracle-style syntax (e.g., "{2}{W}{W}").
    pub fn to_oracle(&self) -> String {
        fn symbol_text(symbol: ManaSymbol) -> String {
            match symbol {
                ManaSymbol::White => "W".to_string(),
                ManaSymbol::Blue => "U".to_string(),
                ManaSymbol::Black => "B".to_string(),
                ManaSymbol::Red => "R".to_string(),
                ManaSymbol::Green => "G".to_string(),
                ManaSymbol::Colorless => "C".to_string(),
                ManaSymbol::Generic(n) => n.to_string(),
                ManaSymbol::Snow => "S".to_string(),
                ManaSymbol::Life(_) => "P".to_string(),
                ManaSymbol::X => "X".to_string(),
            }
        }

        let mut out = String::new();
        for pip in &self.pips {
            let mut parts = Vec::new();
            for symbol in pip {
                parts.push(symbol_text(*symbol));
            }
            out.push('{');
            out.push_str(&parts.join("/"));
            out.push('}');
        }
        out
    }

    /// Adds a pip with a single payment option.
    pub fn push(&mut self, symbol: ManaSymbol) {
        self.push_alternatives(vec![symbol]);
    }

    /// Adds a pip with multiple alternative payment options.
    pub fn push_alternatives(&mut self, alternatives: Vec<ManaSymbol>) {
        let base = if self.has_waterbend_obligation() {
            self.with_pips(self.pips_with_bound_x_expanded())
        } else { self.clone() };
        let mut pips = base.pips.clone();
        pips.push(alternatives);
        *self = base.with_pips(pips);
    }

    /// No mana pips or transaction spending obligations remain. A zero-pip
    /// cost with a spending requirement still needs authoritative validation.
    pub fn is_empty(&self) -> bool {
        self.pips.is_empty() && !self.has_waterbend_obligation()
            && self.spending_restrictions.is_empty()
    }

    /// Returns the number of pips in this mana cost.
    pub fn pip_count(&self) -> usize {
        self.pips.len()
    }

    /// Returns true if this mana cost contains X.
    pub fn has_x(&self) -> bool {
        self.pips
            .iter()
            .any(|pip| pip.iter().any(|s| matches!(s, ManaSymbol::X)))
    }

    /// Returns the total generic mana cost (sum of all Generic(n) pips).
    pub fn generic_mana_total(&self) -> u32 {
        self.pips
            .iter()
            .filter_map(|pip| {
                // Only count pips where the only option is Generic
                if pip.len() == 1
                    && let ManaSymbol::Generic(n) = pip[0]
                {
                    return Some(n as u32);
                }
                None
            })
            .sum()
    }

    /// Returns a new ManaCost with generic mana reduced by the given amount.
    /// Reduction cannot make generic costs negative.
    ///
    /// This is used for abilities like Affinity that reduce generic mana costs.
    pub fn reduce_generic(&self, reduction: u32) -> ManaCost {
        let mut remaining_reduction = reduction;
        let mut new_pips = Vec::new();

        for pip in &self.pips {
            // Check if this is a pure Generic pip (single option that is Generic)
            if pip.len() == 1
                && let ManaSymbol::Generic(n) = pip[0]
            {
                let current = n as u32;
                if remaining_reduction >= current {
                    // This pip is fully reduced away
                    remaining_reduction -= current;
                    continue; // Skip this pip entirely
                } else {
                    // Partially reduce this pip
                    let new_generic = current - remaining_reduction;
                    remaining_reduction = 0;
                    if new_generic > 0 {
                        new_pips.push(vec![ManaSymbol::Generic(new_generic as u8)]);
                    }
                    continue;
                }
            }
            // Not a pure Generic pip, keep it as-is
            new_pips.push(pip.clone());
        }

        self.with_pips(new_pips)
    }

    /// Enumerate the payer's cost/reduction choices under CR 118.7.
    /// Hybrid halves remain choices; Phyrexian reduction symbols never reduce life.
    /// The base cost must already have its X value expanded; X in the reduction is zero.
    pub fn reduced_by_mana_cost_options(&self, reduction: &ManaCost) -> Vec<ManaCost> {
        fn rank(symbol: &ManaSymbol) -> (u8, u8) {
            match symbol {
                ManaSymbol::Generic(n) => (0, *n),
                ManaSymbol::White => (1, 0),
                ManaSymbol::Blue => (2, 0),
                ManaSymbol::Black => (3, 0),
                ManaSymbol::Red => (4, 0),
                ManaSymbol::Green => (5, 0),
                ManaSymbol::Colorless => (6, 0),
                ManaSymbol::Snow => (7, 0),
                ManaSymbol::Life(n) => (8, *n),
                ManaSymbol::X => (9, 0),
            }
        }
        fn expand(cost: &ManaCost, reduction: bool) -> Vec<Vec<ManaSymbol>> {
            let mut states = vec![Vec::new()];
            for pip in cost.pips() {
                let options = pip
                    .iter()
                    .copied()
                    .filter(|symbol| !reduction || !matches!(symbol, ManaSymbol::Life(_)))
                    .collect::<Vec<_>>();
                let mut next = Vec::new();
                for state in &states {
                    for option in &options {
                        let mut branch = state.clone();
                        branch.push(*option);
                        branch.sort_by_key(rank);
                        if !next.contains(&branch) {
                            next.push(branch);
                        }
                    }
                }
                states = next;
            }
            states
        }
        if reduction.pips().is_empty() {
            return vec![self.clone()];
        }
        let mut results = Vec::new();
        for base in expand(self, false) {
            for selected in expand(reduction, true) {
                let mut remaining = base.clone();
                let mut generic_reduction = 0u32;
                for symbol in selected {
                    match symbol {
                        ManaSymbol::Generic(n) => generic_reduction += u32::from(n),
                        ManaSymbol::Snow => generic_reduction += 1,
                        ManaSymbol::X => {}
                        ManaSymbol::Life(_) => unreachable!("reduction cannot spend life"),
                        colored => {
                            if let Some(index) =
                                remaining.iter().position(|symbol| *symbol == colored)
                            {
                                remaining.remove(index);
                            } else {
                                generic_reduction += 1;
                            }
                        }
                    }
                }
                let cost = self.with_pips(remaining.into_iter().map(|symbol| vec![symbol]).collect())
                    .reduce_generic(generic_reduction);
                if !results.contains(&cost) {
                    results.push(cost);
                }
            }
        }
        results
    }

    /// Returns a new ManaCost with additional generic mana appended.
    pub fn add_generic(&self, increase: u32) -> ManaCost {
        if increase == 0 {
            return self.clone();
        }

        let mut new_pips = self.pips.clone();
        let mut remaining = increase;
        while remaining > 0 {
            let chunk = remaining.min(u8::MAX as u32) as u8;
            new_pips.push(vec![ManaSymbol::Generic(chunk)]);
            remaining -= chunk as u32;
        }

        self.with_pips(new_pips)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn source_spending_rules_survive_price_transformations() {
        let rule = ManaSpendingRestriction::ProducedBy(ManaProducerFilter::CardType(crate::types::CardType::Creature));
        let original = ManaCost::from_symbols(vec![ManaSymbol::Generic(2), ManaSymbol::Green])
            .with_spending_restriction(rule.clone());
        for cost in [original.add_generic(3), original.reduce_generic(9), original.with_pips(vec![vec![ManaSymbol::Red]])] {
            assert_eq!(cost.spending_restrictions(), &[rule.clone()]);
        }
        for cost in original.reduced_by_mana_cost_options(&ManaCost::from_symbols(vec![ManaSymbol::Green])) {
            assert_eq!(cost.spending_restrictions(), &[rule.clone()]);
        }
    }

    #[test]
    fn test_mana_symbol_value() {
        assert_eq!(ManaSymbol::White.mana_value(), 1);
        assert_eq!(ManaSymbol::Generic(3).mana_value(), 3);
        assert_eq!(ManaSymbol::X.mana_value(), 0);
        assert_eq!(ManaSymbol::Life(2).mana_value(), 0);
        assert_eq!(ManaSymbol::Colorless.mana_value(), 1);
        assert_eq!(ManaSymbol::Snow.mana_value(), 1);
    }

    #[test]
    fn test_mana_cost_empty() {
        let cost = ManaCost::new();
        assert!(cost.is_empty());
        assert_eq!(cost.mana_value(), 0);
    }

    #[test]
    fn test_mana_cost_simple() {
        // {2}{W}{W} like Serra Angel
        let cost = ManaCost::from_pips(vec![
            vec![ManaSymbol::Generic(2)],
            vec![ManaSymbol::White],
            vec![ManaSymbol::White],
        ]);
        assert_eq!(cost.mana_value(), 4);
        assert_eq!(cost.pip_count(), 3);
    }

    #[test]
    fn test_mana_cost_with_x() {
        // {X}{R}{R} like Fireball
        let cost = ManaCost::from_pips(vec![
            vec![ManaSymbol::X],
            vec![ManaSymbol::Red],
            vec![ManaSymbol::Red],
        ]);
        assert_eq!(cost.mana_value(), 2); // X counts as 0
    }

    #[test]
    fn test_mana_cost_hybrid() {
        // {2}{W/U}{W/U} like some Ravnica cards
        let cost = ManaCost::from_pips(vec![
            vec![ManaSymbol::Generic(2)],
            vec![ManaSymbol::White, ManaSymbol::Blue],
            vec![ManaSymbol::White, ManaSymbol::Blue],
        ]);
        assert_eq!(cost.mana_value(), 4); // max(1,1) = 1 for each hybrid pip
    }

    #[test]
    fn test_mana_cost_twobrid() {
        // {2/W}{2/W}{2/W} like Spectral Procession
        let cost = ManaCost::from_pips(vec![
            vec![ManaSymbol::Generic(2), ManaSymbol::White],
            vec![ManaSymbol::Generic(2), ManaSymbol::White],
            vec![ManaSymbol::Generic(2), ManaSymbol::White],
        ]);
        assert_eq!(cost.mana_value(), 6); // max(2,1) = 2 for each twobrid pip
    }

    #[test]
    fn test_mana_cost_phyrexian() {
        // {1}{W/P}{W/P} like Porcelain Legionnaire
        let cost = ManaCost::from_pips(vec![
            vec![ManaSymbol::Generic(1)],
            vec![ManaSymbol::White, ManaSymbol::Life(2)],
            vec![ManaSymbol::White, ManaSymbol::Life(2)],
        ]);
        assert_eq!(cost.mana_value(), 3); // max(1,0) = 1 for each phyrexian pip
    }

    #[test]
    fn test_mana_cost_phyrexian_hybrid() {
        // {G/U/P} like some cards from All Will Be One
        let cost = ManaCost::from_pips(vec![vec![
            ManaSymbol::Green,
            ManaSymbol::Blue,
            ManaSymbol::Life(2),
        ]]);
        assert_eq!(cost.mana_value(), 1); // max(1,1,0) = 1
    }

    #[test]
    fn test_mana_cost_push() {
        let mut cost = ManaCost::new();
        cost.push(ManaSymbol::Generic(2));
        cost.push(ManaSymbol::Green);
        cost.push(ManaSymbol::Green);
        assert_eq!(cost.mana_value(), 4);
        assert_eq!(cost.pip_count(), 3);
    }

    #[test]
    fn mana_value_with_x_counts_each_x_symbol_on_stack() {
        let cost = ManaCost::from_pips(vec![
            vec![ManaSymbol::X],
            vec![ManaSymbol::X],
            vec![ManaSymbol::Red],
        ]);

        assert_eq!(cost.mana_value(), 1);
        assert_eq!(cost.mana_value_with_x(3), 7);
    }

    #[test]
    fn test_mana_cost_push_alternatives() {
        let mut cost = ManaCost::new();
        cost.push(ManaSymbol::Generic(1));
        cost.push_alternatives(vec![ManaSymbol::White, ManaSymbol::Blue]);
        assert_eq!(cost.mana_value(), 2);
        assert_eq!(cost.pip_count(), 2);
    }

    #[test]
    fn test_mana_cost_colorless_eldrazi() {
        // {3}{C} like Thought-Knot Seer
        let cost = ManaCost::from_pips(vec![
            vec![ManaSymbol::Generic(3)],
            vec![ManaSymbol::Colorless],
        ]);
        assert_eq!(cost.mana_value(), 4);
    }

    #[test]
    fn test_generic_mana_total() {
        // {4} - pure generic
        let cost = ManaCost::from_pips(vec![vec![ManaSymbol::Generic(4)]]);
        assert_eq!(cost.generic_mana_total(), 4);

        // {2}{W}{W} - 2 generic plus 2 colored
        let cost = ManaCost::from_pips(vec![
            vec![ManaSymbol::Generic(2)],
            vec![ManaSymbol::White],
            vec![ManaSymbol::White],
        ]);
        assert_eq!(cost.generic_mana_total(), 2);

        // {R}{R} - no generic
        let cost = ManaCost::from_pips(vec![vec![ManaSymbol::Red], vec![ManaSymbol::Red]]);
        assert_eq!(cost.generic_mana_total(), 0);

        // {2/W} hybrid - not pure generic
        let cost = ManaCost::from_pips(vec![vec![ManaSymbol::Generic(2), ManaSymbol::White]]);
        assert_eq!(cost.generic_mana_total(), 0);
    }

    #[test]
    fn test_reduce_generic() {
        // {4} with 3 reduction = {1}
        let cost = ManaCost::from_pips(vec![vec![ManaSymbol::Generic(4)]]);
        let reduced = cost.reduce_generic(3);
        assert_eq!(reduced.mana_value(), 1);
        assert_eq!(reduced.generic_mana_total(), 1);

        // {4} with 4 reduction = free (empty)
        let cost = ManaCost::from_pips(vec![vec![ManaSymbol::Generic(4)]]);
        let reduced = cost.reduce_generic(4);
        assert!(reduced.is_empty());
        assert_eq!(reduced.mana_value(), 0);

        // {4} with 5 reduction = free (capped at 0)
        let cost = ManaCost::from_pips(vec![vec![ManaSymbol::Generic(4)]]);
        let reduced = cost.reduce_generic(5);
        assert!(reduced.is_empty());
        assert_eq!(reduced.mana_value(), 0);

        // {2}{W}{W} with 1 reduction = {1}{W}{W}
        let cost = ManaCost::from_pips(vec![
            vec![ManaSymbol::Generic(2)],
            vec![ManaSymbol::White],
            vec![ManaSymbol::White],
        ]);
        let reduced = cost.reduce_generic(1);
        assert_eq!(reduced.mana_value(), 3);
        assert_eq!(reduced.pip_count(), 3);

        // {2}{W}{W} with 2 reduction = {W}{W}
        let cost = ManaCost::from_pips(vec![
            vec![ManaSymbol::Generic(2)],
            vec![ManaSymbol::White],
            vec![ManaSymbol::White],
        ]);
        let reduced = cost.reduce_generic(2);
        assert_eq!(reduced.mana_value(), 2);
        assert_eq!(reduced.pip_count(), 2);

        // {R}{R} with any reduction = {R}{R} (no generic to reduce)
        let cost = ManaCost::from_pips(vec![vec![ManaSymbol::Red], vec![ManaSymbol::Red]]);
        let reduced = cost.reduce_generic(5);
        assert_eq!(reduced.mana_value(), 2);
        assert_eq!(reduced.pip_count(), 2);

        // {2/W} hybrid with reduction - should not be affected
        let cost = ManaCost::from_pips(vec![vec![ManaSymbol::Generic(2), ManaSymbol::White]]);
        let reduced = cost.reduce_generic(2);
        // Hybrid pip is not pure Generic, so it's kept
        assert_eq!(reduced.pip_count(), 1);
        assert_eq!(reduced.mana_value(), 2);
    }

    #[test]
    fn test_add_generic() {
        let cost = ManaCost::from_pips(vec![vec![ManaSymbol::White], vec![ManaSymbol::Blue]]);
        let increased = cost.add_generic(3);

        assert_eq!(increased.pip_count(), 3);
        assert_eq!(increased.mana_value(), 5);
        assert_eq!(increased.generic_mana_total(), 3);
        assert_eq!(increased.to_oracle(), "{W}{U}{3}");
    }
    #[test]
    fn power_up_mana_reduction_preserves_payer_choices() {
        use ManaSymbol::*;
        let cost = ManaCost::from_pips(vec![vec![Generic(5)], vec![Red, Green], vec![Red, Green]]);
        let reduction = ManaCost::from_pips(vec![vec![Generic(3)], vec![Red, Green]]);
        let mut actual = cost
            .reduced_by_mana_cost_options(&reduction)
            .iter()
            .map(ManaCost::to_oracle)
            .collect::<Vec<_>>();
        actual.sort();
        assert_eq!(actual, vec!["{1}{G}{G}", "{1}{R}{R}", "{2}{G}", "{2}{R}"]);
        // Excess colored reduction becomes generic, never a different color.
        let cost = ManaCost::from_symbols(vec![Generic(2), Blue]);
        assert_eq!(
            cost.reduced_by_mana_cost_options(&ManaCost::from_symbols(vec![Red, Red, Red])),
            vec![ManaCost::from_symbols(vec![Blue])]
        );
        // A Phyrexian symbol in a reduction uses its color, never a life payment.
        assert_eq!(
            cost.reduced_by_mana_cost_options(&ManaCost::from_pips(vec![vec![Blue, Life(2)]])),
            vec![ManaCost::from_symbols(vec![Generic(2)])]
        );
        // Snow reduces generic; colorless reduces matching colorless first.
        assert_eq!(
            ManaCost::from_symbols(vec![Generic(2), Colorless])
                .reduced_by_mana_cost_options(&ManaCost::from_symbols(vec![Colorless, Snow, X])),
            vec![ManaCost::from_symbols(vec![Generic(1)])]
        );
        let mut twobrid = cost
            .reduced_by_mana_cost_options(&ManaCost::from_pips(vec![vec![Generic(2), Blue]]))
            .iter()
            .map(ManaCost::to_oracle)
            .collect::<Vec<_>>();
        twobrid.sort();
        assert_eq!(twobrid, vec!["{2}", "{U}"]);
    }
}

/// Which symbols in a pending production event a replacement rewrites. This
/// is independent of the source filter: colored mana is not colorless mana,
/// and a white-only rewrite must preserve the other symbols in the same event.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, TagKeyWalk)]
pub enum ManaRewriteInput {
    Any,
    Colored,
    Symbol(ManaSymbol),
}
impl ManaRewriteInput {
    pub fn matches(self, symbol: ManaSymbol) -> bool {
        match self {
            Self::Any => true,
            Self::Colored => matches!(symbol, ManaSymbol::White | ManaSymbol::Blue |
                ManaSymbol::Black | ManaSymbol::Red | ManaSymbol::Green),
            Self::Symbol(required) => symbol == required,
        }
    }
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, TagKeyWalk)]
pub enum ManaRewriteOutput {
    Symbol(ManaSymbol),
    /// Materialized when a resolving instruction registers its replacement.
    ChosenColor,
    /// A fresh decision when the replacement applies, owned by its controller.
    ChooseColor,
    /// One occurrence selects one matching basic-land rewrite for the entire
    /// production, in Plains/Island/Swamp/Mountain/Forest order. Multiple land
    /// types do not create multiple independently applicable effects.
    ByBasicLandType([Option<ManaSymbol>; 5]),
}

#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, TagKeyWalk)]
pub enum ManaRewriteQuantity {
    Preserve,
    Exact(u32),
}

/// Authoritative typed production rewrite, shared by static and registered
/// replacement owners. None of these semantic fields defaults during decoding.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Debug, Clone, PartialEq, TagKeyWalk)]
pub struct ManaOutputRewrite {
    pub source_filter: crate::filter_model::ObjectFilter,
    #[cfg_attr(feature = "serde", serde(deserialize_with = "crate::mana::deserialize_required_mana_option"))]
    pub controller: Option<crate::filter_model::PlayerFilter>,
    pub tapped_for_mana: bool,
    pub input: ManaRewriteInput,
    pub output: ManaRewriteOutput,
    pub quantity: ManaRewriteQuantity,
}

#[cfg(all(test, feature = "serde"))]
mod mana_output_rewrite_wire_contract {
    use super::*;
    #[test]
    fn new_rewrite_semantics_are_authoritative_and_never_defaulted_from_a_label() {
        let rule = ManaOutputRewrite {source_filter: crate::filter_model::ObjectFilter::land(), controller: None,
            tapped_for_mana: true, input: ManaRewriteInput::Any, output: ManaRewriteOutput::ChooseColor,
            quantity: ManaRewriteQuantity::Exact(1)};
        let wire = serde_json::to_value(&rule).unwrap();
        assert_eq!(serde_json::from_value::<ManaOutputRewrite>(wire.clone()).unwrap(), rule);
        for field in ["source_filter", "controller", "tapped_for_mana", "input", "output", "quantity"] {
            let mut missing = wire.clone(); missing.as_object_mut().unwrap().remove(field);
            assert!(serde_json::from_value::<ManaOutputRewrite>(missing).is_err(), "missing {field}");
        }
    }
}

/// Require the field itself while permitting an explicit null value. Serde's
/// ordinary Option handling would otherwise erase a missing scope silently.
#[cfg(feature = "serde")]
pub(crate) fn deserialize_required_mana_option<'de, D, T>(deserializer: D) -> Result<Option<T>, D::Error>
where D: serde::Deserializer<'de>, T: serde::Deserialize<'de> {
    <Option<T> as serde::Deserialize>::deserialize(deserializer)
}

#[cfg(test)]
mod spending_rule_producer_tests{
 use super::*;
 fn receipt(occurrence:u32,label:&str)->ManaSpendingRuleProducer{ManaSpendingRuleProducer{
  rule:ManaSpendingRestriction::GenericManaByMinusOneCounters,source:crate::ObjectId::from_raw(17),controller:crate::PlayerId::from_index(0),occurrence,ability_designations:vec![label.into()],
 }}
 #[test]
 fn producer_occurrences_survive_repricing_and_are_not_collapsed_by_equal_rules(){
  let first=receipt(0,"siphon");let second=receipt(1,"other ability");
  let cost=ManaCost::from_symbols(vec![ManaSymbol::Generic(3)]).with_spending_rule_producer(first.clone()).with_spending_rule_producer(second.clone()).with_spending_rule_producer(first.clone());
  assert_eq!(cost.spending_restrictions(),&[ManaSpendingRestriction::GenericManaByMinusOneCounters]);assert_eq!(cost.spending_rule_producers(),&[first,second]);
  for repriced in [cost.add_generic(2),cost.reduce_generic(99),cost.with_pips(vec![vec![ManaSymbol::Blue]]),ManaCost::new().inherit_spending_restrictions(&cost)]{
   assert_eq!(repriced.spending_rule_producers(),cost.spending_rule_producers());
  }
  assert!(cost.clone().without_spending_restrictions_for_display().spending_rule_producers().is_empty());
  assert_eq!(cost.clone().without_unit_spending_restrictions().spending_rule_producers(),cost.spending_rule_producers());
 }
 #[cfg(feature="serde")]
 #[test]
 fn frozen_producers_roundtrip_and_older_prices_default_to_no_receipts(){
  let cost=ManaCost::from_symbols(vec![ManaSymbol::Generic(1)]).with_spending_rule_producer(receipt(3,"siphon"));
  let wire=serde_json::to_value(&cost).unwrap();assert_eq!(serde_json::from_value::<ManaCost>(wire).unwrap(),cost);
  let mut old=serde_json::to_value(ManaCost::from_symbols(vec![ManaSymbol::Green])).unwrap();old.as_object_mut().unwrap().remove("spending_rule_producers");
  assert!(serde_json::from_value::<ManaCost>(old).unwrap().spending_rule_producers().is_empty());
 }
}
