// global vars
var valid_formats = ["msem", "fieldtest", "rev", "magic", "revolution", "canon", "beacon"];
// util scripts
function windex(str) {
	return str.replace(/[\\\/|*<>?":]/g, "")
}
function keyFilter(key) {
	return key.replace(/[^A-Za-z0-9]/g, "");
}
function formatTextHTML(str) {
	if(!str)
		return "";
	str = str.replace(/\n/g, "<br>");
	str = str.replace(/[*][*]([^*]+)[*][*]/g, "<b>$1</b>");
	str = str.replace(/[*]([^*]+)[*]/g, "<i>$1</i>");
	str = str.replace(/[{]([^}]+)[}]/g, function(matched, _1) {
		let letters = _1.toLowerCase().replace("/", "")
		return '<span class="mana mana-cost mana-' + letters + '" title="' + _1 + '"></span>';
	})
	return str;
}

// image resolve
function resolveCardImage(card, format, face) {
	let f;
	switch(format) {
		case "msem":
			f = msemLinker
			break;
		case "rev":
		case "revolution":
			f = revLinker
			break;
		case "fieldtest":
			f = ftLinker
			break;
		case "magic":
		case "canon":
			f = scryfallLinker
			break;
		case "beacon":
			f = beaconLinker;
			break;
	}
	if(card.secretKey)
		f = lackeyLinker;
	if(!f)
		return "";
	return f(card, face);
}
function resolvePrintImage(print, card, format, face) {
	print.shape = card.shape;
	return resolveCardImage(print, format, face);
}
function lackeyLinker(card, face) {
	let slug = "/" + card.setID + "/" + card.cardID;
	let lead = "/" + format + "/";
	let mid = "img";
	if(card.doubleface) {
		if(face == "b") {
			mid = "back";
		}else if(face) {
			mid = "front";
		}
	}
	return lead + mid + slug;
}
function msemLinker(card, face) {
	let linky = "https://raw.githubusercontent.com/cajunwritescode/MSEM/refs/heads/main/img/";
	linky += card.setID + "/" + card.cardID;
	if(face === true && card.shape == "doubleface") {
		linky += "a";
	}else if(face && card.shape == "doubleface") {
		linky += face;
	}
	linky += ".jpg";
	return linky;	
}
function revLinker(card, face) {
	let linky = "https://raw.githubusercontent.com/cajunwritescode/Revolution/refs/heads/main/img/";
	linky += card.setID + "/" + card.cardID;
	if(face === true && card.shape == "doubleface") {
		linky += "a";
	}else if(face && card.shape == "doubleface") {
		linky += face;
	}
	linky += ".jpg";
	return linky;	
}
function ftLinker(card, face) {
	let ccn = card.cardName;
	if(card.shape == "split")
		ccn += card.cardName2;
	if(face == "b" && card.shape == "doubleface") {
		if(card.imgName2) {
			ccn = card.imgName2;
		}else{
			ccn = card.cardName2;
		}
	}
	if(card.notes.includes("reprint"))
		ccn += "_" + card.setID;
	ccn = windex(ccn);
	
	let linky = "https://raw.githubusercontent.com/rudyards/field-builder/refs/heads/main/final/pics/";//!setcode!/!corrected_name!.jpg";
	linky += card.setID + "/" + ccn;
	linky += ".jpg";
	return linky;	
}
function scryfallLinker(card, face) {
	let linky = "https://cards.scryfall.io/normal/";
	if(face == "b" && card.shape == "doubleface") {
		linky += "back/";
	}else{
		linky += "front/";
	}
	linky += card.scryID.charAt(0) + "/" + card.scryID.charAt(1) + "/";
	linky += card.scryID + ".jpg";
	return linky;
}
function beaconLinker(card, face) {
	let linky = "https://beacon-of-creation-mtg.github.io/sets/" + card.setID + "-files/img/" + card.cardID;
	if(card.shape == "doubleface") {
		if(face == "b") {
			linky += "_back"
		}else{
			linky += "_front"
		}
	}
	linky += ".png";
	return linky;
}

async function copyCardData(card) {
	let designer = getDesignCredit(card);
	let front = buildCopyCard(card);
	let back = null;

	let has_back = card.hasOwnProperty("cardName2");
	if(front.cancel_back) {
		has_back = false;
		delete front.cancel_back;
	}
	if(has_back)
		back = buildCopyCard(card, "2");

	front.data.card_code_text = await designer;

	if(has_back) {
		front.uid = generateUID();
		back.uid = generateUID();
		front.linked_card_1 = back.uid;
		front.linked_relation_1 = "Back Face";
		back.linked_card_1 = front.uid;
		back.linked_relation_1 = "Front Face";
		back.data.card_code_text = await designer;
	}
	
	let mse_card_data = [front];
	if(has_back)
		mse_card_data.push(back);
	let metadata = JSON.stringify(mse_card_data);
	metadata = "<mse-card-data>" + metadata + "</mse-card-data>";
	
	navigator.clipboard.writeText(metadata);
}
function generateUID() {
	let str = "";
	for(let i=0; i<32; i++) {
		let j = Math.floor(Math.random()*10)
		str += j;
	}
	return str;
}
function buildCopyCard(card, tag = "") {
	let obj = {data:{}};
	obj.mse_object_type = "card";
	obj.data.name = card["cardName"+tag];
	obj.data.casting_cost = formatCastingCost(card["manaCost"+tag]);
	if(obj.data.casting_cost == "")
		obj.data.card_color = formatColorIndicator(card, tag);
	let type_split = splitType(card["typeLine"+tag])
	obj.data.super_type = type_split[0];
	obj.data.sub_type = type_split[1];
	obj.data.rarity = card.rarity;
	if(card.hasOwnProperty("power"+tag))
		obj.data.power = card["power"+tag];
	if(card.hasOwnProperty("toughness"+tag))
		obj.data.toughness = card["toughness"+tag]
	if(card.hasOwnProperty("loyalty"+tag))
		obj.data.loyalty = card["loyalty"+tag];
	if(card.hasOwnProperty("defense"+tag))
		obj.data.loyalty = card["defense"+tag]
	if(card.hasOwnProperty("alias"+tag))
		obj.data.alias = card["alias"+tag];
	obj.data.flavor_text = formatFlavorText(card["flavorText"+tag]);
	reconstructRulesText(card, obj, tag);
	obj.bounds = "<mse-crop-data>29;59;316;231;0</mse-crop-data>"
	
	let is_subroutine = obj.data.sub_type.match(/Subroutine/);
	let is_ruin = obj.data.sub_type.match(/Ruin/);
	let is_cybaros = obj.data.casting_cost.match(/C/) && card.prints.includes("CYB");
	if(is_ruin || is_subroutine) {
		if(!obj.styling_data)
			obj.styling_data = {};
		if(obj.styling_data.frames) {
			obj.styling_data.frames += ", custom border";
		}else{
			obj.styling_data.frames = "custom border";
		}
		if(is_ruin) {
			obj.custom_border_source = "custom_border/subroutine/-color-subroutine.png";
		}else if(is_subroutine) {
			obj.styling_data.custom_border_source = "custom_border/ruin.png";
		}else if(is_cybaros) {
			let hybrid = obj.data.casting_cost.match("/");
			let multi = false;
			if(!hybrid) {
				multi = obj.data.casting_cost.match(/[WUBRG]/);
			}
			if(hybrid) {
				obj.styling_data.custom_border_source = "custom_border/CYB/colorless_left.png";
			}else if(multi) {
				obj.styling_data.custom_border_source = "custom_border/CYB/colorless_bottom.png";
			}else{
				obj.styling_data.custom_border_source = "custom_border/CYB/colorless.png";
			}
		}
	}
	
	if(!obj.hasOwnProperty("stylesheet")) {
		if(obj.data.super_type.match("Token")) {
			obj.stylesheet = "m15-mainframe-tokens";
			delete obj.bounds;
		}else if(obj.data.super_type.match("Emblem")) {
			obj.stylesheet = "m15-emblem";
			delete obj.bounds;
		}else{
			obj.stylesheet = "m15-altered";
		}
	}
	
	if(obj.stylesheet == "m15-altered") {
		if(card.rulesText.match(/^Wu Xing/)) {
			if(!obj.extra_data)
				obj.extra_data = {"m15-altered":{}};
			obj.extra_data["m15-altered"].alternate_pinlines = "multicolor";
		}
		if(card.rulesText.match(/^Attain /m) && tag == "2") {
			if(!obj.extra_data)
				obj.extra_data = {"m15-altered":{}};
			obj.extra_data["m15-altered"].alternate_pinlines = "multicolor";
		}
	}
	delete obj.bounds;
	return obj;
}
async function getDesignCredit(card) {
	let getSet = getCookie("setCredits") == "true";
	if(getSet && format != "magic") {
		if(!additional_data.cache)
			additional_data.cache = {};
		let cache = await pingLackey("/" + format + "/setinfo/api", "POST", {})
		additional_data.cache.sets = cache.sets;
		additional_data.cache.formats = cache.formats;
	}
	return new Promise((resolve) => {
		if(format == "magic") {
			resolve("");
			return;
		}
		let designer = card.designer;
		if(!getSet) {
			resolve(designer);
		}
		else {
			let fp = card.firstPrint;
			if(!fp)
				resolve(designer);
			let splitter = fp.split("_");
			if(splitter.length <= 1)
				resolve(designer);
			let set_code = splitter[splitter.length-1];
			if(!additional_data.cache.sets[set_code])
				resolve(designer);
			designer = additional_data.cache.sets[set_code].longname;
			resolve(designer);
		}
	});
}
function formatColorIndicator(card, tag) {
	if(card["typeLine"+tag].match(/Land/))
		return undefined;
	let color = card["color"+tag];
	let colors = [];
	let ar = ["White", "Blue", "Black", "Red", "Green"];
	for(let a in ar) {
		if(color.match(ar[a]))
			colors.push(ar[a].toLowerCase());
	}
	if(colors.length == 0)
		return null;
	if(colors.length == 1)
		return colors[0];
	if(colors.length == 2)
		return colors[0] + ", " + colors[1] + ", multicolor"
	if(colors.length > 2)
		return "multicolor";
}
function reconstructRulesText(card, obj, tag) {
	let rule_text = reformatRulesText(card["rulesText"+tag]);
	let lines = rule_text.split("\n");	
	// reconstruct Adventure
	if(card.shape == "adventure") {
		obj.stylesheet = "m15-adventure"
		obj.cancel_back = true;
		obj.data.name_2 = card.cardName2;
		obj.data.casting_cost_2 = formatCastingCost(card.manaCost2);
		let type_split = splitType(card.typeLine2);
		obj.data.super_type_2 = type_split[0];
		obj.data.sub_type_2 = type_split[1];
		obj.data.rule_text_2 = reformatRulesText(card.rulesText2);
		obj.data.flavor_text_2 = formatFlavorText(card.flavorText2);
		obj.has_styling = true;
		if(!obj.styling_data)
			obj.styling_data = {};
		let supported = obj.data.sub_type_2.match(/(Adventure|Omen|Tale|Mythos|Discharge)/);
		let key = (supported != null ? supported[1] : "fallback")
		switch(key) {
			case "Adventure":
				obj.styling_data.left_style = "name and type page";
				obj.styling_data.right_style = "blank page";
				break;
			case "Omen":
				obj.styling_data.left_style = "name and type omen";
				obj.styling_data.right_style = "none";
				break;
			case "Tale":
				obj.styling_data.left_style = "blank page";
				obj.styling_data.right_style = "name and type page";
				break;
			case "Mythos":
				obj.styling_data.left_style = "blank page";
				obj.styling_data.right_style = "name and type page";
				obj.styling_data.frames = "devoid";
				break;
			case "Discharge":
				obj.styling_data.left_style = "none";
				obj.styling_data.right_style = "name and type flat";
				obj.styling_data.page_decoration = "examples/decoration/light.png;color";
				break;
			default:
				// assume prepared
				obj.styling_data.left_style = "none";
				obj.styling_data.right_style = "name and type omen";
		}
		// don't return to handle adventure walkers
	}
	if(rule_text.match(/^(Forsake|Paradigm|Prototype)/)) {
		// reconstruct prototype
		let res = splitPrototype(lines[0]);
		let clean = lines.splice(0, 1);
		obj.data.rule_text = clean.join("\n");
		obj.data.level_1_text = res[0];
		obj.data.casting_cost_2 = formatCastingCost(res[1]);
		if(res[2] !== null)
			obj.data.power_2 = res[2];
		if(res[3] !== null)
			obj.data.toughness_2 = res[3];
		if(res[4] !== null)
			obj.data.super_type_2 = res[4];
		if(res[5] !== null)
			obj.data.sub_type_2 = res[5];
		obj.has_styling = true;
		if(!obj.styling_data)
			obj.styling_data = {};
		obj.styling_data.frames = "prototype";
		if(res[4] !== null || res[5] != null)
			obj.styling_data.prototype_secondary = "type";
		obj.cancel_back = true;
		// don't return to handle prototype walkers
	}
	if(obj.data.super_type.match(/Planeswalker/)) {
		// reconstruct planeswalker
		for(let i=1; i<9; i++) {
			if(!lines[i-1])
				break;
			let res = splitLoyalty(lines[i-1]);
			if(res[0] != "")
				res[1] = "<margin:130:0:0>" + res[1] + "</margin:130:0:0>";
			obj.data["loyalty_cost_"+i] = res[0];
			obj.data["level_"+i+"_text"] = res[1];
		}
		delete obj.bounds;
		let options = "un-indent nonloyalty abilities";
		if(obj.styling_data?.frames?.match("prototype")) {
			delete obj.styling_data.frames;
			options += ", prototype";
		}
		if(obj.stylesheet == "m15-adventure") {
			if(obj.styling_data.left.includes("name")) {
				options += ", adventure"
			}else{
				options += ", reversed adventure";
			}
			delete obj.styling_data.right_style;
			delete obj.styling_data.left_style;
			delete obj.styling_data.page_decoration;
			delete obj.styling_data.frames;
		}
		if(!obj.styling_data)
			obj.styling_data = {};
		obj.styling_data.other_options = options;
		obj.stylesheet = "m15-mainframe-planeswalker";
		// todo image
		return;
	}
	
	if(obj.data.super_type.match(/Plane/)) {
		// reconstruct plane
		obj.data.level_2_text = lines.pop();
		obj.data.level_1_text = lines.join("\n")
		obj.stylesheet = "plane";
		delete obj.bounds;
		return;
	}
	if(obj.data.sub_type.match(/Saga|Discovery|Quest|Mystery|Policy|Campaign|Realm/)) {
		// reconstruct Saga
		let is_quest = obj.data.sub_type.match(/Quest/);
		let snaps = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
		let counter = 0;
		let i = 0;
		let bumper = 0;
		for(i; i<9; i++) {
			if(!lines[i+bumper])
				break;
			let res = splitSaga(lines[i+bumper]);
			if(i == 0) {
				obj.data.chapter_text = res[1];
				if(is_quest) {
					bumper++
					obj.data.chapter_text += "\n" + lines[i+bumper];
				}
				continue;
			}
			obj.data["level_"+i+"_text"] = res[1];
			if(res[0] != "") {
				let vals = res[0].split(", ");
				for(let v in vals) {
					let val = vals[v];
					let ind = chapter_icons.indexOf(val);
					if(ind < 0)
						ind = quest_icons.indexOf(val)
					if(ind < 0) {
						snaps[counter] = i;
					}else{
						snaps[ind] = i;
					}
					counter++;
				}
			}
		}
		let boxes = "";
		switch(i-1) {
			case 1:
				boxes = "one";
				break;
			case 2:
				boxes = "two";
				break;
			case 4:
				boxes = "four";
				break;
			case 5:
				boxes = "five";
				break;
			case 6:
				boxes = "six";
				break;
		}
		let snap_str = (snaps.join(",")+",").replace(/(0,)+$/, "")
		obj.has_styling = true;
		if(!obj.styling_data)
			obj.styling_data = {};
		obj.styling_data.snap_chapter_to_box = snap_str;
		if(boxes)
			obj.styling_data.chapter_textboxes = boxes;
		obj.stylesheet = "m15-saga";
		if(obj.data.sub_type.match(/Discovery/)) {
			obj.styling_data.custom_chapter_location = "examples/symbol/discovery.png";
			obj.styling_data.custom_chapter_name = "Discovery";
		}
		if(obj.data.sub_type.match(/Realm/)) {
			obj.styling_data.custom_chapter_location = "sagas/favor.png";
			obj.styling_data.custom_chapter_name = "Favor";
		}
		if(obj.data.sub_type.match(/Mystery/)) {
			obj.styling_data.replacement_chapter_location = "sagas/mystery/";
		}
		if(obj.data.sub_type.match(/Policy/)) {
			obj.styling_data.replacement_chapter_location = "sagas/policy/";
		}
		if(obj.data.sub_type.match(/campaign/)) {
			obj.styling_data.replacement_chapter_location = "sagas/campaign/";
		}
		if(is_quest) {
			obj.notes = "!altleader 1,2,3,4,5,6,";
			obj.styling_data.replacement_chapter_location = "sagas/quest/";
		}
		obj.bounds = "<mse-crop-data>188;60;157;377;0</mse-crop-data>"
		return;
	}
	if(rule_text.match(/^(Transcend|Diverge)/) || obj.data.sub_type.match(/Module|Gallery|Class|Operation/)) {
		// reconstruct Class
		let bumper = 0;
		let is_module = obj.data.sub_type.match(/Module/);
		for(let i=0; i<9; i++) {
			if(!lines[i+bumper])
				break;
			if(is_module && i == 1) {
				bumper--;
				continue;
			}
			let res = splitClass(lines[i+bumper]);
			if(i == 0) {
				obj.data.chapter_text = res[2]
				continue;
			}
			if(res[0] != null)
				obj.data["level_"+(7+i)+"_text"] = res[0];
			if(res[1] != null)
				obj.data["level_"+i] = res[1];
			if(res[0] == null && res[1] == null && obj.data.hasOwnProperty("level_1_text") && !obj.data.hasOwnProperty("level_2_text")) {
				obj.data.level_1_text += "\n" + res[2];
				bumper++;
				i--;
			}else if(res[2] == null) {
				bumper++
				obj.data["level_"+i+"_text"] = lines[i+bumper];
			}else{
				obj.data["level_"+i+"_text"] = res[2];
			}
		}
		for(let i=2; i<7; i++) {
			if(obj.data[`level_${i}_text`] != "")
				obj.data[`level_${i}_text`] = "<margin:0:0:30>" + obj.data[`level_${i}_text`] + "</margin:0:0:30>"
		}
		obj.has_styling = true;
		if(!obj.styling_data)
			obj.styling_data = {};
		obj.styling_data.other_options = "class";
		if(is_module)
			obj.styling_data.class_levels = "cyber";
		if(obj.data.sub_type.match(/Operation/)) {
			obj.styling_data.class_levels = "operation";
			obj.styling_data.other_options += ", use defense";
		}
		if(rule_text.match(/^(Transcend|Diverge)/))
			obj.styling_data.auto_frames = "nyx, vehicle, snow";
		if(obj.data.sub_type.match(/Gallery/))
			obj.styling_data.class_levels = "unnotched";
		obj.bounds = "<mse-crop-data>29;60;157;377;0</mse-crop-data>"
		obj.stylesheet = "m15-saga";
		return;
	}
	if(rule_text.match(/\[(Level|Progress|Shape|Lore)/i)) {
		// reconstruct leveler
		let level_label = "";
		let bumper = -1;
		for(let i=1; i<6; i++) {
			let line = lines[i+bumper];
			if(!line)
				break;
			let level_numbers = "", level_text = "";
			let level_power = "", level_toughness = "";
			// pop off the pt
			let rev = reverseLine(line);
			let pt_splitter = rev.match(/^\]([0-9XY]+)\/([0-9XY]+)\[ ?(.*)/);
			if(pt_splitter) {
				level_power = pt_splitter[2];
				level_toughness = pt_splitter[1];
				line = reverseLine(pt_splitter[3]);
			}
			// pop off the arrow
			let splitter = line.match(/^\[([^\]]+)\] ([^\r\n]+)/);
			if(splitter) {
				// a level
				let level_box = splitter[1] || "";
				let level_splitter = level_box.match(/^([^ ]+) (.*)$/);
				if(level_splitter) {
					if(level_label == "")
						level_label = level_splitter[1];
					level_numbers = level_splitter[2];
				}
				
				level_text = splitter[2];
			}
			else {
				// non-arrow text
				// either the very first textbox
				// or a linebreak in a level
				if(!obj.data[`level_${i-1}_text`]) {
					level_text = line;
				}else{
					i--;
					bumper++;
					level_text = obj.data[`level_${i}_text`] + "\n" + line;
				}
			}
			
			if(level_numbers != "")
				obj.data[`level_${i-1}`] = level_numbers;
			if(level_text != "")
				obj.data[`level_${i}_text`] = level_text;
			let pt_tags = ["", "", "_2", "_3", "_7"];
			if(level_power != "")
				obj.data[`power${pt_tags[i]}`] = level_power;
			if(level_toughness != "")
				obj.data[`toughness${pt_tags[i]}`] = level_toughness;
		}
		// currently all our levelers are arrow
		if(!obj.has_styling) {
			obj.has_styling = true;
			obj.styling_data = {};
		}
		if(!obj.styling_data.frames) {
			obj.styling_data.frames = "leveler";
		}else{
			obj.styling_data.frames += ", leveler";
		}
		if(level_label != "" && !level_label.match(/level/i)) {
			obj.styling_data.level_label = level_label.toLowerCase();
		}
	}

	if(obj.data.super_type.match(/Battle/))
		obj.stylesheet = "magic-m15-mainframe-battles";
	if(!obj.data.hasOwnProperty("rule_text") && !obj.data.hasOwnProperty("level_1_text"))
		obj.data.rule_text = rule_text;
}
function fixModals(obj) {
	if(obj.data.rule_text)
		obj.data.rule_text = fixModalTextbox(obj.data.rule_text);
	if(obj.data.rule_text_2)
		obj.data.rule_text_2 = fixModalTextbox(obj.data.rule_text_2);
	for(let i=1; i<9; i++) {
		if(obj.data["level_"+i+"_text"])
			obj.data["level_"+i+"_text"] = fixModalTextbox(obj.data["level_"+i+"_text"]);
	}
}
function fixModalTextbox(txt) {
	let lines = txt.split("\n");
	// fix modals
	for(let i=0; i<lines.length; i++) {
		let previous_line = lines[i-1];
		let line = lines[i];
		let next_line = lines[i+1];
		if(!line.match(/^•/))
			continue;
		line = "<li><margin:0:0:3><bullet>• </bullet>" + line + "</margin:0:0:3>";
		if(previous_line && previous_line.match(/<soft-line>$/))
			line = "</soft-line>" + line;
		if(next_line && next_line.match(/^•/))
			line = line + "<soft-line>";
	}
	return lines.join("\n");
}
function reverseLine(str) {
	return str.split("").reverse("").join("");
}
function reformatRulesText(str) {
	// remove * around parens
	// replace other ** wraps with <i></i>
	// replace {} with <sym></sym>
	str = str.replace(/[*]\(/g, "(");
	str = str.replace(/\)[*]/g, ")");
	str = str.replace(/[*]([^\n*]+)[*]/g, function(_0, _1) {
		return "<i>" + _1 + "</i>";
	})
	str = str.replace(/{([0-9A-Z][^}]*)}/g, function(_0, _1) {
		return "<sym>" + _1 + "</sym>";
	})
	return str;
}
function formatFlavorText(flavor_text) {
	if(flavor_text == "")
		return flavor_text;
	flavor_text = flavor_text.replace(/\n([*]?)$/, "$1");
	flavor_text = flavor_text.replace(/^[*]/, "<i-flavor>").replace(/[*]$/, "</i-flavor>")
	flavor_text = flavor_text.replace(/[*]([^*])([*])?/g, function(_0, _1, _2) {
		let str = "</i>" + _1;
		if(_2 != "")
			str += "<i>";
		return str;
	})
	return flavor_text;
}
function formatCastingCost(str) {
	return str.replace(/[{}]/g, "").replace(/<\/?sym>/g, "")
}
function trim(str) {
	return str.replace(/^[ \t]+/, "").replace(/[ \t]+$/, "");
}
function splitType(str) {
	let splitter = str.split(/[—-]/);
	let sp = trim(splitter[0])
	let sb = "";
	if(splitter[1])
		sb = trim(splitter[1]);
	return [sp, sb];
}
function splitLoyalty(str) {
	let matcher = str.match(/^\[([0-9X+−-]+)]: (.*)/);
	if(matcher)
		return [fixMinus(matcher[1]), matcher[2]];
	return ["", str];
}
function fixMinus(str) {
	return str.replace("−", "-");
}
var chapter_icons = ["I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"];
var quest_icons = ["1", "2", "3", "4", "5", "6"];
function splitSaga(str) {
	
	let matcher = str.match(/^([^—(*]*) — (.*)/);
	
	if(!matcher)
		return ["", str];
	
	let singles = ["Discovery", "Favor", "{mg}", "{f}", "[f]", "{ql}"];
	if(singles.includes(matcher[1]) || chapter_icons.includes(matcher[1]) || quest_icons.includes(matcher[1]))
		return [matcher[1], matcher[2]]
	if(matcher[1].match(/^[1-9], [1-9]/))
		return [matcher[1], matcher[2]];
	if(matcher[1].match(/^[IVX]+, [IXV]+/))
		return [matcher[1], matcher[2]];
	if(matcher[1].match(/^[[{]f[}\]],/))
		return [matcher[1], matcher[2]];
	return ["", str];
}
function splitClass(str) {
	// 0 - class cost
	// 1 - class level
	// 2 - class level text, if null use next line break as it
	
	let split = str.split("—");
	let matcher = split[0].match(/([^:]+:) (.*)/);
	if(!matcher) { // try for operation
		matcher = split[0].match(/(Defeated|[0-9] Defense)/);
		if(matcher)
			matcher = [matcher[0], "", matcher[1]]
	}
	if(!matcher)
		return [null, null, str]
	let res = [];
	res.push(formatCastingCost(matcher[1]));
	res.push(trim(matcher[2]))
	if(split[1]) {
		res.push(trim(split[1]));
	}else{
		res.push(null);
	}
	return res;
}
function splitPrototype(str) {
	let matcher = str.match(/([^ ]+) ([^ ]+) — ([^(]+) ?(.*)$/);
	let kw = matcher[1];
	let cost = matcher[2];
	let pt_type = matcher[3];
	let remind = matcher[4];
	
	let res = []
	res.push(kw + " " + remind);
	res.push(cost.replace(/[{}]/g, ""))
	
	let pt_match = pt_type.match(/([0-9X]+)\/([0-9X]+)/);
	if(pt_match) {
		res.push(pt_match[1])
		res.push(pt_match[2])
		res.push(null)
		res.push(null)
	}else{
		type_split = splitTypes(pt_type);
		res.push(null)
		res.push(null)
		res.push(type_split[0])
		res.push(type_split[1])
	}
	return res;
}
// printing flipper
// end